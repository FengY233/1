# WoT 2.4 CN —— 18 个扩展 pkg 的 entity_defs / component_defs / client 清单

导出时间 2026-09-24。**只读操作，未改动客户端任何文件。**
源 = 客户端 `res/packages/*.pkg`（普通 zip，7-zip 可开）。

---

## 一、这批东西是什么

客户端把「玩法扩展」（战斗 royale、前线、背水一战、故事模式、白虎行动…）
各自打进一个独立 `.pkg`。每个 pkg 内部是：

```
<ext>/
  extension.xml        ← 扩展注册（组件名 / 依赖 / 特性开关）
  scripts/
    entity_defs/       ← 该扩展新增的【实体】
    component_defs/    ← 该扩展新增的【组件】
    arena_defs/        ← 竞技场定义（音效等）
    client/            ← 该扩展的客户端 Python（.pyc）
  gui/ vscript/ audioww/ ...   ← 资源
```

**实体（entity）与组件（component）是 BigWorld 服务端/客户端都在用的类型定义**，
它们决定 wire 上「哪些属性发、发给谁（Flags）、方法有几个参数」。
⇒ **这是还原服务端时「元素号/属性下标」之外的另一个地基。**

---

## 二、目录结构

```
wot24_ext_defs/
├─ README.md            本文件
├─ MANIFEST.tsv         224 个 def/扩展文件的字节数与解码状态
├─ INDEX.tsv            224 行：每个 def 的 ofEntity / Parent / DefaultKeyName / 方法族
└─ ext_defs/<ext>/
   ├─ entity_defs/*.xml      解码后的实体定义
   ├─ component_defs/*.xml   解码后的组件定义
   ├─ arena_defs/*.xml       解码后的竞技场定义
   ├─ extension.xml          解码后的扩展注册
   ├─ client_files.txt       ★ pkg 内 client/ 文件清单（每行一个路径）
   ├─ all_files.txt          pkg 全部成员（含资源，用于判归属）
   └─ _raw/                  ★ 原始二进制 .def（保真，供逐字节复核）
```

**`_raw/` 是原封不动的 pkg 内字节**，任何对 `*.xml` 的怀疑都可以拿它重解。

---

## 三、★ 格式：`.def` / `extension.xml` 都不是文本，是 BWXML 二进制

magic = `45 4E A1 62`（ASCII `EN\xa1b`），之后：

```
[4B magic][1B 未知]
串池: NUL 结尾串连写，遇空串终止
元素: [u16 子数][u32 自描述 = type<<28 | end_offset]
      子数 × { [u16 名字索引][u32 自描述] }
      数据: 自身,然后各子(按序);标量长度 = end_offset - 前一 end_offset
类型: 0=Element 1=String 2=Integer 3=Vector 4=Boolean 5=base64
```

### ★★★ 三个坑（我踩过，逐条给你）

1. **类型名 `ARRAY` / `FIXED_DICT` / `TUPLE` / `STRING` 不在串池里。**
   它们是 Element 节点的**「自身值」**（`[u16 子数][u32 描述]` 之后紧跟的那一段），
   以「父节点的名字」为标签存在。
   ⇒ 写解析器时如果只遍历 `(名字, 值)` 的子元组，**会把这些类型名整片丢掉**，
   输出看起来完全正常、但 `ARRAY` 会凭空消失。本包的渲染规则 =
   `以父名为标签写成 <父名>值</父名>`（如 `<Type>ARRAY</Type>`、`<of>TUPLE</of>`、
   `<Arg>ARRAY</Arg>`）。

2. **`<Properties>` 里每个属性的类型是「套一层 `<Type>`」**，不是属性自己的值：
   ```xml
   <pickupRange>
     <Type>FLOAT32</Type>
     <Flags>ALL_CLIENTS</Flags>
   </pickupRange>
   ```
   而**复杂类型要递归**：`ARRAY` 用 `<of>`，`FIXED_DICT` 再用一层 `<Properties>`。

3. **结构区是字节流，不是 u16 对齐的。** 别按 2 字节对齐去切。

### 解码器（已开源在仓库里）

`C:\wot24\tools\bwxml_decode.py`（130 行，纯 stdlib）+ `def_dump.py`。
本包用的渲染器 = `C:\wot24\tools\export_ext_defs.py`。
校验器 = `C:\wot24\tools\verify_ext_defs.py`（见 §六）。

---

## 四、18 个扩展 pkg 一览（全部实测）

| pkg | 字节 | def | client 文件 |
|---|---|---|---|
| battle_royale | 186.5 MB | 43 | 323 |
| comp7 | 391.4 MB | 6 | 422 |
| comp7_core | 4.9 MB | 8 | 123 |
| comp7_light | 52.7 MB | 4 | 215 |
| event_platform | 3.2 MB | 3 | 13 |
| fall_tanks | 65.7 MB | 4 | 97 |
| frontline | 49.5 MB | 15 | 266 |
| fun_random | 60.2 MB | 3 | 248 |
| in_battle_achievements | 7.5 KB | 3 | 2 |
| la_pinger | 3.3 KB | 1 | 2 |
| last_stand | 634.2 MB | 71 | 422 |
| open_bundle | 44.7 MB | 1 | 71 |
| resource_well | 47.9 MB | 1 | 81 |
| server_side_replay | 4.3 MB | 1 | 57 |
| story_mode | 1387.9 MB | 26 | 202 |
| white_tiger | 373.5 MB | 30 | 311 |
| battle_modifiers | 573.1 KB | 1 | 27 |
| content_exclude | 326 B | 1 | 0 |

★ 另有 `h33_battle_royale_2021` / `h33_comp7` / `hangar_v4` / `hangar_v4_last_stand`
**零 scripts**（纯地图/机库资源），不在这批里。

---

## 五、★ 两个「不是你以为的那样」的实测结论

### 5.1 `interfaces` 不在扩展包里 —— 零个

扩展包 `scripts/` 下**没有** `interfaces/` 目录。
`interfaces` 只在**主** `scripts.pkg` 里：`scripts/entity_defs/interfaces/`，**61 个**。

**并且我实测：16 个扩展的 224 个 def，引用主包 61 个接口名的次数 = 0。**
⇒ **接口不属于这批交付物。** 要接口去 `scripts.pkg`。

### 5.2 扩展实体会继承主包实体 —— 3 处

`<Parent>` 字段指向主包实体：

| 扩展 | 实体/组件 | Parent |
|---|---|---|
| story_mode | SPGZone | `AreaOfEffect` |
| fall_tanks | FallTanksRespawnComponent | `VehicleRespawnComponent` |
| story_mode | SMVehicleRespawnComponent | `VehicleRespawnComponent` |

⇒ **读这三个时，得连同主包的定义一起读**，否则缺属性。

### 5.3 主包 41 个实体（供交叉引用）

`Account AreaDestructibles AreaOfEffect ArenaInfo ArenaObserverInfo
AttackArtilleryFort AttackBomber Avatar AvatarInfo BasicMine
ClientSelectable* DebugDrawEntity DestructibleEntity DetachedTurret
EmptyEntity Flock FlockExotic HangarVehicle HeroTank LimitedVisibilityEntity
Login NetworkEntity OfflineEntity PersonalDeathZone PlatoonLighting
PlatoonTank ProtectionZone RepairBase Sector SectorBase SimulatedVehicle
StaticDeathZone StepRepairPoint TeamInfo Vehicle`

---

## 六、怎么验（别信我的话，自己跑）

```bash
# 逐字节复核：224 个 _raw 与 pkg 内字节全等 + 全部解完 + 属性名全在串池
py -3 C:/wot24/tools/verify_ext_defs.py <本目录>
```

六项断言：
| # | 断言 |
|---|---|
| V1 | MANIFEST 行数 == 各 pkg 里 def 文件数之和 |
| V2 | 每个 `_raw` 字节 == pkg 内字节（逐字节） |
| V3 | 每个 `_raw` 都能解完（consumed == 文件长度） |
| V4 | 解码 xml 里每个属性名都在该 def 的串池里 |
| V5 | `ARRAY`/`FIXED_DICT`/`TUPLE` 等自身值一个没丢 |
| V6 | `client_files.txt` 行数 == pkg 内 `/scripts/client/` 文件数 |

**实测：224/224 全过。**

---

## 七、诚实标注：没做 / 没验的

- **`client/*.pyc` 本身没有反编译**，只给了**文件清单**（路径 + 数量）。
  ★ **但源码你已经有了**：`C:\wot-src24\sources\res\<ext>\scripts\client\`
  里是**反编译成品**（16 个扩展目录全在），**不要去重跑反编译器**。
  **且我逐个核过：`.py` 数量与本包 `client_files.txt` 的 `.pyc` 数量完全一致**
  （如 comp7 = 422/422、last_stand = 422/422、white_tiger = 311/311、共 17 个扩展全对）。
  ⇒ 清单可以直接当**源码目录的索引**用。
- **GUI 资源（`gui/`、`vscript/`、`audioww/`）没导出**，只进了 `all_files.txt` 清单。
- **`ofEntity` 有两个小写 `vehicle`**（`white_tiger` 的 `WTStatCollectorHarrier`
  与 `WTStatCollectorPlayer`）。我核了原始字节：**源文件里就是小写**
  （串池 `76 65 68 69 63 6c 65`），是 WG 自己的笔误，不是解码错误。
  **按原样保留**，但引用时留意大小写。
- **`comp7_light` 与 `server_side_replay` 的 `arena_defs/_default_.xml` 只有 12 字节**
  （空 bwxml 文档，dict 0）。是真的空，不是没解出来。
- **BWXML 的 `[1B 未知]`（magic 后那 1 字节）含义未定**。实测恒为 `00`。

---

## 八、链条对账

| 环 | 内容 | 标记 |
|---|---|---|
| 1 | 18 个 pkg 是 zip、可读、内部布局 | **`[读]`** 直接解压 |
| 2 | def 文件是 BWXML（magic `45 4E A1 62`） | **`[读]`** 原始字节 |
| 3 | 224 个 def 全部解完（consumed == len） | **`[读]`** V3 实测 |
| 4 | 解码渲染正确（含自身值不丢） | **`[读]`** V5 实测 30 个含类型名 |
| 5 | 扩展 def 不引用主包 61 个接口 | **`[读]`** 全量扫串池，命中 0 |
| 6 | 3 处 `<Parent>` 继承主包实体 | **`[读]`** INDEX.tsv |
| 7 | BWXML `[1B 未知]` 的语义 | **`[推]`** 观察到恒 0，未找到定义 |

**剩 1 个 `[推]`（第 7 环，且它不影响任何交付内容）⇒ 按 R2，不称「闭环」。**
