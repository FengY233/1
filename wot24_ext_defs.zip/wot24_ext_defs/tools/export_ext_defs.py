# -*- coding: utf-8 -*-
"""export_ext_defs.py — 从客户端 18 个扩展 pkg 导出 entity_defs / component_defs /
arena_defs(.xml) + client 文件清单，产出可交给「另一个 AI」的自包含包。

用法:
  py -3 tools/export_ext_defs.py <outDir>

产出:
  <outDir>/ext_defs/<ext>/entity_defs/*.xml    已解码的 entity def
  <outDir>/ext_defs/<ext>/component_defs/*.xml 已解码的 component def
  <outDir>/ext_defs/<ext>/arena_defs/*.xml     已解码的 arena def
  <outDir>/ext_defs/<ext>/_raw/*.def           原始二进制（保真，供复核）
  <outDir>/ext_defs/<ext>/client_files.txt     client 文件清单
  <outDir>/MANIFEST.tsv                        总索引
"""
import io
import os
import sys
import zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bwxml_decode as B  # noqa: E402

PKG_DIR = u'//vmware-host/Shared Folders/World_of_Tanks_CN/res/packages/'

# 18 个「扩展」pkg（相对核心 scripts.pkg 而言）。含 defs 的在此。
EXTS = ['battle_royale', 'comp7', 'comp7_core', 'comp7_light', 'event_platform',
        'fall_tanks', 'frontline', 'fun_random', 'in_battle_achievements',
        'la_pinger', 'last_stand', 'open_bundle', 'resource_well',
        'server_side_replay', 'story_mode', 'white_tiger']

# 无 defs 但名字带扩展语义的（一并导出 client 清单 + extension.xml）
EXTS_NO_DEFS = ['battle_modifiers', 'content_exclude']

KINDS = ['entity_defs', 'component_defs', 'interfaces', 'arena_defs']


def esc(s):
    return (s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
             .replace('"', '&quot;'))


def to_xml(node, rdict, out, depth, label=None):
    """把解码树渲染成可读 XML（保结构，不是原始字节）。

    ★★ 关键：bwxml 的 Element 节点可能自带一个「自身值」——
      <Type>ARRAY</Type> / <of>TUPLE</of> / <Arg>ARRAY</Arg> 这种，
      是「名字 + 自身值」，不是「名字 + 子元素」。
      bwxml_decode.read_element 把自身值放在列表的第 0 位（非 tuple）。
      **类型名 ARRAY / FIXED_DICT / TUPLE / STRING 不在串池里**，只以自身值存在，
      丢了它们 = 类型信息整片消失。
      渲染规则：以「父节点的名字」作标签，把自身值写成 <父名>值</父名>。
    """
    pad = '  ' * depth
    if not isinstance(node, list):
        out.write(u'%s%s\n' % (pad, esc(u'%s' % node)))
        return
    if not node:
        return
    selfv = None
    for c in node:
        if not isinstance(c, tuple):
            selfv = c
            break
    children = [c for c in node if isinstance(c, tuple)]
    if selfv is not None and (u'%s' % selfv) != '' and label:
        out.write(u'%s<%s>%s</%s>\n' % (pad, label, esc(u'%s' % selfv), label))
        if not children:
            return
    for name_idx, v in children:
        name = rdict[name_idx] if name_idx < len(rdict) else '?%d' % name_idx
        if isinstance(v, list):
            out.write(u'%s<%s>\n' % (pad, name))
            to_xml(v, rdict, out, depth + 1, label=name)
            out.write(u'%s</%s>\n' % (pad, name))
        else:
            out.write(u'%s<%s>%s</%s>\n' % (pad, name, esc(u'%s' % v), name))


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    outdir = sys.argv[1]
    manifest = []
    total_defs = 0

    for ext in EXTS + EXTS_NO_DEFS:
        pkg = os.path.join(PKG_DIR, ext + '.pkg')
        if not os.path.isfile(pkg):
            print('!! 缺 pkg: %s' % pkg)
            continue
        z = zipfile.ZipFile(pkg)
        names = z.namelist()

        # ---- defs ----
        for kind in KINDS:
            members = sorted(x for x in names
                             if ('/scripts/%s/' % kind) in x and not x.endswith('/'))
            if not members:
                continue
            for m in members:
                base = m.split('/')[-1]
                stem = os.path.splitext(base)[0]
                raw = z.read(m)
                # 原样落盘
                rd = os.path.join(outdir, 'ext_defs', ext, '_raw', kind)
                os.makedirs(rd, exist_ok=True)
                with open(os.path.join(rd, base), 'wb') as f:
                    f.write(raw)
                # 解码成 XML
                txt = io.StringIO()
                try:
                    rdict, tree, used = B.decode(raw)
                    txt.write(u'<?xml version="1.0" encoding="utf-8"?>\n')
                    txt.write(u'<!-- %s :: %s  (%d B, bwxml dict %d, consumed %d/%d) -->\n'
                              % (ext, m, len(raw), len(rdict), used, len(raw)))
                    to_xml(tree, rdict, txt, 0)
                    status = 'ok'
                except Exception as e:
                    txt.write(u'<!-- DECODE FAILED: %s -->\n' % e)
                    status = 'FAIL:%s' % e
                od = os.path.join(outdir, 'ext_defs', ext, kind)
                os.makedirs(od, exist_ok=True)
                outp = os.path.join(od, stem + '.xml')
                with open(outp, 'w', encoding='utf-8', newline='\n') as f:
                    f.write(txt.getvalue())
                manifest.append((ext, kind, base, len(raw), status))
                total_defs += 1

        # ---- extension.xml ----
        ex = [x for x in names if x.endswith('extension.xml')]
        for m in ex:
            raw = z.read(m)
            rd = os.path.join(outdir, 'ext_defs', ext, '_raw')
            os.makedirs(rd, exist_ok=True)
            with open(os.path.join(rd, 'extension.xml'), 'wb') as f:
                f.write(raw)
            try:
                rdict, tree, used = B.decode(raw)
                txt = io.StringIO()
                txt.write(u'<?xml version="1.0" encoding="utf-8"?>\n')
                txt.write(u'<!-- %s :: %s  (%d B) -->\n' % (ext, m, len(raw)))
                to_xml(tree, rdict, txt, 0)
                with open(os.path.join(outdir, 'ext_defs', ext, 'extension.xml'),
                          'w', encoding='utf-8', newline='\n') as f:
                    f.write(txt.getvalue())
                manifest.append((ext, 'extension.xml', m, len(raw), 'ok'))
            except Exception as e:
                manifest.append((ext, 'extension.xml', m, len(raw), 'FAIL:%s' % e))

        # ---- client 文件清单 ----
        cl = sorted(x for x in names if '/scripts/client/' in x and not x.endswith('/'))
        cd = os.path.join(outdir, 'ext_defs', ext)
        os.makedirs(cd, exist_ok=True)
        with open(os.path.join(cd, 'client_files.txt'), 'w', encoding='utf-8',
                  newline='\n') as f:
            f.write(u'# %s.pkg  client 文件清单  (%d 个)\n' % (ext, len(cl)))
            f.write(u'# pkg 内路径\n')
            for x in cl:
                f.write(x + u'\n')
        # 全部成员清单（含资源），便于判归属
        with open(os.path.join(cd, 'all_files.txt'), 'w', encoding='utf-8',
                  newline='\n') as f:
            f.write(u'# %s.pkg  全部成员 (%d 个)\n' % (ext, len(names)))
            for x in sorted(names):
                if not x.endswith('/'):
                    f.write(x + u'\n')

        print('%-24s defs=%d  client=%d' % (ext, sum(1 for m in manifest if m[0] == ext), len(cl)))

    with open(os.path.join(outdir, 'MANIFEST.tsv'), 'w', encoding='utf-8',
              newline='\n') as f:
        f.write(u'ext\tkind\tfile\tbytes\tstatus\n')
        for row in manifest:
            f.write(u'\t'.join(u'%s' % c for c in row) + u'\n')
    print('\n总计 %d 个 def/扩展文件 -> %s' % (total_defs, outdir))


if __name__ == '__main__':
    main()
