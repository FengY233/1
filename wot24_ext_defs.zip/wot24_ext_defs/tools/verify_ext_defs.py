# -*- coding: utf-8 -*-
"""verify_ext_defs.py — 校验 export_ext_defs.py 的产物。

用法: py -3 tools/verify_ext_defs.py <outDir>

校验项（每项都对着 pkg 里的真字节，不是对着我自己的假设）：
  V1  MANIFEST 行数 == 各 pkg 里 def 文件数之和
  V2  每个 .def 的 _raw 字节 == pkg 内字节（逐字节）
  V3  每个 _raw 都能被 bwxml_decode 解完（consumed == len）
  V4  解码出的 xml 里出现的每个属性名，都在该 def 的串池里
  V5  ARRAY / FIXED_DICT 这类「自身值」没被丢掉（对有它们的 def 检查）
  V6  client_files.txt 行数 == pkg 内 /scripts/client/ 文件数
"""
import os
import sys
import zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bwxml_decode as B  # noqa: E402

PKG_DIR = u'//vmware-host/Shared Folders/World_of_Tanks_CN/res/packages/'
KINDS = ['entity_defs', 'component_defs', 'interfaces', 'arena_defs']

fails = []


def chk(cond, msg):
    if not cond:
        fails.append(msg)


def main():
    outdir = sys.argv[1]
    rows = [l.rstrip('\n').split('\t')
            for l in open(os.path.join(outdir, 'MANIFEST.tsv'), encoding='utf-8')][1:]
    exts = sorted(set(r[0] for r in rows))

    # ---- V1 / V2 / V3 / V4 / V5 ----
    n_v2 = n_v4 = n_v5 = 0
    for ext in exts:
        z = zipfile.ZipFile(os.path.join(PKG_DIR, ext + '.pkg'))
        names = z.namelist()
        for kind in KINDS:
            member = sorted(x for x in names
                            if ('/scripts/%s/' % kind) in x and not x.endswith('/'))
            rawdir = os.path.join(outdir, 'ext_defs', ext, '_raw', kind)
            on_disk = sorted(os.listdir(rawdir)) if os.path.isdir(rawdir) else []
            chk(len(member) == len(on_disk),
                'V1 %s/%s pkg=%d disk=%d' % (ext, kind, len(member), len(on_disk)))
            for m in member:
                base = m.split('/')[-1]
                p = os.path.join(rawdir, base)
                if not os.path.isfile(p):
                    fails.append('V2 缺文件 %s' % p)
                    continue
                a = z.read(m)
                b = open(p, 'rb').read()
                chk(a == b, 'V2 字节不符 %s' % p)
                n_v2 += 1
                # V3
                try:
                    rd, tree, used = B.decode(a)
                    chk(used == len(a), 'V3 未解完 %s (%d/%d)' % (p, used, len(a)))
                except Exception as e:
                    fails.append('V3 解码异常 %s: %s' % (p, e))
                    continue
                # V4 属性名必须来自串池
                xmlp = os.path.join(outdir, 'ext_defs', ext, kind,
                                    os.path.splitext(base)[0] + '.xml')
                if os.path.isfile(xmlp):
                    import re
                    tags = set(re.findall(r'<([A-Za-z_][A-Za-z0-9_]*)>', open(xmlp, encoding='utf-8').read()))
                    pool = set(rd)
                    bad = [t for t in tags if t not in pool]
                    chk(not bad, 'V4 %s 出现串池外的名: %s' % (xmlp, bad))
                    n_v4 += 1
                    # V5 自身值：★ ARRAY/FIXED_DICT/TUPLE 这类类型名【不在串池里】，
                    #    它们是 Element 节点的「自身值」，正是旧渲染器丢掉的东西。
                    #    渲染规则 = 以【父节点名】为标签写成 <父名>值</父名>。
                    #    这里按同一规则重算一遍，和 xml 里实际有的比。
                    want = set()
                    def collect(n, label):
                        if not isinstance(n, list):
                            return
                        selfv = None
                        for c in n:
                            if not isinstance(c, tuple):
                                selfv = c
                                break
                        if selfv is not None and (u'%s' % selfv) != '' and label:
                            want.add(u'<%s>%s</%s>' % (label, selfv, label))
                        for c in n:
                            if isinstance(c, tuple):
                                nm = rd[c[0]] if c[0] < len(rd) else '?%d' % c[0]
                                collect(c[1], nm)
                    collect(tree, None)
                    body = open(xmlp, encoding='utf-8').read()
                    for w in want:
                        chk(w in body, 'V5 %s 丢了自身值 %s' % (xmlp, w))
                    if want:
                        n_v5 += 1
        # ---- V6 ----
        ncl = len([x for x in names if '/scripts/client/' in x and not x.endswith('/')])
        cf = os.path.join(outdir, 'ext_defs', ext, 'client_files.txt')
        got = len([l for l in open(cf, encoding='utf-8')
                   if l.strip() and not l.startswith('#')])
        chk(got == ncl, 'V6 %s client 清单 %d != pkg %d' % (ext, got, ncl))

    print('V2 逐字节比对 %d 个 .def' % n_v2)
    print('V4 属性名校验 %d 个 .xml' % n_v4)
    print('V5 自身值校验 %d 个 .xml（含 ARRAY/FIXED_DICT）' % n_v5)
    if fails:
        print('\n!!! 失败 %d 项：' % len(fails))
        for f in fails:
            print('  ', f)
        sys.exit(1)
    print('\n全部通过。')


if __name__ == '__main__':
    main()
