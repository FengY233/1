#!/usr/bin/env python3
"""t56_vt.py — Task 56-b: 直读 PropertyChangeReader 双 vtable (0x1443416a0/0x144341690)
+ 0x143925bc0 .rdata 类型表侦察。输出 slot 函数地址, 供 decomp 检索。"""
import pefile, struct

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()
secs = [(imgbase + s.VirtualAddress, s.VirtualAddress, s.SizeOfRawData,
         s.PointerToRawData, s.Name.decode().rstrip('\0')) for s in pe.sections]

def va2off(va):
    for sva, rva, sz, off, name in secs:
        if sva <= va < sva + max(sz, 0x1000):
            if va - sva < sz:
                return off + (va - sva)
    return None

def rd(va, n):
    o = va2off(va)
    return data[o:o+n] if o is not None else None

def qwords(va, n):
    b = rd(va, n * 8)
    return struct.unpack('<%dQ' % n, b) if b else None

# 1) 双 vtable 内容
for name, va in (('nested(1443416a0)', 0x1443416a0), ('slice(144341690)', 0x144341690)):
    qs = qwords(va, 8)
    print(f'== {name} @ {hex(va)} ==')
    for i, q in enumerate(qs):
        print(f'  slot{i} (+0x{i*8:02x}): {hex(q)}')
    # 也看前后的指针, 确认表边界
    qs_pre = qwords(va - 16, 2)
    qs_post = qwords(va + 64, 2)
    print('  pre :', [hex(x) for x in (qs_pre or [])])
    print('  post:', [hex(x) for x in (qs_post or [])])

# 2) 0x143925bc0 类型表侦察(往后 32 个 qword)
print('\n== 0x143925bc0 .rdata 类型表 ==')
qs = qwords(0x143925bc0, 24)
for i, q in enumerate(qs or []):
    print(f'  +0x{i*8:02x}: {hex(q)}')

# 3) 附: 0x1443411a0 (ClientMethodCalleeNode 用到的另一个 vtable)
print('\n== 0x1443411a0 ==')
qs = qwords(0x1443411a0, 8)
for i, q in enumerate(qs or []):
    print(f'  slot{i}: {hex(q)}')
