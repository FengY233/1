#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""t56_census.py — 随机战语料通道字节占比普查（进度百分比定量基座）

对 10 场随机战回放逐通道统计: 包数 / payload 字节 / 占比,
并叠加「已搞懂程度」权重, 输出加权总进度。
理解状态依据 findings.md v38:
  0x04 leaveAoI        100% (4922/4922)
  0x05 属性/创建流     100% (6899/6899 字节级)
  0x07 属性更新        100% (37105/37105)
  0x24 嵌套/切片更新   100% (5241/5241)
  0x32 NRL组件创建流   100% 文法 (6822/6822) + 语义事件流(t53)
  0x35/0x36 空触发器   100% (Task 55-a)
  0x37 NRL变换缓冲     架构+文法 100%, 值数学定标未完成 → 记 75%
  0x39 复制流          通道身份已知(NetworkReplicationPoint), 语义未鉴定 → 记 40%
  0x3D digest          算法 100% 破译(指纹性质, 非内容) → 记 100% 算法
  其余小类型           v1-v7 已通(时钟/移动/击杀链/deathOrder 等)
"""
import sys, json
from collections import defaultdict

sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

CORPUS = [
    '20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay',
    '20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay',
    '20260907_1321_germany-G197_Pz_Kpfw_Neu_07_lakeville.wotreplay',
    '20260910_1057_china-Ch67_BZ_79_37_caucasus.wotreplay',
    '20260911_1534_ussr-R52_Object_261_44_north_america.wotreplay',
    '20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay',
    '20260912_1036_france-F143_Fauteur_59_asia_great_wall.wotreplay',
    '20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay',
    'PTZ_10K.wotreplay',
    'WZ-219.wotreplay',
]
BASE = '/tmp/wot/github_test/'

# 已搞懂程度: 1.0=字节级/语义级全解, 其余为部分理解权重
UNDERSTAND = {
    0x04: 1.0, 0x05: 1.0, 0x07: 1.0, 0x24: 1.0, 0x32: 1.0,
    0x35: 1.0, 0x36: 1.0,
    0x37: 0.75,   # 架构+文法全解, op=2 变换值定标未完成
    0x39: 0.40,   # 通道身份已知, 字段语义未鉴定
    0x3D: 1.0,    # 算法全破译(指纹, 非内容流)
}
DEFAULT_U = 0.95  # 其余类型 v1-v7 已通(容器/时钟/移动等), 少量边缘留量

LABELS = {
    0x04: 'leaveAoI', 0x05: '属性/创建流', 0x07: '属性更新', 0x24: '嵌套/切片更新',
    0x32: 'NRL组件创建', 0x35: 'NRL触发A', 0x36: 'NRL触发B', 0x37: 'NRL变换缓冲',
    0x39: '复制流', 0x3D: 'entityDefs指纹',
}


def main():
    cnt = defaultdict(int)
    byt = defaultdict(int)
    per_scene = {}
    total_pkts = 0
    total_byts = 0
    for fn in CORPUS:
        rf = ReplayFile(BASE + fn)
        sc = defaultdict(int)
        for ty, clock, payload, idx in rf.pkts:
            cnt[ty] += 1
            byt[ty] += len(payload)
            sc[ty] += 1
            total_pkts += 1
            total_byts += len(payload)
        per_scene[fn] = dict(sc)
        print('%-60s pkts=%6d stream=%d' % (fn, len(rf.pkts), rf.stream_len))

    print('\n==== 通道普查（10 场随机战合计）====')
    print('%-6s %-16s %8s %10s %7s %6s' % ('type', 'label', 'pkts', 'payloadB', 'B占比', '理解度'))
    rows = []
    for ty in sorted(byt, key=lambda t: -byt[t]):
        u = UNDERSTAND.get(ty, DEFAULT_U)
        rows.append((ty, cnt[ty], byt[ty], byt[ty] / total_byts, u))
        print('0x%02X   %-16s %8d %10d %6.2f%% %6.0f%%' % (
            ty, LABELS.get(ty, 'v1-v7已通'), cnt[ty], byt[ty],
            100.0 * byt[ty] / total_byts, 100 * u))

    wsum = sum(b * u for _, _, b, _, u in rows)
    print('\n总包数=%d  总payload=%d B (%.2f MB)' % (total_pkts, total_byts, total_byts / 1048576.0))
    print('加权理解度(按payload字节) = %.2f%%' % (100.0 * wsum / total_byts))

    # 0x37 内部细分: 空体消息(2B) vs 组合体(op值)
    # 由 t55: 11 场消息数≈flush 数; op=2 L=6 主力 27341 条(全语料)
    out = {
        'corpus': CORPUS, 'total_pkts': total_pkts, 'total_payload_bytes': total_byts,
        'channels': [
            {'type': '0x%02X' % ty, 'label': LABELS.get(ty, 'v1-v7已通'),
             'pkts': c, 'bytes': b, 'byte_share': round(100.0 * b / total_byts, 3),
             'understanding': u} for ty, c, b, _, u in rows],
        'weighted_understanding_pct': round(100.0 * wsum / total_byts, 2),
        'per_scene': {k: {('0x%02X' % t): c for t, c in v.items()} for k, v in per_scene.items()},
    }
    with open('/home/z/my-project/download/data_v35/通道字节占比普查_t56.json', 'w', encoding='utf-8') as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    print('saved -> data_v35/通道字节占比普查_t56.json')


if __name__ == '__main__':
    main()
