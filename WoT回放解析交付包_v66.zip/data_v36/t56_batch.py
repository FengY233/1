#!/usr/bin/env python3
"""t56_batch.py — Task 56-b: op=0 巨包容器结构破解
假说: op=0 大 L 消息 = Root 节点位图批量, 内含子消息序列 [nid u16 BE][op u8][L u8][blob]
验证: 对全语料 op=0 且 L 大的消息做序列分割, 检验完美铺满 + 已知 nid 复现
"""
import json
from collections import Counter

D = json.load(open('/tmp/wot/t55_global3.json'))


def seg_chain(data, off=0):
    """从 off 起, 尝试 [nid u16][op][L][L bytes] 链式分割; 返回 (msgs, end) 或 None"""
    msgs = []
    q = off
    n = len(data)
    while q < n:
        if q + 4 > n:
            return None, q  # 尾部不足一条
        nid = (data[q] << 8) | data[q + 1]
        op = data[q + 2]
        L = data[q + 3]
        if L == 0xFF:
            if q + 7 > n:
                return None, q
            L = int.from_bytes(data[q + 4:q + 7], 'little')
            hb = 7
        else:
            hb = 4
        if q + hb + L > n:
            return None, q
        msgs.append((nid, op, L, data[q + hb:q + hb + L]))
        q += hb + L
    return msgs, q


def main():
    # 收集 op=0 大消息
    bigs = []
    for gi in D:
        for nid, op, L, vh, t, clk in D[gi]['msgs']:
            if isinstance(op, int) and op == 0 and L >= 40:
                bigs.append((gi, nid, L, bytes.fromhex(vh), clk))
    print(f'op=0 且 L>=40 的消息: {len(bigs)} 条')
    print('L 分布:', Counter(L for g, n, L, b, c in bigs).most_common(10))
    print('nid 分布:', Counter(hex(n) for g, n, L, b, c in bigs).most_common(10))

    # 尝试从不同偏移做链式分割
    for gi, nid, L, b, clk in bigs[:6]:
        print(f'\n=== g{gi} nid={hex(nid)} L={L} clk={clk} ===')
        print('hex:', b.hex())
        for off in (0, 1, 2, 3, 4, 5, 8):
            msgs, end = seg_chain(b, off)
            if msgs and end == len(b):
                nids = Counter(hex(m[0]) for m in msgs)
                print(f'  偏移{off}: 完美铺满 {len(msgs)} 条: {nids.most_common(8)}')
                for m in msgs[:6]:
                    print(f'    nid={hex(m[0])} op={m[1]} L={m[2]} {m[3].hex()[:48]}')
                break
            elif msgs:
                print(f'  偏移{off}: 链断于 {end}/{len(b)} ({len(msgs)} 条)')
        else:
            print('  所有偏移均无法完美铺满')


if __name__ == '__main__':
    main()
