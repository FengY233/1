#!/usr/bin/env python3
"""t56_root.py — Task 56-b: Root 位图批量消息体结构破解
模型: Root 体 = [前缀(浮点/参数/clist)][子消息链 [u16 nid][u8 op][u8 L][L 字节体]]
验证: 对 t55 的 op=0 家族(实为 Root 体误标)做链式分割, 找到完美铺满的前缀长度
"""
import json
from collections import Counter

D = json.load(open('/tmp/wot/t55_global3.json'))


def try_chain(b, off):
    """从 off 起尝试 [u16 nid][u8 op][u8 L][L B] 链; 返回 (msgs, end)"""
    msgs = []
    q = off
    n = len(b)
    while q + 4 <= n:
        nid = (b[q] << 8) | b[q + 1]
        op = b[q + 2]
        L = b[q + 3]
        if L == 0xFF:
            if q + 7 > n:
                return None, q
            L = int.from_bytes(b[q + 4:q + 7], 'little')
            hb = 7
        else:
            hb = 4
        if op not in (0, 1, 2) or L > n - q - hb:
            return None, q
        if nid < 8 and nid != 0:  # nid 太小可疑(除 0)
            return None, q
        msgs.append((nid, op, L, b[q + hb:q + hb + L]))
        q += hb + L
    return msgs, q


def main():
    roots = []
    for gi in D:
        for nid, op, L, vh, t, clk in D[gi]['msgs']:
            if isinstance(op, int) and op == 0 and L >= 30:
                roots.append((gi, nid, L, bytes.fromhex(vh), clk))
    print(f'Root 候选(op=0 且 L>=30): {len(roots)} 条')

    ok = 0
    prefix_lens = Counter()
    sub_nids = Counter()
    for gi, nid, L, b, clk in roots:
        # t55 的 blob 已扣掉 [op][L]; 真 Root 体 = [op][L] 那 2 字节 + blob = b 前 2 字节恢复
        # 实际上 t55 的 vh 是 blob, 完整体 = op,L + blob — 但 op=0 的 2 字节是误标
        # 尝试把 blob 本身当作完整 Root 体(含被误吃的 2 字节前缀)
        body = b
        found = False
        for off in range(0, 24):
            msgs, end = try_chain(body, off)
            if msgs is not None and end == len(body) and len(msgs) >= 1:
                ok += 1
                prefix_lens[off] += 1
                for m in msgs:
                    sub_nids[(m[0] >> 8, m[1])] += 1
                if ok <= 6:
                    print(f'g{gi} nid={hex(nid)} L={L} 前缀{off}B: {body[:off].hex()}')
                    for m in msgs[:5]:
                        print(f'    -> nid={hex(m[0])} op={m[1]} L={m[2]} {m[3].hex()[:40]}')
                    if len(msgs) > 5:
                        print(f'    ... 共 {len(msgs)} 条子消息')
                found = True
                break
        if not found and ok == 0:
            pass
    print(f'\n完美铺满: {ok}/{len(roots)}')
    print('前缀长度分布:', prefix_lens.most_common(10))
    print('子消息 (nid>>8, op) 分布:', sub_nids.most_common(12))


if __name__ == '__main__':
    main()
