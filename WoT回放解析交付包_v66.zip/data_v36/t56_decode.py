#!/usr/bin/env python3
"""t56_decode.py — Task 56-b: op=2 嵌套路径位流解码器 + 位宽结构经验求解

模型(findings §34 + 本轮 vtable 破译):
  消息 = [u16 BE nid][u8 op=2][u8 L][L 字节 MSB-first 位流]
  位流 = [1][bitsRequired(n1) idx1] [1][bitsRequired(n2) idx2] ... [0][bitsRequired(nFinal) VALUE]
  约束: 总位数 ∈ (8(L-1), 8L] (执行器断言全耗尽)

求解策略: 对每个 (nid, L) 族枚举 (d, w1..wd, wv) 使位精确填满 L 字节,
用跨消息一致性打分: ①路径元组种类少 ②值序列平滑 ③同 b0 配对结构解释
"""
import json, itertools, sys
from collections import defaultdict, Counter

D = json.load(open('/tmp/wot/t55_global3.json'))


def bits_of(blob):
    out = []
    for byte in blob:
        for k in range(7, -1, -1):
            out.append((byte >> k) & 1)
    return out


class BR(object):
    __slots__ = ('bits', 'p')

    def __init__(self, blob):
        self.bits = bits_of(blob)
        self.p = 0

    def read(self, n):
        if n == 0:
            return 0
        if self.p + n > len(self.bits):
            raise EOFError
        v = 0
        for i in range(n):
            v = (v << 1) | self.bits[self.p + i]
        self.p += n
        return v

    def left(self):
        return len(self.bits) - self.p


def parse(blob, widths, wv):
    """widths=[w1..wd] 路径各级位宽, wv=值位宽. 返回 (path_tuple, value) 或 None"""
    br = BR(blob)
    try:
        path = []
        while True:
            more = br.read(1)
            if more == 0:
                break
            if not widths:
                return None  # 路径比假设深
            path.append(br.read(widths.pop(0)))
        if widths:
            return None  # 路径比假设浅
        val = br.read(wv)
        # 全耗尽约束: 剩余位 < 8 且不再跨字节
        if br.left() >= 8:
            return None
        return (tuple(path), val)
    except EOFError:
        return None


def enumerate_structures(L):
    """枚举所有 (d, w1..wd, wv) 使 1+Σ(1+wi)... 总位 = d(路径元素)×(1+wi) + 1(终止) + wv, 且 ∈ (8(L-1), 8L]"""
    total_bits = 8 * L
    out = []
    for d in (1, 2, 3):
        # 枚举 d 个路径宽度和值宽度
        for ws in itertools.product(range(1, 13), repeat=d):
            used = d + sum(ws) + 1  # d 个 more 位 + Σwi + 1 终止位
            rem = total_bits - used
            for wv in range(max(1, rem - 7), rem + 1):
                # 值结束后剩余 total-used-wv ∈ [0,7]
                if 0 <= total_bits - used - wv <= 7:
                    # 同时必须真正进入最后一字节: used+wv > 8*(L-1)
                    if used + wv > 8 * (L - 1):
                        out.append((list(ws), wv))
    return out


def smoothness(vals):
    if len(vals) < 3:
        return 0.0, 0
    dif = [abs(b - a) for a, b in zip(vals, vals[1:])]
    rng = max(vals) - min(vals) + 1
    return sum(dif) / len(dif) / rng, len(dif)


def main():
    # 收集 op=2 消息按 (nid) 分组(game0 先做)
    focus = sys.argv[1] if len(sys.argv) > 1 else '0'
    msgs = defaultdict(list)
    for nid, op, L, vh, t, clk in D[focus]['msgs']:
        if isinstance(op, int) and op == 2 and L in (3, 6):
            msgs[nid].append((L, bytes.fromhex(vh), clk))
    # 取消息最多的 nid
    top = sorted(msgs.items(), key=lambda kv: -len(kv[1]))[:6]
    print(f'game{focus} op=2 L∈{{3,6}} nid TOP6:', [(hex(n), len(v)) for n, v in top])

    for nid, seq in top[:3]:
        print(f'\n===== nid={hex(nid)} ({len(seq)} 条) =====')
        for L in (3, 6):
            sub = [s for s in seq if s[0] == L]
            if not sub:
                continue
            structs = enumerate_structures(L)
            best = []
            for widths, wv in structs:
                parsed = []
                ok = True
                for Lx, blob, clk in sub:
                    r = parse(blob, list(widths), wv)
                    if r is None:
                        ok = False
                        break
                    parsed.append((r[0], r[1], clk))
                if not ok:
                    continue
                paths = Counter(p for p, v, c in parsed)
                npaths = len(paths)
                if npaths > 6:
                    continue  # 路径爆炸 = 假结构
                # 值平滑性(按主路径)
                main_path = paths.most_common(1)[0][0]
                vals = [v for p, v, c in parsed if p == main_path]
                sm, n = smoothness(vals)
                best.append((npaths, -sm, widths, wv, main_path, len(vals),
                             vals[:12], vals[-6:] if len(vals) > 12 else []))
            best.sort()
            print(f'  L={L} ({len(sub)} 条) 候选结构 {len(structs)} 个, 稳定结构 {len(best)} 个:')
            for npaths, negsm, widths, wv, mp, nv, head, tail in best[:5]:
                print(f'    路径宽{widths} 值宽{wv} | 路径种类={npaths} 主路径={mp} 值数={nv} '
                      f'平滑度={-negsm:.4f}')
                print(f'      值头: {head}')
                if tail:
                    print(f'      值尾: {tail}')


if __name__ == '__main__':
    main()
