#!/usr/bin/env python3
"""t56_collect.py — Task 56-b 成果收集: 0x37 op=2 位流解码终态产物
输出 data_v36/: ①语义解码样例(死亡事件/计数器/状态) ②结构速查表 ③nid 族统计
"""
import json, os
from collections import Counter, defaultdict

D = json.load(open('/tmp/wot/t55_global3.json'))
OUT = '/home/z/my-project/download/data_v36'
os.makedirs(OUT, exist_ok=True)


def bits_of(blob):
    out = []
    for byte in blob:
        for k in range(7, -1, -1):
            out.append((byte >> k) & 1)
    return out


def decode_op2(blob):
    """op=2 体位流解码: [1][6-bit idx1][0][finalIdx(6)] + 字节对齐类型值
    返回 (idx1, finalIdx, value_bytes) 或 None"""
    bits = bits_of(blob)
    if bits[0] != 1:
        return None
    idx1 = 0
    for i in range(1, 7):
        idx1 = (idx1 << 1) | bits[i]
    if bits[7] != 0:
        return None  # 本族路径深度=1, bit7 必须=0(偶 b0 的结构根源)
    finalIdx = 0
    for i in range(8, 14):
        finalIdx = (finalIdx << 1) | bits[i]
    # 值从字节 2 起(位域消耗 2 字节)
    return idx1, finalIdx, blob[2:]


def main():
    # 1) 全语料 op=2 L∈{3,4,6,16,26} 的 nid 族解码
    fam = defaultdict(lambda: defaultdict(list))  # nid -> L -> [(game,clk,idx1,finalIdx,val)]
    for gi in D:
        for nid, op, L, vh, t, clk in D[gi]['msgs']:
            if isinstance(op, int) and op == 2 and L in (3, 4, 6, 16, 26):
                r = decode_op2(bytes.fromhex(vh))
                if r:
                    fam[nid][L].append((gi, clk) + r)
    # 2) 死亡事件提取(全语料)
    deaths = []
    for nid in fam:
        for (gi, clk, idx1, fi, val) in fam[nid].get(26, []):
            if len(val) >= 2 and val[0] == len(val) - 1 and val[1:3] == b'\x80\x02':
                # [len][pickle] — 提取 deathOrder
                s = val.decode('latin1')
                import re
                m = re.search(r'deathOrder.{0,3}?K(.?)s\.', s, re.S)
                if m:
                    deaths.append({'game': gi, 'clk': clk, 'nid': nid, 'player_idx1': idx1,
                                   'deathOrder': m.group(1).encode('latin1')[0]})
    deaths.sort(key=lambda d: (int(d['game']), d['clk']))
    print(f'死亡事件: {len(deaths)} 条')
    # 3) 计数器终值统计
    counters = defaultdict(dict)
    for nid in fam:
        for (gi, clk, idx1, fi, val) in fam[nid].get(6, []):
            if len(val) == 4:
                v = int.from_bytes(val, 'little')
                key = (gi, nid, idx1)
                counters[key] = max(counters.get(key, 0), v)
    # 4) 输出
    samples = {'death_events': deaths[:60],
               'death_events_total': len(deaths),
               'counter_max_by_game': {g: sorted(v for (gg, n, i), v in counters.items() if gg == g)
                                        for g in sorted({k[0] for k in counters})},
               'nid_families': {hex(nid): {str(L): len(v) for L, v in ls.items()} for nid, ls in fam.items()},
               'structure': {
                   'message': '[u16 BE nid][u8 op][u8 L(FF->u24)][L B]',
                   'op0': 'Root 位图批量( volatile delta: 前缀浮点/clist + 子消息链 )',
                   'op1': '切片: TWO unsigned reads bitsRequired(width+1) = [lo,hi]',
                   'op2': '位流: [1][bitsRequired(n1) idx1]...[0][bitsRequired(n_final) VALUE] + 字节对齐类型值',
                   'bitstream': 'MSB-first BitReader(FUN_142ca1900); 位域精确耗尽约束 8(L-1)<bits<=8L',
                   'nid_0x07DD_0x08F1 族': 'idx1=32-61(30 玩家), L=6 值=每玩家 u32 单调计数器, '
                                           'L=26 值=[len][pickle {"deathOrder":N}], L=4 值=u16 状态 1->2, '
                                           'L=16 值=[1][13B 记录], L=3 值=u8 常量 1',
               }}
    with open(f'{OUT}/0x37语义解码样例_t56.json', 'w', encoding='utf-8') as f:
        json.dump(samples, f, ensure_ascii=False, indent=1)
    print('saved:', f'{OUT}/0x37语义解码样例_t56.json')
    for d in deaths[:12]:
        print('  ', d)


if __name__ == '__main__':
    main()
