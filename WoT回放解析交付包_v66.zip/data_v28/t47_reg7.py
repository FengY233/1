#!/usr/bin/env python3
"""t47_reg7.py — ClientNodeFactory 7 案跳转表全解: regKey -> 节点类名
跳转表 @0x140399150, 7 项 u32 (相对 0x140000000)
每案: 分配大小 + vtable(s) + 基类构造链 -> COL/RTTI 反查类名
"""
import pefile, struct
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

def va_to_off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

md = Cs(CS_ARCH_X86, CS_MODE_64); md.detail = True

def rq(va):
    off = va_to_off(va)
    return struct.unpack('<Q', data[off:off+8])[0] if off is not None else None

def rtti_name_of_vtable(vt_va):
    """vtable[-1] = COL, COL+0x0c = TD RVA, TD+0x10 = 名字"""
    col = rq(vt_va - 8)
    if col is None: return None
    off = va_to_off(col)
    if off is None: return None
    sig = struct.unpack('<I', data[off:off+4])[0]
    if sig != 1: return None
    td_rva = struct.unpack('<I', data[off+0x0c:off+0x10])[0]
    td_va = imgbase + td_rva
    td_off = va_to_off(td_va)
    if td_off is None: return None
    vf = struct.unpack('<Q', data[td_off:td_off+8])[0]
    if vf != 0x143964f10: return None
    end = data.find(b'\x00', td_off+0x10, td_off+0x100)
    try: return data[td_off+0x10:end].decode('utf-8')
    except: return None

# ── 1) 跳转表 ──
tbl_va = 0x140399150
cases = []
off = va_to_off(tbl_va)
for i in range(7):
    rel = struct.unpack('<I', data[off+i*4:off+i*4+4])[0]
    cases.append(0x140000000 + rel)
print('=== 7 案跳转表 ===')
for i, c in enumerate(cases):
    print(f'  regKey={i}: case @{hex(c)}')

# ── 2) 逐案反汇编前 ~50 指令, 提取 new 大小 + lea vtable + call ctor ──
print('\n=== 逐案分析 ===')
for i, c in enumerate(cases):
    print(f'\n--- regKey={i} case @{hex(c)} ---')
    off = va_to_off(c)
    n = 0
    for ins in md.disasm(data[off:off+400], c):
        line = f'  {ins.address:#x}: {ins.mnemonic:8s} {ins.op_str}'
        extra = ''
        if ins.mnemonic == 'lea' and 'rip' in ins.op_str:
            # 解析 lea 目标
            parts = ins.op_str.split('rip')
            try:
                disp = int(parts[1].strip().replace('+','').replace('-',''), 16) * (1 if '+' in parts[1] else -1)
                tgt = ins.address + ins.size + disp
                nm = rtti_name_of_vtable(tgt)
                extra = f'   ; -> {hex(tgt)}' + (f'  RTTI={nm}' if nm else '')
            except: pass
        print(line + extra)
        n += 1
        if ins.mnemonic == 'jmp' or (ins.mnemonic == 'ret'): break
        if n > 45: break
