#!/usr/bin/env python3
"""t47_vt.py — 7 节点类 vtable 全槽 dump + 关键槽(slot3=+0x18 / slot12=+0x60)反汇编定位"""
import pefile, struct
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

def va_to_off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

md = Cs(CS_ARCH_X86, CS_MODE_64); md.detail = True

def rq(va):
    off = va_to_off(va)
    return struct.unpack('<Q', data[off:off+8])[0] if off is not None else None

def rtti_name(vt_va):
    col = rq(vt_va - 8)
    if col is None: return None
    off = va_to_off(col)
    if off is None: return None
    if struct.unpack('<I', data[off:off+4])[0] != 1: return None
    td_rva = struct.unpack('<I', data[off+0x0c:off+0x10])[0]
    td_off = va_to_off(imgbase + td_rva)
    if td_off is None: return None
    if struct.unpack('<Q', data[td_off:td_off+8])[0] != 0x143964f10: return None
    end = data.find(b'\x00', td_off+0x10, td_off+0x100)
    try: return data[td_off+0x10:end].decode('utf-8')
    except: return None

NODES = [
    (0, 'BWRootNode', 0x1435df3e8),
    (1, 'BWEntityNode', 0x1435df458),
    (2, 'ClientDynComponentNode', 0x1435df4d8),
    (3, 'ClientPrimitivePropertyNode', 0x1435df550),
    (4, 'ClientCompositePropertyNode', 0x1435df5c8),
    (5, 'ClientMethodCalleeNode', 0x1435df640),
    (6, 'ServerMethodCallerNode', 0x1435df6b8),
]

print('=== 7 节点类 vtable 全槽 ===')
vt_funcs = {}
for k, name, vt in NODES:
    print(f'\n-- regKey={k} {name} @{hex(vt)} --')
    slots = []
    for i in range(14):
        f = rq(vt + i*8)
        if f is None or not (0x140000000 <= f < 0x146000000): 
            print(f'  +{i*8:#04x}: (非代码 {hex(f) if f else "?"})')
            break
        slots.append(f)
        print(f'  +{i*8:#04x} (slot{i}): {hex(f)}')
    vt_funcs[k] = slots

# 找公共槽: 所有类相同的槽 = 公共基类 NRL::BW::Node 实现
print('\n=== 槽一致性矩阵 (相同函数地址=继承基类实现) ===')
maxlen = min(len(v) for v in vt_funcs.values())
for i in range(maxlen):
    vals = set(vt_funcs[k][i] for k in vt_funcs if len(vt_funcs[k]) > i)
    tag = '公共' if len(vals) == 1 else '各异'
    print(f'  slot{i} (+{i*8:#04x}): {tag} {[hex(v) for v in sorted(vals)]}')
