#!/usr/bin/env python3
"""t47_class1.py — class1 批量处理器 FUN_140e73cf0 逐指令全解"""
import pefile, struct
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

def va_to_off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

md = Cs(CS_ARCH_X86, CS_MODE_64); md.detail = True

def dis(va, maxlen, title, stop=1):
    off = va_to_off(va)
    print(f'===== {title} @{hex(va)} =====')
    rets = 0
    for ins in md.disasm(data[off:off+maxlen], va):
        print(f'  {ins.address:#x}: {ins.mnemonic:8s} {ins.op_str}')
        if ins.mnemonic == 'ret':
            rets += 1
            if rets >= stop: break

dis(0x140e73cf0, 700, 'class1 批量处理器 FUN_140e73cf0', 2)
