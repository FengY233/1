#!/usr/bin/env python3
"""t47_reg5.py — 从 RTTI 类型描述符反查 vtable: INodeFactory/BWNodeFactory/ClientNodeFactory
方法: COL(RTTI Complete Object Locator)+0x0c = TypeDescriptor RVA; vtable[-1] = COL VA
"""
import pefile, struct

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

def va_to_off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

def off_to_va(off):
    for s in pe.sections:
        if s.PointerToRawData <= off < s.PointerToRawData + s.SizeOfRawData:
            return imgbase + s.VirtualAddress + (off - s.PointerToRawData)
    return None

targets = {
    0x1445bac98: 'INodeFactory@NRL@BW',
    0x1445bacc8: 'BWNodeFactory@BW',
    0x1445badf0: 'ClientNodeFactory@BW',
}

# COL 的 imageBase-relative offset 指向 type descriptor
for td_va, name in targets.items():
    td_rva = td_va - imgbase
    pat = struct.pack('<I', td_rva)
    print(f'\n===== {name} (TypeDescriptor @{hex(td_va)}, RVA {hex(td_rva)}) =====')
    # COL 结构: +0x00 sig, +0x04 offset, +0x08 cdOffset, +0x0c pTypeDescriptor(RVA), +0x10 pClassDescriptor(RVA)
    # 扫 .rdata 找 pat 出现在 COL+0x0c 位置
    for s in pe.sections:
        if s.SizeOfRawData == 0: continue
        sec = data[s.PointerToRawData:s.PointerToRawData+s.SizeOfRawData]
        base_va = imgbase + s.VirtualAddress
        idx = 0
        while True:
            idx = sec.find(pat, idx)
            if idx < 0: break
            col_off = s.PointerToRawData + idx - 0x0c
            if col_off >= 0:
                sig, off1, cdoff = struct.unpack('<III', data[col_off:col_off+12])
                if sig in (0, 1) and off1 < 0x100:
                    col_va = base_va + (idx - 0x0c)
                    pat2 = struct.pack('<Q', col_va)
                    for s2 in pe.sections:
                        if s2.SizeOfRawData == 0: continue
                        sec2 = data[s2.PointerToRawData:s2.PointerToRawData+s2.SizeOfRawData]
                        idx2 = sec2.find(pat2)
                        if idx2 >= 0:
                            vt_va = off_to_va(s2.PointerToRawData + idx2 + 8)
                            print(f'  COL @{hex(col_va)} (sig={sig}) -> vtable @{hex(vt_va)}')
                            vo = va_to_off(vt_va)
                            for i in range(6):
                                slot = struct.unpack('<Q', data[vo+i*8:vo+i*8+8])[0]
                                print(f'    vt+{i*8:#04x}: {hex(slot)}')
            idx += 1
