#!/usr/bin/env python3
"""t47_propval.py — 属性值解释器三件套: 1403d5850(更新读)/1403d5ee0(创建读)/1403d51e0(blob解释)"""
import pefile, struct
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

def va_to_off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

md = Cs(CS_ARCH_X86, CS_MODE_64); md.detail = True

def dis(va, maxlen=900, title='', stop_after_ret=2):
    off = va_to_off(va)
    print(f'\n{"="*72}\n===== {title} @{hex(va)} =====\n{"="*72}')
    rets = 0
    for ins in md.disasm(data[off:off+maxlen], va):
        print(f'  {ins.address:#x}: {ins.mnemonic:8s} {ins.op_str}')
        if ins.mnemonic == 'ret':
            rets += 1
            if rets >= stop_after_ret: break

import sys
w = sys.argv[1] if len(sys.argv) > 1 else 'upd'
if w in ('all','upd'): dis(0x1403d5850, 900, 'FUN_1403d5850 属性更新读', 2)
if w in ('all','crt'): dis(0x1403d5ee0, 900, 'FUN_1403d5ee0 属性创建读', 2)
if w in ('all','blob'): dis(0x1403d51e0, 900, 'FUN_1403d51e0 blob按kind解释', 2)
