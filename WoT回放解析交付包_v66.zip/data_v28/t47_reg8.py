#!/usr/bin/env python3
"""t47_reg8.py — ClientNodeFactory 全 7 案终极解: regKey -> 节点类名 + 尺寸 + vtable
外层布局: [0]=控制块vtable [8]=strong [0xc]=weak [0x10]=Node本体(vtable2)
案 0/2/3/4/5 委托 FUN_140397c60/140397f20/1403981d0/140397de0/140398090
"""
import pefile, struct
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

def va_to_off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

md = Cs(CS_ARCH_X86, CS_MODE_64); md.detail = True

def rq(va):
    off = va_to_off(va)
    return struct.unpack('<Q', data[off:off+8])[0] if off is not None else None

def rtti_name(vt_va):
    col = rq(vt_va - 8)
    if col is None: return None
    off = va_to_off(col)
    if off is None: return None
    if struct.unpack('<I', data[off:off+4])[0] != 1: return None
    td_rva = struct.unpack('<I', data[off+0x0c:off+0x10])[0]
    td_off = va_to_off(imgbase + td_rva)
    if td_off is None: return None
    if struct.unpack('<Q', data[td_off:td_off+8])[0] != 0x143964f10: return None
    end = data.find(b'\x00', td_off+0x10, td_off+0x100)
    try: return data[td_off+0x10:end].decode('utf-8')
    except: return None

def lea_target(ins):
    """计算 lea reg,[rip+disp] 目标"""
    if ins.mnemonic != 'lea': return None
    op = ins.op_str
    if 'rip' not in op: return None
    # 格式: "rax, [rip + 0x123]"
    import re
    m = re.search(r'rip\s*([+-])\s*(0x[0-9a-f]+|\d+)', op)
    if not m: return None
    sign = 1 if m.group(1) == '+' else -1
    disp = int(m.group(2), 0)
    return ins.address + ins.size + sign*disp

def analyze_ctor(fn_va, label):
    """分析构造函数: 提取 new 大小、lea vtable 及其 RTTI、调用的基类 ctor"""
    print(f'\n--- {label}: FUN_{fn_va:x} ---')
    off = va_to_off(fn_va)
    if off is None: print('  !! 不在节内'); return
    vtables, news, ctors = [], [], []
    for ins in md.disasm(data[off:off+600], fn_va):
        tgt = lea_target(ins)
        if tgt:
            nm = rtti_name(tgt)
            vtables.append((tgt, nm))
        if ins.mnemonic == 'mov' and 'ecx' in ins.op_str and ins.op_str.startswith('ecx,'):
            # mov ecx, imm — new 大小候选
            try:
                val = int(ins.op_str.split(',')[1].strip(), 0)
                if 0x10 < val < 0x10000: news.append(val)
            except: pass
        if ins.mnemonic == 'call':
            op = ins.op_str
            if op.startswith('0x'):
                try: ctors.append(int(op, 0))
                except: pass
        if ins.mnemonic == 'ret': break
    print(f'  new 大小候选: {[hex(x) for x in news]}')
    for vt, nm in vtables:
        print(f'  lea -> {hex(vt)}  RTTI={nm}')
    print(f'  calls: {[hex(c) for c in ctors[:8]]}')
    return vtables

# ── 案内直解 ──
print('=== 案1 (0x140398eb6): new(0x78) ===')
for base, disp in [(0x140398ee8, 0x3246c40), (0x140398eff, 0x3246559)]:
    t = base + disp
    print(f'  vtable {hex(t)}  RTTI={rtti_name(t)}')
print('=== 案6 (0x140399035): new(0x70) ===')
for base, disp in [(0x140399067, 0x3246b89), (0x140399092, 0x3246626)]:
    t = base + disp
    print(f'  vtable {hex(t)}  RTTI={rtti_name(t)}')

# ── 案 0/2/3/4/5 辅助构造 ──
helpers = {
    0: (0x140397c60, 'case0 helper (工厂+8 成员)'),
    2: (0x140397f20, 'case2 helper'),
    3: (0x1403981d0, 'case3 helper'),
    4: (0x140397de0, 'case4 helper'),
    5: (0x140398090, 'case5 helper'),
}
for k, (fn, label) in helpers.items():
    analyze_ctor(fn, f'regKey={k} {label}')
