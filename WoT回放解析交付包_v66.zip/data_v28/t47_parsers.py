#!/usr/bin/env python3
"""t47_parsers.py — 9 个节点解析器逐指令反汇编 (0x32 体文法核心)"""
import pefile, struct
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

def va_to_off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

md = Cs(CS_ARCH_X86, CS_MODE_64); md.detail = True

def dis(va, maxlen=700, title='', stop_after_ret=2):
    off = va_to_off(va)
    print(f'\n{"="*72}\n===== {title} @{hex(va)} =====\n{"="*72}')
    rets = 0
    for ins in md.disasm(data[off:off+maxlen], va):
        print(f'  {ins.address:#x}: {ins.mnemonic:8s} {ins.op_str}')
        if ins.mnemonic == 'ret':
            rets += 1
            if rets >= stop_after_ret: break

# ── 创建体解析器 (slot3 = vt+0x18) ──
dis(0x140e37f70, 700, 'BWEntityNode::parseCreate (regKey=1)', 2)
dis(0x140e37ec0, 700, 'ClientDynComponentNode::parseCreate (regKey=2)', 2)
dis(0x140e37ea0, 700, 'ClientPropertyNode::parseCreate (regKey=3/4)', 2)
dis(0x140e380e0, 700, 'ClientMethodCalleeNode::parseCreate (regKey=5)', 2)
dis(0x140399ee0, 700, 'ServerMethodCallerNode::parseCreate (regKey=6)', 2)
