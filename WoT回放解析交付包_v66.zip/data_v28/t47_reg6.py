#!/usr/bin/env python3
"""t47_reg6.py — ClientNodeFactory::方法(0x140398e60) = registry lookup 实现?"""
import pefile, struct
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

def va_to_off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

md = Cs(CS_ARCH_X86, CS_MODE_64); md.detail = True

def dis(va, maxlen=600, title='', stop_after_ret=3):
    off = va_to_off(va)
    print(f'\n{"="*70}\n===== {title} @{hex(va)} =====\n{"="*70}')
    rets = 0
    for ins in md.disasm(data[off:off+maxlen], va):
        print(f'  {ins.address:#x}: {ins.mnemonic:8s} {ins.op_str}')
        if ins.mnemonic == 'ret':
            rets += 1
            if rets >= stop_after_ret: break

dis(0x140398e60, 800, 'ClientNodeFactory::lookup/create?', stop_after_ret=3)
