#!/usr/bin/env python3
"""t47_parsers2.py — 更新体解析器(slot12) + slot13 续体 反汇编"""
import pefile, struct
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

def va_to_off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

md = Cs(CS_ARCH_X86, CS_MODE_64); md.detail = True

def dis(va, maxlen=700, title='', stop_after_ret=2):
    off = va_to_off(va)
    print(f'\n{"="*72}\n===== {title} @{hex(va)} =====\n{"="*72}')
    rets = 0
    for ins in md.disasm(data[off:off+maxlen], va):
        print(f'  {ins.address:#x}: {ins.mnemonic:8s} {ins.op_str}')
        if ins.mnemonic == 'ret':
            rets += 1
            if rets >= stop_after_ret: break

import sys
which = sys.argv[1] if len(sys.argv) > 1 else 'all'
if which in ('all','upd'):
    dis(0x140e379d0, 600, 'BWRootNode::update (slot12 regKey=0)', 2)
    dis(0x140399e20, 700, 'ClientPrimitivePropertyNode::update (regKey=3)', 2)
    dis(0x140399aa0, 700, 'ClientCompositePropertyNode::update (regKey=4)', 2)
    dis(0x140399be0, 700, 'ClientMethodCalleeNode::update (regKey=5)', 2)
if which in ('all','s13'):
    dis(0x1403991a0, 700, 'DynComponentNode::slot13 续体', 2)
    dis(0x140399180, 700, 'PropertyNode::slot13 续体 (regKey=3/4)', 2)
    dis(0x140399890, 700, 'MethodCalleeNode::slot13 续体', 2)
