#!/usr/bin/env python3
"""t47_reg4.py — 检查 +0x14c8 写入点上下文"""
import pefile, struct
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

def va_to_off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

md = Cs(CS_ARCH_X86, CS_MODE_64); md.detail = True

def dis(va, back=0, maxlen=400, title=''):
    start = va - back
    off = va_to_off(start)
    print(f'\n{"="*70}\n===== {title} @[{hex(start)}..] =====\n{"="*70}')
    for ins in md.disasm(data[off:off+maxlen], start):
        mark = ' <<<' if va <= ins.address < va+24 else ''
        print(f'  {ins.address:#x}: {ins.mnemonic:8s} {ins.op_str}{mark}')

dis(0x1413304f2, back=0x100, maxlen=0x180, title='写点A 0x1413304f2')
dis(0x1412f640a, back=0x80, maxlen=0x120, title='传址点F 0x1412f640a')
dis(0x1412fb453, back=0x80, maxlen=0x120, title='传址点G 0x1412fb453')
