#!/usr/bin/env python3
"""t47_reg2.py — 展开 ClientHub 构造点, 看 D+0x78 注册表如何初始化"""
import pefile, struct
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

def va_to_off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

md = Cs(CS_ARCH_X86, CS_MODE_64); md.detail = True

def dis(va, back=0, maxlen=500, title=''):
    """从 va-back 开始反汇编"""
    start = va - back
    off = va_to_off(start)
    print(f'\n{"="*70}\n===== {title} @[{hex(start)}..{hex(start+maxlen)}] =====\n{"="*70}')
    for ins in md.disasm(data[off:off+maxlen], start):
        mark = ' <<<' if va <= ins.address < va+32 else ''
        print(f'  {ins.address:#x}: {ins.mnemonic:8s} {ins.op_str}{mark}')

# 回放邻域构造点
dis(0x140e5d528, back=0x120, maxlen=0x280, title='ClientHub 构造点(回放邻域)')

# ClientHub 构造器本体
dis(0x14057c940, back=0, maxlen=0x200, title='FUN_14057c940 ClientHub 构造器')

# NRL::BW::Hub 基类构造器 — 接收 (this, registrySharedPtr)
dis(0x140e72330, back=0, maxlen=0x180, title='FUN_140e72330 Hub 基类构造器(接收registry)')
