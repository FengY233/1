#!/usr/bin/env python3
"""t47_reg3.py — 找外层对象 +0x14c8 (registry shared_ptr) 的写入点"""
import pefile, struct
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

def va_to_off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

md = Cs(CS_ARCH_X86, CS_MODE_64); md.detail = True

pat = struct.pack('<I', 0x14c8)
hits = []
for s in pe.sections:
    if s.SizeOfRawData == 0 or not (s.Characteristics & 0x20): continue
    sec = data[s.PointerToRawData:s.PointerToRawData+s.SizeOfRawData]
    base_va = imgbase + s.VirtualAddress
    idx = 0
    while True:
        idx = sec.find(pat, idx)
        if idx < 0: break
        va_hit = base_va + idx
        # 反汇编命中点前 8 字节起 24 字节, 看是否 mov [reg+0x14c8]
        off = va_to_off(va_hit - 8)
        for ins in md.disasm(data[off:off+20], va_hit-8):
            if ins.address <= va_hit and ins.address + ins.size > va_hit + 2:
                if '0x14c8' in ins.op_str and ins.mnemonic in ('mov','lea'):
                    hits.append((va_hit, f'{ins.mnemonic} {ins.op_str}'))
                break
        idx += 1

print(f'+0x14c8 访问 {len(hits)} 处:')
for va, s in hits[:50]:
    print(f'  {va:#x}: {s}')
