#!/usr/bin/env python3
"""t47_validate.py — Task 47-c: 新文法 0x32 全量校验器
文法权威版(Task 47 反汇编):
  流 = payload[4:]; 首消息 [u16 BE id] class=0; 后续 [u8 class][u8 id_hi][u8 id_lo]
  class0 创建体: [u16 BE objId][u8 regKey] + createBody[regKey]:
    0 BWRootNode:            空
    1 BWEntityNode:          [u32 LE eid]
    2 DynComponent:          [u16 LE typeId][u8 len|0xFF→u24 LE][name] + 压缩列表(base=msg.id)
    3/4 PropertyNode:        FUN_1403d5ee0 (未知→回溯)
    5 MethodCallee:          [u8 len|0xFF→u24 LE][name]
    6 ServerMethodCaller:    空
  class4/6 更新体(按节点类型):
    0 Root:       复杂(压缩列表+位图) → 回溯
    1 Entity:     空
    2 DynComp:    空
    3 PrimProp:   未知值体 → 回溯
    4 CompProp:   [u8 kind][u8 len|0xFF→u24][blob] (自定界)
    5 MethodCallee: 方法实参(FUN_142aa1b60, 与 0x05 方法参数同构) → 回溯
    6 SrvCaller:  空
  压缩列表操作码(FUN_140e6f0f0 钉死):
    0x00 终止; 01..7F value+=c 发出; 0x80 value=u16BE绝对 发出;
    0x81 发 0 (基值不变); 0x82 位掩码 (n+7)/8 字节 → vector<bool>;
    0x83..0xFE(有符号-125..-2) 游程 count=c+126: 发 value+1..value+count
"""
import struct, sys, glob, json
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter, defaultdict

REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
tundra = [f for f in REPLAYS if 'tundra' in f][0]
RND = [f for f in REPLAYS if f != tundra]

class R:
    __slots__ = ('b','p','eof')
    def __init__(s, b, p=0): s.b=b; s.p=p; s.eof=False
    def rem(s): return len(s.b)-s.p
    def rd(s, n):
        if s.p+n > len(s.b):
            s.eof = True   # 引擎语义: 置错误位, 返回补零
            avail = s.b[s.p:]
            s.p = len(s.b)
            return avail + b'\x00'*(n-len(avail))
        r = s.b[s.p:s.p+n]; s.p += n; return r
    def pk(s):
        if s.p >= len(s.b): raise EOFError
        return s.b[s.p]

def read_len(r):
    """u8 长度, 0xFF→u24 LE"""
    l = r.rd(1)[0]
    if l == 0xff:
        b3 = r.rd(3)
        l = b3[0] | (b3[1]<<8) | (b3[2]<<16)
    return l

def read_clist(r, base):
    """压缩列表: 返回 (values, flags)。flags: 0x82 位掩码置位索引集合
    操作码按有符号字节比较: 0x80=-128, 0x81=-127, 0x82=-126"""
    vals, flags = [], set()
    v = base
    while True:
        c = struct.unpack('b', r.rd(1))[0]  # 有符号
        if c == 0: break
        elif c == -0x80:   # 0x80: 绝对值 u16 BE
            v = struct.unpack('>H', r.rd(2))[0]; vals.append(v)
        elif c == -0x7f:   # 0x81: 发 0, 基值不变
            vals.append(0)
        elif c == -0x7e:   # 0x82: 位掩码 (n+7)/8 字节 + 列表终止(反汇编钉死: 两出区跳转均直达返回)
            nmask = (len(vals)+7) >> 3
            mask = r.rd(nmask)
            for i in range(len(vals)):
                if mask[i>>3] & (1 << (i&7)):
                    flags.add(i)
            break
        elif 1 <= c <= 0x7f:
            v += c; vals.append(v)
        else:  # -125..-1 游程 count=c+126
            n = c + 126
            for _ in range(n):
                v += 1; vals.append(v)
    return vals, flags

# ── 节点类型表 ──
NODE_NAMES = {0:'Root',1:'Entity',2:'DynComp',3:'PrimProp',4:'CompProp',5:'MethCallee',6:'SrvCaller'}

def parse_stream(stream, debug=False):
    """全文法解析 → (msgs, ok, leftovers)。未知体用回溯。"""
    r = R(stream)
    nodes = {}   # objId -> regKey
    msgs = []
    # 首消息
    if r.rem() < 2: return msgs, False, r.rem()
    mid = struct.unpack('>H', r.rd(2))[0]
    mcls = 0
    msgs.append(('first', mcls, mid))
    if not parse_body(r, mcls, mid, nodes, 0):
        return msgs, False, None
    # 后续
    while r.rem() > 0:
        h = r.rd(3)
        mcls, mid = h[0], (h[1]<<8)|h[2]
        if mcls > 6:
            return msgs, False, None
        msgs.append(('next', mcls, mid))
        if not parse_body(r, mcls, mid, nodes, 0):
            return msgs, False, None
    return msgs, True, 0

def parse_body(r, mcls, mid, nodes, depth):
    """解析消息体; 回溯点=未知长度体。返回 True=成功(消耗确定字节)"""
    if mcls == 0:
        objId = struct.unpack('>H', r.rd(2))[0]
        regKey = r.rd(1)[0]
        if regKey > 6: return False
        nodes[objId] = regKey
        return parse_create(r, regKey, mid, nodes)
    elif mcls == 1:
        # 压缩列表 + 每元素 [u8 regKey]+体
        vals, _ = read_clist(r, mid)
        for objId in vals:
            regKey = r.rd(1)[0]
            if regKey > 6: return False
            nodes[objId] = regKey
            if not parse_create(r, regKey, objId, nodes): return False
        return True
    elif mcls in (4, 6):
        # updateNode: 按 mid 查节点类型
        regKey = nodes.get(mid)
        if regKey is None:
            return False  # 未知节点
        return parse_update(r, regKey, mid, nodes)
    elif mcls in (2, 3):
        return True  # 通知类, 无体(假设)
    return False

def parse_create(r, regKey, mid, nodes):
    if regKey == 0: return True
    if regKey == 1:
        r.rd(4); return True
    if regKey == 2:
        r.rd(2)                      # typeId u16 LE
        l = read_len(r); r.rd(l)     # name
        read_clist(r, mid)           # 属性 nid 列表
        return True
    if regKey in (3, 4):
        return True                  # 假设创建体空(FUN_1403d5ee0 未知) — 回溯修正
    if regKey == 5:
        l = read_len(r); r.rd(l)
        return True
    if regKey == 6: return True
    return False

def parse_update(r, regKey, mid, nodes):
    if regKey in (1, 2, 6): return True   # 空桩
    if regKey == 4:
        # CompProp: [u8 kind][len][blob] 自定界 — 但 +0x5c 已初始化时走 5850 未知
        kind = r.rd(1)[0]
        if kind > 1: return False
        l = read_len(r); r.rd(l)
        return True
    # regKey 0/3/5: 未知 → 由上层回溯
    return None

# ══════════ 主统计: 带"结构级"回溯(整包重试未知长度假设) ══════════
def parse_stream_bt(stream):
    """回溯版: 未知体假设 {空体} 或 {自定界}; 失败则整包标记"""
    # 简化: 用逐字节前看验证——遇到未知体时, 假设 A: 空体; 假设 B: [kind][len][blob]
    # 由于 PrimProp 值体不确定, 用迭代加深: 未知处尝试候选长度集合
    import copy
    def try_with(assumption):
        r = R(stream)
        nodes = {}
        def pb(mcls, mid):
            if mcls == 0:
                if r.rem() < 3: return False
                objId = struct.unpack('>H', r.rd(2))[0]
                regKey = r.rd(1)[0]
                if regKey > 6: return False
                nodes[objId] = regKey
                return pc(regKey, mid)
            elif mcls == 1:
                vals, _ = read_clist(r, mid)
                for objId in vals:
                    if r.rem() < 1: return False
                    regKey = r.rd(1)[0]
                    if regKey > 6: return False
                    nodes[objId] = regKey
                    if not pc(regKey, objId): return False
                return True
            elif mcls in (4, 6):
                rk = nodes.get(mid)
                if rk is None: return False
                return pu(rk)
            return True
        def pc(regKey, mid):
            if regKey == 0 or regKey == 6: return True
            if regKey == 1:
                if r.rem() < 4: return False
                r.rd(4); return True
            if regKey == 2:
                if r.rem() < 2: return False
                r.rd(2)
                l = read_len(r)
                if r.rem() < l: return False
                r.rd(l)
                try: read_clist(r, mid)
                except EOFError: return False
                return True
            if regKey in (3,4):
                return assumption.get('prop_create', 'empty') == 'empty'
            if regKey == 5:
                l = read_len(r)
                if r.rem() < l: return False
                r.rd(l); return True
            return False
        def pu(rk):
            if rk in (1,2,6): return True
            if rk == 4:
                mode = assumption.get('comp_upd', 'blob')
                if mode == 'blob':
                    if r.rem() < 1: return False
                    kind = r.rd(1)[0]
                    if kind > 1: return False
                    l = read_len(r)
                    if r.rem() < l: return False
                    r.rd(l); return True
                else:
                    if r.rem() < 4: return False
                    r.rd(4); return True
            if rk == 0:
                # Root: 至少吃一个压缩列表
                try: read_clist(r, mid if False else 0)
                except EOFError: return False
                return True
            if rk == 3:
                n = assumption.get('prim_upd_len', 0)
                if r.rem() < n: return False
                r.rd(n); return True
            if rk == 5:
                n = assumption.get('meth_args_len', 0)
                if r.rem() < n: return False
                r.rd(n); return True
            return False
        # 主循环
        try:
            if r.rem() < 2: return None
            mid0 = struct.unpack('>H', r.rd(2))[0]
            if not pb(0, mid0): return None
            while r.rem() > 0:
                if r.rem() < 3: break   # 尾部 1-2B = 终止符/填充, 忽略
                h = r.rd(3)
                mcls, mid = h[0], (h[1]<<8)|h[2]
                if mcls > 6: return None
                res = pb(mcls, mid)
                if res is False or res is None: return None
            return (len(stream), len(stream)-r.p, r.eof)
        except EOFError:
            return None
    # 假设组合: prop_create 空; comp_upd blob; prim_upd 0..N; meth_args 0
    for prim_len in (0, 1, 2, 4, 8):
        a = {'prop_create':'empty', 'comp_upd':'blob', 'prim_upd_len': prim_len, 'meth_args_len': 0}
        res = try_with(a)
        if res is not None:
            return a, res
    return None, None

# ── 统计 ──
total = ok = partial = 0
first_msg_ids = Counter()
update_targets = Counter()   # (mid) 更新目标类型分布
node_types = Counter()
fail_samples = []
assumption_stats = Counter()

for f in RND:
    blocks, declared, slen, pkts = load(f)
    for t, c, p in pkts:
        if t != 0x32: continue
        total += 1
        stream = p[4:]
        a, res = parse_stream_bt(stream)
        if res is not None:
            ok += 1
            assumption_stats[(json.dumps(a), 'eof补零' if res[2] else '干净')] += 1
        else:
            partial += 1
            if len(fail_samples) < 8:
                fail_samples.append(stream[:40].hex(' '))

print(f'0x32 总包: {total}, 全解: {ok} ({100*ok/total:.1f}%), 失败: {partial}')
print('假设分布:')
for a, n in assumption_stats.most_common():
    print(f'  {a}: {n}')
print('失败样本:')
for s in fail_samples:
    print(f'  {s}')
