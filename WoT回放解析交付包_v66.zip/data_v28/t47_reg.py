#!/usr/bin/env python3
"""t47_reg.py — Task 47-a: hub+0x78 组件注册表全解
目标:
  1) 复核 class0 处理器 FUN_140e73f30 中注册表访问链 (D+0x78 -> registry -> vt[8](reg,&out,regKey))
  2) 求注册表对象的 vtable -> RTTI 类名
  3) 找填充方: 谁调用 registry 的注册槽 / 谁写 D+0x78 -> 静态表提取 regKey->类名
"""
import pefile, struct, re
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

def va_to_off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

def rq(va):
    off = va_to_off(va)
    return struct.unpack('<Q', data[off:off+8])[0] if off is not None else None

def rname(va, maxlen=64):
    """读 C 字符串"""
    off = va_to_off(va)
    if off is None: return None
    end = data.find(b'\x00', off, off+maxlen)
    if end < 0: return None
    try: return data[off:end].decode('utf-8')
    except: return None

md = Cs(CS_ARCH_X86, CS_MODE_64)
md.detail = True

def dis(va, maxlen=900, title='', stop_after_ret=3, show=True):
    off = va_to_off(va)
    if off is None:
        print(f'!! {hex(va)} 不在节内'); return []
    if show: print(f'\n{"="*70}\n===== {title} @{hex(va)} =====\n{"="*70}')
    out = []
    rets = 0
    for ins in md.disasm(data[off:off+maxlen], va):
        line = f'  {ins.address:#x}: {ins.mnemonic:8s} {ins.op_str}'
        if show: print(line)
        out.append(ins)
        if ins.mnemonic == 'ret':
            rets += 1
            if rets >= stop_after_ret: break
    return out

# ── 1) class0 处理器复核: 找 D+0x78 读取 ─────────────────────────
print('### 第一步: class0 处理器 FUN_140e73f30 中 D+0x78 注册表访问')
ins_list = dis(0x140e73f30, 700, 'FUN_140e73f30 class0 处理器', stop_after_ret=2, show=False)
for i, ins in enumerate(ins_list):
    if '0x78' in ins.op_str or 'call' in ins.mnemonic:
        print(f'  {ins.address:#x}: {ins.mnemonic:8s} {ins.op_str}')

# ── 1b) 区段细读 0x140e73f30-0x140e74000 ──────────────────────────
print('\n### 1b) class0 全指令流')
dis(0x140e73f30, 0xd0, 'class0 处理器前 208B', stop_after_ret=1)

# ── 2) 找 ClientHub/ViewHub 构造: 扫全部 lea reg,[rip+disp32] 反解目标 ──
print('\n### 第二步: 引用 hub vtable 的指令 (构造器)')
def scan_lea_targets(target_vas):
    res = {va: [] for va in target_vas}
    for s in pe.sections:
        if s.SizeOfRawData == 0 or not (s.Characteristics & 0x20): continue
        sec = data[s.PointerToRawData:s.PointerToRawData+s.SizeOfRawData]
        base_va = imgbase + s.VirtualAddress
        n = len(sec)-7
        for i in range(n):
            if sec[i] in (0x48, 0x4c) and sec[i+1] == 0x8d and (sec[i+2] & 0xC7) == 0x05:
                disp = struct.unpack('<i', sec[i+3:i+7])[0]
                tgt = base_va + i + 7 + disp
                if tgt in res:
                    res[tgt].append(base_va + i)
    return res

lea_map = scan_lea_targets([0x143606340, 0x1436062b8])
for vt_va, name in [(0x143606340, 'ClientHub'), (0x1436062b8, 'ViewHub')]:
    print(f'\n  {name} vtable {hex(vt_va)} lea 引用 {len(lea_map[vt_va])} 处:')
    for va_hit in lea_map[vt_va][:40]:
        off = va_to_off(va_hit)
        ins_list = list(md.disasm(data[off:off+16], va_hit))
        s2 = f'{ins_list[0].mnemonic} {ins_list[0].op_str}' if ins_list else '?'
        print(f'    {va_hit:#x}: {s2}')
