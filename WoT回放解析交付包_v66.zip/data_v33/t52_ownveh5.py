#!/usr/bin/env python3
"""t52_ownveh5.py — 程序化边界拟合: prop0/prop1/prop18 边界暴力 + 跨包结构一致性
已知: 3值包(0,1,18)=70B, 2值包(0,18)=51B → L1=19, L0+L18=51
"""
import sys, struct, json
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from t50_v5a import RND

pkgs = []; owner = []
for gi, f in enumerate(RND):
    blocks, declared, slen, pkts = load(f)
    for t, c, pl in pkts:
        if t == 0x32: pkgs.append(pl[4:]); owner.append(gi)

def clist(b, p, base, n):
    vals, flags, v = [], set(), base
    while True:
        if p >= n: return None
        c = struct.unpack('b', b[p:p+1])[0]; p += 1
        if c == 0: return vals, flags, p
        elif c == -0x80:
            if p + 2 > n: return None
            v = struct.unpack('>H', b[p:p+2])[0]; p += 2; vals.append(v)
        elif c == -0x7f: vals.append(0)
        elif c == -0x7e:
            nmask = (len(vals) + 7) >> 3
            if p + nmask > n: return None
            mask = b[p:p+nmask]; p += nmask
            for i in range(nmask * 8):
                if mask[i >> 3] & (1 << (i & 7)): flags.add(i)
            return vals, flags, p
        elif 1 <= c <= 0x7f:
            v += c; vals.append(v)
        else:
            for _ in range(c + 126):
                v += 1; vals.append(v)

TRAILER = bytes.fromhex('04090a0203010506000708')
V3 = []; V2 = []
for idx, b in enumerate(pkgs):
    if len(b) < 60 or b[4] != 2 or b[5:7] != b'\x33\x00': continue
    ln = b[7]
    r = clist(b, 8 + ln, 0, len(b))
    if r is None: continue
    vals, flags, p = r
    ti = b.find(TRAILER)
    if ti < 0: continue
    reg = b[p:ti]
    fp = sorted(x for x in flags if x < 23)
    if fp == [0, 1, 18] and len(reg) == 70: V3.append((idx, reg))
    elif fp == [0, 18] and len(reg) == 51: V2.append((idx, reg))
print(f'3值包: {len(V3)} {[x[0] for x in V3]}')
print(f'2值包: {len(V2)} {[x[0] for x in V2]}')

def f32s(bs):
    return [struct.unpack('<f', bs[i:i+4])[0] for i in range(0, len(bs)-3, 4)]

# 暴力 L0: prop0 = reg[0:L0], prop1 = reg[L0:L0+19], prop18 = reg[L0+19:]  (3值)
#          2值: prop0 = reg[0:L0], prop18 = reg[L0:]
print('\n=== L0 扫描 (2值包: prop18 = reg[L0:], 应与 3值包 prop18 同构) ===')
for L0 in range(1, 12):
    # 2值包 prop18
    ok2 = []
    for idx, reg in V2:
        p18 = reg[L0:]
        if len(p18) != 51 - L0: ok2 = None; break
        ok2.append((idx, p18))
    if ok2 is None: continue
    # 3值包 prop18 = reg[L0+19:]
    ok3 = []
    for idx, reg in V3:
        p18 = reg[L0+19:]
        ok3.append((idx, p18))
    if not ok3: continue
    # 同构检验: 长度一致
    lens2 = {len(x[1]) for x in ok2}
    lens3 = {len(x[1]) for x in ok3}
    print(f'L0={L0}: 2值p18长度={lens2} 3值p18长度={lens3} {"★同长" if lens2==lens3 and len(lens2)==1 else ""}')
    if lens2 == lens3 and len(lens2) == 1:
        # 打印首包对照
        i2, r2 = ok2[0]; i3, r3 = ok3[0]
        print(f'   2值#{i2} p18: {r2.hex()}')
        print(f'   3值#{i3} p18: {r3.hex()}')
        # prop1
        i3b, r3b = V3[0]
        print(f'   3值#{i3b} p1 : {r3b[L0:L0+19].hex()}')
        print(f'   3值#{i3b} p0 : {r3b[:L0].hex()}')
