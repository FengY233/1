#!/usr/bin/env python3
"""t52_alias.py — 解码 entity_defs/alias.xml, 提取 OwnVehicle 焦点类型的完整字段结构"""
import sys, json
sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file

d = decode_file('/tmp/wot/wot_scripts/entity_defs/alias.xml', 'alias.xml')

# 遍历 bwxml 树
def walk(node, path=''):
    """bwxml 节点 → (path, attrs, children)"""
    yield node, path
    for ch in getattr(node, 'children', []) or []:
        yield from walk(ch, path + '/' + (getattr(ch, 'tag', '?') or '?'))

# 打印顶层结构样本
tops = list(getattr(d, 'children', []) or [])
print(f'顶层节点: {len(tops)}')
for t in tops[:5]:
    print(' ', getattr(t, 'tag', '?'), dict(getattr(t, 'attributes', {}) or {}))

# 找 <Type> 实体: alias.xml 结构 = <root><Type> NAME <...body></Type>...
FOCUS = {'VEHICLE_AMMO_LIST', 'VEHICLE_SYNC_ATTRS', 'TARGETING_INFO',
         'VEHICLE_GUN_RELOAD_TIME', 'VEHICLE_CLIP_RELOAD_TIME', 'TARGET_VEHICLE_ID',
         'GUN_ROTATOR_FIX_ANGLES', 'VEHICLES_INFO'}
found = {}
for node, path in walk(d):
    tag = getattr(node, 'tag', '') or ''
    attrs = getattr(node, 'attributes', {}) or {}
    # Type 节点带名字属性
    name = attrs.get('name') or attrs.get('NAME') or ''
    if name in FOCUS:
        found.setdefault(name, []).append(node)

print(f'\n命中类型: {sorted(found)}')

def node_to_struct(n, depth=0):
    """bwxml 节点 → 嵌套 dict (tag + attrs + children)"""
    return {
        'tag': getattr(n, 'tag', ''),
        'attrs': dict(getattr(n, 'attributes', {}) or {}),
        'children': [node_to_struct(c, depth+1) for c in (getattr(n, 'children', []) or [])],
    }

out = {}
for nm, nodes in found.items():
    out[nm] = [node_to_struct(x) for x in nodes]
    print(f'\n=== {nm} ({len(nodes)} 定义) ===')
    print(json.dumps(out[nm], ensure_ascii=False, default=str)[:1500])

json.dump(out, open('/tmp/wot/t52_alias_focus.json', 'w'), ensure_ascii=False, indent=1)
print('\n已写 /tmp/wot/t52_alias_focus.json')
