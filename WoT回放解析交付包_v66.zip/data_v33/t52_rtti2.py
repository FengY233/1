#!/usr/bin/env python3
"""t52_rtti2.py — Task 52-③: RTTI→vtable 静态提取 v2
WoT 特化: TypeDescriptor vftable=0x143964f10, 名字在 TD+0x10 (无 .?AV 前缀, 可能是 plain)
1) 扫描 TD (8B 指针 == 0x143964f10)
2) COL(sig=1, pTypeDescriptor=RVA) → vtable (COL 指针出现处+8)
3) 关键词过滤 → 输出 slot3/slot11
"""
import pefile, struct, re, json

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

secs = []
for s in pe.sections:
    secs.append((imgbase + s.VirtualAddress, max(s.Misc_VirtualSize, s.SizeOfRawData),
                 s.PointerToRawData, s.Name.decode().rstrip('\0')))
def va2off(va):
    for sva, sz, off, name in secs:
        if sva <= va < sva + sz:
            return off + (va - sva)
    return None

TD_VF = 0x143964f10
# 1) 扫 .data/.rdata 中 TD
tds = {}
for sva, sz, off, name in secs:
    if name not in ('.rdata', '.data'):
        continue
    blob = data[off:off+sz]
    for i in range(0, len(blob) - 0x20, 8):
        if struct.unpack_from('<Q', blob, i)[0] == TD_VF:
            td_va = sva + i
            end = blob.find(b'\0', i + 0x10, i + 0x110)
            if end < 0: continue
            try:
                nm = blob[i+0x10:end].decode('utf-8')
            except:
                continue
            if 2 < len(nm) < 120 and re.match(r'^[A-Za-z_:@?$.<>\-0-9 ]+$', nm):
                tds[td_va] = nm
print(f'TypeDescriptors: {len(tds)}')
for va, nm in list(tds.items())[:5]:
    print(f'  {hex(va)}: {nm}')

# 2) COL: sig=1, off=0, cd=0, ptd=RVA, pcd=RVA
tdset = set(tds)
cols = {}
for sva, sz, off, name in secs:
    if name != '.rdata':
        continue
    blob = data[off:off+sz]
    for i in range(0, len(blob) - 24, 4):
        sig, o0, cd, ptd, pcd = struct.unpack_from('<IIIII', blob, i)
        if sig == 1 and o0 == 0 and ptd and imgbase + ptd in tdset:
            cols[sva + i] = tds[imgbase + ptd]
print(f'COLs: {len(cols)}')

# 3) vtable: 8B == COL VA 出现处, slot0 = +8
vtables = {}
colset = set(cols)
for sva, sz, off, name in secs:
    if name != '.rdata':
        continue
    blob = data[off:off+sz]
    for i in range(0, len(blob) - 8, 8):
        if struct.unpack_from('<Q', blob, i)[0] in colset:
            vft = sva + i + 8
            vtables.setdefault(cols[struct.unpack_from('<Q', blob, i)[0]], []).append(vft)
print(f'vtable 类数: {len(vtables)}')

# 4) 关键词过滤 + slot 提取
KEY = re.compile(r'Node|Component|Hierarchy|Shots|Sequence|Network|Repl|Property|Callee|Caller|Factory|Transform|Avatar|Vehicle|Hub|EndPoint', re.I)
out = {}
for nm, vfts in sorted(vtables.items()):
    if not KEY.search(nm): continue
    for vft in vfts:
        o = va2off(vft)
        if o is None: continue
        slots = struct.unpack_from('<20Q', data, o)
        good = sum(1 for s in slots[:12] if imgbase + 0x1000 <= s < imgbase + 0x3600000)
        if good < 10: continue
        out[f'{nm}@{vft:#x}'] = {
            'name': nm, 'vft': hex(vft),
            'slot3': hex(slots[3]), 'slot11': hex(slots[11]),
            'slots12': [hex(s) for s in slots[:12]],
        }
print(f'关键词类: {len(out)}')
json.dump(out, open('/tmp/wot/t52_vtables.json', 'w'), indent=1)
for k, v in sorted(out.items(), key=lambda kv: kv[1]['name']):
    print(f"{v['name'][:58]:58s} vft={v['vft']:>12s} slot3={v['slot3']:>12s} slot11={v['slot11']}")
