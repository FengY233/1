#!/usr/bin/env python3
"""t52_etreg.py — Task 52-④: EntityType 注册序逆向
0x143547xxx = CRT 动态初始化区, 内含注册表构建调用
目标: 找到注册函数 → 提取按调用序的组件类型注册(name/属性表) → tid 映射
"""
import pefile, struct, re
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()
md = Cs(CS_ARCH_X86, CS_MODE_64); md.detail = True

def va2off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

def dis(va, n=60, show=True):
    off = va2off(va)
    out = []
    for ins in md.disasm(data[off:off+n*8], va):
        out.append(ins)
        if len(out) >= n: break
    if show:
        for ins in out:
            print(f'  {ins.address:#x}: {ins.mnemonic:8s} {ins.op_str}')
    return out

def cstr(va, maxlen=100):
    off = va2off(va)
    if off is None: return None
    end = data.find(b'\0', off, off+maxlen)
    if end < 0: return None
    try: return data[off:end].decode('utf-8')
    except: return None

def lea_tgt(ins):
    if ins.mnemonic != 'lea' or 'rip' not in ins.op_str: return None
    m = re.search(r'rip\s*([+-])\s*(0x[0-9a-f]+)', ins.op_str)
    if not m: return None
    d = int(m.group(2), 16)
    if m.group(1) == '-': d = -d
    return ins.address + ins.size + d

print('=== 函数头定位: 0x143547db4 所在函数 ===')
# 向前找函数边界 (常见序言: 48 83 ec / 55 / 41 57 等), 用 index.tsv 更准
best = None
for line in open('/tmp/wot/decomp/index.tsv'):
    parts = line.rstrip('\n').split('\t')
    if not parts[0].startswith('14'): continue
    try: a = int(parts[0], 16); sz = int(parts[2])
    except: continue
    if a <= 0x143547db4 < a + sz:
        best = (a, sz, parts[1], parts[3], parts[4])
        break
print('所在函数:', best)
if best:
    va = best[0]
    print(f'=== FUN_{va:x} (size {best[1]}) 反汇编 ===')
    ins_list = dis(va, n=200, show=False)
    for ins in ins_list:
        line = f'  {ins.address:#x}: {ins.mnemonic:8s} {ins.op_str}'
        tgt = lea_tgt(ins)
        if tgt:
            s = cstr(tgt)
            if s and len(s) > 3 and s.isprintable():
                line += f'   ; "{s[:60]}"'
        if ins.mnemonic == 'call' and ins.op_str.startswith('0x'):
            line += '   ; CALL'
        print(line)
