#!/usr/bin/env python3
"""t52_ownveh2.py — OwnVehicle.def 属性真实 XML 序序 dump + tid=51 七包字节级拟合
"""
import sys, json, struct
sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file

# 1) OwnVehicle.def Properties 真实序
d = decode_file('/tmp/wot/wot_scripts/component_defs/OwnVehicle.def', 'OwnVehicle.def')
props_def = d.findChild('Properties')
order = []
for p in props_def.children:
    t = p.findChild('Type')
    an = p.findChild('AllowNone')
    order.append((p.name, t.asString() if t else '?', bool(an) if an else False))
print(f'=== OwnVehicle.def Properties (XML 序, {len(order)}) ===')
for i, (n, t, an) in enumerate(order):
    print(f'  [{i:2d}] {n:42s} {t:36s} {"AllowNone" if an else ""}')

# 2) ClientMethods 序
cm = d.findChild('ClientMethods')
if cm:
    print(f'\n=== ClientMethods ({len(cm.children)}) ===')
    for i, m in enumerate(cm.children):
        print(f'  [{i}] {m.name}')
cell = d.findChild('CellMethods')
if cell:
    print(f'=== CellMethods ({len(cell.children)}) ===')
    for i, m in enumerate(cell.children):
        print(f'  [{i}] {m.name}')

# 3) VEHICLE_AMMO 结构
a = decode_file('/tmp/wot/wot_scripts/entity_defs/alias.xml', 'alias.xml')
for top in a.children:
    if top.name == 'VEHICLE_AMMO':
        print('\n=== VEHICLE_AMMO ===')
        def dd(s, ind=0):
            print('  '*ind + s.name + (' = ' + str(s.asString()) if s.type == 1 else ''))
            for c in s.children: dd(c, ind+1)
        dd(top)
