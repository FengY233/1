#!/usr/bin/env python3
"""t52_v8.py — 解码器 v8: 引擎真文法 + per-tid 精确值读取器
v7 → v8 升级:
1. 方法段修正: 每方法 = [u8 methodID | FF→u24] (FUN_140e380e0 反汇编实证, slot13 零流读)
2. tid=51=OwnVehicle: N_props=23, 实证属性序 [0]=syncVehicleAttrs(10B 定长)
   [1]=vehicleAmmoList(ARRAY<VEHICLE_AMMO>) [18]=targetingInfo([u8 has][10×f32])
3. tid=112: N_props=1, prop0=订阅blob [03][eid][02]+n×([len][path][u32])+n×([eid][00])
4. tid=104: prop0=[u8 n][n×f32] (ARRAY<FLOAT>)
5. 其余沿用 v7 (全局节点表 + class0 修正 + 花名册 + arr4x16 + 自由长度兜底)
"""
import sys, struct, json, time
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from t50_v5a import RND, read_len, clist
from t50_free import make_free_parser
from t51_v6 import parse_roster_array

def make_v8(global_nodes, known_tids=frozenset(), maxvisit=500000):
    def parse_stream(stream):
        b = stream; n = len(b)
        if n < 2: return None
        visit = [0]
        nodes = dict(global_nodes)
        created = {}
        def reg(nid, rk):
            if nodes.get(nid) != rk:
                nodes[nid] = rk; created[nid] = rk
        def step(p, depth):
            if p >= n: return ('done', p)
            if n - p <= 2: return ('tail', p)
            if p + 3 > n: return None
            mcls = b[p]; mid = (b[p+1] << 8) | b[p+2]; q = p + 3
            if mcls > 6: return None
            visit[0] += 1
            if visit[0] > maxvisit: return None
            return dispatch(q, mcls, mid, depth + 1)

        # ---------- per-tid 精确属性读取器 ----------
        def rd_f32(p):
            return (p + 4, p + 4 <= n)
        def ownveh_prop(p, idx):
            """tid=51 OwnVehicle 属性 (实证序)"""
            if idx == 0:   # syncVehicleAttrs [u16][f32][f32]
                return (p + 10, p + 10 <= n)
            if idx == 1:   # vehicleAmmoList ARRAY<VEHICLE_AMMO>
                if p >= n: return (p, False)
                cnt = b[p]; q = p + 1
                if cnt == 0xff:
                    if q + 3 > n: return (p, False)
                    cnt = b[q] | (b[q+1] << 8) | (b[q+2] << 16); q += 3
                if cnt > 40: return (p, False)
                for _ in range(cnt):
                    if q >= n: return (p, False)
                    has = b[q]; q += 1
                    if has:
                        q += 17   # i32+u16*3+f32+i16+u8
                        if q > n: return (p, False)
                return (q, True)
            if idx == 18:  # targetingInfo [u8 has][10×f32]
                if p >= n: return (p, False)
                if b[p] == 0: return (p + 1, True)
                return (p + 41, p + 41 <= n)
            # 其余 20 个属性: 未观测到置位, 给宽松候选
            return None
        def sub_blob(p):
            """tid=112 prop0 订阅blob"""
            q = p
            if q + 6 > n: return None
            if b[q] != 0x03: return None
            q += 1; q += 4      # eid
            nsub = b[q]; q += 1
            if nsub > 8: return None
            for _ in range(nsub):
                if q >= n: return None
                ln = b[q]; q += 1
                if ln == 0xff:
                    if q + 3 > n: return None
                    ln = b[q] | (b[q+1] << 8) | (b[q+2] << 16); q += 3
                if ln > 120 or q + ln + 4 > n: return None
                q += ln + 4      # path + u32 value
            # bindings [eid][00]×
            cnt = 0
            while q + 5 <= n and (b[q] != 0x02 or q + 4 <= n and False):
                q += 5; cnt += 1
                if cnt > 8: return None
            return q
        def attach_chain(p):
            """tid=127 附着记录链: [tag][len][path][01][u32][u32] + n×11B记录(flag∈{0,1}, 00 02 id, 零)"""
            if p >= n or b[p] not in (2, 4, 6, 8): return None
            q = p + 1
            ln = b[q]; q += 1
            if q + ln + 9 > n: return None
            q += ln
            if b[q] != 1: return None
            q += 9      # [01][u32][u32]
            cnt = 0
            while q + 11 <= n:
                if b[q] > 1 or b[q+1] != 0 or b[q+2] != 2: break
                # 尾部字节须全零
                if any(b[q+i] for i in range(4, 11)): break
                q += 11; cnt += 1
                if cnt > 24: break
            if cnt < 1: return None
            return q
        def val_cands(p, tid=None, pidx=None):
            out = []
            rem = n - p
            if rem <= 0: return out
            # ★ per-tid 精确
            if tid == 51 and pidx is not None:
                r = ownveh_prop(p, pidx)
                if r: out.append((r[0], f'ov{pidx}'))
            if tid == 112 and pidx == 0:
                r = sub_blob(p)
                if r is not None: out.append((r, 'sub'))
            if tid == 127:
                r = attach_chain(p)
                if r is not None: out.append((r, 'attach'))
            for L, f in ((4, 'u32'), (1, 'u8'), (2, 'u16'), (4, 'f32'), (8, 'f64'), (12, 'v3'), (16, 'v4')):
                if L <= rem: out.append((p + L, f))
            l = b[p]
            hdr = 4 if l == 0xff else 1
            if l == 0xff and rem >= 4:
                l = b[p+1] | (b[p+2] << 8) | (b[p+3] << 24 % 256)
                l = b[p+1] | (b[p+2] << 8) | (b[p+3] << 16)
            if hdr + l <= rem and l <= 200: out.append((p + hdr + l, 'str'))
            if rem >= 2 and b[p] in (2, 4, 6, 8):
                l2 = b[p+1]
                if 2 + l2 <= rem and l2 <= 200: out.append((p + 2 + l2, 'tagstr'))
                q = p + 2 + l2
                stops = []
                for qq in range(q, min(n - 3, q + 64) + 1):
                    if b[qq] == 0x02:
                        t = b[qq+1] | (b[qq+2] << 8)
                        if t in known_tids or t <= 160:
                            stops.append(qq)
                            if len(stops) >= 5: break
                if not stops: stops = [q]
                for s in stops: out.append((s, 't127'))
            if b[p] <= 12:
                m = b[p]; q = p + 1; ok = True
                for _ in range(m):
                    if q >= n: ok = False; break
                    ln, q2 = read_len(b, q)
                    if q2 + ln + 4 > n: ok = False; break
                    q = q2 + ln + 4
                if ok: out.append((q, 'hier'))
            cnt0 = b[p]
            if cnt0 <= 40:
                for esz, ef in ((4, 'arrf'), (1, 'arr8'), (2, 'arr16'), (12, 'arrv3'), (8, 'arr64')):
                    e = p + 1 + cnt0 * esz
                    if e <= n: out.append((e, ef))
            if 1 <= cnt0 <= 64 and p + 1 + cnt0 * 8 <= n:
                out.append((p + 1 + cnt0 * 8, 'arr4x16'))
            return out
        def rk2_creates(p, nid, depth):
            if p + 2 > n: return
            tid = b[p] | (b[p+1] << 8)
            if tid > 400: return
            l, p2 = read_len(b, p + 2)
            if p2 + l > n: return
            p3 = p2 + l
            r = clist(b, p3, nid, n)
            if r is None: return
            vals, flags, p4 = r
            nv = len(vals)
            cnt = [0]
            if tid == 123 and nv >= 1:
                rr = parse_roster_array(b, p4, n)
                if rr is not None:
                    recs, q = rr
                    cnt[0] += 1
                    yield q
            def gen_props(pp, i, np_, acc):
                if i == np_:
                    yield pp, tuple(acc); return
                if i in flags:
                    cands = val_cands(pp, tid, i)
                    for e, fmt in cands:
                        acc.append(fmt)
                        yield from gen_props(e, i + 1, np_, acc)
                        acc.pop()
                else:
                    yield from gen_props(pp, i + 1, np_, acc)
            # ★ tid=51: N_props=23 固定; 其余: 全范围搜索 (方法段双模型)
            nps = [23] if tid == 51 else ([1] if tid == 112 else range(0, nv))
            for np_ in nps:
                if np_ > nv - 1: break
                for pp, fmts in gen_props(p4, 0, np_, []):
                    for mmodel in ('pk', 'ln'):
                        q = pp; ok = True
                        # ★ 方法段: pk=每方法 [u8 mid | FF→u24] (引擎真) / ln=[len][name] (兼容旧现测)
                        for j in range(np_, nv - 1):
                            if q >= n: ok = False; break
                            if mmodel == 'pk':
                                q += 4 if b[q] == 0xff else 1
                            else:
                                ln, q2 = read_len(b, q)
                                if q2 + ln > n: ok = False; break
                                q = q2 + ln
                            if q > n: ok = False; break
                        if not ok or q > n: continue
                        cnt[0] += 1
                        if cnt[0] > 3000: return
                        yield q
                        if q < n and b[q] <= 6:
                            for e in create_bodies(q + 1, b[q], vals[-1], depth + 1):
                                if e is not None and e > q:
                                    yield e
        def create_bodies(p, rk, nid, depth):
            if depth > 40: return
            if rk in (0, 6): yield p
            elif rk == 1:
                if p + 4 <= n: yield p + 4
            elif rk == 2:
                yield from rk2_creates(p, nid, depth)
            elif rk == 3:
                for L in (1, 2, 4, 8, 12, 16):
                    if p + L <= n: yield p + L
                if p < n:
                    l, q = read_len(b, p)
                    if q + l <= n and l <= 200: yield q + l
            elif rk == 4:
                if p + 1 > n: return
                kind = b[p]
                if kind <= 1:
                    l, q2 = read_len(b, p + 1)
                    if q2 + l <= n: yield q2 + l
                else:
                    for L in (1, 2, 4, 8):
                        if p + L <= n: yield p + L
            elif rk == 5:
                if p >= n: return
                l, q2 = read_len(b, p)
                if q2 + l <= n: yield q2 + l
        def dispatch(p, mcls, mid, depth):
            if depth > 60: return None
            if mcls == 0:
                if p + 3 > n: return None
                parent = (b[p] << 8) | b[p+1]; rk = b[p+2]
                if rk > 6: return None
                reg(mid, rk)
                for e in create_bodies(p + 3, rk, mid, depth):
                    r = step(e, depth)
                    if r is not None: return r
                return None
            elif mcls == 1:
                r = clist(b, p, mid, n)
                if r is None: return None
                vals, flags, q = r
                def rec(i, q2):
                    if i == len(vals):
                        return step(q2, depth)
                    if q2 + 1 > n: return None
                    rk = b[q2]
                    if rk > 6: return None
                    reg(vals[i], rk)
                    for e in create_bodies(q2 + 1, rk, vals[i], depth + 1):
                        r2 = rec(i + 1, e)
                        if r2 is not None: return r2
                    return None
                return rec(0, q)
            elif mcls in (2, 3, 5):
                return step(p, depth)
            elif mcls in (4, 6):
                rk = nodes.get(mid)
                if rk is None: return None
                if rk in (1, 2, 6): return step(p, depth)
                if rk == 3:
                    for L in (0, 1, 2, 4, 8, 12, 16):
                        if p + L <= n:
                            r = step(p + L, depth)
                            if r is not None: return r
                    if p < n:
                        l, q = read_len(b, p)
                        if q + l <= n and l <= 200:
                            return step(q + l, depth)
                    return None
                if rk == 4:
                    if p + 1 > n: return None
                    kind = b[p]
                    if kind <= 1:
                        l, q2 = read_len(b, p + 1)
                        if q2 + l > n: return None
                        return step(q2 + l, depth)
                    for L in (1, 2, 4, 8):
                        if p + L <= n:
                            r = step(p + L, depth)
                            if r is not None: return r
                    return None
                if rk == 0:
                    r = clist(b, p, mid, n)
                    if r is None: return None
                    vals, flags, q = r
                    nw = (len(vals) + 31) >> 5
                    if q + nw * 4 <= n:
                        r2 = step(q + nw * 4, depth)
                        if r2 is not None: return r2
                    return step(q, depth)
                return None
            return None
        mid0 = (b[0] << 8) | b[1]
        r = dispatch(2, 0, mid0, 0)
        if r is not None:
            global_nodes.update(created)
        return r
    return parse_stream

if __name__ == '__main__':
    pkgs_all = []; owner = []
    for gi, f in enumerate(RND):
        blocks, declared, slen, pkts = load(f)
        for t, c, pl in pkts:
            if t == 0x32: pkgs_all.append(pl[4:]); owner.append(gi)
    N = len(pkgs_all)
    known = set()
    for s in pkgs_all[:800]:
        for i in range(len(s) - 3):
            if s[i] == 0x02 and s[i+1] < 0xA0:
                known.add(s[i+1] | (s[i+2] << 8))
    known = {t for t in known if t <= 300}
    t0 = time.time()
    ok1 = 0; fails1 = []
    gnodes = {}; cur_g = -1
    for idx in range(N):
        if owner[idx] != cur_g:
            gnodes = {}; cur_g = owner[idx]
        p = make_v8(gnodes, known)
        r = p(pkgs_all[idx])
        if r is not None: ok1 += 1
        else: fails1.append(idx)
    print(f'Pass1(v8严格): {ok1}/{N} ({100*ok1/N:.2f}%) 耗时{time.time()-t0:.0f}s')
    t1 = time.time()
    free = make_free_parser(known)
    ok2 = 0; fails2 = []
    for idx in fails1:
        r, stats = free(pkgs_all[idx])
        if r is not None: ok2 += 1
        else: fails2.append(idx)
    total = ok1 + ok2
    print(f'Pass2(自由): +{ok2} → 总 {total}/{N} ({100*total/N:.2f}%) 耗时{time.time()-t1:.0f}s')
    print(f'剩余失败 {len(fails2)}: {fails2}')
    json.dump({'pass1_ok': ok1, 'pass2_fixed': ok2, 'total': total, 'n': N, 'fails_final': fails2},
              open('/tmp/wot/t52_v8_result.json', 'w'))
