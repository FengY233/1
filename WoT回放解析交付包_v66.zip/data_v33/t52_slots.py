#!/usr/bin/env python3
"""t52_slots.py — 提取七节点类 vtable 全 16 槽 + 反编译 MethodCallee slot13 与 rk4/rk3 slot13"""
import pefile, struct, re, json
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()
md = Cs(CS_ARCH_X86, CS_MODE_64); md.detail = True

def va2off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

VTS = {
    'BWRootNode':            0x1435df3e8,
    'BWEntityNode':          0x1435df458,
    'ClientDynComponentNode':0x1435df4d8,
    'ClientPrimitivePropertyNode': 0x1435df550,
    'ClientCompositePropertyNode': 0x1435df5c8,
    'ClientMethodCalleeNode':0x1435df640,
    'ServerMethodCallerNode':0x1435df6b8,
}
print('=== 七节点类 vtable 槽表 (slot0-15) ===')
tbl = {}
for nm, vft in VTS.items():
    o = va2off(vft)
    slots = struct.unpack_from('<16Q', data, o)
    tbl[nm] = [hex(s) for s in slots]
    print(f'{nm}:')
    for i, s in enumerate(slots):
        marker = ''
        if i == 3: marker = '  <- slot3 vt[0x18] 创建体'
        if i == 11: marker = '  <- slot11 vt[0x58] 更新体'
        if i == 13: marker = '  <- slot13 vt[0x68]'
        print(f'  [{i:2d}] 0x{s:012x}{marker}')
    print()

json.dump(tbl, open('/tmp/wot/t52_slots.json', 'w'), indent=1)

# 反编译 MethodCallee slot13
def dump_fn(va, name, maxins=60):
    print(f'=== {name} @ {va:#x} ===')
    o = va2off(va)
    if o is None: print('  不在节内'); return
    for i, ins in enumerate(md.disasm(data[o:o+maxins*8], va)):
        print(f'  {ins.address:#x}: {ins.mnemonic:8s} {ins.op_str}')
        if ins.mnemonic == 'ret' or i > maxins: break

mc = int(tbl['ClientMethodCalleeNode'][13], 16)
dump_fn(mc, 'ClientMethodCalleeNode slot13 (vt[0x68])', 40)
