#!/usr/bin/env python3
"""t52_etreg2.py — 直接解剖 0x143547xxx 注册现场 (绕过 index)"""
import pefile, struct, re
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()
md = Cs(CS_ARCH_X86, CS_MODE_64); md.detail = True

def va2off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

def cstr(va, maxlen=120):
    off = va2off(va)
    if off is None: return None
    end = data.find(b'\0', off, off+maxlen)
    if end < 0: return None
    s = data[off:end]
    if len(s) < 3: return None
    try: return s.decode('utf-8')
    except: return None

def lea_tgt(ins):
    if ins.mnemonic != 'lea' or 'rip' not in ins.op_str: return None
    m = re.search(r'rip\s*([+-])\s*(0x[0-9a-f]+)', ins.op_str)
    if not m: return None
    d = int(m.group(2), 16)
    if m.group(1) == '-': d = -d
    return ins.address + ins.size + d

# 找 0x143547db4 前面的函数序言: 向前扫 prologue
START_HINT = 0x143547db4
off = va2off(START_HINT)
# 向前找 push/sub 序言 (最多 8KB)
found = None
for back in range(0, 0x2000, 1):
    va = START_HINT - back
    o = va2off(va)
    b = data[o:o+4]
    # 常见序言: 48 83 ec xx | 55 | 41 57 | 48 89 5c
    if b[0] == 0x48 and b[1] == 0x89 and b[2] == 0x5c:
        found = va; break
    if b[0] == 0x55 and data[o-1] in (0xcc, 0x90, 0xc3):
        found = va; break
print(f'函数起点估计: {found:#x}')

va = found or START_HINT - 0x100
print(f'=== 从 {va:#x} 反汇编 ===')
o = va2off(va)
cnt = 0
for ins in md.disasm(data[o:o+0x1000], va):
    line = f'  {ins.address:#x}: {ins.mnemonic:8s} {ins.op_str}'
    tgt = lea_tgt(ins)
    if tgt:
        s = cstr(tgt)
        if s and s.isprintable() and len(s) > 2:
            line += f'   ; "{s[:70]}"'
        else:
            line += f'   ; -> {tgt:#x}'
    if ins.mnemonic == 'call':
        line += '   ;;CALL'
    print(line)
    cnt += 1
    if ins.mnemonic == 'ret' and ins.address > START_HINT:
        break
    if cnt > 300: break
