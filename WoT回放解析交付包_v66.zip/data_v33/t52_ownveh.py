#!/usr/bin/env python3
"""t52_ownveh.py — Task 52-①: tid=51=OwnVehicle 参数族终审
文法(反汇编级闭环): class0[parent 2B][rk2] + [tid][len][name] + clist(nv=35) +
N_props=23 属性循环(掩码位<23 读内联值) + 11 方法ID(各1B) + rk6
值格式: t48_types DataType 解码器 (alias 全解)
"""
import sys, json
sys.path.insert(0, '/home/z/my-project/scripts')
from t48_types import TypeTab, StreamR, decode_value
from survey_new_replays import load
from t50_v5a import RND

tt = TypeTab()

# 1) 展开三个焦点 alias
for t in ['VEHICLE_AMMO_LIST', 'VEHICLE_SYNC_ATTRS', 'TARGETING_INFO', 'VEHICLE_GUN_RELOAD_TIME']:
    e = tt.expand(t)
    print(f'=== {t} ===')
    print(json.dumps(e, ensure_ascii=False, default=str)[:1200])
    print()

# 2) OwnVehicle 23 属性全表
comps = json.load(open('/tmp/wot/t49_component_types.json'))
ov = comps['OwnVehicle']['props']
print(f'=== OwnVehicle {len(ov)} 属性 ===')
for i, p in enumerate(ov):
    e = tt.expand(p['type'])
    print(f'  [{i:2d}] {p["name"]:40s} {p["type"]:36s} -> {json.dumps(e, default=str)[:90]}')
