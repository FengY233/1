#!/usr/bin/env python3
"""t52_fns.py — 批量反编译节点读取函数簇
0x140e37ea0 (Prim/Comp slot3 jmp), FUN_140399180 (slot13 值读取),
FUN_140399890 (MethodCallee slot13), FUN_140399e20 (Prim slot12 更新),
FUN_140399aa0 (Comp slot12 更新), FUN_140e37ec0 (DynComp slot3), FUN_140e37f70 (Entity slot3)
"""
import pefile, struct, re
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()
md = Cs(CS_ARCH_X86, CS_MODE_64); md.detail = True

def va2off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

def dump(va, name, maxins=80):
    print(f'\n=== {name} @ {va:#x} ===')
    o = va2off(va)
    if o is None:
        print('  不在节内!'); return
    for i, ins in enumerate(md.disasm(data[o:o+maxins*8], va)):
        extra = ''
        if ins.mnemonic == 'call' and ins.op_str.startswith('0x'):
            extra = '  ;;CALL'
        print(f'  {ins.address:#x}: {ins.mnemonic:8s} {ins.op_str}{extra}')
        if ins.mnemonic == 'ret': break
        if i > maxins: break

dump(0x140e37ea0, 'Prim/Comp slot3 (vt[0x18])', 10)
dump(0x140e37ec0, 'DynComp slot3 (vt[0x18])', 10)
dump(0x140e37f70, 'Entity slot3 (vt[0x18])', 20)
dump(0x140399180, 'Prim/Comp slot13 — 内联值读取器', 100)
