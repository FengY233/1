#!/usr/bin/env python3
"""t52_ownveh4.py — 全部 tid=51 实例普查(含通过者): 掩码/值区/尾结构对照"""
import sys, json, struct
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from t50_v5a import RND

pkgs = []; owner = []
for gi, f in enumerate(RND):
    blocks, declared, slen, pkts = load(f)
    for t, c, pl in pkts:
        if t == 0x32: pkgs.append(pl[4:]); owner.append(gi)

def clist(b, p, base, n):
    vals, flags, v = [], set(), base
    while True:
        if p >= n: return None
        c = struct.unpack('b', b[p:p+1])[0]; p += 1
        if c == 0: return vals, flags, p
        elif c == -0x80:
            if p + 2 > n: return None
            v = struct.unpack('>H', b[p:p+2])[0]; p += 2; vals.append(v)
        elif c == -0x7f: vals.append(0)
        elif c == -0x7e:
            nmask = (len(vals) + 7) >> 3
            if p + nmask > n: return None
            mask = b[p:p+nmask]; p += nmask
            for i in range(nmask * 8):
                if mask[i >> 3] & (1 << (i & 7)): flags.add(i)
            return vals, flags, p
        elif 1 <= c <= 0x7f:
            v += c; vals.append(v)
        else:
            for _ in range(c + 126):
                v += 1; vals.append(v)

insts = []
for idx, b in enumerate(pkgs):
    if len(b) < 30: continue
    # 首消息 class0 rk2 tid=51: b[4]=2, b[5:7]=33 00
    if b[4] != 2 or b[5:7] != b'\x33\x00': continue
    ln = b[7]
    r = clist(b, 8 + ln, 0, len(b))
    if r is None: continue
    vals, flags, p = r
    insts.append({'idx': idx, 'len': len(b), 'nv': len(vals), 'flags': sorted(flags),
                  'vstart': p, 'gi': owner[idx]})

print(f'tid=51 实例总数: {len(insts)}')
fails = {48, 560, 600, 845, 1165, 1442, 3500, 5314, 5547, 5736, 6138}
for x in insts:
    b = pkgs[x['idx']]
    tag = '✗FAIL' if x['idx'] in fails else '✓PASS'
    # 尾部 12B
    tail = b[-12:].hex()
    print(f"  #{x['idx']:5d} {tag} len={x['len']:4d} nv={x['nv']:3d} vstart={x['vstart']:3d} "
          f"flags={x['flags'][:12]}{'...' if len(x['flags'])>12 else ''} tail={tail}")

# 通过者的值区结构样本
print('\n=== PASS 实例值区样本 ===')
for x in insts:
    if x['idx'] in fails: continue
    b = pkgs[x['idx']]
    vs, ve = x['vstart'], len(b) - 12
    print(f"  #{x['idx']}: len={x['len']} nv={x['nv']} flags={x['flags']}")
    print(f'    值区[{vs}:{ve}] {len(b)-12-vs}B: {b[vs:min(vs+64, len(b))].hex()}')
    break
json.dump([{'idx': x['idx'], 'len': x['len'], 'nv': x['nv'], 'flags': x['flags'], 'vstart': x['vstart']} for x in insts],
          open('/tmp/wot/t52_t51_all.json', 'w'))
