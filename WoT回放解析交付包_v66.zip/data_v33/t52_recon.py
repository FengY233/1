#!/usr/bin/env python3
"""t52_recon.py — Task 52 侦察: v7 终版 19 失败包全息解剖
目标: 逐包 hex + 结构签名 + 卡死点, 输出精确分类( tid=51 参数族 / 订阅族 / 回调链 / tid=0 命名组件 / 深链 )
"""
import sys, json, collections
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from t50_v5a import RND

pkgs = []; owner = []
for gi, f in enumerate(RND):
    blocks, declared, slen, pkts = load(f)
    for t, c, pl in pkts:
        if t == 0x32: pkgs.append(pl[4:]); owner.append(gi)
N = len(pkgs)
fails = json.load(open('/tmp/wot/t51_v7_result.json'))['fails_final']
print(f'0x32 包总数 {N}, 终版失败 {len(fails)}: {fails}')

def hx(b, p=0, w=48):
    seg = b[p:p+w]
    return ' '.join(f'{x:02x}' for x in seg)

# TRAILER 同 fit2 — tid=51 族签名
TRAILER = bytes.fromhex('04090a0203010506000708')

cat = collections.Counter(); rows = []
for idx in fails:
    b = pkgs[idx]; n = len(b)
    gi = owner[idx]
    sig = []
    # 签名 1: tid=51 族 (首消息 class0 rk2 tid=51)
    is_t51 = False
    if n >= 10 and b[4] == 2 and b[5:8] == b'\x33\x00\x00' and b[8] == 0xa5 and b[9] == 0x82:
        is_t51 = True
    # 签名 2: 订阅族 (体内出现可见属性路径串)
    txt = ''
    try:
        txt = b.decode('latin1')
    except Exception:
        pass
    has_path = any(s in txt for s in ('veh.', 'acc.', 'bhDynAcc.', 'avatar.', 'vehicle.'))
    # 签名 3: tid=0 命名组件创建
    has_tid0 = b'\x00\x00' in b[:64] and b[4:7] == b'\x00\x00\x00'
    # 首消息头
    mid0 = (b[0] << 8) | b[1]
    # 打印前 64B hex
    print(f'\n--- #{idx} (场{gi}) len={n} mid0=0x{mid0:04x} t51={is_t51} path={has_path}')
    print(f'  head: {hx(b, 0, 64)}')
    if n > 64:
        print(f'  mid : {hx(b, 64, 48)}')
    if n > 112:
        print(f'  tail: {hx(b, n-48, 48)}')
    # 分类
    if is_t51: c = 'tid51参数族'
    elif has_path: c = '订阅族'
    elif has_tid0: c = 'tid0命名组件'
    else: c = '其他/深链'
    cat[c] += 1
    rows.append({'idx': idx, 'gi': gi, 'n': n, 'cat': c, 'mid0': mid0,
                 't51': is_t51, 'path': has_path, 'tid0': has_tid0})

print('\n=== 分类统计 ===')
for k, v in cat.most_common():
    print(f'  {k}: {v}')
json.dump(rows, open('/tmp/wot/t52_recon.json', 'w'), ensure_ascii=False, indent=1)
print('已写 /tmp/wot/t52_recon.json')
