#!/usr/bin/env python3
"""t52_rtti.py — Task 52-③: RTTI→vtable 静态提取
1) 解析 PE, 扫描 .data/.rdata 中所有 MSVC RTTI Type Descriptor (".?AV..." 名字)
2) 找引用 TypeDescriptor 的 Complete Object Locator → 定位 vtable
3) 过滤节点类/组件类关键词, 输出 vtable VA + slot3(0x18, 创建体读取) + slot11(0x58, 更新体读取)
"""
import pefile, struct, re, json

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

# section 表: VA → 文件偏移
secs = []
for s in pe.sections:
    secs.append((imgbase + s.VirtualAddress, s.VirtualAddress, s.SizeOfRawData,
                 s.PointerToRawData, s.Name.decode().rstrip('\0')))
def va2off(va):
    for sva, rva, sz, off, name in secs:
        if sva <= va < sva + sz:
            return off + (va - sva)
    return None

# 1) 扫描 .?AV 名字 (Type Descriptor 尾部)
print('sections:', [(hex(s[0]), s[4]) for s in secs])
tds = []  # (td_va, name)
for sva, rva, sz, off, name in secs:
    if name not in ('.rdata', '.data'):
        continue
    blob = data[off:off+sz]
    for m in re.finditer(rb'\.\?A[VUM]@', blob):
        va = sva + m.start()
        # 名字到 \0
        end = blob.find(b'\0', m.start())
        if end < 0 or end - m.start() > 200: continue
        nm = blob[m.start():end].decode('latin1', 'replace')
        # TypeDescriptor 起点 = 名字 - 16 (vftable ptr + spare)
        td_va = va - 16
        tds.append((td_va, nm))
print(f'Type Descriptors: {len(tds)}')

# 2) 建立 TypeDescriptor VA 集合, 扫描 COL (含 RVA 指向 td)
td_set = {td_va: nm for td_va, nm in tds}
cols = {}  # col_va -> td_name
for sva, rva, sz, off, name in secs:
    if name not in ('.rdata',):
        continue
    blob = data[off:off+sz]
    for i in range(0, len(blob) - 24, 4):
        # COL x64: sig=1, offset=0, cdOffset=0, pTypeDescriptor(RVA), pClassDescriptor(RVA)
        sig, off0, cd, ptd, pcd = struct.unpack_from('<IIIII', blob, i)
        if sig == 1 and off0 == 0 and ptd and pcd:
            td_va = imgbase + ptd
            if td_va in td_set and (imgbase + pcd) < sva + sz:
                cols[sva + i] = td_set[td_va]
print(f'Complete Object Locators: {len(cols)}')

# 3) 扫描 .rdata 中 8B 指针 == COL VA → vtable (COL 存于 vtable[-1], slot0 在 COL+8)
vtables = {}  # vftable_va(slot0) -> class name
col_set = set(cols)
for sva, rva, sz, off, name in secs:
    if name not in ('.rdata',):
        continue
    blob = data[off:off+sz]
    n = len(blob) // 8
    for i in range(n):
        ptr = struct.unpack_from('<Q', blob, i*8)[0]
        if ptr in col_set:
            vft = sva + i*8 + 8
            nm = cols[ptr]
            # 去重: 同一 COL 可能被多个 vtable 引用(多继承), 保留全部
            vtables.setdefault(nm, []).append(vft)
print(f'vtables: {len(vtables)} 类')

# 4) 过滤目标类
KEY = re.compile(r'Node|Component|Hierarchy|Shots|Sequence|Network|Repl|Property|Callee|Caller|Factory|Transform|Avatar|Vehicle', re.I)
hits = {k: v for k, v in vtables.items() if KEY.search(k)}
print(f'关键词命中: {len(hits)} 类')

out = {}
for nm, vfts in sorted(hits.items()):
    for vft in vfts:
        o = va2off(vft)
        if o is None: continue
        slots = struct.unpack_from('<24Q', data, o)  # 24 槽
        # 校验: slot 指针须在代码段
        good = all(imgbase + 0x1000 <= s < imgbase + 0x3600000 for s in slots[:12] if s)
        if not good: continue
        key = f'{nm}@{vft:#x}'
        out[key] = {
            'name': nm, 'vft': vft,
            'slot3_create': hex(slots[3]) if len(slots) > 3 else None,
            'slot11_update': hex(slots[11]) if len(slots) > 11 else None,
            'slots': [hex(s) for s in slots[:16]],
        }
print(f'有效 vtable 记录: {len(out)}')
json.dump(out, open('/tmp/wot/t52_vtables.json', 'w'), indent=1)
# 摘要打印
for k, v in sorted(out.items()):
    print(f"{v['name'][:60]:60s} vft={v['vft']:#x} slot3={v['slot3_create']} slot11={v['slot11_update']}")
