#!/usr/bin/env python3
"""t52_ownveh3.py — tid=51=OwnVehicle 七包终审拟合
类型表: alias.xml 全展开; 属性序假设: XML序/字母序 双验证
文法: clist(nv=35) + N_props=23 掩码内联值 + 11×1B 方法ID + rk6
"""
import sys, json, struct
sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file
from survey_new_replays import load
from t50_v5a import RND

# ---------- 1) alias 表 ----------
_alias_raw = {}
_a = decode_file('/tmp/wot/wot_scripts/entity_defs/alias.xml', 'alias.xml')
def sec_struct(s):
    """Section → 类型树 dict"""
    if s.type == 1:
        return s.asString()
    ch = {c.name: c for c in s.children}
    if 'Type' in ch:
        return sec_struct(ch['Type'])
    if s.name == 'ARRAY' or 'of' in ch:
        return ('ARRAY', sec_struct(ch['of']) if 'of' in ch else None,
                int(ch['size'].asInt()) if 'size' in ch else 0)
    # FIXED_DICT 等: Properties 子节点
    if 'Properties' in ch:
        fs = []
        for p in ch['Properties'].children:
            pc = {c.name: c for c in p.children}
            fs.append((p.name, sec_struct(pc['Type']) if 'Type' in pc else None))
        return ('FIXED_DICT', fs, 'AllowNone' in ch)
    # TUPLE
    if s.name == 'TUPLE' or 'tuple' in ch:
        pass
    return s.name
for top in _a.children:
    _alias_raw[top.name] = sec_struct(top)
print(f'alias 表: {len(_alias_raw)} 类型')

PRIM = {'INT8':1,'UINT8':1,'BOOL':1,'INT16':2,'UINT16':2,'INT24':3,'UINT24':3,
        'INT32':4,'UINT32':4,'FLOAT':4,'FLOAT32':4,'FLOAT64':8,'INT64':8,'UINT64':8,'DB_ID':8,
        'OBJECT_ID':8,'VECTOR2':8,'VECTOR3':12,'VECTOR4':16}

def expand(t, depth=0):
    """类型树 → 规范式"""
    if depth > 10: return None
    if isinstance(t, str):
        if t in PRIM: return ('prim', t, PRIM[t])
        if t in ('STRING','BLOB'): return ('str',)
        if t == 'PYTHON': return ('str',)
        if t in _alias_raw: return expand(_alias_raw[t], depth+1)
        return ('unknown', t)
    if isinstance(t, tuple):
        if t[0] == 'ARRAY':
            return ('seq', expand(t[1], depth+1), t[2])
        if t[0] == 'FIXED_DICT':
            fs = [(n, expand(ft, depth+1)) for n, ft in t[1]]
            return ('dict', fs, t[2])
    return None

# OwnVehicle 23 属性
_d = decode_file('/tmp/wot/wot_scripts/component_defs/OwnVehicle.def', 'ov')
props_xml = []
for p in _d.findChild('Properties').children:
    t = p.findChild('Type')
    props_xml.append((p.name, t.asString() if t else '?'))
props_alpha = sorted(props_xml, key=lambda x: x[0])

def types_for(order):
    return [(n, expand(t)) for n, t in order]

# ---------- 2) 读流解码 ----------
def rd_val(b, p, ty):
    """按规范式读值, 返回 (end, ok)"""
    k = ty[0]
    if k == 'prim':
        sz = ty[2]
        if p + sz > len(b): return p, False
        return p + sz, True
    if k == 'str':
        if p >= len(b): return p, False
        l = b[p]; p += 1
        if l == 0xff:
            if p + 3 > len(b): return p, False
            l = b[p] | (b[p+1] << 8) | (b[p+2] << 16); p += 3
        if p + l > len(b): return p, False
        return p + l, True
    if k == 'seq':
        _, elem, n = ty
        if n == 0:
            if p >= len(b): return p, False
            cnt = b[p]; p += 1
            if cnt == 0xff:
                cnt = b[p] | (b[p+1] << 8) | (b[p+2] << 16); p += 3
        else:
            cnt = n
        for _ in range(cnt):
            p, ok = rd_val(b, p, elem)
            if not ok: return p, False
        return p, True
    if k == 'dict':
        _, fs, allow_none = ty
        if allow_none:
            if p >= len(b): return p, False
            has = b[p]; p += 1
            if has == 0: return p, True
        for _, ft in fs:
            p, ok = rd_val(b, p, ft)
            if not ok: return p, False
        return p, True
    return p, False

# ---------- 3) 载入 7 个失败包 ----------
pkgs = []; owner = []
for gi, f in enumerate(RND):
    blocks, declared, slen, pkts = load(f)
    for t, c, pl in pkts:
        if t == 0x32: pkgs.append(pl[4:]); owner.append(gi)

TRAILER = bytes.fromhex('04090a0203010506000708')
def clist(b, p, base, n):
    vals, flags, v = [], set(), base
    while True:
        if p >= n: return None
        c = struct.unpack('b', b[p:p+1])[0]; p += 1
        if c == 0: return vals, flags, p
        elif c == -0x80:
            if p + 2 > n: return None
            v = struct.unpack('>H', b[p:p+2])[0]; p += 2; vals.append(v)
        elif c == -0x7f: vals.append(0)
        elif c == -0x7e:
            nmask = (len(vals) + 7) >> 3
            if p + nmask > n: return None
            mask = b[p:p+nmask]; p += nmask
            for i in range(nmask * 8):
                if mask[i >> 3] & (1 << (i & 7)): flags.add(i)
            return vals, flags, p
        elif 1 <= c <= 0x7f:
            v += c; vals.append(v)
        else:
            for _ in range(c + 126):
                v += 1; vals.append(v)

fails = [48, 560, 600, 845, 1165, 1442, 3500, 5314, 5547, 5736, 6138]  # 含 48/560/600 待验
t51p = []
for idx, b in enumerate(pkgs):
    if len(b) < 60: continue
    if b[4] == 2 and b[5:8] == b'\x33\x00\x00' and b[8] in (0xa5,) or \
       (b[4] == 2 and b[5:8] == b'\x33\x00\x00' and b[8] in (0x84, 0x92)):
        ti = b.find(TRAILER)
        if ti > 0: t51p.append((idx, b, ti))
print(f'\ntid=51 族: {len(t51p)} 包: {[x[0] for x in t51p]}')

# ---------- 4) 双序拟合 ----------
for label, order in (('XML序', props_xml), ('字母序', props_alpha)):
    tys = types_for(order)
    print(f'\n===== 假设: {label} =====')
    for idx, b, ti in t51p:
        n = len(b)
        # clist
        r = clist(b, 9, 0, n)
        if r is None: print(f'  #{idx}: clist FAIL'); continue
        vals, flags, p = r
        nv = len(vals)
        flagprops = sorted(x for x in flags if x < 23)
        methods = nv - 1 - 23
        # 方法段
        q = ti
        ok_m = True
        for j in range(methods):
            if q >= ti + 11: pass
        # 值区 = [p, ti)
        end = ti
        cur = p
        ok = True
        detail = []
        for i in flagprops:
            ty = tys[i][1]
            if ty is None: ok = False; detail.append(f'prop{i}=无类型'); break
            cur2, good = rd_val(b, cur, ty)
            detail.append(f'p{i}[{cur}:{cur2}]{"✓" if good else "✗"}')
            if not good or cur2 > end: ok = False; break
            cur = cur2
        if ok and cur == end:
            print(f'  #{idx}: ★完全闭环 nv={nv} flagprops={flagprops} methods={methods} | {" ".join(detail)}')
        else:
            print(f'  #{idx}: ✗ cur={cur} end={end} flagprops={flagprops} | {" ".join(detail[:6])}')
