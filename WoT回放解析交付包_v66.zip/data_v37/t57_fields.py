#!/usr/bin/env python3
"""t57_fields.py — Task 57-b 终验: 0x37 op=2 全量 fi→VEHICLES_INFO 字段语义解码
定案模型:
  消息 [nid][02][L][位流 [1][idx1 6b][0][fi 6b][pad2]][字节对齐字段值]
  roster 镜像节点: idx1 = 32 + roster_pos (30 玩家), fi = VEHICLES_INFO 39 字段索引
字段表(t51_v6 parse_vehicles_info 线序):
  0 vehicleID i32 | 1 isAlive u8 | 2 outfitCD blob | 3 compDescr blob | 4 fakeName str
  5 name str | 6 team u8 | 7 isAvatarReady u8 | 8 isTeamKiller u8 | 9 accountDBID i64
  10 clanAbbrev str | 11 clanDBID i64 | 12 prebattleID i32 | 13 isPrebattleCreator u8
  14 forbidInBattleInvitations u8 | 15 igrType u8 | 16 avatarSessionID str
  17 overriddenBadge u8 | 18 customRoleSlotTypeId u8 | 19 botDisplayStatus u8
  20 teamPanelMode u8 | 21 maxHealth i16 | 22 prestigeLevel i32 | 23 prestigeGradeMarkID i32
  24 vehPostProgression arr | 25 personalMissionIDs arr | 26 personalMissionInfo blob
  27 events blob | 28 badges blob | 29 ranked tuple | 30 deathInfo FD(13B)
  31 respawnID u32 | 32 stFrags u32 | 33 frags i16 | 34 activePetID i32 | 35 tkills i16
  36 fogOfWar u8 | 37 position (i16,i16) | 38 __generation u32
"""
import struct, sys, json, glob
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import defaultdict, Counter

FILES = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TAGS = ['siegfried', 'karelia', 'lakeville', 'caucasus_NA', 'namerica', 'tundra',
        'caucasus_CN', 'greatwall', 'karelia2', 'PTZ', 'WZ219']
FIELDS = ['vehicleID', 'isAlive', 'outfitCD', 'compDescr', 'fakeName', 'name', 'team',
          'isAvatarReady', 'isTeamKiller', 'accountDBID', 'clanAbbrev', 'clanDBID',
          'prebattleID', 'isPrebattleCreator', 'forbidInBattleInv', 'igrType',
          'avatarSessionID', 'overriddenBadge', 'customRoleSlot', 'botDisplayStatus',
          'teamPanelMode', 'maxHealth', 'prestigeLevel', 'prestigeGradeMarkID',
          'vehPostProgression', 'personalMissionIDs', 'personalMissionInfo', 'events',
          'badges', 'ranked', 'deathInfo', 'respawnID', 'stFrags', 'frags', 'activePetID',
          'tkills', 'fogOfWar', 'position', '__generation']


def decode_op2(blob):
    if not blob:
        return None
    b0 = blob[0]
    if not (b0 & 0x80) or (b0 & 0x01):
        return None
    idx1 = (b0 >> 1) & 0x3F
    if len(blob) < 2:
        return None
    b1 = blob[1]
    if b1 & 0x03:
        return None
    fi = (b1 >> 2) & 0x3F
    return idx1, fi, blob[2:]


def simulate(path):
    blocks, declared, slen, pkts = load(path)
    events = [(t, c, p) for t, c, p in pkts if t in (0x35, 0x36, 0x37)]
    buf = bytearray(); start = 0; msgs = []
    for t, c, p in events:
        if t == 0x37:
            n = struct.unpack_from('<I', p, 0)[0] if len(p) >= 4 else 0
            buf += p[4:4+n]
        elif t == 0x36:
            pos = start
            if pos + 2 > len(buf):
                continue
            nid = struct.unpack_from('>H', buf, pos)[0]
            if pos + 4 <= len(buf) and buf[pos+2] in (0, 1, 2):
                op, L = buf[pos+2], buf[pos+3]
                if L == 0xff:
                    if pos + 7 > len(buf):
                        continue
                    L = int.from_bytes(buf[pos+4:pos+7], 'little'); vstart = pos + 7
                else:
                    vstart = pos + 4
                if vstart + L > len(buf):
                    continue
                msgs.append((nid, op, L, bytes(buf[vstart:vstart+L]), c))
                start = vstart + L
            else:
                msgs.append((nid, None, 0, b'', c))
                start = pos + 2
        else:
            pos = start
            if pos + 2 > len(buf):
                continue
            nid = struct.unpack_from('>H', buf, pos)[0]
            msgs.append((nid, 'c2', 0, b'', c))
            start = pos + 2
    return msgs


stat = defaultdict(Counter)      # (fi, L) -> count
samples = defaultdict(list)      # (fi, L) -> values
per_game_fi = defaultdict(Counter)
for gi, f in enumerate(FILES):
    msgs = simulate(f)
    for nid, op, L, vh, c in msgs:
        if isinstance(op, int) and op == 2 and 3 <= L <= 30:
            r = decode_op2(vh)
            if not r:
                continue
            idx1, fi, val = r
            if not (32 <= idx1 <= 61):
                continue  # 只统计玩家槽
            stat[(fi, L)][TAGS[gi]] += 1
            per_game_fi[TAGS[gi]][fi] += 1
            if len(samples[(fi, L)]) < 6:
                samples[(fi, L)].append((TAGS[gi], idx1, val.hex()))

print('=== (fi, L) 组合分布 × 字段名（玩家槽 idx1=32-61）===')
tot = 0
for (fi, L), cc in sorted(stat.items(), key=lambda kv: -sum(kv[1].values())):
    n = sum(cc.values())
    tot += n
    name = FIELDS[fi] if fi < len(FIELDS) else f'f{fi}'
    vals = samples[(fi, L)]
    print(f'fi={fi:>2} L={L:>2} {name:<20} ×{n:>6}  样例: {[(v[1], v[2][:18]) for v in vals[:3]]}')
print(f'合计玩家槽 op=2 消息: {tot}')

# fi=37 position 坐标域验证
print('\n=== fi=37 position 坐标域(i16 pairs) ===')
posvals = []
for gi, f in enumerate(FILES):
    for nid, op, L, vh, c in simulate(f):
        if isinstance(op, int) and op == 2 and L == 6:
            r = decode_op2(vh)
            if r and 32 <= r[0] <= 61 and r[1] == 37 and len(r[2]) == 4:
                x, y = struct.unpack('<hh', r[2])
                posvals.append((x, y))
xs = [p[0] for p in posvals]; ys = [p[1] for p in posvals]
print(f'n={len(posvals)} x∈[{min(xs)},{max(xs)}] y∈[{min(ys)},{max(ys)}] '
      f'(WoT 地图 ±500m 量级 → 网格坐标单位)')

# fi=38 __generation 单调性验证(单场单玩家)
print('\n=== fi=38 __generation 单场单玩家单调性(siegfried) ===')
msgs = simulate(FILES[0])
gen = defaultdict(list)
for nid, op, L, vh, c in msgs:
    if isinstance(op, int) and op == 2 and L == 6:
        r = decode_op2(vh)
        if r and r[1] == 38 and len(r[2]) == 4:
            gen[r[0]].append(struct.unpack('<I', r[2])[0])
bad_mono = 0
for idx1, seq in sorted(gen.items()):
    if any(b < a for a, b in zip(seq, seq[1:])):
        bad_mono += 1
print(f'玩家数={len(gen)} 终值范围=[{min(max(s) for s in gen.values())},{max(max(s) for s in gen.values())}] '
      f'非单调玩家数={bad_mono}')

json.dump({'fields': FIELDS,
           'combos': {f'{fi}_{L}': dict(cc) for (fi, L), cc in stat.items()},
           'position_range': {'x': [min(xs), max(xs)], 'y': [min(ys), max(ys)], 'n': len(posvals)},
           'generation_check': {'players': len(gen), 'bad_mono': bad_mono,
                                'final_range': [min(max(s) for s in gen.values()), max(max(s) for s in gen.values())]}},
          open('/tmp/wot/t57_fields.json', 'w'), ensure_ascii=False, indent=1)
print('\nsaved -> /tmp/wot/t57_fields.json')
