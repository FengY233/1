#!/usr/bin/env python3
"""t57_l16.py — Task 57-b: L=16 击杀记录直接提取(不经旧链 JSON)
结构定案(窗口手工解析):
  死亡三联包(同 nid 连续):
    [nid][02][1A][位流 idx1, fi=27][17][pickle {"deathOrder":N}]
    [nid][02][10][位流 idx1, fi=30][01][victim eid u32][attacker eid u32][尾 5B]
    [nid][02][04/06][位流 idx1, fi=?][状态/计数]
  L=16 typed value = blob[2:] = [01][victim 4B][attacker 4B][5B]
产出: 全量击杀表(victim/attacker eid + idx1 + deathOrder) + roster join 验证
"""
import struct, sys, json, glob, re
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import defaultdict

ROSTER = json.load(open('/home/z/my-project/download/data_v32/t51_roster_dump.json'))
FILES = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TAGS = ['siegfried_EU_935', 'karelia_EU_935', 'lakeville_EU_935', 'caucasus_NA_945',
        'namerica_CN_942', 'tundra_CN_942', 'caucasus_CN_942', 'greatwall_EU_944',
        'karelia2_EU_944', 'PTZ_EU_944', 'WZ219_EU_944']
RKEYS = sorted(ROSTER.keys(), key=lambda k: int(k.split('_')[0].replace('replay', '')))


def ridx(gi):
    return gi if gi <= 4 else gi - 1


def bits_of(blob):
    out = []
    for byte in blob:
        for k in range(7, -1, -1):
            out.append((byte >> k) & 1)
    return out


def decode_op2(blob):
    """深度1位流: [1][idx1 6b][0][finalIdx 6b] + 字节对齐类型值(blob[2:])"""
    bits = bits_of(blob)
    if bits[0] != 1:
        return None
    idx1 = 0
    for i in range(1, 7):
        idx1 = (idx1 << 1) | bits[i]
    if bits[7] != 0:
        return None
    fi = 0
    for i in range(8, 14):
        fi = (fi << 1) | bits[i]
    return idx1, fi, blob[2:]


def simulate(path):
    blocks, declared, slen, pkts = load(path)
    events = [(t, c, p) for t, c, p in pkts if t in (0x35, 0x36, 0x37)]
    buf = bytearray(); start = 0; msgs = []
    for t, c, p in events:
        if t == 0x37:
            n = struct.unpack_from('<I', p, 0)[0] if len(p) >= 4 else 0
            buf += p[4:4+n]
        elif t == 0x36:
            pos = start
            if pos + 2 > len(buf):
                continue
            nid = struct.unpack_from('>H', buf, pos)[0]
            if pos + 4 <= len(buf) and buf[pos+2] in (0, 1, 2):
                op, L = buf[pos+2], buf[pos+3]
                if L == 0xff:
                    if pos + 7 > len(buf):
                        continue
                    L = int.from_bytes(buf[pos+4:pos+7], 'little'); vstart = pos + 7
                else:
                    vstart = pos + 4
                if vstart + L > len(buf):
                    continue
                msgs.append((nid, op, L, bytes(buf[vstart:vstart+L]), c))
                start = vstart + L
            else:
                msgs.append((nid, None, 0, b'', c))
                start = pos + 2
        else:
            pos = start
            if pos + 2 > len(buf):
                continue
            nid = struct.unpack_from('>H', buf, pos)[0]
            msgs.append((nid, 'c2', 0, b'', c))
            start = pos + 2
    return msgs


kills = []
for gi, f in enumerate(FILES):
    msgs = simulate(f)
    # L=16 击杀记录: typed = [01][victim][attacker][5B]
    for i, (nid, op, L, vh, c) in enumerate(msgs):
        if isinstance(op, int) and op == 2 and L == 16:
            r = decode_op2(vh)
            if not r or len(r[2]) < 9 or r[2][0] != 1:
                continue
            idx1, fi, val = r
            victim = struct.unpack_from('<I', val, 1)[0]
            attacker = struct.unpack_from('<I', val, 5)[0]
            tail = val[9:].hex()
            # 邻近 L=26 (deathOrder) 与 L=4/6
            do = None
            for j in range(max(0, i-3), min(len(msgs), i+4)):
                n2, o2, L2, v2, c2 = msgs[j]
                if isinstance(o2, int) and o2 == 2 and L2 == 26 and n2 == nid:
                    r2 = decode_op2(v2)
                    if r2 and r2[0] == idx1:
                        m = re.search(rb'deathOrder.{0,3}?K(.)s\.', r2[2], re.S)
                        if m:
                            do = m.group(1)[0]
            kills.append({'game': gi, 'tag': TAGS[gi], 'nid': nid, 'clk': c,
                          'idx1': idx1, 'fi': fi, 'victim': victim, 'attacker': attacker,
                          'tail': tail, 'deathOrder': do})

print(f'L=16 击杀记录全量: {len(kills)} 条')
by_g = defaultdict(int)
for k in kills:
    by_g[k['tag']] += 1
print('分场:', dict(by_g))

# roster join: victim/attacker eid -> 身份
print('\n=== roster join 验证(idx1 == pos+32?) ===')
ok = bad = nomatch = 0
feed = []
for k in kills:
    if k['game'] == 5:
        continue
    players = ROSTER[RKEYS[ridx(k['game'])]]['players']
    pos_by_eid = {}
    for i, p in enumerate(players):
        pos_by_eid[str(p.get('avatarSessionID'))] = (i, p)
        pos_by_eid[str(p.get('vehicleID'))] = (i, p)
    v = pos_by_eid.get(str(k['victim']))
    a = pos_by_eid.get(str(k['attacker']))
    if v is None:
        nomatch += 1
        feed.append((k, None, None))
    else:
        pos, pv = v
        if pos + 32 == k['idx1']:
            ok += 1
        else:
            bad += 1
        feed.append((k, (pos, pv), a))

print(f'idx1==pos+32: {ok} | 不等: {bad} | victim不在roster: {nomatch}')

# 击杀 feed 样例(带身份)
print('\n=== 击杀 feed 样例(每场前3) ===')
shown_per_tag = defaultdict(int)
for k, v, a in feed:
    if shown_per_tag[k['tag']] >= 3:
        continue
    shown_per_tag[k['tag']] += 1
    vn = v[1]['name'] if v else f"?eid={k['victim']}"
    an = a[1]['name'] if a else f"?eid={k['attacker']}"
    print(f"{k['tag'][:12]:<13} do={str(k['deathOrder']):>4} idx1={k['idx1']} "
          f"{vn[:14]:<15} ← {an[:14]:<15} tail={k['tail']}")

json.dump(kills, open('/tmp/wot/t57_l16.json', 'w'), ensure_ascii=False)
print('\nsaved -> /tmp/wot/t57_l16.json')
