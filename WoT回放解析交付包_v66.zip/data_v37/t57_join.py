#!/usr/bin/env python3
"""t57_join.py — Task 57-b①: idx₁↔eid↔名册 join
通道A: 0x37 语义解码死亡事件 (game, clk, player_idx1, deathOrder) — 76 条
通道B: 0x32 内嵌 deathOrder 击杀链 (tag, clk, seq, victim_eid, attacker_eid) — 220 条
join 键: clk (同回放流时钟域, v24 §20 三通道时钟统一)
产出: player_idx1 → victim_eid → 花名册身份
"""
import json
from collections import defaultdict

d36 = json.load(open('/home/z/my-project/download/data_v36/0x37语义解码样例_t56.json'))
kc = json.load(open('/home/z/my-project/download/data_v22/deathOrder击杀链_220条_十场.json'))
roster = json.load(open('/home/z/my-project/download/data_v32/t51_roster_dump.json'))

# 击杀链按 clk 建索引
kby = sorted(kc, key=lambda e: e['clk'])

# 花名册: eid(avatarSessionID) → 身份
ident = {}
for gk, g in roster.items():
    for p in g['players']:
        # v20: eid == roster.avatarSessionID join (1092/1092)
        ident[str(p.get('avatarSessionID'))] = p
        ident[str(p.get('vehicleID'))] = p

print('=== clk 全局 join: 76 条 0x37 死亡事件 × 220 条击杀链 ===')
exact = 0
rows = []
for ev in d36['death_events']:
    clk = ev['clk']
    best = min(kby, key=lambda e: abs(e['clk'] - clk))
    d = best['clk'] - clk
    rows.append((ev, best, d))
    if d == 0:
        exact += 1
print(f'clk 精确相等: {exact}/{len(rows)}')
near = sum(1 for _,_,d in rows if abs(d) <= 50)
print(f'|Δclk|<=50ms: {near}/{len(rows)}')
print('\nΔ 分布(前 20):')
for ev, best, d in sorted(rows, key=lambda r: abs(r[2]))[:20]:
    v = ident.get(str(best['victim']), {})
    a = ident.get(str(best['attacker']), {})
    print(f"  g{ev['game']} do={ev['deathOrder']:>2} idx1={ev['player_idx1']:>2} clk={ev['clk']} "
          f"↔ tag={best['tag'][:12]:<12} seq={best['seq']:>2} victim={best['victim']} "
          f"({v.get('name','?')[:14]}) Δ={d:+d}ms")

# deathOrder↔seq 一致性(精确匹配集)
print('\n=== 精确匹配集内 deathOrder vs seq ===')
m = [(ev['deathOrder'], best['seq']) for ev, best, d in rows if d == 0]
same = sum(1 for a,b in m if a == b)
print(f'deathOrder==seq: {same}/{len(m)}')
diff = [(a,b) for a,b in m if a != b]
if diff: print('不一致:', diff[:10])
