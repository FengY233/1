#!/usr/bin/env python3
"""t57_join2.py — Task 57-b①: idx₁↔eid↔名册 join（按场对齐版）
1. 从 t55_global3.json 全量重提 op=2 解码消息（L∈{3,4,6,16,26}）——76 条死亡事件全量
2. game→tag 定案映射（语料 sorted 序, g5=tundra 击杀链无）
3. 每场内 clk 最近邻 join 击杀链 → idx₁↔victim_eid
4. eid→花名册身份（avatarSessionID/vehicleID 双键）
5. 一致性校验: 同 idx₁ 是否恒映射同 eid; idx₁ 序 vs 花名册序
"""
import json, re
from collections import defaultdict

D = json.load(open('/tmp/wot/t55_global3.json'))
kc = json.load(open('/home/z/my-project/download/data_v22/deathOrder击杀链_220条_十场.json'))
roster = json.load(open('/home/z/my-project/download/data_v32/t51_roster_dump.json'))

GAME2TAG = {0: 'siegfried_EU_935', 1: 'karelia_EU_935', 2: 'lakeville_EU_935',
            3: 'caucasus_NA_945', 4: 'namerica_CN_942', 5: 'tundra_CN_942',
            6: 'caucasus_CN_942', 7: 'greatwall_EU_944', 8: 'karelia2_EU_944',
            9: 'PTZ_EU_944', 10: 'WZ219_EU_944'}
# 花名册键序 = replay0..replay9 = p05 REPLAYS 序(剔 tundra? 否——roster 是 t51 语料)
# t51_roster_dump 键: replay0_pkg73..replay9_pkg6208 —— 需独立核对, 先建 tag->roster 的 eid 索引
ROSTER_TAG_ORDER = ['siegfried_EU_935', 'karelia_EU_935', 'lakeville_EU_935', 'caucasus_NA_945',
                    'namerica_CN_942', 'caucasus_CN_942', 'greatwall_EU_944', 'karelia2_EU_944',
                    'PTZ_EU_944', 'WZ219_EU_944']  # t51 十场随机战序(与 census 同)


def bits_of(blob):
    out = []
    for byte in blob:
        for k in range(7, -1, -1):
            out.append((byte >> k) & 1)
    return out


def decode_op2(blob):
    bits = bits_of(blob)
    if bits[0] != 1:
        return None
    idx1 = 0
    for i in range(1, 7):
        idx1 = (idx1 << 1) | bits[i]
    if bits[7] != 0:
        return None
    finalIdx = 0
    for i in range(8, 14):
        finalIdx = (finalIdx << 1) | bits[i]
    return idx1, finalIdx, blob[2:]


# 1) 全量重提
msgs = defaultdict(list)  # (game, nid, L) -> [(clk, idx1, finalIdx, val)]
for gi in D:
    for nid, op, L, vh, t, clk in D[gi]['msgs']:
        if isinstance(op, int) and op == 2 and L in (3, 4, 6, 16, 26):
            r = decode_op2(bytes.fromhex(vh))
            if r:
                msgs[(int(gi), nid, L)].append((clk,) + r)

deaths = []  # (game, clk, nid, idx1, deathOrder)
for (gi, nid, L), seq in msgs.items():
    if L != 26:
        continue
    for clk, idx1, fi, val in seq:
        if len(val) >= 2 and val[0] == len(val) - 1 and val[1:3] == b'\x80\x02':
            s = val.decode('latin1')
            m = re.search(r'deathOrder.{0,3}?K(.?)s\.', s, re.S)
            if m:
                deaths.append((gi, clk, nid, idx1, m.group(1).encode('latin1')[0]))
deaths.sort()
print(f'死亡事件全量: {len(deaths)} 条')

# 三联包伴随消息(L=16/L=4)按 (game, nid, idx1) 索引
l16 = defaultdict(list)
l4 = defaultdict(list)
l6 = defaultdict(list)
for (gi, nid, L), seq in msgs.items():
    for clk, idx1, fi, val in seq:
        if L == 16:
            l16[(gi, nid, idx1)].append((clk, val))
        elif L == 4:
            l4[(gi, nid, idx1)].append((clk, val))
        elif L == 6 and len(val) == 4:
            l6[(gi, nid, idx1)].append((clk, int.from_bytes(val, 'little')))

# 2) 击杀链按场分组
ktag = defaultdict(list)
for e in kc:
    ktag[e['tag']].append(e)
for t in ktag:
    ktag[t].sort(key=lambda e: e['clk'])

# 3) 每场 clk 最近邻 join
print('\n=== 每场 join（|Δclk|<=3000ms 视为候选）===')
idx2eid = defaultdict(set)   # (game, idx1) -> {eid}
eid2idx = defaultdict(set)
report = []
for gi, clk, nid, idx1, do in deaths:
    tag = GAME2TAG[gi]
    chain = ktag.get(tag)
    if not chain:
        report.append((gi, clk, nid, idx1, do, None, None, None))
        continue
    best = min(chain, key=lambda e: abs(e['clk'] - clk))
    d = best['clk'] - clk
    if abs(d) <= 3000:
        idx2eid[(gi, idx1)].add(best['victim'])
        eid2idx[(gi, best['victim'])].add(idx1)
        report.append((gi, clk, nid, idx1, do, best, d, None))
    else:
        report.append((gi, clk, nid, idx1, do, best, d, 'FAR'))

ok = [r for r in report if r[5] is not None and r[7] != 'FAR']
print(f'join 命中: {len(ok)}/{len(report)}')
d0 = sum(1 for r in ok if r[6] == 0)
print(f'Δclk=0 精确: {d0}')
from collections import Counter
print('Δ 分布 top10:', Counter(r[6] for r in ok).most_common(10))

# deathOrder vs seq
mism = [(r[4], r[5]['seq'], r[6]) for r in ok if r[4] != r[5]['seq']]
print(f'deathOrder==seq: {len(ok)-len(mism)}/{len(ok)}; 不一致 {len(mism)} 条:')
for do, seq, d in mism[:15]:
    print(f'   do={do} seq={seq} Δ={d:+d}ms')

# 4) idx1↔eid 一致性
print('\n=== idx₁↔eid 映射表 ===')
multi = 0
for (gi, idx1), eids in sorted(idx2eid.items()):
    if len(eids) > 1:
        multi += 1
    tag = GAME2TAG[gi]
    print(f'g{gi}({tag[:10]}) idx1={idx1} -> eid {eids}')
print(f'多 eid 冲突: {multi}')

json.dump({'deaths_total': len(deaths),
           'joined': len(ok),
           'idx2eid': {f'{g}_{i}': list(v) for (g, i), v in idx2eid.items()}},
          open('/tmp/wot/t57_join2.json', 'w'), ensure_ascii=False, indent=1)
print('\nsaved -> /tmp/wot/t57_join2.json')
