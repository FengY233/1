#!/usr/bin/env python3
"""t57_join3.py — Task 57-b① 修正版: 正确分割逻辑 + 同文件 deathOrder↔seq join
背景勘误: t55_global3.json 为旧版分割( msgs 数偏差±1%, flush clk 归属漂移 ),
本轮以当前逻辑重放 11 文件模拟, 提取 L=26 死亡事件(idx1+deathOrder),
与 0x37 追加包击杀链(220 条, 含 victim eid)做 同文件 deathOrder==seq join → idx₁↔eid
"""
import struct, sys, json, glob, re
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load

KC = json.load(open('/home/z/my-project/download/data_v22/deathOrder击杀链_220条_十场.json'))
ROSTER = json.load(open('/home/z/my-project/download/data_v32/t51_roster_dump.json'))
FILES = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TAGS = ['siegfried_EU_935', 'karelia_EU_935', 'lakeville_EU_935', 'caucasus_NA_945',
        'namerica_CN_942', 'tundra_CN_942', 'caucasus_CN_942', 'greatwall_EU_944',
        'karelia2_EU_944', 'PTZ_EU_944', 'WZ219_EU_944']


def bits_of(blob):
    out = []
    for byte in blob:
        for k in range(7, -1, -1):
            out.append((byte >> k) & 1)
    return out


def decode_op2(blob):
    bits = bits_of(blob)
    if bits[0] != 1:
        return None
    idx1 = 0
    for i in range(1, 7):
        idx1 = (idx1 << 1) | bits[i]
    if bits[7] != 0:
        return None
    fi = 0
    for i in range(8, 14):
        fi = (fi << 1) | bits[i]
    return idx1, fi, blob[2:]


def simulate(path):
    blocks, declared, slen, pkts = load(path)
    events = [(t, c, p) for t, c, p in pkts if t in (0x35, 0x36, 0x37)]
    buf = bytearray(); start = 0; msgs = []
    for t, c, p in events:
        if t == 0x37:
            n = struct.unpack_from('<I', p, 0)[0] if len(p) >= 4 else 0
            buf += p[4:4+n]
        elif t == 0x36:
            pos = start
            if pos + 2 > len(buf):
                continue
            nid = struct.unpack_from('>H', buf, pos)[0]
            if pos + 4 <= len(buf) and buf[pos+2] in (0, 1, 2):
                op, L = buf[pos+2], buf[pos+3]
                if L == 0xff:
                    if pos + 7 > len(buf):
                        continue
                    L = int.from_bytes(buf[pos+4:pos+7], 'little'); vstart = pos + 7
                else:
                    vstart = pos + 4
                if vstart + L > len(buf):
                    continue
                msgs.append((nid, op, L, bytes(buf[vstart:vstart+L]), c))
                start = vstart + L
            else:
                msgs.append((nid, None, 0, b'', c))
                start = pos + 2
        else:  # 0x35
            pos = start
            if pos + 2 > len(buf):
                continue
            nid = struct.unpack_from('>H', buf, pos)[0]
            msgs.append((nid, 'c2', 0, b'', c))
            start = pos + 2
    return msgs


# 击杀链按 tag 索引
chain = {}
for e in KC:
    chain.setdefault(e['tag'], []).append(e)
for t in chain:
    chain[t].sort(key=lambda e: e['clk'])

# 花名册: eid -> 身份 (avatarSessionID + vehicleID 双键)
ident = {}
for gk, g in ROSTER.items():
    for p in g['players']:
        ident[str(p.get('avatarSessionID'))] = p
        ident[str(p.get('vehicleID'))] = p

all_deaths = []
print('=== 逐文件: L=26 死亡事件(当前逻辑) vs 击杀链 deathOrder==seq join ===')
for gi, f in enumerate(FILES):
    tag = TAGS[gi]
    msgs = simulate(f)
    deaths = []
    for nid, op, L, vh, c in msgs:
        if isinstance(op, int) and op == 2 and L == 26 and b'deathOrder' in vh:
            r = decode_op2(vh)
            if r:
                idx1, fi, val = r
                m = re.search(rb'deathOrder.{0,3}?K(.)s\.', val, re.S)
                if m:
                    do = m.group(1)[0]
                    deaths.append((c, nid, idx1, do))
    deaths.sort()
    ch = chain.get(tag, [])
    # join: deathOrder == seq
    by_seq = {e['seq']: e for e in ch}
    hit = [(c, nid, idx1, do, by_seq[do]) for c, nid, idx1, do in deaths if do in by_seq]
    all_deaths.append((gi, tag, deaths, ch, hit))
    print(f'g{gi} {tag:<16} 死亡事件={len(deaths)} 链={len(ch)} do==seq命中={len(hit)}')
    for c, nid, idx1, do, e in hit:
        v = ident.get(str(e['victim']), {})
        print(f'   do={do:>2} idx1={idx1} flush_clk={c} ↔ seq={e["seq"]} victim={e["victim"]} '
              f'({v.get("name","?")[:16]}) Δclk={e["clk"]-c:+d}ms')

# 汇总: idx1 -> eid 一致性
idx2eid = {}
conflict = 0
for gi, tag, deaths, ch, hit in all_deaths:
    for c, nid, idx1, do, e in hit:
        k = (gi, idx1)
        if k in idx2eid and idx2eid[k] != e['victim']:
            conflict += 1
        idx2eid[k] = e['victim']
print(f'\nidx₁↔eid 映射条目: {len(idx2eid)}, 冲突: {conflict}')

# idx1 -> roster 序号探测: roster players 序 vs idx1
print('\n=== idx₁ ↔ 花名册序探测 ===')
RKEYS = list(ROSTER.keys())
for gi, tag, deaths, ch, hit in all_deaths:
    if not hit:
        continue
    rk = RKEYS[gi] if gi < len(RKEYS) else None
    players = ROSTER[rk]['players'] if rk else []
    for c, nid, idx1, do, e in hit[:3]:
        v = ident.get(str(e['victim']), {})
        # 在 roster 中的位置
        pos = next((i for i, p in enumerate(players)
                    if str(p.get('avatarSessionID')) == str(e['victim'])
                    or str(p.get('vehicleID')) == str(e['victim'])), None)
        print(f'g{gi} idx1={idx1} (b0=0x{0xC0+2*(idx1-32):02X}) -> roster_pos={pos} '
              f'name={v.get("name","?")[:16]} team={v.get("team")}')

json.dump({'per_game': [{'game': gi, 'tag': tag, 'deaths': [
                {'clk': c, 'nid': nid, 'idx1': i1, 'deathOrder': do} for c, nid, i1, do in deaths],
            'chain_len': len(ch), 'joined': len(hit)} for gi, tag, deaths, ch, hit in all_deaths],
           'idx2eid': {f'{g}_{i}': e for (g, i), e in idx2eid.items()}},
          open('/tmp/wot/t57_join3.json', 'w'), ensure_ascii=False, indent=1)
print('\nsaved -> /tmp/wot/t57_join3.json')
