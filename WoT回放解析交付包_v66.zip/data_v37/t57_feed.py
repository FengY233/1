#!/usr/bin/env python3
"""t57_feed.py — Task 57-b 终版: 全量击杀 feed(带身份) + 队伍校验 + L=6 计数器对照
输入: /tmp/wot/t57_l16.json (86 条 L=16 记录) + roster
验证: ①敌我击杀/队杀 ②deathOrder 单调 ③tail 字段分布 ④L=6 计数器 per-player 对照
"""
import json
from collections import defaultdict, Counter

K = json.load(open('/tmp/wot/t57_l16.json'))
ROSTER = json.load(open('/home/z/my-project/download/data_v32/t51_roster_dump.json'))
RKEYS = sorted(ROSTER.keys(), key=lambda k: int(k.split('_')[0].replace('replay', '')))


def ridx(gi):
    return gi if gi <= 4 else gi - 1


# 每场玩家表 + idx1 映射
tables = {}
for k in K:
    gi = k['game']
    if gi == 5 or gi in tables:
        continue
    players = ROSTER[RKEYS[ridx(gi)]]['players']
    ent = {}
    for i, p in enumerate(players):
        ent[i + 32] = p
    tables[gi] = ent

# 击杀 feed
print('=== 全量击杀 feed(86 条, victim ← attacker) ===')
cross = same = unknown = 0
rows = []
for k in sorted(K, key=lambda x: (x['game'], x['clk'])):
    t = tables.get(k['game'], {})
    v = t.get(k['idx1'])
    # attacker 从 eid 找
    a = None
    if v is not None:
        for idx, p in t.items():
            if str(p.get('avatarSessionID')) == str(k['attacker']) or \
               str(p.get('vehicleID')) == str(k['attacker']):
                a = p
                break
    vn = v['name'] if v else f"idx1={k['idx1']}"
    an = a['name'] if a else f"eid={k['attacker']}"
    vt = v.get('team') if v else None
    at = a.get('team') if a else None
    rel = '敌杀' if (vt and at and vt != at) else ('★队杀' if (vt and at) else '?')
    if vt and at:
        if vt != at:
            cross += 1
        else:
            same += 1
    else:
        unknown += 1
    rows.append((k['tag'][:11], k['deathOrder'], k['idx1'], vn, an, vt, at, rel, k['tail'], k['clk']))

for r in rows:
    print(f"{r[0]:<12} do={str(r[1]):>4} idx1={r[2]:>2} {r[3][:13]:<14}({r[5]}) ← {r[4][:13]:<14}({r[6]}) {r[7]:<3} tail={r[8]}")

print(f'\n敌我击杀: {cross} | 队杀: {same} | 未知: {unknown}')

# tail 5B 分布
print('\n=== tail 5B 分布 ===')
for tail, c in Counter(k['tail'] for k in K).most_common(12):
    print(f'  {tail} ×{c}')

# deathOrder 一致性(有 L=26 伴随的)
withdo = [k for k in K if k['deathOrder'] is not None]
print(f'\n有 deathOrder 伴随: {len(withdo)}/{len(K)}')

# 按 tag 统计 idx1 死亡分布(每场死亡玩家数)
print('\n=== 每场死亡统计 ===')
for tag in sorted(set(k['tag'] for k in K)):
    ks = [k for k in K if k['tag'] == tag]
    dos = sorted(k['deathOrder'] for k in ks if k['deathOrder'])
    print(f'{tag:<16} L16={len(ks):>2} do范围={dos[:3]}..{dos[-3:] if len(dos)>3 else ""}')

json.dump([{'tag': r[0], 'deathOrder': r[1], 'idx1': r[2], 'victim': r[3], 'attacker': r[4],
            'victim_team': r[5], 'attacker_team': r[6], 'relation': r[7], 'tail': r[8],
            'clk': r[9]} for r in rows],
          open('/tmp/wot/t57_feed.json', 'w'), ensure_ascii=False, indent=1)
print('\nsaved -> /tmp/wot/t57_feed.json')
