#!/usr/bin/env python3
"""t57_map.py — Task 57-b① 终验: idx₁ = roster_pos + 32 假说全量验证 + 完整身份映射表
前置: t57_join3 已证 deathOrder==seq join 74/74 零冲突
修正: roster 为 10 场 census 序(tundra 无), 11 文件序→census 序映射 gi>=6 减 1
产出: ①全量 idx₁↔身份映射(每场 30 玩家) ②join 事件 idx1 vs roster_pos 一致性
      ③L=16 记录字段(死者视角) ④attacker→击杀者名
"""
import struct, sys, json, glob, re
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import defaultdict

J = json.load(open('/tmp/wot/t57_join3.json'))
ROSTER = json.load(open('/home/z/my-project/download/data_v32/t51_roster_dump.json'))
FILES = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TAGS = ['siegfried_EU_935', 'karelia_EU_935', 'lakeville_EU_935', 'caucasus_NA_945',
        'namerica_CN_942', 'tundra_CN_942', 'caucasus_CN_942', 'greatwall_EU_944',
        'karelia2_EU_944', 'PTZ_EU_944', 'WZ219_EU_944']

RKEYS = sorted(ROSTER.keys(), key=lambda k: int(k.split('_')[0].replace('replay', '')))
# census 序(10 场, 无 tundra): 文件 idx -> roster idx
def ridx(gi):
    return gi if gi <= 4 else gi - 1

# roster 场次指纹: eid 前缀样本
print('=== roster 场次 eid 空间指纹 ===')
for i, rk in enumerate(RKEYS):
    g = ROSTER[rk]
    ids = [str(p.get('avatarSessionID')) for p in g['players'][:3]]
    print(f'roster{i} {rk}: eid={g["eid"]} avatarSessionID样例={ids}')

# join 事件 idx1 vs roster_pos
print('\n=== join 事件: idx1 vs roster_pos(修正映射) ===')
ok = bad = nomatch = 0
fail_cases = []
for g in J['per_game']:
    gi = g['game']
    if gi == 5:
        continue
    players = ROSTER[RKEYS[ridx(gi)]]['players']
    # eid -> pos
    pos_by_eid = {}
    for i, p in enumerate(players):
        pos_by_eid[str(p.get('avatarSessionID'))] = i
        pos_by_eid[str(p.get('vehicleID'))] = i
    # victim eid -> pos
    for e_v in []: pass
    # 从 idx2eid 找该场映射
    for key, eid in J['idx2eid'].items():
        gg, idx1 = key.rsplit('_', 1)
        if int(gg) != gi:
            continue
        pos = pos_by_eid.get(str(eid))
        if pos is None:
            nomatch += 1
            fail_cases.append((gi, idx1, eid, 'eid不在roster'))
        elif pos + 32 == int(idx1):
            ok += 1
        else:
            bad += 1
            fail_cases.append((gi, idx1, eid, f'pos={pos} 期望idx1={pos+32}'))
print(f'idx1==pos+32: {ok} | 不等: {bad} | eid不匹配roster: {nomatch}')
for fc in fail_cases[:20]:
    print('  ', fc)

# 完整身份映射表: 每场 30 玩家 idx1=32..61 -> roster 身份
print('\n=== 完整身份映射(假说 idx1=32+pos) ===')
out = {}
for gi in range(11):
    if gi == 5:
        continue
    players = ROSTER[RKEYS[ridx(gi)]]['players']
    ent = []
    for pos, p in enumerate(players):
        ent.append({'idx1': 32 + pos, 'b0': 0xC0 + 2 * pos, 'name': p.get('name'),
                    'fakeName': p.get('fakeName'), 'vehicleID': p.get('vehicleID'),
                    'team': p.get('team'), 'accountDBID': p.get('accountDBID'),
                    'maxHealth': p.get('maxHealth')})
    out[TAGS[gi]] = ent
    teams = sum(1 for e in ent if e['team'] == 1)
    print(f'g{gi} {TAGS[gi]:<16} 30 玩家: team1={teams} team2={30-teams} '
          f'idx1=32-61 b0=0xC0-0xFA')

json.dump({'hypothesis': 'idx1 = roster_pos + 32 (b0 = 0xC0 + 2*roster_pos)',
           'verified': {'ok': ok, 'bad': bad, 'nomatch': nomatch},
           'mapping': out},
          open('/tmp/wot/t57_map.json', 'w'), ensure_ascii=False, indent=1)
print('\nsaved -> /tmp/wot/t57_map.json')
