#!/usr/bin/env python3
"""t57_frags.py — 终极交叉验证: frags(fi=33) 增量轨迹 vs 击杀 feed attacker
若一致: 击杀 feed 的 attacker ↔ frags +1 逐事件对齐 → 全链路闭环
"""
import struct, sys, json, glob
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import defaultdict

FILES = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TAGS = ['siegfried', 'karelia', 'lakeville', 'caucasus_NA', 'namerica', 'tundra',
        'caucasus_CN', 'greatwall', 'karelia2', 'PTZ', 'WZ219']
KILLS = json.load(open('/tmp/wot/t57_l16.json'))
ROSTER = json.load(open('/home/z/my-project/download/data_v32/t51_roster_dump.json'))
RKEYS = sorted(ROSTER.keys(), key=lambda k: int(k.split('_')[0].replace('replay', '')))


def ridx(gi):
    return gi if gi <= 4 else gi - 1


def decode_op2(blob):
    if not blob:
        return None
    b0 = blob[0]
    if not (b0 & 0x80) or (b0 & 0x01):
        return None
    idx1 = (b0 >> 1) & 0x3F
    if len(blob) < 2:
        return None
    b1 = blob[1]
    if b1 & 0x03:
        return None
    fi = (b1 >> 2) & 0x3F
    return idx1, fi, blob[2:]


def simulate(path):
    blocks, declared, slen, pkts = load(path)
    events = [(t, c, p) for t, c, p in pkts if t in (0x35, 0x36, 0x37)]
    buf = bytearray(); start = 0; msgs = []
    for t, c, p in events:
        if t == 0x37:
            n = struct.unpack_from('<I', p, 0)[0] if len(p) >= 4 else 0
            buf += p[4:4+n]
        elif t == 0x36:
            pos = start
            if pos + 2 > len(buf):
                continue
            nid = struct.unpack_from('>H', buf, pos)[0]
            if pos + 4 <= len(buf) and buf[pos+2] in (0, 1, 2):
                op, L = buf[pos+2], buf[pos+3]
                if L == 0xff:
                    if pos + 7 > len(buf):
                        continue
                    L = int.from_bytes(buf[pos+4:pos+7], 'little'); vstart = pos + 7
                else:
                    vstart = pos + 4
                if vstart + L > len(buf):
                    continue
                msgs.append((nid, op, L, bytes(buf[vstart:vstart+L]), c))
                start = vstart + L
            else:
                msgs.append((nid, None, 0, b'', c))
                start = pos + 2
        else:
            pos = start
            if pos + 2 > len(buf):
                continue
            nid = struct.unpack_from('>H', buf, pos)[0]
            msgs.append((nid, 'c2', 0, b'', c))
            start = pos + 2
    return msgs


# 1) 每场 frags 轨迹(idx1, clk, value)
frags_traj = defaultdict(list)   # (gi, idx1) -> [(clk, val)]
for gi, f in enumerate(FILES):
    for nid, op, L, vh, c in simulate(f):
        if isinstance(op, int) and op == 2 and L == 4:
            r = decode_op2(vh)
            if r and r[1] == 33 and 32 <= r[0] <= 61 and len(r[2]) == 2:
                frags_traj[(gi, r[0])].append((c, struct.unpack('<h', r[2])[0]))
for k in frags_traj:
    frags_traj[k].sort()

# 2) 击杀 feed: attacker eid -> idx1 (经 roster)
kill_by_attacker = defaultdict(list)  # (gi, attacker_idx1) -> [clk...]
name_by_idx = {}
for k in KILLS:
    gi = k['game']
    if gi == 5:
        continue
    players = ROSTER[RKEYS[ridx(gi)]]['players']
    for i, p in enumerate(players):
        if str(p.get('avatarSessionID')) == str(k['attacker']) or \
           str(p.get('vehicleID')) == str(k['attacker']):
            kill_by_attacker[(gi, 32 + i)].append(k['clk'])
            name_by_idx[(gi, 32 + i)] = p['name']
            break

# 3) 对齐: 每次 kill 后 attacker 的 frags 应 +1
print('=== frags 增量 vs 击杀 feed 对齐 ===')
aligned = mismatched = nofrags = 0
details = []
for (gi, aidx), clks in sorted(kill_by_attacker.items()):
    traj = frags_traj.get((gi, aidx), [])
    if not traj:
        nofrags += len(clks)
        continue
    for ck in clks:
        # frags 轨迹中 ck 之后首个值 vs 之前值
        before = [v for c, v in traj if c <= ck]
        after = [v for c, v in traj if c > ck]
        if not after:
            nofrags += 1
            details.append((gi, aidx, name_by_idx.get((gi, aidx), '?'), ck, '无后续frags'))
            continue
        prev = before[-1] if before else 0
        if after[0] == prev + 1:
            aligned += 1
        else:
            mismatched += 1
            details.append((gi, aidx, name_by_idx.get((gi, aidx), '?'), ck,
                            f'frags {prev}->{after[0]}'))

print(f'击杀→frags+1 对齐: {aligned} | 不匹配: {mismatched} | 无轨迹: {nofrags}')
for d in details[:12]:
    print('  ', d)

# 4) frags 终值 vs 击杀数 per attacker
print('\n=== 每 attacker frags 终值 vs 击杀计数 ===')
ok2 = bad2 = 0
for (gi, aidx), clks in sorted(kill_by_attacker.items()):
    traj = frags_traj.get((gi, aidx), [])
    final = traj[-1][1] if traj else 0
    if final == len(clks):
        ok2 += 1
    else:
        bad2 += 1
        print(f'  g{gi} idx1={aidx} {name_by_idx.get((gi,aidx),"?")[:14]:<15} frags终值={final} 击杀数={len(clks)}')
print(f'frags 终值==击杀数: {ok2} | 不等: {bad2}')
