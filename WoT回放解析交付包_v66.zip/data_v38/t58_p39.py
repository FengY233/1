#!/usr/bin/env python3
"""t58_p39.py — 0x39 复制流结构化全解 + 运动学一致性验证
模型(本轮窗口解剖):
  72B 型: [u32 len=68][06 00 01][8B 场常量][u32 seq_cur][u32 seq_prev]
          [u32 objID(D6C3C4 系)][16B 常量][f32 pos.x][pos.y][pos.z]
          [f32 vel.x][vel.y][vel.z][f32 ?dt/标量][01 20]
  41B 型: [u32 len=37][06 00 01][8B 场常量][u32 seq][u32 seq_prev][u32 objID2]...
验证: ①pos+vel×Δt≈pos_next ②轨迹连续性与地图域 ③Δclk 分布 ④seq 链
"""
import sys, struct, glob, json
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter, defaultdict
import math

FILES = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TAGS = ['siegfried', 'karelia', 'lakeville', 'caucasus_NA', 'namerica', 'tundra',
        'caucasus_CN', 'greatwall', 'karelia2', 'PTZ', 'WZ219']


def parse72(p):
    """72B 载荷: [u32 68][inner 68B]"""
    inner = p[4:]
    assert len(inner) == 68
    seq_cur, seq_prev = struct.unpack_from('<II', inner, 11)
    objid = struct.unpack_from('<I', inner, 19)[0]
    # f32 ×7 @ 38..65 (inner 偏移: 3+8+4+4+4=23 → 常量 16B → 39? 用绝对偏移重推)
    # 载荷偏移: 4(头)+3+8+8+4+16 = 43 起? 直接全扫 f32 域
    fx = []
    for off in range(38, 66, 4):
        fx.append(struct.unpack_from('<f', inner, off)[0])
    return dict(seq=seq_cur, seq_prev=seq_prev, objid=objid, f=fx,
                const8=inner[3:11].hex(), mid=inner[23:39].hex())


def main():
    out = {}
    for gi, f in enumerate(FILES):
        blocks, declared, slen, pkts = load(f)
        p39 = [(c, p) for t, c, p in pkts if t == 0x39]
        if not p39:
            continue
        n72 = [(c, p) for c, p in p39 if len(p) == 72]
        n41 = [(c, p) for c, p in p39 if len(p) == 41]
        other = len(p39) - len(n72) - len(n41)
        # 72B 全解析
        recs = []
        for c, p in n72:
            inner = p[4:]
            seq_cur, seq_prev = struct.unpack_from('<II', inner, 11)
            objid = struct.unpack_from('<I', inner, 19)[0]
            fs = [struct.unpack_from('<f', inner, o)[0] for o in range(38, 66, 4)]
            recs.append((c, seq_cur, seq_prev, objid, fs))
        # f32 槽位统计: 哪三个是 pos(有界±1000) 哪三个是 vel
        med = [sorted(r[4][k] for r in recs)[len(recs)//2] for k in range(7)]
        rng = [(min(r[4][k] for r in recs), max(r[4][k] for r in recs)) for k in range(7)]
        # Δclk 分布
        dclk = [b[0]-a[0] for a, b in zip(recs, recs[1:])]
        dclk.sort()
        # 运动学一致性: 假设 f0-f2=pos, f3-f5=vel → (pos_{i+1}-pos_i) vs vel_i×Δt
        good = bad = 0
        errs = []
        for a, b in zip(recs, recs[1:]):
            dt = (b[0] - a[0]) / 1000.0
            if dt <= 0 or dt > 60:
                continue
            dp = [b[4][k] - a[4][k] for k in range(3)]
            pred = [a[4][3+k] * dt for k in range(3)]
            e = math.dist(dp, pred)
            sp = math.sqrt(sum(v*v for v in a[4][3:6]))
            errs.append((e, sp, dt))
            if e < 25.0:
                good += 1
            else:
                bad += 1
        # vel 模分布
        speeds = sorted(set(round(math.sqrt(sum(r[4][k]**2 for k in range(3, 6))), 1) for r in recs))
        # objid 与 const
        objids = Counter(hex(r[3]) for r in recs)
        consts = Counter(r if False else 'x' for r in [])
        c8 = Counter()
        for c, p in n72:
            c8[p[7:15].hex()] += 1
        # 41B 型头
        h41 = Counter()
        for c, p in n41:
            h41[struct.unpack_from('<I', p, 23)[0:1] .hex() if False else p[23:27].hex()] += 1
        print(f'=== {TAGS[gi]}: 0x39×{len(p39)} (72B:{len(n72)} 41B:{len(n41)} 其他:{other}) ===')
        print(f'  场常量8B: {dict(c8)} | objID: {dict(objids)}')
        print(f'  41B 型 objID2: {dict(h41)}')
        print(f'  f32 槽中位: {[round(m,2) for m in med]}')
        print(f'  f32 槽范围: {[(round(a,1), round(b,1)) for a, b in rng]}')
        print(f'  Δclk: p10={dclk[len(dclk)//10]} p50={dclk[len(dclk)//2]} p90={dclk[len(dclk)*9//10]} ms')
        print(f'  运动学 pos+vel×Δt 误差<25m: {good} | ≥25m: {bad} (总 {good+bad})')
        if errs:
            es = sorted(e for e, s, d in errs)
            print(f'  误差分位: p50={es[len(es)//2]:.1f}m p90={es[len(es)*9//10]:.1f}m')
        print(f'  速度模唯一值(圆整): {speeds[:12]}')
        out[TAGS[gi]] = {'n': len(p39), 'n72': len(n72), 'n41': len(n41),
                         'const8': dict(c8), 'objid': dict(objids),
                         'f32_median': med, 'f32_range': rng,
                         'kinematics_good': good, 'kinematics_bad': bad,
                         'speeds': speeds[:20]}
    json.dump(out, open('/tmp/wot/t58_p39.json', 'w'), ensure_ascii=False, indent=1)
    print('\nsaved -> /tmp/wot/t58_p39.json')


if __name__ == '__main__':
    main()
