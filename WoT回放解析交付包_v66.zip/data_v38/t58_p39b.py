#!/usr/bin/env python3
"""t58_p39b.py — 0x39 双链分离 + 速度单位/方向终判
步骤: ①seq 链分离(cur==prev_next 关系) ②链内 Δt ③dp/dt vs f3-f5(含缩放搜索)
     ④slot6 语义 ⑤轨迹重建(地图域) ⑥与 0x0A 本车轨迹起点比对
"""
import sys, struct, glob, json, math
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter, defaultdict

FILES = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TAGS = ['siegfried', 'karelia', 'lakeville', 'caucasus_NA', 'namerica', 'tundra',
        'caucasus_CN', 'greatwall', 'karelia2', 'PTZ', 'WZ219']


def chains(recs):
    """按 seq 衔接分链: recs = [(clk, seq, prev, fs)] 按 seq 值索引"""
    byseq = {r[1]: r for r in recs}
    used = set()
    out = []
    for r in sorted(recs, key=lambda x: x[0]):
        if r[1] in used:
            continue
        chain = []
        cur = r
        while cur is not None and cur[1] not in used:
            used.add(cur[1])
            chain.append(cur)
            cur = byseq.get(cur[2])  # prev 指向链上前驱
        out.append(chain)
    return out


for gi, f in enumerate(FILES):
    blocks, declared, slen, pkts = load(f)
    p39 = [(c, p) for t, c, p in pkts if t == 0x39 and len(p) == 72]
    if not p39:
        continue
    recs = []
    for c, p in p39:
        inner = p[4:]
        seq, prev = struct.unpack_from('<II', inner, 11)
        fs = [struct.unpack_from('<f', inner, o)[0] for o in range(38, 66, 4)]
        recs.append((c, seq, prev, fs))
    chs = chains(recs)
    chs.sort(key=len, reverse=True)
    print(f'=== {TAGS[gi]}: 72B×{len(recs)} → {len(chs)} 链 (长度 top: {[len(c) for c in chs[:6]]}) ===')
    for ci, ch in enumerate(chs[:3]):
        # 链内时间序
        ch.sort(key=lambda r: r[0])
        dts = [b[0]-a[0] for a, b in zip(ch, ch[1:])]
        # 缩放搜索: dp/dt = k × f[3:6]?
        best = None
        for k in (1, 0.1, 0.01, 0.001):
            errs = []
            dirs = []
            for a, b in zip(ch, ch[1:]):
                dt = (b[0]-a[0])/1000.0
                if dt <= 0 or dt > 30:
                    continue
                dp = [(b[3][j]-a[3][j])/dt for j in range(3)]
                v = [a[3][3+j]*k for j in range(3)]
                errs.append(math.dist(dp, v))
                na = math.sqrt(sum(x*x for x in dp)); nb = math.sqrt(sum(x*x for x in v))
                if na > 1e-6 and nb > 1e-6:
                    dot = sum(x*y for x, y in zip(dp, v))/(na*nb)
                    dirs.append(dot)
            if not errs:
                continue
            med = sorted(errs)[len(errs)//2]
            if best is None or med < best[1]:
                best = (k, med, sorted(dirs)[len(dirs)//2] if dirs else 0)
        dmed = sorted(dts)[len(dts)//2] if dts else 0
        print(f'  链{ci}: n={len(ch)} Δt中位={dmed}ms '
              f'最佳缩放k={best[0]} 速度误差中位={best[1]:.2f}(单位/s) 方向cos中位={best[2]:.3f}')
        # slot6 分布
        s6 = sorted(r[3][6] for r in ch)
        print(f'    slot6: [{s6[0]:.4f}, {s6[-1]:.4f}] 中位={s6[len(s6)//2]:.4f}')
        # 轨迹域
        xs = [r[3][0] for r in ch]; ys = [r[3][1] for r in ch]; zs = [r[3][2] for r in ch]
        print(f'    轨迹域 x[{min(xs):.0f},{max(xs):.0f}] y[{min(ys):.0f},{max(ys):.0f}] z[{min(zs):.0f},{max(zs):.0f}]')
        # 速度模段结构
        sps = []
        for r in ch:
            sps.append(round(math.sqrt(sum(v*v for v in r[3][3:6])), 0))
        seg = []
        for s in sps:
            if not seg or seg[-1][0] != s:
                seg.append([s, 1])
            else:
                seg[-1][1] += 1
        print(f'    速度段(模,包数): {seg[:14]}')
