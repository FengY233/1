#!/usr/bin/env python3
"""t50_hex.py — 失败样本逐字节注解 dump: 验证 rk0 创建体=层级数组假说"""
import sys, glob, struct, json
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load

REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TUNDRA = [f for f in REPLAYS if 'tundra' in f][0]
RND = [f for f in REPLAYS if f != TUNDRA]

def read_len(b, p):
    l = b[p]; p += 1
    if l == 0xff:
        l = b[p] | (b[p+1] << 8) | (b[p+2] << 16); p += 3
    return l, p

def try_hier(b, p, n):
    """尝试在 p 处解析层级数组 [u8 m][m×[len][name][u32 nid]]; 返回结束偏移或 None"""
    if p >= n: return None
    m = b[p]
    if m > 30: return None
    q = p + 1
    for _ in range(m):
        if q >= n: return None
        ln, q2 = read_len(b, q)
        if ln > 40 or q2 + ln + 4 > n: return None
        q = q2 + ln + 4
    return q

def dump(idx, b, notes=None):
    n = len(b)
    notes = notes or {}
    print(f'===== 包#{idx} len={n} =====')
    for j in range(0, n, 16):
        ch = b[j:j+16]
        line = ' '.join(f'{x:02x}' for x in ch).ljust(48)
        ann = ' '.join(f'@{j+k}:{notes[j+k]}' for k in range(16) if j+k in notes)
        print(f'{j:4d}: {line} {ann}')
    print()

pkgs = []
for f in RND:
    blocks, declared, slen, pkts = load(f)
    for t, c, pl in pkts:
        if t == 0x32: pkgs.append(pl[4:])

# 样本选择: 覆盖 rk0-body 卡死 / tid51 / tid112 / 大包
for idx in (15, 6, 118, 48):
    b = pkgs[idx]
    n = len(b)
    # 自动注解: 每个偏移尝试层级数组
    notes = {}
    for p in range(n):
        e = try_hier(b, p, n)
        if e is not None:
            m = b[p]
            # 提取槽名
            q = p + 1; names = []
            for _ in range(m):
                ln, q2 = read_len(b, q)
                nm = b[q2:q2+ln].decode('latin1')
                nid = struct.unpack('<I', b[q2+ln:q2+ln+4])[0]
                names.append(f'{nm}={nid}')
                q = q2 + ln + 4
            notes[p] = f'HEIR[{m}]: ' + ','.join(names[:6]) + ('...' if m > 6 else '')
    dump(idx, b, notes)
