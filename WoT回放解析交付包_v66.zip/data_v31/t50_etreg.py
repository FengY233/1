#!/usr/bin/env python3
"""t50_etreg.py — 扫描 .text 对 EntityType 注册表 (0x14483E000/8) 的全部引用 + 反汇编上下文"""
import pefile, struct
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()
md = Cs(CS_ARCH_X86, CS_MODE_64); md.detail = True

TEXT_VA = 0x140001000
TEXT_END = 0x140001000 + 0x35b352c
TEXT_OFF = 0x400

TARGETS = {0x14483E000, 0x14483E008}

# 扫描所有 4 字节窗口: 假设它是 rip 相对 disp32, 指令结束于 窗口末
hits = []
text = data[TEXT_OFF:TEXT_OFF + (TEXT_END - TEXT_VA)]
for i in range(len(text) - 4):
    disp = struct.unpack('<i', text[i:i+4])[0]
    va_after = TEXT_VA + i + 4
    tgt = va_after + disp
    if tgt in TARGETS:
        # 回退找指令开头: 常见 7 字节 (48 8b/89/8d 05) 或 8 字节
        for back in (3, 4, 2, 5):
            start_va = TEXT_VA + i - back
            # 验证: 反汇编从 start_va 开始 1 条指令, 检查是否 rip 相对且目标是 TARGETS
            o = start_va - TEXT_VA + TEXT_OFF
            for ins in md.disasm(data[o:o+16], start_va):
                if ins.address <= TEXT_VA + i < ins.address + ins.size:
                    # 确认窗口在指令内 且 指令有 rip 相对操作数
                    opnd = ins.op_str
                    if 'rip' in opnd:
                        # 计算实际目标
                        import re
                        m = re.search(r'rip ([+-]) (0x[0-9a-f]+)', opnd)
                        if m:
                            d = int(m.group(2), 16)
                            if m.group(1) == '-': d = -d
                            real_tgt = ins.address + ins.size + d
                            if real_tgt in TARGETS:
                                hits.append((start_va, ins.mnemonic, opnd))
                break
        # 也试 lea 48 8d 0d 等 (rcx)
print(f'引用数: {len(hits)}')
for va, mn, op in hits:
    print(f'  {hex(va)}: {mn} {op}')

# 反汇编每个引用点上下文 (前 5 条后 25 条)
print()
for va, mn, op in hits[:6]:
    print(f'\n{"="*70}\n===== 上下文 @{hex(va)} =====')
    o = va - TEXT_VA + TEXT_OFF
    # 回退 ~80 字节找函数感觉, 直接反汇编 200 字节
    for ins in md.disasm(data[o:o+260], va):
        print(f'  {ins.address:#x}: {ins.mnemonic:8s} {ins.op_str}')
        if ins.mnemonic == 'ret': break
