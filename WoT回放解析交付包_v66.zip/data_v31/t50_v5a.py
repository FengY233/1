#!/usr/bin/env python3
"""t50_vlen.py — 焦点 tid 属性值长度暴力测定: 对失败包的 tid 节点, 枚举 prop0 值长度,
用 v4 文法继续解析, 统计能零剩余跑完包的长度直方图 → 揭示真实值格式"""
import sys, glob, struct, json
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter, defaultdict

REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TUNDRA = [f for f in REPLAYS if 'tundra' in f][0]
RND = [f for f in REPLAYS if f != TUNDRA]

def read_len(b, p):
    l = b[p]; p += 1
    if l == 0xff:
        l = b[p] | (b[p+1] << 8) | (b[p+2] << 16); p += 3
    return l, p

def clist(b, p, base, n):
    vals, flags, v = [], set(), base
    while True:
        if p >= n: return None
        c = struct.unpack('b', b[p:p+1])[0]; p += 1
        if c == 0: return vals, flags, p
        elif c == -0x80:
            if p + 2 > n: return None
            v = struct.unpack('>H', b[p:p+2])[0]; p += 2; vals.append(v)
        elif c == -0x7f: vals.append(0)
        elif c == -0x7e:
            nmask = (len(vals) + 7) >> 3
            if p + nmask > n: return None
            mask = b[p:p+nmask]; p += nmask
            for i in range(nmask * 8):
                if mask[i >> 3] & (1 << (i & 7)): flags.add(i)
            return vals, flags, p
        elif 1 <= c <= 0x7f:
            v += c; vals.append(v)
        else:
            for _ in range(c + 126):
                v += 1; vals.append(v)

FMTLEN = {'u8': 1, 'u16': 2, 'u32': 4, 'f32': 4, 'f64': 8, 'v3': 12, 'v4': 16}

def make_parser(known_tids=frozenset(), maxvisit=200000):
    def parse_stream(stream):
        b = stream; n = len(b)
        if n < 2: return None
        visit = [0]
        nodes = {}
        # prop 值格式候选: 标准 + ARRAY 族 + 自由长度(焦点tid)
        def step(p, depth):
            if p >= n: return ('done', p)
            if n - p <= 2: return ('tail', p)
            if p + 3 > n: return None
            mcls = b[p]; mid = (b[p+1] << 8) | b[p+2]; q = p + 3
            if mcls > 6: return None
            visit[0] += 1
            if visit[0] > maxvisit: return None
            return dispatch(q, mcls, mid, depth + 1)
        def val_cands(p):
            out = []
            rem = n - p
            if rem <= 0: return out
            for L, f in ((4, 'u32'), (1, 'u8'), (2, 'u16'), (4, 'f32'), (8, 'f64'), (12, 'v3'), (16, 'v4')):
                if L <= rem: out.append((p + L, f))
            l = b[p]
            hdr = 4 if l == 0xff else 1
            if l == 0xff and rem >= 4:
                l = b[p+1] | (b[p+2] << 8) | (b[p+3] << 16)
            if hdr + l <= rem and l <= 200: out.append((p + hdr + l, 'str'))
            if rem >= 2 and b[p] in (2, 4, 6, 8):
                l2 = b[p+1]
                if 2 + l2 <= rem and l2 <= 200: out.append((p + 2 + l2, 'tagstr'))
                q = p + 2 + l2
                stops = []
                for qq in range(q, min(n - 3, q + 64) + 1):
                    if b[qq] == 0x02:
                        t = b[qq+1] | (b[qq+2] << 8)
                        if t in known_tids or t <= 160:
                            stops.append(qq)
                            if len(stops) >= 5: break
                if not stops: stops = [q]
                for s in stops: out.append((s, 't127'))
            if b[p] <= 12:
                m = b[p]; q = p + 1; ok = True
                for _ in range(m):
                    if q >= n: ok = False; break
                    ln, q2 = read_len(b, q)
                    if q2 + ln + 4 > n: ok = False; break
                    q = q2 + ln + 4
                if ok: out.append((q, 'hier'))
            # ★ ARRAY 族: [packedInt n][n×elem]
            cnt0 = b[p]
            if cnt0 <= 40:
                for esz, ef in ((4, 'arrf'), (1, 'arr8'), (2, 'arr16'), (12, 'arrv3'), (8, 'arr64')):
                    e = p + 1 + cnt0 * esz
                    if e <= n: out.append((e, ef))
            return out
        def rk2_creates(p, nid, depth):
            if p + 2 > n: return
            tid = b[p] | (b[p+1] << 8)
            if tid > 400: return
            l, p2 = read_len(b, p + 2)
            if p2 + l > n: return
            p3 = p2 + l
            r = clist(b, p3, nid, n)
            if r is None: return
            vals, flags, p4 = r
            nv = len(vals)
            cnt = [0]
            def gen_props(pp, i, np_, acc):
                if i == np_:
                    yield pp, tuple(acc); return
                if i in flags:
                    for e, fmt in val_cands(pp):
                        if e is None: continue
                        acc.append(fmt)
                        yield from gen_props(e, i + 1, np_, acc)
                        acc.pop()
                else:
                    yield from gen_props(pp, i + 1, np_, acc)
            for np_ in range(0, min(nv, 9)):
                if np_ > nv - 1: break
                for pp, fmts in gen_props(p4, 0, np_, []):
                    q = pp; ok = True
                    for j in range(np_, nv - 1):
                        if q >= n: ok = False; break
                        ln, q2 = read_len(b, q)
                        if q2 + ln > n: ok = False; break
                        q = q2 + ln
                    if not ok or q > n: continue
                    cnt[0] += 1
                    if cnt[0] > 300: return
                    yield q
                    if q < n and b[q] <= 6:
                        for e in create_bodies(q + 1, b[q], vals[-1], depth + 1):
                            if e is not None and e > q:
                                yield e
        def create_bodies(p, rk, nid, depth):
            if depth > 40: return
            if rk in (0, 6): yield p
            elif rk == 1:
                if p + 4 <= n: yield p + 4
            elif rk == 2:
                yield from rk2_creates(p, nid, depth)
            elif rk == 3:
                for L in (1, 2, 4, 8, 12, 16):
                    if p + L <= n: yield p + L
                if p < n:
                    l, q = read_len(b, p)
                    if q + l <= n and l <= 200: yield q + l
            elif rk == 4:
                if p + 1 > n: return
                kind = b[p]
                if kind <= 1:
                    l, q2 = read_len(b, p + 1)
                    if q2 + l <= n: yield q2 + l
                else:
                    for L in (1, 2, 4, 8):
                        if p + L <= n: yield p + L
            elif rk == 5:
                if p >= n: return
                l, q2 = read_len(b, p)
                if q2 + l <= n: yield q2 + l
        def dispatch(p, mcls, mid, depth):
            if depth > 60: return None
            if mcls == 0:
                if p + 3 > n: return None
                objId = (b[p] << 8) | b[p+1]; rk = b[p+2]
                if rk > 6: return None
                nodes[objId] = rk
                for e in create_bodies(p + 3, rk, objId, depth):
                    r = step(e, depth)
                    if r is not None: return r
                return None
            elif mcls == 1:
                r = clist(b, p, mid, n)
                if r is None: return None
                vals, flags, q = r
                def rec(i, q2):
                    if i == len(vals):
                        return step(q2, depth)
                    if q2 + 1 > n: return None
                    rk = b[q2]
                    if rk > 6: return None
                    nodes[vals[i]] = rk
                    for e in create_bodies(q2 + 1, rk, vals[i], depth + 1):
                        r2 = rec(i + 1, e)
                        if r2 is not None: return r2
                    return None
                return rec(0, q)
            elif mcls in (2, 3, 5):
                return step(p, depth)
            elif mcls in (4, 6):
                rk = nodes.get(mid)
                if rk is None: return None
                if rk in (1, 2, 6): return step(p, depth)
                if rk == 3:
                    for L in (0, 1, 2, 4, 8, 12, 16):
                        if p + L <= n:
                            r = step(p + L, depth)
                            if r is not None: return r
                    if p < n:
                        l, q = read_len(b, p)
                        if q + l <= n and l <= 200:
                            return step(q + l, depth)
                    return None
                if rk == 4:
                    if p + 1 > n: return None
                    kind = b[p]
                    if kind <= 1:
                        l, q2 = read_len(b, p + 1)
                        if q2 + l > n: return None
                        return step(q2 + l, depth)
                    for L in (1, 2, 4, 8):
                        if p + L <= n:
                            r = step(p + L, depth)
                            if r is not None: return r
                    return None
                if rk == 0:
                    r = clist(b, p, mid, n)
                    if r is None: return None
                    vals, flags, q = r
                    nw = (len(vals) + 31) >> 5
                    if q + nw * 4 <= n:
                        r2 = step(q + nw * 4, depth)
                        if r2 is not None: return r2
                    return step(q, depth)
                return None
            return None
        mid0 = (b[0] << 8) | b[1]
        return dispatch(2, 0, mid0, 0)
    return parse_stream

if __name__ == '__main__':
    pkgs = []
    for f in RND:
        blocks, declared, slen, pkts = load(f)
        for t, c, pl in pkts:
            if t == 0x32: pkgs.append(pl[4:])
    print(f'0x32 包总数: {len(pkgs)}')
    fails = json.load(open('/tmp/wot/t49_fails2.json'))
    known = set()
    for s in pkgs[:800]:
        for i in range(len(s) - 3):
            if s[i] == 0x02 and s[i+1] < 0xA0:
                known.add(s[i+1] | (s[i+2] << 8))
    known = {t for t in known if t <= 300}
    p1 = make_parser(known)
    import time; t0 = time.time()
    ok = 0; fails2 = []
    for idx, s in enumerate(pkgs):
        r = p1(s)
        if r is not None: ok += 1
        else: fails2.append(idx)
    print(f'v5a(ARRAY族): {ok}/{len(pkgs)} ({100*ok/len(pkgs):.1f}%) 耗时{time.time()-t0:.0f}s')
    print(f'失败 {len(fails2)}: {fails2[:20]}')
    json.dump(fails2, open('/tmp/wot/t50_fails_a.json', 'w'))
    # 对比: v4 失败但 v5a 成功的包
    fixed = set(fails) - set(fails2)
    print(f'\nv4 失败→v5a 修复: {len(fixed)} 包: {sorted(fixed)[:20]}')
