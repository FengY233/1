#!/usr/bin/env python3
"""t50_v5final.py — 解码器 v5 终版(两遍制):
Pass1: 严格候选(标准 DataType + ARRAY 族) → 98.6%
Pass2: 仅对 Pass1 失败包追加自由长度(1..48)候选 → 99.5%+
产出: 全量结果 + 剩余失败清单 + per-tid 值格式统计"""
import sys, glob, struct, json, time
sys.path.insert(0, '/home/z/my-project/scripts')
from t50_v5a import make_parser as make_strict
from t50_free import make_free_parser
from survey_new_replays import load
from t50_v5a import RND
from collections import Counter, defaultdict

pkgs = []
for f in RND:
    blocks, declared, slen, pkts = load(f)
    for t, c, pl in pkts:
        if t == 0x32: pkgs.append(pl[4:])

known = set()
for s in pkgs[:800]:
    for i in range(len(s) - 3):
        if s[i] == 0x02 and s[i+1] < 0xA0:
            known.add(s[i+1] | (s[i+2] << 8))
known = {t for t in known if t <= 300}

t0 = time.time()
strict = make_strict(known)
ok1 = 0; fails1 = []
for idx, s in enumerate(pkgs):
    r = strict(s)
    if r is not None: ok1 += 1
    else: fails1.append(idx)
print(f'Pass1(严格): {ok1}/{len(pkgs)} ({100*ok1/len(pkgs):.2f}%) 耗时{time.time()-t0:.0f}s')

t1 = time.time()
free = make_free_parser(known)
ok2 = 0; fails2 = []; fmt_used = Counter()
for idx in fails1:
    r, stats = free(pkgs[idx])
    if r is not None:
        ok2 += 1
        for tid, L, pos in stats:
            if tid is not None: fmt_used[tid] += 1
    else:
        fails2.append(idx)
total = ok1 + ok2
print(f'Pass2(自由): +{ok2} → 总 {total}/{len(pkgs)} ({100*total/len(pkgs):.2f}%) 耗时{time.time()-t1:.0f}s')
print(f'剩余失败 {len(fails2)}: {fails2}')
print(f'\nPass2 中自由长度参与的 tid: {dict(fmt_used.most_common(20))}')

json.dump({'pass1_ok': ok1, 'pass2_fixed': ok2, 'total': total, 'n': len(pkgs),
           'fails_final': fails2}, open('/tmp/wot/t50_v5_result.json', 'w'))

# 剩余失败定性: 首消息 id 族
fam = Counter()
for idx in fails2:
    b = pkgs[idx]
    fam[(b[0] << 8) | b[1]] += 1
print(f'\n剩余失败首 id 族: {dict(fam.most_common(15))}')
