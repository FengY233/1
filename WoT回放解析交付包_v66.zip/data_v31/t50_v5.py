#!/usr/bin/env python3
"""t50_v5.py — 解码器 v5 终版: v4 + ARRAY 族 + 自由长度兜底(1..48)
+ 失败包的跨包节点引用分析"""
import sys, glob, struct, json, time
sys.path.insert(0, '/home/z/my-project/scripts')
from t50_free import make_free_parser
from survey_new_replays import load
from t50_v5a import RND
from collections import Counter

pkgs = []
for f in RND:
    blocks, declared, slen, pkts = load(f)
    for t, c, pl in pkts:
        if t == 0x32: pkgs.append(pl[4:])

known = set()
for s in pkgs[:800]:
    for i in range(len(s) - 3):
        if s[i] == 0x02 and s[i+1] < 0xA0:
            known.add(s[i+1] | (s[i+2] << 8))
known = {t for t in known if t <= 300}

fp = make_free_parser(known)
t0 = time.time()
ok = 0; fails = []; kinds = Counter()
for idx, s in enumerate(pkgs):
    r, stats = fp(s)
    if r is not None: ok += 1; kinds[r[0]] += 1
    else: fails.append(idx)
print(f'v5: {ok}/{len(pkgs)} ({100*ok/len(pkgs):.2f}%) {dict(kinds)} 耗时{time.time()-t0:.0f}s')
print(f'失败 {len(fails)}: {fails}')
json.dump(fails, open('/tmp/wot/t50_fails_final.json', 'w'))

# 剩余失败分析: 首消息 id + 卡点模式
print('\n剩余失败包首消息与特征:')
for idx in fails[:10]:
    b = pkgs[idx]
    mid0 = (b[0] << 8) | b[1]
    print(f'  包#{idx} len={len(b)} 首id={mid0}(0x{mid0:04x}) 前24B: {b[:24].hex()}')
