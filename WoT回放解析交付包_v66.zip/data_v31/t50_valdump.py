#!/usr/bin/env python3
"""t50_valdump.py — dump 焦点 tid 的获胜 prop0 值字节 → 确定变换记录真实格式"""
import sys, glob, struct, json
sys.path.insert(0, '/home/z/my-project/scripts')
from t50_free import make_free_parser
from survey_new_replays import load
from collections import defaultdict

pkgs = []
for f in __import__('t50_v5a').RND:
    blocks, declared, slen, pkts = load(f)
    for t, c, pl in pkts:
        if t == 0x32: pkgs.append(pl[4:])

fails = json.load(open('/tmp/wot/t50_fails_a.json'))
known = set()
for s in pkgs[:800]:
    for i in range(len(s) - 3):
        if s[i] == 0x02 and s[i+1] < 0xA0:
            known.add(s[i+1] | (s[i+2] << 8))
known = {t for t in known if t <= 300}

fp = make_free_parser(known)
FOCUS = {171, 172, 173, 174, 100, 101, 102, 103, 135, 151, 70, 157}
samples = defaultdict(list)
for idx in fails:
    s = pkgs[idx]
    r, stats = fp(s)
    if r is not None:
        for tid, L, pos in stats:
            if tid in FOCUS and len(samples[(tid, L)]) < 4:
                samples[(tid, L)].append((idx, s[pos:pos+L].hex()))
for (tid, L) in sorted(samples):
    print(f'tid={tid} len={L}:')
    for idx, h in samples[(tid, L)]:
        print(f'   包#{idx}: {h}')
