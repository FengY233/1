#!/usr/bin/env python3
"""t55_values.py — op=2 嵌套值的字节角色统计 + nid 0x8f1 时间序列分析
目标: 判定 [X][1c][Z] / [X][98][Z][00 00 00] 中哪个字节承载变换值
"""
import json, struct
from collections import Counter, defaultdict

d = json.load(open('/tmp/wot/t55_global3.json'))

# 全语料 op=2 按 L 分层的字节位置方差分析
pos_vals = defaultdict(lambda: defaultdict(Counter))
for gi in d:
    for nid, op, L, valhex, t, clk in d[gi]['msgs']:
        if op == 2 and isinstance(op, int):
            b = bytes.fromhex(valhex)
            for i, x in enumerate(b):
                pos_vals[L][i][x] += 1

print('=== op=2 值的字节分布(按 L) ===')
for L in sorted(pos_vals):
    print(f'L={L} ({sum(pos_vals[L][0].values())} 条):')
    for i in sorted(pos_vals[L]):
        c = pos_vals[L][i]
        uniq = len(c)
        top = c.most_common(4)
        print(f'  字节{i}: 唯一值{uniq} TOP4={[ (hex(k),v) for k,v in top ]}')

# nid 0x8f1 (game 0) 时间序列: 值随 clk 的变化
print('\n=== game0 nid=0x8f1 时间序列(前 40 条) ===')
seq = [(clk, op, L, valhex) for nid, op, L, valhex, t, clk in d['0']['msgs'] if nid == 0x8f1]
prev_clk = None
for clk, op, L, valhex in seq[:40]:
    b = bytes.fromhex(valhex)
    print(f'  clk={clk} op={op} L={L}: {valhex}  (b0={b[0]} b1={b[1]} b2={b[2]})')

# clk 差分(采样率)
clks = [c for c, o, l, v in seq if o == 2 and l == 3]
diffs = [b-a for a, b in zip(clks, clks[1:])][:20]
print(f'\nL=3 消息 clk 差分: {diffs}')

# nid 0x8f1 的 b0 值全序列(平滑性检验)
b0s = [bytes.fromhex(v)[0] for c, o, l, v in seq if o == 2 and l == 3]
jumps = [abs(b-a) for a, b in zip(b0s, b0s[1:])]
print(f'b0 序列(前30): {b0s[:30]}')
print(f'b0 相邻差: min={min(jumps)} max={max(jumps)} 均值={sum(jumps)/len(jumps):.1f}')
