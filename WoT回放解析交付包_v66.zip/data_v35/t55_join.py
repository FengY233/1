#!/usr/bin/env python3
"""t55_join.py — 按场 join: 0x37 高频 nid ↔ 0x32 节点表(nd 事件 rk)
目的: 确定 0x37 更新的节点类(regKey 0-6) → 对应 vt[0x60] 读取器
"""
import json, struct, sys, glob
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter, defaultdict

# 1) 每场 0x37 nid 频率(用全局缓冲+flush 分割, 收集 op/L)
game_nids = {}   # gi -> Counter(nid)
game_msgs = {}   # gi -> list[(nid, op, L, val)]
files = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
for gi, f in enumerate(files):
    blocks, declared, slen, pkts = load(f)
    events = [(t, p) for t, c, p in pkts if t in (0x35, 0x36, 0x37)]
    msgs = []
    i = 0
    while i < len(events):
        t, p = events[i]
        if t != 0x37:
            i += 1; continue
        n = struct.unpack_from('<I', p, 0)[0] if len(p) >= 4 else 0
        blob = p[4:4+n]
        j = i + 1
        flushes = []
        while j < len(events) and events[j][0] in (0x35, 0x36):
            flushes.append(events[j][0]); j += 1
        # 分割(blob 可与相邻 blob 连续 — 暂按本blob分割, 失败记残差)
        pos = 0
        for fl in flushes:
            if pos + 4 > len(blob): break
            nid = struct.unpack_from('>H', blob, pos)[0]
            op, L = blob[pos+2], blob[pos+3]
            if L == 0xff and pos+7 <= len(blob):
                L = struct.unpack_from('<I', b'\0'+blob[pos+4:pos+7], 0)[0]
                val = blob[pos+7:pos+7+L]; pos += 7
            else:
                val = blob[pos+4:pos+4+L]; pos += 4
            if len(val) < L: break
            msgs.append((nid, op, L, val, fl))
        i = j
    game_msgs[gi] = msgs

# 2) 每场 nd 事件(id → rk)
game_nd = {}
with open('/tmp/wot/t53_events_v1.jsonl') as f:
    for line in f:
        d = json.loads(line)
        gi = d['gi']
        g = game_nd.setdefault(gi, {})
        for e in d.get('events', []):
            if isinstance(e, list) and e and e[0] == 'nd':
                g[e[1]] = e[2]   # 后写覆盖(重注册以最后为准)

# 3) join: 0x37 消息的 nid → rk 统计
print('场 | 0x37消息数 | nid命中nd表 | rk分布(消息加权) | 未命中nid TOP3')
rk_all = Counter()
unmatched_all = Counter()
for gi in sorted(game_msgs):
    msgs = game_msgs[gi]
    nd = game_nd.get(gi, {})
    rks = Counter(); un = Counter(); hit = 0
    for nid, op, L, val, fl in msgs:
        if nid in nd:
            hit += 1; rks[nd[nid]] += 1
        else:
            un[nid] += 1
    rk_all.update(rks); unmatched_all.update(un)
    print(f'{gi} | {len(msgs)} | {hit}({100*hit/max(1,len(msgs)):.0f}%) | {dict(rks.most_common(7))} | {[(hex(k),v) for k,v in un.most_common(3)]}')
print(f'\n全语料 rk 分布(0x37 消息加权): {dict(rk_all.most_common(8))}')
print(f'未命中总数: {sum(unmatched_all.values())}, 唯一未命中 nid: {len(unmatched_all)}')
# 4) rk × op 交叉
rk_op = Counter()
for gi in sorted(game_msgs):
    nd = game_nd.get(gi, {})
    for nid, op, L, val, fl in game_msgs[gi]:
        if nid in nd: rk_op[(nd[nid], op)] += 1
print(f'rk × op 交叉 TOP12: {dict(rk_op.most_common(12))}')
json.dump({'game_msgs': {str(k): [[m[0], m[1], m[2], m[3].hex(), m[4]] for m in v] for k, v in game_msgs.items()},
           'game_nd': {str(k): v for k, v in game_nd.items()}},
          open('/tmp/wot/t55_join.json', 'w'))
print('已存 /tmp/wot/t55_join.json')
