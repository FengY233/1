#!/usr/bin/env python3
"""t55_probe.py — Task 55 侦察: 0x37 NRL 缓冲架构实证
架构假说(自 decomp FUN_140e5c470/140e5c4e0/140e52060/140e52300):
  - 0x37 包: [u32 len][raw NRL bytes] → 追加到 endpoint +0xb8 缓冲
  - 0x35 包(空): 触发 FUN_140e5c4e0(ep, 2) → 读 [u16 BE nid] → dispatcher class2 → findNode→node->vt[0x58]
  - 0x36 包(空): 触发 FUN_140e5c4e0(ep, 6) → 读 [u16 BE nid] → updateNode → node->vt[0x60]
验证: ①0x35/36 计数与空性 ②交错模式 ③首 nid 是否命中层级字典 ④消息边界一致性
"""
import struct, sys, glob, json
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter

# 层级字典(nid → slots)
hd = json.load(open('/home/z/my-project/download/data_v26/0x32层级字典_260实体_t44_hierarchy_maps.json'))
nid2slot = {int(k): v for k, v in hd['nid_to_slots'].items()}
print(f'层级字典: {len(nid2slot)} nid')

for f in sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))[:3]:
    blocks, declared, slen, pkts = load(f)
    name = f.split('/')[-1][:28]
    # 0x35/36/37 序列
    seq = [(t, c, p) for i, (t, c, p) in enumerate(pkts) if t in (0x35, 0x36, 0x37)]
    c35 = sum(1 for t, _, _ in seq if t == 0x35)
    c36 = sum(1 for t, _, _ in seq if t == 0x36)
    c37 = sum(1 for t, _, _ in seq if t == 0x37)
    empty35 = sum(1 for t, c, p in seq if t == 0x35 and len(p) == 0)
    empty36 = sum(1 for t, c, p in seq if t == 0x36 and len(p) == 0)
    total37 = sum(len(p) for t, c, p in seq if t == 0x37)
    print(f'\n== {name}: 0x35×{c35}(空{empty35}) 0x36×{c36}(空{empty36}) 0x37×{c37}({total37}B)')
    # 交错模式: 前 30 个 35/36/37 事件
    pat = ''.join({0x35: '5', 0x36: '6', 0x37: '7'}[t] for t, _, _ in seq[:40])
    print(f'  交错前40: {pat}')
    # 0x37 载荷前缀(去 u32 len 后)
    blobs = []
    for t, c, p in seq:
        if t == 0x37 and len(p) >= 4:
            n = struct.unpack_from('<I', p, 0)[0]
            blobs.append(p[4:4+n] if n <= len(p) - 4 else p[4:])
    if blobs:
        buf = b''.join(blobs)
        print(f'  拼接缓冲 {len(buf)}B, 首 40B: {buf[:40].hex(" ")}')
        # 首nid检查
        nid0 = struct.unpack_from('>H', buf, 0)[0]
        print(f'  首 nid=0x{nid0:04x} → 槽位: {nid2slot.get(nid0, "?")}')
        # 前 8 个 u16 BE 值的命中检查(仅当 flush 边界未知时粗看)
        hits = sum(1 for i in range(0, min(len(buf)-1, 200), 2)
                   if struct.unpack_from('>H', buf, i)[0] in nid2slot)
        print(f'  前200B 偶数偏移 nid 命中: {hits}/100')
