#!/usr/bin/env python3
"""t55_debug2.py — 定位第一个失步事件并解剖上下文"""
import struct, sys, glob
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load

f = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))[0]
blocks, declared, slen, pkts = load(f)
events = [(t, p) for t, c, p in pkts if t in (0x35, 0x36, 0x37)]

buf = bytearray()
start = 0
first_err = None
errs = 0
for ei, (t, p) in enumerate(events):
    if t == 0x37:
        n = struct.unpack_from('<I', p, 0)[0] if len(p) >= 4 else 0
        buf += p[4:4+n]
    else:
        pos = start
        ok = False
        if pos + 4 <= len(buf):
            nid = struct.unpack_from('>H', buf, pos)[0]
            op, L = buf[pos+2], buf[pos+3]
            if L == 0xff:
                if pos + 7 <= len(buf):
                    L = int.from_bytes(buf[pos+4:pos+7], 'little'); vstart = pos + 7
                    ok = vstart + L <= len(buf)
                else: vstart = pos + 7
            else:
                vstart = pos + 4
                ok = vstart + L <= len(buf)
            if ok:
                start = vstart + L
            else:
                errs += 1
                if first_err is None:
                    first_err = ei
                    print(f'首个失步: 事件#{ei} 类型0x{t:02x}')
                    print(f'  失步点缓冲 @{start}: {bytes(buf[start:start+40]).hex(" ")}')
                    print(f'  解析尝试: nid=0x{nid:04x} op={op} L={L} 需要到偏移{vstart+L}, 缓冲长{len(buf)}')
                    # 前后文
                    print(f'  失步前20B: {bytes(buf[max(0,start-20):start]).hex(" ")}')
                    # 该事件前后各5个事件
                    lo, hi = max(0,ei-6), min(len(events), ei+4)
                    for k in range(lo, hi):
                        tt, pp = events[k]
                        mark = ' <<<' if k == ei else ''
                        if tt == 0x37:
                            nn = struct.unpack_from('<I', pp, 0)[0] if len(pp) >= 4 else 0
                            print(f'    事件#{k} 0x37 len字段={nn} 包长={len(pp)}{mark}')
                        else:
                            print(f'    事件#{k} 0x{tt:02x} 空包={len(pp)==0}{mark}')
        else:
            errs += 1
            if first_err is None:
                first_err = ei
                print(f'首个失步: 事件#{ei} 类型0x{t:02x} 缓冲仅{len(buf)-start}B 不足4B')
                print(f'  失步点缓冲: {bytes(buf[start:start+20]).hex(" ")}')
print(f'\n总错误: {errs}/{sum(1 for t,_ in events if t!=0x37)} flush, 首错@事件{first_err}, 总事件{len(events)}')
