#!/usr/bin/env python3
"""t55_join2.py — 修正解析后的 nid↔nd(rk) join + 残留分析
"""
import json, sys, glob
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter, defaultdict

d = json.load(open('/tmp/wot/t55_global3.json'))

# 每场 nd 表(id → rk)
game_nd = {}
with open('/tmp/wot/t53_events_v1.jsonl') as f:
    for line in f:
        r = json.loads(line)
        gi = r['gi']
        g = game_nd.setdefault(gi, {})
        for e in r.get('events', []):
            if isinstance(e, list) and e and e[0] == 'nd':
                g[e[1]] = e[2]

files = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
print('场 | 消息 | nid命中 | rk分布 | 命中且空体 | 命中且有体(按rk)')
tot_rk_body = Counter(); tot_rk_empty = Counter()
un_all = Counter()
for gi in sorted(d, key=int):
    r = d[gi]
    nd = game_nd.get(int(gi), {})
    msgs = r['msgs']
    hit = 0; rk_hit = Counter(); rk_body = Counter(); rk_empty = Counter(); un = Counter()
    for nid, op, L, valhex, t, clk in msgs:
        if nid in nd:
            hit += 1; rk_hit[nd[nid]] += 1
            if op is None or op == -1 or op == 'c2':
                rk_empty[nd[nid]] += 1
            else:
                rk_body[nd[nid]] += 1
        else:
            un[nid] += 1
    tot_rk_body.update(rk_body); tot_rk_empty.update(rk_empty); un_all.update(un)
    name = files[int(gi)].split('/')[-1][:20]
    print(f'{gi} | {len(msgs)} | {hit}({100*hit/max(1,len(msgs)):.0f}%) | {dict(rk_hit.most_common(6))} | 空{dict(rk_empty)} | 体{dict(rk_body)}')

print(f'\n全语料: 有体按rk={dict(tot_rk_body.most_common())}')
print(f'        空体按rk={dict(tot_rk_empty.most_common())}')
print(f'        未命中唯一nid={len(un_all)} 总数={sum(un_all.values())}')
print(f'        未命中TOP10: {[(hex(k),v) for k,v in un_all.most_common(10)]}')
