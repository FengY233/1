#!/usr/bin/env python3
"""t55_probe3.py — L(sub)=sub 假说全量验证
消息文法: [u16 BE nid][u8 op][u8 L][L B value]  (L 字节=值长度)
约束: 每个 0x37 blob 必须恰好分割成其后随 flush 数量的消息
"""
import struct, sys, glob, json
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter

sub_total = Counter()
op_dist = Counter()
nid_dist = Counter()
ok_blobs = fail_blobs = 0
examples = []
flush_type_of = {0x35: 'class2', 0x36: 'class6'}
msg_flush_pairs = Counter()   # (op, flush_type) 共现

for fi, f in enumerate(sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))):
    blocks, declared, slen, pkts = load(f)
    events = [(t, p) for t, c, p in pkts if t in (0x35, 0x36, 0x37)]
    i = 0
    while i < len(events):
        t, p = events[i]
        if t != 0x37:
            i += 1
            continue
        n = struct.unpack_from('<I', p, 0)[0] if len(p) >= 4 else 0
        blob = p[4:4+n]
        j = i + 1
        flushes = []
        while j < len(events) and events[j][0] in (0x35, 0x36):
            flushes.append(events[j][0])
            j += 1
        # 分割: [u16 nid][u8 op][u8 L][L B]
        def try_segment(blob, nmsg):
            msgs = []
            pos = 0
            while pos < len(blob) and len(msgs) < nmsg:
                if pos + 4 > len(blob): return None
                nid = struct.unpack_from('>H', blob, pos)[0]
                op, L = blob[pos+2], blob[pos+3]
                if pos + 4 + L > len(blob): return None
                msgs.append((nid, op, L, blob[pos+4:pos+4+L]))
                pos += 4 + L
            if pos != len(blob) or len(msgs) != nmsg: return None
            return msgs
        msgs = try_segment(blob, len(flushes))
        if msgs is not None:
            ok_blobs += 1
            for k, (nid, op, L, val) in enumerate(msgs):
                nid_dist[nid] += 1
                op_dist[op] += 1
                sub_total[L] += 1
                msg_flush_pairs[(op, flush_type_of.get(flushes[k], '?'))] += 1
                if fi == 0 and len(examples) < 40:
                    examples.append((hex(nid), op, L, val.hex()))
        else:
            fail_blobs += 1
            if fail_blobs <= 5:
                print(f'FAIL[{f.split("/")[-1][:16]}] blob {len(blob)}B flushes={len(flushes)}: {blob[:44].hex(" ")}')
        i = j

print(f'\n=== 全语料分割: {ok_blobs} OK / {fail_blobs} FAIL ===')
print(f'op 分布: {dict(op_dist.most_common(10))}')
print(f'L(值长度) 分布: {dict(sub_total.most_common(15))}')
print(f'(op, flush类型) 共现: {dict(msg_flush_pairs.most_common(10))}')
print(f'nid TOP15: {[(hex(k),v) for k,v in nid_dist.most_common(15)]}')
print(f'唯一 nid 数: {len(nid_dist)}')
print(f'\n首场前 40 消息:')
for nid, op, L, val in examples[:40]:
    print(f'  nid={nid} op={op} L={L} val={val}')
