#!/usr/bin/env python3
"""t55_probe2.py — 决定性分割测试: 0x37 blob 按后随 flush 数精确分割
模型: 缓冲追加(0x37) → 逐 flush 消费一条消息(0x35/0x36)
消息候选文法: [u16 BE nid][u8 op][u8 sub][value L(sub)]
验证: blob 必须恰好分割成 n 条消息(n=下个0x37前的flush数)
"""
import struct, sys, glob, json
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter

f = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))[2]  # 20260907 replay3
blocks, declared, slen, pkts = load(f)

# 收集 (type, payload) 事件流(只看 35/36/37, 按包序)
events = []
for t, c, p in pkts:
    if t in (0x35, 0x36, 0x37):
        events.append((t, p))

# 找前几个 0x37 blob 与其后随 flush 串
i = 0
blobs_tested = 0
sub_dist = Counter()
op_dist = Counter()
nid_dist = Counter()
ok_blobs = 0
fail_blobs = 0
examples = []

while i < len(events) and blobs_tested < 200:
    t, p = events[i]
    if t != 0x37:
        i += 1
        continue
    # 0x37 blob
    n = struct.unpack_from('<I', p, 0)[0] if len(p) >= 4 else 0
    blob = p[4:4+n]
    # 数后随 flush 直到下个 0x37
    j = i + 1
    flushes = []
    while j < len(events) and events[j][0] in (0x35, 0x36):
        flushes.append(events[j][0])
        j += 1
    # 分割尝试: 贪心按候选文法
    def try_segment(blob, nmsg):
        msgs = []
        pos = 0
        Lmap = {0x03: 3, 0x06: 5}
        while pos < len(blob) and len(msgs) < nmsg:
            if pos + 4 > len(blob): return None
            nid = struct.unpack_from('>H', blob, pos)[0]
            op, sub = blob[pos+2], blob[pos+3]
            L = Lmap.get(sub)
            if L is None: return None
            if pos + 4 + L > len(blob): return None
            msgs.append((nid, op, sub, blob[pos+4:pos+4+L]))
            pos += 4 + L
        if pos != len(blob) or len(msgs) != nmsg:
            return None
        return msgs
    msgs = try_segment(blob, len(flushes))
    if msgs is not None:
        ok_blobs += 1
        for nid, op, sub, val in msgs:
            nid_dist[nid] += 1
            op_dist[op] += 1
            sub_dist[sub] += 1
            if len(examples) < 30:
                examples.append((hex(nid), hex(op), hex(sub), val.hex()))
    else:
        fail_blobs += 1
        if fail_blobs <= 3:
            print(f'FAIL blob @{i}: {len(blob)}B, flushes={len(flushes)}, 前40B: {blob[:40].hex(" ")}')
    blobs_tested += 1
    i = j

print(f'\n分割测试: {ok_blobs} OK / {fail_blobs} FAIL (共 {blobs_tested} blob)')
print(f'op 分布: {dict(op_dist.most_common(8))}')
print(f'sub 分布: {dict(sub_dist.most_common(12))}')
print(f'nid TOP10: {[(hex(k),v) for k,v in nid_dist.most_common(10)]}')
print(f'\n前 30 消息示例:')
for e in examples[:30]:
    print('  nid=%s op=%s sub=%s val=%s' % e)
