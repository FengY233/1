#!/usr/bin/env python3
"""t55_debug.py — 逐事件追踪缓冲状态, 定位失步起点"""
import struct, sys, glob
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load

f = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))[0]
blocks, declared, slen, pkts = load(f)
events = [(t, p) for t, c, p in pkts if t in (0x35, 0x36, 0x37)]

buf = bytearray()
start = 0
nmsg = 0
for ei, (t, p) in enumerate(events[:60]):
    if t == 0x37:
        n = struct.unpack_from('<I', p, 0)[0] if len(p) >= 4 else 0
        buf += p[4:4+n]
        print(f'#{ei} 0x37 +{n}B (包长{len(p)}) 缓冲总量={len(buf)} 未消费={len(buf)-start} @{start}: {bytes(buf[start:start+24]).hex(" ")}')
    else:
        pos = start
        tag = 'class2' if t == 0x35 else 'updN'
        if pos + 4 <= len(buf):
            nid = struct.unpack_from('>H', buf, pos)[0]
            op, L = buf[pos+2], buf[pos+3]
            if L == 0xff and pos + 7 <= len(buf):
                L = int.from_bytes(buf[pos+4:pos+7], 'little'); vstart = pos + 7
            else:
                vstart = pos + 4
            if vstart + L <= len(buf):
                print(f'#{ei} 0x{t:02x} {tag} 消费 nid=0x{nid:04x} op={op} L={L} val={bytes(buf[vstart:vstart+min(L,12)]).hex(" ")}')
                start = vstart + L; nmsg += 1
            else:
                print(f'#{ei} 0x{t:02x} {tag} ✗不完整 需{vstart+L-start}B 只有{len(buf)-start}B: {bytes(buf[pos:pos+20]).hex(" ")}')
        else:
            print(f'#{ei} 0x{t:02x} {tag} ✗缓冲不足{len(buf)-start}B')
