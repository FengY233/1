#!/usr/bin/env python3
"""t55_global.py — 0x37 全局缓冲模拟(消息可跨 blob 边界)
模型: 端点+0xb8 缓冲为全局连续流; 每个 0x35/0x36 flush 消费一条消息
消息文法(源码级): [u16 BE nid][u8 op][u8 L (FF→u24)][L B val]
硬校验: 总消费字节数 == 总追加字节数, 且消息数 == flush 数
"""
import json, struct, sys, glob
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter

files = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
games = []
for gi, f in enumerate(files):
    blocks, declared, slen, pkts = load(f)
    events = [(t, p) for t, c, p in pkts if t in (0x35, 0x36, 0x37)]
    games.append((f.split('/')[-1][:24], events))

all_stats = []
for gi, (name, events) in enumerate(games):
    # 全局模拟: 缓冲 += blob; flush -= 消息
    buf = bytearray()
    buf_start = 0            # 已消费起点
    msgs = []
    errors = 0
    pending_35_36 = 0
    for t, p in events:
        if t == 0x37:
            n = struct.unpack_from('<I', p, 0)[0] if len(p) >= 4 else 0
            buf += p[4:4+n]
        else:
            # flush: 消费一条消息
            pos = buf_start
            if pos + 4 <= len(buf):
                nid = struct.unpack_from('>H', buf, pos)[0]
                op, L = buf[pos+2], buf[pos+3]
                if L == 0xff:
                    if pos + 7 > len(buf): errors += 1; continue
                    L = int.from_bytes(buf[pos+4:pos+7], 'little')
                    vstart = pos + 7
                else:
                    vstart = pos + 4
                if vstart + L <= len(buf):
                    msgs.append((nid, op, L, bytes(buf[vstart:vstart+L]), t))
                    buf_start = vstart + L
                else:
                    errors += 1   # 消息不完整 — flush 时数据未到(录制乱序?)
            else:
                errors += 1
    leftover = len(buf) - buf_start
    flushes = sum(1 for t, p in events if t in (0x35, 0x36))
    ok = (leftover == 0 and len(msgs) == flushes)
    op_c = Counter(m[1] for m in msgs)
    f35 = sum(1 for t, p in events if t == 0x35)
    m35 = sum(1 for m in msgs if m[4] == 0x35)
    print(f'[{gi}] {name}: flush={flushes} msgs={len(msgs)} 残留={leftover}B err={errors} '
          f'{"✓闭环" if ok else "✗"} op分布={dict(op_c.most_common(6))} 35flush消费={m35}/{f35}')
    all_stats.append((gi, name, msgs, ok, leftover, errors))

# 成功场做 nid×op×L 深度统计
print('\n=== 闭环场深度统计 ===')
nid_c = Counter(); opL = Counter(); nid_opL = {}
for gi, name, msgs, ok, leftover, errors in all_stats:
    if not ok: continue
    for nid, op, L, val, fl in msgs:
        nid_c[nid] += 1
        opL[(op, L)] += 1
        nid_opL.setdefault(nid, Counter())[(op, L)] += 1
print(f'唯一 nid: {len(nid_c)}, 消息总量: {sum(nid_c.values())}')
print(f'nid TOP12: {[(hex(k),v) for k,v in nid_c.most_common(12)]}')
print(f'(op,L) TOP15: {dict(opL.most_common(15))}')
# 单 nid 模式样例
for nid, _ in nid_c.most_common(5):
    print(f'  nid=0x{nid:x}: {dict(nid_opL[nid].most_common(6))}')
json.dump([[gi, name, [[m[0], m[1], m[2], m[3].hex(), m[4]] for m in msgs], ok] for gi, name, msgs, ok, leftover, errors in all_stats],
          open('/tmp/wot/t55_global.json', 'w'))
print('已存 /tmp/wot/t55_global.json')
