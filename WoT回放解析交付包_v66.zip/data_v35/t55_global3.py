#!/usr/bin/env python3
"""t55_global3.py — 修正版全局解析: 体格式按节点类型分派
文法终版:
  消息 = [u16 BE nid] + body
  body 依节点 vt[0x60]:
    - Composite(rk4)/Primitive-包装: [u8 op∈{0,1,2}][u8 L (FF→u24 LE)][L B val]
    - Entity/DynComp/ServerMethodCaller(rk1/2/6): 空体(stub vt[0x60]=IsReady)
    - (0x35 flush → vt[0x58] 创建体, 另格式)
判据: op 字节 ∈ {0,1,2} → 组合体; 否则 → 空体
硬校验: 消息数 == flush 数, 残留 == 0
"""
import struct, sys, glob, json
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter

files = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
results = {}
for gi, f in enumerate(files):
    blocks, declared, slen, pkts = load(f)
    events = [(t, c, p) for t, c, p in pkts if t in (0x35, 0x36, 0x37)]
    buf = bytearray()
    start = 0
    msgs = []
    for t, c, p in events:
        if t == 0x37:
            n = struct.unpack_from('<I', p, 0)[0] if len(p) >= 4 else 0
            buf += p[4:4+n]
        elif t == 0x36:
            # updateNode: [nid] + body(分派)
            pos = start
            if pos + 2 > len(buf): continue
            nid = struct.unpack_from('>H', buf, pos)[0]
            if pos + 4 <= len(buf) and buf[pos+2] in (0, 1, 2):
                op, L = buf[pos+2], buf[pos+3]
                if L == 0xff:
                    if pos + 7 > len(buf): continue
                    L = int.from_bytes(buf[pos+4:pos+7], 'little'); vstart = pos + 7
                else:
                    vstart = pos + 4
                if vstart + L > len(buf): continue
                msgs.append((nid, op, L, bytes(buf[vstart:vstart+L]), t, c))
                start = vstart + L
            else:
                # 空体(stub 节点)
                msgs.append((nid, None, 0, b'', t, c))
                start = pos + 2
        else:
            # 0x35: class2 → vt[0x58] 创建体 — 先记 nid, 体暂作空(待后续文法)
            pos = start
            if pos + 2 > len(buf): continue
            nid = struct.unpack_from('>H', buf, pos)[0]
            msgs.append((nid, 'c2', 0, b'', t, c))
            start = pos + 2
    leftover = len(buf) - start
    flushes = sum(1 for t, c, p in events if t != 0x37)
    results[gi] = dict(msgs=msgs, leftover=leftover, flushes=flushes, buflen=len(buf))
    empty_body = sum(1 for m in msgs if m[1] is None)
    c2 = sum(1 for m in msgs if m[1] == 'c2')
    op_c = Counter(m[1] for m in msgs if isinstance(m[1], int))
    print(f'[{gi}] {f.split("/")[-1][:22]}: flush={flushes} msg={len(msgs)} 残留={leftover}B '
          f'空体={empty_body} c2={c2} op={dict(op_c.most_common(5))} '
          f'{"✓" if leftover==0 and len(msgs)==flushes else "✗"}')

json.dump({str(k): {'leftover': v['leftover'], 'flushes': v['flushes'], 'buflen': v['buflen'],
                    'msgs': [[m[0], m[1] if m[1] is not None else -1, m[2], m[3].hex(), m[4], m[5]] for m in v['msgs']]}
           for k, v in results.items()}, open('/tmp/wot/t55_global3.json', 'w'))
print('已存 /tmp/wot/t55_global3.json')
