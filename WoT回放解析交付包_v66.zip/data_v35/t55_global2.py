#!/usr/bin/env python3
"""t55_global2.py — 等待语义全局模拟: flush 时消息不完整则挂起等下一批数据
另外记录每条消息的 (nid, op, L, 完整性) 供后续节点类型分派
"""
import struct, sys, glob, json
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter

files = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
results = {}
for gi, f in enumerate(files):
    blocks, declared, slen, pkts = load(f)
    events = [(t, c, p) for t, c, p in pkts if t in (0x35, 0x36, 0x37)]
    buf = bytearray()
    start = 0
    msgs = []
    waits = 0
    stuck = None
    for t, c, p in events:
        if t == 0x37:
            n = struct.unpack_from('<I', p, 0)[0] if len(p) >= 4 else 0
            buf += p[4:4+n]
        else:
            pos = start
            if pos + 4 > len(buf):
                waits += 1
                continue
            nid = struct.unpack_from('>H', buf, pos)[0]
            op, L = buf[pos+2], buf[pos+3]
            if L == 0xff:
                if pos + 7 > len(buf): waits += 1; continue
                L = int.from_bytes(buf[pos+4:pos+7], 'little'); vstart = pos + 7
            else:
                vstart = pos + 4
            if vstart + L > len(buf):
                waits += 1
                if stuck is None: stuck = (nid, op, L, len(buf)-pos)
                continue
            msgs.append((nid, op, L, bytes(buf[vstart:vstart+L]), t, c))
            start = vstart + L
    leftover = len(buf) - start
    flushes = sum(1 for t, c, p in events if t != 0x37)
    results[gi] = dict(msgs=msgs, leftover=leftover, flushes=flushes, waits=waits, stuck=stuck)
    op_c = Counter(m[1] for m in msgs)
    print(f'[{gi}] {f.split("/")[-1][:22]}: flush={flushes} 消息={len(msgs)} 等待={waits} 残留={leftover}B '
          f'op={dict(op_c.most_common(5))} stuck={stuck}')

# 残留为 0 且消息数==flush 数 → 闭环
print()
for gi, r in results.items():
    ok = r['leftover'] == 0 and len(r['msgs']) == r['flushes']
    print(f'[{gi}] {"✓闭环" if ok else "✗"}', end=' ')
print()
json.dump({str(k): {'leftover': v['leftover'], 'flushes': v['flushes'], 'waits': v['waits'],
                    'msgs': [[m[0], m[1], m[2], m[3].hex(), m[4], m[5]] for m in v['msgs']]}
           for k, v in results.items()}, open('/tmp/wot/t55_global2.json', 'w'))
print('已存 /tmp/wot/t55_global2.json')
