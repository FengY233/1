#!/usr/bin/env python3
"""t45_slots.py — Task 45: 补齐分帧三要素
1) MemoryIStream vtable @0x1435df260 五槽实现(判 readU8 vs peek)
2) FUN_140e6f0f0 class1 的向量读取器
3) FUN_140e5c860 updateNode(X==6/首消息class==4) 处理器
"""
import pefile, struct
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

def va_to_off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

md = Cs(CS_ARCH_X86, CS_MODE_64)

def read_u64(va):
    off = va_to_off(va)
    return struct.unpack_from('<Q', data, off)[0]

def dis(va, maxlen=600, title='', maxins=120):
    off = va_to_off(va)
    if off is None:
        print(f'!! {hex(va)} 不在节内'); return
    print(f'\n{"="*72}\n===== {title} @{hex(va)} =====\n{"="*72}')
    n = 0
    for ins in md.disasm(data[off:off+maxlen], va):
        print(f'  {ins.address:#x}: {ins.mnemonic:10s} {ins.op_str}')
        n += 1
        if n >= maxins:
            print('  ... (截断)'); break

# 1) MemoryIStream vtable 5 槽
print('MemoryIStream vtable @0x1435df260:')
for i in range(5):
    fn = read_u64(0x1435df260 + 8*i)
    print(f'  slot{i} (+0x{8*i:x}): {hex(fn)}')

for i in range(5):
    fn = read_u64(0x1435df260 + 8*i)
    dis(fn, 300, f'MemoryIStream slot{i}', 40)

# 2) 向量读取器
dis(0x140e6f0f0, 700, 'FUN_140e6f0f0 class1 向量读取器', 140)

# 3) updateNode 处理器
dis(0x140e5c860, 700, 'FUN_140e5c860 updateNode 处理器', 140)
