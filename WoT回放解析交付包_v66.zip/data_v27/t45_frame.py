#!/usr/bin/env python3
"""t45_frame.py — Task 45: 钉死 0x32 流的消息分帧(权威反汇编)
目标函数: FUN_140e5c5d0(首消息) / FUN_140e5c6f0(剩余消息循环) / 调用它们的上层
问题: 后续消息头 [X][b0][class][sub] 的字节序与语义分歧
证据样本: 44B 流 "00 58 00 01 01 ab 21 b8 20 | 00 00 59 00 58 02 6a 00 12 Shots..."
"""
import pefile
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

def va_to_off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

md = Cs(CS_ARCH_X86, CS_MODE_64)

def dis(va, maxlen=1500, title='', maxins=250):
    off = va_to_off(va)
    if off is None:
        print(f'!! {hex(va)} 不在节内'); return
    print(f'\n{"="*72}\n===== {title} @{hex(va)} =====\n{"="*72}')
    n = 0
    for ins in md.disasm(data[off:off+maxlen], va):
        print(f'  {ins.address:#x}: {ins.mnemonic:10s} {ins.op_str}')
        n += 1
        if n >= maxins:
            print('  ... (截断)'); break

# 首消息分帧器
dis(0x140e5c5d0, 800, 'FUN_140e5c5d0 首消息解析', 160)
# 剩余消息循环
dis(0x140e5c6f0, 900, 'FUN_140e5c6f0 剩余消息循环', 200)
