#!/usr/bin/env python3
"""t45_rtti.py — Task 45: RTTI 扫描定位 hub+0x78 注册表组件类
1) 在 EXE .rdata 扫描所有 RTTI 类型描述符名(.?AV 前缀)
2) 过滤 NRL/ClientHub/Component 相关
3) 对 FUN_140e736b0(findNode) 反汇编定位节点表结构
"""
import pefile, struct, re
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

def va_to_off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

# 1) 全量 RTTI 名扫描
print('===== RTTI 类名扫描(过滤 NRL/Hub/Component/Node/Replic) =====')
names = {}
for m in re.finditer(rb'\.\?AV[A-Za-z0-9_@]{4,120}\x00', data):
    s = m.group()[:-1].decode()
    va_base = None
    # 计算 VA
    off = m.start()
    for sec in pe.sections:
        if sec.PointerToRawData <= off < sec.PointerToRawData + sec.SizeOfRawData:
            va_base = imgbase + sec.VirtualAddress + (off - sec.PointerToRawData)
            break
    if va_base:
        names[va_base] = s

pat = re.compile(r'(NRL|Hub|Component|Node|Replic|CGF|Replay)', re.I)
hits = [(va, s) for va, s in names.items() if pat.search(s)]
print(f'匹配 {len(hits)} / 总 {len(names)}')
for va, s in sorted(hits):
    print(f'  {hex(va)}: {s}')
