#!/usr/bin/env python3
"""t45_nrl.py — Task 45: NRL::Node vtable 定位 + vt+0x60(0x37 更新体解析器)反汇编
链路: TypeDescriptor(名字) ← COL ← vftable[-1] ← vftable
"""
import pefile, struct, re
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

sections = [(imgbase + s.VirtualAddress, s.PointerToRawData, max(s.Misc_VirtualSize, s.SizeOfRawData), s.Name.rstrip(b'\x00').decode()) for s in pe.sections]

def va_to_off(va):
    for va0, off, sz, _ in sections:
        if va0 <= va < va0 + sz:
            return off + (va - va0)
    return None

def off_to_va(off):
    for va0, o, sz, _ in sections:
        if o <= off < o + sz:
            return va0 + (off - o)
    return None

md = Cs(CS_ARCH_X86, CS_MODE_64)

def read_cstr(va, maxlen=64):
    off = va_to_off(va)
    if off is None: return '?'
    end = data.find(b'\x00', off, off+maxlen)
    if end < 0: end = off+maxlen
    return data[off:end].decode('utf-8','replace')

def find_vftable_by_rtti(td_name_va):
    """td_name_va = RTTI 名字串地址; TypeDescriptor = td_name_va - 0x10"""
    td_va = td_name_va - 0x10
    td_off_rel = td_va - imgbase  # COL 里存的是相对 imagebase 的 32 位偏移
    # 在全文件搜该 dword → COL+0x0C 位置
    needle = struct.pack('<I', td_off_rel)
    cols = []
    pos = 0
    while True:
        idx = data.find(needle, pos)
        if idx < 0: break
        va = off_to_va(idx)
        if va is not None:
            cols.append(va - 0x0C)  # COL 起点
        pos = idx + 1
    # 对每个 COL, 搜 qword 指向它 → vftable[-1]
    out = []
    for col_va in cols:
        if col_va is None or col_va <= imgbase:
            continue
        needle2 = struct.pack('<Q', col_va)
        pos = 0
        while True:
            idx = data.find(needle2, pos)
            if idx < 0: break
            va = off_to_va(idx)
            if va is not None:
                out.append(va + 8)  # vftable 起点
            pos = idx + 1
    return out

def dis(va, maxlen=1000, title='', maxins=200):
    off = va_to_off(va)
    if off is None:
        print(f'!! {hex(va)} 不在节内'); return
    print(f'\n{"="*72}\n===== {title} @{hex(va)} =====\n{"="*72}')
    n = 0
    for ins in md.disasm(data[off:off+maxlen], va):
        note = ''
        if ins.mnemonic == 'lea' and 'rip' in ins.op_str:
            try:
                m = re.search(r'\[rip \+ (0x[0-9a-f]+)\]', ins.op_str)
                if m:
                    tgt = ins.address + ins.size + int(m.group(1), 16)
                    s = read_cstr(tgt)
                    if s and len(s) > 3 and all(32 <= ord(c) < 127 for c in s):
                        note = f'   ; "{s[:44]}"'
            except: pass
        print(f'  {ins.address:#x}: {ins.mnemonic:10s} {ins.op_str}{note}')
        n += 1
        if n >= maxins:
            print('  ...'); break

# NRL::Node TypeDescriptor 名字 @0x1445bbab0
for name_va, label in [(0x1445bbab0, 'NRL::BW::Node'), (0x1445d2078, 'NRL::BW::Hub'),
                        (0x14456e570, 'cgf::network::NetworkTransformComponent'),
                        (0x14456e460, 'cgf::network::NetworkKinematicTransformComponent'),
                        (0x14456e230, 'cgf::network::NetworkEntity')]:
    vts = find_vftable_by_rtti(name_va)
    print(f'{label}: vftable 候选 {[hex(v) for v in vts]}')
    for vt in vts[:2]:
        # 打印前 16 槽
        slots = []
        off = va_to_off(vt)
        for i in range(16):
            fn = struct.unpack_from('<Q', data, off + 8*i)[0]
            slots.append(hex(fn))
        print(f'  vftable@{hex(vt)}: {slots}')
