#!/usr/bin/env python3
"""t45_hubD.py — Task 45: 定位分发器枢纽 D 的 vtable(含 FUN_140e73f30@+0x58) → RTTI 类名
同时: D+0x78 组件注册表的类
"""
import pefile, struct, re

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

def va_to_off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

def off_to_va(off):
    for s in pe.sections:
        if s.PointerToRawData <= off < s.PointerToRawData + s.SizeOfRawData:
            return imgbase + s.VirtualAddress + (off - s.PointerToRawData)
    return None

def read_cstr(va, maxlen=80):
    off = va_to_off(va)
    if off is None: return '?'
    end = data.find(b'\x00', off, off+maxlen)
    if end < 0: end = off+maxlen
    return data[off:end].decode('utf-8','replace')

# 搜 qword = 0x140e73f30 (class0 处理器)
HANDLERS = {0x140e73f30: 'class0处理器', 0x140e73cf0: 'class1处理器',
            0x140e743b0: 'class2处理器', 0x140e73aa0: 'class3处理器',
            0x140e74250: 'class4处理器'}

for fn, label in HANDLERS.items():
    needle = struct.pack('<Q', fn)
    pos = 0
    print(f'--- {label} {hex(fn)} 的 vtable 引用 ---')
    while True:
        idx = data.find(needle, pos)
        if idx < 0: break
        va = off_to_va(idx)
        if va is not None:
            slot_off = (va - imgbase) % 8
            # 假设该 qword 位于某 vtable 的 +0x58(class0)/+0x60(class1)/...
            # 先打印位置, 再尝试读 vtable 头(vt[-1] = COL)
            col_va_pos = idx - 8
            col = struct.unpack_from('<Q', data, col_va_pos)[0]
            col_off = va_to_off(col)
            name = ''
            if col_off and col_off > 0:
                # COL+0x0C = pTypeDescriptor offset (rel imgbase)
                td_rel = struct.unpack_from('<I', data, col_off + 0x0C)[0]
                td_va = imgbase + td_rel
                td_off = va_to_off(td_va)
                if td_off:
                    name = read_cstr(td_va + 0x10)
            print(f'  qword@{hex(va)}: 前一槽={hex(col)} RTTI类名={name!r}')
        pos = idx + 1
