#!/usr/bin/env python3
"""t45_findnode.py — Task 45: FUN_140e736b0 findNode 反汇编 + 返回类 vtable"""
import pefile, struct, re
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

def va_to_off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

md = Cs(CS_ARCH_X86, CS_MODE_64)

def read_cstr(va, maxlen=64):
    off = va_to_off(va)
    if off is None: return '?'
    end = data.find(b'\x00', off, off+maxlen)
    if end < 0: end = off+maxlen
    return data[off:end].decode('utf-8','replace')

def dis(va, maxlen=800, title='', maxins=160):
    off = va_to_off(va)
    if off is None:
        print(f'!! {hex(va)}'); return
    print(f'\n===== {title} @{hex(va)} =====')
    n = 0
    for ins in md.disasm(data[off:off+maxlen], va):
        note = ''
        if ins.mnemonic == 'lea' and 'rip' in ins.op_str:
            try:
                m = re.search(r'\[rip \+ (0x[0-9a-f]+)\]', ins.op_str)
                if m:
                    tgt = ins.address + ins.size + int(m.group(1), 16)
                    s = read_cstr(tgt)
                    if s and len(s) > 3 and all(32 <= ord(c) < 127 for c in s):
                        note = f'   ; "{s[:44]}"'
            except: pass
        print(f'  {ins.address:#x}: {ins.mnemonic:10s} {ins.op_str}{note}')
        n += 1
        if n >= maxins:
            print('  ...'); break

dis(0x140e736b0, 600, 'FUN_140e736b0 findNode', 100)
