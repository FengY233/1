#!/usr/bin/env python3
"""t45_dispatch.py — Task 45: 0x32 消息族 body 字节级语义攻坚 · 第一步
反汇编 ClientHub 消息分发器 FUN_140e74040 + class 0-5 五个处理器, 提取每个 class 的字节读取序列。

已知识(Task 44):
  - 0x32 载荷 = [u32 len][消息流]
  - 首消息 [u16 BE class<<8|sub] + body; 后续 [u8 X][u8 b0][u8 class][u8 sub] + body
  - X<6 走 class 0-5 分发, X==6 = processUpdateNode
  - class 0 = [u16 objId][u8 regKey] + body (CGF 组件对象消息)
  - 分发器 FUN_140e74040: 槽位表 +0x58/+0x60/+0x68/+0x70/+0x78 = FUN_140e73f30/cf0/743b0/73aa0/74250
目标: 每个处理器读什么字节、怎么用 sub、跳到哪。
"""
import pefile
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

def va_to_off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

md = Cs(CS_ARCH_X86, CS_MODE_64)
md.detail = True

def dis(va, maxlen=1200, title='', stop_after_ret=3):
    off = va_to_off(va)
    if off is None:
        print(f'!! {hex(va)} 不在节内')
        return
    print(f'\n{"="*70}\n===== {title} @{hex(va)} =====\n{"="*70}')
    rets = 0
    n = 0
    for ins in md.disasm(data[off:off+maxlen], va):
        # 调用注释
        line = f'  {ins.address:#x}: {ins.mnemonic:10s} {ins.op_str}'
        print(line)
        n += 1
        if ins.mnemonic == 'ret':
            rets += 1
            if rets >= stop_after_ret:
                break
        if n > 400:
            print('  ... (截断)')
            break

# 分发器本体
dis(0x140e74040, 900, 'FUN_140e74040 ClientHub 消息分发器(class 0-5 槽表)', stop_after_ret=2)
# 五个 class 处理器
dis(0x140e73f30, 700, 'FUN_140e73f30 class0 处理器(CGF 组件对象)', stop_after_ret=2)
dis(0x140e73cf0, 500, 'FUN_140e73cf0 class1 处理器', stop_after_ret=2)
dis(0x140e743b0, 500, 'FUN_140e743b0 class2 处理器', stop_after_ret=2)
dis(0x140e73aa0, 500, 'FUN_140e73aa0 class3 处理器', stop_after_ret=2)
dis(0x140e74250, 500, 'FUN_140e74250 class4 处理器', stop_after_ret=2)
