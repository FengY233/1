#!/usr/bin/env python3
"""t45_parse32.py — Task 45: 0x32 消息流全量解析(修正文法)
权威文法(EXE 反汇编钉死):
  stream = payload[4:]  (跳过录制器加的 [u32 len])
  首消息:  id = u16 BE, class = 0 (调用者 FUN_140e51bc0 xor edx,edx 硬编码)
  后续消息: peek b0 → 若 b0<6: read(3)=[class][id_hi][id_lo] → (class, id)
            class==6: 同样 3 字节头 → updateNode
  class 0 body: [u16 BE objId][u8 regKey] + 组件体(组件按 regKey 查 hub+0x78 注册表)
  class 1 body: 压缩 u32 列表(FUN_140e6f0f0) + 每元素 [u8 regKey]+组件体
  class 4/6 (updateNode): id=节点号, body=节点 vt+0x60 自解析
验证: 10 场随机战全量 0x32 包逐消息解析 + objId 与 nid2slot join
"""
import struct, sys, glob, json
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter, defaultdict

REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
tundra = [f for f in REPLAYS if 'tundra' in f][0]
RND = [f for f in REPLAYS if f != tundra]

nid2slot = json.load(open('/home/z/my-project/download/data_v26/0x32层级字典_260实体_t44_hierarchy_maps.json'))
# 结构: {per_entity: {eid: [[slot,nid],...]}, nid_to_slots: {nid: [slots]}}
raw = nid2slot
nid2slot = {}
for nid, slots in raw['nid_to_slots'].items():
    nid2slot[int(nid)] = set(slots)
print('nid 字典规模:', len(nid2slot))
per_entity = {int(k): v for k, v in raw['per_entity'].items()}
print('per_entity 规模:', len(per_entity))

def read_compressed_u32_list(b, pos):
    """FUN_140e6f0f0 压缩列表: 迄今 value 从 0 起
    0x00: 结束
    0x01..0x7f: delta 正增量, value += b
    0x80: 后跟 u16 BE, value += 该值
    0x81: value += 0 (重复当前值? 观察: push esi=0 → 其实 push 0)
    0x82: 位掩码模式: n = (当前列表长度+7)//8?? 重读 (size+7)/8 字节掩码, 每个置位 bit 追加
    负值(-125..-2): 游程重复
    返回 (values, newpos)
    """
    vals = []
    cur = 0
    while pos < len(b):
        c = b[pos]; pos += 1
        if c == 0x00:
            break
        elif c == 0x80:
            v = struct.unpack_from('>H', b, pos)[0]; pos += 2
            cur += v
            vals.append(cur)
        elif c == 0x81:
            vals.append(0)
        elif c == 0x82:
            nmask = (len(vals) + 7) >> 3
            mask = b[pos:pos+nmask]; pos += nmask
            for byte_i, mb in enumerate(mask):
                for bit in range(8):
                    if mb & (0x80 >> bit):
                        vals.append(len(vals))  # 占位: 掩码语义待 corpus 校准
        elif 0x01 <= c <= 0x7f:
            cur += c
            vals.append(cur)
        else:
            # 负数 (0x83..0xfe): 游程
            run = 0x100 - c - 2  # -(c+2) 补
            for _ in range(run):
                vals.append(cur)
    return vals, pos

class Reader:
    def __init__(self, b):
        self.b = b; self.p = 0
    def rem(self):
        return len(self.b) - self.p
    def read(self, n):
        if self.p + n > len(self.b):
            raise EOFError(f'read {n} at {self.p} len {len(self.b)}')
        r = self.b[self.p:self.p+n]; self.p += n
        return r
    def peek(self):
        if self.p >= len(self.b):
            raise EOFError('peek at end')
        return self.b[self.p]

def parse_stream(b, verbose=False):
    """解析一条 0x32 流 → 消息列表 [(class, id, bodybytes)]"""
    r = Reader(b)
    msgs = []
    if r.rem() < 2:
        return msgs, r
    # 首消息
    mid = struct.unpack('>H', r.read(2))[0]
    mcls = 0
    body_start = r.p
    msgs.append((mcls, mid, body_start))
    # 后续
    while r.rem() >= 3:
        try:
            cls = r.peek()
        except EOFError:
            break
        h = r.read(3)
        cls = h[0]
        mid2 = struct.unpack('>H', h[1:3])[0]
        msgs.append((cls, mid2, r.p))
    return msgs, r

# ── class 0 body 细解 ──
def parse_class0_body(b, start):
    if start + 3 > len(b):
        return None
    objId = struct.unpack_from('>H', b, start)[0]
    regKey = b[start+2]
    rest = b[start+3:]
    return objId, regKey, rest

stats = Counter()          # (class, id) → n
regkey_stats = Counter()   # (class, id, regKey) → n
objid_join = Counter()     # objId 命中 nid2slot
objid_miss = Counter()
body_shapes = defaultdict(Counter)  # (class,id,regKey) → body 前缀 hex 样式
msg_counts = Counter()     # 每包消息数分布
total_pkts = 0
parse_fail = 0
samples = {}

for f in RND:
    blocks, declared, slen, pkts = load(f)
    for t, c, p in pkts:
        if t != 0x32:
            continue
        total_pkts += 1
        stream = p[4:]
        try:
            msgs, r = parse_stream(stream)
        except Exception as e:
            parse_fail += 1
            continue
        msg_counts[len(msgs)] += 1
        for mcls, mid, bstart in msgs:
            stats[(mcls, mid)] += 1
            key = (mcls, mid)
            if key not in samples:
                samples[key] = stream[bstart:bstart+24].hex(' ')
            if mcls == 0:
                pb = parse_class0_body(stream, bstart)
                if pb:
                    objId, regKey, rest = pb
                    regkey_stats[(mcls, mid, regKey)] += 1
                    if objId in nid2slot:
                        objid_join[objId] += 1
                    else:
                        objid_miss[objId] += 1
                    body_shapes[(mcls, mid, regKey)][rest[:8].hex(' ')] += 1

print()
print(f'0x32 总包数: {total_pkts}, 解析失败: {parse_fail}')
print(f'每包消息数分布: {dict(sorted(msg_counts.items())[:15])}')
print(f'(class,id) 族数: {len(stats)}')
print()
print('TOP30 (class,id) 族:')
for (mcls, mid), n in stats.most_common(30):
    print(f'  class={mcls} id={mid:#06x}: n={n:5d}  sample: {samples[(mcls,mid)][:60]}')
print()
print('class 0 的 (id, regKey) 分布 TOP25:')
for (mcls, mid, rk), n in sorted(regkey_stats.items(), key=lambda kv: -kv[1])[:25]:
    shapes = ', '.join(f'{s}×{c}' for s, c in body_shapes[(mcls,mid,rk)].most_common(2))
    print(f'  id={mid:#06x} regKey={rk}: n={n:5d}  body: {shapes}')
print()
print(f'objId 命中 nid 字典: {sum(objid_join.values())} / {sum(objid_join.values())+sum(objid_miss.values())}')
print('objId 命中 TOP10:', [(hex(k), v) for k, v in objid_join.most_common(10)])
print('objId 未命中 TOP10:', [(hex(k), v) for k, v in objid_miss.most_common(10)])
