#!/usr/bin/env python3
"""t45_caller.py — Task 45: 找 FUN_140e5c5d0 的调用者(0x32 播放路径), 钉死首消息 class 来源
同时: FUN_140e736b0(findNode) 节点表结构 + 错误路径字符串提取
"""
import pefile, struct
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

def va_to_off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

md = Cs(CS_ARCH_X86, CS_MODE_64)

def read_cstr(va, maxlen=64):
    off = va_to_off(va)
    if off is None: return '?'
    end = data.find(b'\x00', off, off+maxlen)
    if end < 0: end = off+maxlen
    try: return data[off:end].decode('utf-8', 'replace')
    except: return '?'

def dis(va, maxlen=900, title='', maxins=200):
    off = va_to_off(va)
    if off is None:
        print(f'!! {hex(va)} 不在节内'); return
    print(f'\n{"="*72}\n===== {title} @{hex(va)} =====\n{"="*72}')
    n = 0
    for ins in md.disasm(data[off:off+maxlen], va):
        # rip 相对字符串注释
        note = ''
        if 'rip' in ins.op_str and ins.mnemonic == 'lea':
            try:
                import re
                m = re.search(r'\[rip \+ (0x[0-9a-f]+)\]', ins.op_str)
                if m:
                    tgt = ins.address + ins.size + int(m.group(1), 16)
                    s = read_cstr(tgt)
                    if s and len(s) > 3 and all(32 <= ord(c) < 127 for c in s):
                        note = f'   ; "{s[:48]}"'
            except: pass
        print(f'  {ins.address:#x}: {ins.mnemonic:10s} {ins.op_str}{note}')
        n += 1
        if n >= maxins:
            print('  ... (截断)'); break

# 全 EXE 扫描对 FUN_140e5c5d0 的 call (e8 rel32)
TARGET = 0x140e5c5d0
print('搜索 call FUN_140e5c5d0 ...')
callers = []
for s in pe.sections:
    if not (s.Characteristics & 0x20):  # executable
        continue
    start = s.PointerToRawData
    end = start + s.SizeOfRawData
    base = imgbase + s.VirtualAddress
    # 粗扫 e8
    pos = start
    while True:
        idx = data.find(b'\xe8', pos, end)
        if idx < 0 or idx + 5 > end: break
        rel = struct.unpack_from('<i', data, idx+1)[0]
        tgt = base + (idx - start) + 5 + rel
        if tgt == TARGET:
            caller_va = base + (idx - start)
            callers.append(caller_va)
            print(f'  call @ {hex(caller_va)}')
        pos = idx + 1

# 反汇编每个 caller 的函数头(向前找函数起点: 连续 int3 或对齐后)
for cva in callers:
    # 从 caller 往回最多 4KB 找函数边界(int3 填充)
    off = va_to_off(cva)
    back = data.rfind(b'\xcc\xcc', max(0, off-4096), off)
    if back < 0: back = off - 600
    fstart_va = cva - (off - back - 2)
    # 对齐 16
    fstart_va = (fstart_va + 15) & ~15
    dis(fstart_va, 1500, f'caller 函数(含 call @ {hex(cva)})', 300)

# findNode
dis(0x140e736b0, 500, 'FUN_140e736b0 findNode', 90)

# 错误路径字符串
print('\n错误字符串:')
for va, tag in [(0x1435d9dc3, 'updateNode未找到节点'), (0x14358f9e8, 'updateNode解析失败')]:
    print(f'  {tag} @{hex(va)}: "{read_cstr(va, 80)}"')
