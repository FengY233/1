#!/usr/bin/env python3
"""t49_len.py — 检查 199B 标本的 [u32 len] 前缀与前后包关系"""
import sys, glob, struct
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load

REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TUNDRA = [f for f in REPLAYS if 'tundra' in f][0]
RND = [f for f in REPLAYS if f != TUNDRA]

cands = []
for fi, f in enumerate(RND):
    blocks, declared, slen, pkts = load(f)
    for pi, (t, c, pl) in enumerate(pkts):
        if t == 0x32:
            b = pl[4:]
            if b'content/CGFPrefabs' in b:
                cands.append((len(b), fi, pi, b, pl))
cands.sort()
sz, fi, pi, b, pl = cands[0]
print(f'标本: {sz}B (payload总长 {len(pl)}B)')
ln = struct.unpack('<I', pl[:4])[0]
print(f'[u32 LE len] = {ln} (blob 实长 {len(b)})  → 尾部剩余 {len(b)-ln}B')

# 前后包
f = RND[fi]
blocks, declared, slen, pkts = load(f)
print(f'\n回放#{fi} 0x32 包总数: {sum(1 for t,_,_ in pkts if t==0x32)}')
for dpi in range(pi-2, pi+3):
    if 0 <= dpi < len(pkts):
        t, c, p2 = pkts[dpi]
        if t == 0x32:
            ln2 = struct.unpack('<I', p2[:4])[0]
            blob = p2[4:]
            print(f'  包#{dpi}: blob {len(blob)}B, len字段={ln2}, 首16B: {blob[:16].hex()}')
            if dpi == pi + 1:
                print(f'    → 下一包开头 ASCII: {"".join(chr(x) if 32<=x<127 else "." for x in blob[:48])}')
