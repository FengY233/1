#!/usr/bin/env python3
"""t49_compdefs.py — Task49-①: component_defs 128 def 全量解码 → t49_component_types.json
重点: NetworkVehicleHierarchy / SequenceNetworkSync / ShotsReceiver (tid 已锚定)
"""
import sys, json, glob, os
sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file

CD = '/tmp/wot/wot_scripts/component_defs'

def sec_text(s):
    if s.type == 1: return s.asString()
    if s.children: return None
    if s.type == 0 and not s.data: return None
    if s.type == 2: return str(s.asInt())
    if s.type == 4: return 'true' if s.asBool() else 'false'
    return s.data.hex()

def type_tree(node):
    txt = sec_text(node)
    out = {}
    if txt: out['t'] = txt
    for cc in node.children:
        if cc.name in ('Size', 'size'): out['size'] = sec_text(cc)
        elif cc.name in ('AllowNone', 'allowNone'): out['allowNone'] = sec_text(cc)
        elif cc.name in ('DBLength', 'DatabaseLength'): out['dbLen'] = sec_text(cc)
        elif cc.name not in ('Properties',):
            sub = {'n': cc.name}
            for fc in cc.children:
                if fc.name == 'Type': sub['type'] = type_tree(fc)
                else: sub[fc.name.lower()] = sec_text(fc)
            if 'type' not in sub and not cc.children:
                sub['t'] = sec_text(cc)
            out.setdefault('subs', []).append(sub)
    return out

table = {}
for path in sorted(glob.glob(f'{CD}/*.def')):
    name = os.path.basename(path)[:-4]
    try:
        root = decode_file(path)
    except Exception as e:
        table[name] = {'error': str(e)}
        continue
    ent = {}
    for sec in root.children:
        if sec.name == 'Properties':
            props = []
            for p in sec.children:
                if p.name == 'Property':
                    pn = pv = pflags = None
                    ptype = {}
                    for c in p.children:
                        if c.name == 'Name': pn = sec_text(c)
                        elif c.name == 'Type': ptype = type_tree(c)
                        elif c.name == 'Flags': pflags = sec_text(c)
                    if pn:
                        props.append({'name': pn, 'type': ptype.get('t'), 'flags': pflags,
                                      'allowNone': ptype.get('allowNone'), 'size': ptype.get('size')})
                else:
                    # 内联属性节点(无 Property 包装)
                    pn = p.name
                    ptype = {}
                    pflags = None
                    for c in p.children:
                        if c.name == 'Type': ptype = type_tree(c)
                        elif c.name == 'Flags': pflags = sec_text(c)
                    props.append({'name': pn, 'type': ptype.get('t'), 'flags': pflags,
                                  'allowNone': ptype.get('allowNone'), 'size': ptype.get('size')})
            ent['props'] = props
        elif sec.name == 'Implements':
            ent['implements'] = [sec_text(c) for c in sec.children if sec_text(c)]
        elif sec.name and not sec.children and sec_text(sec):
            ent.setdefault('attrs', {})[sec.name] = sec_text(sec)
        elif sec.name:
            ent.setdefault('secs', {})[sec.name] = [str(sec_text(c)) for c in sec.children if sec_text(c)]
    table[name] = ent

json.dump(table, open('/tmp/wot/t49_component_types.json', 'w'), ensure_ascii=False, indent=1)
print(f'component_defs 解码: {len(table)} def')

# 重点三件
for k in ('NetworkVehicleHierarchy', 'SequenceNetworkSync', 'ShotsReceiver'):
    v = table.get(k, {})
    print(f'--- {k}: {len(v.get("props", []))} 属性')
    for p in v.get('props', []):
        print(f'    {p["name"]}: {p["type"]} flags={p["flags"]} allowNone={p.get("allowNone")}')

# 属性数分布
import collections
cnt = collections.Counter(len(v.get('props', [])) for v in table.values())
print('属性数分布(前12):', dict(sorted(cnt.items())[:12]))
# ALL_CLIENTS 属性总数
ac = sum(1 for v in table.values() for p in v.get('props', []) if p['flags'] and 'ALL_CLIENTS' in p['flags'])
tot = sum(len(v.get('props', [])) for v in table.values())
print(f'总属性 {tot}, ALL_CLIENTS {ac}')
