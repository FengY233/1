#!/usr/bin/env python3
"""t49_tidmap2.py — Task49-① v2: 用 t48_full2 完整解析器插桩收集 (tid, name)
=> 语料权威 tid→def 映射 + 偏移假设验证
"""
import sys, glob, struct, json, re
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from bwxml import decode_file
from collections import Counter, defaultdict

# ---- t48_full2 解析器(插桩: rk2 创建体记录 tid/name) ----
def read_len(b, p):
    l = b[p]; p += 1
    if l == 0xff:
        l = b[p] | (b[p+1] << 8) | (b[p+2] << 16); p += 3
    return l, p

def clist(b, p, base, n):
    vals, flags, v = [], set(), base
    while True:
        if p >= n: return None
        c = struct.unpack('b', b[p:p+1])[0]; p += 1
        if c == 0: return vals, flags, p
        elif c == -0x80:
            if p + 2 > n: return None
            v = struct.unpack('>H', b[p:p+2])[0]; p += 2; vals.append(v)
        elif c == -0x7f: vals.append(0)
        elif c == -0x7e:
            nmask = (len(vals) + 7) >> 3
            if p + nmask > n: return None
            mask = b[p:p+nmask]; p += nmask
            for i in range(len(vals)):
                if mask[i >> 3] & (1 << (i & 7)): flags.add(i)
            return vals, flags, p
        elif 1 <= c <= 0x7f:
            v += c; vals.append(v)
        else:
            for _ in range(c + 126):
                v += 1; vals.append(v)

VALUE_LENS = [0, 1, 2, 4, 8, 12, 16]

def value_candidates(b, p, n):
    cand = []
    rem = n - p
    for L in VALUE_LENS:
        if L <= rem: cand.append(L)
    if rem >= 1:
        l = b[p]
        hdr = 4 if l == 0xff else 1
        if l == 0xff and rem >= 4:
            l = b[p+1] | (b[p+2] << 8) | (b[p+3] << 16)
        if hdr + l <= rem and l <= 96: cand.append(hdr + l)
    return cand

def make_parser():
    records = []   # (tid, name)
    def parse_stream(stream, maxvisit=60000):
        b = stream; n = len(b)
        if n < 2: return None
        nodes = {}
        visit = [0]
        def step(p, depth):
            if p >= n: return ('done', p)
            if p + 3 > n: return ('tail', p) if n - p <= 2 else None
            mcls = b[p]; mid = (b[p+1] << 8) | b[p+2]; q = p + 3
            if mcls > 6 or mcls == 5: return None
            visit[0] += 1
            if visit[0] > maxvisit: return None
            return dispatch(q, mcls, mid, depth + 1)
        def create_cands(p, rk, mid, depth):
            out = []
            if rk in (0, 6): out.append(p)
            elif rk == 1:
                if p + 4 <= n: out.append(p + 4)
            elif rk == 2:
                if p + 2 > n: return out
                tid = b[p] | (b[p+1] << 8)
                l, p2 = read_len(b, p + 2)
                if p2 + l > n: return out
                nm = b[p2:p2+l].decode('latin1')
                records.append((tid, nm))
                p3 = p2 + l
                r = clist(b, p3, mid, n)
                if r is None: return out
                vals, flags, p4 = r
                k = len(flags)
                def gen(pp, cnt, acc):
                    if cnt == 0:
                        yield (pp, tuple(acc)); return
                    for L in value_candidates(b, pp, n):
                        acc.append(L)
                        yield from gen(pp + L, cnt - 1, acc)
                        acc.pop()
                if k == 0:
                    out.append(p4)
                else:
                    cnt = 0
                    for pp, lens in gen(p4, k, []):
                        out.append(pp); cnt += 1
                        if cnt >= 12: break
            elif rk in (3, 4):
                for L in value_candidates(b, p, n): out.append(p + L)
            elif rk == 5:
                if p >= n: return out
                l, p2 = read_len(b, p)
                if p2 + l <= n: out.append(p2 + l)
            return out
        def dispatch(p, mcls, mid, depth):
            if depth > 60: return None
            if mcls == 0:
                if p + 3 > n: return None
                objId = struct.unpack('>H', b[p:p+2])[0]; rk = b[p+2]; q = p + 3
                if rk > 6: return None
                nodes[objId] = rk
                for np in create_cands(q, rk, mid, depth):
                    r = step(np, depth)
                    if r is not None: return r
                return None
            elif mcls == 1:
                r = clist(b, p, mid, n)
                if r is None: return None
                vals, flags, q = r
                def rec(i, q2):
                    if i == len(vals):
                        return step(q2, depth)
                    if q2 + 1 > n: return None
                    rk = b[q2]; q3 = q2 + 1
                    if rk > 6: return None
                    nodes[vals[i]] = rk
                    for np in create_cands(q3, rk, vals[i], depth + 1):
                        r2 = rec(i + 1, np)
                        if r2 is not None: return r2
                    return None
                return rec(0, q)
            elif mcls in (2, 3):
                return step(p, depth)
            elif mcls in (4, 6):
                rk = nodes.get(mid)
                if rk is None: return None
                if rk in (1, 2, 6): return step(p, depth)
                if rk == 3:
                    for L in value_candidates(b, p, n):
                        r = step(p + L, depth)
                        if r is not None: return r
                    return None
                if rk == 4:
                    if p + 1 > n: return None
                    kind = b[p]; q = p + 1
                    if kind <= 1:
                        l, q2 = read_len(b, q)
                        if q2 + l > n: return None
                        return step(q2 + l, depth)
                    for L in value_candidates(b, p, n):
                        r = step(p + L, depth)
                        if r is not None: return r
                    return None
                return None
            return None
        mid0 = struct.unpack('>H', b[0:2])[0]
        return dispatch(2, 0, mid0, 0)
    return parse_stream, records

REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TUNDRA = [f for f in REPLAYS if 'tundra' in f][0]
RND = [f for f in REPLAYS if f != TUNDRA]

pkgs = []
for f in RND:
    blocks, declared, slen, pkts = load(f)
    for t, c, pl in pkts:
        if t == 0x32: pkgs.append(pl[4:])

parse_stream, records = make_parser()
ok = 0
for s in pkgs:
    if parse_stream(s) is not None: ok += 1
print(f'全解 {ok}/{len(pkgs)}; 收集 rk2 创建体 {len(records)} 条')

# tid → 名字计数
tid_names = defaultdict(Counter)
for tid, nm in records:
    tid_names[tid][nm or ''] += 1

# def 名集合
import os
defs = set(os.path.basename(p)[:-4] for p in glob.glob('/tmp/wot/wot_scripts/component_defs/*.def'))
root = decode_file('/tmp/wot/wot_scripts/components.xml')
static = [c.name for c in root.children[0].children]
dynamic = [c.name for c in root.children[1].children]

# 对每个 tid: 找名字形如 <def>_<数字> 或 == <def> 的实例
tid_def = {}
for tid, names in sorted(tid_names.items()):
    best = None
    for nm, cnt in names.items():
        m = re.match(r'^(.+?)_?\d+$', nm)
        cand = m.group(1) if m else nm
        if cand in defs:
            if best is None or cnt > best[1]: best = (cand, cnt)
    if best: tid_def[tid] = best[0]
print(f'tid→def(命名锚定): {len(tid_def)} 条')
print(json.dumps(tid_def, ensure_ascii=False))

# 偏移验证: tid - off == dynamic.index(def)?
pairs = [(tid, d) for tid, d in tid_def.items() if d in dynamic]
print(f'\ndynamic 内 def 锚: {len(pairs)}')
for off in range(0, 90):
    h = sum(1 for tid, d in pairs if 0 <= tid - off < len(dynamic) and dynamic[tid - off] == d)
    if h >= max(2, len(pairs) * 0.4):
        print(f'偏移 {off}: {h}/{len(pairs)}')
# 逐条差值
diffs = Counter()
for tid, d in pairs:
    if d in dynamic: diffs[tid - dynamic.index(d)] += 1
print('差值分布:', dict(diffs))
json.dump({str(t): dict(c) for t, c in tid_names.items()},
          open('/tmp/wot/t49_tid_names.json', 'w'), ensure_ascii=False)
json.dump(tid_def, open('/tmp/wot/t49_tid_def.json', 'w'), ensure_ascii=False)
print('已存 /tmp/wot/t49_tid_names.json + t49_tid_def.json')
