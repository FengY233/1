#!/usr/bin/env python3
"""t49_trace.py — 对 199B prefab 标本跑 t48_full2, 输出逐步边界; 失败则定位分歧点"""
import sys, glob, struct
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
import importlib.util
spec = importlib.util.spec_from_file_location('t48f', '/home/z/my-project/scripts/t48_full2.py')
m = importlib.util.module_from_spec(spec)
import types
# 只取函数不跑 main
src = open('/home/z/my-project/scripts/t48_full2.py').read().split("if __name__=='__main__':")[0]
ns = {}
exec(src, ns)
parse_stream = ns['parse_stream']

REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TUNDRA = [f for f in REPLAYS if 'tundra' in f][0]
RND = [f for f in REPLAYS if f != TUNDRA]

cands = []
for fi, f in enumerate(RND):
    blocks, declared, slen, pkts = load(f)
    for pi, (t, c, pl) in enumerate(pkts):
        if t == 0x32:
            b = pl[4:]
            if b'content/CGFPrefabs' in b:
                cands.append((len(b), fi, pi, b))
cands.sort()
sz, fi, pi, b = cands[0]
print(f'标本: {sz}B 回放#{fi} 包#{pi}')
r = parse_stream(b)
print('t48_full2 解析:', r)

# 手工注释版 hexdump
print()
notes = {
    0: '首消息 id=0x02FB(class0 硬编码)',
    2: 'objId=1', 4: 'rk=1(BWEntityNode)', 5: 'eid=u32LE 0x2094A147',
    9: '消息头 class=1 mid=0x02FB',
    12: 'clist: +55→818, +4→822, abs 998, 00 终止',
    18: '元素818: rk=2(DynComp)', 19: 'tid=127', 21: 'name len=0',
    22: 'clist: 85=游程3(819,820,821) 82=掩码',
    24: '掩码字节 05 → 位置{0,2} 置位',
    25: '??? 02',
    26: '44=68 字符串长度 → content/CGFPrefabs prefab 路径',
    95: '01', 96: 'u32LE 80', 100: 'u32LE 62(=gun nid!)', 104: '01 00',
    106: '02', 107: 'u32LE 81', 111: '00×5',
    116: '元素822: rk=2, tid=125, name=0',
    120: 'clist: 83=游程1, 82=掩码, 01→{0}',
    123: '??? 02',
    124: '80 00 00 / 85 82 07 / 51 55 00 00',
    134: '05=层级数, 03 gun u32(62), 04 hull u32(60), 07 chassis u32(59), 06 turret u32(61), 13 compositionRootSlot u32(39)',
}
for j in range(0, len(b), 16):
    ch = b[j:j+16]
    line = ' '.join(f'{x:02x}' for x in ch).ljust(48)
    ann = ' '.join(f'@{j+k}:{notes[j+k]}' for k in range(16) if j+k in notes)
    print(f'{j:4d}: {line} {ann}')
