#!/usr/bin/env python3
"""t49_taxonomy.py — 1105 个失败包全分类: 按首消息结构签名分组"""
import sys, glob, struct
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter, defaultdict

src = open('/home/z/my-project/scripts/t48_full2.py').read().split("if __name__=='__main__':")[0]
ns = {}
exec(src, ns)
parse_stream = ns['parse_stream']

REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TUNDRA = [f for f in REPLAYS if 'tundra' in f][0]
RND = [f for f in REPLAYS if f != TUNDRA]

pkgs = []
for f in RND:
    blocks, declared, slen, pkts = load(f)
    for t, c, pl in pkts:
        if t == 0x32: pkgs.append(pl[4:])

def clist(b, p, base, n):
    vals, flags, v = [], set(), base
    while True:
        if p >= n: return None
        c = b[p]; p += 1
        sc = c - 256 if c >= 128 else c
        if c == 0: return vals, flags, p
        elif sc == -0x80:
            if p + 2 > n: return None
            v = (b[p] << 8) | b[p+1]; p += 2; vals.append(v)
        elif sc == -0x7f: vals.append(0)
        elif sc == -0x7e:
            nmask = (len(vals) + 7) >> 3
            if p + nmask > n: return None
            mask = b[p:p+nmask]; p += nmask
            for i in range(len(vals)):
                if mask[i >> 3] & (1 << (i & 7)): flags.add(i)
            return vals, flags, p
        elif 1 <= sc <= 0x7f:
            v += sc; vals.append(v)
        else:
            for _ in range(sc + 126):
                v += 1; vals.append(v)

tax = Counter()
detail = defaultdict(list)
for idx, b in enumerate(pkgs):
    if parse_stream(b) is not None: continue
    n = len(b)
    if n < 5: tax['太短'] += 1; continue
    mid0 = (b[0] << 8) | b[1]
    objId = (b[2] << 8) | b[3]
    rk = b[4]
    sig = None
    if rk == 1 and n >= 12 and b[9] == 1:
        # class-1 批: 看元素 tid
        r = clist(b, 12, mid0, n)
        if r:
            vals, flags, q = r
            if q < n:
                rk2 = b[q]
                tid = b[q+1] | (b[q+2] << 8) if q + 3 <= n else -1
                sig = f'c1批 rk={rk2} tid={tid} nvals={len(vals)}'
    if sig is None:
        sig = f'其他 rk={rk} (首字节组 {b[:8].hex()})'
    tax[sig] += 1
    if len(detail[sig]) < 2: detail[sig].append((idx, n, b[:40].hex()))

print(f'失败总数 {sum(tax.values())}, 分类:')
for sig, c in tax.most_common(25):
    print(f'  {c:5d}  {sig}')
    for idx, n, h in detail[sig][:1]:
        print(f'         例: #{idx} {n}B {h}')
