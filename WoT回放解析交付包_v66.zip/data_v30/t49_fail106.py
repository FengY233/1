#!/usr/bin/env python3
"""t49_fail106.py — 106B/108B 大失败类 dump + 已解析 106B 成功样本对照"""
import sys, glob, struct
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter

src = open('/home/z/my-project/scripts/t48_full2.py').read().split("if __name__=='__main__':")[0]
ns = {}
exec(src, ns)
parse_stream = ns['parse_stream']

REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TUNDRA = [f for f in REPLAYS if 'tundra' in f][0]
RND = [f for f in REPLAYS if f != TUNDRA]

pkgs = []
for f in RND:
    blocks, declared, slen, pkts = load(f)
    for t, c, pl in pkts:
        if t == 0x32: pkgs.append(pl[4:])

f106 = [(i, s) for i, s in enumerate(pkgs) if len(s) == 106]
f108 = [(i, s) for i, s in enumerate(pkgs) if len(s) == 108]
ok106 = [i for i, s in f106 if parse_stream(s) is not None]
bad106 = [(i, s) for i, s in f106 if parse_stream(s) is None]
print(f'106B: 成功 {len(ok106)} 失败 {len(bad106)}')
bad108 = [(i, s) for i, s in f108 if parse_stream(s) is None]
print(f'108B: 失败 {len(bad108)}')

print('\n=== 106B 失败样本 2 个:')
for idx, b in bad106[:2]:
    print(f'--- #{idx}:')
    for j in range(0, len(b), 16):
        ch = b[j:j+16]
        print(f'  {j:4d}: ' + ' '.join(f'{x:02x}' for x in ch).ljust(48) + ' ' + ''.join(chr(x) if 32 <= x < 127 else '.' for x in ch))

print('\n=== 108B 失败样本 2 个:')
for idx, b in bad108[:2]:
    print(f'--- #{idx}:')
    for j in range(0, len(b), 16):
        ch = b[j:j+16]
        print(f'  {j:4d}: ' + ' '.join(f'{x:02x}' for x in ch).ljust(48) + ' ' + ''.join(chr(x) if 32 <= x < 127 else '.' for x in ch))

# 成功的 106B 长什么样(对照)
print('\n=== 106B 成功样本 1 个(对照):')
if ok106:
    b = pkgs[ok106[0]]
    for j in range(0, len(b), 16):
        ch = b[j:j+16]
        print(f'  {j:4d}: ' + ' '.join(f'{x:02x}' for x in ch).ljust(48) + ' ' + ''.join(chr(x) if 32 <= x < 127 else '.' for x in ch))

# f32 解码辅助
def f32(x): return struct.unpack('<f', x)[0]
