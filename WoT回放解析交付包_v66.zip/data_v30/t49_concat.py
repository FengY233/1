#!/usr/bin/env python3
"""t49_concat.py — 验证 NRL 流跨 0x32 包连续性: 拼接整场回放的 blob 后解析
对照组: 逐包解析(83.8%)
"""
import sys, glob, struct
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load

src = open('/home/z/my-project/scripts/t48_full2.py').read().split("if __name__=='__main__':")[0]
ns = {}
exec(src, ns)
parse_stream = ns['parse_stream']

REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TUNDRA = [f for f in REPLAYS if 'tundra' in f][0]
RND = [f for f in REPLAYS if f != TUNDRA]

# 取一场: 收集 0x32 blob 序列, 看 #92227 的下一个 0x32 包开头
f = RND[5]
blocks, declared, slen, pkts = load(f)
p32 = [(pi, pl[4:]) for pi, (t, c, pl) in enumerate(pkts) if t == 0x32]
print(f'回放#5: 0x32 包 {len(p32)} 个')
# 找 199B 标本位置
for k, (pi, b) in enumerate(p32):
    if len(b) == 199 and b'content/CGFPrefabs' in b:
        print(f'标本 = p32[{k}] (全局包#{pi})')
        for dk in (-1, 1, 2):
            if 0 <= k + dk < len(p32):
                pi2, b2 = p32[k + dk]
                print(f'  p32[{k+dk}] (#{pi2}, {len(b2)}B): {b2[:24].hex()}')
        break

# 拼接实验: 逐场拼接全部 blob, 看能解多长
print('\n=== 拼接实验(以回放#5为例) ===')
blob = b''.join(b for _, b in p32)
print(f'拼接总长: {len(blob):,}B')
r = parse_stream(blob)
print('整场拼接解析:', r if r is None else f'{r[0]} @ {r[1]}/{len(blob)}')

# 分段拼接: 每失败点截断重启 — 模拟"包边界=流边界, 失败包之前都连续"的混合模型
# 先看: 标本前的拼接段能否解到标本开头
seg = b''.join(b for _, b in p32[:k])
r2 = parse_stream(seg)
print(f'标本前拼接段({len(seg):,}B): ', r2 if r2 is None else f'{r2[0]} @ {r2[1]}/{len(seg)}')
