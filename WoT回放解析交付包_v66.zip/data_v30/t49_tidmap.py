#!/usr/bin/env python3
"""t49_tidmap.py — Task49-①: tid→def 全量映射
假设: tid = 49 + dynamic 注册序(components.xml DynamicComponents)
验证: 语料全部命名实例 (tid, name前缀) 对照
"""
import sys, glob, json, re
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from bwxml import decode_file
from collections import Counter, defaultdict

# dynamic 注册序
root = decode_file('/tmp/wot/wot_scripts/components.xml')
static = [c.name for c in root.children[0].children]
dynamic = [c.name for c in root.children[1].children]

REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TUNDRA = [f for f in REPLAYS if 'tundra' in f][0]
RND = [f for f in REPLAYS if f != TUNDRA]

def read_len(b, p):
    l = b[p]; p += 1
    if l == 0xff:
        l = b[p] | (b[p+1] << 8) | (b[p+2] << 16); p += 3
    return l, p

def clist(b, p, base, n):
    vals, flags, v = [], set(), base
    while True:
        if p >= n: return None
        c = b[p]; p += 1
        sc = c - 256 if c >= 128 else c
        if c == 0: return vals, flags, p
        elif sc == -0x80:
            v = (b[p] << 8) | b[p+1]; p += 2; vals.append(v)
        elif sc == -0x7f: vals.append(0)
        elif sc == -0x7e:
            nmask = (len(vals) + 7) >> 3
            mask = b[p:p+nmask]; p += nmask
            for i in range(len(vals)):
                if mask[i >> 3] & (1 << (i & 7)): flags.add(i)
            return vals, flags, p
        elif 1 <= sc <= 0x7f:
            v += sc; vals.append(v)
        else:
            for _ in range(sc + 126):
                v += 1; vals.append(v)

# 扫描全语料 0x32 流, 收集 class0/class1 rk2 创建体的 (tid, name)
# 复用 t48_full2 的分帧逻辑(轻量: 仅 walk 头部+rk2 创建体, 不做完整值解析)
import struct

def scan_stream(b, out):
    """尽力遍历: 首消息 [u16 BE id] class0; 后续 [cls][id_hi][id_lo]"""
    n = len(b)
    if n < 2: return
    p = 2
    mcls = 0
    mid = (b[0] << 8) | b[1]
    guard = 0
    while p < n and guard < 4000:
        guard += 1
        if mcls == 0:
            if p + 3 > n: break
            objId = (b[p] << 8) | b[p+1]; rk = b[p+2]; q = p + 3
            if rk > 6: break
            if rk == 2:
                tid = b[q] | (b[q+1] << 8); q += 2
                l, q2 = read_len(b, q)
                if q2 + l > n: break
                nm = b[q2:q2+l]
                out.append((tid, nm.decode('latin1'), objId, mid))
                # 尝试跳过创建体到下一条: clist
                p3 = q2 + l
                r = clist(b, p3, mid, n)
                if r is None: break
                vals, flags, p4 = r
                p = p4; mcls = 4; mid = objId
                continue
            elif rk == 1:
                if p + 4 > n: break
                p += 4; mcls = 1
                continue
            else:
                break  # 值体长度未知, 停
        elif mcls == 1:
            r = clist(b, p, mid, n)
            if r is None: break
            vals, flags, q = r
            # 逐元素 rk + 创建体: 只消费 rk==2 的命名, 其余停
            i = 0
            ok = True
            while i < len(vals):
                if q + 1 > n: ok = False; break
                rk = b[q]; q += 1
                if rk == 2:
                    if q + 2 > n: ok = False; break
                    tid = b[q] | (b[q+1] << 8); q += 2
                    l, q2 = read_len(b, q)
                    if q2 + l > n: ok = False; break
                    nm = b[q2:q2+l]
                    out.append((tid, nm.decode('latin1'), vals[i], mid))
                    r2 = clist(b, q2 + l, vals[i], n)
                    if r2 is None: ok = False; break
                    _, _, q = r2
                    i += 1
                else:
                    ok = False; break
            if not ok: break
            p = q; mcls = 4; mid = vals[-1] if vals else mid
            continue
        else:
            break
    return

pairs = []
for f in RND:
    blocks, declared, slen, pkts = load(f)
    for t, c, pl in pkts:
        if t == 0x32:
            try: scan_stream(pl[4:], pairs)
            except Exception: pass

print(f'扫描收集创建体: {len(pairs)} 条')

# tid → name 前缀统计 (去掉尾部数字)
tid_names = defaultdict(Counter)
for tid, nm, oid, mid in pairs:
    base = re.sub(r'[_0-9]+$', '', nm) if nm else ''
    tid_names[tid][base] += 1

# 验证 +49 假设 (dynamic 0基)
hits, misses, anon = 0, [], 0
for tid in sorted(tid_names):
    for base, cnt in tid_names[tid].items():
        if not base:
            anon += cnt; continue
        exp = dynamic[tid - 49] if 0 <= tid - 49 < len(dynamic) else None
        if exp == base: hits += cnt
        else: misses.append((tid, base, cnt, exp))
print(f'命名实例: 命中(=dynamic[tid-49]) {hits}, 未命中 {sum(c for _,_,c,_ in misses)}, 匿名 {anon}')
for m in misses[:20]:
    print('  MISS tid=%d base=%s cnt=%d expected=%s' % m)

# 尝试其他偏移
print()
for off in range(0, 80):
    h = sum(cnt for tid in tid_names for base, cnt in tid_names[tid].items()
            if base and 0 <= tid - off < len(dynamic) and dynamic[tid - off] == base)
    tot = sum(cnt for tid in tid_names for base, cnt in tid_names[tid].items() if base)
    if h > tot * 0.5:
        print(f'偏移 {off}: {h}/{tot} ({100*h/tot:.1f}%)')
