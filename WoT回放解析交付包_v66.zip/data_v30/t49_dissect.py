#!/usr/bin/env python3
"""t49_dissect.py — 取最小的含 prefab 名的 0x32 包, 逐字节解剖"""
import sys, glob, struct
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load

REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TUNDRA = [f for f in REPLAYS if 'tundra' in f][0]
RND = [f for f in REPLAYS if f != TUNDRA]

cands = []
for fi, f in enumerate(RND):
    blocks, declared, slen, pkts = load(f)
    for pi, (t, c, pl) in enumerate(pkts):
        if t == 0x32:
            b = pl[4:]
            if b'content/CGFPrefabs' in b:
                cands.append((len(b), fi, pi, b))
cands.sort()
print(f'含 prefab 的 0x32 包: {len(cands)} 个, 最小 5 个长度: {[c[0] for c in cands[:5]]}')

for sz, fi, pi, b in cands[:1]:
    print(f'\n=== 最小包: {sz}B (回放#{fi} 包#{pi}) 全量hexdump:')
    for j in range(0, len(b), 16):
        ch = b[j:j+16]
        print(f'  {j:4d}: ' + ' '.join(f'{x:02x}' for x in ch).ljust(48) + ' ' + ''.join(chr(x) if 32 <= x < 127 else '.' for x in ch))
