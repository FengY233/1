#!/usr/bin/env python3
"""t49_full3.py — Task49 解码器 v3: 反汇编实证文法 + tid 类型记忆推断
文法权威(FUN_1403991a0/FUN_140e6f0f0 实证):
  rk2 创建体: [u16 LE tid][len][name] + clist(base=nid,vals+mask ceil(vals/8)字节)
    + 属性循环 i<N_props: 置位(bit<N_props)读属性值(DataType 格式, 按 def 推断)
    + 方法循环: vals[N_props..末-1] 各读 [len][name]
    + 末 val: ServerMethodCaller 无体
  值候选: 定长/STRING/BLOB/ARRAY/NVH(u32+层级数组)/自定义记录
类型记忆: (tid, prop_idx) -> 成功值格式, 先到先得(语料顺序稳定)
"""
import sys, glob, struct, json
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter, defaultdict

REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TUNDRA = [f for f in REPLAYS if 'tundra' in f][0]
RND = [f for f in REPLAYS if f != TUNDRA]

def read_len(b, p):
    l = b[p]; p += 1
    if l == 0xff:
        l = b[p] | (b[p+1] << 8) | (b[p+2] << 16); p += 3
    return l, p

def clist(b, p, base, n):
    vals, flags, v = [], set(), base
    while True:
        if p >= n: return None
        c = struct.unpack('b', b[p:p+1])[0]; p += 1
        if c == 0: return vals, flags, p
        elif c == -0x80:
            if p + 2 > n: return None
            v = struct.unpack('>H', b[p:p+2])[0]; p += 2; vals.append(v)
        elif c == -0x7f: vals.append(0)
        elif c == -0x7e:
            nmask = (len(vals) + 7) >> 3
            if p + nmask > n: return None
            mask = b[p:p+nmask]; p += nmask
            for i in range(nmask * 8):   # 掩码字节全覆盖, 不越界
                if mask[i >> 3] & (1 << (i & 7)): flags.add(i)
            return vals, flags, p
        elif 1 <= c <= 0x7f:
            v += c; vals.append(v)
        else:
            for _ in range(c + 126):
                v += 1; vals.append(v)

# ---------- 值解析器: 返回候选 end 列表 ----------
def val_cands(b, p, n, memo, tid, pi, depth=0):
    """属性值候选 [(end, fmt)] — memo 命中则只返回记忆格式"""
    key = (tid, pi)
    out = []
    rem = n - p
    if rem <= 0: return out
    mk = memo.get(key)
    def try_fmt(fmt):
        e = parse_val(b, p, n, fmt, depth)
        return e
    if mk:
        e = parse_val(b, p, n, mk, depth)
        if e is not None: out.append((e, mk))
        return out
    # 定长
    for L, f in ((1, 'u8'), (2, 'u16'), (4, 'u32'), (4, 'f32'), (8, 'f64'), (12, 'v3'), (16, 'v4')):
        if L <= rem: out.append((p + L, f))
    # STRING/BLOB: [len][bytes]
    l = b[p]
    hdr = 4 if l == 0xff else 1
    if l == 0xff and rem >= 4:
        l = b[p+1] | (b[p+2] << 8) | (b[p+3] << 16)
    if hdr + l <= rem and l <= 200: out.append((p + hdr + l, 'str'))
    # ARRAY: [u8 n][n × elem] — elem 递归
    if b[p] <= 16:
        nn = b[p]
        q = p + 1
        ok = True
        for _ in range(nn):
            sub = val_cands(b, q, n, {}, tid, pi, depth + 1)
            if not sub: ok = False; break
            q = sub[0][0]   # 贪心: 取最小消耗
        if ok and q <= n: out.append((q, f'arr{nn}'))
    # NVH hierarchy 数组: [u8 m][m × ([len][name][u32])]
    if b[p] <= 12:
        m = b[p]; q = p + 1; ok = True
        for _ in range(m):
            if q >= n: ok = False; break
            ln, q2 = read_len(b, q)
            if q2 + ln + 4 > n: ok = False; break
            q = q2 + ln + 4
        if ok: out.append((q, 'hier'))
    # 自定义记录: [u8 01][u32][u32][u8][u8][u8][u32][u32][u8] = 21B (link record)
    if rem >= 21 and b[p] == 0x01:
        out.append((p + 21, 'lnk21'))
    # 自定义: [u8 tag][len][bytes] (tagged string)
    if rem >= 2 and b[p] in (2, 4, 6, 8):
        l2 = b[p+1]
        if 2 + l2 <= rem and l2 <= 200: out.append((p + 2 + l2, 'tagstr'))
    return out

def parse_val(b, p, n, fmt, depth):
    rem = n - p
    if fmt in ('u8',): return p + 1 if rem >= 1 else None
    if fmt in ('u16',): return p + 2 if rem >= 2 else None
    if fmt in ('u32', 'f32'): return p + 4 if rem >= 4 else None
    if fmt == 'f64': return p + 8 if rem >= 8 else None
    if fmt == 'v3': return p + 12 if rem >= 12 else None
    if fmt == 'v4': return p + 16 if rem >= 16 else None
    if fmt == 'str':
        l, q = read_len(b, p)
        return q + l if q + l <= n and l <= 200 else None
    if fmt == 'tagstr':
        if rem < 2: return None
        l = b[p+1]
        return p + 2 + l if 2 + l <= rem and l <= 200 else None
    if fmt == 'lnk21':
        return p + 21 if rem >= 21 and b[p] == 0x01 else None
    if fmt == 'hier':
        if p >= n: return None
        m = b[p]; q = p + 1
        for _ in range(m):
            if q >= n: return None
            ln, q2 = read_len(b, q)
            if q2 + ln + 4 > n: return None
            q = q2 + ln + 4
        return q
    if fmt.startswith('arr'):
        if p >= n: return None
        nn = int(fmt[3:])
        q = p + 1
        for _ in range(nn):
            # 数组元素 = 泛型最小候选
            c = val_cands(b, q, n, {}, 9999, -1, depth + 1)
            if not c: return None
            q = c[0][0]
        return q if q <= n else None
    return None

# ---------- 主解析 ----------
def parse_stream(stream, memo, maxvisit=80000):
    b = stream; n = len(b)
    if n < 2: return None
    visit = [0]
    nodes = {}
    def step(p, depth):
        if p >= n: return ('done', p)
        if n - p <= 2: return ('tail', p)
        if p + 3 > n: return None
        mcls = b[p]; mid = (b[p+1] << 8) | b[p+2]; q = p + 3
        if mcls > 6: return None
        visit[0] += 1
        if visit[0] > maxvisit: return None
        return dispatch(q, mcls, mid, depth + 1)
    def rk2_create(p, nid, depth):
        """[tid][len][name]+clist+属性值+方法名+末val; 返回 end|None"""
        if p + 2 > n: return None
        tid = b[p] | (b[p+1] << 8)
        l, p2 = read_len(b, p + 2)
        if p2 + l > n: return None
        p3 = p2 + l
        r = clist(b, p3, nid, n)
        if r is None: return None
        vals, flags, p4 = r
        nv = len(vals)
        if nv == 0: return None   # 至少要 1 val (server caller)
        def try_nprops(np_):
            """np_ = 属性数; 属性循环读值; 然后方法名; DFS 值格式"""
            if np_ > nv - 1: return None
            def gen_props(pp, i, acc):
                if i == np_:
                    yield pp, tuple(acc); return
                if i in flags:
                    for e, fmt in val_cands(b, pp, n, memo, tid, i):
                        acc.append(fmt)
                        yield from gen_props(e, i + 1, acc)
                        acc.pop()
                else:
                    yield from gen_props(pp, i + 1, acc)
            best = None
            cnt = 0
            for pp, fmts in gen_props(p4, 0, []):
                # 方法循环: vals[np_..nv-2] 各 [len][name]
                q = pp; ok = True
                for j in range(np_, nv - 1):
                    if q >= n: ok = False; break
                    ln, q2 = read_len(b, q)
                    if q2 + ln > n: ok = False; break
                    q = q2 + ln
                if not ok or q > n: continue
                best = q
                for i, f in enumerate(fmts):
                    if i in flags: memo[(tid, i)] = f
                cnt += 1
                if cnt >= 3: break
                return best  # 首个成功即返回
            return best
        # N_props 未知: 尝试 0..nv-1 (记忆优先: 用已推断的 tid->np)
        np_key = ('np', tid)
        order = []
        if np_key in memo:
            order = [memo[np_key]] + [x for x in range(0, nv) if x != memo[np_key]]
        else:
            order = list(range(0, nv))
        for np_ in order:
            if np_ > nv - 1: continue
            e = try_nprops(np_)
            if e is not None:
                memo[np_key] = np_
                return e
        return None
    def create_body(p, rk, nid, depth):
        if depth > 50: return None
        if rk in (0, 6): return p
        if rk == 1: return p + 4 if p + 4 <= n else None
        if rk == 2: return rk2_create(p, nid, depth)
        if rk == 3:
            for L in (0, 1, 2, 4, 8, 12, 16):
                if p + L <= n:
                    e = p + L
                    if step(e, depth): return e
            l = b[p] if p < n else 0
            hdr = 4 if l == 0xff else 1
            if l == 0xff and p + 4 <= n:
                l = b[p+1] | (b[p+2] << 8) | (b[p+3] << 16)
            if p + hdr + l <= n and l <= 200: return p + hdr + l
            return None
        if rk == 4:
            if p + 1 > n: return None
            kind = b[p]
            if kind <= 1:
                l, q2 = read_len(b, p + 1)
                if q2 + l <= n: return q2 + l
                return None
            for L in (1, 2, 4, 8):
                if p + L <= n: return p + L
            return None
        if rk == 5:
            if p >= n: return None
            l, q2 = read_len(b, p)
            if q2 + l <= n: return q2 + l
            return None
        return None
    def dispatch(p, mcls, mid, depth):
        if depth > 60: return None
        if mcls == 0:
            if p + 3 > n: return None
            objId = (b[p] << 8) | b[p+1]; rk = b[p+2]
            if rk > 6: return None
            nodes[objId] = rk
            e = create_body(p + 3, rk, objId, depth)
            return step(e, depth) if e is not None else None
        elif mcls == 1:
            r = clist(b, p, mid, n)
            if r is None: return None
            vals, flags, q = r
            def rec(i, q2):
                if i == len(vals):
                    return step(q2, depth)
                if q2 + 1 > n: return None
                rk = b[q2]
                if rk > 6: return None
                nodes[vals[i]] = rk
                e = create_body(q2 + 1, rk, vals[i], depth + 1)
                if e is None: return None
                return rec(i + 1, e)
            return rec(0, q)
        elif mcls in (2, 3, 5):
            return step(p, depth)
        elif mcls in (4, 6):
            rk = nodes.get(mid)
            if rk is None: return None
            if rk in (1, 2, 6): return step(p, depth)
            if rk == 3:
                for L in (0, 1, 2, 4, 8, 12, 16):
                    if p + L <= n:
                        r = step(p + L, depth)
                        if r is not None: return r
                return None
            if rk == 4:
                if p + 1 > n: return None
                kind = b[p]
                if kind <= 1:
                    l, q2 = read_len(b, p + 1)
                    if q2 + l > n: return None
                    return step(q2 + l, depth)
                for L in (1, 2, 4, 8):
                    if p + L <= n:
                        r = step(p + L, depth)
                        if r is not None: return r
                return None
            if rk == 0:
                # Root 更新体: clist + 位图段 + 节点更新循环 (Task47)
                r = clist(b, p, mid, n)
                if r is None: return None
                vals, flags, q = r
                # 位图 u32 数组: ceil(len/32) 个? — 试消耗后直接 step
                nbits = len(vals)
                nw = (nbits + 31) >> 5
                if q + nw * 4 <= n:
                    r2 = step(q + nw * 4, depth)
                    if r2 is not None: return r2
                return step(q, depth)
            return None
        return None
    mid0 = (b[0] << 8) | b[1]
    return dispatch(2, 0, mid0, 0)

if __name__ == '__main__':
    pkgs = []
    for f in RND:
        blocks, declared, slen, pkts = load(f)
        for t, c, pl in pkts:
            if t == 0x32: pkgs.append(pl[4:])
    print(f'0x32 包总数: {len(pkgs)}')
    memo = {}
    ok = 0; kinds = Counter()
    import time; t0 = time.time()
    fails = []
    for idx, s in enumerate(pkgs):
        r = parse_stream(s, memo)
        if r is not None: ok += 1; kinds[r[0]] += 1
        elif len(fails) < 8: fails.append(idx)
    print(f'全解 {ok}/{len(pkgs)} ({100*ok/len(pkgs):.1f}%) {dict(kinds)} 耗时{time.time()-t0:.0f}s')
    print('失败样本:', fails[:8])
    # 类型记忆统计
    nps = {tid: v for (k, tid), v in ((k, k[1]), k[1]) for k in memo if k[0] == 'np'} if False else \
          {tid: v for k, v in memo.items() if k[0] == 'np' for tid in [k[1]]}
    print(f'推断 N_props: {len(nps)} 个 tid')
    fmts = Counter(v for k, v in memo.items() if k[0] != 'np')
    print('值格式分布:', dict(fmts.most_common(12)))
    json.dump({f'{k[0]}:{k[1]}': v for k, v in memo.items()},
              open('/tmp/wot/t49_memo.json', 'w'), ensure_ascii=False)
