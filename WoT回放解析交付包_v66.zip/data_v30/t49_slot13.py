#!/usr/bin/env python3
"""t49_slot13.py — FUN_1403991a0 (ClientDynComponentNode slot13 续体) 完整反汇编
问题: clist 之后、掩码之后、属性循环的确切字节序
"""
import pefile
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
base = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

def va2off(va):
    for s in pe.sections:
        if base + s.VirtualAddress <= va < base + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - base - s.VirtualAddress)
    return None

md = Cs(CS_ARCH_X86, CS_MODE_64)
md.detail = False

def dis(va, n, title, stop_rets=3):
    off = va2off(va)
    print(f'\n===== {title} @{hex(va)} =====')
    rc = 0
    for i in md.disasm(data[off:off+n], va):
        print(f'  {i.address:#x}: {i.mnemonic:10s} {i.op_str}')
        if i.mnemonic == 'ret':
            rc += 1
            if rc >= stop_rets: break

# slot13 续体 (findings: FUN_1403991a0)
dis(0x1403991a0, 900, 'DynComp slot13 续体 (创建体解析主循环)', 4)
