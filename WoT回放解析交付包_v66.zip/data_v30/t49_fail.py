#!/usr/bin/env python3
"""t49_fail.py — 失败包按大小排序, dump 最小 8 个 + 失败长度分布"""
import sys, glob, struct
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter

src = open('/home/z/my-project/scripts/t48_full2.py').read().split("if __name__=='__main__':")[0]
ns = {}
exec(src, ns)
parse_stream = ns['parse_stream']

REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TUNDRA = [f for f in REPLAYS if 'tundra' in f][0]
RND = [f for f in REPLAYS if f != TUNDRA]

pkgs = []
for f in RND:
    blocks, declared, slen, pkts = load(f)
    for t, c, pl in pkts:
        if t == 0x32: pkgs.append(pl[4:])

fails = []
for idx, s in enumerate(pkgs):
    if parse_stream(s) is None:
        fails.append((len(s), idx, s))
fails.sort()
print(f'失败包 {len(fails)}/{len(pkgs)}; 长度分布(前15): {sorted(Counter(sz for sz,_,_ in fails).items())[:15]}')

for sz, idx, b in fails[:8]:
    print(f'\n=== #{idx} {sz}B:')
    for j in range(0, len(b), 16):
        ch = b[j:j+16]
        print(f'  {j:4d}: ' + ' '.join(f'{x:02x}' for x in ch).ljust(48) + ' ' + ''.join(chr(x) if 32 <= x < 127 else '.' for x in ch))
