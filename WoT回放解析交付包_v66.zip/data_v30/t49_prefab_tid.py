#!/usr/bin/env python3
"""t49_prefab_tid.py — 搜索 0x32 流中 prefab 路径原始字节, 确定其真实 tid
字节模式: [tid_lo tid_hi] [len] 'content/CGFPrefabs/...'
"""
import sys, glob, struct
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter

REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TUNDRA = [f for f in REPLAYS if 'tundra' in f][0]
RND = [f for f in REPLAYS if f != TUNDRA]

pkgs = []
for f in RND:
    blocks, declared, slen, pkts = load(f)
    for t, c, pl in pkts:
        if t == 0x32: pkgs.append(pl[4:])

PAT = b'content/CGFPrefabs'
hits = Counter()
samples = []
for si, b in enumerate(pkgs):
    start = 0
    while True:
        i = b.find(PAT, start)
        if i < 0: break
        start = i + 1
        # 前溯: name 由 [len] 前缀; len 前是 [tid u16 LE]
        # name 起点即 i, len 字节在 i-1 (单字节) 或 i-4..i-1 (0xFF + u24)
        cands = []
        if i >= 1 and b[i-1] == len(PAT) % 256 and (len(PAT) == b[i-1] or b[i-1] == 0x10):
            pass
        # 一般: l = len('content/CGFPrefabs...') 到下一个结构边界, 未知; 先看 i-1 和 i-4
        ctx = b[max(0, i-8):i]
        if i >= 3:
            tid = b[i-3] | (b[i-2] << 8)
            l = b[i-1]
            cands.append(('u8len', tid, l))
        hits[ctx.hex()] += 1
        if len(samples) < 12:
            samples.append((si, i, b[max(0, i-16):i+40]))

print(f'prefab 路径命中: {sum(hits.values())} 处')
# tid 候选统计: [i-3][i-2]=tid, [i-1]=len(若 len 合理 = 名长)
tid_cnt = Counter()
name_lens = Counter()
for si, b in enumerate(pkgs):
    start = 0
    while True:
        i = b.find(PAT, start)
        if i < 0: break
        start = i + 1
        if i >= 3:
            tid = b[i-3] | (b[i-2] << 8)
            # 名字到 .prefab 结束
            j = b.find(b'.prefab', i)
            if j > 0:
                namelen = j + 7 - i
                tid_cnt[(tid, b[i-1] == namelen)] += 1
                name_lens[(b[i-1], namelen)] += 1
print('tid×(len字节==名长) 计数:')
for (tid, ok), c in tid_cnt.most_common(12):
    print(f'  tid={tid:5d} len对={ok} {c}次')
print()
print('len 字节 vs 实际名长 (前10):')
for (lb, nl), c in name_lens.most_common(10):
    print(f'  len字节={lb} 实际={nl} {c}次')
print()
for si, i, ctx in samples[:6]:
    print(f'pkg#{si} @{i}: {ctx.hex()}')
    print(f'   ASCII: {" ".join(chr(x) if 32<=x<127 else f"{x:02x}" for x in ctx)}')
