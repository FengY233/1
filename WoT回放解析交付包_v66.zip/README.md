

---

# V31 增补（Task 53-54 · v36-v37 · 语义级事件流 + 方法ID机制源码级闭环）

在 V30 全量底座之上新增：

| 内容 | 说明 |
|---|---|
| `findings.md` | ★ 结论登记册 v37（新增 §32：★★★语义标注器——100% 文法验证升级为语义级事件流 + 三项新实证；§33：★★★★组件方法ID机制源码级闭环——槽序排序模型/mid=声明序号/OwnVehicle 10/10 逐位验证） |
| `data_v34/` | t53 语义标注三件套（统计 14KB + 样例 19KB + 全事件流 1.54MB jsonl，6822 行含 span 可回溯字节）+ t54 结果×3（127 def 全保真全表 / mid 机制验证与 OwnVehicle 映射 / tid→def 匹配表 v1） |
| `scripts/t53_*.py` `t54_*.py` | 同步副本：语义标注器 + 收集器 / def 全保真重提 + mid 预测验证 + tid→def 匹配器 |

核心突破（Task 53）：
1. **★★★语义标注器闭环（100% 文法 → 语义）**：t53_semantic.py = v8 验证器 + 事件流提取器（事件日志 + try/finally 逐候选回滚协议 + 注册 journal）；6822/6822 包全量语义事件流（nd=10963/fr=8089/cr=4048/me=4038/pr=2688/cl=1077/ro=10）。
2. **严格回滚模式 0 次污染回退**：sem=6776 与 v8 Pass1 逐包一致——v8 接受集不依赖注册污染，节点表语义干净。
3. **帧 class 分布 {0:7005, 1:1077, 2:5, 5:2}**：class4/6（updateNode）本语料零出现——0x32 纯创建流，节点更新走 0x24/0x07（通道分工定案）。
4. **方法段 pk=3882（96.1%）引擎真模型主导**；ln=156（3.9%）胜出包吸收内容为层级串/prefab 路径——ln 定性为低置信分段。
5. **hier 载荷升级**：867 层级槽位表/4472 槽位（gun/hull/chassis/turret/compositionRootSlot×856 + gun1×78 双管 + rocket_joint/SightPointer/HP_loaders/HP_pod/crest_module 变体），与 t44 字典 104 例逐位一致。
6. **六族语义读取器全命中**：123 花名册（300 记录精确）/51 OwnVehicle（ov0/ov1/ov18 全元素）/112 订阅/127 附着链/54 队伍槽位/104 FLOAT 数组。

核心突破（Task 54）：
7. **★★★★方法ID机制全解（BigWorld 14.4 源码级）**：ExposedMethodsSortHelper + method_description::streamSize——方法槽序 = stable_sort(streamSize)，定长参数和升序在前、变长桶在后（-vlh=1 幅值升序，相等即声明序）；mid = 重载合并声明表序号（13 声明→11 唯一名=网络 11 槽）；组件方法不加 EntityID+4。
8. **OwnVehicle 预测槽序 (4,9,10,2,3,1,5,6,0,7,8) 与实测 10/10 包逐位一致**——mid→名映射全表导出（0=onBattleEvents…10=beforeSetupUpdate），静态可推导。
9. **t49 字典方法漏收修复**：127 def 全保真重提（属性+方法全名+参数类型+attrs；OwnVehicle def 23 属性=网络 np_=23 ✓，13 方法声明→去重 11=网络 11 槽，重载合并实锤）。
10. **★服务端≠客户端 def 漂移组件侧首证**：51/123/128 完美匹配 vs 106/121/150/154 漂移（121=SequenceNetworkSync 服务端 3+3 vs 客户端 5+3，呼应实体侧 TeamInfo+3）；np 搜索偏置确认（v8 从小 np 试起=ln 伪影根源）。


---

# V32 增补（Task 55-56 · v38 · 0x37 通道架构翻案：NRL 缓冲协议全解 + 进度定量普查）

在 V31 全量底座之上新增：

| 内容 | 说明 |
|---|---|
| `findings.md` | ★ 结论登记册 v38（新增 §34：★★★★★0x37/0x35/0x36 三通道真架构——播放分发器源码级翻案 + NRL 消息文法钉死 + op 三语义 + 失败即弃容错模型 + 七类节点 vtable 全表 + 变换值字段坐标） |
| `data_v35/` | t55 全套（0x37 全局解析汇总 / 2.5MB 初步 join / 2.9MB 全语料消息明细 + 脚本×11）+ t56 通道字节占比普查（10 场 151.4 万包 45.97MB 逐通道统计 + 加权理解度 94.09%） |
| `scripts/t55_*.py` `t56_census.py` | 同步副本：NRL 探针/全局缓冲模拟/失步解剖/值统计/join ×11 + 通道普查器 |

核心突破（Task 55）：
1. **★★★★★0x37/0x35/0x36 三通道真架构（源码级翻案）**：播放分发器 FUN_140574dd0——0x35/0x36 = 无流参数的空包触发器（分别驱动 FUN_140e5c4e0(ep,2/6) 从 NRL 缓冲消费一条消息），0x37 = FUN_140e5c470 整块追加端点+0xb8 双接口 MemoryOStream。推翻 v6「0x35/36 空流版本」旧理解——空包是设计而非缺数据。
2. **★★★NRL 消息文法源码级钉死**：[u16 BE nid][体]，体按节点 vt[0x60] 分派——组合属性节点(rk4) = [u8 op∈{0,1,2}][u8 L(0xFF→u24 逃逸)][L B 值]（FUN_140399aa0 逐指令）；Entity/DynComp/ServerMethodCaller(rk1/2/6) = 空体 2 字节消息。
3. **★op 三语义**：0=整值设置 / 1=切片（is_slice=1）/ 2+=嵌套路径更新（is_slice=0）——与 0x24 通道共享执行端 FUN_142a7c1a0。
4. **★失败即弃容错模型**：findNode 失败或体读失败 → stream->finish() 丢弃整个缓冲，服务器以快照重发对账（初始 nid 同 op 同 L 仅值差实证）。
5. **★实证链**：game0 前 102 事件 100% 逐字节闭环；快照 blob 125B=8 消息精确分割；11 场消息数≈flush 数（3 场精确相等）。
6. **★变换值字段坐标定位**：op=2 L=6 主力型 27341 条——b1=字段选择器{0x98 主/0x94/0x1c/0x04/0x30}、b0=成对共享平滑字节（全偶，47 唯一值）、b2-b5=u16 对（符号扩展 fe/ff 模式）——数学定标剩余路径读取器一跳（FUN_142abf4a0）。

核心成果（Task 56）：
7. **进度定量普查**：10 场随机战语料 1,514,067 包 / 45.97MB payload 逐通道统计——0x0A 位置流 68.05% / 0x07 属性 12.94% / 0x39 复制流 2.48% / 0x37 NRL 1.52% / 0x05 1.18% / 0x32 0.69%；**按字节加权「回放内容搞懂度」= 94.09%**。
8. **剩余缺口排序**：①0x37 变换值数学定标（1.52% 字节，车辆动画重建的最后一块）②NRL 节点注册表 join（nid↔节点表 1-11%）③0x39 复制流字段语义（2.48% 字节）④0x3D digest 服务端 def 漂移（算法已全破，指纹性质）⑤边缘小项（karelia2 deathOrder 异常等）。


---

# V33 增补（Task 56-b · v39 · ★★★★★0x37 值段完全破译：PropertyChangeReader 位流 + 死亡事件流）

在 V32 全量底座之上新增：

| 内容 | 说明 |
|---|---|
| `findings.md` | ★ 结论登记册 v39（新增 §35：★★★★★0x37 值段完全破译——路径读取器链源码级闭环 / BitReader 类全解 / op≥2 值格式定案 / op=1 切片区间对 / 七类节点 vtable 终局表（RTTI 全署名）/ 分发架构双触发器真身 / 玩家索引空间 + 死亡事件流 / Root 巨包 volatile delta 位图批量） |
| `data_v36/` | t56 全套（0x37 语义解码样例 JSON：76 死亡事件 / 每玩家计数器终值 / nid 族统计 / 结构速查 + 脚本×6） |
| `scripts/t56_*.py` | 增量 5 件（decode 语义解码器 / batch 全语料批处理 / root Root 巨包解析 / vt vtable 直读 / collect 汇总——census 已随 V32 交付） |

核心突破（Task 56-b）：
1. **★★★★★路径读取器链源码级闭环**：FUN_142abf4a0 = `PropertyChangeReader::readAndApply`（类名与 `property_owner.cpp` 源文件经错误串 + .rdata 构建路径双出土）；调用链 140399aa0（Composite::onUpdate）→1403d51e0（op 分发）→142a7c1a0→142aae130→142abf4a0 全链钉死。
2. **★BitReader 类全解**：FUN_142ca1860 ctor{stream,bitsLeft_,byte_} / 142ca1900 read(n) MSB-first 无符号 / 142ca19a0 readSigned(n) 带符号扩展 / 142ca18e0 bitsRequired(n)——与 vanilla 0x24 通道同族同构（断言串 `.rdata` 出土）。
3. **★★op≥2 值格式定案**：L 字节体 = MSB-first 位流 `[1][bitsRequired(n₁) idx₁]…[0][bitsRequired(n_final) VALUE]` + **字节对齐类型化值**（setter=node->vt[4] 从流剩余字节读 DataType 线格式）；执行器断言全耗尽 → 总位数 ∈ (8(L-1), 8L]。**op=1 切片** = 两次 read(bitsRequired(width+1)) = [lo,hi] 切片区间对——首次字节级钉死。
4. **七类节点 vtable 终局表**：直读 exe 簇 0x1435df3e8-6b8，RTTI 全署名（BWRootNode/BWEntityNode/ClientDynComponentNode/ClientPrimitivePropertyNode/ClientCompositePropertyNode/ClientMethodCalleeNode/ServerMethodCallerNode）；全部 vt[0x58]=ret 桩（class-2 消息零体，0x32/0x37 共享结论）；vt[0x08]=节点类型标签，树哈希 [nid:4B][tag:1B] 进 MD5。
5. **分发架构终局**：0x36（64,165 包/场主力）→ `BW::ClientHub::processUpdateNode`（client_hub.cpp）`[u16 BE nid]→findNode(nid)→node->vt[0x60](stream)`；0x35（189 包/场）→ FUN_140e74040 class 分发（nid 高字节 class 0-5→hub 槽 11-15，class≥6 静默跳过仅耗 2B）。
6. **★玩家索引空间破译**：idx₁=32-61 = **30 个玩家**（15v15 全员）——b0 全偶根源 = w₁=6 时 bit7=路径终止符；b0=0xC0+2×player（30 唯一值 0xC0-0xFA 步长 2 铁证）；nid 0x07DD/0x08F1 族实证。
7. **★★死亡事件流破译**：死亡三联包（L=26 `[len][pickle {"deathOrder":N}]` + L=16 `[1][13B 记录]` + L=4 `u16 状态 1→2`）同 clk 到达；全语料 **76 条死亡事件**，deathOrder 按 clk 单调——击杀顺序语义级可读。
8. **Root 巨包破解**：t55 误标「op=0」族正名 = `BWRootNode::onUpdate` volatile delta 位图批量（树态 MD5→注册表查找→clist+位图+子消息链+浮点元组 -1.0/30.0/4.0/0.05），24/845 完美链式铺满（前缀段交错结构待续）。
9. **进度**：按字节加权理解度 94.09% → **94.31%**（0x37 理解度 0.75→0.90：架构+文法+值格式+死亡事件语义，余 Root 前缀文法与属性确名）。


---

# V34 增补（Task 57-b + 58-a · v40-v41 · ★★★★★0x37 语义终局 + clk 时间基翻案 + 0x0A/0x39 双通道）

在 V33 全量底座之上新增：

| 内容 | 说明 |
|---|---|
| `findings.md` | ★ 结论登记册 v41（新增 §36：★★★★★0x37 语义终局——idx₁↔eid↔花名册全链路 join / finalIdx 定案 / 「变换值」翻案；§37：★★★★★clk 单位翻案 / ★★★★0x0A 45B 源码级布局 + LSB 水印 / ★★★0x39 复制流结构全解） |
| `data_v37/` | Task 57-b 全套（86 条带姓名击杀 feed / idx₁ 身份映射表 58KB / L=16 击杀记录原始 86 条 / VEHICLES_INFO 字段语义统计 + t57 脚本×8） |
| `data_v38/` | Task 58-a 全套（clk=1/65536s 证据 / 0x0A 45B 布局验证 / 0x39 双 subtype 结构统计 + t58 脚本×2） |
| `scripts/t57_*.py` + `scripts/t58_*.py` | 增量 10 件（join×4 / L16 直读 / 字段统计 / frags 交叉验证 / 身份映射 / 0x39 双解析器） |

核心突破（Task 57-b · v40 §36 · 0x37 语义终局）：
1. **★★★★★idx₁↔eid↔花名册全链路 join**：idx₁ = 32 + roster_pos，全语料 84/84 零反例零失配（含 B 组场次）——0x37 玩家状态流全部可署名。
2. **★★★★finalIdx = VEHICLES_INFO 39 字段索引定案**（§30 花名册 FIXED_DICT）：38 __generation（22,250 条单调 0 反例，终值 23-175）/ 37 position（3,572 条 [i16 x][i16 y] 地图坐标 ±500，0x8000 哨兵）/ 33 frags（85）/ 30 deathInfo（84）/ 27 events（74）/ 1 isAlive（62）/ 7 isAvatarReady（300）。
3. **★★★★L=16 = deathInfo 击杀记录**：[nid][02][10][位流 idx1,fi=30][01][victimID][killerID][reasonID][equipmentID][numVehiclesAffected]——与花名册 13B 结构逐字节同构；86 条带姓名击杀 feed，84 敌杀 0 队杀（队伍独立验证）。
4. **★★★★「NRL 变换值」翻案**：27,341 条 L=6 主力 = __generation 计数器（81%）+ position i16 网格坐标（13.5%）——非车辆变换，Task 55/56 遗留数学定标问题以「非变换值」终局；§34.5 b1 选择器{98/94/1c/04/30}=fi{38/37/7/1/12}，低 2 位填充零=b1 偶数铁证根源。
5. **★★frags 交叉验证**：击杀→frags+1 对齐 38/39；frags 终值==击杀数 60/67（frags=真值，feed=镜像子集 86/220）；双勘误登记（t55_global3 旧分割 / v24 链 JSON B 组字段错位）。

核心突破（Task 58-a · v41 §37 · clk 时间基 + 0x0A/0x39）：
6. **★★★★★clk 单位破译：1/65536 秒（15.26µs）**——Δclk 峰{6553.6, 3276.8, 1638.4} = 0.1/0.05/0.025s 精确 + 0x07 战斗窗口 36.9e6=563s（ms 解释 10 小时荒谬）+ 死亡跨度 344s + E 纪元 12.9 天 uptime 自洽——推翻全项目 ms 假设，v23 倍速阶梯现象统一解释，全部时间线按 65.536 重算。
7. **★★★★0x0A 45B 源码级布局**（slot15=FUN_140586620，wg_replay_message_handler.cpp L0x622 逐指令）：[eid][ref][pos3f][B12B][yaw][pitch][roll][tail]；★yaw 铁证：运动方向-yaw 角差 p50=0.9°（n=3760）；pitch±25°/roll[-36°,+13°]；ref=avatar eid；★LSB 水印机制：FUN_140574540 每 4B 词最低位注入标记位（位表@+0x210），float 扰动≤1ULP。
8. **★★★0x39 复制流结构全解**：72B(0x30D6C3C4)=[16B 常量][f32 pos3][f32 vel3][f32][01 20] 运动学（pos 地图域 x/z±500、y=22-44m 低空，速度模量化{680..1000}）/ 41B(0x11D6C3C4) 紧凑状态 / seq 链 cur-prev=1 占 96.6% / 轨迹 1.8km 有界游弋=飞行物（宠物遥测假说）。
9. **进度**：按字节加权理解度 94.39% → **95.9%**（0x0A 0.95→0.97 +0.68% / 0x39 0.40→0.75 +0.87%；0x37 0.90→0.95 已计入 V33 后 57-b 轮）。


## V35 (2026-09-26) — Task 59-b: 0x0A B 12B 定案 ★★★★
- **B 12B = 悬挂车体(hull)位置偏移快照**——七重证据闭环:
  1. 回放端 FUN_14058a6b0 跳读 33B/45B 不对称(重建非必需, 客户端本地重算)
  2. Y 分量全 2 幂序列, 基 2⁻⁹ m(悬挂高度步进 2mm)
  3. B_y 637,317 条非零样本无一负值(车体悬于逻辑原点上方)
  4. X/Z 二分衰减链(阻尼回弹收敛系数 0.5), 基 q_xz=16416314×2⁻³⁰
  5. 每场 1-2 个运动且 B 全零实体=玩家本车(本地物理免报)
  6. 严格启停瞬态 |B| 不变(俯仰在 pitch/roll, 不改 hull 平均偏移)
  7. 排除项: 速度反馈 cos 对称展开/本体偏移投影 0.2%/姿态相关全零
- **tail u8 = 注入来源标志**: 97.5% 周期注入(volatileInjectionPeriodTicks=5)/2.53% 事件触发
- **LSB 水印密度定标**: 有效注入仅 ~0.005%(选择性翻转)
- 0x0A 通道理解度 0.97→0.985; **总体按字节加权理解度 95.9%→96.1%**


## V36 (2026-09-26) — Task 59-c: 0x39 对象身份定案 ★★★★★
- **0x39 宿主确名 = NetworkEntity(typeID=40) 剧情特效实体**（prefab_path 铁证）:
  - siegfried: 城市轰炸剧情——15 栋建筑 7.4 秒内依次 transition→destroyed（31 个事件 NE 全落 0x39 流窗口内）
  - WZ-219: 飞机坠毁剧情——双机 1.65s 先后坠毁（单机受创→摧毁 0.6s）
  - karelia×2: 地堡破坏剧情
- **"宠物遥测"假说推翻**: 72B 运动学（低空 22-44m + 1.8km 游弋）= 坠落物/碎片云遥测
- **clk 1/65536s 全通道时间线重述**: 0x39 特效窗口 437-552s = 战斗窗口 563s 的 78-98%
- 0x39 通道理解度 0.75→0.85; **总体按字节加权理解度 96.1%→96.4%**


## V37 (2026-09-26) — Task 59-d: karelia2 deathOrder -1 例定性 ★★★
- **karelia2 -1 例定性 = 流截止时序竞态**（Task 39 以来 5 轮交接的边缘项终结）:
  - 链 21 条（seq=1..21 连续、victim 全去重、21 死 9 生 attacker 自洽）= 服务器权威流，完整无异常
  - 第 21 杀（clk=1140333117）晚于 0x05 花名册快照流截止（clk=1140303626）0.45 秒——victim 的 isAlive=0 从未进入客户端观测面
  - 伴随 0x35 NRL 组件创建（同 clk）佐证击杀真实发生
- 连带修正: v24「220/221」的 isAlive 数据源 = 0x05 花名册终态快照（非结算 jsonl）


## V44 (2026-09-27 · Task 66) ★★★★★tid 空间终局翻案：wire tid = client index
- 用户事实「录制期 scripts.pkg ≡ scripts.7z」触发重审 → X 裁决与「tid=序位+49」定律双双作废，无版本差无注册洞
- wire tid = desc+0x82 第二索引空间（EntityType::init 全局表 DAT_14483e000 消费；三 decider slot2 三实现：实体版 CS 相位恒真不查脚本 / 动态版真查 scripts/client / 空间版恒真）
- tid 终图 v2：0=空间 + 1-40=CS 实体 + 41-50=10 扩展实体 + 51-157=107 有脚本动态组件 + 158+=扩展动态
- 结构性 wire 不可见三件套：ExtendedSPG / EnemyShotPredictorController / ArenaVehiclesInfo（无 client 脚本 → 无 client index）
- 五重证伪旧模型 + 全锚点复核零反例；五行改判：51=OwnVehicle(Task52 平反)/53=DogTag/54=DogTagsInfo/58=GunMarker/59=AtGunpoint；tid122=DualAccuracy 活槽
- data_v46：t66_wire_tid_终表.json（全 148 槽）+ t66_modelB_diff.json（12 tid 差异表）+ scripts_t66×4


## V45 (2026-09-27 · Task 67-a + 67-b) ★★★★★0x37 方法调用通道全破 + 深路径宿主定名
- Task 67-a (§47 v51)：gi9 12B×37 真身 = onBattleEvents(ARRAY<BATTLE_EVENT>) 参数流——ClientMethodCalleeNode::onUpdate (FUN_140399be0) + MethodArgs::createFromStream (FUN_142abd8e0) 引擎白盒；VEHICLE_HIT_DIRECTION 22B 定案；BATTLE_EVENT_TYPE 0-24 权威枚举 + unpackDamage/Crits/Visibility 位域公式 (BattleFeedbackCommon.py)；创建体方法段 = 子创建序槽号列表（§33 勘误反向）；具名战报 159KB（gi9 52 条：8 受击/37 事件/7 第六感/7 击杀，与 0x35 双通道同拍互证）
- Task 67-b (§48 v52)：路径位宽引擎定律 bitsRequired(n+1)（FUN_142abf620/650/680/6d0 三值读取器族白盒）；wire 属性序新锚（位2=vehicleGunReloadTime 17B、位17=targetVehicleID 5B）；41 条非镜像深路径宿主定名 = 本车战斗状态遥测（vehicleAmmoList 225 条 18B VEHICLE_AMMO 元素级更新：quantity 倒计时=开炮消耗、0xffff=无限弹、endTime=-1.0 哨兵）
- 理解度 96.8% → 97.0%；data_v47：t67_method_map.json 权威表 + t67_named_battle_log.json 具名战报 + scripts_t67×14


## V46 (2026-09-27 · Task 68) ★★★★★0x37 路径文法终局：op 三分配 + wire 属性序 + 动态数组叙事
- 引擎白盒全链：FUN_1403d51e0 分发终读（op==0→整值 / op≠0→路径读取器 isSlice=op==1）；vanilla property_change_reader.cpp 全文出土对照；EntityPropertyOwner vftable 0x14391f970（RTTI 链）；bitsRequired=ceil(log2(n)) 逐行核验
- 路径文法终版：op2=[1][属性跳][exit][元素号]+元素 / op1=[1][属性跳][exit][start][end]+元素序列（Python 切片赋值语义）；宽度 bitsRequired(len) 全程动态；§48.1「第二 6b」定案=固定 6bit 读取伪影；AVI 镜像 0bit 属性跳逐位统一
- wire 属性序 23 槽全表（创建包 bitmask×值结构双重验证）+ 客户端 def 序 0/1 对调铁证（NRL 索引空间=服务器权威，def 热修漂移）
- 动态数组状态机：弹药 293/293 + 设置 230/230 + 维修 33/33 + 损伤 28/35 字节精确；gi0 弹药全故事（空片插入建配弹→逐发消耗→装填事件）；vehicleSettings value=弹种切换与弹药互证
- 理解度 97.0% → 97.3%；data_v48：t68_0x37路径文法终局.json + scripts_t68×12


## V48 (2026-09-28 · Task 69R 重证轮) ★★★★★OwnVehicle 通道 100% 字节精确全解 + LSB 水印负载 32B 表 + 0x15 锚点定律〔V47 废弃重登〕
> **V47 废弃说明**：V47 包的 §50 为上下文丢失后补登记，存在失实（槽6 场数 54/8 场、gi5 冷却组漏项等 4 处），用户裁决废弃；V48 以 V46 包（findings v53 + worklog Task 68）为基准重跑 data_v49 全部脚本重证——t53 事件流 md5 级确定性重建、五支柱输出与存档 JSON 逐一 md5 相同、LSB 提取独立重实现二次验证（block0 dateTime 秒源 10/10）。版本链 V46 → V48。
- 槽6 vehicleDamageInfoList 终版：init_len=0 定案；「7 条失败」真身 = v4i 走器误框（vol/srch 误分段），非初始长度模型；**57 帧/9 场全字节精确**（t69a 直扫 54/8 场 + t69c 树重建补入 gi5 3 帧）；元素 10B [has][extra][dmgIdx][entity i32][equip u16][ext i8]，entity=攻击者 eid 入 0x05 空间，终态 22 元素（roster 2 / 0 十七 / gi5 三）
- OwnVehicle 方法调用边界互证回收 317 条/10 场（签名合法+边界对齐双约束）：onBattleEvents 233 / onObservedByEnemy 39（第六感）/ showOwnVehicleHitDirection 30（受击方向）…；子位↔mid 映射假设A 裁决 312/317（98.4%），子23-33 恰 11 方法子 + 子34=第 12 非方法子；9/11 方法观测（缺席=无重生两方法，与 §47 互证）；**通道合计回收 623 条 = 306 属性帧 + 317 方法调用**
- 23 槽全量审计：2517 候选 → 4 伪帧剔除 → **2513/2513 真帧 100% 字节精确**（11 场）；走器 v4i 丢帧 306（12.2%）分槽账全清；新建 8 槽解码器（3/8/10/13/14/19/21/22，槽17 为 §48 已有复用）；零流量槽 6 个（7/11/12/15/16/20）；**槽19 vehicleHealthInfo=本车血量遥测（11 场轨迹闭合，gi5/gi8 录制者死亡实锤 health→0）**
- LSB 水印负载定谳（指纹级遗留「LSB 位表 256 位」闭合）：0x15 唯一锚点定律（每场恰 1 包，clock=0，8B 载荷）+ 0x0A 9 词/0x05 6 词 LSB 按流序交织 → 32B 小端表 [u16 magic 0xF567][pad][session][flags][year-1900 时间戳][02 04 00][tail]；**时间戳双锚验证 10/11**（文件名分钟级 10/10 + block0 dateTime 秒源 10/10，独立重实现复验）；gi4 无注水三探针复验全负=表真缺失（新线索：0x15 byte6=00 注水激活标志候选）
- 创建包 8/11 字节精确：视野半径 316-524m / **gi5 双管冷却 4 组 5.6003/5.6003/2.5/1.0** / mid 序全场恒定
- 理解度 97.3% → 97.5%；data_v49：7 JSON（全槽终版 342KB/slot6/methods/create/LSB/gi4 终审/LSB×block0 对账）+ scripts_t69×18（含重证双验证器）
