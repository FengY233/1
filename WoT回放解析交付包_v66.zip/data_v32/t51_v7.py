#!/usr/bin/env python3
"""t51_v7.py — 解码器 v7: v6 + 记录数组候选
新增 val_cands: 'arr4x16' = [packedInt n≤64][n×8B (u16×4)] — tid=54 队伍分配表实证
"""
import sys, struct, json, time
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from t50_v5a import RND, read_len, clist
from t50_free import make_free_parser
from t51_v6 import make_v6, parse_roster_array

def make_v7(global_nodes, known_tids=frozenset(), maxvisit=200000):
    def parse_stream(stream):
        b = stream; n = len(b)
        if n < 2: return None
        visit = [0]
        nodes = dict(global_nodes)
        created = {}
        def reg(nid, rk):
            if nodes.get(nid) != rk:
                nodes[nid] = rk; created[nid] = rk
        def step(p, depth):
            if p >= n: return ('done', p)
            if n - p <= 2: return ('tail', p)
            if p + 3 > n: return None
            mcls = b[p]; mid = (b[p+1] << 8) | b[p+2]; q = p + 3
            if mcls > 6: return None
            visit[0] += 1
            if visit[0] > maxvisit: return None
            return dispatch(q, mcls, mid, depth + 1)
        def val_cands(p):
            out = []
            rem = n - p
            if rem <= 0: return out
            for L, f in ((4, 'u32'), (1, 'u8'), (2, 'u16'), (4, 'f32'), (8, 'f64'), (12, 'v3'), (16, 'v4')):
                if L <= rem: out.append((p + L, f))
            l = b[p]
            hdr = 4 if l == 0xff else 1
            if l == 0xff and rem >= 4:
                l = b[p+1] | (b[p+2] << 8) | (b[p+3] << 16)
            if hdr + l <= rem and l <= 200: out.append((p + hdr + l, 'str'))
            if rem >= 2 and b[p] in (2, 4, 6, 8):
                l2 = b[p+1]
                if 2 + l2 <= rem and l2 <= 200: out.append((p + 2 + l2, 'tagstr'))
                q = p + 2 + l2
                stops = []
                for qq in range(q, min(n - 3, q + 64) + 1):
                    if b[qq] == 0x02:
                        t = b[qq+1] | (b[qq+2] << 8)
                        if t in known_tids or t <= 160:
                            stops.append(qq)
                            if len(stops) >= 5: break
                if not stops: stops = [q]
                for s in stops: out.append((s, 't127'))
            if b[p] <= 12:
                m = b[p]; q = p + 1; ok = True
                for _ in range(m):
                    if q >= n: ok = False; break
                    ln, q2 = read_len(b, q)
                    if q2 + ln + 4 > n: ok = False; break
                    q = q2 + ln + 4
                if ok: out.append((q, 'hier'))
            cnt0 = b[p]
            if cnt0 <= 40:
                for esz, ef in ((4, 'arrf'), (1, 'arr8'), (2, 'arr16'), (12, 'arrv3'), (8, 'arr64')):
                    e = p + 1 + cnt0 * esz
                    if e <= n: out.append((e, ef))
            # ★ 新增: 记录数组 [n][n×8B] (tid=54 队伍分配表: u16×4)
            if 1 <= cnt0 <= 64 and p + 1 + cnt0 * 8 <= n:
                out.append((p + 1 + cnt0 * 8, 'arr4x16'))
            return out
        def rk2_creates(p, nid, depth):
            if p + 2 > n: return
            tid = b[p] | (b[p+1] << 8)
            if tid > 400: return
            l, p2 = read_len(b, p + 2)
            if p2 + l > n: return
            p3 = p2 + l
            r = clist(b, p3, nid, n)
            if r is None: return
            vals, flags, p4 = r
            nv = len(vals)
            cnt = [0]
            if tid == 123 and nv >= 1:
                rr = parse_roster_array(b, p4, n)
                if rr is not None:
                    recs, q = rr
                    cnt[0] += 1
                    yield q
            def gen_props(pp, i, np_, acc):
                if i == np_:
                    yield pp, tuple(acc); return
                if i in flags:
                    for e, fmt in val_cands(pp):
                        acc.append(fmt)
                        yield from gen_props(e, i + 1, np_, acc)
                        acc.pop()
                else:
                    yield from gen_props(pp, i + 1, np_, acc)
            for np_ in range(0, min(nv, 9)):
                if np_ > nv - 1: break
                for pp, fmts in gen_props(p4, 0, np_, []):
                    q = pp; ok = True
                    for j in range(np_, nv - 1):
                        if q >= n: ok = False; break
                        ln, q2 = read_len(b, q)
                        if q2 + ln > n: ok = False; break
                        q = q2 + ln
                    if not ok or q > n: continue
                    cnt[0] += 1
                    if cnt[0] > 300: return
                    yield q
                    if q < n and b[q] <= 6:
                        for e in create_bodies(q + 1, b[q], vals[-1], depth + 1):
                            if e is not None and e > q:
                                yield e
        def create_bodies(p, rk, nid, depth):
            if depth > 40: return
            if rk in (0, 6): yield p
            elif rk == 1:
                if p + 4 <= n: yield p + 4
            elif rk == 2:
                yield from rk2_creates(p, nid, depth)
            elif rk == 3:
                for L in (1, 2, 4, 8, 12, 16):
                    if p + L <= n: yield p + L
                if p < n:
                    l, q = read_len(b, p)
                    if q + l <= n and l <= 200: yield q + l
            elif rk == 4:
                if p + 1 > n: return
                kind = b[p]
                if kind <= 1:
                    l, q2 = read_len(b, p + 1)
                    if q2 + l <= n: yield q2 + l
                else:
                    for L in (1, 2, 4, 8):
                        if p + L <= n: yield p + L
            elif rk == 5:
                if p >= n: return
                l, q2 = read_len(b, p)
                if q2 + l <= n: yield q2 + l
        def dispatch(p, mcls, mid, depth):
            if depth > 60: return None
            if mcls == 0:
                if p + 3 > n: return None
                parent = (b[p] << 8) | b[p+1]; rk = b[p+2]
                if rk > 6: return None
                reg(mid, rk)
                for e in create_bodies(p + 3, rk, mid, depth):
                    r = step(e, depth)
                    if r is not None: return r
                return None
            elif mcls == 1:
                r = clist(b, p, mid, n)
                if r is None: return None
                vals, flags, q = r
                def rec(i, q2):
                    if i == len(vals):
                        return step(q2, depth)
                    if q2 + 1 > n: return None
                    rk = b[q2]
                    if rk > 6: return None
                    reg(vals[i], rk)
                    for e in create_bodies(q2 + 1, rk, vals[i], depth + 1):
                        r2 = rec(i + 1, e)
                        if r2 is not None: return r2
                    return None
                return rec(0, q)
            elif mcls in (2, 3, 5):
                return step(p, depth)
            elif mcls in (4, 6):
                rk = nodes.get(mid)
                if rk is None: return None
                if rk in (1, 2, 6): return step(p, depth)
                if rk == 3:
                    for L in (0, 1, 2, 4, 8, 12, 16):
                        if p + L <= n:
                            r = step(p + L, depth)
                            if r is not None: return r
                    if p < n:
                        l, q = read_len(b, p)
                        if q + l <= n and l <= 200:
                            return step(q + l, depth)
                    return None
                if rk == 4:
                    if p + 1 > n: return None
                    kind = b[p]
                    if kind <= 1:
                        l, q2 = read_len(b, p + 1)
                        if q2 + l > n: return None
                        return step(q2 + l, depth)
                    for L in (1, 2, 4, 8):
                        if p + L <= n:
                            r = step(p + L, depth)
                            if r is not None: return r
                    return None
                if rk == 0:
                    r = clist(b, p, mid, n)
                    if r is None: return None
                    vals, flags, q = r
                    nw = (len(vals) + 31) >> 5
                    if q + nw * 4 <= n:
                        r2 = step(q + nw * 4, depth)
                        if r2 is not None: return r2
                    return step(q, depth)
                return None
            return None
        mid0 = (b[0] << 8) | b[1]
        r = dispatch(2, 0, mid0, 0)
        if r is not None:
            global_nodes.update(created)
        return r
    return parse_stream

if __name__ == '__main__':
    pkgs_all = []; owner = []
    for gi, f in enumerate(RND):
        blocks, declared, slen, pkts = load(f)
        for t, c, pl in pkts:
            if t == 0x32: pkgs_all.append(pl[4:]); owner.append(gi)
    N = len(pkgs_all)
    known = set()
    for s in pkgs_all[:800]:
        for i in range(len(s) - 3):
            if s[i] == 0x02 and s[i+1] < 0xA0:
                known.add(s[i+1] | (s[i+2] << 8))
    known = {t for t in known if t <= 300}
    t0 = time.time()
    ok1 = 0; fails1 = []
    gnodes = {}; cur_g = -1
    for idx in range(N):
        if owner[idx] != cur_g:
            gnodes = {}; cur_g = owner[idx]
        p = make_v7(gnodes, known)
        r = p(pkgs_all[idx])
        if r is not None: ok1 += 1
        else: fails1.append(idx)
    print(f'Pass1(v7严格): {ok1}/{N} ({100*ok1/N:.2f}%) 耗时{time.time()-t0:.0f}s')
    t1 = time.time()
    free = make_free_parser(known)
    ok2 = 0; fails2 = []
    for idx in fails1:
        r, stats = free(pkgs_all[idx])
        if r is not None: ok2 += 1
        else: fails2.append(idx)
    total = ok1 + ok2
    print(f'Pass2(自由): +{ok2} → 总 {total}/{N} ({100*total/N:.2f}%) 耗时{time.time()-t1:.0f}s')
    print(f'剩余失败 {len(fails2)}: {fails2}')
    json.dump({'pass1_ok': ok1, 'pass2_fixed': ok2, 'total': total, 'n': N, 'fails_final': fails2},
              open('/tmp/wot/t51_v7_result.json', 'w'))
