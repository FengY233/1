#!/usr/bin/env python3
"""t51_fit2.py — tid=51 族拟合器 v2: 位置序贪心 + 记忆化 + 早剪枝"""
import sys, struct, json
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from t50_v5a import RND

pkgs = []; owner = []
for gi, f in enumerate(RND):
    blocks, declared, slen, pkts = load(f)
    for t, c, pl in pkts:
        if t == 0x32: pkgs.append(pl[4:]); owner.append(gi)

TRAILER = bytes.fromhex('04090a0203010506000708')

family = []
for idx, b in enumerate(pkgs):
    if len(b) < 60: continue
    if b[4] == 2 and b[5:8] == b'\x33\x00\x00' and b[8] == 0xa5 and b[9] == 0x82:
        ti = b.find(TRAILER)
        if ti > 0:
            mask = b[10:15]
            flags = set()
            for byte_i, mb in enumerate(mask):
                for bit in range(8):
                    if mb & (1 << bit): flags.add(byte_i * 8 + bit)
            family.append({'idx': idx, 'b': b, 'ti': ti, 'flags': flags})
print(f"tid=51 族: {len(family)} 包: {[x['idx'] for x in family]}")
for s in family:
    print(f"  #{s['idx']} len={len(s['b'])} ti={s['ti']} flags={sorted(s['flags'])}")

SZ = {'u8': 1, 'u16': 2, 'u32': 4, 'f32': 4, 'i16': 2, 'tf32': 5, 'tf64': 9, 'f64': 8, 'v3': 12, 'tu32': 5, 't2u32f64': 15}
FMTS = ['f32', 'tf32', 'u8', 'tf64', 'f64', 'u32', 'u16', 'v3', 'tu32', 't2u32f64']

ALL_POS = sorted(set().union(*[s['flags'] for s in family]))
print(f'全部位置: {ALL_POS}')

dead = set()
def dfs(pi, states, fmt_map):
    key = (pi, tuple(sorted((s['idx'], s['p'], s['ki']) for s in states)))
    if key in dead: return None
    if pi == len(ALL_POS):
        for s in states:
            if s['p'] != s['ti'] or s['ki'] != len(s['pos_list']):
                dead.add(key); return None
        return dict(fmt_map)
    pos = ALL_POS[pi]
    act = [s for s in states if s['ki'] < len(s['pos_list']) and s['pos_list'][s['ki']] == pos]
    for f in FMTS:
        L = SZ[f]
        ok = True
        for s in act:
            if s['p'] + L > s['ti']: ok = False; break
        if not ok: continue
        saved = [(s['p'], s['ki']) for s in act]
        for s in act:
            s['p'] += L; s['ki'] += 1
        # 剪枝: 已完成的包必须 p==ti; 未完成的 p<ti
        bad = any((s['ki'] == len(s['pos_list'])) != (s['p'] == s['ti']) for s in states)
        if not bad:
            fmt_map[pos] = f
            r = dfs(pi + 1, states, fmt_map)
            if r is not None: return r
            del fmt_map[pos]
        for s, (pp, kk) in zip(act, saved):
            s['p'] = pp; s['ki'] = kk
    dead.add(key)
    return None

for s in family:
    s['pos_list'] = sorted(f for f in s['flags'] if f in set(ALL_POS))
    s['p'] = 15; s['ki'] = 0

r = dfs(0, family, {})
if r:
    print(f'\n★★★ 拟合成功: 位置→格式 = {r}')
    # 验证: 逐包打印消费细节
    for s in family:
        p = 15
        print(f"  #{s['idx']}: ", end='')
        for pos in s['pos_list']:
            f = r[pos]; L = SZ[f]
            raw = s['b'][p:p+L].hex(' ')
            print(f'[{pos}:{f} {raw}]', end=' ')
            p += L
        print(f'→ p={p} ti={s["ti"]} {"✓" if p == s["ti"] else "✗"}')
else:
    print('\n✗ 无解 — 需要扩展格式池')
