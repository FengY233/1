#!/usr/bin/env python3
"""t51_roster_dump.py — 花名册语义提取演示: 10 场随机战玩家全表解码
AvatarVehiclesInfo.vehiclesInfo = ARRAY<VEHICLES_INFO>(39字段) — 完整玩家表
产出: /tmp/wot/t51_roster_dump.json
"""
import sys, json, pickle
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from t50_v5a import RND
from t51_v6 import parse_roster_array

pkgs = []; owner = []
for gi, f in enumerate(RND):
    blocks, declared, slen, pkts = load(f)
    for t, c, pl in pkts:
        if t == 0x32: pkgs.append(pl[4:]); owner.append(gi)

out = {}
total_players = 0
for idx, b in enumerate(pkgs):
    if len(b) < 4000: continue
    if not (b[14] == 2 and b[15:18] == b'\x7b\x00\x00' and b[21] == 0x1e): continue
    rr = parse_roster_array(b, 21, len(b))
    if rr is None:
        print(f'#{idx}: 花名册解析失败?!'); continue
    recs, q = rr
    gi = owner[idx]
    players = []
    for r in recs:
        try: pmi = pickle.loads(r['personalMissionInfo']) if r['personalMissionInfo'] else None
        except Exception: pmi = None
        players.append({
            'name': r['name'].decode('utf-8', 'replace'),
            'fakeName': r['fakeName'].decode('utf-8', 'replace'),
            'vehicleID': r['vehicleID'],
            'team': r['team'],
            'isAlive': r['isAlive'],
            'accountDBID': r['accountDBID'],
            'avatarSessionID': r['avatarSessionID'].decode('ascii', 'replace'),
            'clanAbbrev': r['clanAbbrev'].decode('utf-8', 'replace'),
            'maxHealth': r['maxHealth'],
            'compDescr_len': len(r['compDescr']),
            'outfitCD_len': len(r['outfitCD']),
            'missions': pmi if isinstance(pmi, dict) else str(pmi)[:40],
            'frags': r['frags'], 'tkills': r['tkills'],
            'deathInfo': r.get('deathInfo'),
            'vehPostProgression': r['vehPostProgression'],
        })
        total_players += 1
    out[f'replay{gi}_pkg{idx}'] = {
        'eid': int.from_bytes(b[5:9], 'little'),
        'players': players,
    }
    teams = {}
    for p in players: teams[p['team']] = teams.get(p['team'], 0) + 1
    print(f'场{gi} #{idx}: {len(players)} 玩家, 队伍分布 {teams}, 首玩家: {players[0]["name"]} (vid={players[0]["vehicleID"]}, HP={players[0]["maxHealth"]}, DBID={players[0]["accountDBID"]})')

json.dump(out, open('/tmp/wot/t51_roster_dump.json', 'w'), ensure_ascii=False, indent=1)
print(f'\n共 {len(out)} 场, {total_players} 玩家记录 → /tmp/wot/t51_roster_dump.json')
