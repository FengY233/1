#!/usr/bin/env python3
"""t51_v6.py — 解码器 v6: 引擎真模型全局版
v5(99.56%) → v6 三大升级:
  1. class0 修正: node id = msg.id(头部), body 2B 是 parent — v4/v5 注册 objId 是错的(差一条消息)
  2. 跨包全局节点表: 同场顺序处理, nodes(nid→rk) 持久 (引擎 hub 节点表跨包持久, §29.3)
  3. 花名册文法: tid=123 (AvatarVehiclesInfo) prop0 = ARRAY<VEHICLES_INFO> 39字段定长文法
     (10 个 5.5-6.1KB 大包 = 整包一个属性值, v5 候选集无记录数组 → 全失败)
产出: /tmp/wot/t51_v6_result.json
"""
import sys, struct, json, time
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from t50_v5a import RND, read_len, clist, make_parser as make_v5a
from collections import Counter

# ---------- VEHICLES_INFO 定长文法 (alias.xml 全解, 29/29 元素两场验证) ----------
def parse_vehicles_info(b, p, n):
    """39 字段 FIXED_DICT, 全自定界. 返回 (记录dict, 末偏移) 或 (None, 卡点)"""
    o = {}; q = p
    def take(k):
        return q < n
    if q + 5 > n: return None, 'head'
    o['vehicleID'] = struct.unpack_from('<i', b, q)[0]; q += 4
    o['isAlive'] = b[q]; q += 1
    if o['isAlive'] > 1: return None, 'isAlive'
    for f in ('outfitCD', 'compDescr', 'fakeName', 'name'):
        l, q2 = read_len(b, q)
        if l > 200 or q2 + l > n: return None, f
        o[f] = bytes(b[q2:q2+l]); q = q2 + l
    if q + 3 + 8 > n: return None, 'flags'
    o['team'] = b[q]; o['isAvatarReady'] = b[q+1]; o['isTeamKiller'] = b[q+2]; q += 3
    if o['team'] > 3 or o['isAvatarReady'] > 1 or o['isTeamKiller'] > 1: return None, 'flags2'
    o['accountDBID'] = struct.unpack_from('<Q', b, q)[0]; q += 8
    l, q2 = read_len(b, q)
    if l > 32 or q2 + l > n: return None, 'clanAbbrev'
    o['clanAbbrev'] = bytes(b[q2:q2+l]); q = q2 + l
    if q + 8 + 4 + 3 > n: return None, 'clan'
    o['clanDBID'] = struct.unpack_from('<q', b, q)[0]; q += 8
    o['prebattleID'] = struct.unpack_from('<i', b, q)[0]; q += 4
    o['isPrebattleCreator'] = b[q]; o['forbidInBattleInvitations'] = b[q+1]; o['igrType'] = b[q+2]; q += 3
    if o['isPrebattleCreator'] > 1 or o['forbidInBattleInvitations'] > 1: return None, 'clan2'
    l, q2 = read_len(b, q)
    if l > 40 or q2 + l > n: return None, 'avatarSessionID'
    o['avatarSessionID'] = bytes(b[q2:q2+l]); q = q2 + l
    if q + 4 + 2 + 4 + 4 > n: return None, 'badge4'
    o['overriddenBadge'] = b[q]; o['customRoleSlotTypeId'] = b[q+1]
    o['botDisplayStatus'] = b[q+2]; o['teamPanelMode'] = b[q+3]; q += 4
    o['maxHealth'] = struct.unpack_from('<h', b, q)[0]; q += 2
    if not (0 < o['maxHealth'] < 12000): return None, 'maxHealth'
    o['prestigeLevel'] = struct.unpack_from('<i', b, q)[0]; q += 4
    o['prestigeGradeMarkID'] = struct.unpack_from('<i', b, q)[0]; q += 4
    for f in ('vehPostProgression', 'personalMissionIDs'):
        cnt, q2 = read_len(b, q)
        if cnt > 64 or q2 + 4 * cnt > n: return None, f
        o[f] = [struct.unpack_from('<i', b, q2 + 4*i)[0] for i in range(cnt)]; q = q2 + 4 * cnt
    for f in ('personalMissionInfo', 'events', 'badges'):
        l, q2 = read_len(b, q)
        if l > 400 or q2 + l > n: return None, f
        o[f] = bytes(b[q2:q2+l]); q = q2 + l
    cnt, q2 = read_len(b, q)          # ranked TUPLE<UINT16>
    if cnt > 8 or q2 + 2 * cnt > n: return None, 'ranked'
    o['ranked'] = [struct.unpack_from('<H', b, q2 + 2*i)[0] for i in range(cnt)]; q = q2 + 2 * cnt
    hv = b[q]; q += 1                 # deathInfo allowNone → hasValues
    if hv > 1: return None, 'deathInfo'
    if hv:
        if q + 13 > n: return None, 'deathInfo2'
        o['deathInfo'] = {
            'victimID': struct.unpack_from('<i', b, q)[0],
            'killerID': struct.unpack_from('<i', b, q+4)[0],
            'reasonID': b[q+8], 'equipmentID': struct.unpack_from('<h', b, q+9)[0],
            'numVehiclesAffected': struct.unpack_from('<h', b, q+11)[0]}
        q += 13
    if q + 25 > n: return None, 'tail'
    o['respawnID'] = struct.unpack_from('<I', b, q)[0]; q += 4
    o['stFrags'] = struct.unpack_from('<I', b, q)[0]; q += 4
    o['frags'] = struct.unpack_from('<h', b, q)[0]; q += 2
    o['activePetID'] = struct.unpack_from('<i', b, q)[0]; q += 4
    o['tkills'] = struct.unpack_from('<h', b, q)[0]; q += 2
    o['fogOfWar'] = b[q]; q += 1
    o['position'] = (struct.unpack_from('<h', b, q)[0], struct.unpack_from('<h', b, q+2)[0]); q += 4
    o['__generation'] = struct.unpack_from('<I', b, q)[0]; q += 4
    return o, q

def parse_roster_array(b, p, n):
    """ARRAY<VEHICLES_INFO> = [packedInt n][n×elem]. 返回 (记录列表, 末偏移) 或 None"""
    cnt, q = read_len(b, p)
    if not (1 <= cnt <= 40): return None
    recs = []
    for i in range(cnt):
        r, q2 = parse_vehicles_info(b, q, n)
        if r is None: return None
        recs.append(r); q = q2
    return recs, q

# ---------- v6 全局解析器 ----------
def make_v6(global_nodes, known_tids=frozenset(), maxvisit=200000, fix_class0=True, use_global=True):
    """global_nodes: 同场持久节点表 (跨调用共享, 成功时合并增量)
    fix_class0: class0 注册键修正 (False=v5 行为: objId)
    use_global: class4/6 查全局表 (False=仅本包)"""
    def parse_stream(stream):
        b = stream; n = len(b)
        if n < 2: return None
        visit = [0]
        nodes = dict(global_nodes) if use_global else {}
        created = {}                    # 本包新增 (成功时合并)
        def reg(nid, rk):
            if nid not in nodes:
                nodes[nid] = rk; created[nid] = rk
            elif nodes[nid] != rk:
                nodes[nid] = rk; created[nid] = rk
        def step(p, depth):
            if p >= n: return ('done', p)
            if n - p <= 2: return ('tail', p)
            if p + 3 > n: return None
            mcls = b[p]; mid = (b[p+1] << 8) | b[p+2]; q = p + 3
            if mcls > 6: return None
            visit[0] += 1
            if visit[0] > maxvisit: return None
            return dispatch(q, mcls, mid, depth + 1)
        def val_cands(p):
            out = []
            rem = n - p
            if rem <= 0: return out
            for L, f in ((4, 'u32'), (1, 'u8'), (2, 'u16'), (4, 'f32'), (8, 'f64'), (12, 'v3'), (16, 'v4')):
                if L <= rem: out.append((p + L, f))
            l = b[p]
            hdr = 4 if l == 0xff else 1
            if l == 0xff and rem >= 4:
                l = b[p+1] | (b[p+2] << 8) | (b[p+3] << 24 << 0) if False else b[p+1] | (b[p+2] << 8) | (b[p+3] << 16)
            if hdr + l <= rem and l <= 200: out.append((p + hdr + l, 'str'))
            if rem >= 2 and b[p] in (2, 4, 6, 8):
                l2 = b[p+1]
                if 2 + l2 <= rem and l2 <= 200: out.append((p + 2 + l2, 'tagstr'))
                q = p + 2 + l2
                stops = []
                for qq in range(q, min(n - 3, q + 64) + 1):
                    if b[qq] == 0x02:
                        t = b[qq+1] | (b[qq+2] << 8)
                        if t in known_tids or t <= 160:
                            stops.append(qq)
                            if len(stops) >= 5: break
                if not stops: stops = [q]
                for s in stops: out.append((s, 't127'))
            if b[p] <= 12:
                m = b[p]; q = p + 1; ok = True
                for _ in range(m):
                    if q >= n: ok = False; break
                    ln, q2 = read_len(b, q)
                    if q2 + ln + 4 > n: ok = False; break
                    q = q2 + ln + 4
                if ok: out.append((q, 'hier'))
            cnt0 = b[p]
            if cnt0 <= 40:
                for esz, ef in ((4, 'arrf'), (1, 'arr8'), (2, 'arr16'), (12, 'arrv3'), (8, 'arr64')):
                    e = p + 1 + cnt0 * esz
                    if e <= n: out.append((e, ef))
            return out
        def rk2_creates(p, nid, depth):
            if p + 2 > n: return
            tid = b[p] | (b[p+1] << 8)
            if tid > 400: return
            l, p2 = read_len(b, p + 2)
            if p2 + l > n: return
            p3 = p2 + l
            r = clist(b, p3, nid, n)
            if r is None: return
            vals, flags, p4 = r
            nv = len(vals)
            cnt = [0]
            # ★ 花名册快道: tid=123 prop0 = ARRAY<VEHICLES_INFO> 确定性解析
            if tid == 123 and nv >= 1:
                rr = parse_roster_array(b, p4, n)
                if rr is not None:
                    recs, q = rr
                    # 方法段 vals[N_props..nv-2], N_props=1 → 空; rk6 零读 → 创建体结束于 q
                    cnt[0] += 1
                    yield q
            def gen_props(pp, i, np_, acc):
                if i == np_:
                    yield pp, tuple(acc); return
                if i in flags:
                    for e, fmt in val_cands(pp):
                        acc.append(fmt)
                        yield from gen_props(e, i + 1, np_, acc)
                        acc.pop()
                else:
                    yield from gen_props(pp, i + 1, np_, acc)
            for np_ in range(0, min(nv, 9)):
                if np_ > nv - 1: break
                for pp, fmts in gen_props(p4, 0, np_, []):
                    q = pp; ok = True
                    for j in range(np_, nv - 1):
                        if q >= n: ok = False; break
                        ln, q2 = read_len(b, q)
                        if q2 + ln > n: ok = False; break
                        q = q2 + ln
                    if not ok or q > n: continue
                    cnt[0] += 1
                    if cnt[0] > 300: return
                    yield q
                    if q < n and b[q] <= 6:
                        for e in create_bodies(q + 1, b[q], vals[-1], depth + 1):
                            if e is not None and e > q:
                                yield e
        def create_bodies(p, rk, nid, depth):
            if depth > 40: return
            if rk in (0, 6): yield p
            elif rk == 1:
                if p + 4 <= n: yield p + 4
            elif rk == 2:
                yield from rk2_creates(p, nid, depth)
            elif rk == 3:
                for L in (1, 2, 4, 8, 12, 16):
                    if p + L <= n: yield p + L
                if p < n:
                    l, q = read_len(b, p)
                    if q + l <= n and l <= 200: yield q + l
            elif rk == 4:
                if p + 1 > n: return
                kind = b[p]
                if kind <= 1:
                    l, q2 = read_len(b, p + 1)
                    if q2 + l <= n: yield q2 + l
                else:
                    for L in (1, 2, 4, 8):
                        if p + L <= n: yield p + L
            elif rk == 5:
                if p >= n: return
                l, q2 = read_len(b, p)
                if q2 + l <= n: yield q2 + l
        def dispatch(p, mcls, mid, depth):
            if depth > 60: return None
            if mcls == 0:
                if p + 3 > n: return None
                parent = (b[p] << 8) | b[p+1]; rk = b[p+2]
                if rk > 6: return None
                reg(mid if fix_class0 else parent, rk)   # ★ 修正: node id = msg.id (头部)
                for e in create_bodies(p + 3, rk, mid if fix_class0 else parent, depth):
                    r = step(e, depth)
                    if r is not None: return r
                return None
            elif mcls == 1:
                r = clist(b, p, mid, n)
                if r is None: return None
                vals, flags, q = r
                def rec(i, q2):
                    if i == len(vals):
                        return step(q2, depth)
                    if q2 + 1 > n: return None
                    rk = b[q2]
                    if rk > 6: return None
                    reg(vals[i], rk)
                    for e in create_bodies(q2 + 1, rk, vals[i], depth + 1):
                        r2 = rec(i + 1, e)
                        if r2 is not None: return r2
                    return None
                return rec(0, q)
            elif mcls in (2, 3, 5):
                return step(p, depth)
            elif mcls in (4, 6):
                rk = nodes.get(mid)             # ★ 全局查找
                if rk is None: return None
                if rk in (1, 2, 6): return step(p, depth)
                if rk == 3:
                    for L in (0, 1, 2, 4, 8, 12, 16):
                        if p + L <= n:
                            r = step(p + L, depth)
                            if r is not None: return r
                    if p < n:
                        l, q = read_len(b, p)
                        if q + l <= n and l <= 200:
                            return step(q + l, depth)
                    return None
                if rk == 4:
                    if p + 1 > n: return None
                    kind = b[p]
                    if kind <= 1:
                        l, q2 = read_len(b, p + 1)
                        if q2 + l > n: return None
                        return step(q2 + l, depth)
                    for L in (1, 2, 4, 8):
                        if p + L <= n:
                            r = step(p + L, depth)
                            if r is not None: return r
                    return None
                if rk == 0:
                    r = clist(b, p, mid, n)
                    if r is None: return None
                    vals, flags, q = r
                    nw = (len(vals) + 31) >> 5
                    if q + nw * 4 <= n:
                        r2 = step(q + nw * 4, depth)
                        if r2 is not None: return r2
                    return step(q, depth)
                return None
            return None
        mid0 = (b[0] << 8) | b[1]
        r = dispatch(2, 0, mid0, 0)
        if r is not None and use_global:
            global_nodes.update(created)       # 成功 → 合并增量进全局表
        return r
    return parse_stream

# ---------- 主流程: 同场顺序全局解码 ----------
if __name__ == '__main__':
    import sys as _s
    MODE = _s.argv[1] if len(_s.argv) > 1 else 'full'
    # MODE: full=修正+全局 | fix=仅修正 | roster=仅花名册(v5行为+花名册)
    pkgs_all = []; owner = []
    for gi, f in enumerate(RND):
        blocks, declared, slen, pkts = load(f)
        for t, c, pl in pkts:
            if t == 0x32:
                pkgs_all.append(pl[4:]); owner.append(gi)
    N = len(pkgs_all)
    print(f'0x32 包总数: {N} (场数 {len(RND)})')

    known = set()
    for s in pkgs_all[:800]:
        for i in range(len(s) - 3):
            if s[i] == 0x02 and s[i+1] < 0xA0:
                known.add(s[i+1] | (s[i+2] << 8))
    known = {t for t in known if t <= 300}

    t0 = time.time()
    ok = 0; fails = []; roster_ok = 0
    gnodes = {}
    cur_g = -1
    fc = MODE != 'roster'
    ug = MODE == 'full'
    for idx in range(N):
        if owner[idx] != cur_g:            # 新场 → 重置全局表
            gnodes = {}; cur_g = owner[idx]
        p = make_v6(gnodes, known, fix_class0=fc, use_global=ug)
        r = p(pkgs_all[idx])
        if r is not None:
            ok += 1
            if len(pkgs_all[idx]) > 4000: roster_ok += 1
        else:
            fails.append(idx)
    print(f'v6[{MODE}]: {ok}/{N} ({100*ok/N:.2f}%) 耗时{time.time()-t0:.0f}s')
    print(f'大包(>4KB)通过: {roster_ok}')
    print(f'剩余失败 {len(fails)}: {fails}')
    json.dump({'ok': ok, 'n': N, 'fails': fails}, open('/tmp/wot/t51_v6_result.json', 'w'))
