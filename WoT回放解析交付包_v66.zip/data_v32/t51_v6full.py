#!/usr/bin/env python3
"""t51_v6full.py — v6 两遍制终版: v6 严格(全局+class0修正+花名册) + 自由长度兜底
v5final(99.56%) → v6full 预期: +10 花名册大包 → ~99.7%+
"""
import sys, json, time
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from t50_v5a import RND
from t50_free import make_free_parser
from t51_v6 import make_v6

pkgs_all = []; owner = []
for gi, f in enumerate(RND):
    blocks, declared, slen, pkts = load(f)
    for t, c, pl in pkts:
        if t == 0x32:
            pkgs_all.append(pl[4:]); owner.append(gi)
N = len(pkgs_all)

known = set()
for s in pkgs_all[:800]:
    for i in range(len(s) - 3):
        if s[i] == 0x02 and s[i+1] < 0xA0:
            known.add(s[i+1] | (s[i+2] << 8))
known = {t for t in known if t <= 300}

t0 = time.time()
ok1 = 0; fails1 = []
gnodes = {}; cur_g = -1
for idx in range(N):
    if owner[idx] != cur_g:
        gnodes = {}; cur_g = owner[idx]
    p = make_v6(gnodes, known)
    r = p(pkgs_all[idx])
    if r is not None: ok1 += 1
    else: fails1.append(idx)
print(f'Pass1(v6严格): {ok1}/{N} ({100*ok1/N:.2f}%) 耗时{time.time()-t0:.0f}s')

t1 = time.time()
free = make_free_parser(known)
ok2 = 0; fails2 = []
for idx in fails1:
    r, stats = free(pkgs_all[idx])
    if r is not None: ok2 += 1
    else: fails2.append(idx)
total = ok1 + ok2
print(f'Pass2(自由): +{ok2} → 总 {total}/{N} ({100*total/N:.2f}%) 耗时{time.time()-t1:.0f}s')
print(f'剩余失败 {len(fails2)}: {fails2}')
json.dump({'pass1_ok': ok1, 'pass2_fixed': ok2, 'total': total, 'n': N, 'fails_final': fails2},
          open('/tmp/wot/t51_v6full_result.json', 'w'))
