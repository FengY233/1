#!/usr/bin/env python3
"""t51_recon.py — Task 51-① 侦察: 30 个 v5 终版失败包的卡死点解剖
目标: 确认失败根因分类(跨包 class2 大 id 引用 / class4-6 未知 mid / b0>=6 updateNode / 未知值格式)
并扫描同场更早包中是否存在被引用 id 的创建证据
"""
import sys, glob, struct, json
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from t50_dissect import make_tracer, RND
from collections import Counter

# 1) 载入全部 0x32 包, 保留 (replay_idx, flat_idx) 映射 — 顺序与 v5final 完全一致
pkgs = []       # flat list, 与 v5final 相同的顺序
owner = []      # replay_idx per pkg
for gi, f in enumerate(RND):
    blocks, declared, slen, pkts = load(f)
    for t, c, pl in pkts:
        if t == 0x32:
            pkgs.append(pl[4:])
            owner.append(gi)
print(f'0x32 包总数: {len(pkgs)} (场数 {len(RND)})')

fails = json.load(open('/tmp/wot/t50_v5_result.json'))['fails_final']

known = set()
for s in pkgs[:800]:
    for i in range(len(s) - 3):
        if s[i] == 0x02 and s[i+1] < 0xA0:
            known.add(s[i+1] | (s[i+2] << 8))
known = {t for t in known if t <= 300}

tr = make_tracer(known)

def hexd(b, p, w=28):
    return ' '.join(f'{x:02x}' for x in b[max(0,p-4):p+w])

# 2) 逐失败包解剖
cat = Counter(); ref_ids = Counter(); detail = []
for idx in fails:
    b = pkgs[idx]; n = len(b)
    r, st = tr(b)
    mo = st['maxoff']
    evs = st['ev']
    # 最深消息事件
    msgs = [(o, d) for o, d in evs if d.startswith('msg cls=')]
    last_msg = msgs[-1] if msgs else None
    # 卡死点字节
    at = min(mo, n)
    head = b[at:at+3]
    desc_bits = []
    if at + 3 <= n:
        mcls = b[at]; mid = (b[at+1] << 8) | b[at+2]
        desc_bits.append(f'b0={mcls} id=0x{mid:04x}')
        if mcls > 6:
            cat['updateNode(b0>=6)'] += 1
            ref_ids[f'u24:{b[at]<<16|b[at+1]<<8|b[at+2]:06x}'] += 1
        elif mcls == 2:
            cat['class2 ref'] += 1
            ref_ids[mid] += 1
        elif mcls in (4, 6):
            cat[f'class{mcls} ref'] += 1
            ref_ids[mid] += 1
        else:
            cat[f'class{mcls}'] += 1
    else:
        cat['EOF-adjacent'] += 1
    detail.append((idx, n, mo, last_msg, desc_bits, hexd(b, at)))
    print(f'--- #{idx} len={n} maxoff={mo}/{n} last_msg={last_msg}')
    print(f'    卡点: {desc_bits} | 前4B..后28B: {hexd(b, at)}')
    for o, d in evs[-5:]:
        print(f'    @{o}: {d}')

print('\n=== 失败分类 ===')
for k, v in cat.most_common(): print(f'  {k}: {v}')
print('\n=== 被引用 id 统计 ===')
for k, v in ref_ids.most_common(20): print(f'  0x{k:04x}: {v}' if isinstance(k, int) else f'  {k}: {v}')

# 3) 跨包创建证据: 对每个被引用 id, 在同场更早包中找 3 字节 [00/02][hi][lo] 或裸 [hi][lo] 头
print('\n=== 跨包创建证据扫描 ===')
ev_found = 0; tot = 0
for idx in fails:
    b = pkgs[idx]; n = len(b)
    r, st = tr(b)
    at = min(st['maxoff'], n)
    if at + 3 > n: continue
    mcls = b[at]; mid = (b[at+1] << 8) | b[at+2]
    if mcls > 6 or mcls in (0, 1, 3, 5): continue
    tot += 1
    g = owner[idx]
    pat = bytes([mid >> 8, mid & 0xff])
    hits = []
    for j in range(idx - 1, -1, -1):
        if owner[j] != g: break
        s = pkgs[j]
        # class0/2/4/6 头 [cls][hi][lo] 或 class1 头 [01][hi][lo]
        for pref in (bytes([mcls]), b'\x00', b'\x01'):
            i = s.find(pref + pat)
            if i >= 0:
                hits.append((j, i, s[i:i+8].hex()))
                break
        if hits: break
    if hits:
        ev_found += 1
        print(f'  #{idx} 引用 0x{mid:04x} (cls{mcls}) → 同场更早包#{hits[0][0]} @{hits[0][1]}: {hits[0][2]}')
    else:
        # 扩展: 找 clist 值域内的裸模式(弱证据)
        weak = []
        for j in range(idx - 1, -1, -1):
            if owner[j] != g: break
            if pat in pkgs[j]:
                weak.append(j)
        print(f'  #{idx} 引用 0x{mid:04x} (cls{mcls}) → 无 3B 头证据; 裸 2B 出现于包 {weak[:5]}')
print(f'\n引用扫描: {ev_found}/{tot} 有同场更早创建头证据')
