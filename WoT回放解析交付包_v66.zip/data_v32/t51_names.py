#!/usr/bin/env python3
"""t51_names.py — 失败包玩家名锚点解剖: 提取 [len][name] 对 + 名字间字节模式"""
import sys, glob, struct, json
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from t50_dissect import RND
from collections import Counter

pkgs = []; owner = []
for gi, f in enumerate(RND):
    blocks, declared, slen, pkts = load(f)
    for t, c, pl in pkts:
        if t == 0x32:
            pkgs.append(pl[4:]); owner.append(gi)

fails = json.load(open('/tmp/wot/t50_v5_result.json'))['fails_final']

def is_name(b):
    """可打印 ASCII/UTF8 名字判定"""
    try:
        s = b.decode('utf-8')
    except Exception:
        return False
    if not (3 <= len(s) <= 28): return False
    printable = sum(1 for ch in s if ch.isprintable())
    return printable == len(s) and sum(1 for ch in s if ord(ch) < 128) >= max(2, len(s) - 4)

def find_names(b):
    """所有 [u8 len][name] 位置"""
    out = []
    for i in range(len(b) - 3):
        l = b[i]
        if 3 <= l <= 28 and i + 1 + l <= len(b):
            if is_name(b[i+1:i+1+l]):
                out.append((i, l, b[i+1:i+1+l].decode('utf-8', 'replace')))
    return out

for idx in fails:
    b = pkgs[idx]
    if len(b) < 3000: continue
    names = find_names(b)
    if len(names) < 4: continue
    print(f'=== #{idx} len={len(b)} 名字数={len(names)} ===')
    # 名字对间隔模式: 取前 8 个名字
    prev_end = None
    for (pos, l, s) in names[:10]:
        if prev_end is not None:
            gap = b[prev_end:pos]
            print(f'  gap({len(gap)}B): {gap.hex(" ")}')
        print(f'  @{pos} [{l}] "{s}"')
        prev_end = pos + 1 + l
    # 连续同名对检测
    pairs = sum(1 for i in range(len(names)-1) if names[i][2] == names[i+1][2] and names[i+1][0] == names[i][0] + names[i][1] + 1)
    print(f'  紧邻同名对: {pairs}')
    print()
