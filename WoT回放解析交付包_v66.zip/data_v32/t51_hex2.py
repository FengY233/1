#!/usr/bin/env python3
"""t51_hex2.py — 失败大包头部解剖 + tid=123 组件的跨包对照(成功 vs 失败)"""
import sys, glob, struct, json
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from t50_dissect import RND
from collections import Counter

pkgs = []; owner = []
for gi, f in enumerate(RND):
    blocks, declared, slen, pkts = load(f)
    for t, c, pl in pkts:
        if t == 0x32:
            pkgs.append(pl[4:]); owner.append(gi)

fails = set(json.load(open('/tmp/wot/t50_v5_result.json'))['fails_final'])

def hd(b, a=0, e=64, base=0):
    out = []
    for i in range(a, min(e, len(b)), 16):
        row = b[i:i+16]
        hexs = ' '.join(f'{x:02x}' for x in row)
        asc = ''.join(chr(x) if 32 <= x < 127 else '.' for x in row)
        out.append(f'{base+i:5d}  {hexs:<47}  {asc}')
    return '\n'.join(out)

# 1) 失败大包头 80B
for idx in sorted(fails):
    b = pkgs[idx]
    if len(b) > 3000:
        print(f'=== #{idx} len={len(b)} 前80B ===')
        print(hd(b, 0, 80))
        print()

# 2) 找成功的、含 rk2 tid=123 的大包对照
print('=== 对照: 成功包中含 tid=123 (7b 00) 的样本 ===')
cnt = 0
for idx, b in enumerate(pkgs):
    if idx in fails or len(b) < 500: continue
    # tid=123 LE = 7b 00, rk2 前缀 02
    if b'\x02\x7b\x00' in b[:32]:
        print(f'--- #{idx} len={len(b)} 前64B:')
        print(hd(b, 0, 64))
        cnt += 1
        if cnt >= 3: break
