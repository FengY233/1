#!/usr/bin/env python3
"""t51_roster.py — VEHICLES_INFO 39字段结构拟合器
锚点: 连续 vehicleID(eid+1..+29) 确定元素精确边界 → 逐字段解析 → 验证 10 场 × 30 元素
悬案: badges(PYTHON)/ranked(TUPLE<UINT16>)/events(PYTHON) 的精确字节格式
"""
import sys, glob, struct, json
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from t50_dissect import RND

pkgs = []; owner = []
for gi, f in enumerate(RND):
    blocks, declared, slen, pkts = load(f)
    for t, c, pl in pkts:
        if t == 0x32:
            pkgs.append(pl[4:]); owner.append(gi)

def read_len(b, p):
    l = b[p]; p += 1
    if l == 0xff:
        l = b[p] | (b[p+1] << 8) | (b[p+2] << 16); p += 3
    return l, p

def clist(b, p, base, n):
    vals, flags, v = [], set(), base
    while True:
        if p >= n: return None
        c = struct.unpack('b', b[p:p+1])[0]; p += 1
        if c == 0: return vals, flags, p
        elif c == -0x80:
            if p + 2 > n: return None
            v = struct.unpack('>H', b[p:p+2])[0]; p += 2; vals.append(v)
        elif c == -0x7f: vals.append(0)
        elif c == -0x7e:
            nmask = (len(vals) + 7) >> 3
            if p + nmask > n: return None
            mask = b[p:p+nmask]; p += nmask
            for i in range(nmask * 8):
                if mask[i >> 3] & (1 << (i & 7)): flags.add(i)
            return vals, flags, p
        elif 1 <= c <= 0x7f:
            v += c; vals.append(v)
        else:
            for _ in range(c + 126):
                v += 1; vals.append(v)

# ---- 找花名册包: 头部 02 7b 00 00 (rk2 tid=123 无名) + 1e (30) ----
rosters = []
for idx, b in enumerate(pkgs):
    if len(b) > 4000 and b[14:21] == bytes.fromhex('027b000084820' + ('3' if b[20]==0x03 else '0')):
        pass
    if len(b) > 4000 and b[15:18] == b'\x7b\x00\x00' and b[14] == 2 and b[21] == 0x1e:
        rosters.append(idx)
print(f'花名册包: {rosters} (共{len(rosters)})')

def fit_element(b, p, end):
    """解析单个 VEHICLES_INFO 元素, 返回 (dict, consumed) 或 (None, 卡点描述)"""
    o = {}
    q = p
    def need(k):
        return q + k <= end
    # 1-6: vehicleID, isAlive, outfitCD, compDescr, fakeName, name
    if not need(4+1): return None, 'head'
    o['vehicleID'] = struct.unpack('<i', b[q:q+4])[0]; q += 4
    o['isAlive'] = b[q]; q += 1
    for f in ('outfitCD','compDescr','fakeName','name'):
        l, q2 = read_len(b, q)
        if q2 + l > end: return None, f
        o[f] = b[q2:q2+l]; q = q2 + l
    # 7-10: team, isAvatarReady, isTeamKiller, accountDBID
    if not need(1+1+1+8): return None, 'flags'
    o['team'] = b[q]; o['isAvatarReady'] = b[q+1]; o['isTeamKiller'] = b[q+2]; q += 3
    o['accountDBID'] = struct.unpack('<Q', b[q:q+8])[0]; q += 8
    # 11: clanAbbrev (STRING)
    l, q2 = read_len(b, q)
    if q2 + l > end: return None, 'clanAbbrev'
    o['clanAbbrev'] = b[q2:q2+l]; q = q2 + l
    # 12-16: clanDBID(8), prebattleID(4), isPrebattleCreator, forbidInBattleInvitations, igrType
    if not need(8+4+1+1+1): return None, 'clan'
    o['clanDBID'] = struct.unpack('<q', b[q:q+8])[0]; q += 8
    o['prebattleID'] = struct.unpack('<i', b[q:q+4])[0]; q += 4
    o['isPrebattleCreator'] = b[q]; o['forbidInBattleInvitations'] = b[q+1]; o['igrType'] = b[q+2]; q += 3
    # 17: avatarSessionID (STRING)
    l, q2 = read_len(b, q)
    if q2 + l > end: return None, 'avatarSessionID'
    o['avatarSessionID'] = b[q2:q2+l]; q = q2 + l
    # 18-21: overriddenBadge, customRoleSlotTypeId, botDisplayStatus, teamPanelMode
    if not need(4): return None, 'badges4'
    o['overriddenBadge'], o['customRoleSlotTypeId'], o['botDisplayStatus'], o['teamPanelMode'] = b[q], b[q+1], b[q+2], b[q+3]; q += 4
    # 22-24: maxHealth(i16), prestigeLevel(i32), prestigeGradeMarkID(i32)
    if not need(2+4+4): return None, 'prestige'
    o['maxHealth'] = struct.unpack('<h', b[q:q+2])[0]; q += 2
    o['prestigeLevel'] = struct.unpack('<i', b[q:q+4])[0]; q += 4
    o['prestigeGradeMarkID'] = struct.unpack('<i', b[q:q+4])[0]; q += 4
    # 25-26: vehPostProgression, personalMissionIDs (ARRAY<INT32>)
    for f in ('vehPostProgression','personalMissionIDs'):
        n, q2 = read_len(b, q)
        if q2 + 4*n > end: return None, f
        o[f] = [struct.unpack('<i', b[q2+4*i:q2+4*i+4])[0] for i in range(n)]; q = q2 + 4*n
    # 27-29: personalMissionInfo, events, badges (PYTHON = [len][pickle])
    for f in ('personalMissionInfo','events','badges'):
        l, q2 = read_len(b, q)
        if q2 + l > end: return None, f
        o[f] = b[q2:q2+l]; q = q2 + l
    # 30: ranked (TUPLE<UINT16> — 尺寸待定, 先读 n)
    # 假设 A: 无尺寸=[n][n×u16]; 假设 B: 定长 2×u16
    o['_ranked_pos'] = q
    # 31: deathInfo (FIXED_DICT allowNone → [u8 hasValues])
    # 32-39 尾部定长: respawnID(4) stFrags(4) frags(2) activePetID(4) tkills(2) fogOfWar(1) position(4) __generation(4) = 25B
    TAIL = 25
    return o, q

# ---- 主拟合: 对每个花名册包, 找 30 个连续 vehicleID 锚 ----
for idx in rosters[:3]:
    b = pkgs[idx]; n = len(b)
    # clist 后 prop0 起点
    r = clist(b, 18, 0x1000, n)   # base 无关 (只要 vals 数)
    vals, flags, p0 = r
    assert b[21] == 0x1e
    start = 22
    first_vid = struct.unpack('<i', b[22:26])[0]
    # 找连续 vehicleID 锚: first_vid, +1, +2 ... (LE i32)
    anchors = [start]
    cur = first_vid
    for k in range(1, 30):
        pat = struct.pack('<i', cur + k)
        i = b.find(pat, anchors[-1] + 30)
        if i < 0: break
        anchors.append(i)
    print(f'=== #{idx} len={n} first_vid={first_vid} 锚数={len(anchors)} ===')
    # 元素边界 = anchors[k] .. anchors[k+1]
    lens = []
    ok = 0
    for k in range(len(anchors)):
        s = anchors[k]
        e = anchors[k+1] if k+1 < len(anchors) else None
        if e is None: break
        o, q = fit_element(b, s, e)
        if o is None:
            print(f'  elem{k} FAIL @{q} (range {s}..{e}, len {e-s})')
        else:
            # 悬案字节: ranked 起点 o['_ranked_pos'] 到 尾部25B+deathInfo 之前
            mid = e - 25 - 1   # deathInfo 至少 1B hasValues
            mid_bytes = b[o['_ranked_pos']:mid+1] if o['_ranked_pos'] <= mid else b[o['_ranked_pos']:e-25]
            if k < 3:
                print(f'  elem{k} OK len={e-s} ranked区({e-25-o["_ranked_pos"]}B): {b[o["_ranked_pos"]:e-25].hex(" ")}')
                print(f'        tail25+di: {b[e-26:e].hex(" ")}')
            ok += 1
        lens.append(e - s)
    print(f'  拟合成功 {ok}/{len(anchors)-1}; 元素长度谱: min={min(lens)} max={max(lens)}')
    print()
