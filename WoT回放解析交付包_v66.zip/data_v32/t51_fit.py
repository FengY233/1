#!/usr/bin/env python3
"""t51_fit.py — tid=51 族值格式拟合器
已知: clist `a5 82 [mask 5B]` → nv=35, flags 因包而异; 值区从 mask 后到固定尾巴 `04 09 0a 02 03 01 05 06 00 07 08`
求: 每个位置 i 的值格式 fmt[i], 使所有包在其 flag 集下精确消费到尾巴起点
候选格式: u8/u16/u32/f32/f64/[t]f32(标签f32,5B)/[t]f64(标签f64,9B)/[t]u32(标签u32,5B)/v3...
"""
import sys, struct, json
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from t50_v5a import RND

pkgs = []; owner = []
for gi, f in enumerate(RND):
    blocks, declared, slen, pkts = load(f)
    for t, c, pl in pkts:
        if t == 0x32: pkgs.append(pl[4:]); owner.append(gi)

TRAILER = bytes.fromhex('04090a020301050600070 8'.replace(' ', ''))

# 找 tid=51 族: 头部 02 33 00 00 a5 82 [5B mask] ... 尾巴
family = []
for idx, b in enumerate(pkgs):
    if len(b) < 60: continue
    if b[4] == 2 and b[5:8] == b'\x33\x00\x00' and b[8] == 0xa5 and b[9] == 0x82:
        ti = b.find(TRAILER)
        if ti > 0:
            mask = b[10:15]
            flags = set()
            for byte_i, mb in enumerate(mask):
                for bit in range(8):
                    if mb & (1 << bit): flags.add(byte_i * 8 + bit)
            family.append((idx, b, ti, flags))
print(f'tid=51 族: {len(family)} 包: {[x[0] for x in family]}')

# 值区: [15, ti); flags ∩ [0, N_props) 的位置读值, 位置格式 fmt[i] 待定
# 拟合策略: 贪心逐位置 — 按位置序处理所有包的公共约束
# 格式候选 (名, 消费函数): 返回 (新偏移 or None)
def F(b, p, n, fmt):
    rem = n - p
    try:
        if fmt == 'u8':  return p + 1 if rem >= 1 else None
        if fmt == 'u16': return p + 2 if rem >= 2 else None
        if fmt == 'u32': return p + 4 if rem >= 4 else None
        if fmt == 'f32': return p + 4 if rem >= 4 else None
        if fmt == 'f64': return p + 8 if rem >= 8 else None
        if fmt == 'tf32':  # [tag u8][f32] tag 任意
            return p + 5 if rem >= 5 else None
        if fmt == 'tf64':  # [tag u8][f64]
            return p + 9 if rem >= 9 else None
        if fmt == 'tu32':  # [tag u8][u32]
            return p + 5 if rem >= 5 else None
        if fmt == 'tu8u32':  # [tag][u8][u32] hmm
            return p + 6 if rem >= 6 else None
        if fmt == 'v3':  return p + 12 if rem >= 12 else None
        if fmt == 'rec7':  # #48 中段 7B: [tag][tag][u32][u8]?
            return p + 7 if rem >= 7 else None
        if fmt == 'rec14':  # #48 中段: [01][01][u32][01][f64]
            return p + 15 if rem >= 15 else None
    except Exception:
        return None
    return None

FMTS = ['u8', 'u16', 'u32', 'f32', 'f64', 'tf32', 'tf64', 'tu32', 'v3', 'rec7', 'rec14']

# 每包: 待读位置序列 = sorted(flags ∩ [0, 35))  (N_probs 未知, 先全读, 尾对齐校验)
# 联合拟合: 逐"值序号 k"决定 fmt[k] (所有包共用), DFS
def fit(family, max_depth=16):
    # 每包的状态: (pos, 待读位置列表)
    states = []
    for idx, b, ti, flags in family:
        pos_list = sorted(f for f in flags if f < 35)
        states.append({'idx': idx, 'b': b, 'ti': ti, 'pos_list': pos_list, 'p': 15, 'k': 0})
    fmt = []
    def dfs(k):
        # 全部包的 k 位置是否还有值
        act = [s for s in states if s['k'] == k]
        if not act:
            # 校验: 所有包 p == ti
            ok = all(s['p'] == s['ti'] for s in states)
            return fmt if ok else None
        for f in FMTS:
            good = True
            for s in act:
                np_ = F(s['b'], s['p'], s['ti'], f)
                if np_ is None or np_ > s['ti']:
                    good = False; break
            if not good: continue
            # 暂时推进
            saved = [(s['p'], s['k']) for s in act]
            for s in act:
                s['p'] = F(s['b'], s['p'], s['ti'], f); s['k'] = k + 1
            r = dfs(k + 1)
            if r is not None: return r
            for s, (pp, kk) in zip(act, saved):
                s['p'] = pp; s['k'] = kk
        return None
    return dfs(0)

# 先单独拟合 #1442 (flags 少) 看基线, 再全族
for subset in ([[x for x in family if x[0] == 1442], [x for x in family if x[0] in (1442, 3500)], family]):
    r = fit(subset)
    ids = [x[0] for x in subset]
    if r:
        print(f'✓ 拟合成功 {ids}: 位置格式序列 = {r}')
        break
    else:
        print(f'✗ 拟合失败 {ids}')
