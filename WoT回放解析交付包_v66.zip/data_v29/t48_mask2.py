#!/usr/bin/env python3
"""t48_mask2.py v2 — 全程跟踪所有 rk2 创建体, 统计掩码/尾结构; 对比两种 0x82 语义"""
import sys, glob, struct
sys.path.insert(0,'/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter
REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
tundra=[f for f in REPLAYS if 'tundra' in f][0]
RND=[f for f in REPLAYS if f!=tundra]

def read_len(b,p):
    l=b[p]; p+=1
    if l==0xff:
        l=b[p]|(b[p+1]<<8)|(b[p+2]<<16); p+=3
    return l,p

def read_clist(b,p,base,mode):
    vals,flags,v=[],set(),base
    while True:
        if p>=len(b): return vals,flags,p,True
        c=struct.unpack('b',b[p:p+1])[0]; p+=1
        if c==0: return vals,flags,p,False
        elif c==-0x80:
            v=struct.unpack('>H',b[p:p+2])[0]; p+=2; vals.append(v)
        elif c==-0x7f: vals.append(0)
        elif c==-0x7e:
            nmask=(len(vals)+7)>>3
            mask=b[p:p+nmask]; p+=nmask
            for i in range(len(vals)):
                if mask[i>>3]&(1<<(i&7)): flags.add(i)
            if mode==0: return vals,flags,p,False   # 0x82=终止
            # mode1: 掩码后继续(循环回开头, 下一个00终止)
        elif 1<=c<=0x7f:
            v+=c; vals.append(v)
        else:
            for _ in range(c+126):
                v+=1; vals.append(v)

def sweep(mode):
    stat=Counter(); hexes=Counter(); n2=0
    for f in RND:
        blocks, declared, slen, pkts = load(f)
        for t,c,pl in pkts:
            if t!=0x32: continue
            b=pl[4:]; n=len(b); p=0
            if n<2: continue
            p=2
            # 走到 rk2: 只跟 cls0/cls1 简单路径
            guard=0
            while p+3<=n and guard<60:
                guard+=1
                mcls=b[p]; mid=(b[p+1]<<8)|b[p+2]; p+=3
                if mcls==0:
                    if p+3>n: break
                    objId=struct.unpack('>H',b[p:p+2])[0]; rk=b[p+2]; p+=3
                    if rk>6: break
                    if rk==1: p+=4
                    elif rk==2:
                        n2+=1
                        if p+2>n: break
                        p+=2
                        l,p2=read_len(b,p)
                        if p2+l>n: break
                        nm=b[p2:p2+l]; p=p2+l
                        vals,fl,p,eof=read_clist(b,p,mid,mode)
                        tail=b[p:]
                        stat[(len(vals),len(fl),len(tail))]+=1
                        if len(fl)>0 and len(tail)<=12:
                            hexes[(len(fl),len(tail),tail.hex(), nm[:12].decode('latin1'))]+=1
                        break   # rk2 后停(后续文法未知)
                    elif rk in (3,4,5): break
                elif mcls==1:
                    try: vals,fl,p,eof=read_clist(b,p,mid,mode)
                    except: break
                    if eof: break
                    okc=True
                    for objId in vals:
                        if p+1>n: okc=False; break
                        rk=b[p]; p+=1
                        if rk>6 or rk in (3,4): okc=False; break
                        if rk==1:
                            if p+4>n: okc=False; break
                            p+=4
                        elif rk==2:
                            n2+=1
                            if p+2>n: okc=False; break
                            p+=2
                            l,p2=read_len(b,p)
                            if p2+l>n: okc=False; break
                            p=p2+l
                            try:
                                vals2,fl2,p,eof2=read_clist(b,p,objId,mode)
                            except: okc=False; break
                            if not okc or eof2: break
                        elif rk==5:
                            l,p2=read_len(b,p)
                            if p2+l>n: okc=False; break
                            p=p2+l
                    if not okc: break
                else: break
    return stat,hexes,n2

for mode,label in ((0,'0x82=终止'),(1,'0x82掩码后继续')):
    stat,hexes,n2=sweep(mode)
    print(f'=== {label} === rk2样本={n2}, (vals数,置位数,尾长) top:')
    for k,v in stat.most_common(12): print(f'  {k}: {v}')
    print('  置位且尾短:')
    for k,v in hexes.most_common(10): print(f'    {k}: {v}')
    print()
