#!/usr/bin/env python3
"""t48_mask.py — 统计 rk2 创建后 0x82 掩码置位数 vs 后续字节的结构关系"""
import sys, glob, struct
sys.path.insert(0,'/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter
REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
tundra=[f for f in REPLAYS if 'tundra' in f][0]
RND=[f for f in REPLAYS if f!=tundra]

def read_len(b,p):
    l=b[p]; p+=1
    if l==0xff:
        l=b[p]|(b[p+1]<<8)|(b[p+2]<<16); p+=3
    return l,p

def read_clist(b,p,base):
    """读clist到终止(0x00 或 0x82掩码后)。返回 vals, flags, p(停在掩码后或终止后)"""
    vals,flags,v=[],set(),base
    while True:
        if p>=len(b): return vals,flags,p,True
        c=struct.unpack('b',b[p:p+1])[0]; p+=1
        if c==0: return vals,flags,p,False
        elif c==-0x80:
            v=struct.unpack('>H',b[p:p+2])[0]; p+=2; vals.append(v)
        elif c==-0x7f: vals.append(0)
        elif c==-0x7e:
            nmask=(len(vals)+7)>>3
            mask=b[p:p+nmask]; p+=nmask
            for i in range(len(vals)):
                if mask[i>>3]&(1<<(i&7)): flags.add(i)
            return vals,flags,p,False
        elif 1<=c<=0x7f:
            v+=c; vals.append(v)
        else:
            for _ in range(c+126):
                v+=1; vals.append(v)

stat=Counter(); tails=Counter()
for f in RND:
    blocks, declared, slen, pkts = load(f)
    for t,c,pl in pkts:
        if t!=0x32: continue
        b=pl[4:]; n=len(b); p=0
        if n<2: continue
        p=2
        while p+3<=n:
            mcls=b[p]; mid=(b[p+1]<<8)|b[p+2]; p+=3
            if mcls==0:
                if p+3>n: break
                objId=struct.unpack('>H',b[p:p+2])[0]; rk=b[p+2]; p+=3
                if rk>6: break
                if rk==1: p+=4
                elif rk==2:
                    if p+2>n: break
                    p+=2
                    l,p2=read_len(b,p)
                    if p2+l>n: break
                    p=p2+l
                    vals,fl,p,eof=read_clist(b,p,mid)
                    if eof: break
                    tail=b[p:]
                    stat[(len(fl), len(tail))]+=1
                    if fl and len(tail)<=16:
                        tails[(len(fl),len(tail),tail.hex())]+=1
                    break   # rk2后不再追(其余消息复杂), 只统计首段
                elif rk in (3,4,5):
                    break
            elif mcls==1: break
            else: break
print('(置位数, 尾长) 分布:')
for k,v in sorted(stat.items())[:30]: print(f'  {k}: {v}')
print()
print('具体尾部 (置位数, 尾长, 尾hex) top:')
for k,v in tails.most_common(15): print(f'  {k}: {v}')
