#!/usr/bin/env python3
"""t48_dump1.py — dump fail 样本完整字节流人工对照"""
import sys, glob, struct
sys.path.insert(0,'/home/z/my-project/scripts')
from survey_new_replays import load
REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
tundra=[f for f in REPLAYS if 'tundra' in f][0]
RND=[f for f in REPLAYS if f!=tundra]
target=0
cnt=0
for f in RND:
    blocks, declared, slen, pkts = load(f)
    for t,c,pl in pkts:
        if t!=0x32: continue
        cnt+=1
        if cnt!=target:
            # 找含 ShotsReceiver_4144 的包
            if b'ShotsReceiver_4144' in pl:
                target=cnt
                s=pl[4:]
                print(f'包#{cnt} len={len(s)}: {s.hex(" ")}')
                # UTF8 位置标注
                i=s.find(b'ShotsReceiver_4144')
                print(f'ShotsReceiver@{i}, 前后文: ...{s[max(0,i-12):i+30].hex(" ")}')
                raise SystemExit
