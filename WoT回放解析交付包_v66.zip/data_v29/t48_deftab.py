#!/usr/bin/env python3
"""t48_deftab.py — Task48: 41个def属性名→类型树表 + alias展开 (v2: 修正Type文本读取)
输出 /tmp/wot/t48_deftypes.json
"""
import sys, json, glob, os
sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file

ED = '/tmp/wot/wot_scripts/entity_defs'

def sec_text(s):
    if s.type == 1: return s.asString()
    if s.children: return None
    if s.type == 0 and not s.data: return None
    if s.type == 2: return str(s.asInt())
    if s.type == 4: return 'true' if s.asBool() else 'false'
    return s.data.hex()

def type_tree(node):
    """类型节点: 本体文本=类型名(可为alias/嵌套结构), children=参数(size/字段/元素类型)"""
    txt = sec_text(node)
    out = {}
    if txt: out['t'] = txt
    for cc in node.children:
        if cc.name in ('Size','size'): out['size'] = sec_text(cc)
        elif cc.name in ('AllowNone','allowNone'): out['allowNone'] = sec_text(cc)
        elif cc.name in ('DBLength','DatabaseLength'): out['dbLen'] = sec_text(cc)
        elif cc.name == 'Properties': pass  # 下面处理
        else:
            # 嵌套: ARRAY<T>/TUPLE<T>/FixedDict字段
            sub = {'n': cc.name}
            t = None
            for fc in cc.children:
                if fc.name == 'Type': sub['type'] = type_tree(fc)
                else: sub[fc.name.lower()] = sec_text(fc)
            if 'type' not in sub and not cc.children:
                sub['v'] = sec_text(cc)
            out.setdefault('fields', []).append(sub)
    pw = None
    for cc in node.children:
        if cc.name == 'Properties': pw = cc
    if pw:
        for f in pw.children:
            entry = {'field': f.name}
            for fc in f.children:
                if fc.name == 'Type': entry['type'] = type_tree(fc)
                else: entry[fc.name.lower()] = sec_text(fc)
            out.setdefault('fields', []).append(entry)
    return out

aliases = {}
root = decode_file(os.path.join(ED,'alias.xml'))
for c in root.children:
    aliases[c.name] = type_tree(c)

table = {}
for p in sorted(glob.glob(os.path.join(ED,'*.def'))):
    ent = os.path.basename(p)[:-4]
    try: root = decode_file(p)
    except Exception as e:
        table[ent] = {'_err': str(e)}; continue
    props = {}
    for sec in root.children:
        if sec.name != 'Properties': continue
        for c in sec.children:
            row = {}
            for cc in c.children:
                if cc.name == 'Type': row['type'] = type_tree(cc)
                elif cc.name == 'Flags': row['flags'] = sec_text(cc)
                elif cc.name == 'Identifier': row['ident'] = sec_text(cc)
                elif cc.name == 'DatabaseLength': row['dbLen'] = sec_text(cc)
            props[c.name] = row
    table[ent] = props

json.dump({'aliases': aliases, 'entities': table},
          open('/tmp/wot/t48_deftypes.json','w'), ensure_ascii=False, indent=1)
n = sum(len(v) for v in table.values() if isinstance(v,dict))
print(f'entities={len(table)} props_total={n} aliases={len(aliases)}')
v = table.get('Vehicle', {})
for k in ('position','health','pitch','publicInfo','componentsData','damageStickers','state','gunAnglesPacked'):
    if k in v: print('Vehicle.'+k.ljust(18), '→', json.dumps(v[k].get('type'), ensure_ascii=False)[:150])
