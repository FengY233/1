#!/usr/bin/env python3
"""t48_root.py — FUN_140e379d0 BWRootNode::update slot12 完整读取序"""
import pefile
from capstone import *
EXE='/tmp/wot/wotexe/WorldOfTanks.exe'
pe=pefile.PE(EXE,fast_load=True); base=pe.OPTIONAL_HEADER.ImageBase
data=open(EXE,'rb').read()
def va2off(va):
    for s in pe.sections:
        if base+s.VirtualAddress<=va<base+s.VirtualAddress+max(s.Misc_VirtualSize,s.SizeOfRawData):
            return s.PointerToRawData+(va-base-s.VirtualAddress)
md=Cs(CS_ARCH_X86,CS_MODE_64)
off=va2off(0x140e379d0); r=0
print('===== BWRootNode::update @0x140e379d0 =====')
for i in md.disasm(data[off:off+1200],0x140e379d0):
    print(f'  {i.address:#x}: {i.mnemonic:8s} {i.op_str}')
    if i.mnemonic=='ret':
        r+=1
        if r>=2: break
