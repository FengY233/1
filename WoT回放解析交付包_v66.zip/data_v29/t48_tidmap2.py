#!/usr/bin/env python3
"""t48_tidmap2.py — 字节特征搜索: [02][u16 tid][len][ASCII name] 模式普查"""
import sys, glob, struct, re
sys.path.insert(0,'/home/z/my-project/scripts')
from survey_new_replays import load
from collections import defaultdict
REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TUNDRA=[f for f in REPLAYS if 'tundra' in f][0]
RND=[f for f in REPLAYS if f!=TUNDRA]

tid_names=defaultdict(lambda: defaultdict(int))
for f in RND:
    blocks, declared, slen, pkts = load(f)
    for t,c,pl in pkts:
        if t!=0x32: continue
        b=pl[4:]; n=len(b)
        for i in range(n-6):
            if b[i]!=0x02: continue
            tid=b[i+1]|(b[i+2]<<8)
            if tid==0 or tid>127: continue
            l=b[i+3]
            if l==0:
                tid_names[tid]['']+=1
                continue
            if l>48 or i+4+l>n: continue
            nm=b[i+4:i+4+l]
            try: s=nm.decode('ascii')
            except: continue
            if not all(32<=x<127 for x in nm): continue
            # 首字母大写蛇形/驼峰组件名特征
            if not (s[0].isupper() or s[0].islower()): continue
            if not re.match(r'^[A-Za-z][A-Za-z0-9_]*$', s): continue
            tid_names[tid][s]+=1

print(f'tid 种类: {len(tid_names)}')
rows=[]
for tid in sorted(tid_names):
    tot=sum(tid_names[tid].values())
    top=sorted(tid_names[tid].items(),key=lambda x:-x[1])[:3]
    base=defaultdict(int)
    for nm,c in tid_names[tid].items():
        base[re.sub(r'_\d+$','',nm) if nm else '(空)']+=c
    btop=sorted(base.items(),key=lambda x:-x[1])[:2]
    rows.append((tid,tot,btop))
    print(f'  tid={tid:3d} n={tot:5d}: {btop}')
import json
json.dump({str(t):dict(v) for t,v in tid_names.items()}, open('/tmp/wot/t48_tidmap.json','w'), ensure_ascii=False, indent=1)
print('saved /tmp/wot/t48_tidmap.json')
