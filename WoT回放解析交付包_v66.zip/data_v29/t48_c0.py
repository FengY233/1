#!/usr/bin/env python3
"""t48_c0.py — FUN_140e73f30 class0 处理器全反汇编: regKey3/4 分支 + node+0x58 写入追踪"""
import pefile
from capstone import *
EXE='/tmp/wot/wotexe/WorldOfTanks.exe'
pe=pefile.PE(EXE,fast_load=True); base=pe.OPTIONAL_HEADER.ImageBase
data=open(EXE,'rb').read()
def va2off(va):
    for s in pe.sections:
        if base+s.VirtualAddress<=va<base+s.VirtualAddress+max(s.Misc_VirtualSize,s.SizeOfRawData):
            return s.PointerToRawData+(va-base-s.VirtualAddress)
md=Cs(CS_ARCH_X86,CS_MODE_64)
off=va2off(0x140e73f30); r=0
print('===== class0 处理器 @0x140e73f30 =====')
for i in md.disasm(data[off:off+800],0x140e73f30):
    print(f'  {i.address:#x}: {i.mnemonic:8s} {i.op_str}')
    if i.mnemonic=='ret':
        r+=1
        if r>=3: break
