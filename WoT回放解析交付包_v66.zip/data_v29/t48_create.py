#!/usr/bin/env python3
"""t48_create.py — regKey3/4 PropertyNode 创建体反汇编 (slot3 之前未细看的两案)"""
import pefile
from capstone import *
EXE='/tmp/wot/wotexe/WorldOfTanks.exe'
pe=pefile.PE(EXE,fast_load=True); base=pe.OPTIONAL_HEADER.ImageBase
data=open(EXE,'rb').read()
def va2off(va):
    for s in pe.sections:
        if base+s.VirtualAddress<=va<base+s.VirtualAddress+max(s.Misc_VirtualSize,s.SizeOfRawData):
            return s.PointerToRawData+(va-base-s.VirtualAddress)
md=Cs(CS_ARCH_X86,CS_MODE_64)
def dis(va,n,t,sr=2):
    off=va2off(va); print(f'\n===== {t} @{hex(va)} ====='); r=0
    for i in md.disasm(data[off:off+n],va):
        print(f'  {i.address:#x}: {i.mnemonic:8s} {i.op_str}')
        if i.mnemonic=='ret':
            r+=1
            if r>=sr: break
# 七案跳转表 @0x140399150 (worklog: regKey0-6 创建体)
dis(0x140399180, 500, 'PropertyNode slot13 续体(regKey3/4)')
