#!/usr/bin/env python3
"""t48_probe.py v2 — 失败包字节级对照: 新文法逐消息走, 找卡点分布"""
import sys, glob, struct, json
sys.path.insert(0,'/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter

REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
tundra = [f for f in REPLAYS if 'tundra' in f][0]
RND = [f for f in REPLAYS if f != tundra]

def read_len(b,p):
    l=b[p]; p+=1
    if l==0xff:
        l=b[p]|(b[p+1]<<8)|(b[p+2]<<16); p+=3
    return l,p

def read_clist(b,p,base):
    vals,flags,v=[],set(),base
    while True:
        c=struct.unpack('b',b[p:p+1])[0]; p+=1
        if c==0: break
        elif c==-0x80:
            v=struct.unpack('>H',b[p:p+2])[0]; p+=2; vals.append(v)
        elif c==-0x7f: vals.append(0)
        elif c==-0x7e:
            nmask=(len(vals)+7)>>3
            mask=b[p:p+nmask]; p+=nmask
            for i in range(len(vals)):
                if mask[i>>3]&(1<<(i&7)): flags.add(i)
            break
        elif 1<=c<=0x7f:
            v+=c; vals.append(v)
        else:
            for _ in range(c+126):
                v+=1; vals.append(v)
    return vals,flags,p

def walk(stream):
    nodes={}
    b=stream; n=len(b); p=0; step=0
    mid=struct.unpack('>H',b[0:2])[0] if n>=2 else 0
    if n<2: return ['太短'], 'short', 0
    p=2; mcls=0
    log=[]
    while True:
        step+=1
        desc=f'#{step} cls{mcls} id={mid:#06x}'
        if mcls==0:
            if p+3>n: log.append(desc+' FAIL:objId越界'); return log,'fail',p
            objId=struct.unpack('>H',b[p:p+2])[0]; rk=b[p+2]; p+=3
            if rk>6: log.append(desc+f' FAIL:rk={rk}'); return log,'fail',p
            nodes[objId]=rk
            if rk==1:
                if p+4>n: log.append(desc+' FAIL:eid越界'); return log,'fail',p
                eid=struct.unpack('<I',b[p:p+4])[0]; p+=4
                log.append(desc+f' objId={objId} rk1 eid={eid}')
            elif rk==2:
                if p+2>n: log.append(desc+' FAIL:rk2越界'); return log,'fail',p
                tid=struct.unpack('<H',b[p:p+2])[0]; p+=2
                l,p2=read_len(b,p)
                if p2+l>n: log.append(desc+' FAIL:name越界'); return log,'fail',p
                nm=b[p2:p2+l]; p=p2+l
                try: vals,fl,p=read_clist(b,p,mid)
                except Exception as e: log.append(desc+f' FAIL:clist {e}'); return log,'fail',p
                log.append(desc+f' objId={objId} rk2 tid={tid} nm={nm[:20]!r} cl={len(vals)}项')
            elif rk in (3,4):
                log.append(desc+f' objId={objId} rk{rk} ★创建值@{p}: {b[p:p+24].hex(" ")}')
                return log,'value',p
            elif rk==5:
                l,p2=read_len(b,p)
                if p2+l>n: log.append(desc+' FAIL:rk5name'); return log,'fail',p
                nm=b[p2:p2+l]; p=p2+l
                log.append(desc+f' objId={objId} rk5 nm={nm[:20]!r}')
            else:
                log.append(desc+f' objId={objId} rk{rk}')
        elif mcls==1:
            try: vals,fl,p=read_clist(b,p,mid)
            except Exception as e: log.append(desc+f' FAIL:c1clist {e}'); return log,'fail',p
            for objId in vals:
                if p+1>n: return log+[desc+' FAIL:c1尾'],'fail',p
                rk=b[p]; p+=1
                if rk>6: return log+[desc+f' FAIL:c1rk={rk}'],'fail',p
                nodes[objId]=rk
                if rk==1:
                    if p+4>n: return log+[desc+' FAIL:c1eid'],'fail',p
                    p+=4
                elif rk==2:
                    if p+2>n: return log+[desc+' FAIL:c1rk2'],'fail',p
                    p+=2
                    l,p2=read_len(b,p)
                    if p2+l>n: return log+[desc+' FAIL:c1nm'],'fail',p
                    p=p2+l
                    try: _,_,p=read_clist(b,p,objId)
                    except: return log+[desc+' FAIL:c1cl2'],'fail',p
                elif rk in (3,4):
                    log.append(desc+f' c1 objId={objId} rk{rk} ★创建值@{p}: {b[p:p+24].hex(" ")}')
                    return log,'value',p
                elif rk==5:
                    l,p2=read_len(b,p)
                    if p2+l>n: return log+[desc+' FAIL:c1rk5'],'fail',p
                    p=p2+l
            log.append(desc+f' c1批量 n={len(vals)}')
        elif mcls in (2,3):
            log.append(desc+' 通知')
        elif mcls in (4,6):
            rk=nodes.get(mid)
            if rk is None: return log+[desc+' FAIL:未知节点'],'fail',p
            if rk in (1,2,6):
                log.append(desc+f' upd rk{rk} 空')
            elif rk==3:
                log.append(desc+f' upd rk3 ★值体@{p}: {b[p:p+24].hex(" ")}')
                return log,'value',p
            elif rk==4:
                if p+1>n: return log+[desc+' FAIL:rk4u'],'fail',p
                kind=b[p]; p+=1
                if kind<=1:
                    l,p2=read_len(b,p)
                    if p2+l>n: return log+[desc+' FAIL:rk4blob'],'fail',p
                    p=p2+l
                    log.append(desc+f' upd rk4 kind={kind} blob{ l}B')
                else:
                    log.append(desc+f' upd rk4 ★kind={kind} 值@{p}: {b[p:p+24].hex(" ")}')
                    return log,'value',p
            elif rk==0:
                log.append(desc+f' upd rk0 ★Root@{p}: {b[p:p+24].hex(" ")}')
                return log,'root',p
        elif mcls==5:
            log.append(desc+' cls5')
        if p>=n:
            log.append(f'——完成 {p}/{n}')
            return log,'done',p
        if p+3>n:
            log.append(f'——尾不足 @{p}: {b[p:].hex(" ")}')
            return log,'tail',p
        mcls=b[p]; mid=(b[p+1]<<8)|b[p+2]; p+=3
        if mcls>6 or mcls==5:
            if mcls==5: continue
            log.append(f'#{step} ★错位@{p-3}: {b[p-3:p].hex(" ")} | {b[p:p+16].hex(" ")}')
            return log,'fail',p

stats=Counter(); samples={'value':[], 'root':[], 'fail':[]}
for f in RND:
    blocks, declared, slen, pkts = load(f)
    for t,c,pl in pkts:
        if t!=0x32: continue
        stream=pl[4:]
        log,kind,stop=walk(stream)
        stats[kind]+=1
        if kind in samples and len(samples[kind])<2:
            samples[kind].append(log)
print('6,822包卡点分布:', dict(stats))
print()
for k in ('value','root','fail'):
    for i,logs in enumerate(samples[k]):
        print(f'════ {k}样本{i} ════')
        for l in logs[:10]: print(' ',l)
        print()
