#!/usr/bin/env python3
"""t48_full.py — Task48 核心解码器: 带类型/策略回溯的 0x32 全量解析
策略空间(corpus-driven 自动选优):
  mask_mode: 0=0x82掩码即终止 | 1=掩码后继续至0x00终止
  inline_mode: 掩码置位子属性的内联体形态
     none   = 无内联体
     zero   = 每置位1字节(初值/标记)
     rk     = [u8 rk]+创建体 递归
     eidrec = [u32 eid][u8 flag]{flag=1:[len][name][值]} 直到flag=0/流尽
  value_len: rk3/4 值体的候选长度集(自适应回溯)
"""
import sys, glob, struct, json
sys.path.insert(0,'/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter

REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TUNDRA = [f for f in REPLAYS if 'tundra' in f][0]
RND = [f for f in REPLAYS if f != TUNDRA]

def read_len(b,p):
    l=b[p]; p+=1
    if l==0xff:
        l=b[p]|(b[p+1]<<8)|(b[p+2]<<16); p+=3
    return l,p

class ParseCtx:
    __slots__=('b','n','nodes','msgs','strategy')
    def __init__(s,b,strategy):
        s.b=b; s.n=len(b); s.nodes={}; s.msgs=[]; s.strategy=strategy

def clist(b,p,base,ctx):
    """返回 (vals, flags, p) 或 None=失败"""
    st=ctx.strategy
    vals,flags,v=[],set(),base
    while True:
        if p>=ctx.n: return None
        c=struct.unpack('b',b[p:p+1])[0]; p+=1
        if c==0: return vals,flags,p
        elif c==-0x80:
            if p+2>ctx.n: return None
            v=struct.unpack('>H',b[p:p+2])[0]; p+=2; vals.append(v)
        elif c==-0x7f: vals.append(0)
        elif c==-0x7e:
            nmask=(len(vals)+7)>>3
            if p+nmask>ctx.n: return None
            mask=b[p:p+nmask]; p+=nmask
            for i in range(len(vals)):
                if mask[i>>3]&(1<<(i&7)): flags.add(i)
            if st['mask_mode']==0: return vals,flags,p
            # mode1: 循环继续(下一个 0x00 终止)
        elif 1<=c<=0x7f:
            v+=c; vals.append(v)
        else:
            for _ in range(c+126):
                v+=1; vals.append(v)

def parse_inline(b,p,ctx,depth):
    """掩码置位内联子体解析; 返回 新p 或 None"""
    st=ctx.strategy
    if depth>4: return None
    mode=st['inline_mode']
    if mode=='none': return p
    return None  # 由 parse_create_inline 在调用处按置位数展开

def parse_rk3_value(b,p,ctx,depth):
    """rk3/4 创建体=值体; 回溯候选长度。返回 [候选p,...]"""
    st=ctx.strategy
    cand=[]
    rem=ctx.n-p
    for L in st['value_lens']:
        if L<=rem: cand.append(p+L)
    # STRING 候选
    if rem>=1:
        l=b[p]
        hdr=4 if l==0xff else 1
        if l==0xff and rem>=4:
            l=b[p+1]|(b[p+2]<<8)|(b[p+3]<<16)
        if hdr+l<=rem and l<=96: cand.append(p+hdr+l)
    # eidrec 模式: [eid][flag]{flag=1:[len][name][递归值?]} — 简化: flag=1 → [len][name]+值1候选
    if st.get('eidrec') and rem>=5:
        eid=struct.unpack('<I',b[p:p+4])[0]
        flag=b[p+4]
        if flag==0: cand.append(p+5)
        elif flag==1 and rem>=6:
            l=b[p+5]
            if 6+l<=rem: cand.append(p+6+l)  # name 后值=0字节假设
            if 7+l<=rem: cand.append(p+7+l)  # 值1字节
            if 10+l<=rem: cand.append(p+10+l) # 值4字节
    return sorted(set(cand))

def parse_create(b,p,rk,mid,ctx,depth):
    """regKey 创建体; 返回 [候选p,...]"""
    st=ctx.strategy; n=ctx.n
    if rk==0 or rk==6: return [p]
    if rk==1:
        return [p+4] if p+4<=n else []
    if rk==2:
        if p+2>n: return []
        p+=2  # tid
        l,p2=read_len(b,p)
        if p2+l>n: return []
        nm=b[p2:p2+l]; p3=p2+l
        r=clist(b,p3,mid,ctx)
        if r is None: return []
        vals,flags,p4=r
        # 内联子体
        out=[]
        im=st['inline_mode']
        if im=='none': out.append(p4)
        elif im=='zero':
            if p4+len(flags)<=n: out.append(p4+len(flags))
        elif im=='rk':
            # 递归: 每个置位一个 [u8 rk]+创建体 — 生成候选需DFS, 这里近似: 全 rk0/rk3空
            if p4+len(flags)<=n: out.append(p4+len(flags))
            if p4+2*len(flags)<=n: out.append(p4+2*len(flags))
        elif im=='eidrec':
            # 每置位 [eid][flag]...; 简化候选
            out.append(p4)
        return out
    if rk in (3,4):
        return parse_rk3_value(b,p,ctx,depth)
    if rk==5:
        if p>=n: return []
        l,p2=read_len(b,p)
        if p2+l>n: return []
        return [p2+l]
    return []

def parse_stream(stream, strategy, maxnodes=4000):
    ctx=ParseCtx(stream,strategy)
    b=stream; n=ctx.n
    if n<2: return None
    # DFS
    stack=[]  # (p, mcls, mid, nodes_snapshot?) — 用显式递归
    sys.setrecursionlimit(10000)
    def dfs(p, mcls, mid, depth, guard):
        if guard>2000: return None
        if mcls==0:
            if p+3>n: return None
            objId=struct.unpack('>H',b[p:p+2])[0]; rk=b[p+2]; q=p+3
            if rk>6: return None
            if rk==1 and depth==0:
                ctx.nodes[objId]=rk
            else:
                ctx.nodes[objId]=rk
            for np in parse_create(b,q,rk,mid,ctx,depth):
                r=step(np,depth+1,guard+1)
                if r is not None: return r
            return None
        elif mcls==1:
            r=clist(b,p,mid,ctx)
            if r is None: return None
            vals,flags,q=r
            def rec(i,q2):
                if i==len(vals):
                    return step(q2,depth+1,guard+1)
                if q2+1>n: return None
                rk=b[q2]; q3=q2+1
                if rk>6: return None
                ctx.nodes[vals[i]]=rk
                for np in parse_create(b,q3,rk,vals[i],ctx,depth+1):
                    r=rec(i+1,np)
                    if r is not None: return r
                return None
            return rec(0,q)
        elif mcls in (2,3):
            return step(p,depth+1,guard+1)
        elif mcls in (4,6):
            rk=ctx.nodes.get(mid)
            if rk is None: return None
            if rk in (1,2,6): return step(p,depth+1,guard+1)
            if rk==3:
                for np in parse_rk3_value(b,p,ctx,depth):
                    r=step(np,depth+1,guard+1)
                    if r is not None: return r
                return None
            if rk==4:
                if p+1>n: return None
                kind=b[p]; q=p+1
                if kind<=1:
                    l,q2=read_len(b,q)
                    if q2+l>n: return None
                    return step(q2+l,depth+1,guard+1)
                else:
                    for np in parse_rk3_value(b,p,ctx,depth):
                        r=step(np,depth+1,guard+1)
                        if r is not None: return r
                    return None
            if rk==0:
                # Root: clist + 复杂——暂用"到下一条头"回溯: 保守跳过 (整包失败标记)
                return None
            return None
        return None
    def step(p,depth,guard):
        if p>=n: return ('done',p)
        if p+3>n: return ('tail',p) if n-p<=2 else None
        mcls=b[p]; mid=(b[p+1]<<8)|b[p+2]; q=p+3
        if mcls>6 or mcls==5: return None
        return dfs(q,mcls,mid,depth,guard)
    # 首消息
    mid0=struct.unpack('>H',b[0:2])[0]
    return dfs(2,0,mid0,0,0)

STRATS=[]
for mm in (0,1):
    for im in ('none','zero','rk'):
        STRATS.append({'mask_mode':mm,'inline_mode':im,
                       'value_lens':[0,1,2,4,8,12,16],'eidrec':False})
STRATS.append({'mask_mode':0,'inline_mode':'none','value_lens':[0,1,2,4,8,12,16],'eidrec':True})
STRATS.append({'mask_mode':1,'inline_mode':'none','value_lens':[0,1,2,4,8,12,16],'eidrec':True})

if __name__=='__main__':
    # 先缓存包
    pkgs=[]
    for f in RND:
        blocks, declared, slen, pkts = load(f)
        for t,c,pl in pkts:
            if t==0x32: pkgs.append(pl[4:])
    print(f'0x32 包总数: {len(pkgs)}')
    for si,st in enumerate(STRATS):
        ok=0; kinds=Counter()
        for s in pkgs:
            r=parse_stream(s,st)
            if r is not None: ok+=1; kinds[r[0]]+=1
        print(f'策略{si} mm={st["mask_mode"]} inline={st["inline_mode"]} eidrec={st["eidrec"]}: 全解 {ok}/{len(pkgs)} ({100*ok/len(pkgs):.1f}%) {dict(kinds)}')
