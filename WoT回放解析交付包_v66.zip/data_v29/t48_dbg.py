#!/usr/bin/env python3
"""t48_dbg.py — 指定失败包的逐步调试"""
import sys, glob, struct
sys.path.insert(0,'/home/z/my-project/scripts')
from survey_new_replays import load
from t48_full2 import parse_stream, read_len, clist, value_candidates
REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TUNDRA=[f for f in REPLAYS if 'tundra' in f][0]
RND=[f for f in REPLAYS if f!=TUNDRA]
pkgs=[]
for f in RND:
    blocks, declared, slen, pkts = load(f)
    for t,c,pl in pkts:
        if t==0x32: pkgs.append(pl[4:])

target=int(sys.argv[1]) if len(sys.argv)>1 else 5
s=pkgs[target]; n=len(s)
print(f'包idx={target} len={n}')
for i in range(0,n,16):
    ch=s[i:i+16]
    print(f'  {i:4d}: '+' '.join(f'{x:02x}' for x in ch).ljust(48)+' '+''.join(chr(x) if 32<=x<127 else '.' for x in ch))

# 手工步进打印
p=2; nodes={}
if n>=2:
    mid=struct.unpack('>H',s[0:2])[0]; mcls=0
    step=0
    while p+3<=n or step==0:
        step+=1
        print(f'--#{step} cls{mcls} id={mid:#06x} @{p}')
        if mcls==0:
            if p+3>n: print('  objId越界'); break
            objId=struct.unpack('>H',s[p:p+2])[0]; rk=s[p+2]; p+=3
            nodes[objId]=rk
            if rk==1:
                eid=struct.unpack('<I',s[p:p+4])[0]; p+=4
                print(f'  objId={objId} rk1 eid={eid:#x}')
            elif rk==2:
                tid=struct.unpack('<H',s[p:p+2])[0]; p+=2
                l,p2=read_len(s,p); nm=s[p2:p2+l]; p=p2+l
                r=clist(s,p,mid,n)
                if r is None: print(f'  rk2 tid={tid} nm={nm[:16]!r} clist失败'); break
                vals,flags,p=r
                print(f'  objId={objId} rk2 tid={tid} nm={nm[:16]!r} vals={vals} flags={sorted(flags)} → 初值区@{p}: {s[p:p+20].hex(" ")}')
                k=len(flags)
                print(f'  需{k}个初值, 候选: {[L for L in value_candidates(s,p,n)]}')
                break
            elif rk in (3,4):
                print(f'  objId={objId} rk{rk} 初值@{p}: {s[p:p+20].hex(" ")}')
                print(f'  候选: {[L for L in value_candidates(s,p,n)]}')
                break
            elif rk==5:
                l,p2=read_len(s,p); print(f'  objId={objId} rk5 len={l}'); p=p2+l
            else:
                print(f'  objId={objId} rk{rk}')
        elif mcls==1:
            r=clist(s,p,mid,n)
            if r is None: print('  c1 clist失败'); break
            vals,flags,p=r
            print(f'  c1 vals={vals[:8]}{".." if len(vals)>8 else ""} @{p}: {s[p:p+16].hex(" ")}')
            ok=False
            for objId in vals:
                if p+1>n: break
                rk=s[p]; p+=1
                nodes[objId]=rk
                print(f'    {objId} rk{rk} @{p}: {s[p:p+12].hex(" ")}')
                if rk==1: p+=4
                elif rk==2:
                    if p+2>n: break
                    p+=2
                    l,p2=read_len(s,p)
                    if p2+l>n: break
                    p=p2+l
                    r2=clist(s,p,objId,n)
                    if r2 is None: ok=False; break
                    v2,f2,p=r2
                    k=len(f2)
                    print(f'      rk2 vals={v2} flags={sorted(f2)} 初值@{p}: {s[p:p+16].hex(" ")} (需{k}个)')
                    if k==0: continue
                    # 试单组合
                    import itertools
                    found=False
                    def gen2(pp,cnt):
                        if cnt==0: yield pp; return
                        for L in value_candidates(s,pp,n):
                            yield from gen2(pp+L,cnt-1)
                    for np in gen2(p,k):
                        # 验证: 下一条头合法
                        if np+3<=n and s[np]<=6:
                            p=np; found=True; break
                        if np>=n: p=np; found=True; break
                    if not found: ok=False; break
                elif rk in (3,4):
                    print(f'      rk{rk} 初值@{p} (候选{value_candidates(s,p,n)})')
                    found=False
                    for L in value_candidates(s,p,n):
                        np=p+L
                        if np>=n or (np+3<=n and s[np]<=6 and s[np]!=5):
                            p=np; found=True; break
                    if not found: ok=False; break
                elif rk==5:
                    l,p2=read_len(s,p)
                    if p2+l>n: break
                    p=p2+l
            if not ok and p<n:
                print(f'  c1 元素处理后 @{p}: {s[p:p+16].hex(" ")}')
                break
        elif mcls in (2,3):
            pass
        elif mcls in (4,6):
            rk=nodes.get(mid)
            print(f'  upd rk={rk} @{p}: {s[p:p+16].hex(" ")}')
            if rk in (1,2,6): pass
            elif rk==3:
                print(f'    值候选: {value_candidates(s,p,n)}')
                break
            elif rk==4:
                if p<n:
                    kind=s[p]
                    if kind<=1:
                        l,p2=read_len(s,p+1); p=p2+l
                        print(f'    kind={kind} blob={l}')
                    else:
                        print(f'    kind={kind} 疑似直接值, 候选: {value_candidates(s,p,n)}')
                        break
            else:
                print('    Root更新——复杂体')
                break
        if p>=n:
            print(f'——完成 {p}/{n}')
            break
        if p+3>n:
            print(f'——尾 {n-p}B: {s[p:].hex(" ")}')
            break
        mcls=s[p]; mid=(s[p+1]<<8)|s[p+2]; p+=3
        if mcls>6 or mcls==5:
            print(f'  ★错位 头={s[p-3:p].hex(" ")}')
            break
