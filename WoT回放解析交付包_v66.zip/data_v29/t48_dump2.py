#!/usr/bin/env python3
"""t48_dump2.py — dump value样本0 (含 acc.totalDamage 的包) 完整字节"""
import sys, glob, struct
sys.path.insert(0,'/home/z/my-project/scripts')
from survey_new_replays import load
REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
tundra=[f for f in REPLAYS if 'tundra' in f][0]
RND=[f for f in REPLAYS if f!=tundra]
cnt=0
for f in RND:
    blocks, declared, slen, pkts = load(f)
    for t,c,pl in pkts:
        if t!=0x32: continue
        cnt+=1
        if b'acc.totalDamage' in pl:
            s=pl[4:]
            print(f'包#{cnt} len={len(s)}')
            for i in range(0,len(s),16):
                chunk=s[i:i+16]
                hexs=' '.join(f'{x:02x}' for x in chunk)
                asc=''.join(chr(x) if 32<=x<127 else '.' for x in chunk)
                print(f'  {i:4d}: {hexs:<48s} {asc}')
            raise SystemExit
