#!/usr/bin/env python3
"""t48_ctor.py — FUN_1403981d0 case3 helper: ClientPrimitivePropertyNode 构造全解(找+0x58索引来源)"""
import pefile
from capstone import *
EXE='/tmp/wot/wotexe/WorldOfTanks.exe'
pe=pefile.PE(EXE,fast_load=True); base=pe.OPTIONAL_HEADER.ImageBase
data=open(EXE,'rb').read()
def va2off(va):
    for s in pe.sections:
        if base+s.VirtualAddress<=va<base+s.VirtualAddress+max(s.Misc_VirtualSize,s.SizeOfRawData):
            return s.PointerToRawData+(va-base-s.VirtualAddress)
md=Cs(CS_ARCH_X86,CS_MODE_64)
def dis(va,n,t,sr=3):
    off=va2off(va); print(f'\n===== {t} @{hex(va)} ====='); r=0
    for i in md.disasm(data[off:off+n],va):
        print(f'  {i.address:#x}: {i.mnemonic:8s} {i.op_str}')
        if i.mnemonic=='ret':
            r+=1
            if r>=sr: break
dis(0x1403981d0, 420, 'case3 helper ClientPrimitivePropertyNode 构造', 2)
dis(0x140e6e470, 500, '被调: 0x140e6e470 (NRL基类构造?)', 2)
