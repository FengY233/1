#!/usr/bin/env python3
"""t48_types.py — Task48: BigWorld DataType 流格式解码器 (createFromStream 白盒语义)
类型树来自: def 文件 (367属性+200alias) + 内建基元
流格式权威 (BigWorld 14.4 源码 + 反汇编 142aafb50 双证):
  readPackedInt = u8, 0xFF → u24 LE
  定长基元小端; STRING/BLOB/PYTHON = packedInt len + bytes
  ARRAY<T>/TUPLE<T>: size==0 变长(先 packedInt n) / size>0 定长 n 个
  FIXED_DICT: allowNone → [u8 hasValues](0=None止) / 字段依序递归
  VECTOR2/3/4 = 2/3/4 × f32
"""
import struct, json

class StreamR:
    __slots__=('b','p','err')
    def __init__(s,b,p=0): s.b=b; s.p=p; s.err=False
    def rem(s): return len(s.b)-s.p
    def rd(s,n):
        if n<0: s.err=True; return b''
        if s.p+n>len(s.b):
            s.err=True; avail=s.b[s.p:]; s.p=len(s.b)
            return avail+b'\x00'*(n-len(avail))
        r=s.b[s.p:s.p+n]; s.p+=n; return r
    def pkint(s):
        v=s.rd(1)[0]
        if v==0xff:
            b3=s.rd(3); v=b3[0]|(b3[1]<<8)|(b3[2]<<16)
        return v

PRIMS={'INT8':1,'UINT8':1,'BOOL':1,'INT16':2,'UINT16':2,'INT24':3,'UINT24':3,
       'INT32':4,'UINT32':4,'FLOAT':4,'FLOAT32':4,'FLOAT64':8,'INT64':8,'UINT64':8,'DB_ID':8,
       'VECTOR2':8,'VECTOR3':12,'VECTOR4':16}

class TypeTab:
    def __init__(s, deffile='/tmp/wot/t48_deftypes.json'):
        d=json.load(open(deffile))
        s.alias=d['aliases']; s.ent=d['entities']

    def expand(s, tnode, depth=0):
        """def type_tree 节点 → 规范式:
        ('prim',name,size) | ('str',kind) | ('seq',elem,n) | ('dict',[(fname,elem)],allowNone) | None"""
        if depth>8 or not tnode: return None
        if isinstance(tnode,str):
            t=tnode; tnode={}
        else:
            t=tnode.get('t','')
        if t in PRIMS: return ('prim',t,PRIMS[t])
        if t in ('STRING','BLOB'): return ('str',t)
        if t=='PYTHON': return ('str','PYTHON')
        if t in ('ARRAY','TUPLE'):
            n=int(tnode.get('size',0) or 0)
            for f in tnode.get('fields',[]):
                if 'type' in f:
                    e=s.expand(f['type'],depth+1)
                    if e: return ('seq',e,n)
            return None
        if t in ('MAILBOX','ENTITY_MAILBOX'): return ('prim','MAILBOX',8)
        if t=='OBJECT_ID': return ('prim','OBJECT_ID',8)
        if t in s.alias:
            return s.expand(s.alias[t], depth+1)
        if 'fields' in tnode and not t:
            fs=[]
            for f in tnode['fields']:
                if 'type' in f:
                    e=s.expand(f['type'],depth+1)
                    fs.append((f.get('field',f.get('n','?')), e))
            an=(tnode.get('allowNone') in ('true','1'))
            if fs: return ('dict',fs,an)
        return None

    def ent_prop(s, ent, prop):
        p=s.ent.get(ent,{}).get(prop)
        if not p: return None
        return s.expand(p.get('type'))

def decode_value(r, t):
    """按规范式类型解码一个值; 返回 (value, ok)。r.err 置位=失败"""
    if t is None: return ('?',None)
    k=t[0]
    if k=='prim':
        name,sz=t[1],t[2]
        raw=r.rd(sz)
        if r.err: return ('ERR',False)
        if name in ('FLOAT','FLOAT32'): return struct.unpack('<f',raw)[0],True
        if name=='FLOAT64': return struct.unpack('<d',raw)[0],True
        if name in ('VECTOR2','VECTOR3','VECTOR4'):
            return tuple(round(x,4) for x in struct.unpack('<'+'f'*(sz//4),raw)),True
        if name in ('INT8','INT16','INT24','INT32','INT64'):
            return int.from_bytes(raw,'little',signed=True),True
        if name=='BOOL': return raw[0]!=0,True
        if name in ('MAILBOX','OBJECT_ID'):
            return int.from_bytes(raw,'little'),True
        return int.from_bytes(raw,'little'),True
    if k=='str':
        l=r.pkint()
        if r.err or l>r.rem(): return ('ERR',False)
        raw=r.rd(l)
        if t[1]=='PYTHON':
            return ('pickle',len(raw),raw[:16].hex()),True
        try: return raw.decode('utf-8'),True
        except: return raw,True
    if k=='seq':
        _,elem,n=t[1],t[2]
        if n==0:
            n=r.pkint()
            if r.err or n>4096: return ('ERR',False)
        if isinstance(elem,tuple) and elem[0]=='prim':
            sz=elem[2]
            if sz*n>r.rem(): return ('ERR',False)
            if elem[1] in ('FLOAT','FLOAT32'):
                return tuple(round(x,4) for x in struct.unpack('<%df'%n,r.rd(4*n))),True
            if elem[1] in ('VECTOR2','VECTOR3','VECTOR4'):
                w=elem[2]//4
                return tuple(tuple(round(x,4) for x in struct.unpack('<%df'%w,r.rd(elem[2]))) for _ in range(n)),True
        vals=[]
        for i in range(n):
            v,ok=decode_value(r,elem)
            if not ok: return ('ERR',False)
            vals.append(v)
        return vals,True
    if k=='dict':
        fs=t[1]; an=t[2]
        if an:
            hv=r.rd(1)[0]
            if r.err: return ('ERR',False)
            if hv==0: return None,True
        out={}
        for fname,ft in fs:
            v,ok=decode_value(r,ft)
            if not ok: return ('ERR',False)
            out[fname]=v
        return out,True
    return ('?',None)

# ── 自适应值边界推断: 给定字节串, 枚举候选类型, 返回 (消耗字节数, 类型标签) 列表 ──
GUESS_PRIMS=[('INT8',1),('UINT8',1),('INT16',2),('UINT16',2),('INT32',4),('UINT32',4),
             ('FLOAT32',4),('INT64',8),('FLOAT64',8),('VECTOR3',12)]

def guess_candidates(buf, p, maxstr=64):
    """在 buf[p:] 处生成候选 (consumed, tag)。锚点约束: consumed 后下一条消息头应合法"""
    out=[]
    rem=len(buf)-p
    for name,sz in GUESS_PRIMS:
        if sz<=rem: out.append((sz,'prim:'+name))
    if rem>=1:
        l=buf[p]
        hdr=1
        if l==0xff and rem>=4:
            l=buf[p+1]|(buf[p+2]<<8)|(buf[p+3]<<16)
            hdr=4
        if 0<=l<=min(maxstr,rem-hdr):
            out.append((hdr+l,'str'))
    if rem>=1:
        n=buf[p]
        if n*4<=rem-1 and n<=128:
            out.append((1+n*4,'seq:i32/f32[%d]'%n))
        if n*8<=rem-1 and n<=64:
            out.append((1+n*8,'seq:i64/f64[%d]'%n))
    return out
