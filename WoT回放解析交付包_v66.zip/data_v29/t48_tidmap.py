#!/usr/bin/env python3
"""t48_tidmap.py — corpus 自证 typeId→组件名映射 (rk2 创建体 tid+name 普查)"""
import sys, glob, struct, re
sys.path.insert(0,'/home/z/my-project/scripts')
from survey_new_replays import load
from collections import defaultdict, Counter
REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TUNDRA=[f for f in REPLAYS if 'tundra' in f][0]
RND=[f for f in REPLAYS if f!=TUNDRA]

def read_len(b,p):
    l=b[p]; p+=1
    if l==0xff:
        l=b[p]|(b[p+1]<<8)|(b[p+2]<<16); p+=3
    return l,p

tid_names=defaultdict(Counter)   # tid -> name 计数
# 只走可靠前缀: 首消息后 cls0/cls1, rk2 的 [tid][len][name] 是强 ASCII 特征
for f in RND:
    blocks, declared, slen, pkts = load(f)
    for t,c,pl in pkts:
        if t!=0x32: continue
        b=pl[4:]; n=len(b)
        if n<2: continue
        p=2; guard=0
        while p+3<=n and guard<80:
            guard+=1
            mcls=b[p]; mid=(b[p+1]<<8)|b[p+2]; p+=3
            if mcls==0:
                if p+3>n: break
                objId=struct.unpack('>H',b[p:p+2])[0]; rk=b[p+2]; p+=3
                if rk>6: break
                if rk==1:
                    if p+4>n: break
                    p+=4
                elif rk==2:
                    if p+2>n: break
                    tid=struct.unpack('<H',b[p:p+2])[0]; p+=2
                    l,p2=read_len(b,p)
                    if p2+l>n or l>64: break
                    nm=b[p2:p2+l]
                    try: nm.decode('ascii')
                    except: break
                    tid_names[tid][nm.decode('ascii') if l else '']+=1
                    break   # rk2 后文法复杂, 停
                elif rk in (3,4,5): break
            elif mcls==1:
                # clist 粗读: 到 0x00 或 0x82
                q=p
                while q<n:
                    cb=b[q]
                    if cb==0: q+=1; break
                    if cb==0x82: q+=1+(( (q-p) and 0)+0); break
                    q+=1
                    if cb in (0x80,): q+=2
                p=q
                # 每元素 rk 粗试
                okc=True
                while p+1<=n:
                    rk=b[p]; p+=1
                    if rk>6: okc=False; break
                    if rk==1:
                        if p+4>n: okc=False; break
                        p+=4
                    elif rk==2:
                        if p+2>n: okc=False; break
                        tid=struct.unpack('<H',b[p:p+2])[0]; p+=2
                        l,p2=read_len(b,p)
                        if p2+l>n or l>64: okc=False; break
                        nm=b[p2:p2+l]
                        if l:
                            try: nm.decode('ascii')
                            except: okc=False; break
                        tid_names[tid][nm.decode('ascii') if l else '']+=1
                        okc=False; break   # rk2 后停
                    elif rk==5:
                        l,p2=read_len(b,p)
                        if p2+l>n: okc=False; break
                        p=p2+l
                    elif rk in (0,3,4,6):
                        okc=False; break
                if not okc: break
            else: break

print(f'tid 种类: {len(tid_names)}')
# 归并: 去掉 _数字 后缀
tid2base={}
for tid,cnts in sorted(tid_names.items()):
    base=Counter()
    for nm,c in cnts.items():
        b2=re.sub(r'_\d+$','',nm) if nm else '(空)'
        base[b2]+=c
    top=base.most_common(3)
    tid2base[tid]=top[0][0] if top else '?'
    print(f'  tid={tid:4d} (样本{sum(cnts.values()):4d}): {top}')
