#!/usr/bin/env python3
"""t48_king.py — tid=125/127 样本解剖 (全corpus 32%流量)"""
import sys, glob, struct
sys.path.insert(0,'/home/z/my-project/scripts')
from survey_new_replays import load
REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TUNDRA=[f for f in REPLAYS if 'tundra' in f][0]
RND=[f for f in REPLAYS if f!=TUNDRA]
import re
shown={'125':0,'127':0}
for f in RND:
    blocks, declared, slen, pkts = load(f)
    for t,c,pl in pkts:
        if t!=0x32: continue
        b=pl[4:]; n=len(b)
        for i in range(n-8):
            if b[i]!=0x02: continue
            tid=b[i+1]|(b[i+2]<<8)
            if tid not in (125,127): continue
            l=b[i+3]
            if l!=0 or i+4>n: continue
            key=str(tid)
            if shown[key]>=2: continue
            shown[key]+=1
            print(f'=== tid={tid} @{i} 包长{n} 上下文:')
            st=max(0,i-16)
            seg=b[st:min(n,i+40)]
            for j in range(0,len(seg),16):
                ch=seg[j:j+16]
                print(f'  {st+j:4d}: '+' '.join(f'{x:02x}' for x in ch).ljust(48)+' '+''.join(chr(x) if 32<=x<127 else '.' for x in ch))
            print()
    if all(v>=2 for v in shown.values()): break
