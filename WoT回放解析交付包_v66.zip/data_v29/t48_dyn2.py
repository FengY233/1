#!/usr/bin/env python3
"""t48_dyn2.py — 0x1403991a0 后半: 属性循环+初值+掩码语义"""
import pefile
from capstone import *
EXE='/tmp/wot/wotexe/WorldOfTanks.exe'
pe=pefile.PE(EXE,fast_load=True); base=pe.OPTIONAL_HEADER.ImageBase
data=open(EXE,'rb').read()
def va2off(va):
    for s in pe.sections:
        if base+s.VirtualAddress<=va<base+s.VirtualAddress+max(s.Misc_VirtualSize,s.SizeOfRawData):
            return s.PointerToRawData+(va-base-s.VirtualAddress)
md=Cs(CS_ARCH_X86,CS_MODE_64)
off=va2off(0x140399352); r=0
print('===== 0x1403991a0 续 @0x140399352 =====')
for i in md.disasm(data[off:off+700],0x140399352):
    print(f'  {i.address:#x}: {i.mnemonic:8s} {i.op_str}')
    if i.mnemonic=='ret':
        r+=1
        if r>=2: break
