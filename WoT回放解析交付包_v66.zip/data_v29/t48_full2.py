#!/usr/bin/env python3
"""t48_full2.py — Task48 终版解码器: rk2=clist+位图+置位属性初值; rk3/4=纯值; 全DFS回溯
文法权威(反汇编钉死):
  class0: [u16 BE objId][u8 regKey] + 创建体[regKey]
  class1: clist(base=mid) + 每元素 [u8 regKey]+创建体
  rk2 创建体: [u16 LE tid][len][name] + clist(nid) + 置位属性初值(位图选择)
  rk3/4 创建体: 纯 DataType 初值(自适应回溯)
  更新: rk1/2/6 空; rk3 纯值; rk4 [kind][blob]或纯值; rk0 Root复杂
"""
import sys, glob, struct
sys.path.insert(0,'/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter

REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
TUNDRA = [f for f in REPLAYS if 'tundra' in f][0]
RND = [f for f in REPLAYS if f != TUNDRA]

def read_len(b,p):
    l=b[p]; p+=1
    if l==0xff:
        l=b[p]|(b[p+1]<<8)|(b[p+2]<<16); p+=3
    return l,p

def clist(b,p,base,n):
    """返回 (vals, flags, p) | None"""
    vals,flags,v=[],set(),base
    while True:
        if p>=n: return None
        c=struct.unpack('b',b[p:p+1])[0]; p+=1
        if c==0: return vals,flags,p
        elif c==-0x80:
            if p+2>n: return None
            v=struct.unpack('>H',b[p:p+2])[0]; p+=2; vals.append(v)
        elif c==-0x7f: vals.append(0)
        elif c==-0x7e:
            nmask=(len(vals)+7)>>3
            if p+nmask>n: return None
            mask=b[p:p+nmask]; p+=nmask
            for i in range(len(vals)):
                if mask[i>>3]&(1<<(i&7)): flags.add(i)
            return vals,flags,p
        elif 1<=c<=0x7f:
            v+=c; vals.append(v)
        else:
            for _ in range(c+126):
                v+=1; vals.append(v)

VALUE_LENS=[0,1,2,4,8,12,16]

def value_candidates(b,p,n):
    """rk3/4 值体候选消耗长度"""
    cand=[]
    rem=n-p
    for L in VALUE_LENS:
        if L<=rem: cand.append(L)
    if rem>=1:
        l=b[p]
        hdr=4 if l==0xff else 1
        if l==0xff and rem>=4:
            l=b[p+1]|(b[p+2]<<8)|(b[p+3]<<16)
        if hdr+l<=rem and l<=96: cand.append(hdr+l)
    return cand

def parse_stream(stream, maxvisit=60000):
    b=stream; n=len(b)
    if n<2: return None
    nodes={}
    visit=[0]
    def step(p,depth):
        """读一条消息; 返回 ('done'|'tail', p) | None"""
        if p>=n: return ('done',p)
        if p+3>n: return ('tail',p) if n-p<=2 else None
        mcls=b[p]; mid=(b[p+1]<<8)|b[p+2]; q=p+3
        if mcls>6 or mcls==5: return None
        visit[0]+=1
        if visit[0]>maxvisit: return None
        return dispatch(q,mcls,mid,depth+1)
    def create_cands(p,rk,mid,depth):
        """创建体候选 p 列表"""
        out=[]
        if rk in (0,6): out.append(p)
        elif rk==1:
            if p+4<=n: out.append(p+4)
        elif rk==2:
            if p+2>n: return out
            p+=2
            l,p2=read_len(b,p)
            if p2+l>n: return out
            p3=p2+l
            r=clist(b,p3,mid,n)
            if r is None: return out
            vals,flags,p4=r
            k=len(flags)
            # k 个初值: 各自从 value_candidates — 需要嵌套组合, 用递归生成器
            def gen(pp,cnt,acc):
                if cnt==0:
                    yield (pp,tuple(acc)); return
                for L in value_candidates(b,pp,n):
                    acc.append(L)
                    yield from gen(pp+L,cnt-1,acc)
                    acc.pop()
            if k==0:
                out.append(p4)
            else:
                cnt=0
                for pp,lens in gen(p4,k,[]):
                    out.append(pp)
                    cnt+=1
                    if cnt>=12: break   # 前12个组合
        elif rk in (3,4):
            for L in value_candidates(b,p,n): out.append(p+L)
        elif rk==5:
            if p>=n: return out
            l,p2=read_len(b,p)
            if p2+l<=n: out.append(p2+l)
        return out
    def dispatch(p,mcls,mid,depth):
        if depth>60: return None
        if mcls==0:
            if p+3>n: return None
            objId=struct.unpack('>H',b[p:p+2])[0]; rk=b[p+2]; q=p+3
            if rk>6: return None
            nodes[objId]=rk
            for np in create_cands(q,rk,mid,depth):
                r=step(np,depth)
                if r is not None: return r
            return None
        elif mcls==1:
            r=clist(b,p,mid,n)
            if r is None: return None
            vals,flags,q=r
            def rec(i,q2):
                if i==len(vals):
                    return step(q2,depth)
                if q2+1>n: return None
                rk=b[q2]; q3=q2+1
                if rk>6: return None
                nodes[vals[i]]=rk
                for np in create_cands(q3,rk,vals[i],depth+1):
                    r2=rec(i+1,np)
                    if r2 is not None: return r2
                return None
            return rec(0,q)
        elif mcls in (2,3):
            return step(p,depth)
        elif mcls in (4,6):
            rk=nodes.get(mid)
            if rk is None: return None
            if rk in (1,2,6): return step(p,depth)
            if rk==3:
                for L in value_candidates(b,p,n):
                    r=step(p+L,depth)
                    if r is not None: return r
                return None
            if rk==4:
                if p+1>n: return None
                kind=b[p]; q=p+1
                if kind<=1:
                    l,q2=read_len(b,q)
                    if q2+l>n: return None
                    return step(q2+l,depth)
                for L in value_candidates(b,p,n):
                    r=step(p+L,depth)
                    if r is not None: return r
                return None
            return None   # rk0 Root
        return None
    mid0=struct.unpack('>H',b[0:2])[0]
    return dispatch(2,0,mid0,0)

if __name__=='__main__':
    pkgs=[]
    for f in RND:
        blocks, declared, slen, pkts = load(f)
        for t,c,pl in pkts:
            if t==0x32: pkgs.append(pl[4:])
    print(f'0x32 包总数: {len(pkgs)}')
    ok=0; kinds=Counter(); fails=[]
    import time; t0=time.time()
    for idx,s in enumerate(pkgs):
        r=parse_stream(s)
        if r is not None: ok+=1; kinds[r[0]]+=1
        elif len(fails)<6: fails.append(idx)
    print(f'全解 {ok}/{len(pkgs)} ({100*ok/len(pkgs):.1f}%) {dict(kinds)} 耗时{time.time()-t0:.0f}s')
    print('失败样本 idx:', fails)
