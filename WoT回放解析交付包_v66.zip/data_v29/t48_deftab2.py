#!/usr/bin/env python3
"""t48_deftab2.py — v2: Properties + Volatile + Implements接口递归合并 → t48_deftypes2.json"""
import sys, json, glob, os
sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file

ED = '/tmp/wot/wot_scripts/entity_defs'

def sec_text(s):
    if s.type == 1: return s.asString()
    if s.children: return None
    if s.type == 0 and not s.data: return None
    if s.type == 2: return str(s.asInt())
    if s.type == 4: return 'true' if s.asBool() else 'false'
    return s.data.hex()

def type_tree(node):
    txt = sec_text(node)
    out = {}
    if txt: out['t'] = txt
    for cc in node.children:
        if cc.name in ('Size','size'): out['size'] = sec_text(cc)
        elif cc.name in ('AllowNone','allowNone'): out['allowNone'] = sec_text(cc)
        elif cc.name in ('DBLength','DatabaseLength'): out['dbLen'] = sec_text(cc)
        elif cc.name not in ('Properties',):
            sub = {'n': cc.name}
            for fc in cc.children:
                if fc.name == 'Type': sub['type'] = type_tree(fc)
                else: sub[fc.name.lower()] = sec_text(fc)
            if 'type' not in sub and not cc.children:
                sub['v'] = sec_text(cc)
            out.setdefault('fields', []).append(sub)
    pw = None
    for cc in node.children:
        if cc.name == 'Properties': pw = cc
    if pw:
        for f in pw.children:
            entry = {'field': f.name}
            for fc in f.children:
                if fc.name == 'Type': entry['type'] = type_tree(fc)
                else: entry[fc.name.lower()] = sec_text(fc)
            out.setdefault('fields', []).append(entry)
    return out

def collect(root):
    """返回 (props, volatiles, implements)"""
    props, vols, impls = {}, {}, []
    for sec in root.children:
        if sec.name in ('Properties','Volatile'):
            tgt = props if sec.name=='Properties' else vols
            for c in sec.children:
                row = {}
                for cc in c.children:
                    if cc.name == 'Type': row['type'] = type_tree(cc)
                    elif cc.name in ('Flags','DetailLevel','Identifier','DatabaseLength'):
                        row[cc.name.lower()] = sec_text(cc)
                tgt[c.name] = row
        elif sec.name == 'Implements':
            for cc in sec.children:
                v = sec_text(cc)
                impls.append(v if v else cc.name)
    return props, vols, impls

aliases = {}
for c in decode_file(os.path.join(ED,'alias.xml')).children:
    aliases[c.name] = type_tree(c)

interfaces = {}
for p in sorted(glob.glob(os.path.join(ED,'interfaces','*.def'))):
    nm = os.path.basename(p)[:-4]
    try: root = decode_file(p)
    except Exception: continue
    pr, vo, im = collect(root)
    interfaces[nm] = {'props': pr, 'vols': vo, 'implements': im}

table = {}
for p in sorted(glob.glob(os.path.join(ED,'*.def'))):
    ent = os.path.basename(p)[:-4]
    try: root = decode_file(p)
    except Exception as e:
        table[ent] = {'_err': str(e)}; continue
    pr, vo, im = collect(root)
    table[ent] = {'props': pr, 'vols': vo, 'implements': im}

json.dump({'aliases': aliases, 'entities': table, 'interfaces': interfaces},
          open('/tmp/wot/t48_deftypes2.json','w'), ensure_ascii=False, indent=1)

nv = sum(len(v['props'])+len(v['vols']) for v in table.values())
ni = sum(len(v['props'])+len(v['vols']) for v in interfaces.values())
print(f'entities={len(table)} (props+vols={nv}) interfaces={len(interfaces)} ({ni}) aliases={len(aliases)}')
v = table['Vehicle']
print('Vehicle props:', len(v['props']), 'vols:', list(v['vols'].keys())[:12])
print('Vehicle.position:', json.dumps(v['vols'].get('position')))
print('Vehicle.pitch:', json.dumps(v['vols'].get('pitch')))
