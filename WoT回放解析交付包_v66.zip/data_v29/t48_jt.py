#!/usr/bin/env python3
"""t48_jt.py — 读七案跳转表 0x140399150 (slot3 创建体各regKey入口) + 反汇编 regKey3/4 案"""
import pefile, struct
from capstone import *
EXE='/tmp/wot/wotexe/WorldOfTanks.exe'
pe=pefile.PE(EXE,fast_load=True); base=pe.OPTIONAL_HEADER.ImageBase
data=open(EXE,'rb').read()
def va2off(va):
    for s in pe.sections:
        if base+s.VirtualAddress<=va<base+s.VirtualAddress+max(s.Misc_VirtualSize,s.SizeOfRawData):
            return s.PointerToRawData+(va-base-s.VirtualAddress)
md=Cs(CS_ARCH_X86,CS_MODE_64)
off=va2off(0x140399150)
print('七案跳转表 @0x140399150 (slot3 创建体):')
for i in range(7):
    tgt=struct.unpack('<Q', data[off+i*8:off+i*8+8])[0]
    print(f'  regKey {i}: {tgt:#x}')
def dis(va,n,t,sr=2):
    off=va2off(va); print(f'\n===== {t} @{hex(va)} ====='); r=0
    for i in md.disasm(data[off:off+n],va):
        print(f'  {i.address:#x}: {i.mnemonic:8s} {i.op_str}')
        if i.mnemonic=='ret':
            r+=1
            if r>=sr: break
