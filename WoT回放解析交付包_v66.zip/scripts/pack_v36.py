#!/usr/bin/env python3
"""pack_v36.py — V36 打包: Task 59-c 0x39 对象身份定案 + clk 时间线重述"""
import os, hashlib, json, zipfile, shutil, tempfile

BASE = '/home/z/my-project'
V35 = f'{BASE}/download/WoT回放解析交付包_v35.zip'
OUT = f'{BASE}/download/WoT回放解析交付包_v36.zip'

def md5f(p):
    h = hashlib.md5()
    with open(p, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()

tmp = tempfile.mkdtemp(prefix='v36_')
with zipfile.ZipFile(V35, mode='r') as z:
    z.extractall(tmp)
print(f'V35 底座解包: {sum(len(fs) for _, _, fs in os.walk(tmp))} 文件')

for name in ('findings.md', 'worklog.md'):
    dst = f'{tmp}/{name}'
    if os.path.exists(dst):
        os.remove(dst)
    shutil.copy2(f'{BASE}/{name}', dst)

# data_v39 增量同步
n39 = 0
for f in os.listdir(f'{BASE}/download/data_v39'):
    src = f'{BASE}/download/data_v39/{f}'
    dst = f'{tmp}/data_v39/{f}'
    if not os.path.exists(dst) or os.path.getmtime(src) > os.path.getmtime(dst):
        shutil.copy2(src, dst)
        n39 += 1
print(f'data_v39 同步: {n39} 件')

nsc = 0
for f in os.listdir(f'{BASE}/scripts'):
    if f.startswith('t59_') or f == 'pack_v36.py':
        dst = f'{tmp}/scripts/{f}'
        if not os.path.exists(dst) or os.path.getmtime(f'{BASE}/scripts/{f}') > os.path.getmtime(dst):
            shutil.copy2(f'{BASE}/scripts/{f}', dst)
            nsc += 1
print(f'脚本同步: {nsc} 件')

rd = f'{tmp}/README.md'
if not os.path.exists(rd):
    rd = f'{tmp}/readme.md'
with open(rd, 'a', encoding='utf-8') as f:
    f.write('''

## V36 (2026-09-26) — Task 59-c: 0x39 对象身份定案 ★★★★★
- **0x39 宿主确名 = NetworkEntity(typeID=40) 剧情特效实体**（prefab_path 铁证）:
  - siegfried: 城市轰炸剧情——15 栋建筑 7.4 秒内依次 transition→destroyed（31 个事件 NE 全落 0x39 流窗口内）
  - WZ-219: 飞机坠毁剧情——双机 1.65s 先后坠毁（单机受创→摧毁 0.6s）
  - karelia×2: 地堡破坏剧情
- **"宠物遥测"假说推翻**: 72B 运动学（低空 22-44m + 1.8km 游弋）= 坠落物/碎片云遥测
- **clk 1/65536s 全通道时间线重述**: 0x39 特效窗口 437-552s = 战斗窗口 563s 的 78-98%
- 0x39 通道理解度 0.75→0.85; **总体按字节加权理解度 96.1%→96.4%**
''')

audit = {
 "version": "v36", "date": "2026-09-26",
 "task": "Task 59-c: 0x39 对象身份定案(剧情特效实体) + clk 全通道时间线重述",
 "headline": [
  "★★★★★ 0x39 宿主确名 = NetworkEntity(typeID=40) 剧情特效实体——prefab_path 直读: siegfried=14_city_bombing(15 建筑 7.4s 齐毁)/WZ-219=05_planesCrash01(双机 1.65s)/karelia=01_bunker_destruction",
  "★★★★★ 宠物遥测假说推翻——72B 运动学(y 22-44m 低空/1.8km 游弋/量化速度级)=坠落物碎片云遥测; seq 单链为组件级序",
  "★★★ clk 1/65536s 全通道关键时间量表重述(0x39 窗口 437-552s=战斗 78-98%, 注入节拍 0.05/0.1/0.025s, 特效事件秒级换算)",
  "0x39 通道理解度 0.75→0.85; 总体 96.1%→96.4%"
 ],
 "coverage": {
  "corpus": "10 场随机战(11 文件)", "total_pkts": 1514067, "total_payload_bytes": 48202991,
  "weighted_understanding_pct": 96.4,
  "channel_status": {
   "0x0A": {"share": 68.05, "u": 0.985, "note": "volatile 位置流全解(B=悬挂车体偏移+tail=注入源)"},
   "0x07": {"share": 12.94, "u": 1.0}, "0x1A": {"share": 6.12, "u": 0.95}, "0x26": {"share": 3.89, "u": 0.95},
   "0x39": {"share": 2.48, "u": 0.85, "note": "剧情特效实体复制流, 对象身份定案+叙事级可读; 余 41B 字段级(指纹级)"},
   "0x37": {"share": 1.52, "u": 0.95, "note": "NRL 全解; 余 Root 前缀+深路径 2082"},
   "0x05": {"share": 1.18, "u": 1.0}, "0x32": {"share": 0.69, "u": 1.0}, "0x24": {"share": 0.2, "u": 1.0},
   "0x04": {"share": 0.05, "u": 1.0}, "0x3D": {"share": 0.0, "u": 1.0}
  },
  "remaining": [
   "①0x37 Root 体前缀精确文法 + 深路径 2082 条(0x37 尾巴, 1.52% 字节内的 ~0.07%)",
   "②指纹级: 0x39 41B 字段级/子对象槽位/q_xz=16416314×2⁻³⁰ 数值来源/B_y×车型悬挂行程表/LSB 位表内容",
   "③边缘: karelia2 deathOrder -1 例 / ln156 消歧 / 59 tid 补名 / 0x35 class2 NRL 形态"
  ]
 }
}
with open(f'{tmp}/audit_v36.json', 'w', encoding='utf-8') as f:
    json.dump(audit, f, indent=1, ensure_ascii=False)

if os.path.exists(OUT):
    os.remove(OUT)
with zipfile.ZipFile(OUT, mode='w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for root, dirs, files in os.walk(tmp):
        dirs.sort()
        for fn in sorted(files):
            fp = os.path.join(root, fn)
            z.write(fp, os.path.relpath(fp, tmp))

nfiles = sum(len(fs) for _, _, fs in os.walk(tmp))
size = os.path.getsize(OUT)
digest = md5f(OUT)
with zipfile.ZipFile(OUT, mode='r') as z:
    bad = z.testzip()
    assert bad is None, f'corrupt: {bad}'
    names = z.namelist()
print(f'V36 打包完成: {nfiles} 文件(包内 {len(names)} 条目), {size} B ({size/1048576:.2f} MB), md5={digest}')

os.makedirs(f'{BASE}/upload/backup_v36', exist_ok=True)
shutil.copy2(OUT, f'{BASE}/upload/backup_v36/WoT回放解析交付包_v36.zip')
shutil.copy2(f'{tmp}/audit_v36.json', f'{BASE}/upload/backup_v36/audit_v36.json')
shutil.copy2(f'{BASE}/findings.md', f'{BASE}/upload/backup_v36/findings.md')
shutil.copy2(f'{BASE}/worklog.md', f'{BASE}/upload/backup_v36/worklog.md')
shutil.copy2(f'{tmp}/audit_v36.json', f'{BASE}/download/audit_v36.json')
shutil.rmtree(tmp)
print('backup_v36 入库 + audit_v36.json 已放 download/')
