# -*- coding: utf-8 -*-
"""时间轴重建 v3: 逐段 tick 缺口定位 + 播放速度曲线"""
import sys, json, struct, statistics
sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile
from collections import defaultdict

BATTLE_START_BT = 139.769

# 会话轨迹
own_pts = []
for line in open('/home/z/my-project/upload/session_20260911_175934.jsonl', encoding='utf-8'):
    o = json.loads(line)
    if o['ev'] == 'battle_tick':
        d = o['data']
        if d.get('own'):
            own_pts.append((d['bt'] - BATTLE_START_BT, *d['own']['position']))

rf = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
pkts = rf.pkts
p3_pkt = next(p[3] for p in pkts if p[0] == 0x16 and p[2] == b'\x03\x00\x00\x00')
p4_pkt = next(p[3] for p in pkts if p[0] == 0x16 and p[2] == b'\x04\x00\x00\x00')

# 回放玩家轨迹点
rep_pts = []
for ty, clock, payload, idx in pkts:
    if ty != 0xA or not (p3_pkt <= idx <= p4_pkt) or len(payload) < 45:
        continue
    eid, _ = struct.unpack_from('<II', payload, 0)
    if eid != 546611525:
        continue
    x, y, z = struct.unpack_from('<3f', payload, 8)
    rep_pts.append((idx, clock, x, y, z))

# 锚点（含宽跨度候选的中点信息）
anchors = []
for idx, clock, x, y, z in rep_pts:
    cands = [bt for bt, sx, sy, sz in own_pts if abs(sx-x) <= 2.0 and abs(sz-z) <= 2.0]
    if cands and max(cands) - min(cands) <= 8.0:
        anchors.append((idx, clock, sum(cands)/len(cands)))
anchors.sort()
print(f'锚点: {len(anchors)}')

# 战斗窗口内 tick 的 (idx, clock)
ticks_wc = [(p[3], p[1]) for p in pkts if p[0] == 0x36 and p3_pkt <= p[3] <= p4_pkt]
print(f'战斗窗口 tick: {len(ticks_wc)}')

# ---------- 分段: 用锚点聚类成段, 每段回归 (idx -> true秒) ----------
SEG_N = 40
per = max(1, len(anchors)//SEG_N)
segs = []
for i in range(0, len(anchors), per):
    chunk = anchors[i:i+per]
    if len(chunk) < 5:
        continue
    i0 = chunk[0][0]; i1 = chunk[-1][0]
    t0 = statistics.median(a[2] for a in chunk)
    t1 = t0
    # 段内取前1/4与后1/4中位数作为端点
    q = len(chunk)//4
    if q >= 2:
        t0 = statistics.median(a[2] for a in chunk[:q])
        t1 = statistics.median(a[2] for a in chunk[-q:])
    segs.append((i0, i1, t0, t1))

print('\n段分析: [锚点流区间] 真实时间区间 | 段内tick数 | 期望tick数 | 缺口')
total_deficit = 0.0
prev_t1 = None
for (i0, i1, t0, t1) in segs:
    n_ticks = sum(1 for idx, _ in ticks_wc if i0 <= idx <= i1)
    expected = (t1 - t0) * 10
    deficit = expected - n_ticks
    total_deficit += max(0, deficit)
    flag = ' <<<< 缺口' if deficit > 8 else ''
    print(f'  pkt[{i0:>6}~{i1:>6}] true {t0:6.1f}→{t1:6.1f}s | ticks={n_ticks:>5} 期望={expected:6.1f} 缺={deficit:5.1f}{flag}')

print(f'\n累计 tick 缺口: {total_deficit:.1f} ticks = {total_deficit/10:.2f} 游戏秒')

# ---------- 播放速度曲线: 真实秒/墙钟秒 ----------
print('\n播放速度曲线(真实游戏秒 / 墙钟秒):')
for (i0, i1, t0, t1) in segs:
    clocks = [c for idx, c in ticks_wc if i0 <= idx <= i1]
    if len(clocks) >= 2 and t1 > t0:
        wall = (clocks[-1] - clocks[0]) / 1e6
        speed = (t1 - t0) / wall if wall > 0.01 else 0
        print(f'  true {t0:6.1f}→{t1:6.1f}s  wall {wall:5.2f}s  speed {speed:5.2f}x')
