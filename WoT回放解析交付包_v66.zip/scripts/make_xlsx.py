# -*- coding: utf-8 -*-
"""make_xlsx.py — 导出解码数据为 xlsx (遵循 xlsx 技能设计系统)"""
import json
import struct
import sys
from collections import Counter

sys.path.insert(0, '/home/z/my-project/skills/xlsx')
sys.path.insert(0, '/home/z/my-project/skills/xlsx/templates')
sys.path.insert(0, '/home/z/my-project/scripts')

from openpyxl import Workbook
from openpyxl.utils import get_column_letter

import base as xbase
from wot_replay_lib import ReplayFile

xbase.use_palette_explicit('professional')

REPLAY = '/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay'
R = ReplayFile(REPLAY)
pkts = R.pkts
d = json.load(open('/home/z/my-project/work/decoded_full.json', encoding='utf-8'))

data = open(REPLAY, 'rb').read()
magic, bc = struct.unpack_from('<II', data, 0)
pos = 8
blocks = []
for _ in range(bc):
    (blen,) = struct.unpack_from('<I', data, pos)
    blocks.append(data[pos + 4:pos + 4 + blen])
    pos += 4 + blen
j0 = json.loads(blocks[0].decode('utf-8'))
j1 = json.loads(blocks[1].decode('utf-8'))
r0 = j1[0]

veh_info = {int(k): v for k, v in j0['vehicles'].items()}
name_by = {vid: v['name'] for vid, v in veh_info.items()}
tracks = {int(k): v for k, v in d['vehicle_tracks'].items()}
last_seen = {vid: tr[-1][0] for vid, tr in tracks.items() if tr}

TYPE_INFO = {
    0x0: ('创建玩家Avatar', '[u32实体ID][u16][u32名长][名][u32流长][Avatar数据流:名字/会话/arenaExtraData pickle]'),
    0x1: ('controlEntity控制实体', '[u32 avatarID][u32 spaceID][u16][u32 车辆ID][3f位置][f偏航][f俯仰][f翻滚][u32长][实体流]'),
    0x2: ('选择实体', '[u32实体ID][u8标志]'),
    0x4: ('离开视野leaveAoI', '[u32实体ID]'),
    0x5: ('创建实体createEntity', '[u32实体ID][u32类型ID][u16][u32 spaceID][u32][u32][3f位置][u32×3][u32流长][实体属性流]'),
    0x6: ('实体全量数据', '[u32实体ID][u32字段][数据流]'),
    0x7: ('切片属性更新entityProperty', '[u32实体ID][u32属性号][u32长][属性值流]'),
    0x8: ('属性更新(嵌pickle)', '[u32实体ID][u32属性号][u32长][pickle数据]'),
    0xA: ('位置更新avatarUpdate', '[u32实体ID][u32别名/车辆][3f位置][3f速度][3f方向(偏航/俯仰/翻滚)][u8标志] 45B定长'),
    0xD: ('空间数据spaceData', '[u32 spaceID=7149][u32子项][数据]'),
    0xF: ('空间几何映射addSpaceGeometryMapping', '[u32 spaceID][u32总长][u8路径长][spaces/37_caucasus][4x4f恒等矩阵][u8标志]'),
    0x11: ('战斗结果battleResults', '[u16][u32长1][数据1][u32长2][数据2(压缩结果)]'),
    0x12: ('录制启动标记', '[u8标志] (先触发写入0x18/0x2D/0x30/0x3D头)'),
    0x15: ('时间基', '[f64 时间基值=141061.04]'),
    0x16: ('战斗阶段arenaPeriod', '[u32 1=等待 2=倒计时 3=战斗 4=结算]'),
    0x17: ('阶段倒计时', '[f32剩余秒: 29.943/899.948/60.0]'),
    0x18: ('客户端版本串', '[u32长]["2.4.0.0"]'),
    0x1A: ('观察者/相机更新', '[3f相机位置][f][f][3f注视点][3f方向][f缩放][f][f×2] 60B定长'),
    0x1B: ('相机模式串', '[u32长]["arcade"/"arty"/"strategic"/"prebattleHighlights"]'),
    0x1C: ('输入增量A', '[f32增量]'),
    0x1D: ('输入增量B', '[f32增量]'),
    0x1E: ('状态标记', '[u32 0/2]'),
    0x1F: ('性能统计', '[u8 fps][u18 ping ms][0xFF000000卡顿标志]'),
    0x20: ('相机朝向参数', '[f32][f32]'),
    0x22: ('玩家车辆ID标记', '[u32 玩家车辆实体ID=546611525]'),
    0x24: ('属性变更entityPropertyChange', '[u32实体ID][u8切片标志][u32长][属性数据]'),
    0x26: ('本地车辆状态快照', '[16B方向矩阵][3f位置][f FOV=1.0472][f×2] 40B定长'),
    0x2B: ('标记(u8)', '[u8=0]'),
    0x2D: ('构建串', '[u32长]["17, 1, 0, 5"]'),
    0x2E: ('标记(u8)', '[u8=0]'),
    0x30: ('脚本目录串', '[u32长]["sd"]'),
    0x31: ('客户端回调callbackData', '[u32名长][回调名][u32数据长][pickle参数]'),
    0x32: ('组件消息(可视状态/载具表)', '[u32长][u16组件类型(0x07da/0x07db/0x07dd...)[组件消息流(嵌pickle)]'),
    0x35: ('空标记', '(空载荷)'),
    0x36: ('游戏tick标记', '(空载荷, 战斗中10Hz)'),
    0x37: ('NRL节点更新(视觉层级)', '[u32长][NRL消息流]'),
    0x3D: ('实体定义哈希', '[u32长][32字符hex=5DF886F75E73B33CFF9D87FB9C69389C]'),
    0xFFFFFFFF: ('流结束符', '[16B校验和]'),
}

wb = Workbook()
wb.properties.creator = 'Z.ai'
wb.properties.title = 'WoT 2.4.0 回放完全解析数据包'


def style_sheet(ws, title, headers, widths):
    ws.sheet_view.showGridLines = False
    ws['B2'] = title
    ws['B2'].font = xbase.Font(name=xbase.FONT_NAME, size=14, bold=True, color=xbase.PRIMARY)
    for i, h in enumerate(headers, 2):
        c = ws.cell(row=4, column=i, value=h)
        c.font = xbase.Font(name=xbase.FONT_NAME, size=10, bold=True, color='FFFFFF')
        c.fill = xbase.PatternFill('solid', fgColor=xbase.PRIMARY)
        c.alignment = xbase.Alignment(horizontal='center', vertical='center')
    for i, w in enumerate(widths, 2):
        ws.column_dimensions[get_column_letter(i)].width = w


def fill_rows(ws, rows, start=5):
    for r, row in enumerate(rows, start):
        for cidx, val in enumerate(row, 2):
            if isinstance(val, str) and val.startswith('='):
                val = "'" + val
            c = ws.cell(row=r, column=cidx, value=val)
            c.font = xbase.Font(name=xbase.FONT_NAME, size=10, color=xbase.NEUTRAL_900)
            if (r - start) % 2 == 1:
                c.fill = xbase.PatternFill('solid', fgColor=xbase.NEUTRAL_100)
    ws.freeze_panes = 'B5'


# ─── Sheet1 概览 ───
ws = wb.active
ws.title = '概览'
style_sheet(ws, 'wotreplay 完全解析概览 — 20260911_1801_ussr-R52_Object_261_37_caucasus',
            ['项目', '值'], [34, 74])
rows = [
    ['文件', '20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay'],
    ['文件大小', '{:,} 字节'.format(len(data))],
    ['魔数', '0x11343212 (WoT v2 回放格式)'],
    ['客户端版本', '坦克世界 v.2.4.0.0 #942 (国服 CN, 构建串 17, 1, 0, 5)'],
    ['地图', '37_caucasus 胜利之门 (arenaTypeID=15, spaceID=7149)'],
    ['玩家', '巅峰荣誉v拍子 (playerID 7049414679)'],
    ['座驾', 'ussr:R52_Object_261 261工程 (X级火炮, 满血510)'],
    ['战斗类型', '随机战(ctf, battleType=1, bonusType=1), 15v15'],
    ['战斗时间', '2026-09-11 18:01:05 (arenaCreateTime unix=1789120856)'],
    ['战斗时长', '612 秒 (duration), 服务器10Hz tick 实测601.4秒'],
    ['胜负', '队伍2 获胜 (全歼, finishReason=1), 比分 15:10'],
    ['玩家战绩', '伤害1669 / 击杀1(Deiiv1) / 15发4直接命中14爆炸 / 眩晕192.2s×14 / 存活'],
    ['文件头块', '2 个JSON块: 块0=回放头(80,068B) 块1=战斗结果(110,228B)'],
    ['过渡区', '[u32 zlib解压长=7,106,831][u32 加密流有效长=1,834,785]'],
    ['加密', 'Blowfish-ECB + 前向异或(IV=0), 密钥16字节 DE72BEA0DE04BEB1DEFEBEEFDEADBEEF'],
    ['主流', '1,834,792B 加密 → zlib → 7,106,831B 包流 → 156,482 包 100%消费'],
    ['包类型数', '38 种 (0x00-0x3D + 0xFFFFFFFF结束符)'],
    ['clock字段', '客户端墙钟微秒; 本文件为服务器回放在线观看的再录制(0.5x-64x变速)'],
    ['实体总数', '160 个 (30车辆=类型6, 玩家Avatar=546611552, 其余特效/逻辑实体)'],
    ['实体定义哈希', '5DF886F75E73B33CFF9D87FB9C69389C'],
]
fill_rows(ws, rows)

# ─── Sheet2 包类型普查 ───
ws = wb.create_sheet('包类型普查')
style_sheet(ws, '38 种网络包类型普查（按数量降序）',
            ['类型', '名称', '数量', '占比', '载荷min/med/max(B)', '字节级布局'], [8, 26, 10, 9, 17, 80])
census = Counter(p[0] for p in pkts)
by_type = {}
for p in pkts:
    by_type.setdefault(p[0], []).append(len(p[2]))
rows = []
for t, c in census.most_common():
    sizes = sorted(by_type[t])
    nm, layout = TYPE_INFO.get(t, ('未知', '?'))
    rows.append(['0x%02X' % t if t != 0xFFFFFFFF else '0xFFFFFFFF', nm, c,
                 '%.2f%%' % (c * 100.0 / len(pkts)),
                 '%d/%d/%d' % (sizes[0], sizes[len(sizes) // 2], sizes[-1]), layout])
fill_rows(ws, rows)

# ─── Sheet3 实体表 ───
ws = wb.create_sheet('实体表')
style_sheet(ws, '全部 160 个游戏实体（BigWorld entity）',
            ['实体ID', '十六进制', '类型ID', '创建次数', '0xA位置更新数', '车辆?', '玩家名', '车型', '队伍'],
            [12, 12, 8, 10, 14, 8, 20, 26, 7])
rows = []
for e in sorted(d['entities'], key=lambda x: -x['updates_0xA']):
    rows.append([e['id'], e['hex'], ','.join(str(t) for t in e['types']), e['creates'],
                 e['updates_0xA'], '是' if e['is_vehicle'] else '', e['name'] or '',
                 e['vehicleType'] or '', e['team'] or ''])
fill_rows(ws, rows)

# ─── Sheet4 车辆战绩 ───
ws = wb.create_sheet('车辆战绩')
style_sheet(ws, '30 辆坦克战斗数据（来自结果JSON + 轨迹推算）',
            ['玩家名', '队伍', '车型', '击杀', '伤害', '经验', '阵亡', '击杀者', '最后轨迹(游戏秒)'],
            [24, 7, 26, 7, 9, 8, 7, 20, 14])
rows = []
for vid_str, recs in r0['vehicles'].items():
    vid = int(vid_str)
    rec = recs[-1]
    kid = rec.get('killerID', 0)
    rows.append([veh_info[vid]['name'], veh_info[vid]['team'],
                 veh_info[vid]['vehicleType'].split(':')[1], rec.get('kills', 0),
                 rec.get('damageDealt', 0), rec.get('xp', 0),
                 '否' if rec.get('deathReason', -1) < 0 else '是',
                 name_by.get(kid, '') if kid else '',
                 round(last_seen[vid], 1) if vid in last_seen else ''])
rows.sort(key=lambda r: (-r[1], -r[4]))
fill_rows(ws, rows)

# ─── Sheet5 击杀链 ───
ws = wb.create_sheet('击杀链')
style_sheet(ws, '26 次击杀时间线（按最后轨迹时间排序）',
            ['游戏秒(约)', '阵亡者', '队伍', '击杀者', '击杀者队伍'], [13, 22, 7, 22, 11])
deaths = []
for vid_str, recs in r0['vehicles'].items():
    vid = int(vid_str)
    rec = recs[-1]
    if rec.get('deathReason', -1) >= 0 and vid in last_seen:
        kid = rec.get('killerID', 0)
        deaths.append((last_seen[vid], veh_info[vid]['name'], veh_info[vid]['team'],
                       name_by.get(kid, '?'), veh_info.get(kid, {}).get('team', '')))
deaths.sort()
fill_rows(ws, [[round(t, 1), nm, tm, kn, kt] for t, nm, tm, kn, kt in deaths])

# ─── Sheet6 事件时间线 ───
ws = wb.create_sheet('事件时间线')
style_sheet(ws, '关键事件时间线（阶段/相机/回调）',
            ['游戏秒', '类型', '内容'], [13, 16, 88])
rows = []
for ph in d['phase_events']:
    if 'period' in ph:
        rows.append([round(-(periods := 0) or 0, 1) if False else '', '阶段切换',
                     'arenaPeriod → %d (1等待/2倒计时/3战斗/4结算)' % ph['period']])
for ce in d['camera_events']:
    rows.append([ce['game_t'], '相机模式', ce['mode']])
for ev in d['events']:
    if ev['callback'] == 'ERR':
        continue
    dt = ev.get('data', {})
    desc = ''
    if isinstance(dt, dict):
        a = dt.get('args', {})
        desc = 'eventID=%s %s' % (dt.get('eventID'), {k: (v if not isinstance(v, str) or len(v) < 40 else v[:40]) for k, v in a.items()})
    elif isinstance(dt, list):
        desc = str(dt)
    rows.append([ev['game_t'], ev['callback'].split('.')[-1], desc])
rows.sort(key=lambda r: (r[0] if isinstance(r[0], (int, float)) else -99999))
fill_rows(ws, rows)

# ─── Sheet7 玩家轨迹 ───
ws = wb.create_sheet('玩家轨迹')
style_sheet(ws, '玩家(261工程)位置轨迹（0xA位置更新采样, 每5个取1）',
            ['序号', '游戏秒', 'X', 'Y(高度)', 'Z', '朝向(弧度)'], [8, 10, 10, 10, 10, 13])
tr = tracks.get(546611525, [])
rows = [[i, t, x, y, z, yaw] for i, (t, x, y, z, yaw) in enumerate(tr[::5])]
fill_rows(ws, rows)

out = '/home/z/my-project/download/WoT回放解析数据包_20260911_caucasus.xlsx'
wb.save(out)
print('✅', out)

# 质检
import subprocess
r = subprocess.run(['python3', '/home/z/my-project/skills/xlsx/xlsx.py', 'validate', out],
                   capture_output=True, text=True)
print(r.stdout[-800:] if r.stdout else r.stderr[-800:])
