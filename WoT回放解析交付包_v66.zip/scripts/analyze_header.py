# -*- coding: utf-8 -*-
"""analyze_header.py — 块0/块1 JSON 元数据深度分析"""
import json
import struct
import io
import sys
from collections import Counter

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

DATA = '/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay'
data = open(DATA, 'rb').read()
magic, bc = struct.unpack_from('<II', data, 0)
pos = 8
blocks = []
for _ in range(bc):
    (blen,) = struct.unpack_from('<I', data, pos)
    blocks.append(data[pos + 4:pos + 4 + blen])
    pos += 4 + blen

j0 = json.loads(blocks[0].decode('utf-8'))

print('========== 块0 顶层字段 ==========')
for k, v in j0.items():
    if k == 'vehicles':
        print('  vehicles: {%d 个条目}' % len(v))
    elif k == 'serverSettings':
        print('  serverSettings: {%d 个键}' % len(v))
    else:
        print('  %-24s = %r' % (k, v))

print()
print('========== 车辆统计 ==========')
vehs = j0['vehicles']
print('总车辆数:', len(vehs))
teams = Counter(v['team'] for v in vehs.values())
print('队伍分布:', dict(teams))
print()
print('-- team1 --')
for vid, v in sorted(vehs.items(), key=lambda kv: kv[1]['team']):
    if v['team'] != 1:
        continue
    print('  %-10s %-28s %-20s clan=%-10s hp=%-5d prestige=%-4d stFrags=%-6d alive=%d' % (
        vid, v['vehicleType'], v['name'], v['clanAbbrev'], v['maxHealth'],
        v['prestigeLevel'], v['stFrags'], v['isAlive']))
print('-- team2 --')
for vid, v in sorted(vehs.items(), key=lambda kv: kv[1]['team']):
    if v['team'] != 2:
        continue
    print('  %-10s %-28s %-20s clan=%-10s hp=%-5d prestige=%-4d stFrags=%-6d alive=%d' % (
        vid, v['vehicleType'], v['name'], v['clanAbbrev'], v['maxHealth'],
        v['prestigeLevel'], v['stFrags'], v['isAlive']))

print()
veh_types = Counter(v['vehicleType'] for v in vehs.values())
print('车型分布:')
for t, c in veh_types.most_common():
    print('  %-32s %d' % (t, c))

print()
print('========== 玩家本人 (按 playerName 匹配) ==========')
pid = str(j0['playerID'])
me = None
for vid, v in vehs.items():
    if v['name'] == j0['playerName'] or v.get('avatarSessionID') == pid:
        me = v
        me_vid = vid
        break
print('vehicles 字典键为 avatarSessionID, playerID=%s 未直接命中; 按名字匹配到 %s' % (pid, me_vid))
for k in sorted(me.keys()):
    print('  %-28s = %r' % (k, me[k]))

print()
print('========== serverSettings ==========')
ss = j0['serverSettings']
for k in sorted(ss.keys()):
    v = ss[k]
    s = json.dumps(v, ensure_ascii=False)
    if len(s) > 120:
        s = s[:120] + '...'
    print('  %-32s = %s' % (k, s))

print()
print('========== 块1 战斗结果 ==========')
j1 = json.loads(blocks[1].decode('utf-8'))
print('块1 类型:', type(j1).__name__, '长度:', len(j1))
for i, item in enumerate(j1):
    if isinstance(item, dict):
        print('  item[%d] keys: %s' % (i, list(item.keys())[:30]))
    else:
        print('  item[%d] type: %s' % (i, type(item).__name__))
