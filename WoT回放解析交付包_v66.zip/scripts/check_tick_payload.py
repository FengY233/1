# -*- coding: utf-8 -*-
"""检查 0x36 tick 载荷结构 + 用绝对序号重建真实游戏时间"""
import sys, struct, zlib
sys.path.insert(0, '/home/z/my-project/scripts')
from collections import Counter

# 直接复用库加载包流
from wot_replay_lib import ReplayFile
rf = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
pkts = rf.pkts  # (type, clock, payload, pktIndex)
print(f'总包数: {len(pkts)}')

t36 = [p for p in pkts if p[0] == 0x36]
print(f'0x36 包数: {len(t36)}')
print('前5个载荷 hex:')
for p in t36[:5]:
    print(f'  clock={p[1]/1e6:.3f}s len={len(p[2])} payload={p[2].hex()}')
print('后3个载荷 hex:')
for p in t36[-3:]:
    print(f'  clock={p[1]/1e6:.3f}s len={len(p[2])} payload={p[2].hex()}')

# 载荷长度分布
print('载荷长度分布:', Counter(len(p[2]) for p in t36))

# 尝试解析: 若载荷含 u32 序号
if all(len(p[2]) >= 4 for p in t36):
    vals = [struct.unpack_from('<I', p[2], 0)[0] for p in t36]
    diffs = [b-a for a, b in zip(vals, vals[1:])]
    print(f'\nu32@0 首值={vals[0]} 末值={vals[-1]} 差分分布: {Counter(diffs).most_common(10)}')
    # 也试别的偏移
    for off in (4, 8):
        try:
            v2 = [struct.unpack_from('<I', p[2], off)[0] for p in t36 if len(p[2]) >= off+4]
            d2 = [b-a for a, b in zip(v2, v2[1:])]
            c2 = Counter(d2)
            if len(c2) <= 6:
                print(f'u32@{off} 差分分布: {c2.most_common(8)}')
        except Exception:
            pass
