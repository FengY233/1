# -*- coding: utf-8 -*-
"""prop13_probe.py — 0x05 初始属性流逐字节解析(玩家车 pkt#56) + 0x07 属性13载荷统计"""
import sys, struct, collections
sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

r = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
PLAYER = 0x2094A145

# 1) 玩家车 0x05 (pkt#56) 初始属性流
for (t, clk, pl, i) in r.pkts:
    if i == 56:
        print('=== pkt#56 玩家车 0x05, 载荷', len(pl), 'B ===')
        # 布局: [eid][type][u16 flags][u32 space][u32 0][3f pos][3f dir][u32 streamLen][stream]
        hdr = 8 + 2 + 4 + 4 + 12 + 12 + 4
        eid, typ = struct.unpack_from('<II', pl, 0)
        flags, = struct.unpack_from('<H', pl, 8)
        pos = struct.unpack_from('<3f', pl, 18)
        yaw, pitch, roll = struct.unpack_from('<3f', pl, 30)
        slen, = struct.unpack_from('<I', pl, 42)
        print('eid=0x%X type=%d flags=%d pos=%s yaw=%.4f streamLen=%d (头=%d, 剩=%d)' %
              (eid, typ, flags, ['%.2f' % v for v in pos], yaw, slen, hdr, len(pl) - hdr))
        stream = pl[hdr:]
        print('流长实际:', len(stream), ' 期望:', slen)
        print('hex:', stream.hex())
        # UTF-8 字符串定位
        import re
        for m in re.finditer(rb'[\xe4-\xe9][\x80-\xbf][\x80-\xbf]', stream):
            s, e = m.start(), m.end()
            try:
                txt = stream[max(0, s - 8):e + 16].decode('utf-8', 'replace')
            except Exception:
                txt = '?'
        break

# 2) 全部 0x07 属性统计: (属性号 -> 载荷长分布 + 样本)
print()
print('=== 0x07 属性号统计(全部实体) ===')
prop_len = collections.defaultdict(collections.Counter)
prop_samples = collections.defaultdict(list)
for (t, clk, pl, i) in r.pkts:
    if t == 0x07 and len(pl) >= 10:
        eid, nprops = struct.unpack_from('<IH', pl, 0)
        q = 6
        for k in range(nprops):
            if q >= len(pl): break
            delta = pl[q]; q += 1
            # 需要知道类型才能前进; 这里只处理单属性包(最常见)
            break
        if nprops == 1 and q < len(pl):
            # delta 编码: 属性号 = delta? (切片流通常记录绝对号或差分)
            payload = pl[q:]
            d = pl[q - 1]
            prop_len[d][len(payload)] += 1
            if len(prop_samples[d]) < 6:
                prop_samples[d].append((clk, eid, payload.hex()[:24]))

for p in sorted(prop_len):
    lens = prop_len[p]
    tot = sum(lens.values())
    top = ', '.join('%dB×%d' % (L, n) for L, n in lens.most_common(4))
    print('属性%-3d %6d次  载荷: %s' % (p, tot, top))
print()
print('=== 属性13样本(clock, eid, hex) ===')
for clk, eid, h in prop_samples[13][:6]:
    print('  clk=%10.2f eid=0x%-8X %s' % (clk, eid, h))
print('=== 属性15样本 ===')
for clk, eid, h in prop_samples[15][:4]:
    print('  clk=%10.2f eid=0x%-8X %s' % (clk, eid, h))
print('=== 属性1样本 ===')
for clk, eid, h in prop_samples[1][:4]:
    print('  clk=%10.2f eid=0x%-8X %s' % (clk, eid, h))
print('=== 属性19样本 ===')
for clk, eid, h in prop_samples[19][:4]:
    print('  clk=%10.2f eid=0x%-8X %s' % (clk, eid, h))
