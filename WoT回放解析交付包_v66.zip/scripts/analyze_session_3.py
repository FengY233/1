# -*- coding: utf-8 -*-
"""分析 session jsonl（第3步：回放回调 vs 会话日志 双向对齐验证）"""
import json, re
from collections import Counter, defaultdict
from datetime import datetime, timedelta

CST = timedelta(hours=8)
def cst(ts): return datetime.utcfromtimestamp(ts) + CST

events = [json.loads(l) for l in open('/home/z/my-project/upload/session_20260911_175934.jsonl', encoding='utf-8')]
rep = json.load(open('/home/z/my-project/download/WoT回放解码数据_20260911_caucasus.json', encoding='utf-8'))

# ============ A. 回放 84 条回调事件全列表 ============
print('='*78)
print('A. 回放 0x31 客户端回调事件（全部 84 条）')
print('='*78)
for e in rep['events']:
    cb = e['callback']
    dt = json.dumps(e['data'], ensure_ascii=False)[:110] if not isinstance(e['data'], str) else e['data'][:60]
    print(f"  pkt={e['pkt']:>6}  clock={e['clock']/1e6:>9.2f}s  game_t={e['game_t']:>9.1f}  {cb:38s} {dt}")

# ============ B. 会话侧杀戮/射击/伤害事件（战斗相对时间） ============
BATTLE_START_BT = 139.769
print()
print('='*78)
print('B. 会话日志战斗事件（battle_t = bt - 139.769）')
print('='*78)
sess_kills = [ev for ev in events if ev['ev'] == 'arena.onVehicleKilled']
print(f"onVehicleKilled: {len(sess_kills)}")
for ev in sess_kills:
    a = ev['data']['args']
    print(f"  bt={ev['data']['bt']:>7.2f} battle_t={ev['data']['bt']-BATTLE_START_BT:>7.2f}  victim={a[0]} killer={a[1]} {a[2:]}")

# ============ C. 相位事件对照 ============
print()
print('='*78)
print('C. 相位对照')
print('='*78)
print('回放 phase_events:')
for p in rep['phase_events']:
    print(f"  {json.dumps(p, ensure_ascii=False)[:150]}")
print('会话 period:')
for ev in events:
    if ev['ev'] == 'arena.onPeriodChange':
        print(f"  bt={ev['data']['bt']:>8}  period={ev['data']['args']}")

# ============ D. 玩家轨迹对照（会话 battle_tick own vs 回放 vehicle_tracks[546611525]） ============
print()
print('='*78)
print('D. 玩家轨迹对照')
print('='*78)
ticks = [ev for ev in events if ev['ev'] == 'battle_tick']
own_pts = [(t['data']['bt']-BATTLE_START_BT, *t['data']['own']['position'], t['data']['own']['yaw']) for t in ticks]
print(f'会话 own 轨迹点: {len(own_pts)}, battle_t 范围 {own_pts[0][0]:.1f} ~ {own_pts[-1][0]:.1f}')
trk = rep['vehicle_tracks'].get('546611525', [])
print(f'回放 546611525 轨迹点: {len(trk)}, game_t 范围 {trk[0][0]:.1f} ~ {trk[-1][0]:.1f}')
# 位置范围对比
import math
sx = [p[1] for p in own_pts]; sz = [p[3] for p in own_pts]
rx = [p[1] for p in trk]; rz = [p[3] for p in trk]
print(f'会话 X范围 [{min(sx):.0f},{max(sx):.0f}] Z范围 [{min(sz):.0f},{max(sz):.0f}]')
print(f'回放 X范围 [{min(rx):.0f},{max(rx):.0f}] Z范围 [{min(rz):.0f},{max(rz):.0f}]')

# 取会话每30s一个点 vs 回放最近点比对
print('\n按会话时刻在回放轨迹中找最近 game_t 点（间隔<=1.5s 才比对）:')
def nearest(trk, gt):
    best = min(trk, key=lambda p: abs(p[0]-gt))
    return best if abs(best[0]-gt) <= 1.5 else None
n_cmp = 0; errs = []
for tgt_bt in range(20, 600, 45):
    cand = [p for p in own_pts if abs(p[0]-tgt_bt) < 2.5]
    if not cand: continue
    s = cand[len(cand)//2]
    r = nearest(trk, s[0])
    if r:
        d = math.dist(s[1:4], r[1:4])
        errs.append(d); n_cmp += 1
        print(f'  t={s[0]:6.1f}s  会话pos=({s[1]:7.1f},{s[2]:5.1f},{s[3]:7.1f})  回放pos=({r[1]:7.1f},{r[2]:5.1f},{r[3]:7.1f})  距离={d:6.2f}m')
if errs:
    print(f'\n平均偏差 {sum(errs)/len(errs):.2f}m, 最大 {max(errs):.2f}m, 比对点数 {n_cmp}')

# ============ E. 玩家 68 条车辆事件 vs 会话自身状态 ============
print()
print('='*78)
print('E. 玩家车辆事件（回放 0xB/自有事件）时间分布')
print('='*78)
pv = rep['player_vehicle_events']
print(f'共 {len(pv)} 条, game_t 范围 {min(e["game_t"] for e in pv):.1f} ~ {max(e["game_t"] for e in pv):.1f}')
print('前5条:', *[f'  {e["game_t"]:.1f}s flag={e["flag"]} len={e["len"]}' for e in pv[:5]], sep='\n')
