#!/usr/bin/env python3
"""t53_semantic.py — Task 53-b: 100% 语义标注器 (v8 语法树 → 语义 JSON)
v8 (字节级验证器 100%) → 语义标注器:
  1. 事件日志 + try/finally 逐候选回滚协议: 生成器每个 yield 候选用 (log,jnl) 双 mark,
     被拒后恢复时回退本候选事件/注册; 整体耗尽时回退作用域事件; done 标志冻结成功链.
  2. reg() 注册日志 journal: class0/class1 注册可回退 — 节点表语义保真 (v8 污染模式作回退).
  3. per-tid 语义读取器: 123 花名册 / 51 OwnVehicle(3 属性实证锚) / 112 订阅 / 127 附着 /
     54 队伍槽位 / 104 FLOAT 数组 — 专用读取器前置(不影响接受集, 只增语义).
  4. 名称 join: 创建体自带实例名 + tid 名表基名(data_v30 corpus 插桩) + OV 实证属性锚.
产出: /tmp/wot/t53_events_v1.jsonl (全量事件流)
      download/data_v34/ 语义统计 + 样例 (由 t53_collect 汇总)
验收: pass1(含污染回退) ≥ v8 的 6776; +free = 6822; 花名册总记录 = 300.
"""
import sys, struct, json, time, os
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from t50_v5a import RND, read_len, clist
from t50_free import make_free_parser
from t51_v6 import parse_roster_array

DL = '/home/z/my-project/download'
TMP = '/tmp/wot'

OV_ANCHOR = {0: 'syncVehicleAttrs', 1: 'vehicleAmmoList', 18: 'targetingInfo'}
OV_POOL = ['battleEventsSummary', 'burnoutUnavailable', 'burnoutWarning',
 'destroyedDevicesIsRepairing', 'drownLevel', 'dualGunState', 'dualGunStatus',
 'fixAngles', 'isOtherVehicleDamagedDevicesVisible', 'overturnLevel', 'remoteCamera',
 'siegeStateStatus', 'smokeInfo', 'syncVehicleAttrs', 'targetVehicleID', 'targetingInfo',
 'vehicleAmmoList', 'vehicleClipReloadTime', 'vehicleDamageInfoList', 'vehicleGunReloadTime',
 'vehicleHealthInfo', 'vehicleOptionalDeviceStatusList', 'vehicleSettings', 'welcomeToSector']


def dec(bs):
    try:
        return bs.decode('utf-8')
    except Exception:
        return bs.decode('latin-1')


def load_tid_names():
    d = json.load(open(f'{DL}/data_v30/tid名表_corpus插桩5227_t49_tid_names.json'))
    out = {}
    for tid, names in d.items():
        best, bc = None, -1
        for nm, c in names.items():
            if c > bc:
                bc, best = c, nm
        if best:
            parts = best.rsplit('_', 1)
            base = parts[0] if len(parts) == 2 and parts[1].isdigit() else best
            out[int(tid)] = base
    return out


def roster_json(recs):
    out = []
    for r in recs:
        o = {}
        for k, v in r.items():
            if isinstance(v, bytes):
                o[k] = dec(v) if k in ('fakeName', 'name', 'clanAbbrev', 'avatarSessionID') else v.hex()
            else:
                o[k] = v
        out.append(o)
    return out


def make_sem(global_nodes, known_tids=frozenset(), maxvisit=500000, undo=True):
    """undo=True: 注册/事件严格回滚(语义保真); False: v8 等价污染搜索(接受集保底)."""

    def parse_stream(stream):
        b = stream; n = len(b)
        if n < 2:
            return None
        visit = [0]
        nodes = dict(global_nodes)
        log = []
        jnl = []            # (nid, old_rk_or_None)
        roster_store = []
        done = [False]

        def emit(e):
            log.append(e)

        def reg(nid, rk):
            if nodes.get(nid) != rk:
                jnl.append((nid, nodes.get(nid)))
                nodes[nid] = rk

        def m_():
            return (len(log), len(jnl))

        def undo_to(m):
            lm, jm = m
            if len(log) > lm:
                del log[lm:]
            if undo:
                while len(jnl) > jm:
                    nid, old = jnl.pop()
                    if old is None:
                        nodes.pop(nid, None)
                    else:
                        nodes[nid] = old

        # ---------- per-tid 语义读取器: (end, payload) 或 None ----------
        def rd_ov0(p):
            if p + 10 > n: return None
            a = struct.unpack_from('<H', b, p)[0]
            f1, f2 = struct.unpack_from('<ff', b, p + 2)
            return p + 10, {'kind': 'syncVehicleAttrs', 'u16': a, 'f1': round(f1, 6), 'f2': round(f2, 6)}

        def rd_ov1(p):
            if p >= n: return None
            cnt = b[p]; q = p + 1
            if cnt == 0xff:
                if q + 3 > n: return None
                cnt = b[q] | (b[q + 1] << 8) | (b[q + 2] << 16); q += 3
            if cnt > 40: return None
            lst = []
            for _ in range(cnt):
                if q >= n: return None
                has = b[q]; q += 1
                if has:
                    if q + 17 > n: return None
                    lst.append({'compactDescr': struct.unpack_from('<i', b, q)[0],
                                'qty': struct.unpack_from('<H', b, q + 4)[0],
                                'qtyInClip': struct.unpack_from('<H', b, q + 6)[0],
                                'prevStage': struct.unpack_from('<H', b, q + 8)[0],
                                'endTime': round(struct.unpack_from('<f', b, q + 10)[0], 4),
                                'totalTime': struct.unpack_from('<h', b, q + 14)[0],
                                'index': b[q + 16]})
                    q += 17
            return q, {'kind': 'vehicleAmmoList', 'ammo': lst}

        def rd_ov18(p):
            if p >= n: return None
            if b[p] == 0:
                return p + 1, {'kind': 'targetingInfo', 'has': 0}
            if p + 41 > n: return None
            fl = [round(struct.unpack_from('<f', b, p + 1 + 4 * i)[0], 6) for i in range(10)]
            return p + 41, {'kind': 'targetingInfo', 'has': 1, 'f': fl}

        def ownveh_prop(p, idx):
            if idx == 0: return rd_ov0(p)
            if idx == 1: return rd_ov1(p)
            if idx == 18: return rd_ov18(p)
            return None

        def rd_sub(p):
            q = p
            if q + 6 > n: return None
            if b[q] != 0x03: return None
            q += 1
            eid = struct.unpack_from('<I', b, q)[0]; q += 4
            nsub = b[q]; q += 1
            if nsub > 8: return None
            subs = []
            for _ in range(nsub):
                if q >= n: return None
                ln = b[q]; q += 1
                if ln == 0xff:
                    if q + 3 > n: return None
                    ln = b[q] | (b[q + 1] << 8) | (b[q + 2] << 16); q += 3
                if ln > 120 or q + ln + 4 > n: return None
                subs.append({'path': dec(b[q:q + ln]), 'value': struct.unpack_from('<I', b, q + ln)[0]})
                q += ln + 4
            binds = []
            cnt = 0
            while q + 5 <= n and b[q] != 0x02:
                binds.append((struct.unpack_from('<I', b, q)[0], b[q + 4]))
                q += 5; cnt += 1
                if cnt > 8: return None
            return q, {'kind': 'subscriptions', 'eid': eid, 'nsub': nsub, 'subs': subs, 'bindings': binds}

        def rd_attach(p):
            if p >= n or b[p] not in (2, 4, 6, 8): return None
            tag = b[p]; q = p + 1
            if q >= n: return None
            ln = b[q]; q += 1
            if q + ln + 9 > n: return None
            path = dec(b[q:q + ln]); q += ln
            if b[q] != 1: return None
            q += 1
            u1 = struct.unpack_from('<I', b, q)[0]
            u2 = struct.unpack_from('<I', b, q + 4)[0]
            q += 8
            recs = []
            while q + 11 <= n:
                if b[q] > 1 or b[q + 1] != 0 or b[q + 2] != 2: break
                if any(b[q + i] for i in range(4, 11)): break
                recs.append({'flag': b[q], 'nid': (b[q + 2] << 8) | b[q + 3]})
                q += 11
                if len(recs) > 24: break
            if not recs: return None
            return q, {'kind': 'attachChain', 'tag': tag, 'path': path, 'u1': u1, 'u2': u2, 'records': recs}

        def rd_t54(p):
            if p >= n: return None
            cnt = b[p]; q = p + 1
            if cnt == 0 or q + 8 * cnt > n: return None
            recs = []
            for i in range(cnt):
                nid = b[q] | (b[q + 1] << 8)
                z1 = b[q + 2] | (b[q + 3] << 8)
                ts = b[q + 4] | (b[q + 5] << 8)
                z2 = b[q + 6] | (b[q + 7] << 8)
                if z1 or z2: return None
                recs.append({'nid': nid, 'team': ts >> 8, 'slot': ts & 0xff})
                q += 8
            return q, {'kind': 'teamSlots', 'records': recs}

        def rd_a104(p):
            if p >= n: return None
            cnt = b[p]; q = p + 1
            if q + 4 * cnt > n: return None
            fl = []
            for i in range(cnt):
                f = struct.unpack_from('<f', b, q + 4 * i)[0]
                if f != f or abs(f) > 1e12: return None
                fl.append(round(f, 6))
            return q + 4 * cnt, {'kind': 'floats', 'values': fl}

        def rd_hier(p):
            """层级槽位表 [u8 n][n×([u8 len][name][u32 LE nid])] — 结构检查与泛型 hier 候选一致, 仅增载荷"""
            if p >= n: return None
            m = b[p]
            if m > 12: return None
            q = p + 1
            slots = []
            for _ in range(m):
                if q >= n: return None
                ln = b[q]; q += 1
                if q + ln + 4 > n: return None
                nm = dec(b[q:q + ln]); q += ln
                nid = struct.unpack_from('<I', b, q)[0]; q += 4
                slots.append([nm, nid])
            return q, {'kind': 'hierarchy', 'slots': slots}

        def val_cands(p, tid=None, pidx=None):
            out = []
            rem = n - p
            if rem <= 0: return out
            # ★ per-tid 精确语义读取器前置 (同 v8 顺序, 不减接受集)
            if tid == 51 and pidx is not None:
                r = ownveh_prop(p, pidx)
                if r: out.append((r[0], f'ov{pidx}', r[1]))
            if tid == 112 and pidx == 0:
                r = rd_sub(p)
                if r: out.append((r[0], 'sub', r[1]))
            if tid == 127:
                r = rd_attach(p)
                if r: out.append((r[0], 'attach', r[1]))
            if tid == 54:
                r = rd_t54(p)
                if r: out.append((r[0], 't54', r[1]))
            if tid == 104:
                r = rd_a104(p)
                if r: out.append((r[0], 'a104', r[1]))
            for L, f in ((4, 'u32'), (1, 'u8'), (2, 'u16'), (4, 'f32'), (8, 'f64'), (12, 'v3'), (16, 'v4')):
                if L <= rem: out.append((p + L, f, None))
            l = b[p]
            hdr = 4 if l == 0xff else 1
            if l == 0xff and rem >= 4:
                l = b[p + 1] | (b[p + 2] << 8) | (b[p + 3] << 16)
            if hdr + l <= rem and l <= 200: out.append((p + hdr + l, 'str', None))
            if rem >= 2 and b[p] in (2, 4, 6, 8):
                l2 = b[p + 1]
                if 2 + l2 <= rem and l2 <= 200: out.append((p + 2 + l2, 'tagstr', None))
                q = p + 2 + l2
                stops = []
                for qq in range(q, min(n - 3, q + 64) + 1):
                    if b[qq] == 0x02:
                        t = b[qq + 1] | (b[qq + 2] << 8)
                        if t in known_tids or t <= 160:
                            stops.append(qq)
                            if len(stops) >= 5: break
                if not stops: stops = [q]
                for s_ in stops: out.append((s_, 't127', None))
            if b[p] <= 12:
                m = b[p]; q = p + 1; ok = True
                for _ in range(m):
                    if q >= n: ok = False; break
                    ln, q2 = read_len(b, q)
                    if q2 + ln + 4 > n: ok = False; break
                    q = q2 + ln + 4
                if ok:
                    r = rd_hier(p)
                    out.append((r[0], 'hier', r[1] if r else None))
            cnt0 = b[p]
            if cnt0 <= 40:
                for esz, ef in ((4, 'arrf'), (1, 'arr8'), (2, 'arr16'), (12, 'arrv3'), (8, 'arr64')):
                    e = p + 1 + cnt0 * esz
                    if e <= n: out.append((e, ef, None))
            if 1 <= cnt0 <= 64 and p + 1 + cnt0 * 8 <= n:
                out.append((p + 1 + cnt0 * 8, 'arr4x16', None))
            return out

        # ---------- 生成器 ----------
        def rk2_creates(p, nid, depth):
            if p + 2 > n: return
            tid = b[p] | (b[p + 1] << 8)
            if tid > 400: return
            l, p2 = read_len(b, p + 2)
            if p2 + l > n: return
            p3 = p2 + l
            name = dec(b[p2:p2 + l])
            r = clist(b, p3, nid, n)
            if r is None: return
            vals, flags, p4 = r
            nv = len(vals)
            cnt = [0]
            m_scope = m_()
            try:
                vv = vals if len(vals) <= 64 else (vals[:64] + ['+%d' % (len(vals) - 64)])
                emit(['cr', nid, tid, name, nv, vv, sorted(flags)])
                if tid == 123 and nv >= 1:
                    rr = parse_roster_array(b, p4, n)
                    if rr is not None:
                        recs, q = rr
                        mc = m_()
                        try:
                            emit(['ro', len(recs)])
                            roster_store.append(roster_json(recs))
                            cnt[0] += 1
                            yield q
                        finally:
                            if not done[0]:
                                undo_to(mc)
                                if roster_store: roster_store.pop()

                def gen_props(pp, i, np_, acc):
                    if i == np_:
                        yield tuple(acc); return
                    if i in flags:
                        cands = val_cands(pp, tid, i)
                        for e, fmt, payload in cands:
                            acc.append((i, fmt, pp, e, payload))
                            yield from gen_props(e, i + 1, np_, acc)
                            acc.pop()
                    else:
                        yield from gen_props(pp, i + 1, np_, acc)

                nps = [23] if tid == 51 else ([1] if tid == 112 else range(0, nv))
                for np_ in nps:
                    if np_ > nv - 1: break
                    for chain in gen_props(p4, 0, np_, []):
                        for mmodel in ('pk', 'ln'):
                            q = chain[-1][3] if chain else p4
                            ok = True
                            mids = []
                            for j in range(np_, nv - 1):
                                if q >= n: ok = False; break
                                if mmodel == 'pk':
                                    if b[q] == 0xff:
                                        if q + 4 > n: ok = False; break
                                        mids.append(b[q + 1] | (b[q + 2] << 8) | (b[q + 3] << 16)); q += 4
                                    else:
                                        mids.append(b[q]); q += 1
                                else:
                                    ln, q2 = read_len(b, q)
                                    if q2 + ln > n: ok = False; break
                                    mids.append(dec(b[q2:q2 + ln])); q = q2 + ln
                                if q > n: ok = False; break
                            if not ok or q > n: continue
                            mc = m_()
                            try:
                                for (pi_, fmt, st, en, payload) in chain:
                                    ev = ['pr', pi_, fmt, st, en]
                                    if payload is not None: ev.append(payload)
                                    emit(ev)
                                emit(['me', mmodel, mids])
                                cnt[0] += 1
                                if cnt[0] > 3000: return
                                yield q
                                if q < n and b[q] <= 6:
                                    for e in create_bodies(q + 1, b[q], vals[-1] if vals else nid, depth + 1):
                                        if e is not None and e > q:
                                            yield e
                            finally:
                                if not done[0]:
                                    undo_to(mc)
            finally:
                if not done[0]:
                    undo_to(m_scope)

        def create_bodies(p, rk, nid, depth):
            if depth > 40: return
            if rk in (0, 6): yield p
            elif rk == 1:
                if p + 4 <= n: yield p + 4
            elif rk == 2:
                yield from rk2_creates(p, nid, depth)
            elif rk == 3:
                for L in (1, 2, 4, 8, 12, 16):
                    if p + L <= n: yield p + L
                if p < n:
                    l, q = read_len(b, p)
                    if q + l <= n and l <= 200: yield q + l
            elif rk == 4:
                if p + 1 > n: return
                kind = b[p]
                if kind <= 1:
                    l, q2 = read_len(b, p + 1)
                    if q2 + l <= n: yield q2 + l
                else:
                    for L in (1, 2, 4, 8):
                        if p + L <= n: yield p + L
            elif rk == 5:
                if p >= n: return
                l, q2 = read_len(b, p)
                if q2 + l <= n: yield q2 + l

        def dispatch(p, mcls, mid, depth):
            if depth > 60: return None
            if mcls == 0:
                if p + 3 > n: return None
                parent = (b[p] << 8) | b[p + 1]; rk = b[p + 2]
                if rk > 6: return None
                m0 = m_()
                reg(mid, rk)
                emit(['nd', mid, rk, parent])
                for e in create_bodies(p + 3, rk, mid, depth):
                    r = step(e, depth)
                    if r is not None: return r
                undo_to(m0)
                return None
            elif mcls == 1:
                m0 = m_()
                r = clist(b, p, mid, n)
                if r is None: return None
                vals, flags, q = r
                vv = vals if len(vals) <= 64 else (vals[:64] + ['+%d' % (len(vals) - 64)])
                emit(['cl', mid, vv, sorted(flags)])

                def rec(i, q2):
                    if i == len(vals):
                        return step(q2, depth)
                    if q2 + 1 > n: return None
                    rk = b[q2]
                    if rk > 6: return None
                    m1 = m_()
                    reg(vals[i], rk)
                    emit(['nd', vals[i], rk])
                    for e in create_bodies(q2 + 1, rk, vals[i], depth + 1):
                        r2 = rec(i + 1, e)
                        if r2 is not None: return r2
                    undo_to(m1)
                    return None

                r = rec(0, q)
                if r is not None: return r
                undo_to(m0)
                return None
            elif mcls in (2, 3, 5):
                return step(p, depth)
            elif mcls in (4, 6):
                rk = nodes.get(mid)
                if rk is None: return None
                if rk in (1, 2, 6):
                    r = step(p, depth)
                    if r is not None: emit(['up', mid, rk, 0])
                    return r
                if rk == 3:
                    for L in (0, 1, 2, 4, 8, 12, 16):
                        if p + L <= n:
                            r = step(p + L, depth)
                            if r is not None:
                                emit(['up', mid, rk, L]); return r
                    if p < n:
                        l, q = read_len(b, p)
                        if q + l <= n and l <= 200:
                            r = step(q + l, depth)
                            if r is not None:
                                emit(['up', mid, rk, 's%d' % l]); return r
                    return None
                if rk == 4:
                    if p + 1 > n: return None
                    kind = b[p]
                    if kind <= 1:
                        l, q2 = read_len(b, p + 1)
                        if q2 + l > n: return None
                        r = step(q2 + l, depth)
                        if r is not None: emit(['up', mid, rk, 's%d' % l])
                        return r
                    for L in (1, 2, 4, 8):
                        if p + L <= n:
                            r = step(p + L, depth)
                            if r is not None:
                                emit(['up', mid, rk, L]); return r
                    return None
                if rk == 0:
                    r = clist(b, p, mid, n)
                    if r is None: return None
                    vals, flags, q = r
                    nw = (len(vals) + 31) >> 5
                    if q + nw * 4 <= n:
                        r2 = step(q + nw * 4, depth)
                        if r2 is not None:
                            emit(['up', mid, rk, nw * 4, len(vals)]); return r2
                    return step(q, depth)
                return None
            return None

        def step(p, depth):
            if p >= n:
                done[0] = True; return ('done', p)
            if n - p <= 2:
                done[0] = True; return ('tail', p)
            if p + 3 > n: return None
            mcls = b[p]; mid = (b[p + 1] << 8) | b[p + 2]; q = p + 3
            if mcls > 6: return None
            visit[0] += 1
            if visit[0] > maxvisit: return None
            emit(['fr', p, mcls, mid])
            r = dispatch(q, mcls, mid, depth + 1)
            if r is not None: return r
            log.pop()
            return None

        mid0 = (b[0] << 8) | b[1]
        emit(['fr', 0, 0, mid0])
        r = dispatch(2, 0, mid0, 0)
        if r is not None:
            created = {nid_: nodes[nid_] for (nid_, _old) in jnl}
            global_nodes.update(created)
            tailb = b[r[1]:].hex()
            return {'result': r, 'log': log, 'rosters': roster_store,
                    'created': created, 'tail': tailb}
        return None

    return parse_stream


if __name__ == '__main__':
    tname = load_tid_names()
    print('tid 名表:', len(tname), '个基名')
    pkgs_all = []; owner = []
    for gi, f in enumerate(RND):
        blocks, declared, slen, pkts = load(f)
        for t, c, pl in pkts:
            if t == 0x32:
                pkgs_all.append(pl[4:]); owner.append(gi)
    N = len(pkgs_all)
    print('语料:', N, '包')
    known = set()
    for s in pkgs_all[:800]:
        for i in range(len(s) - 3):
            if s[i] == 0x02 and s[i + 1] < 0xA0:
                known.add(s[i + 1] | (s[i + 2] << 8))
    known = {t for t in known if t <= 300}

    t0 = time.time()
    ok_sem = 0; ok_pol = 0; ok_free = 0
    fails = []
    out_recs = []
    gnodes = {}; cur_g = -1
    roster_total = 0
    for idx in range(N):
        if owner[idx] != cur_g:
            gnodes = {}; cur_g = owner[idx]
        p = make_sem(gnodes, known)
        r = p(pkgs_all[idx])
        via = 'sem'
        if r is None:
            p2 = make_sem(gnodes, known, undo=False)   # v8 等价污染回退
            r = p2(pkgs_all[idx])
            if r is not None:
                via = 'polluted'
        if r is not None:
            if via == 'sem': ok_sem += 1
            else: ok_pol += 1
            rec = {'gi': cur_g, 'idx': idx, 'len': len(pkgs_all[idx]), 'via': via,
                   'end': r['result'][1], 'tail': r['tail'], 'events': r['log']}
            if r['rosters']:
                rec['roster'] = r['rosters'][0]
                roster_total += len(r['rosters'][0])
            out_recs.append(rec)
        else:
            free = make_free_parser(known)
            rf, _st = free(pkgs_all[idx])
            if rf is not None:
                ok_free += 1
                out_recs.append({'gi': cur_g, 'idx': idx, 'len': len(pkgs_all[idx]),
                                 'via': 'free', 'end': rf[1] if isinstance(rf, tuple) else None,
                                 'events': []})
            else:
                fails.append(idx)
    total = ok_sem + ok_pol + ok_free
    dt = time.time() - t0
    print(f'语义标注: sem={ok_sem} polluted={ok_pol} free={ok_free} → {total}/{N} ({100*total/N:.2f}%) 耗时{dt:.0f}s')
    print(f'剩余失败 {len(fails)}: {fails}')
    print(f'花名册记录总数: {roster_total} (期望 300)')
    print(f'v8 对照: pass1=6776 / 本标注器 sem+polluted={ok_sem + ok_pol}')

    with open(f'{TMP}/t53_events_v1.jsonl', 'w') as f:
        for rec in out_recs:
            f.write(json.dumps(rec, ensure_ascii=False, separators=(',', ':')) + '\n')
    sz = os.path.getsize(f'{TMP}/t53_events_v1.jsonl')
    print(f'事件流: {TMP}/t53_events_v1.jsonl {sz:,}B ({len(out_recs)} 行)')
    json.dump({'ok_sem': ok_sem, 'ok_polluted': ok_pol, 'ok_free': ok_free, 'total': total,
               'n': N, 'fails': fails, 'roster_total': roster_total, 'elapsed_s': round(dt, 1),
               'jsonl_bytes': sz},
              open(f'{TMP}/t53_sem_result.json', 'w'))
