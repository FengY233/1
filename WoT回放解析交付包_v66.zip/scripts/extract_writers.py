# -*- coding: utf-8 -*-
"""extract_writers.py — 从反编译文本提取回放块写入函数的完整调用序列
模式: FUN_1405846e0(stream, TYPE, clock, totalLen) 后跟若干 FUN_140584790(stream, src, size)
"""
import io
import re
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

path = '/home/z/my-project/work/decomp/decomp/chunks/c_140495d70.c'
text = open(path, encoding='utf-8', errors='replace').read()
lines = text.split('\n')

# 找出每个 FUN_1405846e0 调用的行号，以及其后 12 行内的 FUN_140584790 调用
starts = []
for i, ln in enumerate(lines):
    m = re.search(r'FUN_1405846e0\([^,]+,\s*(0x[0-9a-fA-F]+|\d+)\s*,', ln)
    if m:
        ty = m.group(1)
        starts.append((i, ty))

print('== 每个块类型写入序列 (type: [size1][size2]...) ==')
seen = {}
for i, ty in starts:
    if ty in seen:
        continue
    seq = []
    for j in range(i, min(i + 14, len(lines))):
        for m in re.finditer(r'FUN_140584790\([^,]+,([^,]+),([^)]+)\)', lines[j]):
            src, size = m.group(1).strip(), m.group(2).strip()
            seq.append((src, size))
    seen[ty] = (i + 1, seq)

def tykey(t):
    try:
        return int(t, 0)
    except Exception:
        return 999

for ty in sorted(seen.keys(), key=tykey):
    line, seq = seen[ty]
    parts = []
    for src, size in seq:
        parts.append('%s[%s]' % (src, size))
    print('type %-5s @line %-7d : %s' % (ty, line, ' '.join(parts)))
