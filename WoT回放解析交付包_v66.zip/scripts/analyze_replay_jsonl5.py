# -*- coding: utf-8 -*-
"""analyze_replay_jsonl5.py — 0x11 zlib 深挖 + 0x06 状态blob + 0x1A 相机几何 + 0x26 decomp对照。
"""
import json
import struct
import sys
import zlib
import re
import collections

sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

REPLAY = '/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay'
JSONL = '/home/z/my-project/upload/replay.jsonl'

rf = ReplayFile(REPLAY)
lines = []
with open(JSONL) as f:
    for line in f:
        if line.strip():
            lines.append(json.loads(line))

def f32(u):
    return struct.unpack('<f', struct.pack('<I', u))[0]

oneoff = {}
for ty, clock, payload, idx in rf.pkts:
    if ty not in oneoff:
        oneoff[ty] = payload

# ---------- 1) 0x11 zlib 解压 ----------
p11 = oneoff[0x11]
print('== 0x11 深挖 ==')
print('head 64B:', p11[:64].hex())
# 找 78 9c
zoff = p11.find(b'\x78\x9c')
print(f'zlib 头 @ {zoff}')
# 前面的 u32
u = struct.unpack_from('<I', p11, zoff - 4)[0]
print(f'zlib 前 u32 = {u} (0x{u:X})')
try:
    dec = zlib.decompress(p11[zoff:])
    print(f'解压成功: {len(dec)}B')
    open('/home/z/my-project/work/p11_zlib.bin', 'wb').write(dec)
    strs = re.findall(rb'[\x20-\x7e]{6,}', dec)
    print(f'ASCII 串 {len(strs)} 个, 前 40:')
    for s in strs[:40]:
        print('   ', s[:100])
    print('head 200B:', dec[:200].hex())
except Exception as e:
    print('解压失败:', e)
    # 尝试 partial
    d = zlib.decompressobj()
    try:
        dec = d.decompress(p11[zoff:])
        print(f'部分解压: {len(dec)}B')
        open('/home/z/my-project/work/p11_zlib.bin', 'wb').write(dec)
        strs = re.findall(rb'[\x20-\x7e]{6,}', dec)
        print(f'ASCII 串 {len(strs)} 个, 前 40:')
        for s in strs[:40]:
            print('   ', s[:100])
    except Exception as e2:
        print('部分解压也失败:', e2)

# pickle int 部分
print()
p = p11[:zoff]
print('zlib 前的头部:', p.hex())
# (I2336018974483140952 = BW pickle

# ---------- 2) 0x06 状态 blob ----------
print()
print('== 0x06 handleEntityPlayerStateChange ==')
p6 = oneoff[0x06]
eid, blen = struct.unpack_from('<II', p6, 0)
print(f'eid={eid} (own vehicle 546611525), blob len={blen}')
blob = p6[8:8+blen]
print('blob[:64]:', blob[:64].hex())
# u16 序列?
us = struct.unpack(f'<{len(blob)//2}H', blob[:len(blob)//2*2])
print('u16 序列前 40:', us[:40])
print('u16 uniq:', len(set(us)))

# ---------- 3) 0x1A 相机几何 ----------
print()
print('== 0x1A 相机几何: col0:3 vs col5:7 (相机vs瞄准点) ==')
rows = []
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    if ty == 0x1A and 'f' in d and len(d['f']) == 15:
        rows.append((f32(clock), d['f']))
dx, dy, dz = [], [], []
for t, f in rows:
    if f[0] != 0 or f[5] != 0:
        dx.append(f[0] - f[5])
        dy.append(f[1] - f[6])
        dz.append(f[2] - f[7])
import statistics
print(f'cam-aim: dx 中位 {statistics.median(dx):.2f} dy {statistics.median(dy):.2f} dz {statistics.median(dz):.2f}')
print(f'  dx 范围 [{min(dx):.1f},{max(dx):.1f}] dy [{min(dy):.1f},{max(dy):.1f}] dz [{min(dz):.1f},{max(dz):.1f}]')
# col8:10 是否 = normalize(aim-cam)
ok = 0
tot = 0
for t, f in rows:
    if f[0] != 0:
        vx, vy, vz = f[5]-f[0], f[6]-f[1], f[7]-f[2]
        n = (vx*vx+vy*vy+vz*vz) ** 0.5
        if n > 1e-6:
            tot += 1
            if abs(vx/n - f[8]) < 0.01 and abs(vy/n - f[9]) < 0.01 and abs(vz/n - f[10]) < 0.01:
                ok += 1
print(f'col8:10 == normalize(aim-cam): {ok}/{tot} ({100.0*ok/max(tot,1):.1f}%)')
# col3 == col4?
same = sum(1 for t, f in rows if f[3] == f[4])
print(f'col3==col4: {same}/{len(rows)}')
# col3 与 cam-aim 距离?
dists = [((f[0]-f[5])**2 + (f[1]-f[6])**2 + (f[2]-f[7])**2)**0.5 for t, f in rows if f[0] != 0]
print(f'|cam-aim| 中位 {statistics.median(dists):.1f} 范围 [{min(dists):.1f},{max(dists):.1f}]')
c3 = [f[3] for t, f in rows if f[0] != 0]
print(f'col3 中位 {statistics.median(c3):.2f} vs |cam-aim| 中位 {statistics.median(dists):.2f}')
corr = sum(1 for t, f in rows if f[0] != 0 and abs(f[3] - ((f[0]-f[5])**2+(f[1]-f[6])**2+(f[2]-f[7])**2)**0.5) < 0.5)
print(f'col3==|cam-aim|: {corr}/{len(dists)}')

# ---------- 4) 0x26 时钟分布 vs 0x1B 相机模式切换 ----------
print()
print('== 0x26 与 0x1B 相机模式切换时间对照 ==')
mode_changes = []
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    if ty == 0x1B and 'str' in d:
        mode_changes.append((f32(clock), d['str']))
print('0x1B 相机模式切换:', [(round(t, 1), s) for t, s in mode_changes[:20]], '...' if len(mode_changes) > 20 else '')
t26 = sorted(f32(clock) for ty, clock, p, i in rf.pkts if ty == 0x26)
# 簇起点
clusters = []
start = prev = t26[0]
for t in t26[1:]:
    if t - prev > 1.0:
        clusters.append((start, prev))
        start = t
    prev = t
clusters.append((start, prev))
print('0x26 簇 (起点,终点) 前 20:', [(round(a, 1), round(b, 1)) for a, b in clusters[:20]])

# 玩家开炮时刻 (0x31 onActionReceived 伤害事件 or 0x08?)
# 用 jsonl: battle 里 shots=15; 从 0x26 簇是否对应炮弹飞行?
# 检查簇数 36 vs 相机切换 48
print(f'0x26 簇数={len(clusters)}, 0x1B 切换数={len(mode_changes)}')
