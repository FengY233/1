# -*- coding: utf-8 -*-
"""时间轴重建：用会话日志真实轨迹对齐回放 0xA 位置流，定位 seek 跳变点"""
import sys, json, struct, math
sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile
from collections import defaultdict, Counter

BATTLE_START_BT = 139.769   # 会话战斗开始
BATTLE_END_BT = 752.259

# ---------- 1. 会话真实轨迹（battle_tick vehicles + own） ----------
sess_tracks = defaultdict(list)  # vid -> [(battle_t, x, y, z)]
for line in open('/home/z/my-project/upload/session_20260911_175934.jsonl', encoding='utf-8'):
    o = json.loads(line)
    if o['ev'] != 'battle_tick':
        continue
    d = o['data']
    bt = d['bt'] - BATTLE_START_BT
    own = d.get('own')
    if own:
        sess_tracks[546611525].append((bt, *own['position']))
    for vid, v in (d.get('vehicles') or {}).items():
        sess_tracks[int(vid)].append((bt, *v['pos']))

cov = {vid: len(pts) for vid, pts in sess_tracks.items()}
print('会话轨迹覆盖（每0.2s一个点）:', sorted(cov.items(), key=lambda x: -x[1])[:12])

# ---------- 2. 回放 0xA 位置流 ----------
rf = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
pkts = rf.pkts
# 战斗窗口: period3 包(pkt idx) 到 period4
p3_pkt = next(p[3] for p in pkts if p[0] == 0x16 and p[2] == b'\x03\x00\x00\x00')
p4_pkt = next(p[3] for p in pkts if p[0] == 0x16 and p[2] == b'\x04\x00\x00\x00')
print(f'\n战斗窗口包: {p3_pkt} ~ {p4_pkt}')

# 0xA 载荷: [u32 eid][f32 x,y,z][f32 yaw,pitch,roll?]  之前实证 52 字节布局
# 用 try 解析常见布局: u32 eid + 7 f32?
rep_tracks = defaultdict(list)
for ty, clock, payload, idx in pkts:
    if ty != 0xA or not (p3_pkt <= idx <= p4_pkt) or len(payload) < 16:
        continue
    eid = struct.unpack_from('<I', payload, 0)[0]
    if eid not in cov:      # 只关心 30 辆战车
        continue
    x, y, z = struct.unpack_from('<3f', payload, 4)
    rep_tracks[eid].append((idx, clock, x, y, z))

print('回放 0xA 战车轨迹点数(前10):', {k: len(v) for k, v in sorted(rep_tracks.items(), key=lambda x: -len(x[1]))[:10]})

# ---------- 3. 位置匹配对齐 ----------
# 对每辆车的每个回放点, 在会话轨迹中找 3m 内的最近点(限制扫描代价: 会话点已按时间排序)
def build_index(pts):
    return pts

alignments = []  # (stream_pos, clock, true_bt, vid)
for vid, rpts in rep_tracks.items():
    spts = sess_tracks.get(vid)
    if not spts or len(rpts) < 50:
        continue
    # 会话点少的话跳过
    for idx, clock, x, y, z in rpts:
        best = None; bd = 1e9
        for bt, sx, sy, sz in spts:
            d2 = (sx-x)**2 + (sy-y)**2 + (sz-z)**2
            if d2 < bd:
                bd = d2; best = bt
        if bd <= 9.0:  # 3m
            alignments.append((idx, clock, best, vid))

alignments.sort()
print(f'\n成功匹配的锚点: {len(alignments)} 个')

# ---------- 4. 分段分析: stream 位置 vs 真实 battle_t ----------
# 用滑动中位数观察映射形状
import statistics
W = 80
print('\n流位置 -> 真实战斗时间 映射(滑动窗口中位数, 每400个锚点采样):')
step = max(1, len(alignments)//30)
samples = []
for i in range(0, len(alignments)-W, step):
    win = alignments[i:i+W]
    med_idx = statistics.median(a[0] for a in win)
    med_bt = statistics.median(a[2] for a in win)
    q_bt = statistics.quantiles([a[2] for a in win], n=4)
    spread = q_bt[2]-q_bt[0]
    samples.append((med_idx, med_bt, spread))
for mi, mb, sp in samples:
    bar = '#' * int(max(0, mb/12))
    print(f'  pkt#{mi:>7.0f}  true_bt={mb:>7.1f}s  (IQR={sp:>5.1f}) {bar}')

# ---------- 5. 跳变检测: 相邻锚点中 true_bt 的大幅回退/前跳 ----------
print('\n=== 跳变检测（窗口内中位 true_bt 的序列变化）===')
jumps = []
for i in range(0, len(alignments)-2*W, max(1, W//2)):
    w1 = alignments[i:i+W]; w2 = alignments[i+W:i+2*W]
    m1 = statistics.median(a[2] for a in w1); m2 = statistics.median(a[2] for a in w2)
    p1 = statistics.median(a[0] for a in w1); p2 = statistics.median(a[0] for a in w2)
    if m2 - m1 < -3.0:   # 回跳
        jumps.append(('BACK', p1, p2, m1, m2))
    elif m2 - m1 > 25.0:  # 前跳(远超正常播放累积)
        jumps.append(('FWD', p1, p2, m1, m2))
for kind, p1, p2, m1, m2 in jumps:
    print(f'  {kind}: pkt#{p1:.0f}→#{p2:.0f}  true_bt {m1:.1f}s → {m2:.1f}s  (Δ{m2-m1:+.1f}s)')

json.dump({'anchors': [(a[0], a[1], round(a[2], 2), a[3]) for a in alignments]},
          open('/home/z/my-project/scripts/align_anchors.json', 'w'))
print(f'\n锚点已保存 scripts/align_anchors.json')
