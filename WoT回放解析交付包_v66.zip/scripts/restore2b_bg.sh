#!/bin/bash
# restore2b_bg.sh — 后台解压：wot_src / wotexe / BigWorld（py7zr 慢 + tar 大包）
set -x
UP=/home/z/my-project/upload
B11=$UP/backup_v11_restore
REPOS=/tmp/my-project/repos

# 1. decomp.zip (zipfile 快) — 单独前台完成也行，放这统一
rm -rf $REPOS/decomp
python3 -c "
import zipfile
with zipfile.ZipFile('$UP/decomp.zip') as z:
    z.extractall('$REPOS/decomp')
print('decomp.zip DONE')
"

# 2. wot_src (py7zr 慢)
python3 -c "
import py7zr, time
t0=time.time()
with py7zr.SevenZipFile('$REPOS/wot_src_merged.7z') as z:
    z.extractall('$REPOS')
print('wot_src DONE %.1fs' % (time.time()-t0))
"

# 3. wotexe.7z
python3 -c "
import py7zr, time
t0=time.time()
with py7zr.SevenZipFile('$B11/wotexe.7z') as z:
    z.extractall('/tmp/wotexe_x')
print('wotexe DONE %.1fs' % (time.time()-t0))
"

# 4. BigWorld tar.gz (C 实现 tar)
mkdir -p $REPOS/BigWorld
tar -xzf $UP/BigWorld-Engine-14.4.1_src.tar.gz -C $REPOS/BigWorld
echo "BigWorld DONE"

echo "ALL_BG_DONE"
