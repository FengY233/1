# -*- coding: utf-8 -*-
"""merge_pdf.py — 合并封面与正文, 输出最终 PDF"""
from pypdf import PdfReader, PdfWriter

A4_W, A4_H = 595.28, 841.89


def normalize(page):
    w, h = float(page.mediabox.width), float(page.mediabox.height)
    if abs(w - A4_W) > 0.1 or abs(h - A4_H) > 0.1:
        page.scale_to(A4_W, A4_H)
        page.mediabox.lower_left = (0, 0)
        page.mediabox.upper_right = (A4_W, A4_H)
    return page


writer = PdfWriter()
writer.add_page(normalize(PdfReader('/home/z/my-project/work/cover.pdf').pages[0]))
for p in PdfReader('/home/z/my-project/work/report_body.pdf').pages:
    writer.add_page(normalize(p))
writer.add_metadata({
    '/Title': 'WoT 2.4.0 wotreplay 完全解析报告',
    '/Author': 'Z.ai',
    '/Creator': 'Z.ai',
    '/Subject': 'World of Tanks replay 文件格式逆向与战斗还原',
})
out = '/home/z/my-project/download/WoT回放完全解析报告.pdf'
with open(out, 'wb') as f:
    writer.write(f)
print('✅', out, len(writer.pages), '页')
