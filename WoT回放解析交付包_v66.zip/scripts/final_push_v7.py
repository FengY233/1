# -*- coding: utf-8 -*-
"""final_push_v7.py — 无服务器资料条件下的最终攻坚。

1) entities.xml 权威实体类型对表（1-based 位置 = 类型号）
2) 0x3D 哈希输入候选爆破（目标 5DF886F75E73B33CFF9D87FB9C69389C）
3) 0x11 校验算法爆破（目标 200528740 = 0x0BF39B64）
4) 0x20 全序列提取 + 相机模式/击杀时间关联
"""
import hashlib
import json
import struct
import sys
import zlib
from collections import Counter

sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

REPLAY = '/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay'
SRC = '/home/z/my-project/work/wot_src/sources/res/scripts'
DECODED = '/home/z/my-project/work/decoded_full.json'

print('=' * 72)
print('PART 1 — entities.xml 权威实体类型对表')
print('=' * 72)
import xml.etree.ElementTree as ET
root = ET.parse(f'{SRC}/entities.xml').getroot()
names = [e.tag for e in root.find('ClientServerEntities')]
type_map = {i + 1: n for i, n in enumerate(names)}  # 1-based
print(f'ClientServerEntities 共 {len(names)} 项（1-based 编号）')

# 回放中观测到的类型号（来自 decoded_full.json）
obs = {}
with open(DECODED) as f:
    dec = json.load(f)
for ent in dec['entities']:
    for t in ent['types']:
        obs.setdefault(t, []).append(ent['id'])
print(f'\n回放观测类型号 -> 权威名字（entities.xml 位置 {min(type_map)}..{max(type_map)}）:')
for t in sorted(obs):
    ids = obs[t]
    n_veh = sum(1 for e in dec['entities'] if t in e['types'] and e.get('is_vehicle'))
    print(f'  type {t:>2} = {type_map.get(t, "<超出范围>"):<32} '
          f'实体数={len(set(ids)):>3}  其中车辆={n_veh}')

print()
print('=' * 72)
print('PART 2 — 0x3D 哈希输入候选爆破')
print('=' * 72)
TARGET3D = '5DF886F75E73B33CFF9D87FB9C69389C'
target3d_bytes = bytes.fromhex(TARGET3D)
print(f'目标: {TARGET3D}')

cands = {}
for fn, label in [('entities.xml', 'entities.xml'), ('entity_defs/alias.xml', 'alias.xml')]:
    cands[label] = open(f'{SRC}/{fn}', 'rb').read()
cands['entities+alias'] = cands['entities.xml'] + cands['alias.xml']
cands['alias+entities'] = cands['alias.xml'] + cands['entities.xml']
cands['entities_nonl'] = cands['entities.xml'].rstrip(b'\n')
cands['alias_nonl'] = cands['alias.xml'].rstrip(b'\n')

hit = False
for label, data in cands.items():
    for algo in ('md5', 'sha1', 'sha256', 'sha512'):
        h = hashlib.new(algo, data).digest()
        for take in (16, 32):
            d = h[:take]
            if d == target3d_bytes or h.hex().upper()[:32] == TARGET3D:
                print(f'  ★★★ 命中: {algo}({label})')
                hit = True
        if h.hex().upper() == TARGET3D:
            print(f'  ★★★ 命中(全串): {algo}({label})')
            hit = True
if not hit:
    print('  全部候选未命中（输入为编译后 entityDefs/.def 集合——本地无该文件集，见结论）')

print()
print('=' * 72)
print('PART 3 — 0x11 校验算法爆破')
print('=' * 72)
r = ReplayFile(REPLAY)
p11 = [p for p in r.pkts if p[0] == 0x11]
print(f'0x11 包数: {len(p11)}')
pl = p11[0][2]
print(f'载荷长度: {len(pl)}')
print(f'头部: {pl[:48].hex()}')

# 解析: [u16 100][u32 12][pickle (6677, 200528740)][u32 6677][zlib blob]
u16a = struct.unpack_from('<H', pl, 0)[0]
n1 = struct.unpack_from('<I', pl, 2)[0]
# pickle 从 offset 6 开始, 找 (6677, 200528740)
import pickletools
pkl = pl[6:6 + 20]
print(f'u16={u16a} u32@2={n1} pickle区={pkl.hex()}')
# 定位 6677 的 u32 长度字段(第二次出现)与 zlib blob
# pickle: 80 02 4d 0a 11 1d 8b ... — 直接扫 zlib 头 78 9c / 78 01 / 78 da
zoff = None
for i in range(6, min(60, len(pl))):
    if pl[i] in (0x78,) and pl[i + 1] in (0x01, 0x9c, 0xda, 0x5e):
        try:
            zlib.decompress(pl[i:i + 7000])
            zoff = i
            break
        except Exception:
            pass
print(f'zlib blob 偏移: {zoff}')
blob = pl[zoff:]
stored_len = struct.unpack_from('<I', pl, zoff - 4)[0]
print(f'存储长度字段: {stored_len}, blob 实长: {len(blob)}')
outer_dec = zlib.decompress(blob)
print(f'外层解压: {len(outer_dec)} B')
open('/home/z/my-project/work/p11_outer_blob.bin', 'wb').write(blob)
open('/home/z/my-project/work/p11_outer_dec.bin', 'wb').write(outer_dec)

TARGET11 = 200528740

def crc32c(data):
    poly = 0x82F63B78
    crc = 0xFFFFFFFF
    for b in data:
        crc ^= b
        for _ in range(8):
            crc = (crc >> 1) ^ (poly & -(crc & 1))
    return crc ^ 0xFFFFFFFF

def crc_gen(data, poly, init, refin, refout, xorout):
    def rev32(x):
        return int(f'{x:032b}'[::-1], 2)
    crc = init
    for b in data:
        if refin:
            crc ^= b
            for _ in range(8):
                crc = (crc >> 1) ^ (poly & -(crc & 1)) & 0xFFFFFFFF
        else:
            crc ^= b << 24
            for _ in range(8):
                crc = ((crc << 1) ^ (poly & -(crc >> 31 & 1))) & 0xFFFFFFFF
    crc &= 0xFFFFFFFF
    if refout != refin:
        crc = rev32(crc)
    return (crc ^ xorout) & 0xFFFFFFFF

def fnv1a32(data):
    h = 0x811C9DC5
    for b in data:
        h = ((h ^ b) * 0x01000193) & 0xFFFFFFFF
    return h

def fnv132(data):
    h = 0x811C9DC5
    for b in data:
        h = ((h * 0x01000193) & 0xFFFFFFFF) ^ b
    return h

def djb2(data):
    h = 5381
    for b in data:
        h = (h * 33 + b) & 0xFFFFFFFF
    return h

def sdbm(data):
    h = 0
    for b in data:
        h = (b + (h << 6) + (h << 16) - h) & 0xFFFFFFFF
    return h

def murmur3_32(data, seed=0):
    c1, c2 = 0xCC9E2D51, 0x1B873593
    h = seed
    n = len(data) - (len(data) % 4)
    for i in range(0, n, 4):
        k = struct.unpack_from('<I', data, i)[0]
        k = (k * c1) & 0xFFFFFFFF
        k = ((k << 15) | (k >> 17)) & 0xFFFFFFFF
        k = (k * c2) & 0xFFFFFFFF
        h ^= k
        h = ((h << 13) | (h >> 19)) & 0xFFFFFFFF
        h = (h * 5 + 0xE6546B64) & 0xFFFFFFFF
    k = 0
    tail = data[n:]
    if len(tail) >= 3: k ^= tail[2] << 16
    if len(tail) >= 2: k ^= tail[1] << 8
    if len(tail) >= 1:
        k ^= tail[0]
        k = (k * c1) & 0xFFFFFFFF
        k = ((k << 15) | (k >> 17)) & 0xFFFFFFFF
        k = (k * c2) & 0xFFFFFFFF
        h ^= k
    h ^= len(data)
    h ^= h >> 16
    h = (h * 0x85EBCA6B) & 0xFFFFFFFF
    h ^= h >> 13
    h = (h * 0xC2B2AE35) & 0xFFFFFFFF
    h ^= h >> 16
    return h

def wordsum(data):
    s = 0
    for i in range(0, len(data) - 3, 4):
        s = (s + struct.unpack_from('<I', data, i)[0]) & 0xFFFFFFFF
    return s

def wordxor(data):
    x = 0
    for i in range(0, len(data) - 3, 4):
        x ^= struct.unpack_from('<I', data, i)[0]
    return x

inputs = {
    'blob_stored_6677': blob,
    'outer_dec_6666': outer_dec,
    'full_payload': pl,
    'payload_after_pickle': pl[6:],
}
algos = {
    'crc32': lambda d: zlib.crc32(d) & 0xFFFFFFFF,
    'adler32': lambda d: zlib.adler32(d) & 0xFFFFFFFF,
    'crc32c': crc32c,
    'crc32_mpeg2': lambda d: crc_gen(d, 0x04C11DB7, 0xFFFFFFFF, False, False, 0),
    'crc32_bzip2': lambda d: crc_gen(d, 0x04C11DB7, 0xFFFFFFFF, False, False, 0xFFFFFFFF),
    'crc32_jamcrc': lambda d: (zlib.crc32(d) ^ 0xFFFFFFFF) & 0xFFFFFFFF,
    'crc32_posix_cksum': lambda d: zlib.crc32(d),  # 简化
    'fnv1a32': fnv1a32,
    'fnv132': fnv132,
    'djb2': djb2,
    'sdbm': sdbm,
    'murmur3_32': murmur3_32,
    'wordsum': wordsum,
    'wordxor': wordxor,
    'md5_le4': lambda d: struct.unpack('<I', hashlib.md5(d).digest()[:4])[0],
    'md5_be4': lambda d: struct.unpack('>I', hashlib.md5(d).digest()[:4])[0],
    'sha1_le4': lambda d: struct.unpack('<I', hashlib.sha1(d).digest()[:4])[0],
    'sha1_be4': lambda d: struct.unpack('>I', hashlib.sha1(d).digest()[:4])[0],
    'sha256_le4': lambda d: struct.unpack('<I', hashlib.sha256(d).digest()[:4])[0],
    'sha256_be4': lambda d: struct.unpack('>I', hashlib.sha256(d).digest()[:4])[0],
}
found = []
for iname, idata in inputs.items():
    for aname, fn in algos.items():
        try:
            v = fn(idata)
        except Exception:
            continue
        if v == TARGET11:
            found.append((iname, aname))
            print(f'  ★★★ 命中: {aname}({iname}) = {v}')
if not found:
    print('  全部算法×输入组合未命中')
    # 打印各算法在两个主输入上的值, 便于人工比对模式
    for iname in ('blob_stored_6677', 'outer_dec_6666'):
        vals = {a: fn(inputs[iname]) for a, fn in list(algos.items())[:8]}
        print(f'  {iname}: ' + ' '.join(f'{a}={v:#010x}' for a, v in vals.items()))

print()
print('=' * 72)
print('PART 4 — 0x20 全序列 + 关联分析')
print('=' * 72)
p20 = [(i, c, pl2) for i, (t, c, pl2, idx) in enumerate(r.pkts) if t == 0x20]
print(f'0x20 包数: {len(p20)}')
series = []
for gi, clock, pay in p20:
    a, b = struct.unpack('<ff', pay[:8])
    t = struct.unpack('<f', struct.pack('<I', clock))[0]
    series.append((t, a, b, gi))
for t, a, b, gi in series:
    print(f'  pkt#{gi:<6} t={t:8.3f}s  A={a:+9.4f}  B={b:+9.4f}')

# 相机模式事件（0x1B）
cam = []
for t, c, pay, idx in r.pkts:
    if t == 0x1B:
        mode = pay.rstrip(b'\x00').decode('utf-8', 'replace')
        tc = struct.unpack('<f', struct.pack('<I', c))[0]
        cam.append((tc, mode))
print(f'\n相机模式串(0x1B) {len(cam)} 次: 模式集合 {Counter(m for _, m in cam)}')

# 击杀时间（decoded_full.json events）
kills = []
for ev in dec.get('events', []):
    if isinstance(ev, dict) and ev.get('type') in ('kill', 'vehicle_death', 'death'):
        kills.append(ev.get('time') or ev.get('clock') or ev.get('t'))
print(f'击杀事件字段样本: {dec["events"][:2] if dec.get("events") else "无"}')

# 关联: 0x20 包与最近的相机切换/击杀的时间差
cam_times = [tc for tc, m in cam if m in ('arty', 'strategic')]
print(f'\narty/strategic 切换时刻(前20): {[round(x,1) for x in cam_times[:20]]}')
flips = []
for i in range(1, len(series)):
    if series[i][1] != series[i - 1][1]:
        flips.append(series[i][0])
print(f'0x20 A 值翻转时刻({len(flips)}): {[round(x,1) for x in flips]}')

# 差分
print('\n0x20 相邻间隔:')
for i in range(1, len(series)):
    dt = series[i][0] - series[i - 1][0]
    print(f'  {series[i-1][0]:8.2f} -> {series[i][0]:8.2f}  dt={dt:7.2f}s  '
          f'({series[i-1][1]:+.3f},{series[i-1][2]:+.3f})->({series[i][1]:+.3f},{series[i][2]:+.3f})')
