#!/usr/bin/env python3
"""pack_v37.py — V37 打包: Task 59-d karelia2 -1 例定性(增量)"""
import os, hashlib, json, zipfile, shutil, tempfile

BASE = '/home/z/my-project'
V36 = f'{BASE}/download/WoT回放解析交付包_v36.zip'
OUT = f'{BASE}/download/WoT回放解析交付包_v37.zip'

def md5f(p):
    h = hashlib.md5()
    with open(p, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()

tmp = tempfile.mkdtemp(prefix='v37_')
with zipfile.ZipFile(V36, mode='r') as z:
    z.extractall(tmp)

for name in ('findings.md', 'worklog.md'):
    dst = f'{tmp}/{name}'
    if os.path.exists(dst):
        os.remove(dst)
    shutil.copy2(f'{BASE}/{name}', dst)

n = 0
for f in os.listdir(f'{BASE}/download/data_v39'):
    src, dst = f'{BASE}/download/data_v39/{f}', f'{tmp}/data_v39/{f}'
    if not os.path.exists(dst) or os.path.getmtime(src) > os.path.getmtime(dst):
        shutil.copy2(src, dst); n += 1
for f in os.listdir(f'{BASE}/scripts'):
    if f.startswith('t59_') or f.startswith('pack_v3'):
        src, dst = f'{BASE}/scripts/{f}', f'{tmp}/scripts/{f}'
        if not os.path.exists(dst) or os.path.getmtime(src) > os.path.getmtime(dst):
            shutil.copy2(src, dst); n += 1
print(f'增量同步: {n} 件')

rd = f'{tmp}/README.md'
if not os.path.exists(rd):
    rd = f'{tmp}/readme.md'
with open(rd, 'a', encoding='utf-8') as f:
    f.write('''

## V37 (2026-09-26) — Task 59-d: karelia2 deathOrder -1 例定性 ★★★
- **karelia2 -1 例定性 = 流截止时序竞态**（Task 39 以来 5 轮交接的边缘项终结）:
  - 链 21 条（seq=1..21 连续、victim 全去重、21 死 9 生 attacker 自洽）= 服务器权威流，完整无异常
  - 第 21 杀（clk=1140333117）晚于 0x05 花名册快照流截止（clk=1140303626）0.45 秒——victim 的 isAlive=0 从未进入客户端观测面
  - 伴随 0x35 NRL 组件创建（同 clk）佐证击杀真实发生
- 连带修正: v24「220/221」的 isAlive 数据源 = 0x05 花名册终态快照（非结算 jsonl）
''')

audit = {
 "version": "v37", "date": "2026-09-26",
 "task": "Task 59-d: karelia2 deathOrder -1 例定性(流截止时序竞态)",
 "headline": [
  "★★★ karelia2 -1 例定性: 链 21 条(seq 连续/victim 全去重/21死9生自洽)=权威流完整; 第21杀晚于 0x05 快照流截止 0.45s, isAlive=0 未入观测面——时序竞态伪影非数据异常",
  "0x35 NRL 组件创建同 clk 佐证击杀真实; v24「220/221」isAlive 数据源修正=0x05 花名册终态快照",
  "Task 39 以来 5 轮交接边缘项终结"
 ],
 "coverage": {
  "corpus": "10 场随机战(11 文件)", "total_pkts": 1514067, "total_payload_bytes": 48202991,
  "weighted_understanding_pct": 96.4,
  "remaining": [
   "①0x37 Root 体前缀精确文法 + 深路径 2082 条(主线唯一剩余结构性缺口)",
   "②指纹级: q_xz=16416314×2⁻³⁰ 数值来源 / 0x39 41B 字段级 / 子对象槽位 / B_y×车型悬挂行程表 / LSB 位表内容 / 0x39 72B [16B 常量] 域",
   "③边缘剩余: ln156 消歧 / 59 tid 补名 / 0x35 class2 NRL 形态"
  ]
 }
}
with open(f'{tmp}/audit_v37.json', 'w', encoding='utf-8') as f:
    json.dump(audit, f, indent=1, ensure_ascii=False)

if os.path.exists(OUT):
    os.remove(OUT)
with zipfile.ZipFile(OUT, mode='w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for root, dirs, files in os.walk(tmp):
        dirs.sort()
        for fn in sorted(files):
            fp = os.path.join(root, fn)
            z.write(fp, os.path.relpath(fp, tmp))

size = os.path.getsize(OUT); digest = md5f(OUT)
with zipfile.ZipFile(OUT, mode='r') as z:
    assert z.testzip() is None
    names = z.namelist()
print(f'V37 打包完成: {len(names)} 条目, {size} B ({size/1048576:.2f} MB), md5={digest}')

os.makedirs(f'{BASE}/upload/backup_v37', exist_ok=True)
shutil.copy2(OUT, f'{BASE}/upload/backup_v37/WoT回放解析交付包_v37.zip')
shutil.copy2(f'{tmp}/audit_v37.json', f'{BASE}/upload/backup_v37/audit_v37.json')
shutil.copy2(f'{BASE}/findings.md', f'{BASE}/upload/backup_v37/findings.md')
shutil.copy2(f'{BASE}/worklog.md', f'{BASE}/upload/backup_v37/worklog.md')
shutil.copy2(f'{tmp}/audit_v37.json', f'{BASE}/download/audit_v37.json')
shutil.rmtree(tmp)
print('backup_v37 入库')
