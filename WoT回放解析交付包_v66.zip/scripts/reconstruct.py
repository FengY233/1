# -*- coding: utf-8 -*-
"""reconstruct.py — 实体映射 + 战斗全景重建 + 游戏时间轴"""
import io
import json
import struct
import sys
from collections import Counter, defaultdict

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile
from bw_pickle import bw_loads

R = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
pkts = R.pkts

periods = {}
for p in pkts:
    if p[0] == 0x16:
        (v,) = struct.unpack('<I', p[2])
        periods[v] = p[1]
p2, p3, p4 = periods[2], periods[3], periods[4]

# ---------- 1. 实体映射: 0x5 createEntity ----------
print('==== createEntity (0x5) 实体清单 ====')
creates = []
for p in pkts:
    if p[0] != 0x5 or len(p[2]) < 46:
        continue
    (eid,) = struct.unpack_from('<I', p[2], 0)
    (tidx,) = struct.unpack_from('<I', p[2], 4)
    creates.append((eid, tidx, p))
type_count = Counter(t for _, t, _ in creates)
print('createEntity 总数: %d, 类型分布: %s' % (len(creates), dict(type_count)))
byid = {}
for eid, tidx, p in creates:
    byid.setdefault(eid, []).append((tidx, p[3]))

# JSON 车辆表
data = open('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay', 'rb').read()
magic, bc = struct.unpack_from('<II', data, 0)
pos = 8
blocks = []
for _ in range(bc):
    (blen,) = struct.unpack_from('<I', data, pos)
    blocks.append(data[pos + 4:pos + 4 + blen])
    pos += 4 + blen
j0 = json.loads(blocks[0].decode('utf-8'))
veh_name = {int(k): v['name'] for k, v in j0['vehicles'].items()}
veh_type = {int(k): v['vehicleType'] for k, v in j0['vehicles'].items()}

print()
print('实体ID → 类型 (样例):')
for eid, lst in sorted(byid.items())[:50]:
    in_json = eid in veh_name
    print('  0x%08X (%d): type=%s ×%d %s' % (
        eid, eid, sorted(set(t for t, _ in lst)), len(lst),
        ('→ ' + veh_name[eid] + ' ' + veh_type[eid]) if in_json else ''))

# ---------- 2. 0xD 空间数据 / 0x6 ----------
print()
print('==== 实体类型汇总 ====')
# 对每个实体ID统计 0xA 出现次数(活跃度)
act = Counter()
for p in pkts:
    if p[0] == 0xA and len(p[2]) >= 8:
        (e,) = struct.unpack_from('<I', p[2], 0)
        act[e] += 1
print('0xA 更新最多的实体 top 20:')
for e, c in act.most_common(20):
    print('  0x%08X (%d): %d 次 %s' % (e, e, c, ('= ' + veh_name[e]) if e in veh_name else ''))

# ---------- 3. 游戏时间轴: 用 0x36 标记构建 ----------
print()
print('==== 游戏时间轴构建 (0x36 = 游戏tick标记) ====')
# 每个包的游戏时间 = battle 开始后的 tick 数 × 0.1s
# tick 计数: 0x36 出现次数(战斗窗口内)
ticks = 0
game_t = {}
tick_clocks = []
for p in pkts:
    if p3 <= p[1] < p4:
        if p[0] == 0x36:
            ticks += 1
            tick_clocks.append(p[1])
        game_t[p[3]] = ticks
print('战斗窗口 0x36 总数 = %d → 游戏时长 ≈ %.1f s' % (ticks, ticks / 10.0))

# ---------- 4. 击杀/伤害事件 (chat ev=76) ----------
print()
print('==== 击杀/伤害/聊天事件时间线 (游戏秒) ====')
events = []
for p in pkts:
    if p[0] != 0x31:
        continue
    (nl,) = struct.unpack_from('<I', p[2], 0)
    name = p[2][4:4 + nl].decode('utf-8', 'replace')
    off = 4 + nl
    (dl,) = struct.unpack_from('<I', p[2], off)
    dta = p[2][off + 4:off + 4 + dl]
    try:
        obj = bw_loads(dta)
    except Exception:
        continue
    if not (isinstance(obj, tuple) and len(obj) == 3 and isinstance(obj[2], dict)):
        continue
    ev = obj[0]
    a = obj[2]
    gt = (game_t.get(p[3], 0)) / 10.0
    if p[1] < p3:
        gt = -((p3 - p[1]) / 57475.0)  # 战前: 用 wall 换算的负值(倒计时)
    if ev == 76:
        events.append((gt, 'damage/kill', a.get('int32Arg1'), a.get('int64Arg1')))
    elif ev == 29:
        events.append((gt, 'waypoint', a.get('int64Arg1'), a.get('int32Arg1')))
    elif ev in (74, 79):
        events.append((gt, 'marker', str(a.get('strArg1', ''))[:60], None))
for e in events:
    print('  t=%8.1fs  %-12s %s' % (e[0], e[1], e[2:]))
