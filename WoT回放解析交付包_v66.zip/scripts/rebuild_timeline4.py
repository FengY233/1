# -*- coding: utf-8 -*-
"""时间轴重建 v4: 炮弹实体创建锚点 -> 精确定位 tick 缺口( seek 事件 )"""
import sys, json, struct, math, statistics
sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile
from collections import defaultdict

BATTLE_START_BT = 139.769

# ---------- 会话数据: 射击事件(射手+时刻) + 玩家轨迹 + 全部 battle_tick own ----------
sess_shots = []   # (bt, shooterID)
own_pts = []
for line in open('/home/z/my-project/upload/session_20260911_175934.jsonl', encoding='utf-8'):
    o = json.loads(line)
    if o['ev'] == 'arena.onVehicleShot':
        sess_shots.append((o['data']['bt'] - BATTLE_START_BT, o['data']['args'][0]))
    elif o['ev'] == 'battle_tick':
        d = o['data']
        if d.get('own'):
            own_pts.append((d['bt'] - BATTLE_START_BT, *d['own']['position']))
print(f'会话射击: {len(sess_shots)} 发')

# 名单
import struct as st
raw = open('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay', 'rb').read()
magic, bc = st.unpack_from('<II', raw, 0)
pos = 8; blocks = []
for _ in range(bc):
    (blen,) = st.unpack_from('<I', raw, pos)
    blocks.append(raw[pos+4:pos+4+blen]); pos += 4+blen
j0 = json.loads(blocks[0])
veh = {int(k): v for k, v in j0['vehicles'].items()}

rf = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
pkts = rf.pkts
p3_pkt = next(p[3] for p in pkts if p[0] == 0x16 and p[2] == b'\x03\x00\x00\x00')
p4_pkt = next(p[3] for p in pkts if p[0] == 0x16 and p[2] == b'\x04\x00\x00\x00')

# ---------- 回放: 0x5 实体创建包 -> 炮弹实体(非546611xxx) ----------
shell_creates = []  # (pktIdx, clock, eid, x, y, z)
for ty, clock, payload, idx in pkts:
    if ty != 0x5 or len(payload) < 46 or not (p3_pkt <= idx <= p4_pkt):
        continue
    eid, tidx = struct.unpack_from('<II', payload, 0)
    if 546611000 <= eid < 546612000:
        continue  # 车辆
    x, y, z = struct.unpack_from('<3f', payload, 8)
    shell_creates.append((idx, clock, eid, tidx, x, y, z))
print(f'战斗窗口内非车辆实体创建: {len(shell_creates)} 个')

# ---------- 玩家轨迹作补充锚点 ----------
rep_own = []
for ty, clock, payload, idx in pkts:
    if ty != 0xA or not (p3_pkt <= idx <= p4_pkt) or len(payload) < 45:
        continue
    eid, _ = struct.unpack_from('<II', payload, 0)
    if eid != 546611525:
        continue
    x, y, z = struct.unpack_from('<3f', payload, 8)
    rep_own.append((idx, clock, x, y, z))

anchors = []
for idx, clock, x, y, z in rep_own:
    cands = [bt for bt, sx, sy, sz in own_pts if abs(sx-x) <= 2.0 and abs(sz-z) <= 2.0]
    if cands and max(cands) - min(cands) <= 8.0:
        anchors.append((idx, clock, sum(cands)/len(cands), 'own'))

# ---------- 炮弹实体 -> 匹配会话射击 ----------
# 炮弹生成位置 = 射手炮口位置。对每个炮弹实体, 找最近的射手(用会话中该射手在射击时刻的位置不可得,
# 但射击时刻近似 = 生成时刻, 而射手位置可用回放中车辆 0xA 轨迹插值)。
# 简化: 先用已有锚点把炮弹创建的 pkt 位置映射到真实时间附近(粗), 再在会话射击列表中找时间最近的同射手射击。
# 由于粗时间误差可能大, 改用: 对每个炮弹实体, 在回放车辆轨迹中找创建时刻±200包内最近车辆(距离<15m) => 射手。
veh_pos = defaultdict(list)
for ty, clock, payload, idx in pkts:
    if ty != 0xA or not (p3_pkt <= idx <= p4_pkt) or len(payload) < 45:
        continue
    eid, _ = struct.unpack_from('<II', payload, 0)
    if 546611000 <= eid < 546612000:
        x, y, z = struct.unpack_from('<3f', payload, 8)
        veh_pos[eid].append((idx, x, y, z))

matched = 0
for idx, clock, eid, tidx, x, y, z in shell_creates:
    # 找创建前最近的车辆位置记录 (idx-800 ~ idx+50)
    best = None; bd = 1e18
    for veid, pts in veh_pos.items():
        for pidx, vx, vy, vz in pts:
            if idx-800 <= pidx <= idx+50:
                d2 = (vx-x)**2 + (vy-y)**2 + (vz-z)**2
                if d2 < bd:
                    bd = d2; best = veid
    if best is None or bd > 400:  # 20m
        continue
    # 该射手在会话中的射击时刻 -> 用炮弹实体 id 作为区分: 同一射手的第 k 发
    # 先粗匹配: 用锚点插值得到真实时间
    t_est = None
    for a in anchors:
        if a[0] >= idx:
            t_est = a[2]; break
    if t_est is None:
        t_est = anchors[-1][2] if anchors else 0
    # 在 t_est±40s 内该射手的射击
    cands = [(abs(bt - t_est), bt) for bt, sh in sess_shots if sh == best and abs(bt - t_est) <= 40]
    if cands:
        _, bt = min(cands)
        anchors.append((idx, clock, bt, f'shell:{eid}'))
        matched += 1

anchors.sort()
print(f'炮弹锚点匹配: {matched} / {len(shell_creates)}')
print(f'总锚点: {len(anchors)}')

# ---------- 用锚点构建分段线性映射, 统计 tick 缺口 ----------
ticks_wc = [(p[3], p[1]) for p in pkts if p[0] == 0x36 and p3_pkt <= p[3] <= p4_pkt]
print(f'战斗窗口 tick: {len(ticks_wc)}')

# 对每个 tick, 用锚点插值真实时间; 记录 (tick序号 -> true_t)
def interp_true(pkt_idx):
    if pkt_idx <= anchors[0][0]:
        return anchors[0][2]
    if pkt_idx >= anchors[-1][0]:
        return anchors[-1][2]
    for i in range(len(anchors)-1):
        a, b = anchors[i], anchors[i+1]
        if a[0] <= pkt_idx <= b[0]:
            if b[0] == a[0]:
                return a[2]
            f = (pkt_idx - a[0]) / (b[0] - a[0])
            return a[2] + f * (b[2] - a[2])
    return anchors[-1][2]

# 逐 tick: true_t 应该按 0.1s 递增; 累计偏差即缺口
gaps = []
prev_true = None
for k, (tidx, tclock) in enumerate(ticks_wc):
    t = interp_true(tidx)
    if prev_true is not None:
        d = t - prev_true
        if d > 0.35 and d < 500:  # 单步游戏时间跳变 >0.35s
            gaps.append((tidx, prev_true, t, d))
    prev_true = t
print(f'\n=== tick 级缺口(游戏时间跳变>0.35s) ===')
for tidx, t0, t1, d in gaps:
    print(f'  pkt#{tidx}: true {t0:.1f}s → {t1:.1f}s  跳过 {d:.2f}s')
print(f'缺口总数: {len(gaps)}, 累计跳过: {sum(g[3] for g in gaps):.2f}s')

json.dump({'anchors': [(a[0], a[1], round(a[2], 2), a[3]) for a in anchors],
           'gaps': [(g[0], round(g[1], 2), round(g[2], 2), round(g[3], 2)) for g in gaps]},
          open('/home/z/my-project/scripts/timeline_v4.json', 'w'))
print('\n已保存 scripts/timeline_v4.json')
