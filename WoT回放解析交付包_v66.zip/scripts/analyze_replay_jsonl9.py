# -*- coding: utf-8 -*-
"""analyze_replay_jsonl9.py — 连续时间窗对照: 0x1A(A,B,dir,v) + 0x26(pos,quat) + 车辆0x0A + 相机模式。
"""
import json
import struct
import sys
import bisect
import math

sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

REPLAY = '/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay'
JSONL = '/home/z/my-project/upload/replay.jsonl'

rf = ReplayFile(REPLAY)
lines = []
with open(JSONL) as f:
    for line in f:
        if line.strip():
            lines.append(json.loads(line))

def f32(u):
    return struct.unpack('<f', struct.pack('<I', u))[0]

t26 = []
t1a = []
veh = []
modes = []
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    t = f32(clock)
    if ty == 0x26 and 'pos' in d:
        t26.append((t, d['pos'], d.get('quat')))
    elif ty == 0x1A and 'f' in d and len(d['f']) == 15:
        t1a.append((t, d['f']))
    elif ty == 0x0A and d.get('eid') == 546611525 and 'pos' in d:
        veh.append((t, d['pos']))
    elif ty == 0x1B and 'str' in d:
        modes.append((t, d['str']))

t26s = [x[0] for x in t26]
t1as = [x[0] for x in t1a]
vehs = [x[0] for x in veh]

def cur_mode(t):
    m = '?'
    for mt, ms in modes:
        if mt <= t:
            m = ms
        else:
            break
    return m

def quat_fwd_az(q):
    x, y, z, w = q
    cr1 = (y, -x, 0)
    t2 = (cr1[0], cr1[1], cr1[2] + w)
    cr2x = y*t2[2] - z*t2[1]
    cr2y = z*t2[0] - x*t2[2]
    cr2z = x*t2[1] - y*t2[0]
    f = (2*cr2x, 2*cr2y, 1 + 2*cr2z)
    return math.degrees(math.atan2(f[1], f[0]))

print('t     | mode       | A(0:3)                  | v3    | B(5:8)                  | dir(8:11)              | c11   | 车辆pos                 | 0x26.pos                | 26az')
print('-' * 190)
for tt in [x * 0.5 for x in range(400, 441)]:
    j = bisect.bisect_left(t1as, tt)
    a = None
    if j < len(t1a) and abs(t1a[j][0] - tt) < 0.25:
        a = t1a[j]
    k = bisect.bisect_left(vehs, tt)
    v = None
    if k < len(veh) and abs(veh[k][0] - tt) < 0.3:
        v = veh[k]
    m = bisect.bisect_left(t26s, tt)
    s = None
    if m < len(t26) and abs(t26[m][0] - tt) < 0.3:
        s = t26[m]
    if a:
        t, f = a
        A = f'{f[0]:7.1f},{f[1]:6.1f},{f[2]:7.1f}'
        B = f'{f[5]:7.1f},{f[6]:6.1f},{f[7]:7.1f}'
        D = f'{f[8]:5.2f},{f[9]:5.2f},{f[10]:5.2f}'
        print(f'{t:6.1f} | {cur_mode(t):10s} | {A} | {f[3]:5.1f} | {B} | {D} | {f[11]:5.1f} | '
              f'{("%7.1f,%6.1f,%7.1f" % tuple(v[1])) if v else "   -":s} | '
              f'{("%7.1f,%6.1f,%7.1f" % tuple(s[1])) if s else "   -":s} | '
              f'{quat_fwd_az(s[2]) if s and s[2] else 0:5.0f}')
