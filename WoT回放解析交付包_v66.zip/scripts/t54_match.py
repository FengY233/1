#!/usr/bin/env python3
"""t54_match.py — Task 54-①: tid→def 结构匹配器 + 方法ID 排序假说检验
1. def 侧: 128 def 全保真 + 方法参数类型提取 → streamSize 估算
2. tid 侧: t53 事件流聚合 (多数派 np_/方法数/属性格式)
3. 匹配: np_==len(props) 且 方法数==去重方法名数 (硬) + 位置格式兼容 (软)
4. 锚点: 51=OwnVehicle / 123=AvatarVehiclesInfo / 128=NetworkVehicleHierarchy /
   106=ShotsReceiver / 121=SequenceNetworkSync / 150=StagedJetBoostersController
5. OwnVehicle 方法ID 排序假说: streamSize 降序 stable_sort → mid 序列 (4,9,10,2,3,1,5,6,0,7,8) 复核
产出: /tmp/wot/t54_match.json + 控制台报告
"""
import sys, json, glob
from collections import Counter, defaultdict
sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file
from t54_mids import load_component_methods, sorted_slots, BLOB_SCALAR

CD = '/tmp/wot/wot_scripts/component_defs'
SCALAR = {'INT8': 1, 'UINT8': 1, 'BOOL': 1, 'INT16': 2, 'UINT16': 2, 'INT32': 4,
          'UINT32': 4, 'FLOAT32': 4, 'INT64': 8, 'UINT64': 8, 'FLOAT64': 8,
          'OBJECT_ID': 4, 'ENTITY_ID': 4}
VARIABLE = ('ARRAY', 'STRING', 'PYTHON', 'TUPLE', 'BLOB', 'VECTOR2', 'VECTOR3',
            'FIXED_DICT', 'PIPELINE_STATUS')


def sec_text(s):
    if s.type == 1:
        return s.asString()
    if s.children:
        return None
    if s.type == 0 and not s.data:
        return None
    if s.type == 2:
        return str(s.asInt())
    if s.type == 4:
        return 'true' if s.asBool() else 'false'
    return s.data.hex()


def type_name(ty):
    if ty.type == 1:
        return ty.asString()
    if ty.children:
        inner = ty.children[0]
        return inner.asString() if inner.type == 1 else inner.name
    return ty.data.hex()


def arg_stream_size(ty):
    """streamSize 估算: 标量=字节数; 变长=1 (长度头最小值, 待假说检验); 未知 alias=None"""
    nm = type_name(ty)
    if nm in SCALAR:
        return SCALAR[nm]
    if nm in VARIABLE or (nm and any(k in nm for k in ('VEHICLE', 'BATTLE', 'HIERARCHY'))):
        return 1
    return None


def parse_def(path):
    r = decode_file(path)
    out = {'props': [], 'methods': [], 'attrs': {}}
    for node in r.children:
        if node.name == 'Properties':
            for p in node.children:
                pr = {'name': p.name, 'type': None, 'flags': None}
                for c in p.children:
                    if c.name == 'Type':
                        pr['type'] = type_name(c)
                    elif c.name in ('Flags', 'flags'):
                        pr['flags'] = sec_text(c)
                out['props'].append(pr)
        elif node.name in ('CellMethods', 'ClientMethods', 'BaseMethods'):
            for m in node.children:
                mm = {'name': m.name, 'sec': node.name, 'args': [], 'size': 0, 'size_known': True}
                for c in m.children:
                    if c.name == 'Arg':
                        sz = arg_stream_size(c)
                        mm['args'].append(type_name(c))
                        if sz is None:
                            mm['size_known'] = False
                        else:
                            mm['size'] += sz
                out['methods'].append(mm)
        elif node.name in ('DetailLevel', 'DefaultKeyName'):
            out['attrs'][node.name] = sec_text(node)
    # 去重方法名 (重载合并, 网络槽=唯一名)
    uniq = {}
    for m in out['methods']:
        if m['name'] not in uniq:
            uniq[m['name']] = m
    out['uniq_methods'] = list(uniq.values())
    return out


def main():
    # ---------- def 侧 ----------
    defs = {}
    for path in sorted(glob.glob(f'{CD}/*.def')):
        name = path.split('/')[-1].replace('.def', '')
        try:
            defs[name] = parse_def(path)
        except Exception as ex:
            defs[name] = {'error': str(ex)}
    print(f'def: {len(defs)} 个')

    # ---------- OwnVehicle 方法ID 排序假说 ----------
    ov = defs['OwnVehicle']['uniq_methods']
    ov_decl = [m['name'] for m in defs['OwnVehicle']['methods']]
    # 注意: 去重后保留首见序; 声明序(重载合并后) = 首见序
    obs_seq = (4, 9, 10, 2, 3, 1, 5, 6, 0, 7, 8)   # t53 实证槽序 (恒定)
    print('\n== OwnVehicle 方法表 (声明序, 重载合并) ==')
    for i, m in enumerate(ov):
        print(f'  decl{i:2d} {m["name"]:36s} args={m["args"]} size~{m["size"]}')
    # 假说 A: 槽序=streamSize 降序, mid=声明序号 → 检验排序
    idx_by_size_desc = sorted(range(len(ov)), key=lambda i: (-ov[i]['size'], i))
    print('\n假说A (槽=降序, mid=声明号): 预测槽序 =', tuple(idx_by_size_desc))
    print('                              实测槽序 =', obs_seq)
    hitA = tuple(idx_by_size_desc) == obs_seq
    # 假说 B: 槽序=声明序, mid=降序名次 → seq[i] = rank_desc(decl i)
    rank = {di: r for r, di in enumerate(idx_by_size_desc)}
    print('假说B (槽=声明序, mid=降序名次): 预测mid序 =', tuple(rank[i] for i in range(len(ov))))
    print('                                实测mid序 =', obs_seq)
    hitB = tuple(rank[i] for i in range(len(ov))) == obs_seq
    print(f'假说A 命中={hitA}  假说B 命中={hitB}')

    # ---------- tid 侧聚合 ----------
    recs = [json.loads(l) for l in open('/tmp/wot/t53_events_v1.jsonl')]
    tid_sig = defaultdict(lambda: {'np': Counter(), 'props': Counter(), 'n': 0})
    for r in recs:
        evs = r['events']
        for i, e in enumerate(evs):
            if e[0] != 'cr':
                continue
            tid = e[2]
            nv = e[4]
            # 同创建链的 pr/me (到下一个 cr 前一层的归属: 简化为紧邻段)
            props = []
            meth = None
            for e2 in evs[i + 1:]:
                if e2[0] == 'cr':
                    break
                if e2[0] == 'pr':
                    props.append((e2[1], e2[2], e2[4] - e2[3]))
                elif e2[0] == 'me' and meth is None:
                    meth = e2
                elif e2[0] == 'ro' and meth is None:
                    meth = ['me', 'pk', []]   # 花名册: 0 方法
            sig = tid_sig[tid]
            sig['n'] += 1
            if meth is not None:
                nm = len(meth[2])
                np_ = nv - 1 - nm
                sig['np'][np_] += 1
                for (pidx, fmt, sz) in props:
                    sig['props'][(pidx, fmt)] += 1
    # ---------- 方法段序列聚合 (多数派) ----------
    tid_meth_seq = {}
    tseq = defaultdict(list)
    cur = None
    for r in recs:
        for e in r['events']:
            if e[0] == 'cr':
                cur = e[2]
            elif e[0] == 'me' and cur is not None:
                if e[1] == 'pk':
                    tseq[cur].append(tuple(e[2]))
                cur = None
            elif e[0] == 'ro' and cur is not None:
                tseq[cur].append(())
                cur = None
    for t, seqs in tseq.items():
        if seqs:
            seq, cnt = Counter(seqs).most_common(1)[0]
            tid_meth_seq[t] = (len(seq), seq, cnt)

    # ---------- 匹配 ----------
    FMT_TYPE = {
        'u32': {'UINT32', 'INT32', 'OBJECT_ID', 'ENTITY_ID'}, 'u16': {'UINT16', 'INT16'},
        'u8': {'UINT8', 'INT8', 'BOOL'}, 'f32': {'FLOAT32'}, 'f64': {'FLOAT64'},
        'v3': {'VECTOR3'}, 'str': {'STRING', 'PYTHON'}, 'hier': {'ARRAY'},
        'arr16': {'ARRAY'}, 'arrf': {'ARRAY'}, 'arr8': {'ARRAY'}, 'arr4x16': {'ARRAY'},
        't127': {'ARRAY'}, 't54': {'ARRAY'}, 'a104': {'ARRAY'}, 'ov0': {'VEHICLE_SYNC_ATTRS'},
        'ov1': {'VEHICLE_AMMO_LIST'}, 'ov18': {'TARGETING_INFO'}, 'sub': None, 'attach': None,
    }
    ANCHORS = {51: 'OwnVehicle', 123: 'AvatarVehiclesInfo', 128: 'NetworkVehicleHierarchy',
               106: 'ShotsReceiver', 121: 'SequenceNetworkSync', 150: 'StagedJetBoostersController',
               154: 'AuxiliaryRocketLauncherComponent', 87: 'BattleFuryController'}
    result = {}
    for tid, sig in sorted(tid_sig.items(), key=lambda kv: -kv[1]['n']):
        np_major, np_cnt = (sig['np'].most_common(1)[0] if sig['np'] else (None, 0))
        nmeth = None
        # 方法数从 np 反推不了; 用 nv-1-np 的众数已含; 单独记录
        # 方法数 (多数派 nm) 与观测方法段序列
        nmeth_major = None
        seq_major = None
        if tid in tid_meth_seq:
            nmeth_major, seq_major, seq_cnt = tid_meth_seq[tid]
        cands = []
        for name, d in defs.items():
            if 'error' in d:
                continue
            if len(d['props']) != np_major:
                continue
            cands.append(name)
        # 软证据: 位置格式兼容
        scored = []
        for name in cands:
            d = defs[name]
            try:
                ms = load_component_methods(name)
                pred_seq = tuple(sorted_slots(ms))
            except Exception:
                ms, pred_seq = [], ()
            seq_hit = None
            if seq_major is not None:
                seq_hit = (pred_seq == seq_major)
            compat = 0
            total = 0
            for (pidx, fmt), c in sig['props'].items():
                ty = d['props'][pidx]['type'] if pidx < len(d['props']) else None
                total += c
                okset = FMT_TYPE.get(fmt)
                if okset is None:
                    continue
                if ty in okset or (fmt == 'hier' and ty == 'ARRAY'):
                    compat += c
                elif ty is None:
                    pass
            scored.append((compat, total, name, seq_hit, len(ms)))
        scored.sort(key=lambda x: (-x[0], -(1 if x[3] else 0), x[2]))
        best = scored[0] if scored else None
        tier = 'C'
        if len(scored) == 1:
            tier = 'A'
        elif len(scored) >= 2 and best and best[1] and best[0] == best[1] and \
                (scored[1][0] < best[0] or scored[1][1] < best[1]):
            tier = 'B'
        anchor = ANCHORS.get(tid)
        nontrivial = (nmeth_major or 0) >= 1 and seq_major
        seq_verified = nontrivial and any(s[3] for s in scored)
        if seq_verified and sum(1 for s in scored if s[3]) == 1:
            tier = 'S'
        result[tid] = {
            'n_creates': sig['n'], 'np_major': np_major, 'np_stability': f'{np_cnt}/{sig["n"]}',
            'nmeth_major': nmeth_major, 'meth_seq_major': list(seq_major) if seq_major else None,
            'candidates': [s[2] for s in scored[:6]], 'compat': f'{best[0]}/{best[1]}' if best else '-',
            'seq_verified': seq_verified, 'seq_verified_defs': [s[2] for s in scored if s[3]][:3],
            'tier': tier, 'anchor': anchor, 'anchor_ok': (anchor in [s[2] for s in scored]) if anchor else None,
            'props_observed': {f'{k[0]}:{k[1]}': v for k, v in sig['props'].most_common(8)},
        }
    json.dump(result, open('/tmp/wot/t54_match.json', 'w'), ensure_ascii=False, indent=1)
    print('\n== tid→def 匹配表 (tier A=唯一 B=软证据胜出 C=歧义) ==')
    for tid, rr in result.items():
        mark = '✓锚点' if rr['anchor_ok'] else ('✗锚点!' if rr['anchor_ok'] is False else '')
        sv = '★序验证' if rr['seq_verified'] else ''
        print(f'  tid={tid:3d} ×{rr["n_creates"]:4d} np={rr["np_major"]} nm={rr["nmeth_major"]} [{rr["tier"]}] {rr["candidates"][:3]} {mark} {sv}')


if __name__ == '__main__':
    main()
