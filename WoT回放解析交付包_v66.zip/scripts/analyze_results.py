# -*- coding: utf-8 -*-
"""analyze_results.py — 块1 战斗结果深度分析"""
import json
import struct
import io
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

DATA = '/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay'
data = open(DATA, 'rb').read()
magic, bc = struct.unpack_from('<II', data, 0)
pos = 8
blocks = []
for _ in range(bc):
    (blen,) = struct.unpack_from('<I', data, pos)
    blocks.append(data[pos + 4:pos + 4 + blen])
    pos += 4 + blen

j1 = json.loads(blocks[1].decode('utf-8'))
r0, r1, r2 = j1

print('========== item[0].common (战斗公共结果) ==========')
common = r0['common']
for k in sorted(common.keys()):
    s = json.dumps(common[k], ensure_ascii=False)
    if len(s) > 200:
        s = s[:200] + '...'
    print('  %-32s = %s' % (k, s))

print()
print('========== item[0].personal 我方视角 ==========')
pers = r0['personal']
print('personal keys:', list(pers.keys())[:5], '... total', len(pers))
mine = pers.get('8705') or list(pers.values())[0]
print('个人结果字段数:', len(mine))
for k in sorted(mine.keys()):
    s = json.dumps(mine[k], ensure_ascii=False)
    if len(s) > 160:
        s = s[:160] + '...'
    print('  %-36s = %s' % (k, s))

print()
print('========== item[1][546611525] 玩家扩展结果 ==========')
p1 = r1['546611525']
print('字段数:', len(p1))
for k in sorted(p1.keys()):
    s = json.dumps(p1[k], ensure_ascii=False)
    if len(s) > 160:
        s = s[:160] + '...'
    print('  %-36s = %s' % (k, s))
