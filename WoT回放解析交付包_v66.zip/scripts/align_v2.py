# -*- coding: utf-8 -*-
"""align_v2.py — 终极对齐: 回放内击杀事件的 clock ↔ 新jsonl的bt
重建 clock↔game_time 映射与真实分段倍速; 检验回跳是否存在
"""
import io
import json
import struct
import sys
from collections import Counter
from datetime import datetime, timedelta

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

CST = timedelta(hours=8)
Q20 = 1048576.0  # 2^20 — 假设的时钟频率 (Hz)


def cst(ts):
    return datetime.utcfromtimestamp(ts) + CST


# ---------- 1. 两个 jsonl 的击杀与阶段 ----------
def load(path):
    return [json.loads(l) for l in open(path, encoding='utf-8') if l.strip()]


old_evs = load('/home/z/my-project/upload/session_20260911_175934.jsonl')
new_evs = load('/home/z/my-project/upload/session_20260923_140427.jsonl')


def kills_of(evs):
    return [(e['data']['bt'], e['data']['args'][0], e['data']['args'][1])
            for e in evs if e['ev'] == 'arena.onVehicleKilled']


def periods_of(evs):
    out = {}
    for e in evs:
        if e['ev'] == 'battle.period_change':
            out[e['data']['period']] = e['data']['bt']
    return out


ok, nk = kills_of(old_evs), kills_of(new_evs)
op, npr = periods_of(old_evs), periods_of(new_evs)
print('旧jsonl 击杀: %d, p1..p4 bt: %s' % (len(ok), op))
print('新jsonl 击杀: %d, p1..p4 bt: %s' % (len(nk), npr))
print('击杀相对战斗开始(p3)时间一致检查:')
n_p3 = npr[3]
diffs = [(ob - nb) for (ob, _, _), (nb, _, _) in zip(ok, nk)]
print('  旧-新 bt 恒差: min=%.3f max=%.3f (应≈常数=%.3f)' % (min(diffs), max(diffs), op[3] - n_p3))
rel_new = [(bt - n_p3, v, k) for bt, v, k in nk]
print('  新jsonl 击杀(战斗相对秒) 前5:', ['%.2f' % r[0] for r in rel_new[:5]])

# ---------- 2. 回放内定位击杀包 ----------
R = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
pkts = R.pkts
p16 = [(struct.unpack('<I', p[2])[0], p[1], p[3]) for p in pkts if p[0] == 0x16]
p3_clk = [c for v, c, i in p16 if v == 3][0]
p4_clk = [c for v, c, i in p16 if v == 4][0]
p2_clk = [c for v, c, i in p16 if v == 2][0]
print('\n回放阶段 clock: p2=%d p3=%d p4=%d' % (p2_clk, p3_clk, p4_clk))

# 搜索 victim+killer 8字节模式
kill_pkts = []
for idx, (bt_rel, vic, kil) in enumerate(rel_new):
    pat = struct.pack('<II', vic, kil)
    hits = [p for p in pkts if p[1] >= p3_clk and pat in p[2]]
    if not hits:  # 也试 victim 单独 + 附近 killer
        hits = [p for p in pkts if p[1] >= p3_clk and struct.pack('<I', vic) in p[2] and len(p[2]) < 60]
    kill_pkts.append((idx, bt_rel, vic, kil, hits))
found = sum(1 for k in kill_pkts if k[4])
print('字节模式命中: %d/25' % found)
for idx, bt_rel, vic, kil, hits in kill_pkts:
    hs = ['pkt#%d t=0x%X clk=%.3fs len=%d' % (h[3], h[0], h[1] / Q20, len(h[2])) for h in hits[:3]]
    print('  kill#%02d bt_rel=%7.2f vic=%d kil=%d -> %s' % (idx + 1, bt_rel, vic, kil, hs))

# ---------- 3. 保存锚点供后续使用 ----------
anchors = []
for idx, bt_rel, vic, kil, hits in kill_pkts:
    if hits:
        h = sorted(hits, key=lambda x: abs(x[1] - (p3_clk + bt_rel * Q20 / 18)))[0]  # 先粗选
        anchors.append({'kill': idx + 1, 'bt_rel': bt_rel, 'victim': vic, 'killer': kil,
                        'pkt': h[3], 'type': h[0], 'clock': h[1]})
json.dump({'period_clocks': {'p2': p2_clk, 'p3': p3_clk, 'p4': p4_clk},
           'new_periods_bt': npr, 'old_periods_bt': op,
           'new_kills': [(b, v, k) for b, v, k in nk], 'old_kills': [(b, v, k) for b, v, k in ok],
           'anchors_raw': anchors},
          open('/home/z/my-project/scripts/align_v2_raw.json', 'w'), ensure_ascii=False, indent=1)
print('\n原始锚点已存 scripts/align_v2_raw.json')
