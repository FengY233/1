# -*- coding: utf-8 -*-
"""时间轴重建 v2: 玩家轨迹位置匹配 + 炮弹实体创建锚点"""
import sys, json, struct, math
sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile
from collections import defaultdict, Counter
import statistics

BATTLE_START_BT = 139.769

# ---------- 1. 会话玩家真实轨迹 ----------
own_pts = []   # (battle_t, x, y, z)
shots_sess = []  # 玩家射击 bt
for line in open('/home/z/my-project/upload/session_20260911_175934.jsonl', encoding='utf-8'):
    o = json.loads(line)
    if o['ev'] == 'battle_tick':
        d = o['data']
        own = d.get('own')
        if own:
            own_pts.append((d['bt'] - BATTLE_START_BT, *own['position']))
    elif o['ev'] == 'arena.onVehicleShot':
        if o['data']['args'][0] == 546611525:
            shots_sess.append(o['data']['bt'] - BATTLE_START_BT)
print(f'会话 own 轨迹: {len(own_pts)} 点; 玩家射击: {len(shots_sess)} 发 @ {[round(t,1) for t in shots_sess]}')

# ---------- 2. 回放玩家轨迹 ----------
rf = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
pkts = rf.pkts
p3_pkt = next(p[3] for p in pkts if p[0] == 0x16 and p[2] == b'\x03\x00\x00\x00')
p4_pkt = next(p[3] for p in pkts if p[0] == 0x16 and p[2] == b'\x04\x00\x00\x00')
rep_pts = []  # (idx, clock, x, y, z)
for ty, clock, payload, idx in pkts:
    if ty != 0xA or not (p3_pkt <= idx <= p4_pkt) or len(payload) < 45:
        continue
    eid, _tidx = struct.unpack_from('<II', payload, 0)
    if eid != 546611525:
        continue
    x, y, z = struct.unpack_from('<3f', payload, 8)
    rep_pts.append((idx, clock, x, y, z))
print(f'回放玩家轨迹: {len(rep_pts)} 点')

# ---------- 3. 位置匹配（仅保留移动期产生的唯一性锚点） ----------
# 计算会话轨迹每个时刻的"位置唯一性": 若该位置在 ±1.5m 内只在 <8s 的窗口出现, 则可用
anchors = []
for idx, clock, x, y, z in rep_pts:
    cands = []
    for bt, sx, sy, sz in own_pts:
        if abs(sx-x) <= 2.0 and abs(sz-z) <= 2.0:
            cands.append(bt)
    if cands:
        span = max(cands) - min(cands)
        if span <= 8.0:  # 位置只出现在短暂窗口 -> 时间可定位
            anchors.append((idx, clock, sum(cands)/len(cands), span))
anchors.sort()
print(f'\n高置信锚点: {len(anchors)} 个')

# ---------- 4. 映射形状: 滑动中位数 ----------
W = 60
print('\n流位置(pkt#) -> 真实战斗秒 (滑动窗口):')
rows = []
for i in range(0, max(1, len(anchors)-W), max(1, (len(anchors)-W)//40 or 1)):
    win = anchors[i:i+W]
    mi = statistics.median(a[0] for a in win)
    mb = statistics.median(a[2] for a in win)
    rows.append((mi, mb))
    print(f'  pkt#{mi:>8.0f}  true={mb:>6.1f}s   {"#" * int(max(0, mb/12))}')

# ---------- 5. 跳变检测 ----------
print('\n=== 疑似跳变（相邻窗口 true 时间回退>3s 或 前跳>30s）===')
W2 = 40
prev = None
for i in range(0, max(1, len(anchors)-W2), W2//2):
    win = anchors[i:i+W2]
    mi = statistics.median(a[0] for a in win)
    mb = statistics.median(a[2] for a in win)
    if prev is not None:
        d_bt = mb - prev[1]
        d_idx = mi - prev[0]
        if d_bt < -3.0:
            print(f'  回跳 pkt#{prev[0]:.0f}→#{mi:.0f}: true {prev[1]:.1f}s → {mb:.1f}s (Δ{d_bt:+.1f}s)')
        elif d_bt > 30.0 and d_idx < 8000:
            print(f'  前跳 pkt#{prev[0]:.0f}→#{mi:.0f}: true {prev[1]:.1f}s → {mb:.1f}s (Δ{d_bt:+.1f}s)')
    prev = (mi, mb)

# ---------- 6. 会话射击时刻的间隔特征（供对照） ----------
print('\n会话射击间隔(s):', [round(b-a,1) for a,b in zip(shots_sess, shots_sess[1:])])
