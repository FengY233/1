# -*- coding: utf-8 -*-
"""patch_pdf_script.py — 按行号修正 make_pdf_body.py 第七章结论/第八章/新增第十章"""
import io, re

P = '/home/z/my-project/scripts/make_pdf_body.py'
lines = io.open(P, encoding='utf-8').read().split('\n')

# ---- 定位关键行 ----
def find(pred, start=0):
    for i in range(start, len(lines)):
        if pred(lines[i]):
            return i
    return -1

# 1. 第七章结论段 (含"结论:clock = 客户端墙钟微秒")
i_concl = find(lambda l: l.strip().startswith("story.append(P('结论:clock = 客户端墙钟微秒"))
assert i_concl >= 0
# 找该语句结束行(以 '))' 结尾)
j = i_concl
while not lines[j].rstrip().endswith("))"):
    j += 1
new_concl = """story.append(P('结论:clock = 客户端墙钟微秒;观看者以约 17.4 倍平均倍速看完 612.49 秒战斗(实际观看 35.17 秒)。'
               '后经客户端会话日志实证升级(见第十章):倍速范围 0.55x-92x;true 104-165s 段含至少 5 次回跳重看'
               '(累计重放约 107 游戏秒,该段含玩家唯一击杀的高光);高速段录制器丢刻使 tick 仅录得 6,012/6,125。'
               '游戏时间轴以阶段 3 为 t=0,按战斗窗口内累计的 0x36 标记数 ×0.1 秒重建。'))"""
lines[i_concl:j + 1] = new_concl.split('\n')
print(f'第七章结论已替换 (行 {i_concl + 1}~{j + 1})')

# 2. 第八章: 时间线 code 块 (以 code(story, \'\'\'t=-439s 开头)
i_code = find(lambda l: l.startswith("code(story, '''t=-439s"))
assert i_code >= 0
j = i_code
while "''')" not in lines[j]:
    j += 1
new_code = """code(story, '''t=-30.0s   阶段2 倒计时 30s(会话 bt 109.768→139.769)
t=0        阶段3 BATTLE 开始, 计时上限 899.948s
t=42.6s    玩家首发(第1发 HE)
t=66.5s    首杀: 一炮真千金(队1) 击杀 爱喝苏打水的海豹(队2)
t=137.9-164.7s 中盘交换 6 车阵亡
t=215.2s   玩家击杀 Deiiv1(-34, 溅射击杀 numVehiclesAffected=-1)
t=384.2s   僵持 117s 后 steropes 阵亡, 进入残局
t=445-457s 队伍2 试探占队伍1基地(0→2点两次重置)
t=577.8s   玩家末发(第15发) -209 墨染泪倾城
t=591-607s 终局交换 4 车阵亡, 一颗已瞄准的炮弹第3杀
t=612.49s  队伍1 全歼, 阶段4, +6.1s 结果下发''')"""
lines[i_code:j + 1] = new_code.split('\n')
print(f'第八章时间线已替换 (行 {i_code + 1}~{j + 1})')

# 3. 击杀链叙述 (含 "26 次击杀构成完整击杀链")
i_kc = find(lambda l: '26 次击杀构成完整击杀链' in l)
assert i_kc >= 0
j = i_kc
while not lines[j].rstrip().endswith("))"):
    j += 1
new_kc = """story.append(P('25 次击杀构成完整击杀链(比分 15:10,队伍 2 胜,时间已按客户端日志修正;旧版"26次/轨迹末点估算"作废)。'
               'MVP 为一颗已瞄准的炮弹(DBV-152,3 杀 4452 伤害)。伤害榜二至五位:良辰是我儿 3902、墨染泪倾城 3808、'
               '灬浮世之绘灬 3658(0杀)、。一炮送你回车库。3305。玩家在 t=215.2 秒击杀 Deiiv1,最终存活。'
               '以下三图分别为战斗包速率时间线(含阵亡标记)、玩家轨迹与全场车辆位置分布、全场伤害排行。'))"""
lines[i_kc:j + 1] = new_kc.split('\n')
print(f'击杀链叙述已替换 (行 {i_kc + 1}~{j + 1})')

# 4. 8.3 玩家操作 (含 "机动:出生点")
i_83 = find(lambda l: '机动:出生点' in l)
assert i_83 >= 0
j = i_83
while not lines[j].rstrip().endswith("))"):
    j += 1
new_83 = """story.append(P('机动:出生点 (452.6, 1.8, -296.7) 至终点 (16.8, -0.5, -257.0),5Hz 轨迹实测 1,140 米'
               '(结果块 mileage=1141,仅差 1 米)的火炮多转场;'
               '射击:15 发全部 180mm HE(compactDescr=20234),时刻 42.6/96.8/123.8/…/577.8 秒,间隔 26.8-110.5s,'
               '弹药事件 15→1 逐发递减;伤害:客户端可见 6 次掉血共 1,280(262+164+34+282+329+209),'
               '服务器结算 1,669(差 389 为 AoI 外事件未触发);'
               '战果:4 直击+14 溅射命中 6 辆敌车,8 辆敌车被眩晕共 192.18 秒,零友伤,存活至全歼。'))"""
lines[i_83:j + 1] = new_83.split('\n')
print(f'8.3 玩家操作已替换 (行 {i_83 + 1}~{j + 1})')

# 5. 在 doc.multiBuild 之前插入第十章
i_build = find(lambda l: l.startswith('doc.multiBuild('))
assert i_build >= 0
ch10 = '''
# ━━ 第十章 客户端会话日志交叉验证 ━━
h1(story, '第十章 客户端会话日志交叉验证')
story.append(P('用户另行提供了 session_20260911_175934.jsonl(9.19MB,7,341 行事件,42 种类型)——'
               '同一场战斗的客户端实时监控日志(注入钩子产生的 {data, ts, ev} 流,含 BigWorld 对象 repr)。'
               '它与 .wotreplay 构成"第一手实时记录 vs 二手变速再录制"的完美互证样本。'))
table(story,
      ['对账项', '回放侧', '会话侧', '结论'],
      [['avatar/车辆ID', '546611552 / 546611525', '相同', '一致'],
       ['30 人名单', 'block[0] vehicles', 'publicInfo repr 30/30', '全一致'],
       ['四阶段', '60/30/900/60', '10.1/30.0/612.49/60', '一致'],
       ['战斗时长', 'tick 推算 601.4s', '实测 612.49s', '差 11.29s=丢刻'],
       ['击杀链', '25 对 victim←killer', '25 对相同+精确时刻', '逐对一致'],
       ['玩家射击', '15 发(推断)', '15 次精确时刻+弹药 15→1', '一致'],
       ['玩家伤害', '结算 1669', '可见 1280(AoI 内)', '差=AoI 限制'],
       ['轨迹/里程', '范围一致+0.00m 重合', '实测 1,140m', 'mileage=1141 一致']],
      [0.16, 0.30, 0.34, 0.20], '表 10-1 逐项对账结果', td_align=['l', 'l', 'l', 'l'])
h2(story, '10.1 会话生命周期')
code(story, \'\'\'17:59:34.861 客户端启动(v2.4.0.0 #942, CN)
17:59:42.708 登录完成进车库
18:00:12.485 加入随机战队列(队列332人 LT62/MT76/HT85/TD45/SPG64)
18:00:55.927 匹配成功(排队 43.4s)
18:01:00.560 avatar_become_player(加载仅 5.16s)
18:01:39.755 战斗开始(bt=139.769, t=0)
18:11:52.250 战斗结束 612.49s, 队2 全歼胜 15:10
18:11:58.357 结算下发(xp=1052 与结果块一致)
18:12:53.358 断开, 监控落盘(7,341 事件, 0 丢弃)\'\'\')
chart(story, CHARTS + '/06_会话生命周期.png', '图 10-1 会话生命周期与战斗事件时间线(客户端日志权威时刻)', max_h=330)
h2(story, '10.2 观看行为完整还原(实证升级)')
story.append(P('以会话玩家轨迹(3,232 点)为基准对回放 0xA 位置流做匹配(1,124 个高置信锚点),'
               '结合累计 tick 曲线与位置序列回退检测,观看者完整行为时间线得以还原:'
               '回放界面停留 18 分钟后,倒计时以 1.19x 观看;战斗段 35.17s 墙钟覆盖 612.49 游戏秒(平均 17.4x):'
               '开局 3.5-21x 快速浏览;首杀前夕 0.55x 慢放;true 104-165s 段至少 5 次回跳重看'
               '(该段含玩家第 5/6 发射击与唯一击杀 Deiiv1 的高光,累计重放约 107 游戏秒);'
               '蹲坑段 30x 快进;终局 30-92x 高速冲线并丢刻(6,012/6,125 tick)。'
               '三条铁证:累计 tick 偏差曲线前段 +107s/后段 -118s;位置序列 5 处真时间倒退;总 tick 差 113。'
               '"服务器回放在线观看的再录制"从推断升级为实证闭环。'))
chart(story, CHARTS + '/07_观看行为与时间轴对齐.png', '图 10-2 再录制观看行为:真实游戏时间 vs 观看墙钟与累计 tick 偏差', max_h=330)
h2(story, '10.3 客户端事件语义新知')
story.append(P('onVehicleKilled(targetID, attackerID, equipmentID, reason, numVehiclesAffected)——'
               'Avatar.py L2764 原型核对;玩家击杀的 numVehiclesAffected=-1 为火炮溅射击杀特殊值。'
               'veh.onVehicleDestroyed 是 BigWorld 实体销毁事件(AoI 离开/战斗结束清理)而非死亡——'
               '30 次 = 25 阵亡车实体清理 + 5 幸存者;真正死亡只看 onVehicleKilled。'
               'onVehicleHealthChanged(victimID, attackerID, damage) 仅对 AoI 内车辆触发(全场仅录得 83% 总伤害)。'
               '回放 0x31 的 bw_chat2.onActionReceived eventID 经 messenger_common_chat2.py ID 发生器逐位推算全部命名:'
               '19=REINIT_BATTLE_CHAT(clock=0 出现——再录制会话重建聊天,又一铁证)、24=POSITIVE、26=AFFIRMATIVE、'
               '29=REPLY、30=CANCEL_REPLY、38=ATTACKING_ENEMY_WITH_SPG(呼叫火炮集火玩家)、42=RELOADINGGUN、'
               '74=ATTACKING_ENEMY(交战自动标记)、76=DEFENDING_BASE(守家自动标记)、79=CONFIRM。'))

'''
lines[i_build:i_build] = ch10.split('\n')
print(f'第十章已插入 (行 {i_build + 1})')

io.open(P, 'w', encoding='utf-8').write('\n'.join(lines))
print('make_pdf_body.py 补丁完成')
