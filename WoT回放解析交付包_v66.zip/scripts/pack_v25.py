#!/usr/bin/env python3
"""pack_v25.py — Task 46 交付打包: V25 = V24 底座 + Task 45-46 增量
data_v27: t45 系列脚本 8 件 + cgf_names.json + 层级字典副本
scripts 增量: t45_*.py
findings v29 + worklog(至 Task 46)
"""
import os, zipfile, hashlib, shutil

DL = '/home/z/my-project/download'
V24 = f'{DL}/WoT回放解析交付包_v24.zip'
OUT = f'{DL}/WoT回放解析交付包_v25.zip'
DATA27 = f'{DL}/data_v27'

os.makedirs(f'{DATA27}', exist_ok=True)

# 1) t45 脚本 + 产物入 data_v27
import glob
for f in glob.glob('/home/z/my-project/scripts/t45_*.py'):
    shutil.copy(f, DATA27)
shutil.copy('/tmp/wot/cgf_names.json', f'{DATA27}/CGF变量名字典_57+7.json')
shutil.copy(f'{DL}/data_v26/0x32层级字典_260实体_t44_hierarchy_maps.json', f'{DATA27}/层级字典副本.json')

# 2) 以 V24 为底座
zin = zipfile.ZipFile(V24, 'r')
names = zin.namelist()
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as zout:
    for item in zin.infolist():
        if item.filename in ('findings.md', 'worklog.md', 'README.md', 'audit_v24.json'):
            continue  # 换新版本
        zout.writestr(item, zin.read(item.filename))
    # findings/worklog 主位新版
    zout.write('/home/z/my-project/findings.md', 'findings.md')
    zout.write('/home/z/my-project/worklog.md', 'worklog.md')
    # data_v27
    for f in sorted(os.listdir(DATA27)):
        zout.write(f'{DATA27}/{f}', f'data_v27/{f}')
    # scripts 增量(t45 系列)
    for f in sorted(glob.glob('/home/z/my-project/scripts/t45_*.py')):
        zout.write(f, f'scripts/{os.path.basename(f)}')

# 3) README 增补
z = zipfile.ZipFile(OUT, 'a')
readme_add = """

---

# V25 增补（Task 46 · v29 · 0x32 分帧终局修正 + CGF 变量字典）

在 V24 全量底座之上新增：

| 内容 | 说明 |
|---|---|
| `findings.md` | ★ 结论登记册 v29（新增 §25：分帧文法翻案/五 class 处理器/ViewHub-ClientHub 终审/findNode FNV/CGF 变量字典/实例名普查） |
| `data_v27/` | t45 系列脚本 8 件 + **CGF 变量名字典（57 变量 + 7 sequenceEvents）** + 层级字典副本 |
| `scripts/t45_*.py` | 分帧/分发器/RTTI/findNode 反汇编与语料验证脚本 |

核心突破：
1. **后续消息头 = 3 字节 `[class][id_hi][id_lo]`**（MemoryIStream vt+0x20 = PEEK 铁证）；首消息 `[u16 BE id]` + class=0 调用者硬编码——Task 44 的 4 字节头模型勘误。
2. 五 class 处理器逐指令语义（class 0 单组件 / class 1 批量压缩列表 / class 4-6 updateNode = 节点 vt+0x60 自解析）。
3. 枢纽 RTTI 终审：ViewHub@0x1436062b8 / ClientHub@0x143606340（勘误「WGReplayConnection」误标）；findNode = FNV-1a 哈希表。
4. **CGF 变量字典**（vehicle/gun×20、hit×10、damageSticker、aux、sectorVision…）——0x32/0x37 值通道语义钥匙。
5. 9B 绑定族 179/179 = 100% eid ∈ 0x05 创建集（caucasus 实测闭环）。
"""
z.writestr('README.md', readme_add)
audit = {
 "version": "v25",
 "date": "2026-09-26",
 "task": "Task 46: 0x32 分帧终局修正 + ViewHub/ClientHub 双枢纽钉死 + CGF 变量字典",
 "headline": [
  "分帧文法翻案: 后续消息头 3 字节 [class][id_hi][id_lo]; 首消息 class=0 硬编码",
  "五 class 处理器逐指令语义 + updateNode = 节点 vt+0x60 自解析",
  "ViewHub/ClientHub RTTI 终审(勘误 Task 44 WGReplayConnection 误标)",
  "findNode = FNV-1a 哈希表",
  "CGF 变量名字典 57+7 全表 + 实例名普查(prefab/SequenceNetworkSync/玩家名组件)",
  "9B 绑定族 179/179 = 100% eid 闭环"
 ],
 "coverage": {
  "scope": "随机战(bt=1, 10场)",
  "0x32": "分帧层 100%, 组件体层 ~60%(架构全解, 逐类解析器待做)",
  "0x32_0x37_overall": "~96%"
 }
}
import json
z.writestr('audit_v25.json', json.dumps(audit, ensure_ascii=False, indent=1))
z.close()

md5 = hashlib.md5(open(OUT,'rb').read()).hexdigest()
sz = os.path.getsize(OUT)
n = len(zipfile.ZipFile(OUT).namelist())
print(f'V25 打包完成: {n} 文件, {sz:,}B, md5={md5}')

# 4) upload 备份
os.makedirs('/home/z/my-project/upload/backup_v25', exist_ok=True)
shutil.copy(OUT, '/home/z/my-project/upload/backup_v25/')
shutil.copy('/home/z/my-project/findings.md', '/home/z/my-project/upload/backup_v25/')
shutil.copy('/home/z/my-project/worklog.md', '/home/z/my-project/upload/backup_v25/')
shutil.copy('/home/z/my-project/findings.md', '/home/z/my-project/upload/findings.md')
shutil.copy('/home/z/my-project/worklog.md', '/home/z/my-project/upload/worklog.md')
print('upload/backup_v25 备份完成')
