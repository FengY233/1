#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""digest_v8.py — EntityDescriptionMap::digest() 字节级完整复刻（pxml 服务器 .def 输入）

规则链（BigWorld 14.4.1 源码逐函数考证, 见 worklog Task 14/16）:
  for 每实体(服务器 entities.xml 顺序, 40 个全为 client 类型):
    MD5 += name 原始字节
    for 每属性(累积序: Parent链→Implements序→自有; 同名覆盖保留原位):
      仅 isClientServerData() = flags & (OTHER 0x02|OWN 0x04|REPLAY 0x100):
        += int32 csi   ★ = allocateClientServerFullIndexes(): 稳定排序
                        (定长按 streamSize 升序在前, 变长按 VLH 字节数升序在后)
        += [uint32 vlh] 仅当 (定长?否) 且 vlh != 1   # MemberDescription::addToMD5
        += name 原始字节
        += int32 (dataFlags & 0x5F)                  # DATA_DISTRIBUTION_FLAGS
        += DataType 配方
    方法(每组件按名去重先到先得; parse 序 Base→Cell→Client, 累积序同属性):
      client 全部(flags_=0x04, 组件位0+自动 setExposedToAllClients)
      base/cell 仅 isExposed(): flags_ = 组件位(CELL=1/BASE=2) +
        Exposed: ''→0xC  OWN_CLIENT→0x8  ALL_CLIENTS→0x4(仅CELL)
      每条: += [uint32 vlh 仅 client 方法且参数变长且 vlh!=1] + name
            + uint8 flags_ + 各参数 DataType 配方 + int32 count
DataType 配方 (sizeof 含 NUL):
  Int/Uint+int32尺寸 | Float/Float64 | String/UnicodeString/Blob/Python/MailBox
  Vector+int32维数 | Array/Tuple + int32 size + [int32 16777215 若 persistAsBlob] + 元素
  FixedDict + [module+instance 若 implementedBy] + uint8 allowNone + (字段名+配方)*
  Class + uint8 allowNone + (字段名+配方)* | User + module + instance
  UserDataObjectLinkDataType
streamSize: Int/Uint 1/2/4/8, Float 4/64 8, Vector 4n, MailBox 12,
  序列 size*元素(<=0→-1), FixedDict 字段和(任一-1→-1), 其余变长 -1;
  DataDescription::streamSize: 变长 → -varLenHeaderSize
对算目标: 5DF886F75E73B33CFF9D87FB9C69389C (回放头 pkt#3)
"""
import hashlib
import struct
import sys

sys.path.insert(0, '/home/z/my-project/upload/tools')
import bwxml_decode as B

ED = '/tmp/wot_scripts/scripts/entity_defs'
TARGET = '5DF886F75E73B33CFF9D87FB9C69389C'

# ---------------------------------------------------------------- 常量
F_GHOSTED, F_OTHER, F_OWN, F_BASE = 0x01, 0x02, 0x04, 0x08
F_CLIENT_ONLY, F_PERSISTENT, F_EDITOR, F_ID, F_REPLAY = 0x10, 0x20, 0x40, 0x80, 0x100
DIST_FLAGS = 0x5F

FLAG_MAP = {
    'CELL_PRIVATE': 0x00, 'CELL_PUBLIC': F_GHOSTED,
    'OTHER_CLIENTS': F_GHOSTED | F_OTHER, 'OWN_CLIENT': F_OWN,
    'BASE': F_BASE, 'BASE_AND_CLIENT': F_OWN | F_BASE,
    'CELL_PUBLIC_AND_OWN': F_GHOSTED | F_OWN,
    'ALL_CLIENTS': F_GHOSTED | F_OTHER | F_OWN, 'EDITOR_ONLY': F_EDITOR,
}
DEFAULT_VLH = 1

# name → (tag, size 或 None)  None = 无尺寸字段
# 注: FLOAT 为内建别名 → FLOAT32 (data_type.cpp:339 MetaDataType::addAlias)
SIMPLE = {
    'INT8': ('Int', 1), 'INT16': ('Int', 2), 'INT32': ('Int', 4), 'INT64': ('Int', 8),
    'UINT8': ('Uint', 1), 'UINT16': ('Uint', 2), 'UINT32': ('Uint', 4), 'UINT64': ('Uint', 8),
    'FLOAT': ('Float', None), 'FLOAT32': ('Float', None), 'FLOAT64': ('Float64', None),
    'STRING': ('String', None), 'UNICODE_STRING': ('UnicodeString', None),
    'BLOB': ('Blob', None), 'PYTHON': ('Python', None), 'MAILBOX': ('MailBox', None),
    'UDO_REF': ('UserDataObjectLinkDataType', None),
}
SIMPLE_SZ = {
    'INT8': 1, 'INT16': 2, 'INT32': 4, 'INT64': 8,
    'UINT8': 1, 'UINT16': 2, 'UINT32': 4, 'UINT64': 8,
    'FLOAT': 4, 'FLOAT32': 4, 'FLOAT64': 8, 'MAILBOX': 12,
}



# ---------------------------------------------------------------- 变体开关
import json as _json
import os as _os
V = {"client_flags": 0x04, "comp_bits": True, "count": True,
     "vlh_size": 4, "name_nul": False, "flags_mask": 0x5F,
     "allow_none": True, "seq_size": True, "int_size_field": 4,
     "tag_nul": True, "cs_only": True, "exposed_only": True,
     "vlh_default": 1, "sort_csi": True, "count_after_args": True}
V.update(_json.loads(_os.environ.get("DIGEST_V", "{}")))


class MD5Acc:
    def __init__(self):
        self.buf = bytearray()

    def raw(self, s):
        if isinstance(s, str):
            s = s.encode('utf-8')
        self.buf += s

    def i32(self, v):
        self.buf += struct.pack('<i', v)

    def u32(self, v):
        self.buf += struct.pack('<I', v)

    def u8(self, v):
        self.buf += struct.pack('<B', v)

    def tag(self, t):
        self.raw(t.encode('ascii') + b'\x00')

    def hexdigest(self):
        return hashlib.md5(bytes(self.buf)).hexdigest().upper()


# ---------------------------------------------------------------- 文档
class Doc:
    _cache = {}

    def __init__(self, path):
        with open(path, 'rb') as f:
            raw = f.read()
        self.rdict, self.tree, self.consumed = B.decode(raw)

    @classmethod
    def load(cls, name):
        if name in cls._cache:
            return cls._cache[name]
        import os
        for cand in (os.path.join(ED, name + '.def'),
                     os.path.join(ED, 'interfaces', name + '.def')):
            if os.path.isfile(cand):
                d = cls(cand)
                cls._cache[name] = d
                return d
        raise FileNotFoundError('def not found: ' + name)

    def nm(self, idx):
        return self.rdict[idx] if 0 <= idx < len(self.rdict) else '?%d' % idx

    def kids(self, node):
        if isinstance(node, list):
            return [(c[0], c[1]) for c in node if isinstance(c, tuple)]
        return []

    def child(self, node, name):
        for idx, v in self.kids(node):
            if self.nm(idx) == name:
                return v
        return None

    def section(self, name):
        return self.child(self.tree, name)


def first_scalar(node):
    if not isinstance(node, list):
        return node
    for c in node:
        if not isinstance(c, tuple):
            return c
    return None


def own_value(node):
    """元素自身值; pxml 裸值(list 首位非 tuple)或 None"""
    return first_scalar(node) if isinstance(node, list) else node


def child_int(doc, node, name, default):
    v = doc.child(node, name)
    if v is None:
        return default
    v = own_value(v)
    return v if isinstance(v, int) else default


def child_bool(doc, node, name, default=False):
    v = doc.child(node, name)
    if v is None:
        return default
    v = own_value(v)
    return v is True


# ---------------------------------------------------------------- 别名
ALIAS_DOC = Doc(ED + '/alias.xml')
ALIASES = {}
for _idx, _v in ALIAS_DOC.kids(ALIAS_DOC.tree):
    ALIASES[ALIAS_DOC.nm(_idx)] = _v


# ---------------------------------------------------------------- 类型引擎
def type_info(doc, spec, trail=()):
    """→ (recipe: bytes, stream_size: int)。变长 → stream_size = -1(类型层)。"""
    if isinstance(spec, str):
        name, node = spec, None
    else:
        name = own_value(spec)
        if not isinstance(name, str):
            raise ValueError('类型名非字符串: %r (trail=%s)' % (name, trail))
        node = spec

    # 别名优先 (buildDataType: alias 查找先于 metatype); 仅别名名做环检测
    if node is None and name in ALIASES:
        if name in trail:
            raise ValueError('别名递归: %s' % ' -> '.join(trail + (name,)))
        return type_info(ALIAS_DOC, ALIASES[name], trail + (name,))

    up = name.upper()
    if up in SIMPLE:
        tag, sz = SIMPLE[up]
        md5 = b'N\0'  # placeholder
        buf = bytearray()
        buf += tag.encode('ascii') + (b'\x00' if V['tag_nul'] else b'')
        if sz is not None:
            if V['int_size_field'] == 1:
                buf += struct.pack('<B', sz)
            else:
                buf += struct.pack('<i', sz)
        return bytes(buf), SIMPLE_SZ.get(up, -1)

    if up in ('VECTOR2', 'VECTOR3', 'VECTOR4'):
        n = int(up[-1])
        return (b'Vector' + (b'\x00' if V['tag_nul'] else b'') + struct.pack('<i', n)), 4 * n

    if up in ('ARRAY', 'TUPLE'):
        if node is None:
            raise ValueError('%s 需要子元素 (of)' % up)
        size = child_int(doc, node, 'size', 0)
        pab = child_bool(doc, node, 'persistAsBlob', False)
        of = doc.child(node, 'of')
        if of is None:
            raise ValueError('%s 缺 <of>' % up)
        elem_rec, elem_sz = type_info(doc, of, trail)
        buf = bytearray(up.capitalize().encode('ascii') + (b'\x00' if V['tag_nul'] else b''))
        if V['seq_size']:
            buf += struct.pack('<i', size)
        if pab:
            buf += struct.pack('<i', 16777215)
        buf += elem_rec
        ss = size * elem_sz
        if ss <= 0:
            ss = -1
        return bytes(buf), ss

    if up in ('FIXED_DICT', 'FIXED_DICT_SIMPLE'):
        if node is None:
            raise ValueError('%s 需要 Properties' % up)
        props = doc.child(node, 'Properties')
        if props is None:
            raise ValueError('%s 缺 Properties' % up)
        ib = doc.child(node, 'implementedBy')
        allow_none = child_bool(doc, node, 'AllowNone', False)
        buf = bytearray(b'FixedDict' + (b'\x00' if V['tag_nul'] else b''))
        if ib is not None:
            s = own_value(ib)
            if isinstance(s, str) and '.' in s:
                mod, inst = s.split('.', 1)
                buf += mod.encode('utf-8')
                buf += inst.encode('utf-8')
        if V['allow_none']:
            buf += struct.pack('<B', 1 if allow_none else 0)
        total = 0
        for fidx, fnode in doc.kids(props):
            fname = doc.nm(fidx)
            ftype = doc.child(fnode, 'Type')
            if ftype is None:
                raise ValueError('FixedDict 字段 %s 缺 Type' % fname)
            frec, fsz = type_info(doc, ftype, trail)
            buf += fname.encode('utf-8')
            buf += frec
            if fsz == -1:
                total = -1
            elif total != -1:
                total += fsz
        return bytes(buf), total

    if up == 'CLASS':
        if node is None:
            raise ValueError('CLASS 需要 Properties')
        props = doc.child(node, 'Properties')
        allow_none = child_bool(doc, node, 'AllowNone', False)
        buf = bytearray(b'Class' + (b'\x00' if V['tag_nul'] else b'') + struct.pack('<B', 1 if allow_none else 0))
        if props is not None:
            for fidx, fnode in doc.kids(props):
                fname = doc.nm(fidx)
                ftype = doc.child(fnode, 'Type')
                frec, _ = type_info(doc, ftype, trail)
                buf += fname.encode('utf-8')
                buf += frec
        return bytes(buf), -1

    if up == 'USER_TYPE':
        if node is None:
            raise ValueError('USER_TYPE 需要 module/instance')
        mod = own_value(doc.child(node, 'module')) or ''
        inst = own_value(doc.child(node, 'instance')) or ''
        return (b'User' + (b'\x00' if V['tag_nul'] else b'') + mod.encode('utf-8') + inst.encode('utf-8')), -1

    raise ValueError('未知类型 %r (trail=%s)' % (name, trail))


_TYPE_CACHE = {}


def type_info_cached(doc, spec):
    key = (id(doc), id(spec))
    if key not in _TYPE_CACHE:
        _TYPE_CACHE[key] = type_info(doc, spec)
    return _TYPE_CACHE[key]


def is_variable(sz):
    return sz < 0


# ---------------------------------------------------------------- 属性解析
def parse_one_property(doc, pidx, pnode, source):
    name = doc.nm(pidx)
    flags = None
    efr = None          # None = 缺省
    tspec = None
    vlh = None
    persistent = False
    for cidx, cv in doc.kids(pnode):
        cn = doc.nm(cidx)
        if cn == 'Flags':
            fs = own_value(cv)
            if fs not in FLAG_MAP:
                raise ValueError('未知 Flags %r on %s.%s' % (fs, source, name))
            flags = FLAG_MAP[fs]
        elif cn == 'ExposedForReplay':
            efr = own_value(cv) is True
        elif cn == 'Persistent':
            persistent = own_value(cv) is True
        elif cn == 'Type':
            tspec = cv
        elif cn == 'VariableLengthHeaderSize':
            vlh = own_value(cv)
    if flags is None:
        raise ValueError('属性缺 Flags: %s.%s' % (source, name))
    if tspec is None:
        raise ValueError('属性缺 Type: %s.%s' % (source, name))
    if efr is None:
        efr = bool(flags & F_OTHER)
    if efr:
        flags |= F_REPLAY
    if persistent:
        flags |= 0x20                    # DATA_PERSISTENT (在 0x5F 掩码内, fork parse 354990 实证)
    return dict(name=name, flags=flags, tspec=tspec, doc=doc,
                vlh=vlh if isinstance(vlh, int) else None, source=source)


def parse_props_section(doc, sec, source):
    out = []
    if sec is None:
        return out
    for pidx, pnode in doc.kids(sec):
        out.append(parse_one_property(doc, pidx, pnode, source))
    return out


# ---------------------------------------------------------------- 方法解析
COMP_BITS = {'client': 0, 'cell': 1, 'base': 2}


def parse_methods_section(doc, sec_name, comp, source):
    sec = doc.section(sec_name)
    out = []
    if sec is None:
        return out
    for midx, mnode in doc.kids(sec):
        mname = doc.nm(midx)
        args = []
        exposed_bits = 0
        vlh = None
        for cidx, cv in doc.kids(mnode):
            cn = doc.nm(cidx)
            if cn == 'Arg':
                args.append(cv)
            elif cn == 'Exposed':
                v = own_value(cv)
                if v == '' or v is False or v is None:
                    exposed_bits = 0x0C
                elif v == 'OWN_CLIENT':
                    exposed_bits = 0x08
                elif v == 'ALL_CLIENTS':
                    if comp == 'cell':
                        exposed_bits = 0x04
                    else:
                        raise ValueError('BASE 方法不合法 Exposed=ALL_CLIENTS: %s.%s'
                                         % (source, mname))
                else:
                    raise ValueError('未知 Exposed %r: %s.%s' % (v, source, mname))
            elif cn == 'VariableLengthHeaderSize':
                v = own_value(cv)
                vlh = v if isinstance(v, int) else None
        if comp == 'client':
            flags = V['client_flags']         # 组件位0 + setExposedToAllClients
            if exposed_bits:
                raise ValueError('ClientMethods 不允许 Exposed: %s.%s' % (source, mname))
        else:
            flags = (COMP_BITS[comp] if V['comp_bits'] else 0) | exposed_bits
        out.append(dict(name=mname, flags=flags, args=args, vlh=vlh,
                        exposed=(comp == 'client') or bool(exposed_bits), doc=doc))
    return out


# ---------------------------------------------------------------- 累积
def accumulate(entity_name):
    """按引擎解析序累积属性与方法。返回 (props, methods{client,base,cell})"""
    doc = Doc.load(entity_name)
    props = []
    methods = {'client': [], 'base': [], 'cell': []}

    parent = doc.section('Parent')
    if parent is not None:
        pn = own_value(parent)
        if isinstance(pn, str) and pn:
            pp, pm = accumulate(pn)
            props += pp
            for k in methods:
                methods[k] += pm[k]

    impl = doc.section('Implements')
    if impl is not None:
        for _idx, iv in doc.kids(impl):
            iname = own_value(iv)
            if not (isinstance(iname, str) and iname):
                continue
            ip, im = accum_interface(iname)
            props += ip
            for k in methods:
                methods[k] += im[k]

    props += parse_props_section(doc, doc.section('Properties'), entity_name)
    methods['base'] += parse_methods_section(doc, 'BaseMethods', 'base', entity_name)
    methods['cell'] += parse_methods_section(doc, 'CellMethods', 'cell', entity_name)
    methods['client'] += parse_methods_section(doc, 'ClientMethods', 'client', entity_name)
    return props, methods


def accum_interface(iname):
    """接口: Implements 递归 → 自身 Properties → 自身方法(不跟随 Parent)"""
    doc = Doc.load(iname)
    props = []
    methods = {'client': [], 'base': [], 'cell': []}
    impl = doc.section('Implements')
    if impl is not None:
        for _idx, iv in doc.kids(impl):
            jn = own_value(iv)
            if isinstance(jn, str) and jn:
                jp, jm = accum_interface(jn)
                props += jp
                for k in methods:
                    methods[k] += jm[k]
    props += parse_props_section(doc, doc.section('Properties'), iname)
    methods['base'] += parse_methods_section(doc, 'BaseMethods', 'base', iname)
    methods['cell'] += parse_methods_section(doc, 'CellMethods', 'cell', iname)
    methods['client'] += parse_methods_section(doc, 'ClientMethods', 'client', iname)
    return props, methods


# ---------------------------------------------------------------- csi 分配
def finalize_entity(props):
    """同名覆盖(保留原位) + csi 稳定排序。返回 (final_list, cs_set, csi_map)"""
    final = []
    pos = {}
    for p in props:
        if p['name'] in pos:
            final[pos[p['name']]] = p
        else:
            pos[p['name']] = len(final)
            final.append(p)

    def is_cs(p):
        return bool(p['flags'] & (F_OTHER | F_OWN | F_REPLAY))

    # 首遇 CS 的槽位序(引擎 clientServerProperties_)
    cs_slots = []
    slot_of = {}      # final 位置 → 槽位下标
    for i, p in enumerate(final):
        pass
    # 按引擎算法: 覆盖时若旧属性有槽则保留
    occupied = {}
    for p in props:                    # 沿累积序重演槽位分配
        i = pos[p['name']]
        if is_cs(p):
            if i in occupied:
                pass                    # 保留旧槽
            else:
                occupied[i] = len(cs_slots)
                cs_slots.append(i)
        else:
            occupied.pop(i, None)       # 非 CS 覆盖: 不再占用(引擎中槽仍在, 但属性非 CS 不进 digest)

    def stream_size_of(p):
        rec, ss = type_info_cached(p['doc'], p['tspec'])
        if ss < 0:
            return -DEFAULT_VLH if p['vlh'] is None else -p['vlh']
        return ss

    def sort_key(i):
        ss = stream_size_of(final[i])
        if ss >= 0:
            return (0, ss, 0)
        return (1, -ss, 0)              # 变长: -size = vlh 字节数, 升序

    order = sorted(cs_slots, key=sort_key) if V['sort_csi'] else list(cs_slots)
    csi_map = {}
    for csi, i in enumerate(order):
        csi_map[i] = csi
    return final, is_cs, csi_map, stream_size_of


# ---------------------------------------------------------------- digest
def entity_list():
    doc = Doc(ED + '/../entities.xml') if False else Doc('/tmp/wot_scripts/scripts/entities.xml')
    ents = []
    sec = doc.section('ClientServerEntities')
    for idx, v in doc.kids(sec):
        ents.append(doc.nm(idx))
    return ents


def compute(verbose=True, dump_csi=None):
    md5 = MD5Acc()
    ents = entity_list()
    csi_tables = {}
    for ename in ents:
        props, methods = accumulate(ename)
        final, is_cs, csi_map, stream_size_of = finalize_entity(props)

        # 方法去重(先到先得)
        def dedup(mlist):
            seen = set()
            out = []
            for m in mlist:
                if m['name'] in seen:
                    continue
                seen.add(m['name'])
                out.append(m)
            return out

        mclient = dedup(methods['client'])
        mbase = [m for m in dedup(methods['base']) if (m['exposed'] or not V['exposed_only'])]
        mcell = [m for m in dedup(methods['cell']) if (m['exposed'] or not V['exposed_only'])]

        if verbose:
            ncs = sum(1 for p in final if is_cs(p))
            print('  %-32s 属性%3d(CS %2d) 方法 c/b/e:%3d/%3d/%3d'
                  % (ename, len(final), ncs, len(mclient), len(mbase), len(mcell)),
                  file=sys.stderr)

        if dump_csi and ename in dump_csi:
            rows = []
            for i, p in enumerate(final):
                if is_cs(p):
                    rows.append((csi_map[i], p['name'], stream_size_of(p), p['source']))
            rows.sort()
            csi_tables[ename] = rows

        md5.raw(ename + ('\x00' if V['name_nul'] else ''))

        for i, p in enumerate(final):
            if V['cs_only'] and not is_cs(p):
                continue
            md5.i32(csi_map[i])
            rec, ss = type_info_cached(p['doc'], p['tspec'])
            if ss < 0 and p['vlh'] is not None and p['vlh'] != V['vlh_default']:
                md5.u32(p['vlh'])
            md5.raw(p['name'] + ('\x00' if V['name_nul'] else ''))
            md5.i32(p['flags'] & V['flags_mask'])
            md5.buf += rec

        for mlist in (mclient, mbase, mcell):
            count = 0
            for m in mlist:
                # VLH 分支: 仅 client 方法(isForClient), 参数变长, vlh != 1
                if mlist is mclient and m['vlh'] is not None and m['vlh'] != DEFAULT_VLH:
                    args_var = False
                    for a in m['args']:
                        _, ass = type_info_cached(m['doc'], a)
                        if ass < 0:
                            args_var = True
                            break
                    if args_var:
                        if V['vlh_size'] == 2:
                            md5.buf += struct.pack('<H', m['vlh'])
                        else:
                            md5.u32(m['vlh'])
                md5.raw(m['name'] + ('\x00' if V['name_nul'] else ''))
                md5.u8(m['flags'])
                for a in m['args']:
                    arec, _ = type_info_cached(m['doc'], a)
                    md5.buf += arec
                if V['count']:
                    md5.i32(count)
                count += 1

    return md5.hexdigest(), csi_tables


if __name__ == '__main__':
    want = [a for a in sys.argv[1:]]
    dump = [w for w in want if w != '--quiet'] or None
    verbose = '--quiet' not in want
    dg, tables = compute(verbose=verbose, dump_csi=dump)
    print()
    print('EntityDescriptionMap::digest =', dg)
    print('目标                        =', TARGET)
    print('匹配' if dg == TARGET else '不匹配')
    for ename, rows in tables.items():
        if not rows:
            continue
        print()
        print('=== %s CS 属性 csi 表 (csi, 名字, streamSize, 来源) ===' % ename)
        for csi, name, ss, src in rows:
            print('  %3d  %-34s %4d  %s' % (csi, name, ss, src))
