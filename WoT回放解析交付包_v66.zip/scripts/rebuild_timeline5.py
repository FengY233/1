# -*- coding: utf-8 -*-
"""时间轴重建 v5(最终): 顺序匹配炮弹锚点 + 分段 tick 核算, 精确定位缺口"""
import sys, json, struct, statistics
sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile
from collections import defaultdict

BATTLE_START_BT = 139.769

sess_shots = []   # (bt, shooterID)
own_pts = []
for line in open('/home/z/my-project/upload/session_20260911_175934.jsonl', encoding='utf-8'):
    o = json.loads(line)
    if o['ev'] == 'arena.onVehicleShot':
        sess_shots.append((o['data']['bt'] - BATTLE_START_BT, o['data']['args'][0]))
    elif o['ev'] == 'battle_tick':
        d = o['data']
        if d.get('own'):
            own_pts.append((d['bt'] - BATTLE_START_BT, *d['own']['position']))
sess_shots.sort()

rf = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
pkts = rf.pkts
p3_pkt = next(p[3] for p in pkts if p[0] == 0x16 and p[2] == b'\x03\x00\x00\x00')
p4_pkt = next(p[3] for p in pkts if p[0] == 0x16 and p[2] == b'\x04\x00\x00\x00')

# 车辆 0xA 位置(供射手识别)
veh_pos = defaultdict(list)
for ty, clock, payload, idx in pkts:
    if ty != 0xA or not (p3_pkt <= idx <= p4_pkt) or len(payload) < 45:
        continue
    eid, _ = struct.unpack_from('<II', payload, 0)
    if 546611000 <= eid < 546612000:
        x, y, z = struct.unpack_from('<3f', payload, 8)
        veh_pos[eid].append((idx, x, y, z))

# 炮弹实体创建
shell_creates = []
for ty, clock, payload, idx in pkts:
    if ty != 0x5 or len(payload) < 46 or not (p3_pkt <= idx <= p4_pkt):
        continue
    eid, tidx = struct.unpack_from('<II', payload, 0)
    if 546611000 <= eid < 546612000:
        continue
    x, y, z = struct.unpack_from('<3f', payload, 8)
    # 射手识别: 创建前±范围内最近车辆
    best = None; bd = 1e18
    for veid, pts in veh_pos.items():
        for pidx, vx, vy, vz in pts:
            if idx-800 <= pidx <= idx+50:
                d2 = (vx-x)**2 + (vy-y)**2 + (vz-z)**2
                if d2 < bd:
                    bd = d2; best = veid
    if best is not None and bd <= 400:
        shell_creates.append((idx, clock, eid, best))
shell_creates.sort()
print(f'战斗窗口炮弹实体(含射手): {len(shell_creates)}')

# 顺序匹配: 每个射手的炮弹流序 <-> 该射手会话射击序
shots_by = defaultdict(list)
for bt, sh in sess_shots:
    shots_by[sh].append(bt)
shell_by = defaultdict(list)
for idx, clock, eid, sh in shell_creates:
    shell_by[sh].append((idx, clock, eid))

shell_anchors = []
for sh, shells in shell_by.items():
    sshots = shots_by.get(sh, [])
    n = min(len(shells), len(sshots))
    for k in range(n):
        idx, clock, eid = shells[k]
        shell_anchors.append((idx, clock, sshots[k], f'shell{k}:{sh}'))
print(f'顺序匹配炮弹锚点: {len(shell_anchors)} (覆盖射手 {len(shell_by)} 个)')

# 玩家轨迹锚点
rep_own = []
for ty, clock, payload, idx in pkts:
    if ty != 0xA or not (p3_pkt <= idx <= p4_pkt) or len(payload) < 45:
        continue
    eid, _ = struct.unpack_from('<II', payload, 0)
    if eid == 546611525:
        x, y, z = struct.unpack_from('<3f', payload, 8)
        rep_own.append((idx, clock, x, y, z))
own_anchors = []
for idx, clock, x, y, z in rep_own:
    cands = [bt for bt, sx, sy, sz in own_pts if abs(sx-x) <= 2.0 and abs(sz-z) <= 2.0]
    if cands and max(cands) - min(cands) <= 8.0:
        own_anchors.append((idx, clock, sum(cands)/len(cands), 'own'))

# 合并 + 相位边界锚点
anchors = own_anchors + shell_anchors
anchors.append((p3_pkt, pkts[p3_pkt][1] if False else 0, 0.0, 'phase3'))
anchors.sort()
# 检查单调性
viol = 0
for a, b in zip(anchors, anchors[1:]):
    if b[2] < a[2] - 1.0:
        viol += 1
print(f'锚点总数: {len(anchors)}, 单调性违例(回退>1s): {viol}')

# ---------- 聚类成段并核算 tick ----------
ticks_wc = [p[3] for p in pkts if p[0] == 0x36 and p3_pkt <= p[3] <= p4_pkt]
tickset = ticks_wc

# 把锚点按流位置聚成簇(簇内 true 跨度<5s)
clusters = []
cur = [anchors[0]]
for a in anchors[1:]:
    if a[0] - cur[-1][0] <= 1500 and abs(a[2] - cur[-1][2]) <= 6.0:
        cur.append(a)
    else:
        clusters.append(cur); cur = [a]
clusters.append(cur)
print(f'\n锚点簇: {len(clusters)} 个')

print('\n=== 段间 tick 核算 ===')
total_def = 0
for i in range(len(clusters)-1):
    c1, c2 = clusters[i], clusters[i+1]
    p1 = statistics.median(a[0] for a in c1); t1 = statistics.median(a[2] for a in c1)
    p2 = statistics.median(a[0] for a in c2); t2 = statistics.median(a[2] for a in c2)
    n = sum(1 for t in tickset if p1 <= t <= p2)
    exp = (t2 - t1) * 10
    d = exp - n
    if abs(d) > 15:
        print(f'  段{i}→{i+1}: pkt[{p1:.0f}→{p2:.0f}] true {t1:6.1f}→{t2:6.1f}s | tick={n:>4} 期望={exp:6.1f} 差={d:+7.1f} {"<<< 缺" if d>15 else "<<< 多(锚点误差)"}')
    total_def += max(0, d)
print(f'\n正向缺口累计: {total_def:.0f} ticks = {total_def/10:.1f}s')

json.dump({'anchors': [(a[0], a[1], round(a[2], 2), a[3]) for a in anchors]},
          open('/home/z/my-project/scripts/timeline_v5_anchors.json', 'w'))
print('锚点已保存 timeline_v5_anchors.json')
