# -*- coding: utf-8 -*-
"""speed_profile.py — 用锚点(击杀+阶段)插值 + 0x1A逐包瞬时速度, 重建完整变速画像
并检验: 游戏时间单调性(回跳?), 速度阶梯, 各速度段覆盖的游戏秒
"""
import io
import json
import struct
import sys
from collections import Counter

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

Q20 = 1048576.0
TICK = 104857.6  # 0.1s 在 Q20 下的单位数

R = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
pkts = R.pkts
raw = json.load(open('/home/z/my-project/scripts/align_v2_raw.json'))
p2c, p3c, p4c = raw['period_clocks']['p2'], raw['period_clocks']['p3'], raw['period_clocks']['p4']
nbt = raw['new_periods_bt']  # 新jsonl(回放播放)的bt: p1=17.115 p2=27.168 p3=57.172 p4=669.447

# ---- 锚点表 (clock, bt) ----
anchors = [(p3c, nbt['3']), (p4c, nbt['4'])]
for a in raw['anchors_raw']:
    anchors.append((a['clock'], nbt['3'] + a['bt_rel']))
anchors.append((p2c, nbt['2']))
anchors.sort()
print('锚点数: %d (p2/p3/p4 + 25击杀)' % len(anchors))
print('单调性检查: clock 递增=%s, bt 递增=%s' % (
    all(anchors[i][0] < anchors[i + 1][0] for i in range(len(anchors) - 1)),
    all(anchors[i][1] < anchors[i + 1][1] for i in range(len(anchors) - 1))))


def clock_to_bt(c):
    """分段线性: clock → bt (新jsonl竞技场时钟)"""
    for i in range(len(anchors) - 1):
        c0, b0 = anchors[i]
        c1, b1 = anchors[i + 1]
        if c0 <= c <= c1:
            if c1 == c0:
                return b0
            return b0 + (b1 - b0) * (c - c0) / (c1 - c0)
    return anchors[-1][1] if c > anchors[-1][0] else anchors[0][1]


# ---- 0x1A 逐包瞬时速度 ----
a1a = [p for p in pkts if p[0] == 0x1A and p[1] > 0]
prof = []  # (clock, bt, speed)
for i in range(1, len(a1a)):
    d = a1a[i][1] - a1a[i - 1][1]
    if d <= 0 or d > 5 * Q20:
        continue
    sp = TICK / d  # 瞬时倍速
    prof.append((a1a[i][1], clock_to_bt(a1a[i][1]), sp))
print('0x1A 瞬时速度样本: %d' % len(prof))

# ---- 战斗窗内: 按10游戏秒分箱取速度众数 ----
print('\n==== 战斗速度画像 (10游戏秒bin, 众数速度) ====')
battle = [(c, b, s) for c, b, s in prof if nbt['3'] <= b <= nbt['4']]
bins = {}
for c, b, s in battle:
    bins.setdefault(int((b - nbt['3']) // 10) * 10, []).append(s)
prev_sp = None
segs = []
for k in sorted(bins):
    mode = Counter(round(s * 2) / 2 for s in bins[k]).most_common(1)[0][0]
    n = len(bins[k])
    if prev_sp != mode:
        segs.append([k, k + 10, mode])
        prev_sp = mode
    else:
        segs[-1][1] = k + 10
for s0, s1, sp in segs:
    print('  游戏t %3d-%3d s: %5.1fx  (%d包)' % (s0, s1, sp, sum(len(bins[k]) for k in bins if s0 <= k < s1)))

# ---- 战前(倒计时+等待)速度 ----
print('\n==== 战前速度 (0x1A 在 p2 之前/p2→p3) ====')
pre = [(c, b, s) for c, b, s in prof if b < nbt['3']]
print('战前 0x1A 包数: %d' % len(pre))
preb = {}
for c, b, s in pre:
    key = '等待期(bt<%.1f)' % nbt['2'] if b < nbt['2'] else '倒计时'
    preb.setdefault(key, Counter()).update([round(s * 4) / 4])
for k, cnt in preb.items():
    print('  %s: %s' % (k, cnt.most_common(6)))

# ---- 倒计时阶段精确速度(锚点法) ----
cd_game = nbt['3'] - nbt['2']
cd_clk = (p3c - p2c) / Q20
print('\n倒计时锚点法: %.3f游戏s / %.3fclock s = %.3fx' % (cd_game, cd_clk, cd_game / cd_clk))
b_game = nbt['4'] - nbt['3']
b_clk = (p4c - p3c) / Q20
print('战斗锚点法: %.3f游戏s / %.3fclock s = %.3fx 平均' % (b_game, b_clk, b_game / b_clk))

# ---- 全程时间预算法 ----
first_nz = min(p[1] for p in pkts if p[1] > 0)
last_clk = max(p[1] for p in pkts if p[1] < 4_000_000_000)
print('\n录制会话时间轴 (Q20):')
print('  非零流起点: %.2f s (观看开始, 含加载同步的1146个clock=0包在此之前)' % (first_nz / Q20))
print('  p2(倒计时): %.2f s' % (p2c / Q20))
print('  p3(战斗开始): %.2f s' % (p3c / Q20))
print('  p4(战斗结束): %.2f s' % (p4c / Q20))
print('  流结束: %.2f s' % (last_clk / Q20))
print('  → 客户端开机后闲置 %.0f 秒(~%.1f分钟)才开始观看' % (first_nz / Q20, first_nz / Q20 / 60))

# ---- 保存画像 ----
out = {
    'unit': 'Q20 = 1/2^20 s (1.048576 MHz), 实证: 0.1s tick = 104857.6 单位',
    'anchors': [{'clock': c, 'bt': b} for c, b in anchors],
    'segments': [{'game_t0': s0, 'game_t1': s1, 'speed': sp} for s0, s1, sp in segs],
    'battle_avg': b_game / b_clk,
    'battle_game_s': b_game, 'battle_clock_s': b_clk,
    'pre_battle': {'first_nonzero_clock_s': first_nz / Q20, 'p2': p2c / Q20, 'p3': p3c / Q20},
    'instant': [(c / Q20, b, s) for c, b, s in prof],
}
json.dump(out, open('/home/z/my-project/scripts/speed_profile.json', 'w'), ensure_ascii=False)
print('\n画像已存 scripts/speed_profile.json')
