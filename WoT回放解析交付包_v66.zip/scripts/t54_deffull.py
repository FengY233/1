#!/usr/bin/env python3
"""t54_deffull.py — Task 54-①: component_defs 128 def 全保真重提 (修复 t49 方法漏收)
每 def: props(name/type/flags/allowNone) + 方法段全名(Cell/Client/BaseMethods, 含重载) + attrs.
np_ 推导: tid 侧 nv-1-方法数; def 侧 len(props); OwnVehicle 23=23 锚定.
产出: /tmp/wot/t54_deffull.json
"""
import sys, json, glob
sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file

CD = '/tmp/wot/wot_scripts/component_defs'


def sec_text(s):
    if s.type == 1:
        return s.asString()
    if s.children:
        return None
    if s.type == 0 and not s.data:
        return None
    if s.type == 2:
        return str(s.asInt())
    if s.type == 4:
        return 'true' if s.asBool() else 'false'
    return s.data.hex()


def type_name(ty):
    """Type 节点 → 类型名 (标量=字符串; 复合=内层名+参数)"""
    if ty.type == 1:
        return ty.asString()
    if ty.children:
        inner = ty.children[0]
        nm = inner.asString() if inner.type == 1 else inner.name
        return nm
    return ty.data.hex()


def parse_def(path):
    r = decode_file(path)
    out = {'props': [], 'methods': {}, 'attrs': {}}
    for node in r.children:
        if node.name == 'Properties':
            for p in node.children:
                pr = {'name': p.name}
                for c in p.children:
                    if c.name == 'Type':
                        pr['type'] = type_name(c)
                    elif c.name in ('Flags', 'flags'):
                        pr['flags'] = sec_text(c)
                    elif c.name in ('AllowNone', 'allowNone'):
                        pr['allowNone'] = sec_text(c)
                out['props'].append(pr)
        elif node.name in ('CellMethods', 'ClientMethods', 'BaseMethods'):
            lst = []
            for m in node.children:
                mm = {'name': m.name}
                for c in m.children:
                    if c.name == 'Flags':
                        mm['flags'] = sec_text(c)
                lst.append(mm)
            out['methods'][node.name] = lst
        elif node.name in ('DetailLevel', 'DefaultKeyName', 'Implementation', 'Volatile', 'storable'):
            out['attrs'][node.name] = sec_text(node)
    return out


def main():
    table = {}
    for path in sorted(glob.glob(f'{CD}/*.def')):
        name = path.split('/')[-1].replace('.def', '')
        try:
            table[name] = parse_def(path)
        except Exception as ex:
            table[name] = {'error': str(ex)}
    json.dump(table, open('/tmp/wot/t54_deffull.json', 'w'), ensure_ascii=False, indent=1)
    # 摘要
    nprops = {}
    nuniq = {}
    for name, d in table.items():
        if 'error' in d:
            continue
        nprops[name] = len(d['props'])
        allm = []
        for sec, lst in d['methods'].items():
            allm += [m['name'] for m in lst]
        nuniq[name] = len(set(allm))
    print(f'def 总数: {len(table)} (错误 {sum(1 for d in table.values() if "error" in d)})')
    print(f'属性数分布: 0:{sum(1 for v in nprops.values() if v==0)} 1:{sum(1 for v in nprops.values() if v==1)} 2:{sum(1 for v in nprops.values() if v==2)} 3+:{sum(1 for v in nprops.values() if v>=3)}')
    # OwnVehicle 锚定复核
    ov = table.get('OwnVehicle', {})
    print(f'OwnVehicle: props={len(ov.get("props", []))} (期望网络 np_=23)')
    allm = [m['name'] for lst in ov.get('methods', {}).values() for m in lst]
    print(f'  方法声明 {len(allm)} 个, 去重 {len(set(allm))} 个 (期望网络 11): {allm}')
    # 名单方法最多的 def
    top = sorted(nuniq.items(), key=lambda kv: -kv[1])[:8]
    print('方法数 top8:', top)


if __name__ == '__main__':
    main()
