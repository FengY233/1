# -*- coding: utf-8 -*-
"""analyze_replay_jsonl4.py — 握手期一次性大包解剖(0x11/0x0F/0x15/0x2D/0x22/0x2B/0x2E) +
   0x26 语义判定 + 0x1A 相机几何验证。
"""
import json
import struct
import sys
import collections

sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

REPLAY = '/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay'

rf = ReplayFile(REPLAY)

def f32(u):
    return struct.unpack('<f', struct.pack('<I', u))[0]

def f32b(b):
    return struct.unpack('<f', b)[0]

# ---------- 1) 一次性包全景 ----------
print('== 握手期/一次性包全景 ==')
oneoff = {0x18: None, 0x2D: None, 0x30: None, 0x3D: None, 0x12: None, 0x00: None,
          0x01: None, 0x02: None, 0x0F: None, 0x11: None, 0x22: None, 0x15: None,
          0x2B: None, 0x2E: None, 0x06: None, 0x16: None, 0x17: None, 0x1E: None}
for ty, clock, payload, idx in rf.pkts:
    if ty in oneoff and oneoff[ty] is None:
        oneoff[ty] = payload
for ty in sorted(oneoff):
    p = oneoff[ty]
    if p is None:
        print(f'0x{ty:02X}: (多包类型)')
        continue
    print(f'0x{ty:02X}: {len(p)}B  head: {p[:64].hex()}')
print()

# 0x0F 全量
p = oneoff[0x0F]
print('== 0x0F 地图包 (92B) 全解码 ==')
print('hex:', p.hex())
# ref (u32) + [len u8][str] + 4x4 matrix?
q = 0
ref, = struct.unpack_from('<I', p, q); q += 4
print(f'ref={ref}')
slen = p[q]; q += 1
s = p[q:q+slen]; q += slen
print(f'str[{slen}]={s!r}')
rest = p[q:]
print(f'剩余 {len(rest)}B: {rest.hex()}')
# 按 f32 解
n = len(rest) // 4
vals = [f32b(rest[i*4:i*4+4]) for i in range(n)]
print(f'f32×{n}: {["%.4f" % v for v in vals]}')
# 按 u32 解
uvals = struct.unpack(f'<{n}I', rest[:n*4])
print(f'u32×{n}: {[hex(v) for v in uvals]}')

# 0x2D 内容
p = oneoff[0x2D]
print()
print('== 0x2D (15B) ==')
print('hex:', p.hex())
ln, = struct.unpack_from('<I', p, 0)
print(f'u32 len={ln}, str={p[4:4+ln]!r}, 尾={p[4+ln:].hex()}')

# 0x15 8B
p = oneoff[0x15]
print()
print('== 0x15 (8B) ==')
print('hex:', p.hex(), ' f64=', struct.unpack('<d', p)[0], ' 2×f32=', f32b(p[:4]), f32b(p[4:]), ' 2×u32=', struct.unpack('<II', p))

# 0x22 4B / 0x2B 4B / 0x2E / 0x12
for ty in (0x22, 0x2B, 0x2E, 0x12):
    p = oneoff[ty]
    print(f'0x{ty:02X} ({len(p)}B): {p.hex()}  u32={struct.unpack("<I", p)[0] if len(p)==4 else ""}')

# 0x11 6699B 结构探查
p = oneoff[0x11]
print()
print('== 0x11 (6699B) 大包探查 ==')
print('head 128B:', p[:128].hex())
# ASCII 渗透
import re
strs = re.findall(rb'[\x20-\x7e]{6,}', p)
print(f'ASCII串 {len(strs)} 个, 前 30:')
for s in strs[:30]:
    print('   ', s[:90])
# 尾部
print('tail 64B:', p[-64:].hex())

# 0x00 avatar create 前 64B
p = oneoff[0x00]
print()
print('== 0x00 Avatar创建 (1330B) ==')
print('head 96B:', p[:96].hex())
strs = re.findall(rb'[\x20-\x7e]{6,}', p)
print('ASCII串前 12:', [s[:40] for s in strs[:12]])
