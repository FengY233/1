# -*- coding: utf-8 -*-
"""analyze_replay_jsonl7.py — 0x26 抛物线弹道检验 + 0x11 内容解剖 + 0x05 结构验证。
"""
import json
import struct
import sys
import zlib
import re
import collections
import statistics

sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

REPLAY = '/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay'
JSONL = '/home/z/my-project/upload/replay.jsonl'

rf = ReplayFile(REPLAY)
lines = []
with open(JSONL) as f:
    for line in f:
        if line.strip():
            lines.append(json.loads(line))

def f32(u):
    return struct.unpack('<f', struct.pack('<I', u))[0]

# ---------- 1) 0x26 抛物线检验 ----------
print('== 0x26 弹道检验: 短簇内速度/加速度 ==')
seq = []
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    if ty == 0x26 and 'pos' in d:
        seq.append((f32(clock), d['pos'], d.get('quat')))
# 按簇切
clusters = []
cur = [seq[0]]
for s in seq[1:]:
    if s[0] - cur[-1][0] > 1.0:
        clusters.append(cur)
        cur = [s]
    else:
        cur.append(s)
clusters.append(cur)
print(f'簇数 {len(clusters)}')

def analyze_traj(traj, name):
    if len(traj) < 5:
        return
    # 速度
    vs = []
    for a, b in zip(traj, traj[1:]):
        dt = b[0] - a[0]
        if dt > 0:
            vx = (b[1][0] - a[1][0]) / dt
            vy = (b[1][1] - a[1][1]) / dt
            vz = (b[1][2] - a[1][2]) / dt
            vs.append((a[0], vx, vy, vz))
    if not vs:
        return
    # 垂直加速度
    ays = []
    for a, b in zip(vs, vs[1:]):
        dt = b[0] - a[0]
        if dt > 0:
            ays.append((b[2] - a[2]) / dt)
    speeds = [(vx*vx+vy*vy+vz*vz)**0.5 for _, vx, vy, vz in vs]
    y0, y1 = traj[0][1][1], traj[-1][1][1]
    span = traj[-1][0] - traj[0][0]
    print(f'{name}: 时长{span:.1f}s n={len(traj)} y:{y0:.1f}→{y1:.1f} 峰值{max(p[1][1] for p in traj):.1f} '
          f'速度中位{statistics.median(speeds):.1f}m/s 垂直加速度中位{statistics.median(ays) if ays else 0:.1f}m/s²')

for i, c in enumerate(clusters):
    if len(c) >= 5:
        analyze_traj(c, f'簇{i} [{c[0][0]:.1f}s]')

# 全体: 垂直加速度分布 (同簇相邻)
print()
allspeeds = []
allay = []
for c in clusters:
    for a, b in zip(c, c[1:]):
        dt = b[0] - a[0]
        if dt > 0.01:
            vx = (b[1][0]-a[1][0])/dt; vy = (b[1][1]-a[1][1])/dt; vz = (b[1][2]-a[1][2])/dt
            allspeeds.append((vx*vx+vy*vy+vz*vz)**0.5)
            allay.append(('v', vy))
# 相邻速度差 -> 加速度
accs = []
for c in clusters:
    prev = None
    for a, b in zip(c, c[1:]):
        dt = b[0] - a[0]
        if dt > 0.01:
            vy = (b[1][1]-a[1][1])/dt
            if prev is not None:
                dt2 = b[0] - prev[0]
                if dt2 > 0:
                    accs.append((vy - prev[1]) / dt2)
            prev = (a[0], vy)
print(f'全部 0x26 相邻包速度: 中位 {statistics.median(allspeeds):.1f} m/s  P10 {sorted(allspeeds)[len(allspeeds)//10]:.1f}  P90 {sorted(allspeeds)[len(allspeeds)*9//10]:.1f}')
print(f'垂直加速度: 中位 {statistics.median(accs):.2f} m/s²  P10 {sorted(accs)[len(accs)//10]:.2f}  P90 {sorted(accs)[len(accs)*9//10]:.2f}  (炮弹应≈-9.8)')

# ---------- 2) 0x11 解压内容解剖 ----------
print()
print('== 0x11 外层解压 6,666B 解剖 ==')
p11 = None
for ty, clock, payload, idx in rf.pkts:
    if ty == 0x11:
        p11 = payload
        break
outer = zlib.decompress(p11[22:])
print('head 96B:', outer[:96].hex())
strs = re.findall(rb'[\x20-\x7e]{6,}', outer)
print(f'ASCII 串 {len(strs)} 个, 前 25:')
for s in strs[:25]:
    print('   ', s[:90])
# 内嵌 zlib 位置 (在解压后数据里)
zoffs = []
for i in range(len(outer) - 1):
    if outer[i] == 0x78:
        v = outer[i] * 256 + outer[i + 1]
        if v % 31 == 0 and (outer[i + 1] & 0x20) == 0:
            try:
                d = zlib.decompressobj()
                dec = d.decompress(outer[i:])
                zoffs.append((i, len(dec), len(outer[i:]) - len(d.unused_data)))
            except Exception:
                pass
print('内嵌 zlib 段 (offset, 解压长, 压缩长):', zoffs)

# ---------- 3) 0x05 结构验证 ----------
print()
print('== 0x05 结构验证 ==')
shown = 0
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    if ty == 0x05 and shown < 5:
        shown += 1
        eid, n = struct.unpack_from('<II', payload, 0)
        u16a, u16b = struct.unpack_from('<HH', payload, 8)
        print(f'#{idx} len={len(payload)}B eid={eid} n={n} u16@8=({u16a},{u16b}) hex[12:32]={payload[12:32].hex()}')
        # 找 00005a42 类 f32 模式: 直接试 pos @ offset p
        for off in (12, 16, 20, 24, 28):
            if off + 12 <= len(payload):
                x, y, z = struct.unpack_from('<fff', payload, off)
                if abs(x) < 600 and abs(z) < 600 and -50 < y < 120:
                    print(f'    可能pos @{off}: ({x:.2f}, {y:.2f}, {z:.2f})')
                    break
