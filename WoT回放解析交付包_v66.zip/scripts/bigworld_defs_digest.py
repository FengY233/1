#!/usr/bin/env python3
"""bigworld_defs_digest.py — BigWorld EntityDescriptionMap::digest() 的 Python 复刻 (v2)
来源: BigWorld-Engine-14.4.1 源码逐函数翻译; 语法对齐引擎自带 demo entity_defs
用法: python3 bigworld_defs_digest.py <entity_defs目录> [entities.xml]

字节配方摘要 (详见各函数注释):
  for 每个实体(entities.xml ClientServerEntities 顺序, 仅 client 类型):
    MD5 += entity.name (原始字节)
    for 每个属性(声明顺序, 仅 isClientServerData=OTHER_CLIENT|OWN_CLIENT|REPLAY):
      += int32 clientServerFullIndex (从0顺序编号)
      += [若变长类型且 varLenHeaderSize!=2: uint32 varLenHeaderSize]  # 默认不触发
      += name (原始字节)
      += int32 (dataFlags & 0x5F)   # DATA_DISTRIBUTION_FLAGS, 注意 REPLAY(0x100)被掩掉
      += DataType 配方
    for client 全部方法 / base+cell 的 Exposed 方法 (各自 count 从0):
      += [varLen 条件同上] + name
      += uint8 flags_               # 方法标志位(Exposed 等)
      += 每个参数的 DataType 配方
      += int32 count (legacyExposedIndex)

Flags 命名表 (data_description.cpp s_entityDataFlagMappings):
  CELL_PRIVATE=0  CELL_PUBLIC=0x01  OTHER_CLIENTS=0x03  OWN_CLIENT=0x04
  BASE=0x08  BASE_AND_CLIENT=0x0C  CELL_PUBLIC_AND_OWN=0x05  ALL_CLIENTS=0x07
  EDITOR_ONLY=0x40
  亦可叠加 <Persistent>/<Identifier>/<REPLAY> 等布尔标记 (Persistent=0x20, Identifier=0x80, REPLAY=0x100)
"""
import hashlib
import os
import struct
import sys
import xml.etree.ElementTree as ET

DATA_GHOSTED = 0x01
DATA_OTHER_CLIENT = 0x02
DATA_OWN_CLIENT = 0x04
DATA_BASE = 0x08
DATA_CLIENT_ONLY = 0x10
DATA_PERSISTENT = 0x20
DATA_EDITOR_ONLY = 0x40
DATA_ID = 0x80
DATA_REPLAY = 0x100
DATA_DISTRIBUTION_FLAGS = (DATA_GHOSTED | DATA_OTHER_CLIENT | DATA_OWN_CLIENT |
                           DATA_BASE | DATA_CLIENT_ONLY | DATA_EDITOR_ONLY)  # 0x5F

FLAG_NAMES = {
    'CELL_PRIVATE': 0, 'CELL_PUBLIC': DATA_GHOSTED,
    'OTHER_CLIENTS': DATA_GHOSTED | DATA_OTHER_CLIENT,
    'OWN_CLIENT': DATA_OWN_CLIENT, 'BASE': DATA_BASE,
    'BASE_AND_CLIENT': DATA_OWN_CLIENT | DATA_BASE,
    'CELL_PUBLIC_AND_OWN': DATA_GHOSTED | DATA_OWN_CLIENT,
    'ALL_CLIENTS': DATA_GHOSTED | DATA_OTHER_CLIENT | DATA_OWN_CLIENT,
    'EDITOR_ONLY': DATA_EDITOR_ONLY,
}

SIMPLE_TYPES = {
    'INT8': ('Int', 1), 'INT16': ('Int', 2), 'INT32': ('Int', 4), 'INT64': ('Int', 8),
    'UINT8': ('Uint', 1), 'UINT16': ('Uint', 2), 'UINT32': ('Uint', 4), 'UINT64': ('Uint', 8),
    'FLOAT32': ('Float', None), 'FLOAT64': ('Float64', None),
    'STRING': ('String', None), 'UNICODE_STRING': ('UnicodeString', None),
    'BLOB': ('Blob', None), 'MAILBOX': ('MailBox', None), 'PYTHON': ('Python', None),
    'UDO_REF': ('UserDataObjectLinkDataType', None),
}

VARLEN_TYPES = {'STRING', 'BLOB', 'ARRAY', 'TUPLE', 'FIXED_DICT', 'PYTHON',
                'CLASS', 'UNICODE_STRING', 'USER_TYPE', 'MAILBOX'}


class MD5Acc:
    def __init__(self):
        self.buf = bytearray()

    def raw(self, s_or_b):
        if isinstance(s_or_b, str):
            s_or_b = s_or_b.encode('utf-8')
        self.buf += s_or_b

    def i32(self, v):
        self.buf += struct.pack('<i', v)

    def u32(self, v):
        self.buf += struct.pack('<I', v)

    def u8(self, v):
        self.buf += struct.pack('<B', v)

    def tag(self, t):
        self.raw(t.encode('ascii') + b'\x00')   # sizeof("X") 含 NUL

    def hexdigest(self):
        return hashlib.md5(bytes(self.buf)).hexdigest()


def _type_of_element(elem):
    """从属性/参数 XML 节点取出类型节点: <Type>子节点 或 直接文本"""
    for ch in elem:
        if ch.tag == 'Type':
            return ch
    t = (elem.text or '').strip()
    return t if t else None


def data_type_md5(md5, t):
    """DataType::addToMD5 — t 为类型名字符串或 <Type> 元素(含复杂类型子树)"""
    if t is None:
        raise ValueError('空类型')
    if isinstance(t, str):
        name, attrs, children = t.strip(), {}, []
    else:
        name = (t.text or '').strip()
        # <Type> Tuple size=..><UINT32/></Type> → 元素属性在 Type 上, 子元素为元素类型
        attrs, children = t.attrib, list(t)

    up = name.upper()
    if up in SIMPLE_TYPES:
        tag, size = SIMPLE_TYPES[up]
        md5.tag(tag)
        if size is not None:
            md5.i32(size)
        return
    if up in ('VECTOR2', 'VECTOR3', 'VECTOR4'):
        md5.tag('Vector')
        md5.i32(int(up[-1]))
        return
    if up in ('TUPLE', 'ARRAY'):
        md5.tag(up.capitalize())            # "Tuple" / "Array"
        md5.i32(int(attrs.get('size', '0')))         # int32 size_
        db_len = int(attrs.get('db_len', '0'))       # dbLen_ > 0 才追加
        if db_len > 0:
            md5.i32(db_len)
        if not children:
            raise ValueError(f'{up} 缺元素类型')
        data_type_md5(md5, children[0])
        return
    if up == 'FIXED_DICT':
        md5.tag('FixedDict')
        # 自定义类实现: <Type module=... instance=...> (有 hasCustomClass 才追加)
        if 'module' in attrs or 'instance' in attrs:
            md5.raw(attrs.get('module', ''))
            md5.raw(attrs.get('instance', ''))
        md5.u8(1 if attrs.get('allowNone', 'false').lower() == 'true' else 0)
        for field in children:              # <字段名><Type>..</Type></字段名>
            md5.raw(field.tag)
            data_type_md5(md5, _type_of_element(field))
        return
    if up == 'CLASS':
        md5.tag('Class')
        md5.u8(1 if attrs.get('allowNone', 'false').lower() == 'true' else 0)
        for field in children:
            md5.raw(field.tag)
            data_type_md5(md5, _type_of_element(field))
        return
    if up == 'USER_TYPE':
        md5.tag('User')
        md5.raw(attrs.get('module', ''))
        md5.raw(attrs.get('instance', ''))
        return
    raise ValueError(f'未知/未支持类型: {name!r} — 若为 WoT 扩展类型需补配方')


def parse_flags(prop_elem):
    """解析属性 Flags: <Flags>命名</Flags> + 布尔子元素(Persistent/Identifier/REPLAY...)"""
    flags = None
    for ch in prop_elem:
        if ch.tag == 'Flags':
            v = (ch.text or '').strip().upper()
            if v in FLAG_NAMES:
                flags = FLAG_NAMES[v]
            elif v:  # 允许管道叠加? 引擎不支持, 保底报错
                raise ValueError(f'未知 Flags 值: {v}')
    if flags is None:
        flags = DATA_GHOSTED  # 缺省 CELL_PUBLIC
    for ch in prop_elem:
        if ch.tag in ('Persistent', 'Identifier', 'REPLAY', 'Ghosted'):
            if (ch.text or 'true').strip().lower() in ('true', '1'):
                flags |= {'Persistent': DATA_PERSISTENT, 'Identifier': DATA_ID,
                          'REPLAY': DATA_REPLAY, 'Ghosted': DATA_GHOSTED}[ch.tag]
    return flags


def is_client_server(flags):
    return bool(flags & (DATA_OTHER_CLIENT | DATA_OWN_CLIENT | DATA_REPLAY))


def varlen_header_append(md5, type_elem, var_len_header_size=2):
    """MemberDescription::addToMD5 的 varLenHeaderSize 分支:
    isForClient && streamSize<0 && varLenHeaderSize != 2(默认) 才追加"""
    # 引擎默认 2 且 .def 很少改; 本复刻默认不追加 (与引擎默认路径一致)
    return


def parse_def(path):
    """解析 .def → (props, client_methods, base_methods, cell_methods)"""
    root = ET.parse(path).getroot()

    props = []
    for section in ('Properties', 'CellProperties', 'BaseProperties'):
        sec = root.find(section)
        if sec is None:
            continue
        for prop in sec:
            flags = parse_flags(prop)
            props.append(dict(name=prop.tag, flags=flags,
                              type_elem=_type_of_element(prop)))

    def methods_of(section):
        out = []
        sec = root.find(section)
        if sec is None:
            return out
        for m in sec:
            exposed_child = m.find('Exposed')
            exposed = exposed_child is not None
            # 方法 flags_: 1=EXPOSED... 以 method_description.hpp 位定义为准的近似
            mflags = 0
            if exposed_child is not None:
                v = (exposed_child.text or '').strip()
                mflags |= 0x01                       # IS_EXPOSED 位近似
                if v == 'ALL_CLIENTS':
                    mflags |= 0x02
            args = []
            for arg in m:
                if arg.tag == 'Arg':
                    args.append(_type_of_element(arg))
            out.append(dict(name=m.tag, exposed=exposed,
                            flags=mflags, args=args))
        return out

    return props, methods_of('ClientMethods'), methods_of('BaseMethods'), \
        methods_of('CellMethods')


def compute_digest(entity_defs_dir, entities_xml='entities.xml', verbose=True):
    md5 = MD5Acc()
    tree = ET.parse(os.path.join(entity_defs_dir, entities_xml))
    root = tree.getroot()
    cs = root.find('ClientServerEntities')
    entries = list(cs) if cs is not None else list(root)

    for entry in entries:
        name = entry.tag
        # .def 与 entities.xml 的相对位置: 同目录 或 entity_defs/ 子目录
        def_path = os.path.join(entity_defs_dir, name + '.def')
        if not os.path.exists(def_path):
            def_path = os.path.join(entity_defs_dir, 'entity_defs', name + '.def')
        if not os.path.exists(def_path):
            if verbose:
                print(f'  [警告] 缺 {name}.def, 跳过', file=sys.stderr)
            continue
        props, client_m, base_m, cell_m = parse_def(def_path)
        if verbose:
            print(f'  {name}: {len(props)}属性 '
                  f'({sum(1 for p in props if is_client_server(p["flags"]))}CS) '
                  f'{len(client_m)}/{len(base_m)}/{len(cell_m)}方法', file=sys.stderr)

        md5.raw(name)                                   # 实体名

        csi = 0
        for p in props:                                 # 属性
            if not is_client_server(p['flags']):
                continue
            md5.i32(csi)                                # clientServerFullIndex
            varlen_header_append(md5, p['type_elem'])   # 默认不追加
            md5.raw(p['name'])                          # 属性名
            md5.i32(p['flags'] & DATA_DISTRIBUTION_FLAGS)
            data_type_md5(md5, p['type_elem'])
            csi += 1

        for methods, exposed_only in ((client_m, False), (base_m, True), (cell_m, True)):
            count = 0
            for m in methods:
                if exposed_only and not m['exposed']:
                    continue
                varlen_header_append(md5, None)
                md5.raw(m['name'])
                md5.u8(m['flags'])
                for a in m['args']:
                    data_type_md5(md5, a)
                md5.i32(count)
                count += 1

    return md5.hexdigest()


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    d = compute_digest(sys.argv[1],
                       sys.argv[2] if len(sys.argv) > 2 else 'entities.xml')
    print('EntityDescriptionMap::digest =', d)
