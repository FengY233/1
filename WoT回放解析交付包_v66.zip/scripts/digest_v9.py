#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""digest_v9.py — WoT fork entity_description_digests.cpp 终版复刻（结构 100% 已知）+ 小型暴力

【本轮 decomp 深挖定案的结构】(2026-09-24, 见 worklog Task 18)
入口 FUN_142a9b640: MD5Calculator{vptr, MD5 ctx@+8} → visitor → Final
槽位: +0x18 begin(name,flag)=空操作/flag宽度变体 | +0x20 end()=空操作(穷举法证明)
     +0x28 u32(4B LE) | +0x40 varLen(2/4B 变体) | +0x50 u8 | +0x58 bool(1B)
     +0x60 stdstr(内容无NUL, len=u32 size) | +0x68 cstr(带NUL) | +0x70 getState()→ctx
裸哈希: csi 与 methodIndex 经 getState+FUN_1403e82c0 直接 4B LE
DAT_1435e0950="type"(len4铁证) DAT_143665890="args"(len4铁证)
DAT_143676a60="Int"(len3铁证) DAT_143928948="Uint" DAT_1437d083c="Blob"(BlobDataType旁证)
类型名=vanilla驼峰: Int/Uint/Float/Float64/String/UnicodeString/Blob/Python/MailBox/
  UserDataObjectLinkDataType/Vector/Array/Tuple/FixedDict
MAILBOX: 客户端build=UnsupportedDataType(vanilla #if MF_SERVER 条件编译)
  → 0x3D 由服务器计算 → 服务器侧 MAILBOX→"MailBox"
isVolatile: <Volatile>节仅列 position/yaw/roll/pitch 自动属性(8/7/4/4处)
  → 声明属性恒 0
FixedDict: 无 implementedBy → module/instance 空 → 0 字节
persistAsBlob: 0 处 → dbLen 分支永不触发
vlh 分布: {1:342, 2:5} → 仅 5 个成员触发 varLenHeaderSize
方法重名: Account.requestToken 接口遮蔽 1 处 | 同名属性覆盖 7 处(csi 已锚点验证)

序列化结构:
entity: begin(name,0) str(name) begin("properties",1)
  per CS prop: u32(csi) begin(name,0) [vlh] str(name) u32(flags&0x5F) u8(0) TYPE(type节) end
  end begin("clientMethods",1) per m: MBODY u32(idx++) end
    begin("baseMethods",1) per exposed m: MBODY u32(idx++) end
    begin("cellMethods",1) 同 end  (实体懒惰闭合)
MBODY: begin(name,0) [vlh] str(name) u8(flags)
  [args非空: begin("args",1) per a: begin(?,0) TYPE(无节名) end end]
  [rets非空: begin("returnValues",1) per r: 同 end]
  end
TYPE(t, sec): begin(sec,0) cstr(类型名) [u32(size)] [dbLen] [elem TYPE(elementType)]
  FixedDict: cstr u8(allowNone) begin("fields",1) per f: begin(f,0) str(f) TYPE(无) end end end

方法序变体: M1=v8交织(parent→ifaces→own,首胜去重)
  M2=own链(parent→own)+接口后置(a=仅本实体接口 b=含父接口扁平) × cross(跳过/保留遮蔽)
  M4=M1+接口再哈希(a/b)
begin 变体: none/u8/u16/u32 (flag 字节) × vlh 宽度: u16/u32
"""
import hashlib
import itertools
import struct
import sys
from collections import defaultdict

sys.path.insert(0, '/home/z/my-project/scripts')
import digest_v8 as D8

TARGET = '5DF886F75E73B33CFF9D87FB9C69389C'
KIND_NAME = {
    'Int': 'Int', 'Uint': 'Uint', 'Float': 'Float', 'Float64': 'Float64',
    'String': 'String', 'UnicodeString': 'UnicodeString', 'Blob': 'Blob',
    'Python': 'Python', 'MailBox': 'MailBox',
    'UDO': 'UserDataObjectLinkDataType',
}


# ================================================================ 类型树解析
def resolve_type(doc, spec):
    """规格 → 类型树 (kind, params...)；别名递归展开"""
    if isinstance(spec, str):
        name, node = spec, None
    else:
        name = D8.own_value(spec)
        node = spec
    if not isinstance(name, str) or not name:
        raise ValueError('bad type spec: %r' % (spec,))
    if node is None and name in D8.ALIASES:
        return resolve_type(D8.ALIAS_DOC, D8.ALIASES[name])
    up = name.upper()
    if up in D8.SIMPLE:
        tag, sz = D8.SIMPLE[up]
        # tag: Int/Uint/Float/Float64/String/UnicodeString/Blob/Python/MailBox/UserDataObjectLinkDataType
        for k, v in KIND_NAME.items():
            if v == tag:
                return (k, sz) if sz is not None and k in ('Int', 'Uint') else (k,)
        if tag == 'UserDataObjectLinkDataType':
            return ('UDO',)
        return (tag,)
    if up in ('VECTOR2', 'VECTOR3', 'VECTOR4'):
        return ('Vector', int(up[-1]))
    if up in ('ARRAY', 'TUPLE'):
        if node is None:
            raise ValueError('%s 需子元素' % up)
        size = D8.child_int(doc, node, 'size', 0)
        of = doc.child(node, 'of')
        if of is None:
            raise ValueError('%s 缺 <of>' % up)
        return (up.capitalize(), size, resolve_type(doc, of))
    if up in ('FIXED_DICT', 'FIXED_DICT_SIMPLE'):
        if node is None:
            raise ValueError('FixedDict 需节点')
        props = doc.child(node, 'Properties')
        if props is None:
            raise ValueError('FixedDict 缺 Properties')
        allow_none = D8.child_bool(doc, node, 'AllowNone', False)
        fields = []
        for cidx, cv in doc.kids(props):
            fname = doc.nm(cidx)
            ftype = doc.child(cv, 'Type')
            if ftype is None:
                raise ValueError('FixedDict 字段 %s 缺 Type' % fname)
            fields.append((fname, resolve_type(doc, ftype)))
        return ('FixedDict', allow_none, fields)
    raise ValueError('未知类型: %r' % name)


def type_is_var(t):
    k = t[0]
    if k in ('Int', 'Uint', 'Float', 'Float64', 'Vector'):
        return False
    if k in ('String', 'UnicodeString', 'Blob', 'Python', 'MailBox', 'UDO'):
        return True
    if k in ('Array', 'Tuple'):
        return t[1] <= 0 or type_is_var(t[2])
    if k == 'FixedDict':
        return any(type_is_var(ft) for _f, ft in t[2])
    return True


# ================================================================ 方法解析(含 ReturnValues)
def parse_methods_v9(doc, sec_name, comp, source):
    sec = doc.section(sec_name)
    out = []
    if sec is None:
        return out
    for midx, mnode in doc.kids(sec):
        mname = doc.nm(midx)
        args, rets = [], []
        exposed_bits = 0
        vlh = None
        allow_unsafe = False
        for cidx, cv in doc.kids(mnode):
            cn = doc.nm(cidx)
            if cn == 'Arg':
                args.append(cv)
            elif cn == 'ReturnValues':
                if isinstance(cv, list):
                    for ridx, rv in doc.kids(cv):
                        rets.append(rv)
            elif cn == 'Exposed':
                v = D8.own_value(cv)
                if v == '' or v is False or v is None:
                    exposed_bits = 0x0C
                elif v == 'OWN_CLIENT':
                    exposed_bits = 0x08
                elif v == 'ALL_CLIENTS':
                    exposed_bits = 0x04 if comp == 'cell' else None
                    if exposed_bits is None:
                        raise ValueError('BASE 方法不合法 Exposed: %s.%s' % (source, mname))
                else:
                    raise ValueError('未知 Exposed %r: %s.%s' % (v, source, mname))
            elif cn == 'VariableLengthHeaderSize':
                v = D8.own_value(cv)
                vlh = v if isinstance(v, int) else None
            elif cn == 'AllowUnsafeData':
                allow_unsafe = D8.own_value(cv) is True
        if comp == 'client':
            flags = 0x04
        else:
            flags = D8.COMP_BITS[comp] | exposed_bits
        if allow_unsafe:
            flags |= 0x10
        try:
            atrees = [resolve_type(doc, a) for a in args]
            rtrees = [resolve_type(doc, r) for r in rets]
        except ValueError as e:
            raise ValueError('%s.%s: %s' % (source, mname, e))
        out.append(dict(name=mname, flags=flags, vlh=vlh,
                        args=atrees, rets=rtrees,
                        var=any(type_is_var(t) for t in atrees),
                        exposed=(comp == 'client') or bool(exposed_bits),
                        has_args=bool(args), has_rets=bool(rets),
                        doc=doc))
    return out


def m1_methods(entity_name):
    """v8 交织序: parent全量 → 接口(嵌套递归→自身) → 自身"""
    doc = D8.Doc.load(entity_name)
    out = {'client': [], 'base': [], 'cell': []}
    par = doc.section('Parent')
    if par is not None:
        pn = D8.own_value(par)
        if isinstance(pn, str) and pn:
            pm = m1_methods(pn)
            for k in out:
                out[k] += pm[k]
    impl = doc.section('Implements')
    if impl is not None:
        for _idx, iv in doc.kids(impl):
            iname = D8.own_value(iv)
            if isinstance(iname, str) and iname:
                im = iface_own_methods(iname)   # 嵌套递归→自身, 同 v8 accum_interface
                for k in out:
                    out[k] += im[k]
    out['base'] += parse_methods_v9(doc, 'BaseMethods', 'base', entity_name)
    out['cell'] += parse_methods_v9(doc, 'CellMethods', 'cell', entity_name)
    out['client'] += parse_methods_v9(doc, 'ClientMethods', 'client', entity_name)
    return out


def own_chain_methods(entity_name):
    """Parent 链(递归) + 自身方法, 不含接口"""
    doc = D8.Doc.load(entity_name)
    out = {'client': [], 'base': [], 'cell': []}
    par = doc.section('Parent')
    if par is not None:
        pn = D8.own_value(par)
        if isinstance(pn, str) and pn:
            pm = own_chain_methods(pn)
            for k in out:
                out[k] += pm[k]
    out['base'] += parse_methods_v9(doc, 'BaseMethods', 'base', entity_name)
    out['cell'] += parse_methods_v9(doc, 'CellMethods', 'cell', entity_name)
    out['client'] += parse_methods_v9(doc, 'ClientMethods', 'client', entity_name)
    return out


def iface_own_methods(iname):
    """接口自身方法(其 Implements 递归后置内联, 等价 M2 语义)"""
    doc = D8.Doc.load(iname)
    out = {'client': [], 'base': [], 'cell': []}
    impl = doc.section('Implements')
    if impl is not None:
        for _idx, iv in doc.kids(impl):
            jn = D8.own_value(iv)
            if isinstance(jn, str) and jn:
                jm = iface_own_methods(jn)
                for k in out:
                    out[k] += jm[k]
    out['base'] += parse_methods_v9(doc, 'BaseMethods', 'base', iname)
    out['cell'] += parse_methods_v9(doc, 'CellMethods', 'cell', iname)
    out['client'] += parse_methods_v9(doc, 'ClientMethods', 'client', iname)
    return out


def entity_iface_list(entity_name, include_parent):
    """实体(或含父链)的顶层接口名列表, 按累积序"""
    names = []

    def rec(ename):
        doc = D8.Doc.load(ename)
        if include_parent:
            par = doc.section('Parent')
            if par is not None:
                pn = D8.own_value(par)
                if isinstance(pn, str) and pn:
                    rec(pn)
        impl = doc.section('Implements')
        if impl is not None:
            for _idx, iv in doc.kids(impl):
                iname = D8.own_value(iv)
                if isinstance(iname, str) and iname:
                    names.append(iname)

    rec(entity_name)
    return names


def dedup_methods(mlist):
    seen = {}
    out = []
    for m in mlist:
        if m['name'] in seen:
            continue
        seen[m['name']] = 1
        out.append(m)
    return out


# ================================================================ 模型
class Model(object):
    pass


def build_model():
    ents = []
    for ename in D8.entity_list():
        props, _m = D8.accumulate(ename)
        final, is_cs, csi_map, ss_of = D8.finalize_entity(props)
        md = Model()
        md.name = ename
        md.props = []
        for i, p in enumerate(final):
            if not is_cs(p):
                continue
            tt = resolve_type(p['doc'], p['tspec'])
            vlh = p['vlh'] if p['vlh'] is not None else D8.DEFAULT_VLH
            md.props.append(dict(csi=csi_map[i], name=p['name'],
                                 flags=p['flags'] & 0x5F,
                                 var=type_is_var(tt), vlh=vlh, type=tt))
        # 方法三种序的数据源
        md.own_chain = {k: dedup_methods(v) for k, v in own_chain_methods(ename).items()}
        md.ifaces_own = entity_iface_list(ename, include_parent=False)
        md.ifaces_all = entity_iface_list(ename, include_parent=True)
        md.m1 = {k: dedup_methods(v) for k, v in m1_methods(ename).items()}
        # M2/M4 需要遮蔽集合
        md.own_names = {k: set(m['name'] for m in md.own_chain[k]) for k in ('client', 'base', 'cell')}
        ents.append(md)
    return ents


# ================================================================ 序列化
class Dig(object):
    def __init__(self, begin_mode, vlh_mode):
        self.h = hashlib.md5()
        self.begin_mode = begin_mode        # 'none' | 'u8' | 'u16' | 'u32'
        self.vlh_mode = vlh_mode            # 'u8' | 'u16' | 'u32'

    def begin(self, flag):
        if self.begin_mode == 'u8':
            self.h.update(struct.pack('<B', flag))
        elif self.begin_mode == 'u16':
            self.h.update(struct.pack('<H', flag))
        elif self.begin_mode == 'u32':
            self.h.update(struct.pack('<I', flag))

    def end(self):
        pass

    def u32(self, v):
        self.h.update(struct.pack('<I', v & 0xFFFFFFFF))

    def u8(self, v):
        self.h.update(struct.pack('<B', v & 0xFF))

    def vlh(self, v):
        if self.vlh_mode == 'u8':
            self.h.update(struct.pack('<B', v))
        elif self.vlh_mode == 'u16':
            self.h.update(struct.pack('<H', v))
        else:
            self.h.update(struct.pack('<i', v))

    def string(self, s):
        if s:
            self.h.update(s.encode('utf-8'))

    def cstr(self, s):
        self.h.update(s.encode('utf-8') + b'\x00')

    def raw_u32(self, v):
        self.h.update(struct.pack('<I', v & 0xFFFFFFFF))


def ser_type(d, t):
    d.begin(0)
    k = t[0]
    if k in ('Int', 'Uint'):
        d.cstr(k)
        d.u32(t[1])
    elif k in KIND_NAME:
        d.cstr(KIND_NAME[k])
    elif k == 'Vector':
        d.cstr('Vector')
        d.u32(t[1])
    elif k in ('Array', 'Tuple'):
        d.cstr(k)
        d.u32(t[1])
        # dbLen 永不触发(WoT 无 persistAsBlob)
        ser_type(d, t[2])
    elif k == 'FixedDict':
        d.cstr('FixedDict')
        # module/instance: WoT 无 implementedBy → 0 字节
        d.u8(1 if t[1] else 0)
        d.begin(1)                                    # fields 数组
        for fname, ft in t[2]:
            d.begin(0)                                # 字段对象
            d.string(fname)
            ser_type(d, ft)                           # 无节名
            d.end()
        d.end()
        d.end()
    else:
        raise ValueError('?? %r' % (t,))
    d.end()


def ser_method(d, m):
    d.begin(0)
    if m['var'] and m['vlh'] is not None and m['vlh'] != 1:
        d.vlh(m['vlh'])
    d.string(m['name'])
    d.u8(m['flags'])
    if m['has_args']:
        d.begin(1)                                    # args 数组
        for a in m['args']:
            d.begin(0)
            ser_type(d, a)
            d.end()
        d.end()
    if m['has_rets']:
        d.begin(1)                                    # returnValues 数组
        for r in m['rets']:
            d.begin(0)
            ser_type(d, r)
            d.end()
        d.end()
    d.end()


def ser_domain(d, mlist, comp, domain_name):
    d.begin(1)                                        # 节数组
    idx = 0
    for m in mlist:
        if comp != 'client' and not m['exposed']:
            continue
        ser_method(d, m)
        d.raw_u32(idx)
        idx += 1
    d.end()


def methods_variant(md, variant):
    """variant: m1 | m2a | m2b | m2a_x | m2b_x | m4a | m4b"""
    if variant == 'm1':
        return md.m1
    base = variant[:3]
    out = {}
    for k in ('client', 'base', 'cell'):
        lst = list(md.own_chain[k])
        ifaces = md.ifaces_own if base == 'm2a' or variant == 'm4a' else md.ifaces_all
        if variant.startswith('m2'):
            for iname in ifaces:
                for m in iface_own_methods(iname)[k]:
                    if variant.endswith('_x') and m['name'] in md.own_names[k]:
                        continue
                    lst.append(m)
            out[k] = dedup_methods(lst) if not variant.endswith('_x') else lst
        else:  # m4: M1 + 接口再哈希
            lst = list(md.m1[k])
            for iname in ifaces:
                for m in iface_own_methods(iname)[k]:
                    lst.append(m)
            out[k] = lst
    return out


def compute_digest(ents, begin_mode, vlh_mode, mvar):
    d = Dig(begin_mode, vlh_mode)
    d.begin(0)                                        # root
    for md in ents:
        d.begin(0)                                    # entity (懒惰闭合由下一 begin 体现)
        d.string(md.name)
        d.begin(1)                                    # properties
        for p in md.props:
            d.raw_u32(p['csi'])
            d.begin(0)
            if p['var'] and p['vlh'] != 1:
                d.vlh(p['vlh'])
            d.string(p['name'])
            d.u32(p['flags'])
            d.u8(0)                                   # isVolatile 恒 0
            ser_type(d, p['type'])
            d.end()
        d.end()
        mm = methods_variant(md, mvar)
        ser_domain(d, mm['client'], 'client', 'clientMethods')
        ser_domain(d, mm['base'], 'base', 'baseMethods')
        ser_domain(d, mm['cell'], 'cell', 'cellMethods')
    d.end()                                           # root end
    return d.h.hexdigest().upper()


def main():
    print('构建模型...')
    ents = build_model()
    ncs = sum(len(m.props) for m in ents)
    nm = {}
    for m in ents:
        for k in ('client', 'base', 'cell'):
            nm[k] = nm.get(k, 0) + len(m.m1[k])
    print('实体 %d | CS 属性 %d | 方法 c/b/c: %d/%d/%d' % (
        len(ents), ncs, nm.get('client', 0), nm.get('base', 0), nm.get('cell', 0)))

    variants = ['m1', 'm2a', 'm2b', 'm2a_x', 'm2b_x', 'm4a', 'm4b']
    total = 0
    hits = []
    for bm in ('none', 'u8', 'u16', 'u32'):
        for vw in ('u32', 'u16', 'u8'):
            for mv in variants:
                total += 1
                dg = compute_digest(ents, bm, vw, mv)
                if dg == TARGET:
                    hits.append((bm, vw, mv, dg))
                    print('★ 命中! begin=%s vlh=%s 方法序=%s' % (bm, vw, mv))
    print('共试 %d 组合, 命中 %d' % (total, len(hits)))
    if not hits:
        print('未命中。样本(第一组):', compute_digest(ents, 'none', 'u32', 'm1'))
    return hits


if __name__ == '__main__':
    main()
