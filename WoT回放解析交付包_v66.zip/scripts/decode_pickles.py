# -*- coding: utf-8 -*-
"""decode_pickles.py — 解码 0x8/0x0 等类型内嵌的 pickle 载荷 + 时钟标定"""
import io
import pickle
import struct
import sys
from collections import Counter

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

R = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
pkts = R.pkts


def p2str(obj, depth=0, maxdepth=4):
    """py2 pickle 解出的对象转可读串"""
    if isinstance(obj, bytes):
        try:
            return obj.decode('utf-8')
        except Exception:
            return repr(obj)
    if isinstance(obj, dict):
        if depth >= maxdepth:
            return '{...%d键}' % len(obj)
        items = []
        for k, v in list(obj.items())[:12]:
            items.append('%s: %s' % (p2str(k, depth + 1), p2str(v, depth + 1)))
        more = '' if len(obj) <= 12 else ' ...(+%d)' % (len(obj) - 12)
        return '{' + ', '.join(items) + more + '}'
    if isinstance(obj, (list, tuple)):
        if depth >= maxdepth:
            return '[...%d项]' % len(obj)
        items = [p2str(x, depth + 1) for x in obj[:8]]
        more = '' if len(obj) <= 8 else ' ...(+%d)' % (len(obj) - 8)
        return ('[' if isinstance(obj, list) else '(') + ', '.join(items) + more + (']' if isinstance(obj, list) else ')')
    return repr(obj)


def try_pickle(b):
    try:
        return pickle.loads(b, encoding='utf-8', errors='replace'), None
    except Exception as e:
        return None, str(e)


print('==== 0x8 各 field2 的 pickle 解码 (每类取1个样本) ====')
seen = {}
for p in pkts:
    if p[0] != 0x8 or len(p[2]) < 12:
        continue
    (eid, f2) = struct.unpack_from('<II', p[2], 0)
    (n,) = struct.unpack_from('<I', p[2], 8)
    if f2 in seen or n + 12 > len(p[2]) or n < 2:
        continue
    data = p[2][12:12 + n]
    if not data.startswith(b'\x80'):
        continue
    obj, err = try_pickle(data)
    seen[f2] = True
    print('-- field2=%d entity=0x%X len=%d' % (f2, eid, n))
    if err:
        print('   ERR:', err[:80])
    else:
        print('   ', p2str(obj)[:400])
    print()

print()
print('==== 0x0 (avatar聚合) 内层流解码 ====')
for p in pkts[:30]:
    if p[0] != 0x0:
        continue
    b = p[2]
    (eid,) = struct.unpack_from('<I', b, 0)
    (u16v,) = struct.unpack_from('<H', b, 4)
    (l1,) = struct.unpack_from('<I', b, 6)
    (l2,) = struct.unpack_from('<I', b, 10 + l1)
    print('pkt#%d: [u32 0x%X][u16 %d][u32 l1=%d][u32 l2=%d] total=%d' % (
        p[3], eid, u16v, l1, l2, len(b)))
    inner = b[14 + l1:14 + l1 + l2]
    print('  内层前 160 字节:')
    for i in range(0, min(160, len(inner)), 16):
        ch = inner[i:i + 16]
        print('    %04x  %-47s  %s' % (i, ' '.join('%02x' % c for c in ch),
                                       ''.join(chr(c) if 32 <= c < 127 else '.' for c in ch)))
    # 找 pickle 起点
    idx = inner.find(b'\x80\x02')
    if idx >= 0:
        obj, err = try_pickle(inner[idx:])
        print('  pickle@%d:' % idx, ('ERR ' + err[:60]) if err else p2str(obj)[:500])
    break

print()
print('==== 时钟标定: 0x1F 值 vs 包 clock 线性回归 ====')
xs, ys = [], []
for p in pkts:
    if p[0] == 0x1F:
        (v,) = struct.unpack('<I', p[2])
        xs.append(p[1])
        ys.append(v)
# 只用 battle 阶段段(值在 0..20000 且 clock>1100e6) 做回归
pts = [(x, y) for x, y in zip(xs, ys) if y < 20000 and x > 1.05e9]
if len(pts) > 10:
    n = len(pts)
    sx = sum(a for a, b in pts) / n
    sy = sum(b for a, b in pts) / n
    sxx = sum((a - sx) ** 2 for a, b in pts)
    sxy = sum((a - sx) * (b - sy) for a, b in pts)
    slope = sxy / sxx
    print('  样本=%d  slope=%.6f (0x1F值/秒)  截距=%.1f' % (n, slope, sy - slope * sx))
    print('  → 若 slope≈10 则 0x1F = 10Hz tick; 1 tick = %.4f s' % (1.0 / slope if slope else 0))
    # clock 单位验证: 用 0x1F 差分
    x0, y0 = pts[0]
    x1, y1 = pts[-1]
    print('  首样本 clock=%d val=%d; 末样本 clock=%d val=%d' % (x0, y0, x1, y1))
    print('  Δclock=%d, Δval=%d → clock/val = %.2f' % (x1 - x0, y1 - y0, (x1 - x0) / max(1, y1 - y0)))

print()
print('==== 0x16 阶段事件与 clock (µs?) 对齐 ====')
for p in pkts:
    if p[0] == 0x16:
        (v,) = struct.unpack('<I', p[2])
        print('  period %d @ clock=%d (= %.1f s if µs)' % (v, p[1], p[1] / 1e6))
