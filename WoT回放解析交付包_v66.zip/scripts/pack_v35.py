#!/usr/bin/env python3
"""pack_v35.py — V35 打包: Task 59-b 0x0A B 12B 定案 + tail + LSB
底座: V34 包(剔 findings/worklog/README/audit) + findings v42 + worklog + data_v39×7 + t59 脚本×5 + README V35 节 + audit_v35.json
"""
import os, hashlib, json, sys, zipfile

BASE = '/home/z/my-project'
V34 = f'{BASE}/download/WoT回放解析交付包_v34.zip'
OUT = f'{BASE}/download/WoT回放解析交付包_v35.zip'

def md5f(p):
    h = hashlib.md5()
    with open(p, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()

# 1) 解 V34 底座到临时目录
import shutil, tempfile
tmp = tempfile.mkdtemp(prefix='v35_')
with zipfile.ZipFile(V34, mode='r') as z:
    z.extractall(tmp)
n_base = sum(len(fs) for _, _, fs in os.walk(tmp))
print(f'V34 底座解包: {n_base} 文件')

# 2) 替换 findings/worklog
for name in ('findings.md', 'worklog.md'):
    src = f'{BASE}/{name}'
    dst = f'{tmp}/{name}'
    if os.path.exists(dst):
        os.remove(dst)
    shutil.copy2(src, dst)

# 3) data_v39 目录
d39 = f'{BASE}/download/data_v39'
os.makedirs(f'{tmp}/data_v39', exist_ok=True)
n39 = 0
for f in os.listdir(d39):
    shutil.copy2(f'{d39}/{f}', f'{tmp}/data_v39/{f}')
    n39 += 1
print(f'data_v39: {n39} 件')

# 4) t59 脚本
nsc = 0
for f in os.listdir(f'{BASE}/scripts'):
    if f.startswith('t59_'):
        shutil.copy2(f'{BASE}/scripts/{f}', f'{tmp}/scripts/{f}')
        nsc += 1
print(f't59 脚本: {nsc} 件')

# 5) README V35 节
rd = f'{tmp}/README.md'
if not os.path.exists(rd):
    rd = f'{tmp}/readme.md'
with open(rd, 'a', encoding='utf-8') as f:
    f.write('''

## V35 (2026-09-26) — Task 59-b: 0x0A B 12B 定案 ★★★★
- **B 12B = 悬挂车体(hull)位置偏移快照**——七重证据闭环:
  1. 回放端 FUN_14058a6b0 跳读 33B/45B 不对称(重建非必需, 客户端本地重算)
  2. Y 分量全 2 幂序列, 基 2⁻⁹ m(悬挂高度步进 2mm)
  3. B_y 637,317 条非零样本无一负值(车体悬于逻辑原点上方)
  4. X/Z 二分衰减链(阻尼回弹收敛系数 0.5), 基 q_xz=16416314×2⁻³⁰
  5. 每场 1-2 个运动且 B 全零实体=玩家本车(本地物理免报)
  6. 严格启停瞬态 |B| 不变(俯仰在 pitch/roll, 不改 hull 平均偏移)
  7. 排除项: 速度反馈 cos 对称展开/本体偏移投影 0.2%/姿态相关全零
- **tail u8 = 注入来源标志**: 97.5% 周期注入(volatileInjectionPeriodTicks=5)/2.53% 事件触发
- **LSB 水印密度定标**: 有效注入仅 ~0.005%(选择性翻转)
- 0x0A 通道理解度 0.97→0.985; **总体按字节加权理解度 95.9%→96.1%**
''')

# 6) audit_v35.json
audit = {
 "version": "v35", "date": "2026-09-26",
 "task": "Task 59-b: 0x0A B 12B 定案(悬挂车体偏移) + tail 注入源标志 + LSB 密度定标",
 "headline": [
  "★★★★ B 12B = 悬挂车体(hull)位置偏移快照——回放端 FUN_14058a6b0 跳读 33B/45B 不对称 + Y 全 2 幂基 2⁻⁹ + B_y 637,317 条恒正 + 二分衰减链 + 本车免报 + 启停无瞬态, 七重证据闭环",
  "★★★★ 量化指纹: q_y=2⁻⁹(尾数全零), q_xz=16416314×2⁻³⁰=0.015288883820176125(尾数恒 1 尾随零); X/Z 阻尼收敛系数 0.5",
  "★★★ tail u8 = 注入来源标志(周期注入 97.5% / 事件触发 2.53%; 修正 v41 22 例记录为 19,334 例)",
  "★★ LSB 水印密度定标: 有效注入仅 ~0.005%, pos 21%/ypr 39% LSB 率为原始量化特征",
  "0x0A 通道理解度 0.97→0.985; 总体 95.9%→96.1%"
 ],
 "coverage": {
  "corpus": "10 场随机战(11 文件)", "total_pkts": 1514067, "total_payload_bytes": 48202991,
  "weighted_understanding_pct": 96.1,
  "channel_status": {
   "0x0A": {"share": 68.05, "u": 0.985, "note": "volatile 位置流全解: 45B 布局+B 悬挂偏移定案+tail 注入源+LSB 定标; 余指纹级(q_xz 数值来源)"},
   "0x07": {"share": 12.94, "u": 1.0}, "0x1A": {"share": 6.12, "u": 0.95}, "0x26": {"share": 3.89, "u": 0.95},
   "0x39": {"share": 2.48, "u": 0.75, "note": "结构全解; 余对象身份+41B 字段级"},
   "0x37": {"share": 1.52, "u": 0.95, "note": "NRL 全解; 余 Root 前缀+深路径 2082"},
   "0x05": {"share": 1.18, "u": 1.0}, "0x32": {"share": 0.69, "u": 1.0}, "0x24": {"share": 0.2, "u": 1.0},
   "0x04": {"share": 0.05, "u": 1.0}, "0x3D": {"share": 0.0, "u": 1.0}
  },
  "remaining": [
   "①0x39 对象身份(0x05 CSI≥50 扩展区 prefabPath)+41B 字段级——约 0.6% 字节",
   "②0x37 Root 体前缀精确文法 + 深路径 2082 条",
   "③clk 1/65536s 换算全通道时间线重述(含 v24 E 纪元复核)",
   "④指纹级: q_xz=16416314×2⁻³⁰ 数值来源 / B_y×车型悬挂行程表 / LSB 位表 256 位内容",
   "⑤边缘: karelia2 deathOrder -1 例 / ln156 消歧 / 59 tid 补名 / 0x35 class2 NRL 形态"
  ]
 }
}
with open(f'{tmp}/audit_v35.json', 'w', encoding='utf-8') as f:
    json.dump(audit, f, indent=1, ensure_ascii=False)

# 7) 打包 (ZIP 格式, 与 V2-V34 一致)
if os.path.exists(OUT):
    os.remove(OUT)
with zipfile.ZipFile(OUT, mode='w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for root, dirs, files in os.walk(tmp):
        dirs.sort()
        for fn in sorted(files):
            fp = os.path.join(root, fn)
            arc = os.path.relpath(fp, tmp)
            z.write(fp, arc)

nfiles = sum(len(fs) for _, _, fs in os.walk(tmp))
size = os.path.getsize(OUT)
digest = md5f(OUT)
# testzip
with zipfile.ZipFile(OUT, mode='r') as z:
    bad = z.testzip()
    assert bad is None, f'corrupt: {bad}'
    names = z.namelist()
print(f'V35 打包完成: {nfiles} 文件(包内 {len(names)} 条目), {size} B ({size/1048576:.2f} MB), md5={digest}')
# 备份
os.makedirs(f'{BASE}/upload/backup_v35', exist_ok=True)
shutil.copy2(OUT, f'{BASE}/upload/backup_v35/WoT回放解析交付包_v35.zip')
shutil.copy2(f'{tmp}/audit_v35.json', f'{BASE}/upload/backup_v35/audit_v35.json')
shutil.copy2(f'{BASE}/findings.md', f'{BASE}/upload/backup_v35/findings.md')
shutil.copy2(f'{BASE}/worklog.md', f'{BASE}/upload/backup_v35/worklog.md')
# audit 副本放 download
shutil.copy2(f'{tmp}/audit_v35.json', f'{BASE}/download/audit_v35.json')
shutil.rmtree(tmp)
print('backup_v35 入库 + audit_v35.json 已放 download/')
