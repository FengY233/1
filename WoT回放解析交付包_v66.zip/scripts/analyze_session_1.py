# -*- coding: utf-8 -*-
"""分析 session_20260911_175934.jsonl 客户端会话监控日志（第1步：全量结构化提取）"""
import json, re, ast
from collections import Counter, defaultdict
from datetime import datetime, timedelta

SRC = '/home/z/my-project/upload/session_20260911_175934.jsonl'
CST = timedelta(hours=8)

events = []
with open(SRC, encoding='utf-8') as f:
    for i, line in enumerate(f):
        try:
            events.append(json.loads(line))
        except Exception:
            print(f'行 {i} 解析失败')

print(f'总事件数: {len(events)}')

def cst(ts): return datetime.utcfromtimestamp(ts) + CST

# ============ 1. 会话生命周期时间线 ============
print('\n' + '='*70)
print('1. 会话生命周期关键节点')
print('='*70)
lifecycle = ['session', 'garage.account_become_player', 'garage.show_gui',
             'queue.enqueued', 'queue.arena_created', 'battle.avatar_become_player',
             'battle.avatar_ready', 'battle.round_finished', 'battle.results_received',
             'battle.avatar_vehicle_leave_world', 'battle.avatar_become_non_player',
             'exit.disconnected', 'monitor_stopped']
for ev in events:
    if ev['ev'] in lifecycle:
        d = ev['data']
        extra = ''
        if ev['ev'] == 'session':
            extra = f"client={d['client_version']} realm={d['realm']} tick={d['server_tick_length']}"
        elif ev['ev'] == 'queue.enqueued':
            extra = f"queue_type={d['queue_type']}"
        elif ev['ev'] == 'queue.info':
            extra = f"players={d['args'][0]['players']} classes={d['args'][0]['classes']}"
        elif ev['ev'] == 'battle.round_finished':
            extra = f"args={d['args']} (胜方,结束原因)"
        print(f"  {cst(ev['ts']).strftime('%H:%M:%S.%f')[:-3]}  bt={d.get('bt','-'):>8}  {ev['ev']:42s} {extra}")

# ============ 2. 阶段切换 ============
print('\n' + '='*70)
print('2. arena.onPeriodChange 全部事件 (period: 1=倒计时? 2=战斗?)')
print('='*70)
for ev in events:
    if ev['ev'] in ('arena.onPeriodChange', 'battle.period_change'):
        d = ev['data']
        a = d.get('args', d)
        print(f"  bt={d.get('bt','-'):>8}  {cst(ev['ts']).strftime('%H:%M:%S.%f')[:-3]}  {ev['ev']:28s} {a}")

# ============ 3. 加载里程碑 ============
print('\n' + '='*70)
print('3. loading_milestone 全部里程碑（战斗加载流水线）')
print('='*70)
mstones = [(ev['data']['bt'], ev['data']['milestone'], cst(ev['ts'])) for ev in events if ev['ev'] == 'loading_milestone']
for bt, m, t in mstones:
    print(f'  bt={bt:>8}  {t.strftime("%H:%M:%S.%f")[:-3]}  {m}')

# ============ 4. battle_tick 统计 ============
print('\n' + '='*70)
print('4. battle_tick 分布')
print('='*70)
ticks = [ev for ev in events if ev['ev'] == 'battle_tick']
bts = [t['data']['bt'] for t in ticks]
periods = Counter(t['data'].get('period') for t in ticks)
print(f'  tick数: {len(ticks)}, bt范围: {min(bts):.1f} ~ {max(bts):.1f} (span {max(bts)-min(bts):.1f}s)')
print(f'  period分布: {dict(periods)}')
diffs = [b2-b1 for b1, b2 in zip(bts, bts[1:])]
dc = Counter(round(d, 3) for d in diffs)
print(f'  bt间隔分布(前8): {dc.most_common(8)}')
print(f'  平均间隔: {sum(diffs)/len(diffs):.4f}s -> 平均采样率 {1/(sum(diffs)/len(diffs)):.2f} Hz')

# ============ 5. 车辆实体 ============
print('\n' + '='*70)
print('5. 车辆实体创建/AoI进入')
print('='*70)
creates = [ev for ev in events if ev['ev'] == 'battle.vehicle_entity_created']
enters = [ev for ev in events if ev['ev'] == 'avatar.onVehicleEnterWorld']
# 从 publicInfo repr 提取
pub_re = re.compile(r"\{name: '(.*?)', compDescr: '(.*?)', outfit: '(.*?)', outfitLevel: (\d+), index: (\d+), team: (\d+)")
def parse_public(veh):
    pi = veh.get('publicInfo', '')
    if isinstance(pi, str):
        m = pub_re.search(pi)
        if m:
            name = m.group(1).encode('latin1', 'backslashreplace').decode('unicode_escape').encode('latin1').decode('utf-8', 'replace')
            return {'name': name, 'compDescr_hex': m.group(2).encode().decode('unicode_escape').encode('latin1').hex(),
                    'outfitLevel': int(m.group(4)), 'index': int(m.group(5)), 'team': int(m.group(6))}
    return None

roster = {}
for ev in creates:
    veh = ev['data'].get('vehicle', {})
    vid = veh.get('id')
    if vid is None:
        continue
    info = parse_public(veh)
    if info and vid not in roster:
        roster[vid] = {'bt': ev['data']['bt'], **info, 'maxHealth': veh.get('maxHealth'), 'type': veh.get('type')}
uniq_enter = set()
for ev in enters:
    veh = ev['data'].get('vehicle', {})
    uniq_enter.add(veh.get('id'))
print(f'  vehicle_entity_created 事件: {len(creates)}, 唯一车辆ID: {len(roster)}')
print(f'  onVehicleEnterWorld 事件: {len(enters)}, 唯一ID: {len(uniq_enter)}')
print(f'  AoI重进入次数: {len(enters)-len(uniq_enter)}')
teams = Counter(v['team'] for v in roster.values())
print(f'  名单队伍分布: {dict(teams)}')
print(f'\n  前5辆车示例:')
for vid, v in list(roster.items())[:5]:
    print(f"    {vid}: {v['name']} team={v['team']} maxHP={v['maxHealth']} compDescr={v['compDescr_hex'][:30]}")

json.dump({'roster': {str(k): v for k, v in roster.items()}},
          open('/home/z/my-project/scripts/session_roster_tmp.json', 'w', ensure_ascii=False), ensure_ascii=False, indent=1)
print('\n已保存 roster 到 scripts/session_roster_tmp.json')
