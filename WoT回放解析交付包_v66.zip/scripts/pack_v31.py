#!/usr/bin/env python3
"""pack_v31.py — Task 54-b 交付打包: V31 = V30 底座 + Task 53/54 增量
Task 53: ★★★语义标注器(100% 文法 → 语义级事件流, 6822 包全量)
Task 54: ★★★★组件方法ID机制源码级闭环 + def 全表重提 + tid→def 匹配器
data_v34: t53 结果×3(统计/样例/1.54MB 全事件流) + t54 结果×3(def 全表/mid 验证/匹配表)
scripts 增量: t53_*.py ×2 + t54_*.py ×3
findings v37 (§32 语义标注器 + §33 方法ID机制) + worklog(至 Task 54-a)
"""
import os, zipfile, hashlib, shutil, glob, json

DL = '/home/z/my-project/download'
V30 = f'{DL}/WoT回放解析交付包_v30.zip'
OUT = f'{DL}/WoT回放解析交付包_v31.zip'
DATA34 = f'{DL}/data_v34'

assert os.path.exists(V30), 'V30 底座缺失'
assert os.path.exists(DATA34) and len(os.listdir(DATA34)) == 6, f'data_v34 不完整(期望6件, 实际{len(os.listdir(DATA34)) if os.path.exists(DATA34) else 0})'
t5x = sorted(glob.glob('/home/z/my-project/scripts/t53_*.py')) + sorted(glob.glob('/home/z/my-project/scripts/t54_*.py'))
assert len(t5x) == 5, f't53/t54 脚本不齐(期望5件, 实际{len(t5x)})'

# 1) 以 V30 为底座
zin = zipfile.ZipFile(V30, 'r')
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as zout:
    for item in zin.infolist():
        if item.filename in ('findings.md', 'worklog.md', 'README.md', 'audit_v30.json'):
            continue  # 换新版本
        zout.writestr(item, zin.read(item.filename))
    # findings/worklog 主位新版
    zout.write('/home/z/my-project/findings.md', 'findings.md')
    zout.write('/home/z/my-project/worklog.md', 'worklog.md')
    # data_v34
    for f in sorted(os.listdir(DATA34)):
        zout.write(f'{DATA34}/{f}', f'data_v34/{f}')
    # scripts 增量(t53/t54 系列)
    for f in t5x:
        zout.write(f, f'scripts/{os.path.basename(f)}')

# 2) README 增补
z = zipfile.ZipFile(OUT, 'a')
readme_add = """

---

# V31 增补（Task 53-54 · v36-v37 · 语义级事件流 + 方法ID机制源码级闭环）

在 V30 全量底座之上新增：

| 内容 | 说明 |
|---|---|
| `findings.md` | ★ 结论登记册 v37（新增 §32：★★★语义标注器——100% 文法验证升级为语义级事件流 + 三项新实证；§33：★★★★组件方法ID机制源码级闭环——槽序排序模型/mid=声明序号/OwnVehicle 10/10 逐位验证） |
| `data_v34/` | t53 语义标注三件套（统计 14KB + 样例 19KB + 全事件流 1.54MB jsonl，6822 行含 span 可回溯字节）+ t54 结果×3（127 def 全保真全表 / mid 机制验证与 OwnVehicle 映射 / tid→def 匹配表 v1） |
| `scripts/t53_*.py` `t54_*.py` | 同步副本：语义标注器 + 收集器 / def 全保真重提 + mid 预测验证 + tid→def 匹配器 |

核心突破（Task 53）：
1. **★★★语义标注器闭环（100% 文法 → 语义）**：t53_semantic.py = v8 验证器 + 事件流提取器（事件日志 + try/finally 逐候选回滚协议 + 注册 journal）；6822/6822 包全量语义事件流（nd=10963/fr=8089/cr=4048/me=4038/pr=2688/cl=1077/ro=10）。
2. **严格回滚模式 0 次污染回退**：sem=6776 与 v8 Pass1 逐包一致——v8 接受集不依赖注册污染，节点表语义干净。
3. **帧 class 分布 {0:7005, 1:1077, 2:5, 5:2}**：class4/6（updateNode）本语料零出现——0x32 纯创建流，节点更新走 0x24/0x07（通道分工定案）。
4. **方法段 pk=3882（96.1%）引擎真模型主导**；ln=156（3.9%）胜出包吸收内容为层级串/prefab 路径——ln 定性为低置信分段。
5. **hier 载荷升级**：867 层级槽位表/4472 槽位（gun/hull/chassis/turret/compositionRootSlot×856 + gun1×78 双管 + rocket_joint/SightPointer/HP_loaders/HP_pod/crest_module 变体），与 t44 字典 104 例逐位一致。
6. **六族语义读取器全命中**：123 花名册（300 记录精确）/51 OwnVehicle（ov0/ov1/ov18 全元素）/112 订阅/127 附着链/54 队伍槽位/104 FLOAT 数组。

核心突破（Task 54）：
7. **★★★★方法ID机制全解（BigWorld 14.4 源码级）**：ExposedMethodsSortHelper + method_description::streamSize——方法槽序 = stable_sort(streamSize)，定长参数和升序在前、变长桶在后（-vlh=1 幅值升序，相等即声明序）；mid = 重载合并声明表序号（13 声明→11 唯一名=网络 11 槽）；组件方法不加 EntityID+4。
8. **OwnVehicle 预测槽序 (4,9,10,2,3,1,5,6,0,7,8) 与实测 10/10 包逐位一致**——mid→名映射全表导出（0=onBattleEvents…10=beforeSetupUpdate），静态可推导。
9. **t49 字典方法漏收修复**：127 def 全保真重提（属性+方法全名+参数类型+attrs；OwnVehicle def 23 属性=网络 np_=23 ✓，13 方法声明→去重 11=网络 11 槽，重载合并实锤）。
10. **★服务端≠客户端 def 漂移组件侧首证**：51/123/128 完美匹配 vs 106/121/150/154 漂移（121=SequenceNetworkSync 服务端 3+3 vs 客户端 5+3，呼应实体侧 TeamInfo+3）；np 搜索偏置确认（v8 从小 np 试起=ln 伪影根源）。
"""
z.writestr('README.md', readme_add)
audit = {
 "version": "v31",
 "date": "2026-09-26",
 "task": "Task 53: 语义标注器(100% 文法→语义级事件流) + Task 54: 组件方法ID机制源码级闭环 + def 全表重提 + tid→def 匹配器",
 "headline": [
  "★★★ 语义标注器闭环: 6822/6822 包全量语义事件流(nd=10963/fr=8089/cr=4048/me=4038/pr=2688/cl=1077/ro=10); 事件日志+try/finally 逐候选回滚协议+注册 journal",
  "★ 严格回滚模式 0 次污染回退: sem=6776 与 v8 Pass1 逐包一致——v8 接受集不依赖注册污染",
  "★ 帧 class 分布 {0:7005,1:1077,2:5,5:2}: class4/6(updateNode) 零出现——0x32 纯创建流, 节点更新走 0x24/0x07(通道分工定案)",
  "★ 方法段 pk=3882(96.1%) 引擎真模型主导; ln=156(3.9%)吸收层级串/prefab 路径——ln 定性低置信分段",
  "★ hier 载荷升级: 867 层级槽位表/4472 槽位(gun1×78 双管+rocket_joint/SightPointer/HP_loaders/HP_pod/crest_module), 与 t44 字典逐位一致",
  "★★★★ 方法ID机制源码级全解: 槽序=stable_sort(streamSize) 定长升序→变长桶(-vlh=1); mid=重载合并声明序号; 组件方法不加 EntityID+4",
  "★ OwnVehicle 预测槽序 (4,9,10,2,3,1,5,6,0,7,8) == 实测 10/10 逐位一致; mid→名映射全表静态可推导",
  "★ 127 def 全保真重提(方法参数修复); tid→def 匹配器 v1(np 硬约束+方法排序序列验证+名称锚点)",
  "★ 服务端≠客户端 def 漂移组件侧首证: 51/123/128 完美 vs 106/121/150/154 漂移(121=SequenceNetworkSync 3+3 vs 5+3)"
 ],
 "coverage": {
  "scope": "随机战(bt=1, 10场)",
  "0x32": "分帧层 100% + 创建体文法层 100.00% (6822/6822) + 语义级事件流 100% (语义标注器)",
  "0x32_0x37_overall": "~99%",
  "method_id": "组件方法ID: 源码级机制闭环 + OwnVehicle 10/10 验证 + 127 def 全表 + tid→def 匹配 v1(3 完美+4 漂移)"
 }
}
z.writestr('audit_v31.json', json.dumps(audit, ensure_ascii=False, indent=1))
z.close()

md5 = hashlib.md5(open(OUT, 'rb').read()).hexdigest()
sz = os.path.getsize(OUT)
n = len(zipfile.ZipFile(OUT).namelist())
print(f'V31 打包完成: {n} 文件, {sz:,}B, md5={md5}')

# 3) testzip 完整性
zf = zipfile.ZipFile(OUT)
assert zf.testzip() is None, 'testzip FAIL'
print('testzip PASS')
# 增量文件抽验
names = zf.namelist()
for must in ['data_v34/语义标注全事件流_t53.jsonl', 'data_v34/组件def全表_127def方法参数修复_t54.json',
             'data_v34/tid到def匹配表v1_t54.json', 'scripts/t53_semantic.py', 'scripts/t54_mids.py',
             'findings.md', 'worklog.md', 'README.md', 'audit_v31.json']:
    assert must in names, f'缺 {must}'
print('增量清单抽验 PASS (data_v34×6 + t53/t54×5 + 主文档×4)')

# 4) upload 备份
os.makedirs('/home/z/my-project/upload/backup_v31', exist_ok=True)
shutil.copy(OUT, '/home/z/my-project/upload/backup_v31/')
shutil.copy('/home/z/my-project/findings.md', '/home/z/my-project/upload/backup_v31/')
shutil.copy('/home/z/my-project/worklog.md', '/home/z/my-project/upload/backup_v31/')
open('/home/z/my-project/upload/backup_v31/audit_v31.json', 'w').write(json.dumps(audit, ensure_ascii=False, indent=1))
shutil.copy('/home/z/my-project/findings.md', '/home/z/my-project/upload/findings.md')
shutil.copy('/home/z/my-project/worklog.md', '/home/z/my-project/upload/worklog.md')
print('upload/backup_v31 备份完成')

# 5) 三处一致性自检
h = lambda p: hashlib.md5(open(p, 'rb').read()).hexdigest()
print('findings 三处一致:',
      h('/home/z/my-project/findings.md') == h('/home/z/my-project/upload/findings.md'),
      '| 包内:', hashlib.md5(zipfile.ZipFile(OUT).read('findings.md')).hexdigest() == h('/home/z/my-project/findings.md'))
