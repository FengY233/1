#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""csi_tables.py — 生成全部 40 实体的 CS 属性 csi 权威表 → download/csi_tables_v8.json"""
import json
import sys

sys.path.insert(0, '/home/z/my-project/scripts')
import digest_v8 as D8

TARGETS = sys.argv[1:] if len(sys.argv) > 1 else None

out = {
    '说明': ('WoT 2.4.0 服务器 entity_defs 全量 csi 表 (v8)。 '
             'csi = clientServerFullIndex, 经 allocateClientServerFullIndexes '
             '稳定排序: 定长属性按 streamSize 升序在前, 变长按 VLH 字节数在后。 '
             '回放 0x07/0x24 块的 topLevelIndex 即此表 csi (selectEntity 目标实体)。 '
             '已与实测 11 锚点全部吻合: Vehicle 4=siegeState/13=gunAnglesPacked/14=health/'
             '15=engineMode/16=avatarID/23=stunInfo/33=perkEffects/34=perks; '
             'Avatar 10=ownVehicleGear/19=ownVehicleAuxPhysicsData。'),
    '规则': {
        '累积序': 'Parent链 → Implements按声明序(各自递归,不跟随接口Parent) → 自有Properties',
        'CS判定': 'flags & (OTHER_CLIENT 0x02 | OWN_CLIENT 0x04 | REPLAY 0x100)',
        'csi排序': '稳定排序 key=(0,streamSize) 定长 / (1,vlhBytes) 变长; streamSize=类型宽度,变长=-VLH',
        '勘误v5': 'csi23=stunInfo(非damageStickers, 8B定长STUN_INFO); '
                  'csi1=isStrafing(原"移动标志",语义待细化: 值=1与10Hz移动更新相关)',
    },
    'entities': {},
}

ents = TARGETS or D8.entity_list()
for ename in ents:
    props, methods = D8.accumulate(ename)
    final, is_cs, csi_map, stream_size_of = D8.finalize_entity(props)
    rows = []
    for i, p in enumerate(final):
        if is_cs(p):
            rows.append({
                'csi': csi_map[i],
                'name': p['name'],
                'streamSize': stream_size_of(p),
                'flags': p['flags'],
                'source': p['source'],
            })
    rows.sort(key=lambda r: r['csi'])
    out['entities'][ename] = {
        'cs_property_count': len(rows),
        'properties': rows,
    }

path = '/home/z/my-project/download/csi_tables_v8.json'
with open(path, 'w', encoding='utf-8') as f:
    json.dump(out, f, ensure_ascii=False, indent=1)
print('已写入', path)
print('实体数:', len(out['entities']))
for e, d in out['entities'].items():
    print('  %-32s %d CS 属性' % (e, d['cs_property_count']))
