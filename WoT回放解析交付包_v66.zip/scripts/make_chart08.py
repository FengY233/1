# -*- coding: utf-8 -*-
"""make_chart08.py — 图08: 瞄准圈轨迹 (v6 播放捕获解锁的 0x26 gun marker 数据)
左: 地图俯视 — 瞄准点轨迹(时间渐变) + 玩家车轨迹 + 车辆分布
右: 瞄准点与车辆距离/高度随时间 — 显示瞄准节奏与地形跟随
"""
import json
import os
import sys
import struct
import collections

import matplotlib
import matplotlib.font_manager as fm

fm.fontManager.addfont('/usr/share/fonts/truetype/chinese/SarasaMonoSC-Regular.ttf')
fm.fontManager.addfont('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')

import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import numpy as np

plt.rcParams.update({
    'font.sans-serif': ['Sarasa Mono SC', 'DejaVu Sans'],
    'axes.unicode_minus': False,
    'figure.facecolor': '#FFFFFF', 'axes.facecolor': '#FFFFFF',
    'axes.edgecolor': '#E5E7EB', 'axes.linewidth': 0.8,
    'axes.spines.top': False, 'axes.spines.right': False,
    'axes.grid': False,
    'xtick.major.size': 0, 'ytick.major.size': 0,
    'xtick.labelsize': 9, 'ytick.labelsize': 9,
    'axes.labelsize': 10, 'axes.titlesize': 15, 'axes.titleweight': 'bold', 'axes.titlepad': 14,
    'legend.frameon': False, 'legend.fontsize': 9,
    'figure.dpi': 200, 'savefig.dpi': 200, 'savefig.facecolor': '#FFFFFF',
})

C_BLUE, C_CYAN, C_PURPLE, C_AMBER, C_RED, C_GREEN = '#3B82F6', '#06B6D4', '#8B5CF6', '#F59E0B', '#EF4444', '#10B981'
G900, G700, G500, G400, G300, G200, G100 = '#111827', '#374151', '#6B7280', '#9CA3AF', '#D1D5DB', '#E5E7EB', '#F3F4F6'
OUT = '/home/z/my-project/download/charts'
os.makedirs(OUT, exist_ok=True)

sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

R = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
lines = [json.loads(l) for l in open('/home/z/my-project/upload/replay.jsonl') if l.strip()]

def f32(u):
    return struct.unpack('<f', struct.pack('<I', u))[0]

p16 = sorted((f32(p[1]), struct.unpack('<I', p[2][:4])[0]) for p in R.pkts if p[0] == 0x16)
t_p3 = min(c for c, per in p16 if per == 3)

# 数据: 0x26 瞄准圈 + 0x0A 车辆轨迹 + 车辆初始位置
aim = []
veh = []
veh_init = {}
for (ty, clock, payload, idx), d in zip(R.pkts, lines):
    t = f32(clock)
    if ty == 0x26 and 'pos' in d:
        aim.append((t, d['pos'][0], d['pos'][1], d['pos'][2]))
    elif ty == 0x0A and 'pos' in d:
        eid = d['eid']
        if eid == 546611525:
            veh.append((t, d['pos'][0], d['pos'][2]))
        if eid not in veh_init:
            veh_init[eid] = (d['pos'][0], d['pos'][2])

aim = [a for a in aim if a[0] >= t_p3]  # 战斗段
A = np.array([(a[1], a[3]) for a in aim])
At = np.array([a[0] - t_p3 for a in aim])
Ay = np.array([a[2] for a in aim])
V = np.array([(v[1], v[2]) for v in veh if v[0] >= t_p3])
Vt = np.array([v[0] - t_p3 for v in veh if v[0] >= t_p3])

# 距离序列
import bisect
dists = []
for i, a in enumerate(aim):
    j = bisect.bisect_left([v[0] for v in veh], a[0])
    if j < len(veh):
        dx = a[1] - veh[j][1]
        dz = a[3] - veh[j][2]
        dists.append((a[0] - t_p3, (dx * dx + dz * dz) ** 0.5))
DT = np.array([d[0] for d in dists])
DV = np.array([d[1] for d in dists])

fig = plt.figure(figsize=(13.6, 6.4), constrained_layout=True)
gs = fig.add_gridspec(2, 2, width_ratios=[1.15, 1], height_ratios=[1, 1])

# ---- 左: 地图俯视 ----
ax = fig.add_subplot(gs[:, 0])
sc = ax.scatter(A[:, 0], A[:, 1], c=At, cmap='viridis', s=7, alpha=0.55, linewidths=0, zorder=3)
ax.plot(V[:, 0], V[:, 1], color=C_RED, lw=2.0, alpha=0.9, zorder=4, label='玩家车辆轨迹 (0x0A)')
others = [(x, z) for eid, (x, z) in veh_init.items() if 546611517 <= eid <= 546611546 and eid != 546611525]
ox = [p[0] for p in others]; oz = [p[1] for p in others]
ax.scatter(ox, oz, marker='s', s=26, facecolors='none', edgecolors=G500, linewidths=1.0, zorder=2, label='其他29辆初始位')
cb = fig.colorbar(sc, ax=ax, shrink=0.85, pad=0.02)
cb.set_label('游戏时间 (s)', fontsize=9)
cb.outline.set_edgecolor(G300)
ax.set_xlabel('X (m)')
ax.set_ylabel('Z (m)')
ax.set_title('瞄准圈轨迹 — 0x26 gun marker（5,107 点, 战斗段）', loc='left')
ax.set_aspect('equal')
ax.grid(True, color=G100, lw=0.7)
for s_ in ('top', 'right'):
    ax.spines[s_].set_visible(False)
ax.legend(loc='lower left', fontsize=9)

# 标注开局/收官
if len(A):
    ax.annotate('开局瞄准区', xy=(A[0, 0], A[0, 1]), xytext=(10, -22), textcoords='offset points',
                fontsize=8.5, color=G700,
                arrowprops=dict(arrowstyle='-', color=G400, lw=0.8))

# ---- 右上: 距离 ----
ax2 = fig.add_subplot(gs[0, 1])
ax2.scatter(DT, DV, s=4, color=C_BLUE, alpha=0.35, linewidths=0)
# 滑动中位
w = 60
med = []
for k in range(0, len(DT), 30):
    seg = DV[(DT >= DT[k]) & (DT < DT[k] + 30)]
    if len(seg):
        med.append((DT[k] + 15, np.median(seg)))
ax2.plot([m[0] for m in med], [m[1] for m in med], color=C_AMBER, lw=2.0, label='30s 窗口中位')
ax2.set_xlabel('游戏时间 (s)')
ax2.set_ylabel('瞄准点—车辆距离 (m)')
ax2.set_title('瞄准距离节奏 — 火炮由近及远再收缩', loc='left')
ax2.grid(True, color=G100, lw=0.7)
ax2.legend(loc='upper right')

# ---- 右下: 瞄准点高度(地形) ----
ax3 = fig.add_subplot(gs[1, 1])
ax3.scatter(At, Ay, s=4, color=C_GREEN, alpha=0.35, linewidths=0)
w = 60
med3 = []
for k in range(0, len(At), 30):
    seg = Ay[(At >= At[k]) & (At < At[k] + 30)]
    if len(seg):
        med3.append((At[k] + 15, np.median(seg)))
ax3.plot([m[0] for m in med3], [m[1] for m in med3], color=C_PURPLE, lw=2.0, label='30s 窗口中位')
ax3.set_xlabel('游戏时间 (s)')
ax3.set_ylabel('瞄准点高度 Y (m)')
ax3.set_title('瞄准点高度 = 地形高程采样（-24~106m）', loc='left')
ax3.grid(True, color=G100, lw=0.7)
ax3.legend(loc='upper right')

fig.suptitle('图08 · 瞄准圈(gun marker)轨迹还原 — 播放捕获 replay.jsonl 交叉验证 (v6)', fontsize=16, fontweight='bold', x=0.02, ha='left')
fig.get_layout_engine().set(rect=(0, 0, 1, 0.94))
fig.savefig(f'{OUT}/08_瞄准圈轨迹.png')
print('saved:', f'{OUT}/08_瞄准圈轨迹.png')
print('aim points (battle):', len(aim), ' range X', A[:, 0].min(), A[:, 0].max(), 'Z', A[:, 1].min(), A[:, 1].max())
