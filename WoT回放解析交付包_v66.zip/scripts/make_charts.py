# -*- coding: utf-8 -*-
"""make_charts.py — 生成回放分析图表(遵循 charts 技能 matplotlib 规范)"""
import json
import os
import struct
import sys
from collections import Counter, defaultdict

import matplotlib
import matplotlib.font_manager as fm

fm.fontManager.addfont('/usr/share/fonts/truetype/chinese/SarasaMonoSC-Regular.ttf')
fm.fontManager.addfont('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')

import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np

plt.rcParams.update({
    'font.sans-serif': ['Sarasa Mono SC', 'DejaVu Sans'],
    'axes.unicode_minus': False,
    'figure.facecolor': '#FFFFFF', 'axes.facecolor': '#FFFFFF',
    'axes.edgecolor': '#E5E7EB', 'axes.linewidth': 0.8,
    'axes.spines.top': False, 'axes.spines.right': False,
    'axes.grid': False,
    'xtick.major.size': 0, 'ytick.major.size': 0,
    'xtick.labelsize': 9, 'ytick.labelsize': 9,
    'axes.labelsize': 10, 'axes.titlesize': 15, 'axes.titleweight': 'bold', 'axes.titlepad': 14,
    'legend.frameon': False, 'legend.fontsize': 9,
    'figure.dpi': 200, 'savefig.dpi': 200, 'savefig.facecolor': '#FFFFFF',
})

C_BLUE, C_CYAN, C_PURPLE, C_AMBER, C_RED, C_GREEN = '#3B82F6', '#06B6D4', '#8B5CF6', '#F59E0B', '#EF4444', '#10B981'
G900, G700, G500, G400, G300, G200, G100, G50 = '#111827', '#374151', '#6B7280', '#9CA3AF', '#D1D5DB', '#E5E7EB', '#F3F4F6', '#F9FAFB'

OUT = '/home/z/my-project/download/charts'
os.makedirs(OUT, exist_ok=True)

sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

R = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
pkts = R.pkts
d = json.load(open('/home/z/my-project/work/decoded_full.json', encoding='utf-8'))

periods = {}
for p in pkts:
    if p[0] == 0x16:
        (v,) = struct.unpack('<I', p[2])
        periods[v] = p[1]
p2, p3, p4 = periods[2], periods[3], periods[4]

TYPE_NAMES = {
    0x0: '0x00 创建玩家Avatar(含arenaExtraData)', 0x1: '0x01 controlEntity控制实体',
    0x2: '0x02 选择实体', 0x4: '0x04 实体离开视野leaveAoI', 0x5: '0x05 创建实体createEntity',
    0x6: '0x06 实体全量数据', 0x7: '0x07 切片属性更新', 0x8: '0x08 属性更新(含pickle)',
    0xA: '0x0A 位置更新avatarUpdate', 0xD: '0x0D 空间数据spaceData', 0xF: '0x0F 空间几何映射',
    0x11: '0x11 战斗结果battleResults', 0x12: '0x12 录制启动标记', 0x15: '0x15 时间基',
    0x16: '0x16 战斗阶段arenaPeriod', 0x17: '0x17 阶段倒计时', 0x18: '0x18 客户端版本串',
    0x1A: '0x1A 观察者/相机更新', 0x1B: '0x1B 相机模式串', 0x1C: '0x1C 输入/视角增量A',
    0x1D: '0x1D 输入/视角增量B', 0x1E: '0x1E 状态标记', 0x1F: '0x1F 性能统计(fps/ping)',
    0x20: '0x20 相机朝向参数', 0x22: '0x22 玩家车辆ID标记', 0x24: '0x24 属性变更entityProperty',
    0x26: '0x26 本地车辆快照', 0x2B: '0x2B 标记', 0x2D: '0x2D 构建串',
    0x2E: '0x2E 标记', 0x30: '0x30 脚本目录串', 0x31: '0x31 客户端回调(callbackData)',
    0x32: '0x32 组件消息(实体可视/载具表)', 0x35: '0x35 空标记', 0x36: '0x36 游戏tick标记',
    0x37: '0x37 NRL节点更新(视觉)', 0x3D: '0x3D 实体定义哈希',
    0xFFFFFFFF: '0xFFFFFFFF 流结束符(校验)',
}


def save(fig, path):
    fig.savefig(path, dpi=200, facecolor='white')
    plt.close(fig)
    print('✅', path, '(%.0fKB)' % (os.path.getsize(path) / 1024))


# ═══ 图1: 包类型分布 ═══
census = Counter(p[0] for p in pkts)
items = census.most_common()
labels = [TYPE_NAMES.get(t, '0x%02X 未知' % t) for t, _ in items][::-1]
values = [c for _, c in items][::-1]

fig, ax = plt.subplots(figsize=(11, 12), constrained_layout=True)
colors = []
for t, _ in items[::-1]:
    if t == 0xA:
        colors.append(C_BLUE)
    elif t in (0x7, 0x1A, 0x36):
        colors.append('#93C5FD')
    else:
        colors.append(G300)
bars = ax.barh(range(len(values)), values, color=colors, height=0.62, zorder=3)
ax.set_xscale('log')
for i, (bar, val) in enumerate(zip(bars, values)):
    ax.text(bar.get_width() * 1.15, bar.get_y() + bar.get_height() / 2,
            '{:,}'.format(val), va='center', fontsize=9,
            color=G900 if values[i] > 1000 else G400)
ax.set_yticks(range(len(labels)))
ax.set_yticklabels(labels, fontsize=9)
ax.set_xlim(0.5, 300000)
ax.set_title('回放包类型分布（156,482 个网络包，对数轴）', loc='left')
ax.set_xlabel('包数量（对数刻度）')
ax.xaxis.grid(True, alpha=0.08, color=G300)
ax.set_axisbelow(True)
save(fig, OUT + '/01_包类型分布.png')

# ═══ 图2: 战斗时间线（游戏秒）═══
# 每游戏秒包速率 + 阶段 + 死亡
ticks = 0
rate = defaultdict(int)
for p in pkts:
    if p3 <= p[1] < p4:
        if p[0] == 0x36:
            ticks += 1
        rate[int(ticks / 10)] += 1
ts = sorted(rate)
rs = [rate[t] for t in ts]

fig, ax = plt.subplots(figsize=(13, 5.5), constrained_layout=True)
ax.plot(ts, rs, color=C_BLUE, linewidth=1.2, zorder=3)
ax.fill_between(ts, 0, rs, alpha=0.08, color=C_BLUE)
ax.set_xlim(0, 612)
ax.set_xlabel('战斗游戏时间（秒）')
ax.set_ylabel('每秒包数')
ax.set_title('战斗期间网络包速率时间线（服务器10Hz游戏tick驱动）', loc='left')
ax.yaxis.grid(True, alpha=0.08, color=G300)
ax.set_axisbelow(True)

# 死亡标记
data = open('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay', 'rb').read()
magic, bc = struct.unpack_from('<II', data, 0)
pos = 8
blocks = []
for _ in range(bc):
    (blen,) = struct.unpack_from('<I', data, pos)
    blocks.append(data[pos + 4:pos + 4 + blen])
    pos += 4 + blen
j1 = json.loads(blocks[1].decode('utf-8'))
r0 = j1[0]
veh_info = {int(k): v for k, v in d['header_json']['vehicles'].items()}
name_by = {vid: v['name'] for vid, v in veh_info.items()}
tracks = {int(k): v for k, v in d['vehicle_tracks'].items()}
last_seen = {vid: tr[-1][0] for vid, tr in tracks.items() if tr}
deaths = []
for vid_str, recs in r0['vehicles'].items():
    vid = int(vid_str)
    rec = recs[-1]
    if rec.get('deathReason', -1) >= 0 and vid in last_seen:
        deaths.append((last_seen[vid], veh_info[vid]['team'], name_by[vid]))
ymax = max(rs) * 1.15
for t, team, nm in deaths:
    ax.plot([t], [ymax * 0.98], marker='v' if team == 1 else '^',
            color=C_RED if team == 1 else C_GREEN, markersize=7, zorder=4,
            linestyle='none', clip_on=False)
ax.set_ylim(0, ymax)
ax.plot([], [], marker='v', color=C_RED, linestyle='none', label='队伍1(败)阵亡 ×%d' % sum(1 for x in deaths if x[1] == 1))
ax.plot([], [], marker='^', color=C_GREEN, linestyle='none', label='队伍2(胜)阵亡 ×%d' % sum(1 for x in deaths if x[1] == 2))
ax.legend(loc='upper right')
save(fig, OUT + '/02_战斗时间线.png')

# ═══ 图3: 玩家轨迹 + 全部车辆散点 ═══
fig, ax = plt.subplots(figsize=(9, 9), constrained_layout=True)
for vid, tr in tracks.items():
    if not tr:
        continue
    xs = [p[1] for p in tr]
    zs = [p[3] for p in tr]
    tm = veh_info[vid]['team']
    if vid == 546611525:
        continue
    ax.scatter(xs, zs, s=1.5, alpha=0.25, color=C_RED if tm == 1 else C_GREEN, zorder=2)
me = tracks.get(546611525, [])
mx = [p[1] for p in me]
mz = [p[3] for p in me]
ax.plot(mx, mz, color=C_BLUE, linewidth=2.0, zorder=4, alpha=0.9)
ax.scatter([mx[0]], [mz[0]], marker='o', s=90, color=C_BLUE, zorder=5, edgecolor='white', linewidth=1.5)
ax.scatter([mx[-1]], [mz[-1]], marker='s', s=90, color=C_PURPLE, zorder=5, edgecolor='white', linewidth=1.5)
ax.annotate('出生点', (mx[0], mz[0]), textcoords='offset points', xytext=(10, 8), fontsize=10, color=G700)
ax.annotate('终点', (mx[-1], mz[-1]), textcoords='offset points', xytext=(10, -14), fontsize=10, color=G700)
ax.set_title('地图 37_caucasus（胜利之门）车辆位置分布与玩家轨迹', loc='left')
ax.set_xlabel('X 坐标（米）')
ax.set_ylabel('Z 坐标（米）')
ax.scatter([], [], s=12, color=C_RED, label='队伍1 车辆位置样本')
ax.scatter([], [], s=12, color=C_GREEN, label='队伍2 车辆位置样本')
ax.plot([], [], color=C_BLUE, linewidth=2, label='玩家(261工程)移动轨迹')
ax.legend(loc='upper left', bbox_to_anchor=(1.02, 1))
ax.set_aspect('equal')
save(fig, OUT + '/03_玩家轨迹与车辆分布.png')

# ═══ 图4: 性能统计与播放速度 ═══
fig, axes = plt.subplots(2, 1, figsize=(12, 8), constrained_layout=True)
ax = axes[0]
fps_pts, ping_pts = [], []
for p in pkts:
    if p[0] != 0x1F:
        continue
    (v,) = struct.unpack('<I', p[2])
    fps = v & 0xFF
    ping = (v >> 8) & 0x3FFFF
    lag = (v & 0xFF000000) != 0
    t = (p[1] - p3) / 57475.0
    fps_pts.append((t, fps))
    ping_pts.append((t, min(ping, 999)))
fps_pts.sort()
ping_pts.sort()
ax.plot([x for x, _ in fps_pts], [y for _, y in fps_pts], color=C_GREEN, linewidth=1.0, label='fps（0x1F 低字节）')
ax.plot([x for x, _ in ping_pts], [y for _, y in ping_pts], color=C_AMBER, linewidth=1.0, alpha=0.85, label='ping·ms（0x1F 位8-17）')
ax.axvline(0, color=G300, linewidth=0.8, linestyle='--')
ax.set_xlabel('战斗时间（秒，按墙钟换算）')
ax.set_ylabel('fps / ping(ms)')
ax.set_title('客户端性能统计（0x1F 包, 共 6,321 帧）', loc='left')
ax.legend(loc='upper right')
ax.yaxis.grid(True, alpha=0.08, color=G300)
ax.set_axisbelow(True)

ax = axes[1]
a = [p[1] for p in pkts if p[0] == 0x1A and p[1] > p3]
ds = [b - c for c, b in zip(a, a[1:]) if b > c]
speeds = [100000.0 / x for x in ds]  # 0.1s游戏tick / wall秒 → 倍速
bins = [0, 0.6, 1.4, 3, 6, 11, 22, 44, 90, 200]
labels_s = ['~0.5x', '~1x', '~2-4x', '~4-8x', '~8-16x', '~16-32x', '~32-64x', '~64-128x', '>128x']
cnt, _ = np.histogram(speeds, bins=bins)
colors_s = [G300] * len(cnt)
mi = int(np.argmax(cnt))
colors_s[mi] = C_BLUE
bars = ax.bar(range(len(cnt)), cnt, color=colors_s, width=0.62, zorder=3)
for i, (b, v) in enumerate(zip(bars, cnt)):
    if v > 0:
        ax.text(b.get_x() + b.get_width() / 2, v + max(cnt) * 0.02, '{:,}'.format(v),
                ha='center', va='bottom', fontsize=9, color=G900 if i == mi else G400)
ax.set_xticks(range(len(cnt)))
ax.set_xticklabels(labels_s)
ax.set_ylim(0, max(cnt) * 1.18)
ax.set_title('推断的回放观看倍速分布（0x1A 相邻间隔 = 0.1s游戏时间 ÷ 墙钟间隔）', loc='left')
ax.set_ylabel('样本数')
ax.set_xlabel('播放倍速档位（2 的幂次簇）')
ax.yaxis.grid(True, alpha=0.08, color=G300)
ax.set_axisbelow(True)
save(fig, OUT + '/04_性能与播放速度.png')

# ═══ 图5: 伤害/击杀排行 ═══
rows = []
for vid_str, recs in r0['vehicles'].items():
    vid = int(vid_str)
    rec = recs[-1]
    rows.append({'name': veh_info[vid]['name'], 'team': veh_info[vid]['team'],
                 'vtype': veh_info[vid]['vehicleType'].split(':')[1],
                 'dmg': rec.get('damageDealt', 0), 'kills': rec.get('kills', 0),
                 'deathReason': rec.get('deathReason', -1)})
rows.sort(key=lambda r: r['dmg'])
fig, ax = plt.subplots(figsize=(10, 11), constrained_layout=True)
names = ['%s (%s)' % (r['name'][:10], r['vtype'][:14]) for r in rows]
vals = [r['dmg'] for r in rows]
cols = [(C_RED if r['team'] == 1 else C_GREEN) if r['deathReason'] < 0 else
        ('#FCA5A5' if r['team'] == 1 else '#86EFAC') for r in rows]
bars = ax.barh(range(len(vals)), vals, color=cols, height=0.62, zorder=3)
for i, (b, r) in enumerate(zip(bars, rows)):
    ax.text(b.get_width() + max(vals) * 0.012, b.get_y() + b.get_height() / 2,
            '%d  击杀%d%s' % (r['dmg'], r['kills'], ' 存活' if r['deathReason'] < 0 else ''),
            va='center', fontsize=8.5, color=G700)
ax.set_yticks(range(len(names)))
ax.set_yticklabels(names, fontsize=8.5)
ax.set_xlim(0, max(vals) * 1.22)
ax.set_title('全场 30 辆坦克伤害排行（队伍2 胜 15:10）', loc='left')
ax.set_xlabel('总伤害')
ax.xaxis.grid(True, alpha=0.08, color=G300)
ax.set_axisbelow(True)
save(fig, OUT + '/05_伤害排行.png')

print('全部图表完成')
