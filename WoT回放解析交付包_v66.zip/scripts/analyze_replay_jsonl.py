# -*- coding: utf-8 -*-
"""analyze_replay_jsonl.py — 播放时捕获的 replay.jsonl 与 wotreplay 包流的对账与榨取。

目的:
  1) 验证 jsonl 156,482 行与 wotreplay 156,482 包是否同一流 (type+clock 逐对)
  2) 尝试从 jsonl 字段重建 payload 字节, 与 wotreplay payload 对账 (body/rest/raw)
  3) 统计工具的解码知识: key 分布 / methodID 分布 / str 方法名 / v20 v32 tail 语义
  4) 检查 clk 是否 float32 秒 (v3 结论交叉验证)
"""
import json
import struct
import sys
import collections

sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

REPLAY = '/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay'
JSONL = '/home/z/my-project/upload/replay.jsonl'

print('== 加载 wotreplay ==')
rf = ReplayFile(REPLAY)
print('packets:', len(rf.pkts))

print('== 加载 replay.jsonl ==')
lines = []
with open(JSONL) as f:
    for line in f:
        line = line.strip()
        if line:
            lines.append(json.loads(line))
print('lines:', len(lines))

# ---------- 1) type+clock 序列对账 ----------
mismatch_t = 0
mismatch_c = 0
first_mm = None
for i, ((ty, clock, payload, idx), d) in enumerate(zip(rf.pkts, lines)):
    if d['t'] != ty:
        mismatch_t += 1
        if first_mm is None:
            first_mm = ('type', i, ty, d['t'])
    elif d['clk'] != clock:
        mismatch_c += 1
        if first_mm is None:
            first_mm = ('clock', i, clock, d['clk'])
print('type mismatch:', mismatch_t, ' clock mismatch:', mismatch_c, ' first:', first_mm)

# clk float32 抽样
def f32(u):
    return struct.unpack('<f', struct.pack('<I', u))[0]
samp = [0, 100, 2438, 10000, 50000, 100000, 156481]
for i in samp:
    ty, clock, payload, idx = rf.pkts[i]
    print(f'  pkt[{i}] type=0x{ty:X} clk={clock} float32={f32(clock):.4f}s jsonl_clk={lines[i]["clk"]}')

# ---------- 2) payload 重建对账 ----------
# 策略: jsonl 中 'body' 'rest' 'raw' 'hex' 都是 hex 字段; 直接拼不一定是全 payload
# 先看每类的 payload 长度 vs jsonl hex 字段长度
hexkeys = ['body', 'rest', 'raw', 'hex']
per_type_stat = collections.defaultdict(lambda: collections.Counter())
per_type_hexlen = collections.defaultdict(collections.Counter)
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    plen = len(payload)
    per_type_stat[ty]['n'] += 1
    # 拼接所有 hex 字段
    hexall = b''
    for k in hexkeys:
        v = d.get(k)
        if isinstance(v, str) and v:
            try:
                hexall += bytes.fromhex(v)
            except ValueError:
                pass
    per_type_stat[ty]['hexlen_eq'] += (len(hexall) == plen)
    per_type_stat[ty]['payload_len'] += plen
    per_type_stat[ty]['hex_len'] += len(hexall)
    per_type_hexlen[ty][plen - len(hexall)] += 1

print()
print('== payload 对账 (按类型) ==')
for ty in sorted(per_type_stat):
    st = per_type_stat[ty]
    n = st['n']
    eq = st['hexlen_eq']
    print(f'  0x{ty:02X}: n={n} hex全等={eq} payload总长={st["payload_len"]} hex总长={st["hex_len"]} 差值分布={dict(list(per_type_hexlen[ty].items())[:5])}')
