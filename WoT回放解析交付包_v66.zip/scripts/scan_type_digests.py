#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""scan_type_digests.py — 全 dump 扫描类型块 digest 函数（形状: begin(param_3,0)+cstr("name",X)+...+end）"""
import re
import os
import sys

ROOT = '/home/z/my-project/work/decomp/decomp/chunks'
hdr = re.compile(r'==== FUNC (0x[0-9a-f]+) (\S+) ====')
# 形状: (+0x18)(param_2,param_3,0) 后跟 (+0x68)(param_2,&DAT_1435d2d24,NAME)
pat_begin = re.compile(r'\(\*\*\(code \*\*\)\(\*param_2 \+ 0x18\)\)\(param_2,param_3,0\)')
pat_name = re.compile(r'\(\*\*\(code \*\*\)\(\*param_2 \+ 0x68\)\)\(param_2,&DAT_1435d2d24,([^)]+)\)')

results = []
for fn in sorted(os.listdir(ROOT)):
    if not fn.endswith('.c'):
        continue
    path = os.path.join(ROOT, fn)
    cur = None
    body = []
    try:
        with open(path, errors='replace') as f:
            for i, line in enumerate(f, 1):
                m = hdr.search(line)
                if m:
                    if cur and body:
                        text = ''.join(body)
                        if pat_begin.search(text):
                            nm = pat_name.search(text)
                            results.append((cur[0], fn, nm.group(1) if nm else '?'))
                    cur = (m.group(1), i)
                    body = []
                elif cur:
                    body.append(line)
        if cur and body:
            text = ''.join(body)
            if pat_begin.search(text):
                nm = pat_name.search(text)
                results.append((cur[0], fn, nm.group(1) if nm else '?'))
    except Exception as e:
        print('ERR', fn, e, file=sys.stderr)

print('形状匹配的类型块 digest 函数 (%d 个):' % len(results))
for addr, fn, name in sorted(results):
    print('  %s  %-18s name=%s' % (addr, fn, name))
