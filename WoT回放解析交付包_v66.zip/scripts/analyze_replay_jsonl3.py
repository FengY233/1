# -*- coding: utf-8 -*-
"""analyze_replay_jsonl3.py — 0x07 key 分布 vs v5 属性表 / 全部 str 方法名 / map 字段 /
   0x26 语义(相机vs炮弹) / 0x1A 与玩家轨迹对齐 / 0x04 语义 / 哈希暴破第二轮。
"""
import json
import struct
import sys
import hashlib
import collections

sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

REPLAY = '/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay'
JSONL = '/home/z/my-project/upload/replay.jsonl'

rf = ReplayFile(REPLAY)
lines = []
with open(JSONL) as f:
    for line in f:
        if line.strip():
            lines.append(json.loads(line))

def f32(u):
    return struct.unpack('<f', struct.pack('<I', u))[0]

# ---------- 1) 0x07 key 分布 ----------
keyc = collections.Counter()
key_eid = collections.Counter()
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    if ty == 0x07:
        keyc[d['key']] += 1
        key_eid[(d['key'], d['eid'])] += 1
print('== 0x07 key 分布 (对照 v5: 1=移动 4=siege 10=gear 13=gunAngles 14=health 15=engineMode 16/33=死亡 19=auxPhysics 23=damageStickers 34=低频) ==')
for k, c in sorted(keyc.items()):
    eids = len([e for (kk, e) in key_eid if kk == k])
    print(f'  key={k:3d}: {c:6d} 次, {eids} 个实体')

# body 长度 per key
key_bodylen = collections.defaultdict(collections.Counter)
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    if ty == 0x07:
        key_bodylen[d['key']][d.get('len', 0)] += 1
print('key -> body长度分布:')
for k in sorted(key_bodylen):
    top = key_bodylen[k].most_common(4)
    print(f'  key={k:3d}: {top}')

# ---------- 2) 全部 str 值 ----------
print()
print('== 全部 str 值 (方法名/标识符) ==')
strc = collections.Counter()
str_type = {}
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    s = d.get('str')
    if s is not None:
        strc[s] += 1
        str_type.setdefault(s, ty)
for s, c in strc.most_common():
    print(f'  0x{str_type[s]:02X} x{c}: {s[:80]}')

# ---------- 3) map 字段 ----------
print()
print('== map / b / eid2 字段所在行 ==')
for i, ((ty, clock, payload, idx), d) in enumerate(zip(rf.pkts, lines)):
    if 'map' in d or 'b' in d or 'eid2' in d:
        print(f'  line {i} type 0x{ty:X}:', {k: (v[:100] if isinstance(v, str) else v) for k, v in d.items()})

# ---------- 4) 0x26 语义: 时间聚类 + 与炮弹数 ----------
print()
print('== 0x26 时间聚类 ==')
t26 = [f32(clock) for (ty, clock, p, i) in rf.pkts if ty == 0x26]
t26.sort()
gaps = [b - a for a, b in zip(t26, t26[1:])]
big = [g for g in gaps if g > 1.0]
print(f'n={len(t26)} 跨度 {t26[0]:.1f}..{t26[-1]:.1f}s 间隔>1s 的空档数={len(big)}')
cl = []
start = t26[0]
prev = t26[0]
for t in t26[1:]:
    if t - prev > 1.0:
        cl.append((start, prev))
        start = t
    prev = t
cl.append((start, prev))
print(f'聚类数={len(cl)} 前12个: {[(round(a,1), round(b,1)) for a, b in cl[:12]]}')
lens = [b - a for a, b in cl]
print(f'簇时长: min={min(lens):.2f}s max={max(lens):.2f}s 中位={sorted(lens)[len(lens)//2]:.2f}s')
# 每簇包数
import itertools
cnts = collections.Counter()
for t in t26:
    pass
# 简单: 用 gap 切分计数
c = 1
percluster = []
for g in gaps:
    if g > 1.0:
        percluster.append(c)
        c = 1
    else:
        c += 1
percluster.append(c)
print(f'每簇包数: min={min(percluster)} max={max(percluster)} 中位={sorted(percluster)[len(percluster)//2]}')

# 0x26 pos 值域
pos26 = []
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    if ty == 0x26 and 'pos' in d:
        pos26.append(d['pos'])
if pos26:
    xs = [p[0] for p in pos26]; ys = [p[1] for p in pos26]; zs = [p[2] for p in pos26]
    print(f'0x26 pos: x[{min(xs):.1f},{max(xs):.1f}] y[{min(ys):.4f},{max(ys):.4f}] z[{min(zs):.1f},{max(zs):.1f}]')

# 玩家车辆 0x0A 轨迹对照
ppos = []
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    if ty == 0x0A and d.get('eid') == 546611525 and 'pos' in d:
        ppos.append((f32(clock), d['pos']))
print(f'玩家车 0x0A 轨迹点数={len(ppos)} 前3: {[(round(t,1), [round(v,1) for v in p]) for t, p in ppos[:3]]}')

# 0x1A col0:3 vs 玩家轨迹
rows1a = []
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    if ty == 0x1A and 'f' in d and len(d['f']) == 15:
        rows1a.append((f32(clock), d['f']))
# 找 t 相近的配对
import bisect
tsp = [t for t, p in ppos]
match = 0
tot = 0
diffs = []
for t, f in rows1a:
    i = bisect.bisect_left(tsp, t)
    for j in (i - 1, i):
        if 0 <= j < len(tsp) and abs(tsp[j] - t) < 0.06:
            p = ppos[j][1]
            dd = ((f[0] - p[0])**2 + (f[2] - p[2])**2) ** 0.5
            diffs.append(dd)
            tot += 1
            if dd < 2.0:
                match += 1
            break
print(f'0x1A col0:3 与玩家车位置配对: {tot} 对, <2m 吻合 {match} ({100.0*match/max(tot,1):.1f}%) 中位差 {sorted(diffs)[len(diffs)//2] if diffs else -1:.2f}m')

# ---------- 5) 0x04 语义 ----------
print()
print('== 0x04 u32 值解析 ==')
u4 = collections.Counter()
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    if ty == 0x04:
        u4[d['u32']] += 1
print('0x04 u32 top12:', [(hex(v), c) for v, c in u4.most_common(12)])
# 高16/低16拆
hi = collections.Counter()
lo = collections.Counter()
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    if ty == 0x04:
        v = d['u32']
        hi[v >> 16] += 1
        lo[v & 0xFFFF] += 1
print('hi16 top8:', hi.most_common(8))
print('lo16 top8:', lo.most_common(8))

# ---------- 6) 哈希暴破第二轮 ----------
print()
print('== 0xFFFFFFFF 哈希暴破 R2 ==')
target = 'd509e348a47afab6e8afe4da6137178e'
cands = {}
cands['md5(stream[:-28])'] = hashlib.md5(rf.stream[:-28]).hexdigest()
cands['md5(stream[:pkt0])'] = hashlib.md5(rf.stream[:rf.pkts[0][3] and 0]).hexdigest() if False else None
dec = rf.decrypt_main(rf.main)
cands['md5(dec[:valid])'] = hashlib.md5(dec[:1834785]).hexdigest()
cands['md5(main[:valid])'] = hashlib.md5(rf.main[:1834785]).hexdigest()
cands['md5(blocks0)'] = hashlib.md5(rf.blocks[0]).hexdigest()
cands['md5(blocks1)'] = hashlib.md5(rf.blocks[1]).hexdigest()
cands['md5(blocks01)'] = hashlib.md5(rf.blocks[0] + rf.blocks[1]).hexdigest()
cands['md5(raw[:gap])'] = hashlib.md5(rf.raw[:rf.gap_pos]).hexdigest()
cands['md5(raw[:main])'] = hashlib.md5(rf.raw[:rf.main_pos]).hexdigest()
cands['md5(raw[gap:])'] = hashlib.md5(rf.raw[rf.gap_pos:]).hexdigest()
cands['sha1(stream)[:32]'] = hashlib.sha1(rf.stream).hexdigest()[:32]
cands['sha256(stream)[:32]'] = hashlib.sha256(rf.stream).hexdigest()[:32]
# stream 含 terminator 头不含 hash
last_off = len(rf.stream) - 28
cands['md5(stream[:last_off-0])'] = hashlib.md5(rf.stream[:last_off]).hexdigest()
# 头部+流
cands['md5(raw[:main]+stream)'] = hashlib.md5(rf.raw[:rf.main_pos] + rf.stream).hexdigest()
for k, v in cands.items():
    if v:
        print(f'  {k}: {v}{"  <== MATCH!" if v == target else ""}')
