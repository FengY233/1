#!/usr/bin/env python3
"""用 BigWorld vanilla spaceData 模板重新精解回放中的 0x0F 包
vanilla client_interface.hpp: spaceData = [u32 spaceID][SpaceEntryID 6B(u32 ip+u16 port)][u16 key][string value]
key=1 (MAPPING_CLIENT_SERVER) 的 value = [char path[]][f32 matrix[4][4]]
"""
import struct
import sys

sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

r = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
print(f"包数 {len(r.pkts)}")

targets = [p for p in r.pkts if p[0] == 0x0F]
print(f"0x0F 包数: {len(targets)}")

for ty, clock, payload, idx in targets:
    print(f"\n=== 0x0F pkt#{idx} clock_raw=0x{clock:08X} ({struct.unpack('<f', struct.pack('<I', clock))[0]:.3f}s) len={len(payload)} ===")
    print("hex:", payload.hex(' '))
    p = 0
    spaceID = struct.unpack_from('<I', payload, p)[0]; p += 4
    print(f"[u32 spaceID = {spaceID}]")
    if len(payload) >= p + 6:
        eip, eport = struct.unpack_from('<IH', payload, p)
        print(f"[SpaceEntryID 6B: ip=0x{eip:08X}({eip}) port={eport}] → {payload[p:p+6].hex(' ')}")
        p += 6
    if len(payload) >= p + 2:
        key = struct.unpack_from('<H', payload, p)[0]; p += 2
        print(f"[u16 key = {key}]")
    rest = payload[p:]
    print(f"[value {len(rest)}B]")
    print("  hex   :", rest.hex(' '))
    print("  ascii :", ''.join(chr(c) if 32 <= c < 127 else '.' for c in rest))
    # 若 value = NUL/长度定界 path + 16×f32
    # 尝试 NUL 定界
    nul = rest.find(b'\x00')
    print(f"  NUL@{nul}")
    # 尝试从尾部取 64B 矩阵
    if len(rest) >= 64:
        mats = struct.unpack_from('<16f', rest, len(rest) - 64)
        print("  尾部64B作16×f32:", ' '.join(f'{v:.3f}' for v in mats))
