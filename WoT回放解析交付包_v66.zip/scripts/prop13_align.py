# -*- coding: utf-8 -*-
"""prop13_align.py — 正确解析0x07 + 与jsonl速度/档位流时间对齐, 命名属性13/15"""
import sys, struct, collections, json
sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

r = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
PLAYER = 0x2094A145

# 1) 0x07 正确解析普查
prop_cnt = collections.Counter()
prop_len = collections.defaultdict(collections.Counter)
prop_vals = collections.defaultdict(collections.Counter)
player13, player15, player4 = [], [], []
bad = 0
for (t, clk, pl, i) in r.pkts:
    if t == 0x07:
        if len(pl) < 12: bad += 1; continue
        eid, prop, vlen = struct.unpack_from('<III', pl, 0)
        if 12 + vlen > len(pl): bad += 1; continue
        val = pl[12:12 + vlen]
        prop_cnt[prop] += 1
        prop_len[prop][vlen] += 1
        if vlen <= 4:
            prop_vals[prop][val.hex()] += 1
        if eid == PLAYER:
            fclk = struct.unpack('<f', struct.pack('<I', clk))[0] if clk < 0x7F800000 else clk
            if prop == 13: player13.append((fclk, val))
            elif prop == 15: player15.append((fclk, val))
            elif prop == 4: player4.append((fclk, val))

print('=== 0x07 属性普查(正确解析) ===')
for p, n in prop_cnt.most_common(20):
    lens = ', '.join('%dB×%d' % (L, c) for L, c in prop_len[p].most_common(3))
    tops = ', '.join('%s×%d' % (h, c) for h, c in prop_vals[p].most_common(3))
    print('属性%-3d %6d次  [%s]  值top: %s' % (p, n, lens, tops))
print('解析失败:', bad)

# 2) jsonl 速度/档位事件(玩家车)
speeds, cruises = [], []
for line in open('/home/z/my-project/upload/session_20260911_175934.jsonl', encoding='utf-8'):
    try: e = json.loads(line)
    except: continue
    if e.get('ev') == 'state.onVehicleStateUpdated':
        d = e['data']
        if d.get('state') == 64: speeds.append((d['bt'], d['value']))
        elif d.get('state') == 128: cruises.append((d['bt'], d['value']))

print()
print('jsonl 速度事件:', len(speeds), ' 档位事件:', len(cruises))
print('玩家车 prop13:', len(player13), ' prop15:', len(player15), ' prop4:', len(player4))

# 3) 时间对齐: 用 0x16 阶段变化(回放侧) 与 arena.onPeriodChange(jsonl侧) 校准
#    回放侧: 0x16 phase=3(战斗开始) clock; jsonl侧: period 3 的 bt
p3_clock = None
for (t, clk, pl, i) in r.pkts:
    if t == 0x16 and len(pl) >= 4:
        phase, = struct.unpack_from('<I', pl, 0)
        if phase == 3:
            p3_clock = struct.unpack('<f', struct.pack('<I', clk))[0]
            break
p3_bt = None
for line in open('/home/z/my-project/upload/session_20260911_175934.jsonl', encoding='utf-8'):
    if 'onPeriodChange' in line:
        e = json.loads(line)
        d = e.get('data', {})
        if d.get('period') == 3 or d.get('newPeriod') == 3:
            p3_bt = d.get('bt')
            break
print()
print('战斗开始: 回放 clock=%.3f | jsonl bt=%s' % (p3_clock, p3_bt))
if p3_bt is not None:
    offset = p3_clock - p3_bt  # clock = bt + offset
    print('偏移 clock-bt = %.3f' % offset)
    # 4) 对齐验证: prop13 值序列 vs jsonl 速度序列
    def lookup_speed(bt):
        best = None
        for b, v in speeds:
            if b <= bt + 0.05: best = (b, v)
            else: break
        return best
    print()
    print('=== 对齐样本: prop13(clk→bt, hex) vs jsonl速度 ===')
    import bisect
    sbts = [b for b, _ in speeds]
    shown = 0
    for fclk, val in player13:
        bt = fclk - offset
        j = bisect.bisect_right(sbts, bt) - 1
        if j >= 0 and shown < 25:
            sb, sv = speeds[j]
            dt = bt - sb
            u16 = struct.unpack('<H', val)[0] if len(val) == 2 else None
            i16 = struct.unpack('<h', val)[0] if len(val) == 2 else None
            f16a = struct.unpack('<e', val)[0] if len(val) == 2 else None
            print('clk=%8.2f bt=%8.2f prop13=%s u16=%-6d i16=%-6d f16=%-9.3f | jsonl speed=%-4s (dt=%.2fs)' %
                  (fclk, bt, val.hex(), u16 if u16 is not None else -1, i16 if i16 is not None else -1,
                   f16a if f16a is not None else -1, sv, dt))
            shown += 1
    # 5) prop15 vs 档位
    print()
    print('=== prop15 vs jsonl 档位 ===')
    cbts = [b for b, _ in cruises]
    shown = 0
    for fclk, val in player15:
        bt = fclk - offset
        j = bisect.bisect_right(cbts, bt) - 1
        if j >= 0 and shown < 15:
            cb, cv = cruises[j]
            print('clk=%8.2f prop15=%s | jsonl cruise=%s (dt=%.2f)' % (fclk, val.hex(), cv, bt - cb))
            shown += 1
