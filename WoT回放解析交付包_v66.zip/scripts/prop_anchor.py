# -*- coding: utf-8 -*-
"""prop_anchor.py — 全属性×jsonl序列自动锚定: 确定 0x07 每个属性索引的语义"""
import sys, struct, collections, json, bisect
sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

r = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
PLAYER = 0x2094A145
OFF = 34.240 - 139.769  # clock = bt + OFF

# ── 1. 回放侧: 每实体每属性的时间序列 ──
series = collections.defaultdict(list)   # (eid, prop) -> [(fclk, bytes)]
for (t, clk, pl, i) in r.pkts:
    if t == 0x07 and len(pl) >= 12:
        eid, prop, vlen = struct.unpack_from('<III', pl, 0)
        if 12 + vlen <= len(pl):
            fclk = struct.unpack('<f', struct.pack('<I', clk))[0]
            series[(eid, prop)].append((fclk, pl[12:12 + vlen]))

# eid -> avatarSessionID 映射(从块0 JSON)
hdr = json.loads(r.blocks[0].decode('utf-8', 'replace'))
eid2name = {}
for vehID, info in hdr.get('vehicles', {}).items():
    eid2name[int(vehID)] = info.get('name', '?')

# ── 2. jsonl 侧: 各序列(bt -> value) ──
own_gun, own_health, own_engine, own_siege, own_crew, own_started = [], [], [], [], [], []
health_events = []   # (bt, eid?, amount)
killed = []
siege_events = []
for line in open('/home/z/my-project/upload/session_20260911_175934.jsonl', encoding='utf-8'):
    try: e = json.loads(line)
    except: continue
    ev, d = e.get('ev'), e.get('data', {})
    bt = d.get('bt')
    if ev == 'battle_tick' and isinstance(d.get('own'), dict):
        o = d['own']
        own_gun.append((bt, o.get('gunAnglesPacked')))
        own_health.append((bt, o.get('health')))
        own_engine.append((bt, tuple(o.get('engineMode', ()))))
        own_siege.append((bt, o.get('siegeState')))
        own_crew.append((bt, o.get('isCrewActive')))
        own_started.append((bt, o.get('isStarted')))
    elif ev == 'arena.onVehicleHealthChanged':
        health_events.append((bt, d))
    elif ev == 'veh.onSiegeStateUpdated':
        siege_events.append((bt, d))

print('jsonl: own_gun=%d own_health=%d own_engine=%d own_siege=%d | 血量事件=%d siege=%d' %
      (len(own_gun), len(own_health), len(own_engine), len(own_siege), len(health_events), len(siege_events)))

def match_ratio(replay_seq, jsonl_seq, val_fn):
    """对齐后逐点比较: 返回(匹配数, 总数, 样本)"""
    jbts = [b for b, _ in jsonl_seq]
    ok = tot = 0
    samples = []
    for fclk, raw in replay_seq:
        bt = fclk - OFF
        j = bisect.bisect_right(jbts, bt + 0.12) - 1
        if j < 0: continue
        jb, jv = jsonl_seq[j]
        if bt - jb > 2.0: continue
        rv = val_fn(raw)
        tot += 1
        if rv == jv:
            ok += 1
        elif len(samples) < 6:
            samples.append((fclk, rv, jv, bt - jb))
    return ok, tot, samples

# ── 3. 属性13 = gunAnglesPacked 验证 ──
print()
print('=== prop13 == own.gunAnglesPacked? ===')
ok, tot, s = match_ratio(series[(PLAYER, 13)], own_gun, lambda b: struct.unpack('<H', b)[0])
print('匹配 %d/%d (%.1f%%)' % (ok, tot, 100.0 * ok / max(tot, 1)))
for fclk, rv, jv, dt in s[:4]: print('  clk=%.2f replay=%s jsonl=%s dt=%+.2f' % (fclk, rv, jv, dt))

# ── 4. 属性14 vs 血量事件 ──
print()
print('=== prop14(2B) 与 onVehicleHealthChanged ===')
print('血量事件样例:', json.dumps(health_events[0], ensure_ascii=False)[:200] if health_events else '无')
# 对全部车辆的 prop14 与血量事件对齐计数
h_by_time = [(bt, d) for bt, d in health_events]
prop14_total = sum(len(v) for (e, p), v in series.items() if p == 14)
print('prop14 总数=%d 血量事件总数=%d' % (prop14_total, len(health_events)))

# ── 5. 属性15 vs engineMode ──
print()
print('=== prop15(2B) vs own.engineMode ===')
ok, tot, s = match_ratio(series[(PLAYER, 15)], own_engine,
                         lambda b: (b[0], b[1]) if len(b) == 2 else None)
print('匹配 %d/%d (%.1f%%)' % (ok, tot, 100.0 * ok / max(tot, 1)))
for fclk, rv, jv, dt in s[:6]: print('  clk=%.2f replay=%s jsonl=%s dt=%+.2f' % (fclk, rv, jv, dt))

# ── 6. 其余属性: 玩家车的事件数与值变化模式 ──
print()
print('=== 玩家车全部属性概览 ===')
for (eid, prop), seq in sorted(series.items(), key=lambda kv: (kv[0][1], -len(kv[1]))):
    if eid != PLAYER: continue
    vals = [v for _, v in seq]
    uniq = len(set(v.hex() for v in vals))
    ex = vals[:3] + vals[-2:]
    print('prop%-3d %4d次 唯一值%-4d 样本: %s' % (prop, len(seq), uniq, [v.hex() for v in ex]))

# ── 7. 属性19(8B)解码为2×f32看看 ──
print()
print('=== prop19(8B) 解码 2×f32 (前12个, 玩家车) ===')
for fclk, v in series[(PLAYER, 19)][:12]:
    a, b2 = struct.unpack('<2f', v)
    print('  clk=%8.2f  (%10.4f, %10.4f)' % (fclk, a, b2))
print('=== prop23(8B) 解码 2×f32 (前8个) ===')
for fclk, v in series[(PLAYER, 23)][:8]:
    a, b2 = struct.unpack('<2f', v)
    print('  clk=%8.2f  (%10.4f, %10.4f)' % (fclk, a, b2))

# ── 8. 属性1(1B 0/1): 玩家车的时间分布 ──
print()
print('=== prop1 玩家车时间分布(前20) ===')
for fclk, v in series[(PLAYER, 1)][:20]:
    print('  clk=%8.2f val=%s' % (fclk, v.hex()))
