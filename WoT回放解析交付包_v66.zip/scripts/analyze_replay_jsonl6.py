# -*- coding: utf-8 -*-
"""analyze_replay_jsonl6.py — 0x11 全结构走查(多段zlib+校验和) + 0x3D 哈希候选 +
   0x26 坐标空间判定 + 0x1A 列语义精化 + 0x05 结构。
"""
import json
import struct
import sys
import zlib
import hashlib
import re
import collections
import statistics

sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

REPLAY = '/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay'
JSONL = '/home/z/my-project/upload/replay.jsonl'

rf = ReplayFile(REPLAY)
lines = []
with open(JSONL) as f:
    for line in f:
        if line.strip():
            lines.append(json.loads(line))

def f32(u):
    return struct.unpack('<f', struct.pack('<I', u))[0]

def f32b(b):
    return struct.unpack('<f', b)[0]

oneoff = {}
for ty, clock, payload, idx in rf.pkts:
    if ty not in oneoff:
        oneoff[ty] = payload

# ---------- 1) 0x11 全结构走查 ----------
print('== 0x11 (6699B) 全结构走查 ==')
p = oneoff[0x11]
print('[u16]', struct.unpack_from('<H', p, 0)[0])
print('[u32 @2]', struct.unpack_from('<I', p, 2)[0])
print('pickle 段 @6:', p[6:18].hex())
print('[u32 @18]:', struct.unpack_from('<I', p, 18)[0], hex(struct.unpack_from('<I', p, 18)[0]))
# 找所有 zlib 头 (78 xx, 校验合法)
zoffs = []
for i in range(len(p) - 1):
    if p[i] == 0x78:
        v = p[i] * 256 + p[i + 1]
        if v % 31 == 0 and (p[i + 1] & 0x20) == 0:
            zoffs.append(i)
print('合法 zlib 头偏移:', zoffs)
# 逐段解压
q = 0
seg = 0
all_dec = b''
for zo in zoffs:
    try:
        d = zlib.decompressobj()
        dec = d.decompress(p[zo:])
        used = len(p) - zo - len(d.unused_data)
        print(f'  段{seg}: @{zo} 压缩{used}B → 解压{len(dec)}B  未消费尾部{len(d.unused_data)}B')
        all_dec += dec
        # 内容指纹
        strs = re.findall(rb'[\x20-\x7e]{8,}', dec)
        keyws = [s for s in strs if any(k in s for k in (b'quest', b'XP', b'xp', b'bonus', b'credit', b'VEHICLE', b'kill', b'damage', b'team', b'player', b'common', b'personal'))]
        print(f'    关键词串 {len(keyws)} 个: {[s[:50] for s in keyws[:6]]}')
        seg += 1
    except Exception as e:
        print(f'  @{zo} 解压失败: {e}')
print(f'解压总计: {len(all_dec)}B')
open('/home/z/my-project/work/p11_full.bin', 'wb').write(all_dec)

# 校验和候选: 200528740
print()
print('== 校验和 200528740 候选 ==')
dec = all_dec
cands = {
    'adler32(all_dec)': zlib.adler32(dec) & 0xFFFFFFFF,
    'crc32(all_dec)': zlib.crc32(dec) & 0xFFFFFFFF,
    'adler32(p[22:])': zlib.adler32(p[22:]) & 0xFFFFFFFF,
    'crc32(p[22:])': zlib.crc32(p[22:]) & 0xFFFFFFFF,
    'adler32(p18_6699)': zlib.adler32(p[18:]) & 0xFFFFFFFF,
    'crc32(p18_6699)': zlib.crc32(p[18:]) & 0xFFFFFFFF,
}
for k, v in cands.items():
    print(f'  {k}: {v} {"<== 200528740 MATCH!" if v == 200528740 else ""}')

# ---------- 2) 0x3D 哈希候选 ----------
print()
print('== 0x3D "5DF886F75E73B33CFF9D87FB9C69389C" 候选 ==')
target = '5df886f75e73b33cff9d87fb9c69389c'
c2 = {
    'md5(all_dec)': hashlib.md5(all_dec).hexdigest(),
    'md5(p11)': hashlib.md5(p).hexdigest(),
    'md5(p6)': hashlib.md5(oneoff[0x06]).hexdigest(),
    'md5(p0)': hashlib.md5(oneoff[0x00]).hexdigest(),
    'md5(p11+p6)': hashlib.md5(p + oneoff[0x06]).hexdigest(),
    'md5(p0+p6+p11)': hashlib.md5(oneoff[0x00] + oneoff[0x06] + p).hexdigest(),
}
for k, v in c2.items():
    print(f'  {k}: {v} {"<== MATCH!" if v == target else ""}')

# ---------- 3) 0x26 坐标空间判定 ----------
print()
print('== 0x26 坐标空间判定 ==')
# 收集: 0x26 (t, quat, pos), 0x0A own vehicle pos+v32, 0x1A 相机
veh = []  # (t, pos, v32euler)
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    if ty == 0x0A and d.get('eid') == 546611525 and 'pos' in d:
        veh.append((f32(clock), d['pos'], d.get('v32')))
t26 = []
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    if ty == 0x26 and 'pos' in d:
        t26.append((f32(clock), d['pos'], d.get('quat')))
tvehs = [v[0] for v in veh]
import bisect
# 检查: 0x26.pos vs 车辆位置 / 车辆+offset / 相机
d_veh = []
d_veh_off = []
d_cam = []
cam_rows = []
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    if ty == 0x1A and 'f' in d and len(d['f']) == 15 and d['f'][0] != 0:
        cam_rows.append((f32(clock), d['f']))
tcams = [c[0] for c in cam_rows]
for t, pos, quat in t26:
    if t < 30:
        continue
    i = bisect.bisect_left(tvehs, t)
    if i < len(veh) and abs(veh[i][0] - t) < 0.15:
        vp = veh[i][1]
        d_veh.append(((pos[0]-vp[0])**2 + (pos[2]-vp[2])**2) ** 0.5)
    j = bisect.bisect_left(tcams, t)
    if j < len(cam_rows) and abs(cam_rows[j][0] - t) < 0.15:
        cp = cam_rows[j][1][0:3]
        d_cam.append(((pos[0]-cp[0])**2 + (pos[1]-cp[1])**2 + (pos[2]-cp[2])**2) ** 0.5)
if d_veh:
    print(f'0x26.pos 与车辆水平距离: 中位 {statistics.median(d_veh):.1f}m 范围 [{min(d_veh):.1f},{max(d_veh):.1f}] n={len(d_veh)}')
if d_cam:
    print(f'0x26.pos 与0x1A相机距离: 中位 {statistics.median(d_cam):.1f}m 范围 [{min(d_cam):.1f},{max(d_cam):.1f}] n={len(d_cam)}')
# 0x26.pos 与相机 aim (col5:7)
d_aim = []
for t, pos, quat in t26:
    if t < 30:
        continue
    j = bisect.bisect_left(tcams, t)
    if j < len(cam_rows) and abs(cam_rows[j][0] - t) < 0.15:
        ap = cam_rows[j][1][5:8]
        d_aim.append(((pos[0]-ap[0])**2 + (pos[1]-ap[1])**2 + (pos[2]-ap[2])**2) ** 0.5)
if d_aim:
    print(f'0x26.pos 与0x1A注视点距离: 中位 {statistics.median(d_aim):.1f}m 范围 [{min(d_aim):.1f},{max(d_aim):.1f}] n={len(d_aim)}')

# 0x26 y分量 vs 地形高度: 若是瞄准点, y≈地面
ys = [pos[1] for t, pos, q in t26 if t >= 30]
print(f'0x26.pos.y (战斗段): 中位 {statistics.median(ys):.2f} 范围 [{min(ys):.2f},{max(ys):.2f}]')

# ---------- 4) 0x05 结构 ----------
print()
print('== 0x05 实体创建包 ==')
cnt = 0
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    if ty == 0x05 and cnt < 6:
        cnt += 1
        show = {k: (v[:48] if isinstance(v, str) else v) for k, v in d.items() if k not in ('t', 'clk')}
        print(f'  #{idx} {show}')
print()
n5 = sum(1 for l in lines if l['t'] == 5)
n_eid = sum(1 for l in lines if l['t'] == 5 and 'eid' in l)
n_raw = sum(1 for l in lines if l['t'] == 5 and '_raw' in l)
print(f'0x05 总数 {n5}, 带 eid 解码 {n_eid}, _raw 未解 {n_raw}')
# 0x05 eid 分布
eid5 = collections.Counter(l.get('eid') for l in lines if l['t'] == 5 and 'eid' in l)
print('0x05 eid top10:', eid5.most_common(10))
