# -*- coding: utf-8 -*-
"""analyze_replay_jsonl10.py — 终轮: 各类型字段归属 + 0x32/0x37 eid 关联 + 0x20/0x1C/0x1D 抽样。
"""
import json
import struct
import sys
import collections

sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

REPLAY = '/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay'
JSONL = '/home/z/my-project/upload/replay.jsonl'

rf = ReplayFile(REPLAY)
lines = []
with open(JSONL) as f:
    for line in f:
        if line.strip():
            lines.append(json.loads(line))

def f32(u):
    return struct.unpack('<f', struct.pack('<I', u))[0]

# 1) 每类型用了哪些字段
usage = collections.defaultdict(collections.Counter)
for d in lines:
    for k in d:
        if k not in ('t', 'clk'):
            usage[d['t']][k] += 1
print('== 各类型字段归属 ==')
for t in sorted(usage):
    print(f'  0x{t:02X}: {dict(usage[t].most_common())}')

# 2) 0x32 / 0x37 eid 分布
print()
print('== 0x32 / 0x37 eid 分布 ==')
for tt in (0x32, 0x37):
    eids = collections.Counter()
    for d in lines:
        if d['t'] == tt:
            eids[d['eid']] += 1
    top = eids.most_common(12)
    print(f'0x{tt:02X}: {len(eids)} 个实体, top12: {top}')

# 3) 0x37 样本 body 前 12 字节
print()
print('== 0x37 样本 ==')
cnt = 0
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    if ty == 0x37 and cnt < 8:
        cnt += 1
        print(f'  eid={d["eid"]} len={d.get("len")} body[:24]={d.get("body","")[:48]}')

# 4) 0x20 样本
print()
print('== 0x20 样本 (8B) ==')
cnt = 0
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    if ty == 0x20 and cnt < 6:
        cnt += 1
        print(' ', {k: v for k, v in d.items() if k not in ("t", "clk")})

# 5) 0x1C / 0x1D 值分布
print()
print('== 0x1C / 0x1D (u32) 值分布 ==')
for tt in (0x1C, 0x1D):
    vals = collections.Counter()
    for d in lines:
        if d['t'] == tt:
            v = d.get('u32', d.get('f32'))
            vals[v] += 1
    print(f'0x{tt:02X}: uniq={len(vals)} top10={vals.most_common(10)}')

# 6) 0x31 str 与 rest 关系 + methodID 0x08 样本
print()
print('== 0x08 methodID 分布 ==')
mid = collections.Counter()
for d in lines:
    if d['t'] == 0x08:
        mid[d.get('methodID')] += 1
print(f'uniq methodID: {len(mid)}')
print('top15:', mid.most_common(15))

# 7) 0x24 flag/k 分布
print()
print('== 0x24 flag 分布 ==')
fl = collections.Counter()
kk = collections.Counter()
for d in lines:
    if d['t'] == 0x24:
        fl[d.get('flag')] += 1
        kk[d.get('k')] += 1
print('flag:', dict(fl))
print('k uniq:', len(kk), 'top8:', kk.most_common(8))
