#!/usr/bin/env python3
"""t54_mids.py — Task 54-①: 方法ID 排序模型源码级验证 + mid→名映射表
模型 (BigWorld 14.4 源码 ExposedMethodsSortHelper + MethodDescription::streamSize):
  streamSize(方法) = Σ定长参数大小; 含任一变长参数 → -vlh(=1)
  (组件方法不加 EntityID+4 — OwnVehicle 锚定实证)
  槽序 = stable_sort(streamSize): 定长升序在前, 变长桶按 -vlh 升序(=声明序)在后
  mid 值 = 重载合并声明表序号 (13 声明→11 唯一名→网络 11 方法槽)
锚定: OwnVehicle 观测槽序 (4,9,10,2,3,1,5,6,0,7,8) 10 包恒定 → 模型逐位复现即证.
产出: /tmp/wot/t54_midnames.json (OwnVehicle mid→名 + 模型参数)
"""
import sys, json, glob
sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file

CD = '/tmp/wot/wot_scripts/component_defs'
SCALAR = {'INT8': 1, 'UINT8': 1, 'BOOL': 1, 'INT16': 2, 'UINT16': 2, 'INT32': 4,
          'UINT32': 4, 'FLOAT32': 4, 'INT64': 8, 'UINT64': 8, 'FLOAT64': 8,
          'OBJECT_ID': 4, 'ENTITY_ID': 4}
# §31 alias.xml BLOB 类型引用破译: 04e38b=BOOL, 20d4fc=UINT8
BLOB_SCALAR = {'04e38b': ('BOOL', 1), '20d4fc': ('UINT8', 1)}
VARIABLE = ('ARRAY', 'STRING', 'PYTHON', 'TUPLE', 'BLOB', 'FIXED_DICT', 'VECTOR2', 'VECTOR3')


def sec_text(s):
    if s.type == 1:
        return s.asString()
    if s.children:
        return None
    if s.type == 2:
        return str(s.asInt())
    if s.type == 4:
        return 'true' if s.asBool() else 'false'
    return s.data.hex() if s.data else None


def type_name(ty):
    if ty.type == 1:
        return ty.asString()
    if ty.children:
        inner = ty.children[0]
        return inner.asString() if inner.type == 1 else inner.name
    return ty.data.hex() if ty.data else None


def method_size(args):
    """返回 (size, is_variable): 变长参数 → (-1, True); BLOB 标量引用按解析表; 未知 alias 视作变长"""
    total = 0
    for a in args:
        nm = type_name(a)
        if nm in SCALAR:
            total += SCALAR[nm]
        elif nm in BLOB_SCALAR:
            total += BLOB_SCALAR[nm][1]
        else:
            return -1, True   # 变长 (vlh=1) 或未知 alias → 按变长处理
    return total, False


def load_component_methods(name):
    """重载合并声明表: [(方法名, size, is_var)]"""
    r = decode_file(f'{CD}/{name}.def')
    methods = []
    for node in r.children:
        if node.name in ('CellMethods', 'ClientMethods', 'BaseMethods'):
            for m in node.children:
                if any(d['name'] == m.name for d in methods):
                    continue    # 重载合并 (首见)
                args = [c for c in m.children if c.name == 'Arg']
                sz, isv = method_size(args)
                methods.append({'name': m.name, 'size': sz, 'var': isv,
                                'args': [type_name(a) for a in args]})
    return methods


def sorted_slots(methods):
    """stable_sort: 定长升序, 变长(-1)在后 (源码比较器逐语义)"""
    return sorted(range(len(methods)),
                  key=lambda i: (methods[i]['size'] < 0, methods[i]['size'] if methods[i]['size'] >= 0 else -methods[i]['size']))


def main():
    # ---- OwnVehicle 锚定验证 ----
    ov = load_component_methods('OwnVehicle')
    slots = sorted_slots(ov)
    pred = tuple(slots)
    obs = (4, 9, 10, 2, 3, 1, 5, 6, 0, 7, 8)
    print('== OwnVehicle 方法表 (重载合并声明序) ==')
    for i, m in enumerate(ov):
        print(f'  decl{i:2d} mid={i:2d} {m["name"]:36s} args={str(m["args"]):40s} size={m["size"]}')
    print(f'\n预测槽序 (源码模型): {pred}')
    print(f'实测槽序 (t53 10包恒定): {obs}')
    print(f'★ 逐位一致: {pred == obs}')
    midname = {i: m['name'] for i, m in enumerate(ov)}
    print(f'\nmid→名映射: {json.dumps(midname, ensure_ascii=False)}')

    # ---- t53 事件流全量方法段验证 (凡可匹配 def 的 tid) ----
    # 已锚定 def 的 tid: 51=OwnVehicle / 123=AvatarVehiclesInfo / 128=NetworkVehicleHierarchy
    ANCHOR_DEFS = {51: 'OwnVehicle', 123: 'AvatarVehiclesInfo', 128: 'NetworkVehicleHierarchy'}
    recs = [json.loads(l) for l in open('/tmp/wot/t53_events_v1.jsonl')]
    verify = {}
    for tid, dname in ANCHOR_DEFS.items():
        ms = load_component_methods(dname)
        exp = tuple(sorted_slots(ms))
        seqs = []
        cur = None
        for r in recs:
            for e in r['events']:
                if e[0] == 'cr':
                    cur = e[2]
                elif e[0] == 'me' and cur == tid:
                    if e[1] == 'pk':
                        seqs.append(tuple(e[2]))
        ok = sum(1 for s in seqs if s == exp)
        verify[tid] = {'def': dname, 'n_methods': len(ms), 'predicted': list(exp),
                       'observed_seqs': {str(s): c for s, c in __import__('collections').Counter(seqs).items()},
                       'match': f'{ok}/{len(seqs)}'}
        print(f'\ntid={tid} ({dname}): 预测={exp} 匹配 {ok}/{len(seqs)}')

    json.dump({'model': {'source': 'ExposedMethodsSortHelper (entity_method_descriptions.cpp L112-144) + MethodDescription::streamSize (L674)',
                         'rule': '定长参数和为正; 含变长参数 → -vlh(1); 组件方法不加 EntityID+4; stable_sort: 定长升序→变长桶; mid=重载合并声明序号',
                         'ownvehicle_anchor': '预测==实测 (4,9,10,2,3,1,5,6,0,7,8)'},
               'ownvehicle_mid_to_name': midname,
               'verify': verify},
              open('/tmp/wot/t54_midnames.json', 'w'), ensure_ascii=False, indent=1)
    print('\n写出 /tmp/wot/t54_midnames.json')


if __name__ == '__main__':
    main()
