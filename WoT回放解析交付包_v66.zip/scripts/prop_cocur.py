# -*- coding: utf-8 -*-
"""prop_cocur.py — prop1翻转的jsonl事件共现分析 + Avatar.py的setter + prop23与着火/dotEffect"""
import sys, struct, collections, json, bisect
sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

r = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
PLAYER = 0x2094A145
OFF = 34.240 - 139.769

series = collections.defaultdict(list)
for (t, clk, pl, i) in r.pkts:
    if t == 0x07 and len(pl) >= 12:
        eid, prop, vlen = struct.unpack_from('<III', pl, 0)
        if 12 + vlen <= len(pl):
            fclk = struct.unpack('<f', struct.pack('<I', clk))[0]
            series[(eid, prop)].append((fclk, pl[12:12 + vlen]))

# jsonl 全部事件(时间轴)
allevents = []
for line in open('/home/z/my-project/upload/session_20260911_175934.jsonl', encoding='utf-8'):
    try: e = json.loads(line)
    except: continue
    d = e.get('data', {})
    bt = d.get('bt')
    if bt is not None:
        allevents.append((bt, e.get('ev'), d))
allevents.sort(key=lambda x: x[0])

# ── 1. prop1 翻转共现 ──
print('=== prop1(玩家车) 翻转时刻的共现事件(±0.4s) ===')
cocur = collections.Counter()
samples = []
for fclk, v in series[(PLAYER, 1)]:
    bt = fclk - OFF
    near = [(b, ev, d) for b, ev, d in allevents if abs(b - bt) < 0.4 and ev != 'battle_tick']
    for b, ev, d in near:
        cocur[ev] += 1
    if near and len(samples) < 12:
        samples.append((bt, v.hex(), [(b, ev) for b, ev, _ in near]))
print('共现计数:', dict(cocur.most_common(10)))
for bt, v, near in samples:
    print('  bt=%8.2f prop1=%s  <- %s' % (bt, v, near))

# ── 2. prop10(Avatar) 变化共现 ──
print()
print('=== prop10(Avatar) 变化时刻共现(±0.4s, 非battle_tick) ===')
cocur10 = collections.Counter()
for fclk, v in series[(0x2094A160, 10)]:
    bt = fclk - OFF
    for b, ev, d in allevents:
        if abs(b - bt) < 0.4 and ev != 'battle_tick':
            cocur10[ev] += 1
print('共现计数:', dict(cocur10.most_common(10)))

# ── 3. prop23 置位时刻共现(着火?) ──
print()
print('=== prop23 置位(非零值)时刻共现(±0.5s) ===')
cocur23 = collections.Counter()
for (eid, p), seq in series.items():
    if p == 23:
        for fclk, v in seq:
            if v == b'\x00' * 8: continue
            bt = fclk - OFF
            for b, ev, d in allevents:
                if abs(b - bt) < 0.5:
                    cocur23[ev] += 1
print('共现计数:', dict(cocur23.most_common(12)))
# 对照: onVehicleHit 事件的伤害类型字段
print()
print('=== arena.onVehicleHit 样例结构 ===')
n = 0
for b, ev, d in allevents:
    if ev == 'arena.onVehicleHit':
        print(json.dumps(d, ensure_ascii=False)[:260])
        n += 1
        if n >= 3: break

# ── 4. veh.onShowDamageFromShot 结构(伤害方向!) ──
print()
print('=== veh.onShowDamageFromShot 样例 ===')
n = 0
for b, ev, d in allevents:
    if ev == 'veh.onShowDamageFromShot':
        print(json.dumps(d, ensure_ascii=False)[:260])
        n += 1
        if n >= 3: break

# ── 5. prop4(7辆车 0-3) 与 veh.onDynamicComponentCreated? 与 siege? ──
print()
print('=== prop4 变化时刻共现(±0.5s) ===')
cocur4 = collections.Counter()
for (eid, p), seq in series.items():
    if p == 4:
        for fclk, v in seq:
            bt = fclk - OFF
            for b, ev, d in allevents:
                if abs(b - bt) < 0.5 and ev != 'battle_tick':
                    cocur4[ev] += 1
print('共现计数:', dict(cocur4.most_common(10)))

# ── 6. prop33/34/16 置位时刻(一次性事件) ──
print()
print('=== prop16(4B零,15车) / prop33(1B零,19车) / prop34 时刻分布 ===')
for prop in [16, 33, 34]:
    times = []
    for (eid, p), seq in series.items():
        if p == prop:
            for fclk, v in seq:
                times.append((fclk, eid, v.hex()))
    times.sort()
    span = ('%.1f~%.1f' % (times[0][0], times[-1][0])) if times else '-'
    print('prop%-3d %d次  clock范围 %s  前6: %s' % (prop, len(times), span,
          [(round(t, 1), hex(e), v) for t, e, v in times[:6]]))
