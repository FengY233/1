#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""digest_fork.py — WoT fork entity_description_digests.cpp 复刻 + 编码暴力破解

结构(反编译实证, 见 worklog Task 16):
  for 每实体(entities.xml 顺序, isClientType):
    [若上一实体未闭合: end()]
    name 键(name,0) + name="实体名"
    for 每属性(累积序):
      [flags & 0x106 == 0 跳过]           # isClientServerData
      raw_i32(csi)
      name 键(name,0)
      [isForClient && streamSize<0 && vlh!=1: "varLenHeaderSize"=vlh]
      "name"=属性名
      "dataDistributionFlags"=flags&0x5F
      "isVolatile"=bool
      类型块: key(DAT_1435e0950,0) + "name"="Int"等 + 类型字段 + end()
      end()
    "properties" 节(键,1) ... 由外层 startProperties/endProperties 控制
    "clientMethods"(键,1): 每方法(含接口方法, 后置):
      [flags & 0xC == 0 跳过]             # exposed (client 恒 0x4)
      name 键(name,0)
      [vlh 条件同上]
      "name"=方法名
      "flags"=u8
      args 节(DAT_143665890,1): 每参数: "Arg"键 + "name"=参数名 + 类型块(无key?有key) + end
      "returnValues" 节(非空时)
      end()
      raw_i32(count)
    "baseMethods"(1)/"cellMethods"(4): 仅 exposed
"""
import hashlib
import itertools
import json
import os
import struct
import sys

sys.path.insert(0, '/home/z/my-project/upload/tools')
import bwxml_decode as B
import digest_v8 as D8          # 复用解析/类型/csi 机制

ED = '/tmp/wot_scripts/scripts/entity_defs'
TARGET = '5DF886F75E73B33CFF9D87FB9C69389C'


# ---------------------------------------------------------------- 编码器
class Encoder:
    """IMD5Calculator 槽位的字节编码假设(可插拔)"""
    def __init__(self, o):
        self.o = dict(o)
        self.buf = bytearray()

    def raw(self, b):
        self.buf += b

    # vt+0x18(str, flag)
    def vt18(self, s, flag):
        b = s.encode('utf-8')
        mode = self.o['vt18']
        if mode == 0:                      # 恒 +NUL
            self.buf += b + b'\x00'
        elif mode == 1:                    # 恒裸
            self.buf += b
        elif mode == 2:                    # flag=0 → NUL; flag=1 → 裸
            self.buf += b + (b'\x00' if flag == 0 else b'')
        elif mode == 3:                    # flag=1 → NUL; flag=0 → 裸
            self.buf += b + (b'\x00' if flag == 1 else b'')
        elif mode == 4:                    # len_u8 + bytes
            self.buf += bytes([len(b)]) + b
        elif mode == 5:                    # len_u32 + bytes
            self.buf += struct.pack('<I', len(b)) + b

    def key(self, k):
        """命名字段的键编码"""
        b = k.encode('utf-8')
        mode = self.o['key']
        if mode == 0:
            self.buf += b + b'\x00'
        elif mode == 1:
            self.buf += b
        elif mode == 2:
            self.buf += struct.pack('<I', len(b)) + b

    # vt+0x60(key, stdstr) / vt+0x68(key, cstr)
    def vt60(self, k, v):
        self.key(k)
        self.vt18(v, 0) if self.o['strval_via_vt18'] else self._strval(v)

    def _strval(self, v):
        b = v.encode('utf-8')
        mode = self.o['strval']
        if mode == 0:
            self.buf += b + b'\x00'
        elif mode == 1:
            self.buf += b
        elif mode == 2:
            self.buf += struct.pack('<I', len(b)) + b

    # vt+0x28(key, u32) / vt+0x40 / vt+0x50(key,u8) / vt+0x58(key,bool)
    def num(self, k, v, width=4):
        self.key(k)
        mode = self.o['num']
        if mode == 0:
            self.buf += v.to_bytes(width, 'little', signed=True)
        elif mode == 1:
            self.buf += bytes([v & 0xFF])
        elif mode == 2:
            self.buf += str(v).encode('ascii')

    # vt+0x20() end
    def end(self):
        mode = self.o['end']
        if mode == 0:
            pass
        elif mode == 1:
            self.buf += b'\x00'
        elif mode == 2:
            self.buf += b'}'
        elif mode == 3:
            self.buf += b'\n'


# ---------------------------------------------------------------- 类型摘要(fork 结构)
def type_digest_fork(enc, doc, spec, key_name, tcache):
    k = (id(doc), id(spec))
    if k in tcache:
        node_rec, ss, meta = tcache[k]
    else:
        rec, ss = D8.type_info(doc, spec)
        # 提取结构信息: (kind, name, fields...)
        meta = analyze_type(doc, spec)
        tcache[k] = (rec, ss, meta)
    kind, tname, extra = meta

    if key_name is not None:
        enc.vt18(key_name, 0)
    enc.vt60('name', tname)
    if kind == 'int':
        enc.num('size', extra)
    elif kind == 'vector':
        enc.num('size', extra)
    elif kind in ('array', 'tuple'):
        enc.num('size', extra[0])
        if extra[1]:
            enc.num('dbLen', 16777215)
        type_digest_fork(enc, extra[2][0], extra[2][1], 'elementType', tcache)
    elif kind == 'fixed_dict':
        if extra[0] is not None:
            enc.vt60('moduleName', extra[0])
            enc.vt60('instanceName', extra[1])
        enc.num('allowNone', 1 if extra[2] else 0, 1)
        enc.vt18('fields', 1)
        for fname, fdoc, fspec in extra[3]:
            enc.vt18(fname, 0)
            enc.vt60('name', fname)
            type_digest_fork(enc, fdoc, fspec, None, tcache)
            enc.end()
        enc.end()
    enc.end()


def analyze_type(doc, spec):
    """→ (kind, 显示名, 附加信息)"""
    if isinstance(spec, str):
        name, node = spec, None
    else:
        name = D8.own_value(spec)
        node = spec
    if name in D8.ALIASES and node is None:
        return analyze_type(D8.ALIAS_DOC, D8.ALIASES[name])
    up = name.upper()
    INTMAP = {'INT8': ('Int', 1), 'INT16': ('Int', 2), 'INT32': ('Int', 4),
              'UINT8': ('Uint', 1), 'UINT16': ('Uint', 2), 'UINT32': ('Uint', 4),
              'INT64': ('Int64', 8), 'UINT64': ('Uint64', 8)}
    if up in INTMAP:
        return ('int', INTMAP[up][0], INTMAP[up][1])
    if up == 'FLOAT' or up == 'FLOAT32':
        return ('simple', 'Float', None)
    if up == 'FLOAT64':
        return ('simple', 'Float64', None)
    if up == 'STRING':
        return ('simple', 'String', None)
    if up == 'UNICODE_STRING':
        return ('simple', 'UnicodeString', None)
    if up == 'BLOB':
        return ('simple', 'Blob', None)
    if up == 'PYTHON':
        return ('simple', 'Python', None)
    if up == 'MAILBOX':
        return ('simple', 'MailBox', None)
    if up == 'UDO_REF':
        return ('simple', 'UserDataObjectLinkDataType', None)
    if up in ('VECTOR2', 'VECTOR3', 'VECTOR4'):
        return ('vector', 'Vector', int(up[-1]))
    if up in ('ARRAY', 'TUPLE'):
        size = D8.child_int(doc, node, 'size', 0)
        pab = D8.child_bool(doc, node, 'persistAsBlob', False)
        of = doc.child(node, 'of')
        return (up.lower(), up.capitalize(), (size, pab, (doc, of)))
    if up in ('FIXED_DICT', 'FIXED_DICT_SIMPLE'):
        ib = doc.child(node, 'implementedBy')
        mod = inst = None
        if ib is not None:
            s = D8.own_value(ib)
            if isinstance(s, str) and '.' in s:
                mod, inst = s.split('.', 1)
        allow = D8.child_bool(doc, node, 'AllowNone', False)
        fields = []
        props = doc.child(node, 'Properties')
        if props is not None:
            for fidx, fnode in doc.kids(props):
                fname = doc.nm(fidx)
                fields.append((fname, doc, doc.child(fnode, 'Type')))
        return ('fixed_dict', 'FixedDict', (mod, inst, allow, fields))
    if up == 'CLASS':
        allow = D8.child_bool(doc, node, 'AllowNone', False)
        fields = []
        props = doc.child(node, 'Properties')
        if props is not None:
            for fidx, fnode in doc.kids(props):
                fields.append((doc.nm(fidx), doc, doc.child(fnode, 'Type')))
        return ('fixed_dict', 'Class', (None, None, allow, fields))
    if up == 'USER_TYPE':
        mod = D8.own_value(doc.child(node, 'module')) or ''
        inst = D8.own_value(doc.child(node, 'instance')) or ''
        return ('simple', 'User', None)
    raise ValueError('未知类型 %r' % name)


# ---------------------------------------------------------------- 实体摘要(fork 结构)
_ENT_CACHE = {}


def entity_parsed(ename):
    if ename not in _ENT_CACHE:
        _ENT_CACHE[ename] = D8.accumulate(ename)
    return _ENT_CACHE[ename]


def digest_fork(o):
    enc = Encoder(o)
    tcache = {}
    ents = D8.entity_list()
    in_entity = False
    for ename in ents:
        props, methods = entity_parsed(ename)
        final, is_cs, csi_map, stream_size_of = D8.finalize_entity(props)

        def dedup(mlist):
            seen = set()
            out = []
            for m in mlist:
                if m['name'] in seen:
                    continue
                seen.add(m['name'])
                out.append(m)
            return out

        mclient = dedup(methods['client'])
        mbase = [m for m in dedup(methods['base']) if m['exposed']]
        mcell = [m for m in dedup(methods['cell']) if m['exposed']]

        # beginEntity
        if in_entity:
            enc.end()
        in_entity = True
        enc.vt18(ename, 0)
        enc.vt60('name', ename)

        # properties
        enc.vt18('properties', 1)
        for i, p in enumerate(final):
            if not is_cs(p):
                continue
            enc.raw(struct.pack('<i', csi_map[i]))
            enc.vt18(p['name'], 0)
            rec, ss = D8.type_info_cached(p['doc'], p['tspec'])
            if ss < 0 and p['vlh'] is not None and p['vlh'] != 1:
                enc.num('varLenHeaderSize', p['vlh'])
            enc.vt60('name', p['name'])
            enc.num('dataDistributionFlags', p['flags'] & 0x5F)
            enc.num('isVolatile', 0, 1)
            type_digest_fork(enc, p['doc'], p['tspec'], o['typekey'], tcache)
            enc.end()
        enc.end()

        for comp_name, mlist in (('clientMethods', mclient),
                                 ('baseMethods', mbase), ('cellMethods', mcell)):
            enc.vt18(comp_name, 1)
            count = 0
            for m in mlist:
                if not m['exposed']:
                    continue
                enc.vt18(m['name'], 0)
                args_var = False
                for a in m['args']:
                    _, ass = D8.type_info_cached(m['doc'], a)
                    if ass < 0:
                        args_var = True
                        break
                if args_var and m['vlh'] is not None and m['vlh'] != 1:
                    enc.num('varLenHeaderSize', m['vlh'])
                enc.vt60('name', m['name'])
                enc.num('flags', m['flags'], 1)
                if m['args']:
                    enc.vt18(o['argskey'], 1)
                    for a in m['args']:
                        enc.vt18('Arg', 0)
                        enc.vt60('name', 'Arg')
                        type_digest_fork(enc, m['doc'], a, None, tcache)
                        enc.end()
                    enc.end()
                enc.raw(struct.pack('<i', count))
                count += 1
                enc.end()
            enc.end()
    if in_entity:
        enc.end()
    return hashlib.md5(bytes(enc.buf)).hexdigest().upper()


BASE_OPTS = {
    'vt18': 0, 'key': 0, 'strval': 0, 'num': 0, 'end': 0,
    'strval_via_vt18': False, 'typekey': 'dataType', 'argskey': 'args',
}

if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--sweep':
        ranges = {
            'vt18': [0, 1, 2, 3, 4, 5],
            'key': [0, 1, 2],
            'strval': [0, 1, 2],
            'num': [0, 1, 2],
            'end': [0, 1, 2, 3],
            'strval_via_vt18': [False, True],
            'typekey': ['dataType', 'type', 'Type', 'dataType_'],
            'argskey': ['args', 'arguments', 'Args'],
        }
        keys = list(ranges)
        n = 0
        # 两阶段: 先只扫主要维度
        for combo in itertools.product(*[ranges[k] for k in keys]):
            o = dict(BASE_OPTS)
            o.update(dict(zip(keys, combo)))
            try:
                dg = digest_fork(o)
            except Exception as ex:
                continue
            n += 1
            if dg == TARGET:
                print('★★★ 命中! opts =', json.dumps(o))
                sys.exit(0)
            if n % 200 == 0:
                print('  ... %d 组合已测' % n, file=sys.stderr)
        print('未命中, 共测 %d 组合' % n)
    else:
        dg = digest_fork(BASE_OPTS)
        print('fork digest =', dg)
        print('目标       =', TARGET)
        print('匹配' if dg == TARGET else '不匹配')
