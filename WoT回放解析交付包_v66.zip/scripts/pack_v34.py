#!/usr/bin/env python3
"""pack_v34.py — Task 59-a 交付打包: V34 = V33 底座 + Task 57-b/58-a 增量
Task 57-b (findings v40 §36): ★★★★★0x37 语义终局(idx₁↔eid↔花名册全链路 join + finalIdx 定案 + 变换值翻案)
Task 58-a (findings v41 §37): ★★★★★clk 单位翻案(1/65536s) + 0x0A 源码级布局 + 0x39 结构全解
data_v37: 12 件(击杀 feed/身份映射/L16 原始/字段统计 + t57 脚本×8)
data_v38: 5 件(clk 证据/0x0A 布局/0x39 统计 + t58 脚本×2)
scripts 增量: t57×8 + t58×2 = 10 件
"""
import os, zipfile, hashlib, shutil, json

DL = '/home/z/my-project/download'
V33 = f'{DL}/WoT回放解析交付包_v33.zip'
OUT = f'{DL}/WoT回放解析交付包_v34.zip'
DATA37 = f'{DL}/data_v37'
DATA38 = f'{DL}/data_v38'

assert os.path.exists(V33), 'V33 底座缺失'
n37 = len(os.listdir(DATA37)) if os.path.exists(DATA37) else 0
n38 = len(os.listdir(DATA38)) if os.path.exists(DATA38) else 0
assert n37 == 12, f'data_v37 不完整(期望12件, 实际{n37})'
assert n38 == 5, f'data_v38 不完整(期望5件, 实际{n38})'
INC = ['t57_feed.py', 't57_fields.py', 't57_frags.py', 't57_join.py', 't57_join2.py',
       't57_join3.py', 't57_l16.py', 't57_map.py', 't58_p39.py', 't58_p39b.py']
for f in INC:
    assert os.path.exists(f'/home/z/my-project/scripts/{f}'), f'缺 {f}'

# 1) 以 V33 为底座
zin = zipfile.ZipFile(V33, 'r')
old_readme = zin.read('README.md').decode('utf-8')
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as zout:
    for item in zin.infolist():
        if item.filename in ('findings.md', 'worklog.md', 'README.md', 'audit_v33.json'):
            continue  # 换新版本
        zout.writestr(item, zin.read(item.filename))
    # findings/worklog 主位新版
    zout.write('/home/z/my-project/findings.md', 'findings.md')
    zout.write('/home/z/my-project/worklog.md', 'worklog.md')
    # data_v37 / data_v38
    for f in sorted(os.listdir(DATA37)):
        zout.write(f'{DATA37}/{f}', f'data_v37/{f}')
    for f in sorted(os.listdir(DATA38)):
        zout.write(f'{DATA38}/{f}', f'data_v38/{f}')
    # scripts 增量
    for f in INC:
        zout.write(f'/home/z/my-project/scripts/{f}', f'scripts/{f}')

# 2) README 增补(旧 README + V34 节)
readme_add = """

---

# V34 增补（Task 57-b + 58-a · v40-v41 · ★★★★★0x37 语义终局 + clk 时间基翻案 + 0x0A/0x39 双通道）

在 V33 全量底座之上新增：

| 内容 | 说明 |
|---|---|
| `findings.md` | ★ 结论登记册 v41（新增 §36：★★★★★0x37 语义终局——idx₁↔eid↔花名册全链路 join / finalIdx 定案 / 「变换值」翻案；§37：★★★★★clk 单位翻案 / ★★★★0x0A 45B 源码级布局 + LSB 水印 / ★★★0x39 复制流结构全解） |
| `data_v37/` | Task 57-b 全套（86 条带姓名击杀 feed / idx₁ 身份映射表 58KB / L=16 击杀记录原始 86 条 / VEHICLES_INFO 字段语义统计 + t57 脚本×8） |
| `data_v38/` | Task 58-a 全套（clk=1/65536s 证据 / 0x0A 45B 布局验证 / 0x39 双 subtype 结构统计 + t58 脚本×2） |
| `scripts/t57_*.py` + `scripts/t58_*.py` | 增量 10 件（join×4 / L16 直读 / 字段统计 / frags 交叉验证 / 身份映射 / 0x39 双解析器） |

核心突破（Task 57-b · v40 §36 · 0x37 语义终局）：
1. **★★★★★idx₁↔eid↔花名册全链路 join**：idx₁ = 32 + roster_pos，全语料 84/84 零反例零失配（含 B 组场次）——0x37 玩家状态流全部可署名。
2. **★★★★finalIdx = VEHICLES_INFO 39 字段索引定案**（§30 花名册 FIXED_DICT）：38 __generation（22,250 条单调 0 反例，终值 23-175）/ 37 position（3,572 条 [i16 x][i16 y] 地图坐标 ±500，0x8000 哨兵）/ 33 frags（85）/ 30 deathInfo（84）/ 27 events（74）/ 1 isAlive（62）/ 7 isAvatarReady（300）。
3. **★★★★L=16 = deathInfo 击杀记录**：[nid][02][10][位流 idx1,fi=30][01][victimID][killerID][reasonID][equipmentID][numVehiclesAffected]——与花名册 13B 结构逐字节同构；86 条带姓名击杀 feed，84 敌杀 0 队杀（队伍独立验证）。
4. **★★★★「NRL 变换值」翻案**：27,341 条 L=6 主力 = __generation 计数器（81%）+ position i16 网格坐标（13.5%）——非车辆变换，Task 55/56 遗留数学定标问题以「非变换值」终局；§34.5 b1 选择器{98/94/1c/04/30}=fi{38/37/7/1/12}，低 2 位填充零=b1 偶数铁证根源。
5. **★★frags 交叉验证**：击杀→frags+1 对齐 38/39；frags 终值==击杀数 60/67（frags=真值，feed=镜像子集 86/220）；双勘误登记（t55_global3 旧分割 / v24 链 JSON B 组字段错位）。

核心突破（Task 58-a · v41 §37 · clk 时间基 + 0x0A/0x39）：
6. **★★★★★clk 单位破译：1/65536 秒（15.26µs）**——Δclk 峰{6553.6, 3276.8, 1638.4} = 0.1/0.05/0.025s 精确 + 0x07 战斗窗口 36.9e6=563s（ms 解释 10 小时荒谬）+ 死亡跨度 344s + E 纪元 12.9 天 uptime 自洽——推翻全项目 ms 假设，v23 倍速阶梯现象统一解释，全部时间线按 65.536 重算。
7. **★★★★0x0A 45B 源码级布局**（slot15=FUN_140586620，wg_replay_message_handler.cpp L0x622 逐指令）：[eid][ref][pos3f][B12B][yaw][pitch][roll][tail]；★yaw 铁证：运动方向-yaw 角差 p50=0.9°（n=3760）；pitch±25°/roll[-36°,+13°]；ref=avatar eid；★LSB 水印机制：FUN_140574540 每 4B 词最低位注入标记位（位表@+0x210），float 扰动≤1ULP。
8. **★★★0x39 复制流结构全解**：72B(0x30D6C3C4)=[16B 常量][f32 pos3][f32 vel3][f32][01 20] 运动学（pos 地图域 x/z±500、y=22-44m 低空，速度模量化{680..1000}）/ 41B(0x11D6C3C4) 紧凑状态 / seq 链 cur-prev=1 占 96.6% / 轨迹 1.8km 有界游弋=飞行物（宠物遥测假说）。
9. **进度**：按字节加权理解度 94.39% → **95.9%**（0x0A 0.95→0.97 +0.68% / 0x39 0.40→0.75 +0.87%；0x37 0.90→0.95 已计入 V33 后 57-b 轮）。
"""
z = zipfile.ZipFile(OUT, 'a')
z.writestr('README.md', old_readme + readme_add)
audit = {
 "version": "v34",
 "date": "2026-09-26",
 "task": "Task 57-b + 58-a: 0x37 语义终局(身份 join + 字段定案 + 变换值翻案) + clk 单位翻案(1/65536s) + 0x0A 源码级布局 + 0x39 结构全解",
 "headline": [
  "★★★★★ idx₁↔eid↔花名册全链路 join: idx₁=32+roster_pos, 全语料 84/84 零反例——0x37 玩家状态流全部可署名",
  "★★★★ finalIdx=VEHICLES_INFO 39 字段索引定案: 38 __generation(22250 条单调)/37 position(i16 网格±500)/33 frags/30 deathInfo/27 events/1 isAlive/7 isAvatarReady",
  "★★★★ L=16=deathInfo 击杀记录: [位流 idx1,fi=30][01][victimID][killerID][reasonID][equipmentID][numVehiclesAffected], 与花名册 13B 同构; 86 条带姓名击杀 feed, 84 敌杀 0 队杀",
  "★★★★ 「NRL 变换值」翻案: 27341 条 L=6 = __generation(81%)+position(13.5%), 非车辆变换——数学定标遗留问题终局",
  "★★ frags 交叉验证 38/39 对齐; 双勘误(t55_global3 旧分割 / v24 链 JSON B 组字段错位)",
  "★★★★★ clk 单位破译: 1/65536 秒(15.26µs)——Δclk 峰 6553.6/3276.8/1638.4=0.1/0.05/0.025s 精确 + 战斗窗口 563s + E 纪元 12.9 天自洽, 推翻全项目 ms 假设",
  "★★★★ 0x0A 45B 源码级布局(wg_replay_message_handler.cpp L0x622): [eid][ref][pos3f][B12B][yaw][pitch][roll][tail]; yaw 铁证=运动方向角差 0.9°(n=3760); LSB 水印(4B 词最低位注入, ≤1ULP)",
  "★★★ 0x39 复制流结构全解: 72B 运动学(pos3+vel3 地图域)/41B 紧凑状态/seq 链 96.6%/速度量化级/1.8km 有界游弋=飞行物",
  "按字节加权理解度 94.39% → 95.9% (0x0A 0.95→0.97, 0x39 0.40→0.75, 0x37 0.90→0.95)",
 ],
 "coverage": {
  "corpus": "10 场随机战", "total_pkts": 1514067, "total_payload_bytes": 48202991,
  "weighted_understanding_pct": 95.9,
  "channel_status": {
   "0x0A": {"share": 68.05, "u": 0.97, "note": "volatile 位置流, 源码级 45B 布局+yaw/pitch/roll 确名+LSB 水印+clk 定标; 余 B 12B 死推滤波状态待名"},
   "0x07": {"share": 12.94, "u": 1.00, "note": "属性更新 100%(37105/37105)"},
   "0x1A": {"share": 6.12, "u": 0.95, "note": "v1-v7 已通"},
   "0x26": {"share": 3.89, "u": 0.95, "note": "v1-v7 已通"},
   "0x39": {"share": 2.48, "u": 0.75, "note": "复制流结构全解(72B 运动学/41B 状态/seq 链/飞行物行为学); 余对象身份+41B 字段级"},
   "0x37": {"share": 1.52, "u": 0.95, "note": "NRL 缓冲——架构+文法+值格式+身份 join+字段定案全解; 余 Root 前缀文法+深路径 2082 条"},
   "0x05": {"share": 1.18, "u": 1.00, "note": "属性/创建流 100%(6899/6899)"},
   "0x32": {"share": 0.69, "u": 1.00, "note": "NRL 组件创建 100%(6822/6822)+语义事件流"},
   "0x24": {"share": 0.20, "u": 1.00, "note": "嵌套/切片更新 100%(5241/5241)"},
   "0x04": {"share": 0.05, "u": 1.00, "note": "leaveAoI 100%(4922/4922)"},
   "0x3D": {"share": 0.00, "u": 1.00, "note": "entityDefs 指纹, 算法 100% 破译(服务端 def 漂移致复现值未中, 指纹性质)"},
  },
  "remaining": [
   "①0x0A B 12B 确名(死推滤波状态假说, FUN_140586620 调用方反查)——约 2.0% 字节",
   "②0x39 对象身份(0x05 CSI≥50 扩展区 prefabPath 深挖)+41B 字段级——约 0.6% 字节",
   "③0x37 Root 体前缀精确文法 + 深路径 2082 条(深度≥2 位流)",
   "④LSB 水印位表语义(256 位标记内容)+22 例 tail=0 定性",
   "⑤clk 1/65536s 换算全通道时间线重述(含 v24 E 纪元复核)",
   "⑥边缘: karelia2 deathOrder -1 例 / ln156 消歧 / 59 tid 补名 / 0x35 class2 NRL 形态 / 残留字节归因",
  ],
 },
}
z.writestr('audit_v34.json', json.dumps(audit, ensure_ascii=False, indent=1))
z.close()

# 3) 校验
zf = zipfile.ZipFile(OUT)
assert zf.testzip() is None, 'zip 校验失败'
names = zf.namelist()
n = len(names)
size = os.path.getsize(OUT)
md5 = hashlib.md5(open(OUT, 'rb').read()).hexdigest()
for probe in ('data_v37/击杀feed_86条带身份_t57.json', 'data_v37/idx1身份映射表_t57.json',
              'data_v38/clk单位证据_t58.json', 'scripts/t57_l16.py', 'scripts/t58_p39.py',
              'audit_v34.json', 'README.md', 'findings.md', 'worklog.md'):
    assert probe in names, f'缺 {probe}'
zin_md5 = hashlib.md5(open(V33, 'rb').read()).hexdigest()
print(f'V34 = {n} 文件, {size:,} B ({size/1048576:.2f} MB), md5={md5}')
print(f'底座 V33 md5={zin_md5} (617 件)')
print(f'增量: data_v37×12 + data_v38×5 + scripts×10 + findings v41 + worklog + README + audit_v34')

# 4) 备份 + 三处同步
BK = '/home/z/my-project/upload/backup_v34'
os.makedirs(BK, exist_ok=True)
shutil.copy2(OUT, f'{BK}/WoT回放解析交付包_v34.zip')
shutil.copy2('/home/z/my-project/findings.md', f'{BK}/findings.md')
shutil.copy2('/home/z/my-project/worklog.md', f'{BK}/worklog.md')
with zipfile.ZipFile(OUT) as zz:
    open(f'{DL}/audit_v34.json', 'wb').write(zz.read('audit_v34.json'))
    open(f'{BK}/audit_v34.json', 'wb').write(zz.read('audit_v34.json'))
shutil.copy2('/home/z/my-project/findings.md', '/home/z/my-project/upload/findings.md')
shutil.copy2('/home/z/my-project/worklog.md', '/home/z/my-project/upload/worklog.md')
print('备份: upload/backup_v34/ (包+findings+worklog+audit); upload/findings+worklog 同步')
