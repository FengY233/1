# -*- coding: utf-8 -*-
"""分析 session jsonl（第2步：完整名单/击杀链/射击/玩家数据交叉验证）"""
import json, re
from collections import Counter, defaultdict
from datetime import datetime, timedelta

SRC = '/home/z/my-project/upload/session_20260911_175934.jsonl'
CST = timedelta(hours=8)
def cst(ts): return datetime.fromtimestamp(ts, timedelta(hours=8).dst() if False else None) if False else datetime.utcfromtimestamp(ts) + CST

events = [json.loads(l) for l in open(SRC, encoding='utf-8')]

# ---------- 完整 30 人名单（用 enterWorld + entity_created 双源，宽松解析） ----------
name_re = re.compile(r"name: '((?:[^'\\]|\\.)*)'")
cd_re = re.compile(r"compDescr: '((?:[^'\\]|\\.)*)'")
team_re = re.compile(r"team: (\d+)")
idx_re = re.compile(r"index: (\d+)")
def unesc(s):
    try:
        return s.encode('latin1', 'backslashreplace').decode('unicode_escape').encode('latin1').decode('utf-8', 'replace')
    except Exception:
        return s

roster = {}
for ev in events:
    if ev['ev'] in ('avatar.onVehicleEnterWorld', 'battle.vehicle_entity_created'):
        veh = ev['data'].get('vehicle', {})
        vid = veh.get('id')
        if vid is None:
            continue
        pi = veh.get('publicInfo', '')
        if not isinstance(pi, str) or 'name:' not in pi:
            continue
        nm = name_re.search(pi); tm = team_re.search(pi); ix = idx_re.search(pi); cd = cd_re.search(pi)
        if nm and vid not in roster:
            roster[vid] = {
                'name': unesc(nm.group(1)),
                'team': int(tm.group(1)) if tm else None,
                'index': int(ix.group(1)) if ix else None,
                'compDescr_hex': cd.group(1).encode().decode('unicode_escape').encode('latin1').hex() if cd else None,
                'maxHealth': veh.get('maxHealth'),
            }
print(f'名单解析成功: {len(roster)} / 30')
print(f"队伍分布: {Counter(v['team'] for v in roster.values())}")

# ---------- 玩家自己的车 ----------
# avatar id = 546611552；玩家车名应为 巅峰荣誉v拍子（回放分析结论）
player_name_guess = '巅峰荣誉v拍子'
cand = [(vid, v) for vid, v in roster.items() if v['name'] == player_name_guess]
print(f"\n玩家车辆(按名 {player_name_guess}): {[(v[0], v[1]['name'], v[1]['team'], v[1]['maxHealth']) for v in cand]}")

# battle_tick own 里 siegeState 变化与 health 也能定位玩家车
ticks = [ev for ev in events if ev['ev'] == 'battle_tick']
own0 = ticks[0]['data']['own']
print(f"battle_tick own: health={own0['health']} pos={[round(x,1) for x in own0['position']]}")

# veh.onSiegeStateUpdated 的第一个事件 veh 字段
siege = [ev for ev in events if ev['ev'] == 'veh.onSiegeStateUpdated']
siege_vehs = Counter(ev['data']['veh'] for ev in siege)
print(f"\nsiege 事件车辆分布(前5): {siege_vehs.most_common(5)}")

# ---------- 玩家车 = siege 出现最多的？不，玩家是 SPG，自己的 siege 由 avatar 处理 ----------
# ammo 事件是玩家自己的
ammo_upd = [ev for ev in events if ev['ev'] == 'ammo.onShellsUpdated']
print(f"\nammo.onShellsUpdated 样本(前20): ")
for ev in ammo_upd[:20]:
    print(f"  bt={ev['data']['bt']:>7}  args={ev['data']['args']}")

# ---------- 击杀链 ----------
print('\n' + '='*70)
print('arena.onVehicleKilled 全部事件 [victim, killer, reason?, ?, ?]')
print('='*70)
kills = [ev for ev in events if ev['ev'] == 'arena.onVehicleKilled']
def nm(vid): 
    v = roster.get(vid)
    return f"{v['name']}(T{v['team']})" if v else str(vid)
for ev in kills:
    a = ev['data']['args']
    vic, kil = a[0], a[1]
    print(f"  bt={ev['data']['bt']:>8}  {cst(ev['ts']).strftime('%H:%M:%S')}  {nm(vic):32s} <- {nm(kil)}  args={a}")

# ---------- veh.onVehicleDestroyed vs onVehicleKilled 对比 ----------
destroyed = [ev for ev in events if ev['ev'] == 'veh.onVehicleDestroyed']
killed_ids = Counter(tuple(ev['data']['args'][:2]) for ev in kills)
dest_ids = Counter(ev['data']['veh'] for ev in destroyed)
print(f"\nonVehicleKilled: {len(kills)} 起, 唯一受害者: {len(set(e['data']['args'][0] for e in kills))}")
print(f"onVehicleDestroyed: {len(destroyed)} 起, 唯一车: {len(dest_ids)}, 重复ID: {[(k,v) for k,v in dest_ids.items() if v>1]}")
print(f"Destroyed 但不在 Killed 受害者里的: {set(dest_ids) - set(e['data']['args'][0] for e in kills)}")

# ---------- 射击统计 ----------
print('\n' + '='*70)
print('射击统计')
print('='*70)
shots = [ev for ev in events if ev['ev'] == 'arena.onVehicleShot']
shot_by = Counter(ev['data']['args'][0] for ev in shots)
print(f'总射击: {len(shots)} 发, 射手数: {len(shot_by)}')
for vid, c in shot_by.most_common(40):
    print(f'  {nm(vid):36s} {c} 发')

json.dump({'roster': {str(k): v for k, v in roster.items()}},
          open('/home/z/my-project/scripts/session_roster_tmp.json', 'w'), ensure_ascii=False, indent=1)
print('\nroster 已保存')
