# -*- coding: utf-8 -*-
"""把覆盖度终审结果写入 JSON 导出与 xlsx 概览表"""
import json

# ---- 1. JSON ----
JP = '/home/z/my-project/download/WoT回放解码数据_20260911_caucasus.json'
with open(JP, encoding='utf-8') as f:
    data = json.load(f)

data['coverage_audit_final'] = {
    '说明': '理解覆盖度终审(v3终局后的量化审计), 脚本 scripts/coverage_audit.py',
    '容器层': {
        '文件字节': 2025112, '定界率': '100%',
        '构成': {'头': 8, '块0_回放头JSON': 80068, '块1_战斗结果JSON': 110228,
                 '过渡区': 8, '加密主流区': 1834792},
        '解压后包流': 7106831, '消费率': '100%', '残余字节': 0,
        'JSON块字段读取率': '100%'
    },
    '包层': {
        '总包数': 156482, '总载荷字节': 5229047,
        'A级_完全透彻': {'包数': 116392, '占比': '74.38%', '载荷字节': 4564155, '载荷占比': '87.28%'},
        'B级_结构透彻_个别子字段未命名': {'包数': 40090, '占比': '25.62%', '载荷字节': 664892, '载荷占比': '12.72%',
                                          '构成': {'0x07切片属性更新': {'包数': 37105, '载荷': 530054},
                                                   '0x32组件消息': {'包数': 1837, '载荷': 67487},
                                                   '0x37NRL节点更新': {'包数': 1148, '载荷': 67351}}},
        'C级_未知': {'包数': 0, '占比': '0.00%', '载荷字节': 0, '载荷占比': '0.00%'},
        '结论': '没有一字节处于"不知道它是什么"的状态; 12.72%载荷字节存在"知道结构但个别位含义未命名"的残留(附录D)'
    }
}
with open(JP, 'w', encoding='utf-8') as f:
    json.dump(data, f, ensure_ascii=False, indent=1)
print('JSON 已更新:', JP, '(新增 coverage_audit_final 段)')

# ---- 2. xlsx 概览表 ----
import openpyxl
XP = '/home/z/my-project/download/WoT回放解析数据包_20260911_caucasus.xlsx'
wb = openpyxl.load_workbook(XP)
ws = wb['概览'] if '概览' in wb.sheetnames else wb.worksheets[0]
# 找到第一个空行
r = ws.max_row + 2
ws.cell(row=r, column=1, value='理解覆盖度终审 (v3)')
ws.cell(row=r, column=1).font = openpyxl.styles.Font(bold=True)
rows = [
    ('容器层定界率', '100% (2,025,112 B 全部定界: 头8+块0 80,068+块1 110,228+过渡区8+主流1,834,792)'),
    ('包流消费率', '100% (156,482 包, 解压 7,106,831 B, 零残余)'),
    ('JSON 块读取率', '100% (两个 JSON 块全部字段)'),
    ('A 级·完全透彻', '116,392 包 (74.38%) / 载荷 4,564,155 B (87.28%) — 帧结构+字段+位级编码全部命名'),
    ('B 级·结构透彻', '40,090 包 (25.62%) / 载荷 664,892 B (12.72%) — 0x07属性13紧凑编码、0x32/0x37私有TLV细则'),
    ('C 级·未知', '0 包 (0.00%) / 0 B — 没有未知字节'),
]
for i, (k, v) in enumerate(rows):
    ws.cell(row=r + 1 + i, column=1, value=k)
    ws.cell(row=r + 1 + i, column=2, value=v)
    ws.cell(row=r + 1 + i, column=2).alignment = openpyxl.styles.Alignment(wrap_text=True, vertical='top')
wb.save(XP)
print('xlsx 已更新:', XP, '(概览表追加', len(rows), '行审计结果)')
print('sheets:', wb.sheetnames)
