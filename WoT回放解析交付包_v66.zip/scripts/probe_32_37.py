# -*- coding: utf-8 -*-
"""probe_32_37.py — 0x32组件消息全标签枚举 + 0x37 NRL结构分析"""
import sys, struct, collections
sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

r = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')

# ── 0x32: [eid][?]... 枚举头部模式 ──
print('=== 0x32 头部模式普查(前24字节) ===')
h32 = collections.Counter()
len32 = collections.Counter()
s32 = []
for (t, clk, pl, i) in r.pkts:
    if t == 0x32:
        h32[pl[:8].hex()] += 1
        len32[len(pl)] += 1
        if len(s32) < 8: s32.append(pl.hex())
print('头部8B模式数:', len(h32))
for h, n in h32.most_common(12):
    print('  %s ×%d' % (h, n))
print('长度分布:', dict(sorted(len32.items())[:10]))
print('样本:')
for s in s32: print(' ', s[:140])

# ── 0x37: NRL 结构 ──
print()
print('=== 0x37 头部模式 ===')
h37 = collections.Counter()
s37 = []
for (t, clk, pl, i) in r.pkts:
    if t == 0x37:
        h37[pl[:8].hex()] += 1
        if len(s37) < 10: s37.append(pl.hex())
print('头部8B模式数:', len(h37))
for h, n in h37.most_common(10):
    print('  %s ×%d' % (h, n))
print('样本:')
for s in s37: print(' ', s[:160])
