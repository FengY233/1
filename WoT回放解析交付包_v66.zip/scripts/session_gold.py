# -*- coding: utf-8 -*-
"""会话日志剩余金矿: 性能统计/基地占领/幸存者/玩家伤害流/ Siege """
import json, re, ast
from collections import Counter, defaultdict
from datetime import datetime, timedelta

CST = timedelta(hours=8)
def cst(ts): return datetime.utcfromtimestamp(ts) + CST
BATTLE_START_BT = 139.769

events = [json.loads(l) for l in open('/home/z/my-project/upload/session_20260911_175934.jsonl', encoding='utf-8')]

# ---------- 1. client_stats 解析 (Python2 repr) ----------
print('='*70)
print('1. 客户端性能统计 (battle_tick.client_stats, Python2 dict repr)')
print('='*70)
def parse_p2(s):
    s = re.sub(r'(\d)L\b', r'\1', s)
    s = s.replace("u'", "'")
    try:
        return ast.literal_eval(s)
    except Exception:
        return None

stats_series = []
for o in events:
    if o['ev'] == 'battle_tick':
        d = o['data']
        st = parse_p2(d.get('client_stats', ''))
        if st:
            stats_series.append((d['bt'] - BATTLE_START_BT, st))
print(f'含性能统计的 tick: {len(stats_series)}')
if stats_series:
    keys = sorted(stats_series[0][1].keys())
    print('字段:', keys[:25])
    # fps 与 ping 汇总
    fps_vals = []
    for bt, st in stats_series:
        # 尝试常见 fps 字段
        fps = st.get('fps') or st.get('avgFps') or st.get('fpsAvg')
        if fps is None:
            # 从分桶计算
            tot = sum(st.get(k, 0) for k in keys if k.startswith('fps_') and k[4:].replace('_','.').replace('..','_').isdigit())
            pass
        if fps: fps_vals.append((bt, float(fps)))
    # ping 字段
    ping_keys = [k for k in keys if 'ping' in k.lower()]
    print('ping 相关字段:', ping_keys[:10])
    fps_keys = [k for k in keys if 'fps' in k.lower()]
    print('fps 相关字段:', fps_keys[:15])
    # 采样输出
    for bt, st in stats_series[::max(1, len(stats_series)//8)]:
        sel = {k: st[k] for k in list(keys)[:8]}
        print(f'  bt={bt:7.1f}s  样本: {sel}')

# ---------- 2. 基地占领事件 ----------
print()
print('='*70)
print('2. 基地占领事件 (arena.onTeamBasePointsUpdate args=[team, baseID, points, capturingTeam, ...])')
print('='*70)
bases = [o for o in events if o['ev'] == 'arena.onTeamBasePointsUpdate']
for o in bases:
    a = o['data']['args']
    print(f'  bt={o["data"]["bt"]:>7.2f} battle_t={o["data"]["bt"]-BATTLE_START_BT:6.1f}  {a}')

# ---------- 3. 30 个 onVehicleDestroyed 时间 ----------
print()
print('='*70)
print('3. veh.onVehicleDestroyed 时间分布')
print('='*70)
dest = [(o['data']['bt'] - BATTLE_START_BT, o['data']['veh']) for o in events if o['ev'] == 'veh.onVehicleDestroyed']
killed_ids = {o['data']['args'][0] for o in events if o['ev'] == 'arena.onVehicleKilled'}
for bt, vid in sorted(dest):
    tag = 'KILLED' if vid in killed_ids else '存活(战斗结束移除/AoI)'
    print(f'  battle_t={bt:6.1f}  veh={vid}  {tag}')

# ---------- 4. 玩家伤害流 ----------
print()
print('='*70)
print('4. 玩家(546611525)相关全部战斗事件')
print('='*70)
roster = {}
name_re = re.compile(r"name: '((?:[^'\\]|\\.)*)'")
for o in events:
    if o['ev'] in ('avatar.onVehicleEnterWorld',):
        veh = o['data'].get('vehicle', {})
        vid = veh.get('id')
        pi = veh.get('publicInfo', '')
        if isinstance(pi, str):
            m = name_re.search(pi)
            if m and vid and vid not in roster:
                try:
                    roster[vid] = m.group(1).encode('latin1','backslashreplace').decode('unicode_escape').encode('latin1').decode('utf-8','replace')
                except Exception:
                    roster[vid] = m.group(1)
def nm(v): return roster.get(v, str(v))

ME = 546611525
for o in events:
    ev = o['ev']; d = o['data']; bt = d.get('bt', 0) - BATTLE_START_BT
    hit = False
    if ev in ('arena.onVehicleShot', 'arena.onVehicleHit', 'arena.onVehicleKilled', 'arena.onVehicleHealthChanged'):
        args = d['args']
        if ME in args: hit = True
    elif ev in ('veh.onShowDamageFromShot', 'veh.onSiegeStateUpdated', 'veh.onVehicleHealthChanged', 'veh.onDiscreteShotDone'):
        if d.get('veh') == ME: hit = True
    elif ev in ('ammo.onShellsUpdated', 'ammo.onCurrentShellChanged'):
        hit = True
    if hit and 0 <= bt < 620:
        a = d.get('args', d.get('milestone'))
        print(f'  bt={bt:6.1f}  {ev:36s} args={str(a)[:90]}')
