# -*- coding: utf-8 -*-
"""analyze_session_new.py — 新旧 jsonl 全面对比 + 回放时钟重测
目的: 用户澄清 旧jsonl=真实战斗记录, 新jsonl(09-23)=回放对应会话。
重新检验: ①两份jsonl各自的 bt↔ts 速率(1x? 变速?) ②回放clock单位与压缩性质
"""
import io
import json
import sys
from collections import Counter
from datetime import datetime, timedelta

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
CST = timedelta(hours=8)

OLD = '/home/z/my-project/upload/session_20260911_175934.jsonl'
NEW = '/home/z/my-project/upload/session_20260923_140427.jsonl'


def load(path):
    evs = []
    with open(path, encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    evs.append(json.loads(line))
                except Exception:
                    pass
    return evs


def cst(ts):
    return datetime.utcfromtimestamp(ts) + CST


def fmt(ev):
    d = ev.get('data', {})
    return '%s bt=%-9s %s' % (
        cst(ev['ts']).strftime('%H:%M:%S.%f')[:-3],
        ('%.3f' % d['bt']) if isinstance(d.get('bt'), (int, float)) else '-',
        ev['ev'])


for tag, path in (('旧(09-11 真实战斗)', OLD), ('新(09-23 回放会话)', NEW)):
    evs = load(path)
    t0 = evs[0]['ts']
    t1 = evs[-1]['ts']
    print('=' * 78)
    print('【%s】 %d 事件, 会话 %s → %s (%.1f 秒)' % (
        tag, len(evs), cst(t0).strftime('%H:%M:%S'), cst(t1).strftime('%H:%M:%S'), t1 - t0))

    # 1. 事件类型普查
    census = Counter(e['ev'] for e in evs)
    print('\n-- 事件类型普查 (%d 种) --' % len(census))
    for name, c in census.most_common():
        print('   %-46s %5d' % (name, c))

    # 2. bt 单调性与速率
    bts = [(e['ts'], e['data']['bt']) for e in evs
           if isinstance(e.get('data', {}).get('bt'), (int, float))]
    print('\n-- bt 字段: %d 个, 范围 %.3f ~ %.3f --' % (len(bts), bts[0][1], bts[-1][1]))
    back = [(bts[i - 1], bts[i]) for i in range(1, len(bts)) if bts[i][1] < bts[i - 1][1] - 1e-6]
    print('   bt 倒退次数: %d' % len(back))
    for (ta, ba), (tb, bb) in back[:12]:
        print('     %s bt %.3f -> %s bt %.3f (Δbt=%.3f, Δts=%.3f)' % (
            cst(ta).strftime('%H:%M:%S.%f')[:-3], ba, cst(tb).strftime('%H:%M:%S.%f')[:-3], bb,
            bb - ba, tb - ta))
    # 分段速率: 每60个bt样本
    print('   -- bt↔ts 分段速率 (每 ~50 样本) --')
    N = 50
    for i in range(0, len(bts) - N, N):
        ta, ba = bts[i]
        tb, bb = bts[i + N]
        if tb > ta and bb >= ba:
            print('     ts+%-7.1fs bt %-8.2f→%-8.2f 速率=%.3fx' % (
                ta - t0, ba, bb, (bb - ba) / (tb - ta)))

    # 3. 阶段变化
    print('\n-- arena.onPeriodChange / battle.period_change --')
    for e in evs:
        if e['ev'] in ('arena.onPeriodChange', 'battle.period_change'):
            print('   ' + fmt(e) + '  ' + str(e['data'].get('args', e['data'])))

    # 4. 生命周期
    print('\n-- 生命周期关键事件 --')
    keys = ('session', 'garage.account_become_player', 'queue.enqueued', 'queue.arena_created',
            'battle.avatar_become_player', 'battle.round_finished', 'battle.results_received',
            'battle.avatar_become_non_player', 'exit.disconnected', 'monitor_stopped',
            'loading_milestone')
    seen_load = 0
    for e in evs:
        if e['ev'] in keys:
            if e['ev'] == 'loading_milestone':
                seen_load += 1
                if seen_load > 2 and e is not evs[-1]:
                    continue
            print('   ' + fmt(e))

    # 5. 击杀事件
    print('\n-- veh.onVehicleKilled (击杀链) --')
    kills = [e for e in evs if e['ev'] == 'veh.onVehicleKilled']
    print('   共 %d 条' % len(kills))
    for e in kills:
        a = e['data'].get('args', [])
        print('   ' + fmt(e) + ' args=' + json.dumps(a, ensure_ascii=False)[:110])

    print()
