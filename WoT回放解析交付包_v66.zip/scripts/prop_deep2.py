# -*- coding: utf-8 -*-
"""prop_deep2.py — prop1可见性假说 + prop19/23浮点解码 + prop14值验证 + 其余属性归属"""
import sys, struct, collections, json, bisect
sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

r = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
PLAYER = 0x2094A145
OFF = 34.240 - 139.769

series = collections.defaultdict(list)
for (t, clk, pl, i) in r.pkts:
    if t == 0x07 and len(pl) >= 12:
        eid, prop, vlen = struct.unpack_from('<III', pl, 0)
        if 12 + vlen <= len(pl):
            fclk = struct.unpack('<f', struct.pack('<I', clk))[0]
            series[(eid, prop)].append((fclk, pl[12:12 + vlen]))

hdr = json.loads(r.blocks[0].decode('utf-8', 'replace'))
eid2name, eid2team = {}, {}
for vehID, info in hdr.get('vehicles', {}).items():
    eid2name[int(vehID)] = info.get('name', '?')
    eid2team[int(vehID)] = info.get('team', 0)

# ── 1. prop19 (8B) 浮点解码(其他车辆) ──
print('=== prop19 (8B) 各车辆样本 2×f32 ===')
seen = set()
for (eid, prop), seq in sorted(series.items()):
    if prop == 19 and eid not in seen and len(seq) >= 3:
        seen.add(eid)
        vals = [struct.unpack('<2f', v) for _, v in seq[:3]]
        print('eid=0x%X %-14s %d次  值: %s' % (eid, eid2name.get(eid, '?')[:12], len(seq),
              ['(%.3f, %.3f)' % v for v in vals]))
    if len(seen) >= 8: break

print()
print('=== prop19 全部值域统计(2×f32) ===')
allv = []
for (eid, prop), seq in series.items():
    if prop == 19:
        for _, v in seq:
            allv.append(struct.unpack('<2f', v))
if allv:
    a_s = sorted(a for a, b in allv if abs(a) < 1e9)
    b_s = sorted(b for a, b in allv if abs(b) < 1e9)
    print('第1浮点: min=%.3f max=%.3f 非零占比=%.1f%%' % (a_s[0], a_s[-1], 100.0 * sum(1 for a, b in allv if a != 0) / len(allv)))
    print('第2浮点: min=%.3f max=%.3f 非零占比=%.1f%%' % (b_s[0], b_s[-1], 100.0 * sum(1 for a, b in allv if b != 0) / len(allv)))

# ── 2. prop23 (8B) ──
print()
print('=== prop23 (8B) 车辆与样本 ===')
for (eid, prop), seq in sorted(series.items()):
    if prop == 23:
        vals = [struct.unpack('<2f', v) for _, v in seq[:3]]
        print('eid=0x%X %-14s %d次  值: %s' % (eid, eid2name.get(eid, '?')[:12], len(seq),
              ['(%.4f, %.4f)' % v for v in vals]))

# ── 3. prop14 = health 值验证 ──
print()
print('=== prop14(2B) vs onVehicleHealthChanged 值对齐 ===')
health_events = []
for line in open('/home/z/my-project/upload/session_20260911_175934.jsonl', encoding='utf-8'):
    try: e = json.loads(line)
    except: continue
    if e.get('ev') == 'arena.onVehicleHealthChanged':
        d = e['data']
        health_events.append((d['bt'], d['args']))
# jsonl: args = [target_eid, attacker_eid, newHealth?] 409? amount?
p14_events = []
for (eid, prop), seq in series.items():
    if prop == 14:
        for fclk, v in seq:
            p14_events.append((fclk - OFF, eid, struct.unpack('<H', v)[0]))
p14_events.sort()
he_sorted = sorted(health_events)
matched = 0
samples = []
for j, (bt, args) in enumerate(he_sorted):
    teid = args[0] & 0xFFFFFFFF
    # jsonl eid 可能是 vehicleSessionID; 找最近的 p14
    best = None
    for k, (pbt, peid, pv) in enumerate(p14_events):
        if abs(pbt - bt) < 0.3:
            best = (pbt, peid, pv); break
    if best:
        matched += 1
        if len(samples) < 8:
            samples.append((bt, args, best))
print('时间窗内配对: %d/%d' % (matched, len(he_sorted)))
for bt, args, (pbt, peid, pv) in samples:
    print('  bt=%8.2f jsonl_args=%s | p14 bt=%8.2f eid=0x%X(%s) val=%d' %
          (bt, args, pbt, peid, eid2name.get(peid, '?')[:10], pv))

# ── 4. prop1 可见性假说: 与 onPositionsUpdated 车辆集对比 ──
print()
print('=== prop1 vs onPositionsUpdated 可见集 ===')
pos_sets = []  # (bt, set of eids)
for line in open('/home/z/my-project/upload/session_20260911_175934.jsonl', encoding='utf-8'):
    try: e = json.loads(line)
    except: continue
    if e.get('ev') == 'arena.onPositionsUpdated':
        d = e['data']
        s = d.get('positions') or d.get('vehicles') or d.get('args')
        if isinstance(s, dict):
            pos_sets.append((d['bt'], set(int(k) for k in s)))
        elif isinstance(s, list) and s and isinstance(s[0], list):
            pos_sets.append((d['bt'], set(x[0] for x in s if isinstance(x, list))))
print('位置更新事件:', len(pos_sets), '样例:', list(pos_sets[0][1])[:5] if pos_sets else None)

# 检验: 非玩家车辆的 prop1=1 区间 是否对应其在位置更新集中
if pos_sets:
    pbts = [b for b, _ in pos_sets]
    test_eids = [eid for (eid, p) in series if p == 1 and eid != PLAYER][:6]
    for eid in test_eids:
        seq = series[(eid, 1)]
        inset_when_1 = tot1 = inset_when_0 = tot0 = 0
        for fclk, v in seq:
            bt = fclk - OFF
            j = bisect.bisect_right(pbts, bt) - 1
            if j < 0: continue
            present = eid in pos_sets[j][1]
            if v == b'\x01':
                tot1 += 1; inset_when_1 += present
            else:
                tot0 += 1; inset_when_0 += present
        print('eid=0x%X %-12s: prop1=1时在可见集%.0f%% (%d样本) | prop1=0时%.0f%% (%d样本)' %
              (eid, eid2name.get(eid, '?')[:10], 100.0 * inset_when_1 / max(tot1, 1), tot1,
               100.0 * inset_when_0 / max(tot0, 1), tot0))

# ── 5. 其他小属性的车辆覆盖 ──
print()
print('=== 各属性覆盖的车辆数与样本 ===')
for prop in [1, 4, 10, 16, 33, 34]:
    eids = [eid for (eid, p) in series if p == prop]
    seq_all = [(fclk, v) for (eid, p), seq in series.items() if p == prop for fclk, v in seq]
    uniq = collections.Counter(v.hex() for _, v in seq_all)
    print('prop%-3d 车辆数=%2d 总数=%4d 值分布: %s' % (prop, len(set(eids)), len(seq_all),
          dict(uniq.most_common(4))))
