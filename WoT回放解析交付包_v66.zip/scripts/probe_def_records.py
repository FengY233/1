#!/usr/bin/env python3
"""probe_def_records.py — 用已知属性名锚定 Vehicle.def 二进制记录语法"""
import struct, sys

path = '/tmp/wot_scripts/scripts/entity_defs/Vehicle.def'
data = open(path, 'rb').read()

# ---- 字符串表 ----
strings, pos = [], 5
while pos < len(data):
    e = data.find(b'\x00', pos)
    if e < 0: break
    s = data[pos:e]
    if s == b'':
        pos = e + 1; break
    if any(b < 0x20 or b > 0x7e for b in s): break
    strings.append(s.decode()); pos = e + 1
idx = {s: i for i, s in enumerate(strings)}
print(f'字符串表 {len(strings)} 项, 二进制区 0x{pos:x}..0x{len(data):x} ({len(data)-pos}B)')
print('完整索引表:')
for i in range(0, len(strings), 6):
    print('  ' + ' | '.join(f'{j:3d}:{strings[j]}' for j in range(i, min(i+6, len(strings)))))

BIN = data[pos:]
abs0 = pos

def ctx(at, before=24, after=40):
    """带上下文的 hexdump"""
    s = max(0, at-before); e = min(len(BIN), at+after)
    out = []
    for i in range(s, e, 16):
        chunk = BIN[i:i+16]
        hexs = ' '.join(f'{b:02x}' for b in chunk)
        text = ''.join(chr(b) if 32 <= b < 127 else '.' for b in chunk)
        mark = ' <<' if s <= at < s+16 else ''
        out.append(f'  +0x{i:04x}  {hexs:<48}  {text}{mark if i<=at<i+16 else ""}')
    return '\n'.join(out)

# ---- 已知属性名锚定 ----
print('\n===== 属性名索引出现位置 =====')
for name in ['health', 'gunAnglesPacked', 'engineMode', 'siegeState',
             'damageStickers', 'physicsMode', 'publicInfo', 'stunInfo', 'state']:
    i = idx.get(name)
    if i is None:
        print(f'{name}: 不在字符串表!'); continue
    pat = struct.pack('<H', i)
    hits = []
    p = 0
    while True:
        p = BIN.find(pat, p)
        if p < 0: break
        hits.append(p); p += 1
    print(f'\n--- {name} (idx={i}, u16={pat.hex()}) {len(hits)} 处命中 ---')
    for h in hits[:3]:
        print(ctx(h))
