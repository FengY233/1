# -*- coding: utf-8 -*-
"""make_chart04_v3.py — 图04 v3: clock=float32秒 证明 + 全程1x实时 + 伪影机理
三联图:
  上: 0x1A 逐包浮点差分 (全程≈0.1s) — 1x 实时铁证
  中: 整数比特视角的"倍速阶梯" vs float32 ULP binade — 伪影解剖
  下: 阶段时间线 (float秒) + 墙钟对账
"""
import json
import os
import sys
import struct

import matplotlib
import matplotlib.font_manager as fm

fm.fontManager.addfont('/usr/share/fonts/truetype/chinese/SarasaMonoSC-Regular.ttf')
fm.fontManager.addfont('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')

import matplotlib.pyplot as plt

plt.rcParams.update({
    'font.sans-serif': ['Sarasa Mono SC', 'DejaVu Sans'],
    'axes.unicode_minus': False,
    'figure.facecolor': '#FFFFFF', 'axes.facecolor': '#FFFFFF',
    'axes.edgecolor': '#E5E7EB', 'axes.linewidth': 0.8,
    'axes.spines.top': False, 'axes.spines.right': False,
    'axes.grid': False,
    'xtick.major.size': 0, 'ytick.major.size': 0,
    'xtick.labelsize': 9, 'ytick.labelsize': 9,
    'axes.labelsize': 10, 'axes.titlesize': 15, 'axes.titleweight': 'bold', 'axes.titlepad': 14,
    'legend.frameon': False, 'legend.fontsize': 9,
    'figure.dpi': 200, 'savefig.dpi': 200, 'savefig.facecolor': '#FFFFFF',
})

C_BLUE, C_CYAN, C_PURPLE, C_AMBER, C_RED, C_GREEN = '#3B82F6', '#06B6D4', '#8B5CF6', '#F59E0B', '#EF4444', '#10B981'
G900, G700, G500, G400, G300, G200, G100 = '#111827', '#374151', '#6B7280', '#9CA3AF', '#D1D5DB', '#E5E7EB', '#F3F4F6'
OUT = '/home/z/my-project/download/charts'
os.makedirs(OUT, exist_ok=True)

sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

R = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
pkts = R.pkts

def f32(u):
    return struct.unpack('<f', struct.pack('<I', u))[0]

p16 = sorted((f32(p[1]), struct.unpack('<I', p[2][:4])[0]) for p in pkts if p[0] == 0x16)
p2, p3, p4 = (min(c for c, per in p16 if per == k) for k in (2, 3, 4))
t_end = f32(max(p[1] for p in pkts if p[1] != 0xFFFFFFFF))

fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(11.5, 10.6), constrained_layout=True,
                                    gridspec_kw={'height_ratios': [1.0, 1.05, 0.78]})

# ─── 上: 0x1A 浮点差分 — 全程 0.1s ───
a1a = [f32(p[1]) for p in pkts if p[0] == 0x1A and p[1] > 0]
ts_ = a1a
ds_ = [b - a for a, b in zip(ts_, ts_[1:]) if 0 < b - a < 5]
xs = ts_[1:len(ds_) + 1]
ax1.scatter(xs, ds_, s=4, alpha=0.30, color=C_BLUE, rasterized=True, zorder=2,
            label='0x1A 相邻包间隔 (n=%d)' % len(ds_))
ax1.axhline(0.1, color=C_RED, lw=1.8, zorder=3, label='游戏 tick = 0.100s (10Hz @1x)')
n_exact = sum(1 for d in ds_ if abs(d - 0.1) < 0.001)
ax1.annotate('96.2% 的间隔恰为 0.100s → 战斗以 1x 实时进行, 全程零变速',
             xy=(0.5, 0.5), xycoords='axes fraction', ha='center', fontsize=10.5,
             fontweight='bold', color=G700)
for c, lab in [(p2, '倒计时开始'), (p3, '战斗开始'), (p4, '战斗结束')]:
    ax1.axvline(c, color=G300, lw=1.0, ls='--', zorder=1)
    ax1.annotate(lab, xy=(c, 0.208), ha='center', fontsize=8.5, color=G500,
                 xytext=(0, 2), textcoords='offset points')
ax1.set_ylim(0, 0.24)
ax1.set_xlim(0, t_end + 3)
ax1.set_ylabel('相邻 0x1A 包间隔 (float 秒)')
ax1.set_title('图04 · clock 字段 float32 语义证明与全程 1x 实时判定 (v3)')
ax1.legend(loc='lower right')

# ─── 中: 伪影解剖 — 整数比特"倍速" = ULP binade ───
bits = [p[1] for p in pkts if p[0] == 0x1A and p[1] > 0]
dbits = [b - a for a, b in zip(bits, bits[1:]) if 0 < b - a < 10 * 1048576]
xb = [f32(u) for u in bits[1:len(dbits) + 1]]
ax2.scatter(xb, dbits, s=4, alpha=0.30, color=C_PURPLE, rasterized=True, zorder=2,
            label='同一数据, 把 u32 比特当整数看的"每 tick 增量"')
# binade 阶梯
binades = [2, 4, 8, 16, 32, 64, 128, 256, 512, 1024]
for i, b in enumerate(binades[:-1]):
    hi = binades[i + 1]
    n = i + 1                      # 区间 [b, hi) 的 floor(log2) = i+1
    d = 0.1 * (2.0 ** (23 - n))    # 理论比特增量 = 0.1 × 2^(23−⌊log2 t⌋)
    ax2.plot([b, hi], [d, d], color=C_RED, lw=2.2, zorder=3,
             solid_capstyle='round')
    if d > 2500:
        ax2.annotate('%.1f' % d, xy=(hi * 0.97, d), fontsize=8.5, color=C_RED,
                     ha='right', xytext=(0, 4), textcoords='offset points')
ax2.set_yscale('log')
ax2.set_xlim(0, t_end + 3)
ax2.set_xlabel('真实时间 (float32 秒, 录制起点=0)')
ax2.set_ylabel('每游戏 tick 的比特增量 (整数视角)')
ax2.set_title('伪影解剖: v2 的 "倍速阶梯" = 比特增量 0.1×2^(23−⌊log₂t⌋) 的 binade 台阶 (94.9% 实测吻合)')
ax2.legend(loc='upper right')
ax2.annotate('比特增量 = 0.1s ÷ ULP(t)\n越过每个 2^n 秒边界时精确 ×2 —— 与"倍速"无关',
             xy=(0.32, 0.16), xycoords='axes fraction', fontsize=9.5, color=G700,
             bbox=dict(boxstyle='round,pad=0.45', fc='#FEF3C7', ec='#FDE68A'))

# ─── 下: 阶段时间线 + 墙钟对账 ───
phases = [
    (0, p2, '加载尾段\n4.24s', G300),
    (p2, p3, '倒计时\n30.000s', C_CYAN),
    (p3, p4, '战斗 612.495s (实时会话 612.49s, 结果JSON 612s)', C_BLUE),
    (p4, t_end, '结算\n6.10s', C_AMBER),
]
for x0, x1, lab, col in phases:
    ax3.barh(0, x1 - x0, left=x0, height=0.5, color=col, edgecolor='white', zorder=2)
    ax3.annotate(lab, xy=((x0 + x1) / 2, 0), ha='center', va='center', fontsize=8.8,
                 color=G900 if col in (G300, C_AMBER) else 'white', zorder=3)
# 击杀标记
raw = json.load(open('/home/z/my-project/scripts/align_v2_raw.json'))
for a in raw['anchors_raw']:
    ax3.plot(f32(a['clock']), 0.42, marker='v', ms=5, color=C_RED, alpha=0.75, zorder=4)
ax3.annotate('25 个击杀包 (与实时会话 bt 偏差 ≤0.225s)', xy=(300, 0.56), fontsize=9, color=C_RED, ha='center')
# 墙钟轴注释
wall = [('18:01:05.3\n录制起点\n=回放头dateTime', 0), ('18:01:39.7\n战斗开始', p3),
        ('18:11:52.0\n战斗结束', p4), ('18:11:58.3\n末包', t_end)]
for lab, x in wall:
    ax3.annotate(lab, xy=(x, -0.62), ha='center', fontsize=8.2, color=G700,
                 xytext=(0, -6), textcoords='offset points')
    ax3.plot([x, x], [-0.28, -0.36], color=G400, lw=1.0)
ax3.set_xlim(-8, t_end + 8)
ax3.set_ylim(-1.1, 0.85)
ax3.set_yticks([])
ax3.set_xlabel('回放 float32 时钟 (秒)')
ax3.set_title('录制时间线: 2026-09-11 18:01:05.3 → 18:11:58.3 (652.8s) — 与实时会话墙钟逐点对账一致')
ax3.spines['left'].set_visible(False)

fig.savefig(OUT + '/04_时钟float32证明与1x实时.png')
plt.close(fig)
print('chart 04 v3 saved')
import shutil
os.replace
shutil.copy(OUT + '/04_时钟float32证明与1x实时.png', OUT + '/04_性能与播放速度.png')  # 兼容旧引用
print('legacy name copied')
