#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""scan_gaps.py — 检查类型块区域(0x142ab3000-0x142ace000)内所有含计算器虚调用的函数"""
import re

hdr = re.compile(r'==== FUNC (0x[0-9a-f]+) (\S+) ====')
vcall = re.compile(r'\(\*\*\(code \*\*\)\(\*param_\d \+ (0x[0-9a-f]+)\)\)')

LO, HI = 0x142ab3000, 0x142ace000
cur = None; body = []; out = []
with open('/home/z/my-project/work/decomp/decomp/chunks/c_1428d1e40.c', errors='replace') as f:
    for line in f:
        m = hdr.search(line)
        if m:
            if cur:
                out.append((cur, body))
            cur = (int(m.group(1), 16), m.group(2))
            body = []
        elif cur is not None:
            body.append(line)
if cur:
    out.append((cur, body))

print('区间内函数总数:', sum(1 for c, b in out if LO <= c[0] < HI))
for (addr, name), body in out:
    if not (LO <= addr < HI):
        continue
    text = ''.join(body)
    slots = sorted(set(vcall.findall(text)))
    if not slots:
        continue
    has_name_key = '&DAT_1435d2d24' in text
    sz = 'size' if 'DAT_1435e92e4' in text else ('"size"' if '"size"' in text else '')
    # 打印槽位序列(过滤已知大函数)
    print('%s  slots=%s name_key=%s %s lines=%d' % (name, ','.join(slots), 'Y' if has_name_key else '-', sz, len(body)))
