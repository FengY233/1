# -*- coding: utf-8 -*-
"""analyze_replay_jsonl2.py — 榨取工具解码知识: 0x0A/0x26/0x1A/0x05/0x04 位布局 + 0xFFFFFFFF 哈希。
"""
import json
import struct
import sys
import hashlib
import collections
import zlib

sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

REPLAY = '/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay'
JSONL = '/home/z/my-project/upload/replay.jsonl'

rf = ReplayFile(REPLAY)
lines = []
with open(JSONL) as f:
    for line in f:
        if line.strip():
            lines.append(json.loads(line))

def f32(u):
    return struct.unpack('<f', struct.pack('<I', u))[0]

# ---------- A. 0x0A 位布局反推 ----------
print('== 0x0A 位布局 (45B: eid/ref/pos/v20/v32/tail) ==')
cnt = 0
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    if ty == 0x0A and cnt < 5:
        cnt += 1
        print('raw:', payload.hex())
        print('decoded:', {k: v for k, v in d.items() if k not in ('t', 'clk')})
        print()

# 分布: pos 值域 / v20 v32 值域
posvals = []
v20vals = []
v32vals = []
tailc = collections.Counter()
refc = collections.Counter()
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    if ty == 0x0A:
        if 'pos' in d:
            posvals += d['pos']
            v20vals += d['v20']
            v32vals += d['v32']
            tailc[d.get('tail')] += 1
            refc[d.get('ref')] += 1
print('pos range:', min(posvals), '..', max(posvals), 'n=', len(posvals))
print('v20 range:', min(v20vals), '..', max(v20vals))
print('v32 range:', min(v32vals), '..', max(v32vals))
print('tail dist:', dict(tailc))
print('ref distinct:', len(refc), 'top:', refc.most_common(5))

# ---------- B. 0x26 布局 ----------
print()
print('== 0x26 布局 ==')
cnt = 0
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    if ty == 0x26 and cnt < 3:
        cnt += 1
        print('raw:', payload.hex())
        print('decoded:', {k: v for k, v in d.items() if k not in ('t', 'clk')})
        print()

# ---------- C. 0x1A 15 浮点语义 ----------
print('== 0x1A 15 floats 语义 ==')
# 收集战斗段 0x1A, 看每列统计
import math
rows = []
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    if ty == 0x1A and 'f' in d and len(d['f']) == 15:
        rows.append((f32(clock), d['f']))
print('rows:', len(rows))
for col in range(15):
    vals = [r[1][col] for r in rows]
    nz = [v for v in vals if v != 0.0]
    print(f'  col{col:2d}: zero={len(vals)-len(nz)}/{len(vals)} range=({min(vals):.4g},{max(vals):.4g}) uniq={len(set(vals))}')
# 玩家 0x26 pos 与 0x1A 对齐看是否相机
print('sample rows (每 1000 行取 1):')
for i in range(0, len(rows), 1000):
    t, f = rows[i]
    print(f'  t={t:8.3f} ' + ' '.join(f'{x:8.3f}' for x in f))

# ---------- D. 0x05 结构 ----------
print()
print('== 0x05 结构 ==')
cnt = 0
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    if ty == 0x05 and cnt < 4:
        cnt += 1
        print('raw[:80]:', payload[:80].hex())
        print('decoded:', {k: (v if not isinstance(v, str) else v[:60]) for k, v in d.items() if k not in ('t', 'clk')})
        print()

# ---------- E. 0xFFFFFFFF 16 字节哈希 ----------
print('== 0xFFFFFFFF 尾包哈希破解 ==')
term_raw = bytes.fromhex('d509e348a47afab6e8afe4da6137178e')
print('target:', term_raw.hex())
# 候选: 整个 stream / 所有 payload 拼接 / 加密主流 / 解密流 / 头部
cands = {
    'md5(stream)': hashlib.md5(rf.stream).hexdigest(),
    'md5(raw file)': hashlib.md5(rf.raw).hexdigest(),
    'md5(decrypted)': hashlib.md5(rf.decrypt_main(rf.main)).hexdigest(),
    'md5(main enc)': hashlib.md5(rf.main).hexdigest(),
    'md5(payloads)': hashlib.md5(b''.join(p[2] for p in rf.pkts)).hexdigest(),
    'md5(headers)': hashlib.md5(b''.join(struct.pack('<III', len(p[2]), p[0], p[1]) for p in rf.pkts)).hexdigest(),
}
for k, v in cands.items():
    mark = ' <== MATCH!' if v == term_raw.hex() else ''
    print(f'  {k}: {v}{mark}')
