#!/usr/bin/env python3
"""survey_en_format.py — 摸清 scripts.7z 里 EN 二进制格式的分布与结构"""
import os, sys

BASE = '/tmp/wot_scripts/scripts'

def read_string_table(data):
    """EN 格式: 魔数 + NUL 分隔字符串表, 返回 (strings, end_offset)"""
    if not data.startswith(b'EN'):
        return None, 0
    strings, pos = [], 5          # 跳过 EN a1 62 00
    while pos < len(data):
        e = data.find(b'\x00', pos)
        if e < 0:
            break
        s = data[pos:e]
        if s == b'':
            pos = e + 1
            break                # 双 NUL = 表结束(猜测)
        if any(b < 0x20 or b > 0x7e for b in s):
            break                # 非可打印 = 进入二进制区
        strings.append(s.decode('ascii'))
        pos = e + 1
    return strings, pos

# ---- 1. 全树格式普查 ----
xml_cnt = en_cnt = other_cnt = 0
samples = {'xml': [], 'en': [], 'other': []}
for root, dirs, files in os.walk(BASE):
    for f in files:
        p = os.path.join(root, f)
        try:
            with open(p, 'rb') as fh:
                head = fh.read(8)
        except OSError:
            continue
        rel = os.path.relpath(p, BASE)
        if head.startswith(b'EN'):
            en_cnt += 1
            if len(samples['en']) < 6: samples['en'].append(rel)
        elif head.lstrip().startswith((b'<?xml', b'<')):
            xml_cnt += 1
            if len(samples['xml']) < 6: samples['xml'].append(rel)
        else:
            other_cnt += 1
            if len(samples['other']) < 8: samples['other'].append(rel)
print(f'EN 二进制: {en_cnt}  XML: {xml_cnt}  其他: {other_cnt}')
print('EN 样本:', samples['en'])
print('XML 样本:', samples['xml'])
print('其他样本:', samples['other'])

# ---- 2. Vehicle.def 结构解剖 ----
print('\n' + '=' * 70)
data = open(os.path.join(BASE, 'entity_defs/Vehicle.def'), 'rb').read()
print(f'Vehicle.def: {len(data)} bytes, magic={data[:5]}')
strings, pos = read_string_table(data)
print(f'字符串表: {len(strings)} 项, 结束于 0x{pos:x}')
print('前 12 项:', strings[:12])
tail = data[pos:]
print(f'二进制区: {len(tail)} bytes (0x{pos:x}..0x{len(data):x})')
print('魔数第2-4字节:', ' '.join(f'{b:02x}' for b in data[2:5]))

# ---- 3. 二进制区前 512 字节注释式 hexdump ----
def dump(data, start, length, base):
    for i in range(0, length, 16):
        chunk = data[start+i:start+i+16]
        if not chunk:
            break
        hexs = ' '.join(f'{b:02x}' for b in chunk)
        text = ''.join(chr(b) if 32 <= b < 127 else '.' for b in chunk)
        print(f'{base+start+i:06x}  {hexs:<48}  {text}')

print('\n--- 二进制区头部 384B ---')
dump(data, pos, 384, 0)
print('\n--- 中段(找属性记录模式) ---')
mid = pos + len(tail) // 2
dump(data, mid - 64, 256, 0)
