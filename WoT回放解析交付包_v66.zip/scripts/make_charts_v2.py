# -*- coding: utf-8 -*-
"""make_charts_v2.py — 依据纠正性结论重生成 图04/06/07
04: 倍速阶梯画像(锚点法+0x1A瞬时) + 0x1F性能
06: 三会话生命周期对比 (实时战斗09-11 / 录制会话clock域 / 1x播放09-23)
07: clock↔游戏时间单调映射 + 双会话击杀时刻一致性
"""
import json
import os
import sys
import struct
from collections import Counter

import matplotlib
import matplotlib.font_manager as fm

fm.fontManager.addfont('/usr/share/fonts/truetype/chinese/SarasaMonoSC-Regular.ttf')
fm.fontManager.addfont('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')

import matplotlib.pyplot as plt

plt.rcParams.update({
    'font.sans-serif': ['Sarasa Mono SC', 'DejaVu Sans'],
    'axes.unicode_minus': False,
    'figure.facecolor': '#FFFFFF', 'axes.facecolor': '#FFFFFF',
    'axes.edgecolor': '#E5E7EB', 'axes.linewidth': 0.8,
    'axes.spines.top': False, 'axes.spines.right': False,
    'axes.grid': False,
    'xtick.major.size': 0, 'ytick.major.size': 0,
    'xtick.labelsize': 9, 'ytick.labelsize': 9,
    'axes.labelsize': 10, 'axes.titlesize': 15, 'axes.titleweight': 'bold', 'axes.titlepad': 14,
    'legend.frameon': False, 'legend.fontsize': 9,
    'figure.dpi': 200, 'savefig.dpi': 200, 'savefig.facecolor': '#FFFFFF',
})

C_BLUE, C_CYAN, C_PURPLE, C_AMBER, C_RED, C_GREEN = '#3B82F6', '#06B6D4', '#8B5CF6', '#F59E0B', '#EF4444', '#10B981'
G900, G700, G500, G400, G300, G200, G100 = '#111827', '#374151', '#6B7280', '#9CA3AF', '#D1D5DB', '#E5E7EB', '#F3F4F6'
OUT = '/home/z/my-project/download/charts'
os.makedirs(OUT, exist_ok=True)

sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

prof = json.load(open('/home/z/my-project/scripts/speed_profile.json', encoding='utf-8'))
raw = json.load(open('/home/z/my-project/scripts/align_v2_raw.json', encoding='utf-8'))
Q20 = 1048576.0
P3_BT = 57.172  # 播放会话bt
segs = prof['segments']  # game_t0/t1/speed (战斗相对)
inst = prof['instant']  # (clock_s, bt, speed)

# ═══════════════ 图 04: 倍速画像 + 性能 ═══════════════
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(11.5, 8.2), constrained_layout=True,
                               gridspec_kw={'height_ratios': [1.25, 1]})

# -- 上: 速度阶梯 --
battle_inst = [(b - P3_BT, s) for c, b, s in inst if P3_BT <= b <= 669.447]
xs = [g for g, s in battle_inst]
ys = [s for g, s in battle_inst]
ax1.scatter(xs, ys, s=3.5, alpha=0.28, color=C_BLUE, rasterized=True, zorder=2,
            label='0x1A 逐包瞬时倍速 (n=%d)' % len(xs))
# 阶梯(众数段)
step_x, step_y = [0], [segs[0]['speed']]
for sg in segs:
    step_x += [sg['game_t1']]
    step_y += [sg['speed']]
ax1.step([0] + [s['game_t1'] for s in segs], [s['speed'] for s in segs] + [segs[-1]['speed']],
         where='post', color=C_RED, lw=2.4, zorder=4, label='锚点法分段倍速(众数)')
for sg in segs:
    ax1.annotate('%gx' % sg['speed'], xy=((sg['game_t0'] + min(sg['game_t1'], 612)) / 2, sg['speed']),
                 xytext=(0, 7), textcoords='offset points', ha='center', fontsize=10,
                 fontweight='bold', color=C_RED)
ax1.set_yscale('log', base=2)
ax1.set_yticks([2, 4, 8, 16, 32, 64])
ax1.set_yticklabels(['2x', '4x', '8x', '16x', '32x', '64x'])
ax1.set_ylim(1.6, 100)
ax1.set_xlim(0, 615)
ax1.set_xlabel('游戏时间 (战斗相对秒, 以1x播放会话为权威)')
ax1.set_ylabel('播放倍速 (log₂)')
ax1.set_title('图4 · 回放录制倍速画像：精确 2 的幂阶梯 4x→8x→16x→32x→64x（战斗平均 18.25x）')
# 击杀标记
kts = [a['bt_rel'] for a in raw['anchors_raw']]
for kt in kts:
    ax1.axvline(kt, color=G300, lw=0.6, zorder=1)
ax1.axvline(kts[8], color=C_AMBER, lw=1.4, zorder=3)
ax1.annotate('玩家击杀 Deiiv1', xy=(kts[8], 88), fontsize=8.5, color=G700,
             xytext=(kts[8] - 118, 92), arrowprops=dict(arrowstyle='-', color=G400, lw=0.7))
ax1.legend(loc='upper left', bbox_to_anchor=(0.0, 1.0))
ax1.text(0.985, 0.045, '战斗 612.28 游戏秒 ÷ 33.55 观看秒 = 18.25x\n旧版"0.55x–92x/回跳重看"已撤销(错误基线会话+µs单位误判)',
         transform=ax1.transAxes, ha='right', va='bottom', fontsize=8, color=G500,
         bbox=dict(boxstyle='round,pad=0.4', fc=G100, ec=G200))

# -- 下: 0x1F 性能 (fps/ping 随观看时钟) --
R = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
f_rows = []
for p in R.pkts:
    if p[0] == 0x1F and len(p[2]) >= 4:
        v = struct.unpack('<I', p[2])[0]
        if v & 0xFF000000:
            continue
        f_rows.append((p[1] / Q20, v & 0xFF, (v >> 8) & 0x3FFFF))
fx = [t for t, f, g in f_rows]
fy = [f for t, f, g in f_rows]
fping = [g for t, f, g in f_rows]
ax2.scatter(fx, fy, s=3.5, alpha=0.4, color=C_CYAN, rasterized=True, label='fps (左轴)')
ax2.set_ylabel('fps', color=C_CYAN)
ax2.tick_params(axis='y', labelcolor=C_CYAN)
ax2.set_xlabel('录制会话时钟 (Q20 秒, 观看起点=989.4s)')
ax2.set_ylim(0, 250)
ax2r = ax2.twinx()
ax2r.spines['right'].set_visible(True)
ax2r.scatter(fx, fping, s=3.5, alpha=0.35, color=C_AMBER, rasterized=True, label='ping (右轴)')
ax2r.set_ylabel('ping (ms)', color=C_AMBER)
ax2r.tick_params(axis='y', labelcolor=C_AMBER)
ax2r.set_ylim(0, 500)
ax2.set_title('图4·下 · 录制会话性能遥测 (0x1F)：战斗段 fps 150–190, ping 中位 77ms / p95 450ms')
h1, l1 = ax2.get_legend_handles_labels()
h2, l2 = ax2r.get_legend_handles_labels()
ax2.legend(h1 + h2, l1 + l2, loc='upper left')
for tck, lab in ((989.44, '观看开始'), (1032.48, '倒计时'), (1056.56, '战斗开始'), (1090.11, '战斗结束')):
    ax2.axvline(tck, color=G300, lw=0.8, ls='--', zorder=1)
    ax2.text(tck, 245, lab, rotation=90, fontsize=7.5, color=G500, va='top', ha='right')
fig.savefig(OUT + '/04_性能与播放速度.png')
plt.close(fig)
print('04 完成')

# ═══════════════ 图 06: 三会话生命周期 ═══════════════
fig, axes = plt.subplots(3, 1, figsize=(11.5, 8.6), constrained_layout=True)
rows = [
    ('① 实时战斗会话  09-11 17:59:34–18:12:53 (798.5s) · bt↔ts 全程 1.000x', [
        # (名称, 起, 止, 颜色, 标签层级: 'above'/'b1'/'b2'/'none')
        ('车库+登录', 0, 71.8, G300, 'above'),
        ('随机战排队 43.4s', 71.8, 115.2, C_AMBER, 'above'),
        ('加载+等待', 115.2, 125.4, C_CYAN, 'b1'),
        ('倒计时 30s', 125.4, 155.4, C_PURPLE, 'b2'),
        ('战斗 612.49s (1.000x 实时)', 155.4, 767.9, C_GREEN, 'above'),
        ('结算+断开', 767.9, 798.5, G400, 'b1')]),
    ('② 回放录制会话 (clock 域重建) · 总在机 ≥1090.2s', [
        ('客户端闲置 (车库/浏览, 无timed包)', 0, 989.44, G200, 'above'),
        ('装载', 989.44, 992.0, C_CYAN, 'b1'),
        ('等待+倒计时 (0.25x–4x 混合)', 992.0, 1056.56, C_PURPLE, 'above'),
        ('战斗 33.5s', 1056.56, 1090.11, C_RED, 'b1'),
        ('收尾', 1090.11, 1090.20, G400, 'b2')]),
    ('③ 1x 播放会话  09-23 14:04:27–14:15:47 (680.8s) · bt↔ts 全程 1.000x', [
        ('启动+装载', 0, 12.0, C_CYAN, 'b1'),
        ('等待+倒计时', 12.0, 42.0, C_PURPLE, 'b2'),
        ('战斗 612.28s (1.000x 全速播放, 内容与①完全等价)', 42.0, 654.3, C_GREEN, 'above'),
        ('结算+停止', 654.3, 680.8, G400, 'b1')]),
]
YL = {'above': 0.30, 'b1': -0.34, 'b2': -0.64}
VA = {'above': 'bottom', 'b1': 'top', 'b2': 'top'}
for ax, (title, phases) in zip(axes, rows):
    for name, s, e, c, lv in phases:
        ax.barh(0, e - s, left=s, height=0.5, color=c, zorder=3)
        if lv != 'none':
            ax.text((s + e) / 2, YL[lv], name, ha='center', va=VA[lv],
                    fontsize=7.6 if lv != 'above' else 8.2,
                    color=G700 if lv == 'above' else G500)
    ax.set_ylim(-0.95, 0.72)
    ax.set_yticks([])
    ax.set_title(title, fontsize=11.5, loc='left', pad=6)
    ax.set_xlabel('会话时间 (秒)')
axes[0].set_xlim(0, 800)
axes[1].set_xlim(0, 1100)
axes[2].set_xlim(0, 700)
fig.suptitle('图6 · 三个会话的生命周期对比：同一战斗的 实时(1x) / 录制(变倍速) / 播放(1x)', fontsize=14,
             fontweight='bold')
fig.savefig(OUT + '/06_会话生命周期.png')
plt.close(fig)
print('06 完成')

# ═══════════════ 图 07: 映射与内容一致性 ═══════════════
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12.6, 5.9), constrained_layout=True,
                               gridspec_kw={'width_ratios': [1.35, 1]})
# 左: clock → 游戏时间 (单调映射)
anch = sorted([(a['clock'] / Q20, a['bt']) for a in prof['anchors']])
ax1.plot([c for c, b in anch], [b for c, b in anch], color=C_BLUE, lw=2.2, zorder=3,
         label='锚点连线 (25击杀+阶段包)')
kx = [a['clock'] / Q20 for a in raw['anchors_raw']]
ky = [P3_BT + a['bt_rel'] for a in raw['anchors_raw']]
ax1.scatter(kx, ky, s=26, color=C_RED, zorder=4, label='击杀事件 (0x37 内定位)')
speed_colors = {4.0: C_CYAN, 8.0: C_GREEN, 16.0: C_AMBER, 32.0: C_PURPLE, 64.0: C_RED}
for i, sg in enumerate(segs):
    c_lo = anch[0][0]
    # 找该游戏段对应的clock范围
    g0, g1 = P3_BT + sg['game_t0'], P3_BT + min(sg['game_t1'], 612.3)
    cs = [c for c, b in anch if g0 <= b <= g1 + 0.01]
    if cs:
        ax1.axvspan(min(cs), max(cs), alpha=0.10, color=speed_colors[sg['speed']], zorder=1)
        ax1.text((min(cs) + max(cs)) / 2, 25, '%gx' % sg['speed'], ha='center', fontsize=10,
                 fontweight='bold', color=speed_colors[sg['speed']])
ax1.set_xlabel('录制会话时钟 (Q20 秒)')
ax1.set_ylabel('游戏时间 · 播放会话 bt (秒)')
ax1.set_title('图7·左 · 回放 clock → 游戏时间映射：严格单调\n(斜率=倍速; 无任何回跳 — 旧"5次回看重看"结论撤销)')
ax1.legend(loc='upper left')
ax1.set_xlim(1050, 1092)
# 右: 双会话击杀时刻一致性
ok_bt = [b - 139.769 for b, v, k in raw['old_kills']]
nk_bt = [b - P3_BT for b, v, k in raw['new_kills']]
ax2.plot([0, 620], [0, 620], color=G300, lw=1, ls='--', zorder=1)
ax2.scatter(ok_bt, nk_bt, s=30, color=C_GREEN, zorder=3)
maxd = max(abs(a - b) for a, b in zip(ok_bt, nk_bt))
ax2.set_xlabel('实时战斗会话 击杀时刻 (战斗相对秒)')
ax2.set_ylabel('1x 播放会话 击杀时刻 (战斗相对秒)')
ax2.set_title('图7·右 · 25 个击杀时刻双会话一致\n(最大偏差 %.2fs → 内容完整等价)' % maxd)
ax2.set_xlim(0, 620)
ax2.set_ylim(0, 620)
ax2.set_aspect('equal')
fig.savefig(OUT + '/07_观看行为与时间轴对齐.png')
plt.close(fig)
print('07 完成')
