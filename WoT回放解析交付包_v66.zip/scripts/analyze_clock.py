# -*- coding: utf-8 -*-
"""analyze_clock.py — clock 字段形状测量"""
import io
import struct
import sys
from collections import Counter

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

R = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
pkts = R.pkts

print('==== clock==0 的包范围 ====')
last0 = max(p[3] for p in pkts if p[1] == 0)
print('  clock=0 的最后包索引: %d / %d' % (last0, len(pkts)))
nz = [p for p in pkts if p[1] != 0]
print('  第一个非零 clock: pkt#%d clk=%d' % (nz[0][3], nz[0][1]))

print()
print('==== 0x1A 序列: 每 500 个打印 (index, clock, delta_from_prev) ====')
a = [p for p in pkts if p[0] == 0x1A]
prev = None
for i, p in enumerate(a):
    if i % 500 == 0 or i == len(a) - 1:
        d = p[1] - prev if prev is not None else 0
        print('  [%5d] pkt#%d clk=%d  Δ=%d' % (i, p[3], p[1], d))
    prev = p[1]

print()
print('==== 0x1A clock 的一阶差分分布 ====')
ds = []
for i in range(1, len(a)):
    d = a[i][1] - a[i - 1][1]
    if d > 0:
        ds.append(d)
ds.sort()
n = len(ds)
print('  n=%d  p1=%d p25=%d p50=%d p75=%d p99=%d max=%d' % (
    n, ds[n // 100], ds[n // 4], ds[n // 2], ds[3 * n // 4], ds[99 * n // 100], ds[-1]))

print()
print('==== 全体相邻包 clock 正差分分布(抽样) ====')
ds2 = []
prev = None
for p in pkts:
    if p[1] > 0:
        if prev is not None and p[1] > prev:
            ds2.append(p[1] - prev)
        prev = p[1]
ds2.sort()
n2 = len(ds2)
print('  n=%d  p25=%d p50=%d p75=%d p99=%d max=%d' % (
    n2, ds2[n2 // 4], ds2[n2 // 2], ds2[3 * n2 // 4], ds2[99 * n2 // 100], ds2[-1]))

print()
print('==== battle 段估算: 0x1A 数量×周期 vs clock 跨度 ====')
span = a[-1][1] - a[0][1]
print('  0x1A: count=%d, clock跨度=%d' % (len(a), span))
print('  若 10Hz: 时长=%.1fs → clock速率=%.1f/s' % (len(a) / 10.0, span / (len(a) / 10.0)))
print('  若 clock=µs: 时长=%.1fs' % (span / 1e6))

print()
print('==== 0x1F 值形状: 每500个 ====')
f = [p for p in pkts if p[0] == 0x1F]
for i, p in enumerate(f):
    if i % 800 == 0 or i == len(f) - 1:
        (v,) = struct.unpack('<I', p[2])
        print('  [%5d] pkt#%d clk=%d val=%d' % (i, p[3], p[1], v))

print()
print('==== 0x1F 值直方图(粗) ====')
vals = [struct.unpack('<I', p[2])[0] for p in f]
buckets = Counter(v // 1000 for v in vals)
for k in sorted(buckets):
    print('  %5d000-%5d999: %s (%d)' % (k, k, '#' * min(50, buckets[k] // 20), buckets[k]))
