# -*- coding: utf-8 -*-
"""插入第12章 + 更新§11交付物清单 + 附录D"""
import io, json

P = '/home/z/my-project/download/WoT回放完全解析报告.md'
txt = io.open(P, encoding='utf-8').read()

S = json.load(open('/home/z/my-project/scripts/session_summary.json', encoding='utf-8'))
kills = S['battle']['kills']

ch12 = f"""
---

## 12. 客户端会话日志交叉验证（session_20260911_175934.jsonl）

用户另行提供了 `session_20260911_175934.jsonl`（9,187,316 字节，7,341 行）——这是**同一场战斗的客户端实时事件监控日志**（每行 `{{"data": ..., "ts": 墙钟秒, "ev": 事件名}}`，由注入客户端的监控钩子产生，含 BigWorld 对象 repr）。它与 .wotreplay 构成"**第一手实时记录 vs 二手变速再录制**"的完美互证样本，本章为逐项对账结果。

### 12.1 事件类型全景（42 种，7,341 条）

| 类别 | 事件（数量） | 说明 |
|---|---|---|
| 会话框架 | session(1) / monitor_stopped(1) / exit.disconnected(1) | 开机（v2.4.0.0 #942，CN，tick=0.1s）→ 断开（dropped=0，零丢行） |
| 车库 | garage.account_become_player(2) / show_gui(2) / client_synchronize(7) / client_updated(7) | 登录/结算返回车库两次 |
| 排队 | queue.enqueued(1) / queue.info(9) / queue.arena_created(1) | queue_type=1 随机战；队列 332 人（LT62/MT76/HT85/TD45/SPG64） |
| 加载 | loading_milestone(54) | enter→inventory→shop→dossier→discounts→recycleBin→playerData→loadContent→hangarReady 完整流水线 |
| 战斗生命周期 | battle.avatar_become_player/ready/round_finished/results_received 等(8) | 加载仅 5.16s；结算下发 6.1s |
| 阶段 | arena.onPeriodChange(4) / battle.period_change(4) | 1等待(10.1s/上限60)→2倒计时(30.0s)→3战斗(612.49s/上限900)→4结束(60s, [2,1]=队2胜/全歼) |
| 高频状态 | battle_tick(3,232) | 5Hz 快照：own 车辆姿态/血量/攻城模式 + client_stats 性能串 + AoI 车辆位置表（仅首帧含表） |
| 车辆实体 | avatar.onVehicleEnterWorld(247) / battle.vehicle_entity_created(247) | 30 唯一车 + **217 次 AoI 重进入**（服务器因视野往复销毁/重建实体） |
| 战斗事件 | onVehicleShot(156) / onVehicleHit(147) / onVehicleHealthChanged(114) / onVehicleKilled(25) / onVehicleStatisticsUpdate(55) / onVehicleUpdated(25) | 全场 156 发炮弹、25 次击杀的权威实时记录 |
| 车辆组件 | veh.onSiegeStateUpdated(54) / onDiscreteShotDone(34) / onVehicleDestroyed(30) / onShowDamageFromShot(18) / onAppearanceReady(15) / onVehicleHealthChanged(15) / onDynamicComponentCreated(53) | **onVehicleDestroyed 是实体移除事件而非死亡**（26-76s 簇=AoI 离开，618.8s 簇=战斗结束清理） |
| 玩家专属 | ammo.onShellsUpdated(15) / onCurrentShellChanged(2) / state.onVehicleStateUpdated(1,571) / playerEvents.onTracerReceived(216) | 弹药 15→1 逐发递减；216 条 tracer 实体 ID |
| 占领 | arena.onTeamBasePointsUpdate(45) | 队伍2 两波进占队伍1 基地（445-457s 点数0→2 两次重置；600-611.5s 终局 0→11 未满即全歼） |

### 12.2 会话生命周期（墙钟，UTC+8）

```
17:59:34.861  客户端启动（bt=0 基准）
17:59:42.708  登录完成进车库（bt=21.6，加载里程碑 34.2s 处 hangarReady）
18:00:12.485  加入随机战队列（排队 43.4s）
18:00:55.927  匹配成功 arena_created
18:01:00.560  avatar_become_player（avatar 实体 id=546611552，与回放一致）
18:01:05.722  avatar_ready（战斗加载 5.16s，SSD 级速度）
18:01:09.752  全员加载完毕，倒计时 30s 开始
18:01:39.755  战斗开始（bt=139.769，游戏时间 t=0）
18:11:52.250  战斗结束 612.49s，队2 全歼胜 15:10
18:11:58.357  结算下发（xp=1052 与结果块一致）
18:11:59.948  返回车库
18:12:53.358  断开服务器，监控落盘（7,341 事件，0 丢弃）
```

回放文件名 `20260911_1801_...` 的 "1801" 即战斗进入时刻，两份材料同源无疑。

### 12.3 与回放解码的逐项对账

| 对账项 | 回放侧 | 会话侧 | 结论 |
|---|---|---|---|
| avatar/车辆 ID | avatarSessionID=546611552，玩家车 546611525 | avatar.id=546611552，玩家车 546611525 | ✅ 一致 |
| 30 人名单 | block[0] vehicles（15+15） | publicInfo repr 解析 30/30 | ✅ 姓名队伍全一致 |
| 战斗时长 | tick 推算 601.4s | 阶段 3 实测 **612.49s** | ⚠️ 差 11.29s=录制丢刻（见 12.4） |
| 四阶段 | 0x16/0x17 包（1/2/3/4，timer 29.943/899.948/60.0） | onPeriodChange 同序同时长 | ✅ 一致（60/30/900/60） |
| 击杀链 | 25 对 victim←killer（旧报告误作 26） | 25 对完全相同 + 精确时刻 | ✅ **逐对一致**，时间以会话为准 |
| 击杀数按人 | — | 30 人 frags 与结果块逐人一致 | ✅ |
| 玩家射击 | 15 发（射速约束推断） | onVehicleShot 15 次精确时刻 + 弹药 15→1 | ✅ |
| 玩家伤害 | 结果块 1669（分目标 296/598/353/258/164） | 可见事件 1280（262+34+282+329+209），Deiiv1 296=262+34 精确吻合 | ⚠️ 差 389：`onVehicleHealthChanged` 仅对 AoI 内车辆触发（全场仅录得 40,824/49,180 总伤害，83%），非数据矛盾 |
| 玩家轨迹 | 0xA 3,872 点，X/Z 范围 [17,482]/[-432,-231] | own 3,232 点，范围完全相同，对齐后出现 0.00m 精确重合点 | ✅ 同一场战斗 |
| 里程 | 结果块 mileage=1141 | 5Hz 轨迹实测 1,140m | ✅ 差 1m（舍入） |
| 0x31 回调 | 84 条（client_vehicle_state / bw_chat2.onActionReceived） | chat action ID 表全部命名（12.5） | ✅ 语义闭合 |
| 相机/导播 | 0x1A/0x1B 变速+模式切换 | 会话为 1x 实时战斗，无相机包 | ✅ 再录制定性成立 |

### 12.4 观看行为完整还原（本报告此前推断的实证升级）

以会话玩家轨迹（3,232 点）为基准，对回放 0xA 位置流做位置匹配（1,124 个高置信锚点），结合累计 tick 曲线与位置序列回退检测，得到观看者的**完整操作时间线**：

```
墙钟 0 ~ 1082.6s   回放界面停留/缓冲 18 分钟（阶段1 内容仅推进 78 tick≈7.8 游戏秒）
墙钟 1082.6~1107.9s 倒计时以 1.19x 观看
墙钟 1107.9~1143.1s 战斗段 35.17s 墙钟覆盖 612.49 游戏秒（平均 17.4x）：
  t≈0-84s     3.5-21x 快速浏览开局（位置锚点单调，无跳转）
  t≈46-49s    0.55x 慢放（首杀前 66.5s 的己方动向）
  t≈104-165s  ★至少 5 次回跳重看（pkt#50737/57378/77448/82351/89942 处
              位置序列倒回 true~106s 后重放，累计重放约 107 游戏秒——
              该时段含玩家 5/6 发射击与唯一击杀 Deiiv1，反复回看高光）
  t≈165-285s  约 30x 快进扫过（玩家静止蹲坑段）
  t≈285-612s  30-92x 高速冲线（高速段录制器丢刻，6,012/6,125 tick）
墙钟 1143.1s~ 阶段4 + 0x11 结果包 + 0xFFFFFFFF 结束符落盘
```

三条铁证链：① 累计 tick 偏差曲线前段 -107s（重放）/后段 +118s（丢刻）；② 位置序列 5 处真时间倒退；③ 总 tick 6,012 ≠ 期望 6,125。**"服务器回放在线观看的再录制"从推断升级为实证闭环。**

### 12.5 客户端事件语义新知（源码级）

- `arena.onVehicleKilled(targetID, attackerID, equipmentID, reason, numVehiclesAffected)`——客户端 `Avatar.py L2764` 原型核对；玩家击杀的 `numVehiclesAffected=-1` 为火炮溅射击杀特殊值，其余 24 杀均为 1；
- `veh.onVehicleDestroyed` = **BigWorld 实体对象销毁**（AoI 离开/战斗结束清理），不是死亡事件——30 次 = 25 阵亡车的实体清理中的非 AoI 部分 + 5 幸存者；真正的死亡只看 `onVehicleKilled`；
- `arena.onVehicleHealthChanged(victimID, attackerID, damage)` 与 `onVehicleHit(victimID, damage)` 的 arg2 均为伤害值（hit 可为 0=溅射未破甲）；
- 回放 0x31 中 `bw_chat2.onActionReceived` 的 eventID 经 `messenger_common_chat2.py` ID 发生器逐位推算全部命名：**19=REINIT_BATTLE_CHAT**（clock=0 处出现——再录制会话重建聊天，又一铁证）、**24=POSITIVE、26=AFFIRMATIVE、29=REPLY、30=CANCEL_REPLY、38=ATTACKING_ENEMY_WITH_SPG**（呼叫火炮集火，int64Arg1=玩家车 ID）、**42=RELOADINGGUN、74=ATTACKING_ENEMY**（交战自动标记，含 10 目标簇）、**76=DEFENDING_BASE**（守家自动标记）、**79=CONFIRM**；
- 玩家 siegeState 全程 0：261 工程本局未使用攻城模式切换（H 键），全程普通驾驶+瞄准模式。

### 12.6 新增可视化

![会话生命周期](charts/06_会话生命周期.png)

![观看行为与时间轴对齐](charts/07_观看行为与时间轴对齐.png)
"""

# 插入到 "## 附录 A" 之前
anchor = '---\n\n## 附录 A：加密与解包最小实现'
assert anchor in txt, '附录A锚点未找到'
txt = txt.replace(anchor, ch12 + '\n' + anchor)

# 更新 §11 交付物清单
old11 = """| `WoT回放解析数据包_20260911_caucasus.xlsx` | 7 个工作表：概览/包类型普查/实体表/车辆战绩/击杀链/事件时间线/玩家轨迹 |
| `WoT回放解码数据_20260911_caucasus.json` | 全量解码数据（实体/轨迹/事件/阶段/相机） |"""
new11 = """| `WoT回放解析数据包_20260911_caucasus.xlsx` | 11 个工作表：概览/包类型普查/实体表/车辆战绩/击杀链(25次修正版)/事件时间线/玩家轨迹/会话事件类型/会话生命周期/击杀链对照/玩家射击与伤害 |
| `WoT回放解码数据_20260911_caucasus.json` | 全量解码数据（实体/轨迹/事件/阶段/相机/session_log 交叉验证段） |"""
assert old11 in txt
txt = txt.replace(old11, new11)

old11b = "| `charts/01-05 *.png` | 包类型分布 / 战斗时间线 / 轨迹图 / 性能与倍速 / 伤害排行 |"
new11b = "| `charts/01-07 *.png` | 包类型分布 / 战斗时间线 / 轨迹图 / 性能与倍速 / 伤害排行 / 会话生命周期 / 观看行为与时间轴对齐 |"
assert old11b in txt
txt = txt.replace(old11b, new11b)

# 附录 D 更新
oldD = "4. 阶段 1 的 0x17 值 -141055.1 为等待期未初始化计时器，无实际语义。"
newD = """4. 阶段 1 的 0x17 值 -141055.1 为等待期未初始化计时器，无实际语义；
5. ~~0x31 聊天回调 eventID 语义未命名~~——已通过 `messenger_common_chat2.py` ID 发生器推算 + 会话日志比对全部命名（见 §12.5），此遗留项闭合；
6. 会话日志 `battle_tick.client_stats` 为被截断的 Python2 repr 串（fps/ping 分桶仅存片段），无法完整复原逐帧性能曲线，仅可确认 0x1F 包与统计机制同源；
7. 回放内 545320xxx/545508xxx 段 129 个实体的具体种类（可破坏物/特效/逻辑）仅有类型索引证据（7/40/28/3/29/18），未逐一命名。"""
assert oldD in txt
txt = txt.replace(oldD, newD)

io.open(P, 'w', encoding='utf-8').write(txt)
print('第12章已插入, §11/附录D 已更新')
print(f'击杀样本校验: {len(kills)} 条')
