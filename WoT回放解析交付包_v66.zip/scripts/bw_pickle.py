# -*- coding: utf-8 -*-
"""bw_pickle.py — BigWorld 定制 pickle 兼容解码器"""
import datetime
import io
import pickle


class BWFixedDict(dict):
    """_BWp.FixedDict 兼容类"""
    def __init__(self, *args, **kwargs):
        try:
            dict.__init__(self, *args, **kwargs)
        except Exception:
            dict.__init__(self)


class BWArray(list):
    """_BWp.Array 兼容类"""
    pass


class BWVector2(tuple):
    """Math.Vector2"""
    def __new__(cls, x=0.0, y=0.0):
        try:
            return tuple.__new__(cls, (float(x), float(y)))
        except Exception:
            return tuple.__new__(cls, (x, y))


class BWVector3(tuple):
    """Math.Vector3"""
    def __new__(cls, x=0.0, y=0.0, z=0.0):
        try:
            return tuple.__new__(cls, (float(x), float(y), float(z)))
        except Exception:
            return tuple.__new__(cls, (x, y, z))


def _find_class(module, name):
    mn = module.decode() if isinstance(module, bytes) else module
    nn = name.decode() if isinstance(name, bytes) else name
    if mn == '_BWp':
        if nn == 'FixedDict':
            return BWFixedDict
        if nn == 'Array':
            return BWArray
    if mn == 'Math':
        if nn == 'Vector2':
            return BWVector2
        if nn == 'Vector3':
            return BWVector3
    if mn == 'datetime' and nn == 'datetime':
        return datetime.datetime
    if mn == '__builtin__' or mn == 'builtins':
        if nn in ('str', 'unicode'):
            return str
        if nn in ('int', 'long'):
            return int
        if nn == 'float':
            return float
        if nn == 'bool':
            return bool
        if nn in ('list', 'tuple', 'dict', 'set'):
            return {'list': list, 'tuple': tuple, 'dict': dict, 'set': set}[nn]
    raise pickle.UnpicklingError('not allowed: %s.%s' % (mn, nn))


class _BWUnpickler(pickle.Unpickler):
    def find_class(self, module, name):
        return _find_class(module, name)


def bw_loads(data):
    """解码 BigWorld pickle (protocol 2, py2 风格)"""
    return _BWUnpickler(io.BytesIO(data), encoding='utf-8', errors='replace').load()


if __name__ == '__main__':
    import struct
    import sys
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.path.insert(0, '/home/z/my-project/scripts')
    from wot_replay_lib import ReplayFile

    R = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
    pkts = R.pkts
    n = 0
    for p in pkts:
        if p[0] != 0x31:
            continue
        (nl,) = struct.unpack_from('<I', p[2], 0)
        name = p[2][4:4 + nl].decode('utf-8', 'replace')
        off = 4 + nl
        (dl,) = struct.unpack_from('<I', p[2], off)
        data = p[2][off + 4:off + 4 + dl]
        try:
            obj = bw_loads(data)
            print('pkt#%-6d clk=%-10d %-32s %s' % (p[3], p[1], name, repr(obj)[:220]))
        except Exception as e:
            print('pkt#%-6d clk=%-10d %-32s ERR %s' % (p[3], p[1], name, e))
        n += 1
        if n >= 25:
            break
