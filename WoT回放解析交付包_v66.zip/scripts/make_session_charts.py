# -*- coding: utf-8 -*-
"""make_session_charts.py — 生成第12章两张新图表 (06 会话生命周期 / 07 观看行为与时间轴对齐)"""
import json
import os
import sys
import struct
import math
import statistics
import bisect

import matplotlib
import matplotlib.font_manager as fm

fm.fontManager.addfont('/usr/share/fonts/truetype/chinese/SarasaMonoSC-Regular.ttf')
fm.fontManager.addfont('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')

import matplotlib.pyplot as plt

plt.rcParams.update({
    'font.sans-serif': ['Sarasa Mono SC', 'DejaVu Sans'],
    'axes.unicode_minus': False,
    'figure.facecolor': '#FFFFFF', 'axes.facecolor': '#FFFFFF',
    'axes.edgecolor': '#E5E7EB', 'axes.linewidth': 0.8,
    'axes.spines.top': False, 'axes.spines.right': False,
    'axes.grid': False,
    'xtick.major.size': 0, 'ytick.major.size': 0,
    'xtick.labelsize': 9, 'ytick.labelsize': 9,
    'axes.labelsize': 10, 'axes.titlesize': 15, 'axes.titleweight': 'bold', 'axes.titlepad': 14,
    'legend.frameon': False, 'legend.fontsize': 9,
    'figure.dpi': 200, 'savefig.dpi': 200, 'savefig.facecolor': '#FFFFFF',
})

C_BLUE, C_CYAN, C_PURPLE, C_AMBER, C_RED, C_GREEN = '#3B82F6', '#06B6D4', '#8B5CF6', '#F59E0B', '#EF4444', '#10B981'
G900, G700, G500, G400, G300, G200, G100, G50 = '#111827', '#374151', '#6B7280', '#9CA3AF', '#D1D5DB', '#E5E7EB', '#F3F4F6', '#F9FAFB'

OUT = '/home/z/my-project/download/charts'
os.makedirs(OUT, exist_ok=True)
BATTLE_START_BT = 139.769

S = json.load(open('/home/z/my-project/scripts/session_summary.json', encoding='utf-8'))

# ═══════════════════ 图 6: 会话生命周期 ═══════════════════
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(11.5, 7.6), constrained_layout=True,
                               gridspec_kw={'height_ratios': [1.15, 1]})

# ---- 上: 会话阶段甘特 ----
phases = [
    ('车库加载', 0, 34.2, G400),
    ('车库停留', 34.2, 37.6, G300),
    ('随机战排队', 71.8, 115.2, C_AMBER),
    ('战斗加载+等待', 115.2, 125.4, C_CYAN),
    ('倒计时 30s', 125.4, 155.4, C_PURPLE),
    ('战斗 612.49s', 155.4, 767.9, C_GREEN),
    ('结算+回车库', 767.9, 778.5, C_BLUE),
    ('车库→断开', 778.5, 798.5, G300),
]
for i, (name, s, e, c) in enumerate(phases):
    ax1.barh(0, e - s, left=s, height=0.52, color=c, zorder=3)
    mid = (s + e) / 2
    ax1.text(mid, 0.42, name, ha='center', va='bottom', fontsize=8.5, color=G700)
    ax1.text(mid, -0.40, f'{e - s:.1f}s', ha='center', va='top', fontsize=8, color=G500)

marks = [(115.2, '匹配成功'), (125.4, 'avatar_ready\n(加载5.2s)'), (155.4, '战斗开始'),
         (767.9, '全歼获胜\n15:10'), (778.5, '结算下发')]
for x, label in marks:
    ax1.plot([x], [0], 'o', color=G900, ms=5, zorder=5)
    ax1.annotate(label, (x, 0), xytext=(x, -0.62), ha='center', fontsize=7.5, color=G500)

ax1.set_xlim(-8, 806)
ax1.set_ylim(-1.0, 0.85)
ax1.set_yticks([])
ax1.set_xlabel('客户端运行秒（bt，自 17:59:34.861 启动起）')
ax1.set_title('客户端会话生命周期（session_20260911_175934.jsonl，7,341 事件，总时长 798.5s）', loc='left')
ax1.xaxis.grid(True, alpha=0.08, color=G300)
ax1.set_axisbelow(True)

# ---- 下: 战斗内关键事件散点（真实游戏时间） ----
kills = S['battle']['kills']
shots = S['player']['shots_battle_t']
kx = [k['battle_t'] for k in kills if k['victim_team'] == 1]
kv = [(k['battle_t'], k['victim_name'], k['killer_name']) for k in kills]
score1, score2 = 0, 0
scores = []
for k in kills:
    if k['victim_team'] == 1:
        score2 += 1
    else:
        score1 += 1
    scores.append((k['battle_t'], score1, score2))

for t, s1, s2 in scores:
    pass
ax2.scatter([t for t, _, _ in scores], [2 for _ in scores], marker='v', s=42, color=C_RED, zorder=4, label='队伍1车辆阵亡')
ax2.scatter([t for t, _, _ in scores], [1 for _ in scores], marker='^', s=42, color=C_GREEN, zorder=4, label='队伍2车辆阵亡')
ax2.scatter(shots, [0.5] * len(shots), marker='s', s=30, color=C_BLUE, zorder=4, label='玩家射击(15发)')

# 比分阶梯线(右轴)
ax2b = ax2.twinx()
kt = [t for t, _, _ in scores]
ks2 = [s2 for _, s2, _ in [(a, b, c) for (a, b, c) in [(t, s1, s2) for t, s1, s2 in scores]]]
ax2b.step([0] + kt, [0] + [s2 for _, _, s2 in scores], where='post', color=G400, lw=1.2, alpha=0.85)
ax2b.set_ylim(0, 16)
ax2b.set_yticks(range(0, 16, 3))
ax2b.tick_params(labelsize=8, colors=G500)
ax2b.set_ylabel('队伍2 累计击杀', fontsize=9, color=G500)
ax2b.spines['right'].set_visible(True)
ax2b.spines['right'].set_color(G200)

for t, name, in [(215.2, '★玩家击杀\nDeiiv1'), (607.0, '最后一杀\n全歼 12:15')]:
    ax2.annotate(name, (t, 2), xytext=(t - 12, 2.55), fontsize=8, color=G900, ha='center',
                 arrowprops=dict(arrowstyle='-', color=G400, lw=0.8))

ax2.set_ylim(-0.15, 3.0)
ax2.set_yticks([0.5, 1, 2])
ax2.set_yticklabels(['玩家射击', '队伍2击杀', '队伍1击杀'])
ax2.set_xlim(-15, 640)
ax2.set_xlabel('战斗游戏时间（秒，阶段3 起点 t=0，实测总长 612.49s）')
ax2.set_title('战斗事件时间线（客户端日志权威时刻：25 杀 / 15 发炮弹 / 两波占点）', loc='left')
ax2.xaxis.grid(True, alpha=0.08, color=G300)
ax2.set_axisbelow(True)
ax2.legend(loc='upper left', bbox_to_anchor=(0.0, 1.0))

# 占领窗口
for (x0, x1) in [(445.0, 457.0), (600.0, 611.5)]:
    ax2.axvspan(x0, x1, color=C_AMBER, alpha=0.12, zorder=1)
ax2.text(451, 2.72, '试探占点\n0→2', ha='center', fontsize=7.5, color='#B45309')
ax2.text(605.7, 2.72, '终局占点\n0→11', ha='center', fontsize=7.5, color='#B45309')

fig.savefig(OUT + '/06_会话生命周期.png')
plt.close(fig)
print('图6 完成')

# ═══════════════════ 图 7: 观看行为与时间轴对齐 ═══════════════════
sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

own_pts = []
for line in open('/home/z/my-project/upload/session_20260911_175934.jsonl', encoding='utf-8'):
    o = json.loads(line)
    if o['ev'] == 'battle_tick' and o['data'].get('own'):
        d = o['data']
        own_pts.append((d['bt'] - BATTLE_START_BT, *d['own']['position']))

R = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
pkts = R.pkts
p3_pkt = next(p[3] for p in pkts if p[0] == 0x16 and p[2] == b'\x03\x00\x00\x00')
p4_pkt = next(p[3] for p in pkts if p[0] == 0x16 and p[2] == b'\x04\x00\x00\x00')

rep_own = []
for ty, clock, payload, idx in pkts:
    if ty != 0xA or not (p3_pkt <= idx <= p4_pkt) or len(payload) < 45:
        continue
    eid, _ = struct.unpack_from('<II', payload, 0)
    if eid == 546611525:
        x, y, z = struct.unpack_from('<3f', payload, 8)
        rep_own.append((idx, clock, x, z))

anchors = []
for idx, clock, x, z in rep_own:
    cands = [bt for bt, sx, sy, sz in own_pts if abs(sx - x) <= 2.0 and abs(sz - z) <= 2.0]
    if cands and max(cands) - min(cands) <= 8.0:
        anchors.append((idx, clock, sum(cands) / len(cands)))
anchors.sort()

tick_idx = sorted(p[3] for p in pkts if p[0] == 0x36 and p3_pkt <= p[3] <= p4_pkt)

fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(11.5, 8.2), constrained_layout=True,
                               gridspec_kw={'height_ratios': [1.2, 1]})

# ---- 上: 真实游戏时间 vs 观看墙钟 (展示倍速与回跳) ----
a_clk = [a[1] / 1e6 for a in anchors]
a_tru = [a[2] for a in anchors]
# 转为相对战斗段墙钟
base = min(a_clk)
ax1.scatter([c - base for c in a_clk], a_tru, s=6, color=C_BLUE, alpha=0.45, zorder=3, label='位置匹配锚点(1,124个)')

# 理想1x参考
lim_c = max(a_clk) - base
ax1.plot([0, lim_c], [0, lim_c], '--', color=G300, lw=1.2, zorder=2)
ax1.text(lim_c * 0.86, lim_c * 0.80, '1x 参考线', fontsize=8.5, color=G400, rotation=38)

# 分段速度标注
seg_style = [
    ((0.0, 1.1), 8, '开局 3.5-21x'),
    ((1.1, 3.9), 0.55, '慢放 0.55x\n(首杀前夕)'),
    ((3.9, 6.2), 10, '7-13x'),
    ((6.2, 8.6), 30, '回跳重看区\n(≥5次, true 104-165s)'),
    ((8.6, 17.3), 30, '30x 快进'),
    ((17.3, 35.2), 55, '终局 30-92x 高速+丢刻'),
]
for (x0, x1), v, label in seg_style:
    if v:
        ax1.plot([x0, x1], [0, (x1 - x0) * v], '-', color=C_AMBER, lw=2.2, alpha=0.9, zorder=4)
ax1.annotate('回跳重看区\n(true 104-165s, ≥5次)', (7.4, 100), xytext=(8.6, 40), fontsize=8.5, color='#B45309',
             arrowprops=dict(arrowstyle='->', color=C_AMBER, lw=1.0))
ax1.annotate('终局 30-92x 高速\n(录制器丢刻段)', (26, 380), xytext=(21.5, 200), fontsize=8.5, color='#B45309',
             arrowprops=dict(arrowstyle='->', color=C_AMBER, lw=1.0))

ax1.set_xlabel('观看会话墙钟（秒，战斗段起点=0，总长 35.17s）')
ax1.set_ylabel('真实游戏时间（秒）')
ax1.set_title('再录制的观看行为还原：真实游戏时间 vs 观看墙钟（平均 17.4x）', loc='left')
ax1.set_xlim(0, 36.5)
ax1.set_ylim(0, 640)
ax1.yaxis.grid(True, alpha=0.08, color=G300)
ax1.xaxis.grid(True, alpha=0.08, color=G300)
ax1.set_axisbelow(True)
ax1.legend(loc='lower right')

# ---- 下: 累计tick与偏差 ----
rows = []
for t, n in [(0.0, 0)] + [(a[2], bisect.bisect_right(tick_idx, a[0])) for a in anchors[::max(1, len(anchors) // 60)]] + [(612.49, len(tick_idx))]:
    rows.append((t, n))
rows.sort()
ts = [r[0] for r in rows]
ns = [r[1] / 10.0 for r in rows]
ax2.plot(ts, ns, '-', color=C_CYAN, lw=1.8, zorder=3, label='tick 推算游戏时间')
ax2.plot(ts, ts, '--', color=G300, lw=1.2, zorder=2, label='理想完整时间轴')
ax2.fill_between(ts, ns, ts, color=C_RED, alpha=0.10, zorder=1)

ax2.annotate('曲线在理想线上方 = 内容被重复回放\n(前段 +107 游戏秒)', (100, 165), fontsize=8.5, color='#B91C1C', ha='left')
ax2.annotate('曲线回落到线下 = 高速段丢刻\n(后段 -118 游戏秒, 净缺 11.29s)', (330, 425), fontsize=8.5, color='#B91C1C', ha='left')

ax2.set_xlabel('真实游戏时间（秒）')
ax2.set_ylabel('累计 tick ÷ 10（秒）')
ax2.set_title('累计 tick 与理想时间轴的偏差：回跳重放（+107s）与高速丢刻（-118s）的叠加', loc='left')
ax2.set_xlim(0, 640)
ax2.set_ylim(0, 640)
ax2.yaxis.grid(True, alpha=0.08, color=G300)
ax2.xaxis.grid(True, alpha=0.08, color=G300)
ax2.set_axisbelow(True)
ax2.legend(loc='upper left')
ax2.annotate('终点: 612.49s 实测\nvs 601.2s tick 推算', (612.49, 601.2), xytext=(505, 520),
             fontsize=8, color=G700, ha='right', va='bottom',
             arrowprops=dict(arrowstyle='->', color=G400, lw=0.8))

fig.savefig(OUT + '/07_观看行为与时间轴对齐.png')
plt.close(fig)
print('图7 完成')
