# -*- coding: utf-8 -*-
"""run_def_dump.py — 在服务器上跑用户的 def_dump.py（改 PKG 路径指向本地 mini pkg）。"""
import os
import sys

TOOLS = '/home/z/my-project/upload/tools'
sys.path.insert(0, TOOLS)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import def_dump

def_dump.PKG = '/home/z/my-project/work/mini_scripts.pkg'   # 唯一改动

if __name__ == '__main__':
    sys.argv[0] = 'def_dump.py'
    def_dump.main()
