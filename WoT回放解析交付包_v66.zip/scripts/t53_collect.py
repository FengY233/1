#!/usr/bin/env python3
"""t53_collect.py — Task 53-b 语义标注交付收集器
输入: /tmp/wot/t53_events_v1.jsonl (6822 包全量事件流)
输出: download/data_v34/
  语义标注统计_t53_stats.json  — 全维度统计 + 名称表
  语义标注样例_t53_samples.json — 每语义族完整样例
  语义标注全事件流_t53.jsonl   — 全量事件流副本
"""
import json, os, shutil
from collections import Counter, defaultdict

DL = '/home/z/my-project/download'
TMP = '/tmp/wot'
OUT = f'{DL}/data_v34'
os.makedirs(OUT, exist_ok=True)

recs = [json.loads(l) for l in open(f'{TMP}/t53_events_v1.jsonl')]

# ---------- 名称表 ----------
tname = {}
d = json.load(open(f'{DL}/data_v30/tid名表_corpus插桩5227_t49_tid_names.json'))
for tid, names in d.items():
    best, bc = None, -1
    for nm, c in names.items():
        if c > bc:
            bc, best = c, nm
    if best:
        parts = best.rsplit('_', 1)
        tname[int(tid)] = parts[0] if len(parts) == 2 and parts[1].isdigit() else best

OV_ANCHOR = {0: 'syncVehicleAttrs', 1: 'vehicleAmmoList', 18: 'targetingInfo'}

# ---------- 统计 ----------
ev_c = Counter()
fmt_c = Counter()
tid_c = Counter()
me_model = Counter()
mid_c = Counter()
rk_c = Counter()
fr_cls = Counter()
per_gi = defaultdict(lambda: Counter())
families = Counter()
roster_per_gi = Counter()
ln_names = Counter()
subs_paths = Counter()
attach_paths = Counter()
max_depth_fr = 0

for r in recs:
    g = per_gi[r['gi']]
    g['n'] += 1
    g['via_' + r['via']] += 1
    if 'roster' in r:
        roster_per_gi[r['gi']] += len(r['roster'])
        g['roster_records'] += len(r['roster'])
    fam = set()
    for e in r['events']:
        k = e[0]
        ev_c[k] += 1
        if k == 'pr':
            fmt_c[e[2]] += 1
            if e[2] in ('sub', 'attach', 't54', 'a104') or e[2].startswith('ov'):
                fam.add(e[2])
            if e[2] == 'sub':
                for sb in e[5].get('subs', []):
                    subs_paths[sb['path']] += 1
            if e[2] == 'attach':
                attach_paths[e[5].get('path', '')] += 1
        elif k == 'cr':
            tid_c[e[2]] += 1
        elif k == 'me':
            me_model[e[1]] += 1
            if e[1] == 'pk':
                for m in e[2]:
                    if isinstance(m, int):
                        mid_c[m] += 1
            else:
                for m in e[2]:
                    if isinstance(m, str):
                        ln_names[m] += 1
        elif k == 'nd':
            rk_c[e[2]] += 1
        elif k == 'fr':
            fr_cls[e[2]] += 1
    for f in fam:
        families[f] += 1

# create tid → 名称 join
tid_table = []
for tid, cnt in tid_c.most_common():
    tid_table.append({'tid': tid, 'count': cnt, 'name': tname.get(tid, '')})

stats = {
 'meta': {
  'corpus': '随机战 10 场 (RND), 0x32 通道 6822 包',
  'decoder': 't53_semantic (v8 文法 + 事件回滚协议 + per-tid 语义读取器)',
  'generated': '2026-09-26 Task 53-b',
 },
 'acceptance': {
  'sem': sum(1 for r in recs if r['via'] == 'sem'),
  'polluted': sum(1 for r in recs if r['via'] == 'polluted'),
  'free': sum(1 for r in recs if r['via'] == 'free'),
  'total': len(recs),
  'pct': 100.0,
  'note': 'sem=6776 与 v8 Pass1 完全一致且 polluted=0 — v8 接受集不依赖注册污染, 节点表语义干净(新实证)',
 },
 'events': dict(ev_c.most_common()),
 'frames_by_class': {str(k): v for k, v in sorted(fr_cls.items())},
 'frames_note': 'class4/6(updateNode) 本语料零出现 — 0x32 全为创建流, 节点更新走 0x24/0x07 通道(通道分工新实证)',
 'node_rk_dist': {str(k): v for k, v in sorted(rk_c.items())},
 'prop_fmt_dist': dict(fmt_c.most_common()),
 'create_tid_table': tid_table,
 'method_model': dict(me_model),
 'method_id_top': mid_c.most_common(20),
 'method_ln_names_top': ln_names.most_common(15),
 'semantic_families': dict(families.most_common()),
 'roster': {
  'packets': sum(1 for r in recs if 'roster' in r),
  'records_total': sum(roster_per_gi.values()),
  'per_replay': {str(k): v for k, v in sorted(roster_per_gi.items())},
 },
 'subscription_paths': dict(subs_paths.most_common()),
 'attach_paths_top': dict(attach_paths.most_common(10)),
 'per_replay': {str(k): dict(v) for k, v in sorted(per_gi.items())},
 'name_tables': {
  'tid_base_names': {str(k): v for k, v in sorted(tname.items())},
  'ownvehicle_prop_anchors': {str(k): v for k, v in sorted(OV_ANCHOR.items())},
 },
}

# ---------- 样例 ----------
def find(pred):
    for r in recs:
        if pred(r):
            return r
    return None

def slim(r, keep_roster=False):
    o = {'gi': r['gi'], 'idx': r['idx'], 'len': r['len'], 'via': r['via'],
         'end': r['end'], 'tail': r['tail'], 'events': r['events']}
    if keep_roster and 'roster' in r:
        o['roster_first2'] = r['roster'][:2]
        o['roster_count'] = len(r['roster'])
    return o

samples = {}
samples['ownvehicle'] = slim(find(lambda r: any(e[0] == 'pr' and e[2] == 'ov1' for e in r['events'])))
samples['subscription'] = slim(find(lambda r: any(e[0] == 'pr' and e[2] == 'sub' for e in r['events'])))
samples['teamslots'] = slim(find(lambda r: any(e[0] == 'pr' and e[2] == 't54' for e in r['events'])))
samples['attach'] = slim(find(lambda r: any(e[0] == 'pr' and e[2] == 'attach' and len(e[5].get('records', [])) >= 3 for e in r['events'])))
samples['floats'] = slim(find(lambda r: any(e[0] == 'pr' and e[2] == 'a104' for e in r['events'])))
samples['roster'] = slim(find(lambda r: 'roster' in r), keep_roster=True)
samples['class1_batch'] = slim(find(lambda r: any(e[0] == 'cl' and len(e[2]) >= 4 for e in r['events'])))
samples['hierarchy_nested'] = slim(find(lambda r: sum(1 for e in r['events'] if e[0] == 'cr' and e[2] in (125, 127, 128)) >= 3))
samples['ln_methods'] = slim(find(lambda r: any(e[0] == 'me' and e[1] == 'ln' and e[2] for e in r['events'])))
samples['deep_chain'] = slim(max((r for r in recs if r['events']), key=lambda r: len(r['events'])))

# ---------- 写出 ----------
json.dump(stats, open(f'{OUT}/语义标注统计_t53_stats.json', 'w'), ensure_ascii=False, indent=1)
json.dump(samples, open(f'{OUT}/语义标注样例_t53_samples.json', 'w'), ensure_ascii=False, indent=1)
shutil.copy(f'{TMP}/t53_events_v1.jsonl', f'{OUT}/语义标注全事件流_t53.jsonl')
print('data_v34 写出完成:')
for f in sorted(os.listdir(OUT)):
    print(f'  {f}  {os.path.getsize(os.path.join(OUT, f)):,}B')
print()
print('语义族:', dict(families.most_common()))
print('订阅路径:', dict(subs_paths.most_common()))
print('ln 方法名样例:', ln_names.most_common(8))
print('mid top:', mid_c.most_common(10))
