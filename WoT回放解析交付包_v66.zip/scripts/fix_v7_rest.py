# -*- coding: utf-8 -*-
"""fix_v7_rest.py — JSON 字符串残留修正 + xlsx v7 工作表"""
import json

JSONF = '/home/z/my-project/download/WoT回放解码数据_20260911_caucasus.json'
XLSX = '/home/z/my-project/download/WoT回放解析数据包_20260911_caucasus.xlsx'

d = json.load(open(JSONF))
hits = []


def walk(obj, path=''):
    if isinstance(obj, dict):
        for k, v in obj.items():
            walk(v, path + '/' + str(k))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            walk(v, path + '[%d]' % i)
    elif isinstance(obj, str) and '200528740' in obj:
        hits.append(path)
        return obj.replace('200528740', '200229732') + '(v7 勘误:原记录十进制转写错误)'


def walk2(obj):
    if isinstance(obj, dict):
        return {k: walk2(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [walk2(v) for v in obj]
    if isinstance(obj, str) and '200528740' in obj:
        return obj.replace('200528740', '200229732') + '(v7 勘误:原十进制转写错误)'
    return obj


d = walk2(d)
json.dump(d, open(JSONF, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('JSON 字符串残留修正:', hits)

# ── xlsx ──
from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

wb = load_workbook(XLSX)
HDR = PatternFill('solid', fgColor='645B42')
SUB = PatternFill('solid', fgColor='EDEDEB')
HF = Font(color='FFFFFF', bold=True)
THIN = Side(style='thin', color='D7D2C2')
BD = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
WRAP = Alignment(wrap_text=True, vertical='top')

if 'v7终局攻坚' in wb.sheetnames:
    del wb['v7终局攻坚']
ws = wb.create_sheet('v7终局攻坚')
rows = [
    ('v7 终局攻坚（2026-09-23 定稿）——无服务器资料条件下本地材料收官', ''),
    ('项', '结论'),
    ('0x11 校验算法', '破解：pickle 元组真值 (6677, 200229732)；zlib.crc32(6677B 存储 blob)=0x0BEF4364=200229732 逐字节精确命中；BigWorld (size, crc32) 信封；v6 的 200,528,740 系十进制转写错误'),
    ('0x20 确名', 'setGunReloadTime 装填计时器：[负装填经过秒][装填时长]；BattleReplay.py:681 + AmmoReplayRecorder + FUN_140588350/FUN_1405796f0 符号翻转 + 15 射击↔15 复位逐对吻合(延迟 0.09-0.34s)；B=26.419s=261工程装填时长；勘误 v1"相机朝向"/v6"天气阵风"'),
    ('实体类型确名', 'entities.xml（客户端注册表，1-based）：3=ArenaInfo / 6=Vehicle / 7=AreaDestructibles / 18=EmptyEntity(勘误"天气控制器") / 28=TeamInfo / 29=AvatarInfo / 40=NetworkEntity；附录D 第 7 条闭合'),
    ('0x3D 定性收口', 'WGReplayMessageHandler+0xa8 会话侧 entityDefs 指纹；错误码 ENTITYDEF_MISMATCH=2；输入=编译后 .def 集合，本地无该文件集，原理上不可复算；语义/存储/校验路径 100% 钉死'),
    ('覆盖率终态', '口径不变：结构层 100% / 语义层 A 级 99.48% / B 级 0.52%；38 种类型全部有确定名字与语义（0x20 为最后一个未名类型）'),
    ('剩余开放', '仅两项且均需服务器 .def/CGF 资料：0x07 属性 1/16/33/34 的 .def 级确名（语义已实证）；0x32/0x37 视觉节点 ID→节点名映射'),
]
for r in rows:
    ws.append(list(r))
for c in ('A1', 'B1'):
    ws[c].font = Font(bold=True, size=12)
    ws[c].fill = SUB
for c in ('A2', 'B2'):
    ws[c].fill = HDR
    ws[c].font = HF
for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
    for cell in row:
        cell.border = BD
        cell.alignment = WRAP
ws.column_dimensions['A'].width = 16
ws.column_dimensions['B'].width = 110
ws.freeze_panes = 'A3'

ov = wb['概览']
ov.append(['v7 终局攻坚', '0x11 校验破解(crc32) / 0x20 确名 setGunReloadTime(15/15 射击对齐) / 实体类型权威确名(entities.xml) / 0x3D 定性收口；38 种类型全部有确定名字与语义'])
for cell in ov[ov.max_row]:
    cell.alignment = WRAP
wb.save(XLSX)
print('xlsx 更新完成:', wb.sheetnames)
