# -*- coding: utf-8 -*-
"""calibrate_time.py — 用阶段边界+0x1F 值分段标定 clock"""
import io
import struct
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

R = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
pkts = R.pkts

# 阶段边界 clock
periods = {}
for p in pkts:
    if p[0] == 0x16:
        (v,) = struct.unpack('<I', p[2])
        periods[v] = p[1]
print('阶段 clock:', {k: v for k, v in sorted(periods.items())})
p2, p3, p4 = periods[2], periods[3], periods[4]

f = [(p[1], struct.unpack('<I', p[2])[0], p[3]) for p in pkts if p[0] == 0x1F]

print()
print('==== 0x1F 在阶段边界附近的值 ====')
for name, pc in (('period2', p2), ('period3', p3), ('period4', p4)):
    near = [x for x in f if abs(x[0] - pc) < 3_000_000]
    print('-- %s (clock=%d):' % (name, pc))
    for clk, val, idx in near[:6]:
        print('   pkt#%d clk=%d val=%d (Δclk=%+d)' % (idx, clk, val, clk - pc))

print()
print('==== 0x1F (clock, val) 每隔400个的斜率 ====')
for i in range(0, len(f) - 400, 400):
    c0, v0, _ = f[i]
    c1, v1, _ = f[i + 400]
    if c1 > c0 and v1 != v0:
        print('  [%5d] clk %d→%d (Δ=%d)  val %d→%d (Δ=%+d)  斜率=%.3f val/s' % (
            i, c0, c1, c1 - c0, v0, v1, v1 - v0, (v1 - v0) / ((c1 - c0) / 1e6)))

print()
print('==== 0x1F val==115227 的 clock 范围; val==301 的 clock ====')
v115 = [x for x in f if 115000 <= x[1] <= 115999]
v301 = [x for x in f if x[1] == 301]
if v115:
    print('  115xxx: %d 个, clock %d .. %d' % (len(v115), v115[0][0], v115[-1][0]))
if v301:
    print('  301: %d 个, clock %d .. %d' % (len(v301), v301[0][0], v301[-1][0]))
vff = [x for x in f if x[1] > 4278000000]
if vff:
    print('  0xFF..: %d 个, clock %d .. %d, val样本 %d' % (
        len(vff), vff[0][0], vff[-1][0], vff[0][1]))

print()
print('==== 阶段区间包密度 ====')
segs = [('setup/等待(clock=0)', 0, 1), ('非零→p2', 1037503037, p2), ('p2→p3(倒计时)', p2, p3), ('p3→p4(战斗)', p3, p4), ('p4→结束', p4, 1143158129 + 1)]
for name, lo, hi in segs:
    cnt = sum(1 for p in pkts if lo <= p[1] < hi)
    print('  %-20s clock[%d..%d): %d 包' % (name, lo, hi, cnt))

print()
print('==== 0x15 (8字节) 双 u32 解读 ====')
for p in pkts:
    if p[0] == 0x15:
        a, b = struct.unpack('<II', p[2])
        (fa, fb) = struct.unpack('<ff', p[2])
        print('  pkt#%d: u32=(%d, %d) f32=(%.4f, %.4f)' % (p[3], a, b, fa, fb))
        print('  与 p2/p3/p4 clock 差: %+d %+d %+d' % (p2 - a, p3 - a, p4 - a) if a else '')
