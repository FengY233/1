#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""sweep_digest.py — 变体矩阵扫描: 单因素 + 高价值组合"""
import itertools
import json
import os
import subprocess
import sys

TARGET = '5DF886F75E73B33CFF9D87FB9C69389C'
BASE = {"client_flags": 0x04, "comp_bits": True, "count": True,
        "vlh_size": 4, "name_nul": False, "flags_mask": 0x5F,
        "allow_none": True, "seq_size": True, "int_size_field": 4,
        "tag_nul": True, "cs_only": True, "exposed_only": True,
        "vlh_default": 1, "sort_csi": True, "count_after_args": True}

SINGLE = {
    'client_flags': [0x01, 0x00, 0x05, 0x06],
    'comp_bits': [False],
    'count': [False],
    'vlh_size': [2, 1],
    'name_nul': [True],
    'flags_mask': [0xFF, 0x07, 0x17, 0x3F, 0x1F],
    'allow_none': [False],
    'seq_size': [False],
    'int_size_field': [1],
    'tag_nul': [False],
    'cs_only': [False],
    'exposed_only': [False],
    'vlh_default': [2],
    'sort_csi': [False],
}


def run(v):
    env = dict(os.environ, DIGEST_V=json.dumps(v))
    r = subprocess.run(['python3', 'scripts/digest_v8.py', '--quiet'],
                       capture_output=True, text=True, env=env, timeout=280)
    for l in r.stdout.splitlines():
        if 'digest =' in l:
            return l.split('=')[1].strip()
    return 'ERR: ' + (r.stderr.strip().splitlines()[-1] if r.stderr else '?')[:120]


def main():
    n = 0
    print('== 单因素扫描 ==')
    for key, vals in SINGLE.items():
        for val in vals:
            v = dict(BASE)
            v[key] = val
            d = run(v)
            n += 1
            hit = ' ★★★命中!' if d == TARGET else ''
            print('%2d. %-18s = %-8s -> %s%s' % (n, key, val, d, hit))
            if hit:
                return
    print()
    print('== 二因素组合 (高价值) ==')
    keys = [('client_flags', [0x01, 0x00]), ('comp_bits', [False]),
            ('count', [False]), ('tag_nul', [False]),
            ('name_nul', [True]), ('flags_mask', [0xFF, 0x07])]
    for (k1, v1s), (k2, v2s) in itertools.combinations(keys, 2):
        for v1 in v1s:
            for v2 in v2s:
                v = dict(BASE)
                v[k1] = v1
                v[k2] = v2
                d = run(v)
                n += 1
                hit = ' ★★★命中!' if d == TARGET else ''
                print('%2d. %s=%s & %s=%s -> %s%s' % (n, k1, v1, k2, v2, d, hit))
                if hit:
                    return


if __name__ == '__main__':
    main()
