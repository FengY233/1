# -*- coding: utf-8 -*-
"""probe_layout.py — 用浮点合理性自动探测 0x5/0xA/0x1A/0x26 字段对齐"""
import io
import struct
import sys
import math

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

R = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
pkts = R.pkts


def f32(b, off):
    return struct.unpack_from('<f', b, off)[0]


def is_sane(v):
    return (math.isfinite(v) and -1500.0 <= v <= 1500.0 and v != 0.0)


def probe(name, ty, n=6):
    print('==== %s (type 0x%X) 浮点对齐扫描 ====' % (name, ty))
    cnt = 0
    for p in pkts:
        if p[0] != ty or len(p[2]) < 40:
            continue
        b = p[2]
        # 对每个偏移 4..len-12，统计连续3个 sane float 的窗口
        good = []
        for off in range(4, len(b) - 12):
            if all(is_sane(f32(b, off + i * 4)) for i in range(3)):
                good.append(off)
        print('#%d len=%d  id=0x%08X  u32@4=%d  good3f_offsets=%s' % (
            p[3], len(b), struct.unpack_from('<I', b, 0)[0],
            struct.unpack_from('<I', b, 4)[0], good[:8]))
        # 打印候选窗口的值
        for off in good[:3]:
            extra = ''
            if off + 20 <= len(b):
                extra = ' yaw?=%.4f pitch?=%.4f' % (f32(b, off + 12), f32(b, off + 16))
            elif off + 16 <= len(b):
                extra = ' yaw?=%.4f' % (f32(b, off + 12), )
            print('     off=%d: (%.2f, %.2f, %.2f)%s' % (
                off, f32(b, off), f32(b, off + 4), f32(b, off + 8), extra))
        cnt += 1
        if cnt >= n:
            break
    print()


probe('createEntity', 0x5)
probe('volatile/avatarUpdate', 0xA)
probe('local detailed update', 0x1A)
probe('local vehicle snapshot', 0x26)

# 0x1A 和 0x1F 配对检查
print('==== 0x1A/0x1F 配对检查 ====')
idx_1a = [p[3] for p in pkts if p[0] == 0x1A][:5]
idx_1f = [p[3] for p in pkts if p[0] == 0x1F][:5]
print('0x1A 前5索引:', idx_1a)
print('0x1F 前5索引:', idx_1f)
for i in idx_1a[:3]:
    p = pkts[i]
    print('#%d 0x1A clk=%d 下一包 #%d t=0x%X clk=%d' % (i, p[1], i + 1, pkts[i + 1][0], pkts[i + 1][1]))
