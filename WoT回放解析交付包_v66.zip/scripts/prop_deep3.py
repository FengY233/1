# -*- coding: utf-8 -*-
"""prop_deep3.py — prop19(Avatar 8B)原始hex + prop23时刻表 + prop10归属 + jsonl siege/onPositionsUpdated结构"""
import sys, struct, collections, json, bisect
sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

r = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
PLAYER = 0x2094A145
AVATAR = 0x2094A160
OFF = 34.240 - 139.769

series = collections.defaultdict(list)
for (t, clk, pl, i) in r.pkts:
    if t == 0x07 and len(pl) >= 12:
        eid, prop, vlen = struct.unpack_from('<III', pl, 0)
        if 12 + vlen <= len(pl):
            fclk = struct.unpack('<f', struct.pack('<I', clk))[0]
            series[(eid, prop)].append((fclk, pl[12:12 + vlen]))

# ── 1. prop19 (Avatar, 8B) 原始hex + 多种解码 ──
print('=== prop19 (Avatar 0x2094A160) 前16个原始样本 ===')
for fclk, v in series[(AVATAR, 19)][:16]:
    a, b = struct.unpack('<2f', v)
    ia, ib = struct.unpack('<2i', v)
    ua, ub = struct.unpack('<2I', v)
    d = struct.unpack('<d', v)[0]
    print('clk=%8.2f %s | 2f=(%12.3f,%12.3f) 2i=(%-12d,%-12d) f64=%g' %
          (fclk, v.hex(), a, b, ia, ib, d))

# 与玩家炮击事件的关联(玩家开炮15发)
shots_bt = []
for line in open('/home/z/my-project/upload/session_20260911_175934.jsonl', encoding='utf-8'):
    try: e = json.loads(line)
    except: continue
    if e.get('ev') == 'arena.onVehicleShot':
        shots_bt.append(e['data'])
print()
print('玩家射击事件数:', len(shots_bt), '样例:', json.dumps(shots_bt[0], ensure_ascii=False)[:200] if shots_bt else '')

# prop19 时刻 vs 射击时刻
print()
print('=== prop19 时刻 vs onVehicleShot 时刻 ===')
if shots_bt:
    sbts = sorted(d.get('bt', 0) for d in shots_bt if isinstance(d, dict))
    near = 0
    for fclk, v in series[(AVATAR, 19)]:
        bt = fclk - OFF
        if any(abs(bt - s) < 0.5 for s in sbts):
            near += 1
    print('prop19 中与射击±0.5s 对齐的: %d/%d' % (near, len(series[(AVATAR, 19)])))

# ── 2. prop23 时刻与数值 ──
print()
print('=== prop23 全部事件(时间升序, 前20) ===')
ev23 = sorted([(fclk, eid, v) for (eid, p), seq in series.items() if p == 23 for fclk, v in seq])
for fclk, eid, v in ev23[:20]:
    a, b = struct.unpack('<2f', v)
    ia, ib = struct.unpack('<2i', v)
    print('clk=%8.2f eid=0x%X  %s | i=(%d,%d) f=(%.3f,%.3f)' % (fclk, eid, v.hex(), ia, ib, a, b))

# ── 3. prop10 属于哪辆车? ──
print()
print('=== prop10 归属 ===')
for (eid, p), seq in series.items():
    if p == 10:
        hdr = json.loads(r.blocks[0].decode('utf-8', 'replace'))
        info = hdr['vehicles'].get(str(eid), {})
        print('eid=0x%X name=%s team=%s class=%s' % (eid, info.get('name'), info.get('team'),
              info.get('vehicleType', '?')))
        for fclk, v in seq[:12]:
            print('   clk=%8.2f val=%s' % (fclk, v.hex()))

# ── 4. jsonl siege 事件结构 ──
print()
print('=== veh.onSiegeStateUpdated 样例 ===')
n = 0
for line in open('/home/z/my-project/upload/session_20260911_175934.jsonl', encoding='utf-8'):
    if 'onSiegeStateUpdated' in line:
        e = json.loads(line)
        print(json.dumps(e['data'], ensure_ascii=False)[:200])
        n += 1
        if n >= 4: break

# ── 5. onPositionsUpdated 结构 ──
print()
print('=== arena.onPositionsUpdated 样例 ===')
for line in open('/home/z/my-project/upload/session_20260911_175934.jsonl', encoding='utf-8'):
    if 'onPositionsUpdated' in line:
        e = json.loads(line)
        print(json.dumps(e['data'], ensure_ascii=False)[:400])
        break

# ── 6. prop4 的7辆车是谁 ──
print()
print('=== prop4 的车辆 ===')
hdr = json.loads(r.blocks[0].decode('utf-8', 'replace'))
for (eid, p), seq in series.items():
    if p == 4:
        info = hdr['vehicles'].get(str(eid), {})
        print('eid=0x%X %-20s team=%s' % (eid, info.get('name', '?')[:18], info.get('team')))

# ── 7. prop33/34/16 的车辆 ──
print()
print('=== prop33 的19辆车(名/队) ===')
for (eid, p), seq in sorted(series.items()):
    if p == 33:
        info = hdr['vehicles'].get(str(eid), {})
        print('  0x%X %-20s team=%s' % (eid, info.get('name', '?')[:16], info.get('team')))
print('=== prop34 的车辆 ===')
for (eid, p), seq in sorted(series.items()):
    if p == 34:
        info = hdr['vehicles'].get(str(eid), {})
        vals = [v.hex() for _, v in seq]
        print('  0x%X %-20s team=%s 值:%s' % (eid, info.get('name', '?')[:16], info.get('team'), vals))
