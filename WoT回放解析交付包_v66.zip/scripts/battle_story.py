# -*- coding: utf-8 -*-
"""battle_story.py — 击杀链 + 死亡时间线 + 战斗叙事"""
import io
import json
import struct
import sys
from collections import defaultdict

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

REPLAY = '/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay'
data = open(REPLAY, 'rb').read()
magic, bc = struct.unpack_from('<II', data, 0)
pos = 8
blocks = []
for _ in range(bc):
    (blen,) = struct.unpack_from('<I', data, pos)
    blocks.append(data[pos + 4:pos + 4 + blen])
    pos += 4 + blen
j0 = json.loads(blocks[0].decode('utf-8'))
j1 = json.loads(blocks[1].decode('utf-8'))
r0 = j1[0]

veh_info = {int(k): v for k, v in j0['vehicles'].items()}
name = {vid: v['name'] for vid, v in veh_info.items()}
vtype = {vid: v['vehicleType'].split(':')[1] for vid, v in veh_info.items()}
team = {vid: v['team'] for vid, v in veh_info.items()}

d = json.load(open('/home/z/my-project/work/decoded_full.json', encoding='utf-8'))
tracks = {int(k): v for k, v in d['vehicle_tracks'].items()}
leaves = d['leave_aoi']

# 每车最后轨迹时间 (游戏秒)
last_seen = {}
for vid, tr in tracks.items():
    if tr:
        last_seen[vid] = tr[-1][0]

# 死亡信息
print('=' * 100)
print('战果与击杀链 (vehicles 记录)')
print('=' * 100)
deaths = []
for vid_str, recs in r0['vehicles'].items():
    vid = int(vid_str)
    rec = recs[-1]
    dr = rec.get('deathReason', -1)
    kid = rec.get('killerID', 0)
    alive = rec.get('health', 0) > 0
    deaths.append({
        'vid': vid, 'name': name.get(vid, '?'), 'team': team.get(vid),
        'vtype': vtype.get(vid, '?'), 'kills': rec.get('kills', 0),
        'dmg': rec.get('damageDealt', 0), 'xp': rec.get('xp', 0),
        'deathReason': dr, 'killer': kid,
        'last_track_t': last_seen.get(vid),
        'alive': rec.get('isAlive', 1) if 'isAlive' in rec else (dr == -1),
    })

t1 = [x for x in deaths if x['team'] == 1]
t2 = [x for x in deaths if x['team'] == 2]
print('\n-- 队伍1 (败) --')
for x in sorted(t1, key=lambda z: -(z['dmg'] or 0)):
    kn = name.get(x['killer'], '') if x['killer'] else ''
    print('  %-18s %-22s kills=%-2d dmg=%-6d dr=%-3d killer=%-18s 最后轨迹t=%s' % (
        x['name'][:18], x['vtype'][:22], x['kills'], x['dmg'], x['deathReason'], kn[:18],
        ('%.1fs' % x['last_track_t']) if x['last_track_t'] is not None else '-'))
print('\n-- 队伍2 (胜) --')
for x in sorted(t2, key=lambda z: -(z['dmg'] or 0)):
    kn = name.get(x['killer'], '') if x['killer'] else ''
    print('  %-18s %-22s kills=%-2d dmg=%-6d dr=%-3d killer=%-18s 最后轨迹t=%s' % (
        x['name'][:18], x['vtype'][:22], x['kills'], x['dmg'], x['deathReason'], kn[:18],
        ('%.1fs' % x['last_track_t']) if x['last_track_t'] is not None else '-'))

# 死亡时间排序 (活着的 last_track 会到战斗结束)
print('\n-- 按最后轨迹时间排序 (阵亡估计) --')
for x in sorted(deaths, key=lambda z: z['last_track_t'] if z['last_track_t'] is not None else 9e9):
    if x['deathReason'] >= 0:
        print('  t≈%7.1fs  %-18s (队伍%s) 被 %-18s 击杀 [deathReason=%d]' % (
            x['last_track_t'], x['name'][:18], x['team'], name.get(x['killer'], '?')[:18], x['deathReason']))

# 汇总
k1 = sum(x['kills'] for x in t1)
k2 = sum(x['kills'] for x in t2)
d1 = sum(1 for x in t1 if x['deathReason'] >= 0)
d2 = sum(1 for x in t2 if x['deathReason'] >= 0)
print('\n汇总: 队伍1 击杀%d/阵亡%d, 队伍2 击杀%d/阵亡%d' % (k1, d1, k2, d2))
print('总伤害: 队伍1 %d, 队伍2 %d' % (sum(x['dmg'] for x in t1), sum(x['dmg'] for x in t2)))
