# -*- coding: utf-8 -*-
"""replay_reclock.py — 回放时钟重测定: 用新jsonl(1x播放)作为游戏时间权威,
彻底重测回放内部时钟结构, 裁决"压缩/倍速"问题
"""
import io
import json
import struct
import sys
from collections import Counter

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

R = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
pkts = R.pkts
print('总包数: %d' % len(pkts))

# ============ 1. 阶段包 0x16 / 0x17 ============
print('\n==== 1. 0x16 阶段包 (值, clock, pkt#) ====')
p16 = [(p[1], struct.unpack('<I', p[2])[0] if len(p[2]) >= 4 else None, p[3]) for p in pkts if p[0] == 0x16]
for clk, v, idx in p16:
    print('  period=%s clock=%d pkt#%d' % (v, clk, idx))
print('==== 0x17 倒计时包 ====')
for p in pkts:
    if p[0] == 0x17 and len(p[2]) >= 4:
        f = struct.unpack('<f', p[2])[0]
        print('  f32=%-10.3f clock=%d pkt#%d' % (f, p[1], p[3]))

# ============ 2. clock=0 区与非零区结构 ============
print('\n==== 2. clock=0 区 vs 非零区 ====')
z = [p for p in pkts if p[1] == 0]
nz = [p for p in pkts if p[1] != 0]
print('clock=0 包数: %d (pkt#%d..%d), 类型: %s' % (
    len(z), z[0][3], z[-1][3], dict(Counter(p[0] for p in z))))
print('非零包数: %d, 首(pkt#%d type=0x%X clock=%d) 末(pkt#%d type=0x%X clock=%d)' % (
    len(nz), nz[0][3], nz[0][0], nz[0][1], nz[-1][3], nz[-1][0], nz[-1][1]))
print('非零 clock 跨度: %d' % (nz[-1][1] - nz[0][1]))

# ============ 3. 0x36 tick 包: 载荷结构与计数 ============
print('\n==== 3. 0x36 tick 包 ====')
t36 = [p for p in pkts if p[0] == 0x36]
print('总数: %d, 载荷长度分布: %s' % (len(t36), dict(Counter(len(p[2]) for p in t36))))
print('前3个载荷: %s' % [p[2].hex() for p in t36[:3]])
# 检查载荷中的 u32 是否为递增计数器
if all(len(p[2]) >= 4 for p in t36):
    for off in range(0, min(12, len(t36[0][2]) - 3), 4):
        vals = [struct.unpack_from('<I', p[2], off)[0] for p in t36]
        diffs = Counter(b - a for a, b in zip(vals, vals[1:]))
        if len(diffs) <= 8:
            print('  u32@%d: 首=%d 末=%d 差分分布=%s' % (off, vals[0], vals[-1], diffs.most_common(8)))
# p3/p4 边界之间的 0x36 数量
p3_clk = [v for v in p16 if v[1] == 3][0][0]
p4_clk = [v for v in p16 if v[1] == 4][0][0]
p3_idx = [v[2] for v in p16 if v[1] == 3][0]
p4_idx = [v[2] for v in p16 if v[1] == 4][0]
btw = [p for p in t36 if p[3] > p3_idx and p[3] < p4_idx]
print('p3(pkt#%d,clock=%d)→p4(pkt#%d,clock=%d) 之间 0x36: %d 个' % (p3_idx, p3_clk, p4_idx, p4_clk, len(btw)))
print('  若10Hz → 游戏秒 = %.1f; clock跨度 = %d' % (len(btw) / 10.0, p4_clk - p3_clk))
print('  新jsonl实测战斗时长 612.275s → 期望tick数 ~6123')

# ============ 4. 0x1A 差分直方图(带计数) ============
print('\n==== 4. 0x1A 相邻差分直方图 ====')
a = [p for p in pkts if p[0] == 0x1A]
print('0x1A 总数: %d' % len(a))
ds_all = Counter()
for i in range(1, len(a)):
    d = a[i][1] - a[i - 1][1]
    if d > 0:
        ds_all[round(d, 1)] += 1
print('-- 全程 (前20) --')
for v, c in ds_all.most_common(20):
    print('   Δ=%-10.1f %6d 次   [若µs=%.4fms | 若2^20Hz=%.4fms → 0.1s/Δ的倍速: µs=%.2fx, 2^20=%.2fx]' % (
        v, c, v / 1000.0, v / 1048576.0 * 1000.0, 100000.0 / v, 104857.6 / v))
# 战斗窗内
ab = [p for p in a if p3_clk <= p[1] <= p4_clk]
ds_b = Counter()
for i in range(1, len(ab)):
    d = ab[i][1] - ab[i - 1][1]
    if d > 0:
        ds_b[round(d, 1)] += 1
print('-- 战斗窗 p3→p4 (%d 个) 前16 --' % len(ab))
for v, c in ds_b.most_common(16):
    print('   Δ=%-10.1f %6d 次' % (v, c))

# ============ 5. 0x1B / 0x1A 相机模式串 ============
print('\n==== 5. 相机模式字符串 census ====')
import re
modes = Counter()
for p in pkts:
    if p[0] in (0x1A, 0x1B, 0x20, 0x24):
        s = p[2]
        for m in re.findall(rb'[a-zA-Z_]{6,28}', s):
            modes[(hex(p[0]), m.decode('ascii', 'replace'))] += 1
for (ty, m), c in modes.most_common(20):
    print('   type=%s %-28s %d' % (ty, m, c))

# ============ 6. 0x15 双u32 ============
print('\n==== 6. 0x15 (u32,u32) ====')
for p in pkts:
    if p[0] == 0x15:
        x, y = struct.unpack('<II', p[2])
        print('  pkt#%d clock=%d  (u32a=%d, u32b=%d)  a/2^20=%.3fs b/2^20=%.3fs a/1e6=%.3fs' % (
            p[3], p[1], x, y, x / 1048576.0, y / 1048576.0, x / 1e6))

# ============ 7. 末包 ============
print('\n==== 7. 最后5个包 ====')
for p in pkts[-5:]:
    print('  type=0x%X clock=%d len=%d pkt#%d payload[:24]=%s' % (p[0], p[1], len(p[2]), p[3], p[2][:24].hex()))
