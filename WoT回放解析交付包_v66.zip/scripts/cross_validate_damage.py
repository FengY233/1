# -*- coding: utf-8 -*-
"""全量伤害交叉验证: 会话事件汇总 vs 结果块每人 damageDealt"""
import json, struct, re
from collections import defaultdict

BATTLE_START_BT = 139.769
events = [json.loads(l) for l in open('/home/z/my-project/upload/session_20260911_175934.jsonl', encoding='utf-8')]

# 名单
raw = open('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay', 'rb').read()
magic, bc = struct.unpack_from('<II', raw, 0)
pos = 8; blocks = []
for _ in range(bc):
    (blen,) = struct.unpack_from('<I', raw, pos)
    blocks.append(raw[pos+4:pos+4+blen]); pos += 4+blen
j0 = json.loads(blocks[0]); j1 = json.loads(blocks[1])
veh = {int(k): v for k, v in j0['vehicles'].items()}

# 会话伤害汇总
dmg_by_attacker = defaultdict(int)
dmg_events = 0
for o in events:
    if o['ev'] == 'arena.onVehicleHealthChanged':
        vic, att, dmg = o['data']['args']
        dmg_by_attacker[att] += dmg
        dmg_events += 1
print(f'会话 onVehicleHealthChanged 事件: {dmg_events}, 总伤害: {sum(dmg_by_attacker.values())}')

# 结果块的每人数据
res = j1.get('players', j1.get('vehicles', {}))
print(f'结果块键: {list(j1.keys())[:12]}')
# 找到个人结果
personal = None
for k in ('personal', 'common'):
    if k in j1:
        print(f'j1[{k}] 键: {list(j1[k].keys())[:15]}')

# 尝试多种路径
def find_player_stats(j1):
    cands = []
    p = j1.get('personal', {})
    if p:
        cands.append(('personal', p))
    return cands

# 直接在 j1 顶层找 players
if 'players' in j1:
    pl = j1['players']
    print(f"players 数: {len(pl)}")
    # 输出对照表
    print(f'{"车名":<14} {"队伍":>2} {"结果dmg":>7} {"会话dmg":>7} {"结果kills":>6} {"会话kills":>6}')
    sess_kills = defaultdict(int)
    for o in events:
        if o['ev'] == 'arena.onVehicleKilled':
            sess_kills[o['data']['args'][1]] += 1
    rows = []
    for vid_s, info in pl.items():
        vid = int(vid_s)
        name = veh[vid_s]['fakeName'] if vid_s in veh else vid_s
        team = veh[vid_s]['team'] if vid_s in veh else '?'
        rdmg = info.get('damageDealt', info.get('dmg', 0))
        rkil = info.get('kills', 0)
        sdmg = dmg_by_attacker.get(vid, 0)
        skil = sess_kills.get(vid, 0)
        rows.append((team, name, rdmg, sdmg, rkil, skil))
    for r in sorted(rows, key=lambda x: -x[2]):
        flag = '' if r[2] == r[3] else '  <<< 不一致'
        kflag = '' if r[4] == r[5] else '  <<< 杀数不一致'
        print(f'{r[1]:<14} T{r[0]}  {r[2]:>7} {r[3]:>7}  {r[4]:>6} {r[5]:>6}{flag}{kflag}')
else:
    print('j1 顶层无 players, 顶层键:', list(j1.keys()))
