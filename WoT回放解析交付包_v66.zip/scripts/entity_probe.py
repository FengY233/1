# -*- coding: utf-8 -*-
"""entity_probe.py — 实体类型深挖: 每类型取样 0x05/0x06/0x00 原始载荷, 确认类型表"""
import sys, struct, collections
sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

r = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')

# 1) 0x00 (创建玩家Avatar聚合包) 与 0x05/0x06 逐包扫描, 记录每实体的创建证据
creates = collections.defaultdict(list)   # eid -> [(pktType, idx, payload)]
for (t, clk, pl, i) in r.pkts:
    if t == 0x05 and len(pl) >= 8:
        eid, etype = struct.unpack_from('<II', pl, 0)
        creates[eid].append((t, i, pl, etype))
    elif t == 0x06 and len(pl) >= 8:
        eid, etype = struct.unpack_from('<II', pl, 0)
        creates[eid].append((t, i, pl, etype))
    elif t == 0x00 and len(pl) >= 16:
        # [u32 长度?][u32 eid][u32 type]... 先hexdump看
        creates[struct.unpack_from('<I', pl, 4)[0]].append((t, i, pl, None))

print('实体数:', len(creates))
# 2) 类型统计(以最后一次出现为准) + ID段分析
ent = {}
for eid, evs in creates.items():
    for (t, i, pl, et) in evs:
        if et is not None:
            ent[eid] = (et, t, i)

tc = collections.Counter(v[0] for v in ent.values())
print('类型分布(0x05/0x06确认):', dict(sorted(tc.items())))

# 3) 0x00 的载荷结构样本
print()
print('=== 0x00 创建包样本(前3个, hex 前64B) ===')
n = 0
for (t, i, pl, clk) in [(t, i, pl, c) for (t, c, pl, i) in
                         [(t, c, pl, i) for (t, i, pl, c) in r.pkts]][:0]:  # placeholder
    pass
for (t, clk, pl, i) in r.pkts:
    if t == 0x00 and n < 3:
        print(f'-- pkt#{i} len={len(pl)} clock={clk}')
        print('   ', pl[:64].hex())
        n += 1

# 4) 每类型 0x05 载荷样本 hex(前96B)
print()
print('=== 0x05/0x06 每类型样本 ===')
seen = set()
for (t, clk, pl, i) in r.pkts:
    if t in (0x05, 0x06) and len(pl) >= 8:
        eid, etype = struct.unpack_from('<II', pl, 0)
        if etype not in seen:
            seen.add(etype)
            print(f'-- type {etype} (eid=0x{eid:X}) pkt#{i} len={len(pl)}')
            print('   ', pl[:96].hex())
        if len(seen) >= 10:
            break

# 5) type 361 的完整事件流
print()
print('=== type361 实体相关全部包 ===')
tgt = [eid for eid, v in ent.items() if v[0] == 361]
print('eid:', [hex(x) for x in tgt])
if tgt:
    e = tgt[0]
    cnt = collections.Counter()
    for (t, clk, pl, i) in r.pkts:
        if len(pl) >= 4 and struct.unpack_from('<I', pl, 0)[0] == e:
            cnt[t] += 1
    print('涉及包类型:', {hex(k): v for k, v in sorted(cnt.items())})
