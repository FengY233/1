# -*- coding: utf-8 -*-
"""analyze_replay_jsonl8.py — 0x26=瞄准点 决定性检验: 0x26.pos 是否落在 0x1A 相机视线射线上。
   + quat/rest 分布 + decomp FUN_14057f240 + 校验和补充候选。
"""
import json
import struct
import sys
import zlib
import collections
import statistics
import math

sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

REPLAY = '/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay'
JSONL = '/home/z/my-project/upload/replay.jsonl'

rf = ReplayFile(REPLAY)
lines = []
with open(JSONL) as f:
    for line in f:
        if line.strip():
            lines.append(json.loads(line))

def f32(u):
    return struct.unpack('<f', struct.pack('<I', u))[0]

# 收集三路数据
t26 = []   # (t, pos, quat, rest)
t1a = []   # (t, 15f)
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    t = f32(clock)
    if ty == 0x26 and 'pos' in d:
        t26.append((t, d['pos'], d.get('quat'), d.get('rest')))
    elif ty == 0x1A and 'f' in d and len(d['f']) == 15:
        t1a.append((t, d['f']))

# ---------- 1) 视线射线检验 ----------
print('== 0x26.pos 是否在 0x1A 视线射线上 ==')
import bisect
t1as = [x[0] for x in t1a]
perp_d = []
along_d = []
for t, pos, quat, rest in t26:
    if t < 40:
        continue
    j = bisect.bisect_left(t1as, t)
    if j >= len(t1a):
        continue
    ct, f = t1a[j]
    if abs(ct - t) > 0.16:
        continue
    cam = f[0:3]
    dirv = f[8:11]
    w = (pos[0]-cam[0], pos[1]-cam[1], pos[2]-cam[2])
    dn = math.sqrt(dirv[0]**2 + dirv[1]**2 + dirv[2]**2)
    if dn < 1e-9:
        continue
    along = (w[0]*dirv[0] + w[1]*dirv[1] + w[2]*dirv[2]) / dn
    cx = (dirv[1]*w[2] - dirv[2]*w[1], dirv[2]*w[0] - dirv[0]*w[2], dirv[0]*w[1] - dirv[1]*w[0])
    cn = math.sqrt(cx[0]**2 + cx[1]**2 + cx[2]**2) / dn
    if along > 5:
        perp_d.append(cn)
        along_d.append(along)
if perp_d:
    perp_d.sort(); along_d.sort()
    n = len(perp_d)
    print(f'样本 {n}')
    print(f'垂直距离: 中位 {perp_d[n//2]:.1f}m  P25 {perp_d[n//4]:.1f}  P75 {perp_d[3*n//4]:.1f}  P90 {perp_d[9*n//10]:.1f}')
    print(f'沿射线距离: 中位 {along_d[n//2]:.1f}m  P25 {along_d[n//4]:.1f}  P75 {along_d[3*n//4]:.1f}')
    close = sum(1 for x in perp_d if x < 15)
    print(f'垂直距离<15m 的样本: {close}/{n} = {100.0*close/n:.1f}%')

# ---------- 2) 0x26 quat / rest 分布 ----------
print()
print('== 0x26 quat / rest 分布 ==')
quats = collections.Counter()
rests = collections.Counter()
for t, pos, quat, rest in t26:
    if quat:
        quats[tuple(round(x, 3) for x in quat)] += 1
    if rest:
        rests[rest] += 1
print(f'独立 quat 值: {len(quats)} 个, top5: {quats.most_common(5)}')
print(f'独立 rest 值: {len(rests)} 个, top5: {rests.most_common(5)}')

# quat 与炮向? 检查 quat forward 在水平面的方位角分布
def quat_fwd(q):
    x, y, z, w = q
    # rotate (0,0,1)
    qx, qy, qz = x, y, z
    cx = qy*1 - qz*0
    cy = qz*0 - qx*1
    cz = 0
    # cross(qv, v) with v=(0,0,1): (qy*1 - qz*0, qz*0 - qx*1, qx*0 - qy*0) = (qy, -qx, 0)
    cr1 = (qy, -qx, 0)
    t2 = (cr1[0] + w*0, cr1[1] + w*0, cr1[2] + w*1)
    cr2x = qy*t2[2] - qz*t2[1]
    cr2y = qz*t2[0] - qx*t2[2]
    cr2z = qx*t2[1] - qy*t2[0]
    return (2*cr2x, 2*cr2y, 1 + 2*cr2z)
angs = []
for t, pos, quat, rest in t26:
    if quat and t > 40:
        f = quat_fwd(quat)
        angs.append(math.degrees(math.atan2(f[1], f[0])))
if angs:
    print(f'quat forward 方位角: 中位 {statistics.median(angs):.1f}° 范围 [{min(angs):.1f},{max(angs):.1f}]')

# ---------- 3) 玩家炮向对照 (0x07 key13 gunAngles yaw) ----------
print()
print('== 玩家 gunAngles (0x07 key13, eid=546611525) 对照 ==')
yaw = []
for (ty, clock, payload, idx), d in zip(rf.pkts, lines):
    if ty == 0x07 and d.get('eid') == 546611525 and d.get('key') == 13:
        body = bytes.fromhex(d['body'])
        if len(body) == 2:
            v = struct.unpack('<H', body)[0]
            y10 = v >> 6
            yaw.append((f32(clock), y10 * 360.0 / 1024.0 if y10 < 512 else (y10 - 1024) * 360.0 / 1024.0))
print(f'玩家炮塔yaw样本 {len(yaw)} 个, 后5个: {[(round(t,1), round(a,1)) for t, a in yaw[-5:]]}')

# 0x26 quat 方位角 vs 玩家炮 yaw 同时刻
if yaw:
    ty_ = [x[0] for x in yaw]
    agree = 0
    tot = 0
    for t, pos, quat, rest in t26:
        if quat and t > 40:
            f = quat_fwd(quat)
            a26 = math.degrees(math.atan2(f[1], f[0]))
            i = bisect.bisect_left(ty_, t)
            if i < len(yaw) and abs(yaw[i][0] - t) < 0.3:
                diff = (a26 - yaw[i][1] + 180) % 360 - 180
                tot += 1
                if abs(diff) < 25:
                    agree += 1
    print(f'0x26方位角 vs 炮yaw: {agree}/{tot} <25° 吻合')

# ---------- 4) 校验和补充 ----------
print()
print('== 200528740 校验和补充候选 ==')
p11 = None
for ty, clock, payload, idx in rf.pkts:
    if ty == 0x11:
        p11 = payload
        break
outer = zlib.decompress(p11[22:])
inner1 = zlib.decompress(outer[29:29+754])
# inner2 @790, inner3 @2025
d = zlib.decompressobj()
inner2 = d.decompress(outer[790:])
d2 = zlib.decompressobj()
inner3 = d2.decompress(outer[2025:])
inner_all = inner1 + inner2 + inner3
target = 200528740
cands = {
    'adler32(outer)': zlib.adler32(outer),
    'crc32(outer)': zlib.crc32(outer),
    'adler32(inner_all)': zlib.adler32(inner_all),
    'crc32(inner_all)': zlib.crc32(inner_all),
    'adler32(inner1)': zlib.adler32(inner1),
    'crc32(inner1)': zlib.crc32(inner1),
    'adler32(inner2)': zlib.adler32(inner2),
    'crc32(inner2)': zlib.crc32(inner2),
    'adler32(inner3)': zlib.adler32(inner3),
    'crc32(inner3)': zlib.crc32(inner3),
    'adler32(p11[22:])': zlib.adler32(p11[22:]),
    'crc32(p11[22:])': zlib.crc32(p11[22:]),
    'adler32(p11)': zlib.adler32(p11),
    'crc32(p11)': zlib.crc32(p11),
}
for k, v in cands.items():
    v &= 0xFFFFFFFF
    if v == target:
        print(f'  {k}: {v}  <== MATCH!')
    else:
        print(f'  {k}: {v}')
# 0x3D 再试: md5(inner_all), md5(outer)
import hashlib
t3d = '5df886f75e73b33cff9d87fb9c69389c'
for name, data in (('outer', outer), ('inner_all', inner_all), ('inner3', inner3)):
    h = hashlib.md5(data).hexdigest()
    print(f'  md5({name}) = {h} {"<== 0x3D MATCH!" if h == t3d else ""}')
