# -*- coding: utf-8 -*-
"""汇总: 生成会话日志+权威结果的完整交叉验证数据 session_summary.json"""
import json, struct, math, re
from collections import defaultdict, Counter

BATTLE_START_BT = 139.769
ME = 546611525

raw = open('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay', 'rb').read()
magic, bc = struct.unpack_from('<II', raw, 0)
pos = 8; blocks = []
for _ in range(bc):
    (blen,) = struct.unpack_from('<I', raw, pos)
    blocks.append(raw[pos+4:pos+4+blen]); pos += 4+blen
j0 = json.loads(blocks[0]); j1 = json.loads(blocks[1])
veh = j0['vehicles']
auth = {int(k): v[-1] for k, v in j1[0]['vehicles'].items()}   # 权威战绩

events = [json.loads(l) for l in open('/home/z/my-project/upload/session_20260911_175934.jsonl', encoding='utf-8')]

# ---- 会话侧统计 ----
dmg_by = defaultdict(int); kills_by = defaultdict(int)
kills = []
for o in events:
    if o['ev'] == 'arena.onVehicleHealthChanged':
        dmg_by[o['data']['args'][1]] += o['data']['args'][2]
    elif o['ev'] == 'arena.onVehicleKilled':
        a = o['data']['args']
        kills_by[a[1]] += 1
        kills.append({'battle_t': round(o['data']['bt'] - BATTLE_START_BT, 2),
                      'victim': a[0], 'victim_name': veh[str(a[0])]['fakeName'],
                      'victim_team': veh[str(a[0])]['team'],
                      'killer': a[1], 'killer_name': veh[str(a[1])]['fakeName'],
                      'killer_team': veh[str(a[1])]['team'],
                      'equipmentID': a[2], 'reason': a[3], 'numVehiclesAffected': a[4]})

shots_me = [round(o['data']['bt'] - BATTLE_START_BT, 2) for o in events
            if o['ev'] == 'arena.onVehicleShot' and o['data']['args'][0] == ME]
all_shots = Counter(o['data']['args'][0] for o in events if o['ev'] == 'arena.onVehicleShot')

own_traj = [(round(o['data']['bt'] - BATTLE_START_BT, 2), *o['data']['own']['position'])
            for o in events if o['ev'] == 'battle_tick' and o['data'].get('own')]
dist = sum(math.dist(a[1:4], b[1:4]) for a, b in zip(own_traj, own_traj[1:]) if math.dist(a[1:4], b[1:4]) < 15)

# siege 状态切换
siege_seq = []
prev = None
for o in events:
    if o['ev'] == 'battle_tick' and o['data'].get('own'):
        s = o['data']['own'].get('siegeState')
        if s != prev:
            siege_seq.append((round(o['data']['bt'] - BATTLE_START_BT, 2), s))
            prev = s

# 玩家可见伤害事件
me_dmg = [{'battle_t': round(o['data']['bt'] - BATTLE_START_BT, 2),
           'victim': o['data']['args'][0], 'victim_name': veh[str(o['data']['args'][0])]['fakeName'],
           'damage': o['data']['args'][2]}
          for o in events if o['ev'] == 'arena.onVehicleHealthChanged' and o['data']['args'][1] == ME]

# 权威玩家个人
p = j1[0]['personal']['8705']
details = {}
for tgt, st in p.get('details', {}).items():
    vid = int(tgt.strip('()').split(',')[0])
    details[veh[str(vid)]['fakeName']] = st.get('damageDealt', 0)

# 权威伤害表
auth_table = sorted(
    [{'name': veh[str(vid)]['fakeName'], 'team': veh[str(vid)]['team'],
      'vtype': veh[str(vid)]['vehicleType'].split(':')[1],
      'damageDealt': rec.get('damageDealt', 0), 'kills': rec.get('kills', 0),
      'xp': rec.get('xp', 0), 'isAlive': bool(rec.get('isAlive', 0)),
      'deathReason': rec.get('deathReason', -1),
      'session_visible_damage': dmg_by.get(vid, 0)}
     for vid, rec in auth.items()], key=lambda x: -x['damageDealt'])

summary = {
    'meta': {
        'file': 'session_20260911_175934.jsonl', 'events': len(events),
        'boot': '2026-09-11 17:59:34.861', 'disconnect': '2026-09-11 18:12:53.358',
        'client': '坦克世界 v.2.4.0.0 #942', 'realm': 'CN', 'databaseID': 7049414679,
        'avatar_session_id': 546611552, 'player_vehicle_id': ME,
    },
    'lifecycle': [
        {'wall': '17:59:34.861', 'bt': 0, 'event': 'session boot (客户端启动)'},
        {'wall': '17:59:42.708', 'bt': 21.595, 'event': 'garage.account_become_player (登录完成)'},
        {'wall': '18:00:12.485', 'bt': None, 'event': 'queue.enqueued (queue_type=1 随机战)'},
        {'wall': '18:00:12.731', 'bt': None, 'event': 'queue.info (队列332人, 分布 LT62/MT76/HT85/TD45/SPG64)'},
        {'wall': '18:00:55.927', 'bt': 95.949, 'event': 'queue.arena_created (匹配成功, 排队43.4s)'},
        {'wall': '18:01:00.560', 'bt': 99.671, 'event': 'battle.avatar_become_player (进入战斗)'},
        {'wall': '18:01:05.722', 'bt': 105.511, 'event': 'battle.avatar_ready (战斗加载完成, 用时5.2s)'},
        {'wall': '18:01:09.752', 'bt': 109.768, 'event': 'period 1→2 等待结束(10.1s), 倒计时30s开始'},
        {'wall': '18:01:39.755', 'bt': 139.769, 'event': 'period 2→3 倒计时结束, 战斗开始'},
        {'wall': '18:11:52.250', 'bt': 752.259, 'event': 'period 3→4 战斗结束(612.49s), 胜方=队伍2, 原因=全歼'},
        {'wall': '18:11:58.357', 'bt': 758.364, 'event': 'battle.results_received (结算下发)'},
        {'wall': '18:11:59.948', 'bt': 758.53, 'event': '返回车库'},
        {'wall': '18:12:53.358', 'bt': None, 'event': 'exit.disconnected + monitor_stopped(dropped=0)'},
    ],
    'battle': {
        'duration_game_seconds': 612.49,
        'periods': {'1_waiting_max60s_actual': 10.097, '2_countdown': 30.001, '3_battle': 612.490, '4_afterbattle': 60.0},
        'score': '15:10', 'winner': 2, 'finish_reason': 'extermination(全歼)',
        'kills': kills,
        'all_shots_total': sum(all_shots.values()), 'all_shots_by_vehicle': {str(k): v for k, v in all_shots.items()},
    },
    'player': {
        'shots_battle_t': shots_me,
        'shot_intervals': [round(b - a, 1) for a, b in zip(shots_me, shots_me[1:])],
        'shell_compact_descr': 20234, 'shell_count_start': 15,
        'visible_damage_events': me_dmg, 'visible_damage_total': sum(d['damage'] for d in me_dmg),
        'server_damage_total': p['damageDealt'],
        'server_damage_by_target': details,
        'directHits': p['directHits'], 'explosionHits': p['explosionHits'], 'damaged': p['damaged'],
        'kills': p['kills'], 'xp': p['xp'], 'mileage': p.get('mileage'),
        'stun_duration': p.get('stunDuration'), 'stun_hits': p.get('stunNumHits'),
        'survived': True, 'trajectory_points': len(own_traj),
        'trajectory_distance_calc': round(dist), 'final_position': [round(x, 1) for x in own_traj[-1][1:4]],
        'siege_transitions': siege_seq,
    },
    'aoi': {
        'vehicle_enter_events': sum(1 for o in events if o['ev'] == 'avatar.onVehicleEnterWorld'),
        'unique_vehicles': 30, 'reentries': sum(1 for o in events if o['ev'] == 'avatar.onVehicleEnterWorld') - 30,
    },
    'damage_accounting': {
        'server_total_dead_maxhp': sum(veh[str(int(v))]['maxHealth'] for v, s in
                                       ((k, j1[1][k]) for k in j1[1]) if not s.get('isAlive')),
        'session_event_total': sum(dmg_by.values()),
        'note': 'onVehicleHealthChanged 仅对玩家AoI视野内车辆触发, 会话覆盖约83%; 权威值以结果块为准',
    },
    'auth_damage_table': auth_table,
    'base_capture': [
        {'window': 'battle_t 445.0-457.0', 'story': '队伍2坦克进入队伍1基地, 占领点数0→2后两次重置(离开/被击退)'},
        {'window': 'battle_t 600.0-611.5', 'story': '终局占领: 点数0→11持续爬升, 战斗在612.49s因全歼结束, 未完成占领'},
    ],
}
json.dump(summary, open('/home/z/my-project/scripts/session_summary.json', 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('已保存 session_summary.json')
print(f"玩家: 15发射击@{shots_me}")
print(f"可见伤害 {summary['player']['visible_damage_total']} vs 服务器 {p['damageDealt']}")
print(f"轨迹 {len(own_traj)} 点, 行程 {dist:.0f}m, 终点 {summary['player']['final_position']}")
print(f"mileage(结果): {p.get('mileage')}")
print(f"眩晕: {p.get('stunDuration'):.1f}s / {p.get('stunNumHits')}次")
print(f"权威伤害TOP5: {[(r['name'], r['damageDealt'], r['kills']) for r in auth_table[:5]]}")
print(f"玩家xp={p['xp']}, 击杀数核对: session={kills_by.get(ME)}, server={p['kills']}")
print(f"siege切换: {siege_seq[:12]}")
