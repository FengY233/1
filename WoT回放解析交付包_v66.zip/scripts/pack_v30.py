#!/usr/bin/env python3
"""pack_v30.py — Task 53-a 交付打包: V30 = V29 底座 + Task 52 增量
data_v33: t52 系列脚本 14 件 + 结果×3（含 1978 类 vtable 全表 JSON + 解码器 v8 100% 结果）
scripts 增量: t52_*.py
findings v35 (§31 0x32 通道 100% 终局 + 引擎文法三修正 + OwnVehicle/订阅族全破) + worklog(至 Task 52-b)
"""
import os, zipfile, hashlib, shutil, glob, json

DL = '/home/z/my-project/download'
V29 = f'{DL}/WoT回放解析交付包_v29.zip'
OUT = f'{DL}/WoT回放解析交付包_v30.zip'
DATA33 = f'{DL}/data_v33'

assert os.path.exists(DATA33) and len(os.listdir(DATA33)) == 17, 'data_v33 不完整(期望17件)'
assert len(glob.glob('/home/z/my-project/scripts/t52_*.py')) == 14, 't52 脚本不齐(期望14件)'

# 1) 以 V29 为底座
zin = zipfile.ZipFile(V29, 'r')
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as zout:
    for item in zin.infolist():
        if item.filename in ('findings.md', 'worklog.md', 'README.md', 'audit_v29.json'):
            continue  # 换新版本
        zout.writestr(item, zin.read(item.filename))
    # findings/worklog 主位新版
    zout.write('/home/z/my-project/findings.md', 'findings.md')
    zout.write('/home/z/my-project/worklog.md', 'worklog.md')
    # data_v33
    for f in sorted(os.listdir(DATA33)):
        zout.write(f'{DATA33}/{f}', f'data_v33/{f}')
    # scripts 增量(t52 系列)
    for f in sorted(glob.glob('/home/z/my-project/scripts/t52_*.py')):
        zout.write(f, f'scripts/{os.path.basename(f)}')

# 2) README 增补
z = zipfile.ZipFile(OUT, 'a')
readme_add = """

---

# V30 增补（Task 52 · v35 · ★★★★★ 0x32 通道 100% 终局）

在 V29 全量底座之上新增：

| 内容 | 说明 |
|---|---|
| `findings.md` | ★ 结论登记册 v35（新增 §31：★★★★★解码器 v8 = 100.00%——随机战 0x32 通道全量纯文法离线解码完成；★★MethodCallee 方法段 packed methodID 真模型；★clist signed c+126 终审；★★tid=51=OwnVehicle 全破；★★订阅族全破；RTTI vtable 提取管线） |
| `data_v33/` | t52 系列脚本 14 件（侦察/RTTI×2/槽位/fns/etreg×2/alias/ownveh×5/v8 终版解码器）+ 结果×3（含 1978 类 vtable 全表 JSON 与 100% 结果） |
| `scripts/t52_*.py` | 同步副本：失败侦察/RTTI vtable 链/ViewHub 槽位/ EntityType 注册侦察/OwnVehicle 拟合×5/解码器 v8 |

核心突破（Task 52）：
1. **★★★★★解码器 v8 = 100.00%（6822/6822）**：随机战 0x32 通道全量纯文法离线解码完成（Task 47 的 82.3% → 48 的 83.8% → 49 的 97.9% → 50 的 99.56% → 51 的 99.72% → 52 的 100%）；Pass1 99.33% + Pass2 补 46；方法段双模型（pk 引擎真 + ln 兼容）+ N_props 全范围 + per-tid 精确读取器（ov*/sub/attach）。
2. **★★MethodCallee 方法段真模型**：slot3=FUN_140e380e0 读 packed methodID（[u8 | FF→u24 LE]）后 slot13=FUN_140399890 零流读——修正 §28「方法段=[len][name]」；方法段每项 1-4B。
3. **★clist 游程终审**：signed c+126（0x83..0xFF → 1..125 个，FUN_140e6f0f0 else 分支 `(byte)(c+0x7d)<0x7d` 条件），0x00=终止符。
4. **★★tid=51=OwnVehicle 全破**：23 属性+11 方法+rk6=35 vals 闭环；属性序 [0]=syncVehicleAttrs（[u16][f32][f32] 定长 10B）、[1]=vehicleAmmoList（ARRAY&lt;VEHICLE_AMMO&gt;）、[18]=targetingInfo（[u8 has][10×f32]，endTime=-1.0 哨兵实证）；掩码位≥N_props 的位=方法 ID 段标记。
5. **★★订阅族全破**：tid=112 prop0=订阅 blob=[03][eid][02]+2×([len][属性路径][u32 当前值])+2×([eid][00])；tid=78=N_props0+1 方法；属性路径语义级解码（battlesCount/totalSpotted/veh.wins/totalDamageDealt）。
6. **★tid=127 附着记录链**：[tag][len][prefab path][01][u32][u32]+n×11B 记录（[flag 0/1][u24 BE nid][u32 0][u24 0]），四胞胎差异=5 个 flag 位。
7. **alias.xml BLOB 类型引用破译**（04e38b=BOOL、20d4fc=UINT8，roster 互证）。
8. **RTTI vtable 提取管线**：TD vftable=0x143964f10 → COL → vtable，1978 类全表——后续 NRL 组件读取器批量提取的基础设施。
"""
z.writestr('README.md', readme_add)
audit = {
 "version": "v30",
 "date": "2026-09-26",
 "task": "Task 52: 0x32 通道 100% 终局(解码器 v8 = 6822/6822) + 引擎文法三修正 + OwnVehicle/订阅族/附着链全破 + RTTI 管线",
 "headline": [
  "★★★★★ 解码器 v8 = 100.00% (6822/6822): 随机战 0x32 通道全量纯文法离线解码完成 (82.3%→83.8%→97.9%→99.56%→99.72%→100%); Pass1 99.33% + Pass2 补 46",
  "★★ MethodCallee 方法段真模型: slot3=FUN_140e380e0 读 packed methodID ([u8 | FF→u24 LE]) 后 slot13 零流读——修正 §28 [len][name] 模型",
  "★ clist 游程终审 = signed c+126 (0x83..0xFF→1..125), 0x00=终止符; class1 真模型 = clist+每 val [u8 rk]+工厂 switch 0-6+slot3 体",
  "★★ tid=51=OwnVehicle 全破: 23 属性+11 方法+rk6=35 vals; [0]=syncVehicleAttrs 定长 10B, [1]=vehicleAmmoList ARRAY<VEHICLE_AMMO>, [18]=targetingInfo [u8 has][10×f32], endTime=-1.0 哨兵",
  "★★ 订阅族全破: tid=112 订阅 blob ([03][eid][02]+2×([len][属性路径][u32 值])+2×([eid][00])); 属性路径语义级解码 (battlesCount/totalSpotted/veh.wins/totalDamageDealt)",
  "★ tid=127 附着记录链 ([tag][len][path][01][u32][u32]+n×11B 记录); alias.xml BLOB 类型引用破译 (04e38b=BOOL/20d4fc=UINT8)",
  "RTTI vtable 提取管线 (TD vftable=0x143964f10→COL→vtable, 1978 类全表)"
 ],
 "coverage": {
  "scope": "随机战(bt=1, 10场)",
  "0x32": "分帧层 100% + 创建体文法层 100.00% (6822/6822) 纯文法全解——0x32 通道全量离线解码闭环",
  "0x32_0x37_overall": "~99%"
 }
}
z.writestr('audit_v30.json', json.dumps(audit, ensure_ascii=False, indent=1))
z.close()

md5 = hashlib.md5(open(OUT, 'rb').read()).hexdigest()
sz = os.path.getsize(OUT)
n = len(zipfile.ZipFile(OUT).namelist())
print(f'V30 打包完成: {n} 文件, {sz:,}B, md5={md5}')

# 3) testzip 完整性
zf = zipfile.ZipFile(OUT)
assert zf.testzip() is None, 'testzip FAIL'
print('testzip PASS')

# 4) upload 备份
os.makedirs('/home/z/my-project/upload/backup_v30', exist_ok=True)
shutil.copy(OUT, '/home/z/my-project/upload/backup_v30/')
shutil.copy('/home/z/my-project/findings.md', '/home/z/my-project/upload/backup_v30/')
shutil.copy('/home/z/my-project/worklog.md', '/home/z/my-project/upload/backup_v30/')
open('/home/z/my-project/upload/backup_v30/audit_v30.json', 'w').write(json.dumps(audit, ensure_ascii=False, indent=1))
shutil.copy('/home/z/my-project/findings.md', '/home/z/my-project/upload/findings.md')
shutil.copy('/home/z/my-project/worklog.md', '/home/z/my-project/upload/worklog.md')
print('upload/backup_v30 备份完成')

# 5) 三处一致性自检
h = lambda p: hashlib.md5(open(p, 'rb').read()).hexdigest()
print('findings 三处一致:',
      h('/home/z/my-project/findings.md') == h('/home/z/my-project/upload/findings.md'),
      '| 包内:', hashlib.md5(zipfile.ZipFile(OUT).read('findings.md')).hexdigest() == h('/home/z/my-project/findings.md'))
