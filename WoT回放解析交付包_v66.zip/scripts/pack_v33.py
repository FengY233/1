#!/usr/bin/env python3
"""pack_v33.py — Task 57 交付打包: V33 = V32 底座 + Task 56-b 增量
Task 56-b: ★★★★★0x37 值段完全破译(PropertyChangeReader 位流+类型化值+玩家索引+死亡事件流, findings v39 §35)
data_v36: 0x37语义解码样例 JSON + t56 脚本×6 = 7 件
scripts 增量: t56_{batch,collect,decode,root,vt}.py ×5 (census 已随 V32)
"""
import os, zipfile, hashlib, shutil, glob, json

DL = '/home/z/my-project/download'
V32 = f'{DL}/WoT回放解析交付包_v32.zip'
OUT = f'{DL}/WoT回放解析交付包_v33.zip'
DATA36 = f'{DL}/data_v36'

assert os.path.exists(V32), 'V32 底座缺失'
n36 = len(os.listdir(DATA36)) if os.path.exists(DATA36) else 0
assert n36 == 7, f'data_v36 不完整(期望7件, 实际{n36})'
# V32 已含 t56_census.py; 增量 = 其余 5 件
INC = ['t56_batch.py', 't56_collect.py', 't56_decode.py', 't56_root.py', 't56_vt.py']
for f in INC:
    assert os.path.exists(f'/home/z/my-project/scripts/{f}'), f'缺 {f}'
zv = zipfile.ZipFile(V32)
have_census = 'scripts/t56_census.py' in zv.namelist()
assert have_census, 'V32 底座应已含 scripts/t56_census.py'
zv.close()

# 1) 以 V32 为底座
zin = zipfile.ZipFile(V32, 'r')
old_readme = zin.read('README.md').decode('utf-8')
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as zout:
    for item in zin.infolist():
        if item.filename in ('findings.md', 'worklog.md', 'README.md', 'audit_v32.json'):
            continue  # 换新版本
        zout.writestr(item, zin.read(item.filename))
    # findings/worklog 主位新版
    zout.write('/home/z/my-project/findings.md', 'findings.md')
    zout.write('/home/z/my-project/worklog.md', 'worklog.md')
    # data_v36
    for f in sorted(os.listdir(DATA36)):
        zout.write(f'{DATA36}/{f}', f'data_v36/{f}')
    # scripts 增量
    for f in INC:
        zout.write(f'/home/z/my-project/scripts/{f}', f'scripts/{f}')

# 2) README 增补(旧 README + V33 节)
readme_add = """

---

# V33 增补（Task 56-b · v39 · ★★★★★0x37 值段完全破译：PropertyChangeReader 位流 + 死亡事件流）

在 V32 全量底座之上新增：

| 内容 | 说明 |
|---|---|
| `findings.md` | ★ 结论登记册 v39（新增 §35：★★★★★0x37 值段完全破译——路径读取器链源码级闭环 / BitReader 类全解 / op≥2 值格式定案 / op=1 切片区间对 / 七类节点 vtable 终局表（RTTI 全署名）/ 分发架构双触发器真身 / 玩家索引空间 + 死亡事件流 / Root 巨包 volatile delta 位图批量） |
| `data_v36/` | t56 全套（0x37 语义解码样例 JSON：76 死亡事件 / 每玩家计数器终值 / nid 族统计 / 结构速查 + 脚本×6） |
| `scripts/t56_*.py` | 增量 5 件（decode 语义解码器 / batch 全语料批处理 / root Root 巨包解析 / vt vtable 直读 / collect 汇总——census 已随 V32 交付） |

核心突破（Task 56-b）：
1. **★★★★★路径读取器链源码级闭环**：FUN_142abf4a0 = `PropertyChangeReader::readAndApply`（类名与 `property_owner.cpp` 源文件经错误串 + .rdata 构建路径双出土）；调用链 140399aa0（Composite::onUpdate）→1403d51e0（op 分发）→142a7c1a0→142aae130→142abf4a0 全链钉死。
2. **★BitReader 类全解**：FUN_142ca1860 ctor{stream,bitsLeft_,byte_} / 142ca1900 read(n) MSB-first 无符号 / 142ca19a0 readSigned(n) 带符号扩展 / 142ca18e0 bitsRequired(n)——与 vanilla 0x24 通道同族同构（断言串 `.rdata` 出土）。
3. **★★op≥2 值格式定案**：L 字节体 = MSB-first 位流 `[1][bitsRequired(n₁) idx₁]…[0][bitsRequired(n_final) VALUE]` + **字节对齐类型化值**（setter=node->vt[4] 从流剩余字节读 DataType 线格式）；执行器断言全耗尽 → 总位数 ∈ (8(L-1), 8L]。**op=1 切片** = 两次 read(bitsRequired(width+1)) = [lo,hi] 切片区间对——首次字节级钉死。
4. **七类节点 vtable 终局表**：直读 exe 簇 0x1435df3e8-6b8，RTTI 全署名（BWRootNode/BWEntityNode/ClientDynComponentNode/ClientPrimitivePropertyNode/ClientCompositePropertyNode/ClientMethodCalleeNode/ServerMethodCallerNode）；全部 vt[0x58]=ret 桩（class-2 消息零体，0x32/0x37 共享结论）；vt[0x08]=节点类型标签，树哈希 [nid:4B][tag:1B] 进 MD5。
5. **分发架构终局**：0x36（64,165 包/场主力）→ `BW::ClientHub::processUpdateNode`（client_hub.cpp）`[u16 BE nid]→findNode(nid)→node->vt[0x60](stream)`；0x35（189 包/场）→ FUN_140e74040 class 分发（nid 高字节 class 0-5→hub 槽 11-15，class≥6 静默跳过仅耗 2B）。
6. **★玩家索引空间破译**：idx₁=32-61 = **30 个玩家**（15v15 全员）——b0 全偶根源 = w₁=6 时 bit7=路径终止符；b0=0xC0+2×player（30 唯一值 0xC0-0xFA 步长 2 铁证）；nid 0x07DD/0x08F1 族实证。
7. **★★死亡事件流破译**：死亡三联包（L=26 `[len][pickle {"deathOrder":N}]` + L=16 `[1][13B 记录]` + L=4 `u16 状态 1→2`）同 clk 到达；全语料 **76 条死亡事件**，deathOrder 按 clk 单调——击杀顺序语义级可读。
8. **Root 巨包破解**：t55 误标「op=0」族正名 = `BWRootNode::onUpdate` volatile delta 位图批量（树态 MD5→注册表查找→clist+位图+子消息链+浮点元组 -1.0/30.0/4.0/0.05），24/845 完美链式铺满（前缀段交错结构待续）。
9. **进度**：按字节加权理解度 94.09% → **94.31%**（0x37 理解度 0.75→0.90：架构+文法+值格式+死亡事件语义，余 Root 前缀文法与属性确名）。
"""
z = zipfile.ZipFile(OUT, 'a')
z.writestr('README.md', old_readme + readme_add)
audit = {
 "version": "v33",
 "date": "2026-09-26",
 "task": "Task 56-b: 0x37 值段完全破译(PropertyChangeReader 位流 + 类型化值 + 玩家索引空间 + 死亡事件流)",
 "headline": [
  "★★★★★ 路径读取器链源码级闭环: FUN_142abf4a0 = PropertyChangeReader::readAndApply(property_owner.cpp), 调用链 140399aa0→1403d51e0→142a7c1a0→142aae130→142abf4a0",
  "★ BitReader 类全解: 142ca1860 ctor / 142ca1900 read(n) MSB-first / 142ca19a0 readSigned / 142ca18e0 bitsRequired——与 0x24 通道同族",
  "★★ op≥2 值格式定案: [1][bitsRequired(n) idx]…[0][VALUE] 位流 + 字节对齐类型化值(setter=vt[4] DataType 线格式); op=1 切片=[lo,hi] 区间对",
  "七类节点 vtable 终局表(RTTI 全署名, 全部 vt[0x58]=桩=class2 零体; vt[0x08]=类型标签; 树哈希 [nid:4B][tag:1B] 进 MD5)",
  "分发架构终局: 0x36 主力(64,165 包/场)→BW::ClientHub::processUpdateNode [u16 nid]→vt[0x60]; 0x35→FUN_140e74040 class 分发(class≥6 静默跳过)",
  "★ 玩家索引空间: idx₁=32-61=30 玩家(15v15), b0=0xC0+2×player 全偶铁证(终止符 bit)",
  "★★ 死亡事件流: 三联包(L=26 pickle deathOrder + L=16 记录 + L=4 状态)同 clk; 全语料 76 条, deathOrder 按 clk 单调",
  "Root 巨包破解: BWRootNode::onUpdate volatile delta 位图批量(树态 MD5→注册表→clist+位图+子消息链+浮点元组), 24/845 完美铺满",
  "按字节加权理解度 94.09% → 94.31% (0x37 理解度 0.75→0.90)",
 ],
 "coverage": {
  "corpus": "10 场随机战", "total_pkts": 1514067, "total_payload_bytes": 48202991,
  "weighted_understanding_pct": 94.31,
  "channel_status": {
   "0x0A": {"share": 68.05, "u": 0.95, "note": "volatile 位置流, v6 布局 45B 定长零例外"},
   "0x07": {"share": 12.94, "u": 1.00, "note": "属性更新 100%(37105/37105)"},
   "0x39": {"share": 2.48, "u": 0.40, "note": "复制流, 通道身份已知(NetworkReplicationPoint), 字段语义未鉴定"},
   "0x37": {"share": 1.52, "u": 0.90, "note": "NRL 变换缓冲——架构+文法+值格式+死亡事件语义全解; 余 Root 前缀文法与属性确名"},
   "0x05": {"share": 1.18, "u": 1.00, "note": "属性/创建流 100%(6899/6899)"},
   "0x32": {"share": 0.69, "u": 1.00, "note": "NRL 组件创建 100%(6822/6822)+语义事件流"},
   "0x24": {"share": 0.20, "u": 1.00, "note": "嵌套/切片更新 100%(5241/5241)"},
   "0x04": {"share": 0.05, "u": 1.00, "note": "leaveAoI 100%(4922/4922)"},
   "0x3D": {"share": 0.00, "u": 1.00, "note": "entityDefs 指纹, 算法 100% 破译(服务端 def 漂移致复现值未中, 指纹性质)"},
  },
  "remaining": [
   "①0x37 Root 体前缀精确文法(clist/位图/浮点交错布局, 24/845 已铺满链式段)",
   "②finalIdx 索引空间终判 + 属性确名(v8-csi vs 运行时重排空间, 待 0x07 同拍对齐)",
   "③idx₁↔eid↔名册 join(30 玩家序↔300 花名册)",
   "④L=6 计数器与 L=16 记录的属性确名(待 0x07 同拍)",
   "⑤NRL 节点注册表补全(0x37 nid↔0x32 nd 表 join 现 1-11%, Root 子 nid 增量注册假说)",
   "⑥0x39 复制流字段语义(2.48% 字节)",
   "⑦0x3D digest 服务端 def 漂移(指纹性质, 不影响内容理解)",
   "⑧边缘: karelia2 deathOrder 异常 / ln156 消歧 / 59 tid 补名 / 残留字节归因",
  ],
 },
}
z.writestr('audit_v33.json', json.dumps(audit, ensure_ascii=False, indent=1))
z.close()

# 3) 校验
zf = zipfile.ZipFile(OUT)
assert zf.testzip() is None, 'zip 校验失败'
names = zf.namelist()
n = len(names)
size = os.path.getsize(OUT)
md5 = hashlib.md5(open(OUT, 'rb').read()).hexdigest()
for probe in ('data_v36/0x37语义解码样例_t56.json', 'scripts/t56_decode.py',
              'scripts/t56_root.py', 'audit_v33.json', 'README.md', 'findings.md', 'worklog.md'):
    assert probe in names, f'缺 {probe}'
zin_md5 = hashlib.md5(open(V32, 'rb').read()).hexdigest()
print(f'V33 = {n} 文件, {size:,} B ({size/1048576:.2f} MB), md5={md5}')
print(f'底座 V32 md5={zin_md5} (605 件)')
print(f'增量: data_v36×7 + scripts×5 + findings v39 + worklog + README + audit_v33')

# 4) 备份 + 三处同步
BK = '/home/z/my-project/upload/backup_v33'
os.makedirs(BK, exist_ok=True)
shutil.copy2(OUT, f'{BK}/WoT回放解析交付包_v33.zip')
shutil.copy2('/home/z/my-project/findings.md', f'{BK}/findings.md')
shutil.copy2('/home/z/my-project/worklog.md', f'{BK}/worklog.md')
with zipfile.ZipFile(OUT) as zz:
    open(f'{DL}/audit_v33.json', 'wb').write(zz.read('audit_v33.json'))
    open(f'{BK}/audit_v33.json', 'wb').write(zz.read('audit_v33.json'))
shutil.copy2('/home/z/my-project/findings.md', '/home/z/my-project/upload/findings.md')
shutil.copy2('/home/z/my-project/worklog.md', '/home/z/my-project/upload/worklog.md')
print('备份: upload/backup_v33/ (包+findings+worklog+audit); upload/findings+worklog 同步')
