#!/usr/bin/env python3
"""pack_v32.py — Task 56 交付打包: V32 = V31 底座 + Task 55 增量 + 进度普查
Task 55: ★★★★★0x37 通道架构翻案(NRL 缓冲协议全解, findings v38 §34)
Task 56: 通道字节占比普查(10 场 151.4万包 45.97MB → 加权理解度 94.09%)
data_v35: t55 脚本×11 + 结果×3(汇总/join/明细) + 普查×1 = 15 件
scripts 增量: t55_*.py ×11 + t56_census.py ×1 = 12 件
"""
import os, zipfile, hashlib, shutil, glob, json

DL = '/home/z/my-project/download'
V31 = f'{DL}/WoT回放解析交付包_v31.zip'
OUT = f'{DL}/WoT回放解析交付包_v32.zip'
DATA35 = f'{DL}/data_v35'

assert os.path.exists(V31), 'V31 底座缺失'
n35 = len(os.listdir(DATA35)) if os.path.exists(DATA35) else 0
assert n35 == 15, f'data_v35 不完整(期望15件, 实际{n35})'
t5x = sorted(glob.glob('/home/z/my-project/scripts/t55_*.py')) + sorted(glob.glob('/home/z/my-project/scripts/t56_*.py'))
assert len(t5x) == 12, f't55/t56 脚本不齐(期望12件, 实际{len(t5x)})'

# 1) 以 V31 为底座
zin = zipfile.ZipFile(V31, 'r')
old_readme = zin.read('README.md').decode('utf-8')
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as zout:
    for item in zin.infolist():
        if item.filename in ('findings.md', 'worklog.md', 'README.md', 'audit_v31.json'):
            continue  # 换新版本
        zout.writestr(item, zin.read(item.filename))
    # findings/worklog 主位新版
    zout.write('/home/z/my-project/findings.md', 'findings.md')
    zout.write('/home/z/my-project/worklog.md', 'worklog.md')
    # data_v35
    for f in sorted(os.listdir(DATA35)):
        zout.write(f'{DATA35}/{f}', f'data_v35/{f}')
    # scripts 增量
    for f in t5x:
        zout.write(f, f'scripts/{os.path.basename(f)}')

# 2) README 增补(旧 README + V32 节)
readme_add = """

---

# V32 增补（Task 55-56 · v38 · 0x37 通道架构翻案：NRL 缓冲协议全解 + 进度定量普查）

在 V31 全量底座之上新增：

| 内容 | 说明 |
|---|---|
| `findings.md` | ★ 结论登记册 v38（新增 §34：★★★★★0x37/0x35/0x36 三通道真架构——播放分发器源码级翻案 + NRL 消息文法钉死 + op 三语义 + 失败即弃容错模型 + 七类节点 vtable 全表 + 变换值字段坐标） |
| `data_v35/` | t55 全套（0x37 全局解析汇总 / 2.5MB 初步 join / 2.9MB 全语料消息明细 + 脚本×11）+ t56 通道字节占比普查（10 场 151.4 万包 45.97MB 逐通道统计 + 加权理解度 94.09%） |
| `scripts/t55_*.py` `t56_census.py` | 同步副本：NRL 探针/全局缓冲模拟/失步解剖/值统计/join ×11 + 通道普查器 |

核心突破（Task 55）：
1. **★★★★★0x37/0x35/0x36 三通道真架构（源码级翻案）**：播放分发器 FUN_140574dd0——0x35/0x36 = 无流参数的空包触发器（分别驱动 FUN_140e5c4e0(ep,2/6) 从 NRL 缓冲消费一条消息），0x37 = FUN_140e5c470 整块追加端点+0xb8 双接口 MemoryOStream。推翻 v6「0x35/36 空流版本」旧理解——空包是设计而非缺数据。
2. **★★★NRL 消息文法源码级钉死**：[u16 BE nid][体]，体按节点 vt[0x60] 分派——组合属性节点(rk4) = [u8 op∈{0,1,2}][u8 L(0xFF→u24 逃逸)][L B 值]（FUN_140399aa0 逐指令）；Entity/DynComp/ServerMethodCaller(rk1/2/6) = 空体 2 字节消息。
3. **★op 三语义**：0=整值设置 / 1=切片（is_slice=1）/ 2+=嵌套路径更新（is_slice=0）——与 0x24 通道共享执行端 FUN_142a7c1a0。
4. **★失败即弃容错模型**：findNode 失败或体读失败 → stream->finish() 丢弃整个缓冲，服务器以快照重发对账（初始 nid 同 op 同 L 仅值差实证）。
5. **★实证链**：game0 前 102 事件 100% 逐字节闭环；快照 blob 125B=8 消息精确分割；11 场消息数≈flush 数（3 场精确相等）。
6. **★变换值字段坐标定位**：op=2 L=6 主力型 27341 条——b1=字段选择器{0x98 主/0x94/0x1c/0x04/0x30}、b0=成对共享平滑字节（全偶，47 唯一值）、b2-b5=u16 对（符号扩展 fe/ff 模式）——数学定标剩余路径读取器一跳（FUN_142abf4a0）。

核心成果（Task 56）：
7. **进度定量普查**：10 场随机战语料 1,514,067 包 / 45.97MB payload 逐通道统计——0x0A 位置流 68.05% / 0x07 属性 12.94% / 0x39 复制流 2.48% / 0x37 NRL 1.52% / 0x05 1.18% / 0x32 0.69%；**按字节加权「回放内容搞懂度」= 94.09%**。
8. **剩余缺口排序**：①0x37 变换值数学定标（1.52% 字节，车辆动画重建的最后一块）②NRL 节点注册表 join（nid↔节点表 1-11%）③0x39 复制流字段语义（2.48% 字节）④0x3D digest 服务端 def 漂移（算法已全破，指纹性质）⑤边缘小项（karelia2 deathOrder 异常等）。
"""
z = zipfile.ZipFile(OUT, 'a')
z.writestr('README.md', old_readme + readme_add)
audit = {
 "version": "v32",
 "date": "2026-09-26",
 "task": "Task 55: 0x37 通道架构翻案(NRL 缓冲协议全解) + Task 56: 通道字节占比普查(进度定量)",
 "headline": [
  "★★★★★ 0x37/0x35/0x36 三通道真架构(源码级): 0x35/36=空包触发器(FUN_140e5c4e0(ep,2/6) 消费 NRL 缓冲一条), 0x37=FUN_140e5c470 整块追加端点+0xb8——推翻 v6 空流版本旧理解",
  "★★★ NRL 消息文法源码级钉死: [u16 BE nid][体], 体按节点 vt[0x60] 分派; rk4 组合体=[u8 op][u8 L(FF→u24)][L B]; rk1/2/6=空体 2B 消息",
  "★ op 三语义: 0=整值/1=切片(is_slice=1)/2+=嵌套路径(is_slice=0), 与 0x24 共享执行端 FUN_142a7c1a0",
  "★ 失败即弃协议: findNode/体读失败→stream->finish() 丢弃整个缓冲, 服务器快照重发对账",
  "★ 七类节点 vt[0x58]/vt[0x60] 全表补齐(Composite/Primitive/MethodCallee/Root 位图驱动)",
  "★ 实证: game0 前 102 事件 100% 闭环; 快照 blob 125B=8 消息精确分割; 11 场消息数≈flush 数(3 场精确相等)",
  "★ 变换值字段坐标: op=2 L=6 主力 27341 条——b1=字段选择器/b0=成对共享平滑字节(全偶)/b2-b5=u16 对(符号扩展)",
  "★ 通道普查: 10 场 1,514,067 包 45.97MB——0x0A 68.05%/0x07 12.94%/0x39 2.48%/0x37 1.52%; 按字节加权理解度 94.09%",
 ],
 "coverage": {
  "corpus": "10 场随机战", "total_pkts": 1514067, "total_payload_bytes": 48202991,
  "weighted_understanding_pct": 94.09,
  "channel_status": {
   "0x0A": {"share": 68.05, "u": 0.95, "note": "volatile 位置流, v6 布局 45B 定长零例外"},
   "0x07": {"share": 12.94, "u": 1.00, "note": "属性更新 100%(37105/37105)"},
   "0x39": {"share": 2.48, "u": 0.40, "note": "复制流, 通道身份已知(NetworkReplicationPoint), 字段语义未鉴定"},
   "0x37": {"share": 1.52, "u": 0.75, "note": "NRL 变换缓冲, 架构+文法 100%, op=2 值定标未完成"},
   "0x05": {"share": 1.18, "u": 1.00, "note": "属性/创建流 100%(6899/6899)"},
   "0x32": {"share": 0.69, "u": 1.00, "note": "NRL 组件创建 100%(6822/6822)+语义事件流"},
   "0x24": {"share": 0.20, "u": 1.00, "note": "嵌套/切片更新 100%(5241/5241)"},
   "0x04": {"share": 0.05, "u": 1.00, "note": "leaveAoI 100%(4922/4922)"},
   "0x3D": {"share": 0.00, "u": 1.00, "note": "entityDefs 指纹, 算法 100% 破译(服务端 def 漂移致复现值未中, 指纹性质)"},
  },
  "remaining": [
   "①0x37 op=2 变换值数学定标(FUN_142abf4a0 路径读取器链, 1.52% 字节)",
   "②NRL 节点注册表 join 补全(0x37 nid↔0x32 nd 表, 现 1-11%)",
   "③0x39 复制流字段语义(2.48% 字节)",
   "④0x3D digest 服务端 def 漂移(需服务器侧 def, 指纹性质不影响内容理解)",
   "⑤边缘: karelia2 deathOrder 异常/ln156 消歧/59 tid 补名/0x35 class2 创建体 NRL 形态/残留字节归因",
  ],
 },
}
z.writestr('audit_v32.json', json.dumps(audit, ensure_ascii=False, indent=1))
z.close()

# 3) 校验
zf = zipfile.ZipFile(OUT)
assert zf.testzip() is None, 'zip 校验失败'
names = zf.namelist()
n = len(names)
size = os.path.getsize(OUT)
md5 = hashlib.md5(open(OUT, 'rb').read()).hexdigest()
# 增量抽验
for probe in ('data_v35/0x37全局解析汇总_t55.json', 'data_v35/通道字节占比普查_t56.json',
              'scripts/t55_global3.py', 'scripts/t56_census.py', 'audit_v32.json', 'README.md'):
    assert probe in names, f'缺 {probe}'
zin_md5 = hashlib.md5(open(V31, 'rb').read()).hexdigest()
print(f'V32 = {n} 文件, {size:,} B ({size/1048576:.2f} MB), md5={md5}')
print(f'底座 V31 md5={zin_md5} (578 件)')
print(f'增量: data_v35×15 + scripts×12 + findings v38 + worklog + README + audit_v32')

# 4) 备份 + 三处同步
BK = '/home/z/my-project/upload/backup_v32'
os.makedirs(BK, exist_ok=True)
shutil.copy2(OUT, f'{BK}/WoT回放解析交付包_v32.zip')
shutil.copy2('/home/z/my-project/findings.md', f'{BK}/findings.md')
shutil.copy2('/home/z/my-project/worklog.md', f'{BK}/worklog.md')
shutil.copy2(f'{DL}/audit_v32.json', f'{BK}/audit_v32.json') if os.path.exists(f'{DL}/audit_v32.json') else None
# audit 从包内导出一份
with zipfile.ZipFile(OUT) as zz:
    open(f'{DL}/audit_v32.json', 'wb').write(zz.read('audit_v32.json'))
    open(f'{BK}/audit_v32.json', 'wb').write(zz.read('audit_v32.json'))
shutil.copy2('/home/z/my-project/findings.md', '/home/z/my-project/upload/findings.md')
shutil.copy2('/home/z/my-project/worklog.md', '/home/z/my-project/upload/worklog.md')
print('备份: upload/backup_v32/ (包+findings+worklog+audit); upload/findings+worklog 同步')
