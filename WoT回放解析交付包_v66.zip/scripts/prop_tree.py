# -*- coding: utf-8 -*-
"""prop_tree.py — 30辆车0x05初始属性流锚点对齐差分 + Avatar.py属性setter + dotEffect结构"""
import sys, struct, collections, json
sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

r = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
PLAYER = 0x2094A145
AVATAR = 0x2094A160
OFF = 34.240 - 139.769
HDR = 46

hdr = json.loads(r.blocks[0].decode('utf-8', 'replace'))

# 1. 每辆车第一个 0x05 的初始流(按名称锚点对齐)
firsts = {}
for (t, clk, pl, i) in r.pkts:
    if t == 0x05 and len(pl) >= HDR:
        eid, typ = struct.unpack_from('<II', pl, 0)
        if typ == 6 and eid not in firsts:
            firsts[eid] = pl[HDR:]

print('车辆初始流数量:', len(firsts))
# 2. 以玩家车为基准, 在流中定位各锚点
pstream = firsts[PLAYER]
print()
print('=== 玩家车初始流(%dB)分段标注 ===' % len(pstream))
print(pstream.hex())
# 锚点: avatarID(0x2094A160)在偏移12出现
aid = struct.pack('<I', AVATAR)
pos_aid = pstream.find(aid)
print('avatarID 出现于偏移', pos_aid)
name = '巅峰荣誉v拍子'.encode('utf-8')
pos_name = pstream.find(name)
print('玩家名出现于偏移', pos_name)

# 3. 全部车辆: 头16字节 + 名称偏移(揭示索引结构是否一致)
print()
print('=== 30辆车初始流前16字节与流长 ===')
for eid in sorted(firsts):
    st = firsts[eid]
    info = hdr['vehicles'].get(str(eid), {})
    nm = info.get('name', '?')
    print('0x%X %-16s len=%3d 前16B: %s' % (eid, nm[:14], len(st), st[:16].hex()))

# 4. 提取所有车的 [.. name ..] 前后固定结构: 对齐到名称末尾做后缀对比
print()
print('=== 名称后32字节(对齐名称结束) ===')
rows = []
for eid in sorted(firsts):
    st = firsts[eid]
    info = hdr['vehicles'].get(str(eid), {})
    nm = info.get('name', '?').encode('utf-8')
    p = st.find(nm)
    if p >= 0 and p + len(nm) + 32 <= len(st):
        rows.append((eid, info.get('name', '?'), st[p + len(nm):p + len(nm) + 32].hex()))
for eid, nm, h in rows[:12]:
    print('0x%X %-14s %s' % (eid, nm[:12], h))
