# -*- coding: utf-8 -*-
"""analyze_packets.py — 逐类型字节级实证分析
对每种类型取代表性样本 hexdump，统计首字节/结构特征。
"""
import io
import struct
import sys
from collections import Counter, defaultdict

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

R = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
pkts = R.pkts


def hexdump(b, limit=96):
    out = []
    for i in range(0, min(len(b), limit), 16):
        chunk = b[i:i + 16]
        hexs = ' '.join('%02x' % c for c in chunk)
        txt = ''.join(chr(c) if 32 <= c < 127 else '.' for c in chunk)
        out.append('    %04x  %-47s  %s' % (i, hexs, txt))
    if len(b) > limit:
        out.append('    ... (%d bytes total)' % len(b))
    return '\n'.join(out)


by_type = defaultdict(list)
for p in pkts:
    by_type[p[0]].append(p)

print('共 %d 类型' % len(by_type))
for ty in sorted(by_type.keys()):
    lst = by_type[ty]
    sizes = [len(p[2]) for p in lst]
    clocks = [p[1] for p in lst]
    print('=' * 78)
    print('TYPE 0x%-3X  count=%-6d  size min/med/max = %d/%d/%d  clock %d..%d' % (
        ty, len(lst), min(sizes), sorted(sizes)[len(sizes) // 2], max(sizes),
        min(clocks), max(clocks)))
    # 首包（通常在 setup 阶段）与中间一包
    idxs = [0, len(lst) // 2, -1] if len(lst) >= 3 else list(range(len(lst)))
    for j in idxs:
        p = lst[j]
        gi = p[3]
        print('  -- pkt#%d (第%d个该类型) clock=%d len=%d' % (gi, j, p[1], len(p[2])))
        print(hexdump(p[2]))
    print()
