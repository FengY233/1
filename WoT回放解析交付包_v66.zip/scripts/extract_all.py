# -*- coding: utf-8 -*-
"""extract_all.py — 全量数据提取: 实体表/轨迹/事件/属性 → JSON"""
import io
import json
import struct
import sys
from collections import Counter, defaultdict

sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile
from bw_pickle import bw_loads

REPLAY = '/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay'
R = ReplayFile(REPLAY)
pkts = R.pkts

periods = {}
for p in pkts:
    if p[0] == 0x16:
        (v,) = struct.unpack('<I', p[2])
        periods[v] = p[1]
p2, p3, p4 = periods[2], periods[3], periods[4]

# 游戏时间: 战斗窗口内用 0x36 tick 计数
ticks = 0
game_t = {}
for p in pkts:
    if p3 <= p[1] < p4:
        if p[0] == 0x36:
            ticks += 1
        game_t[p[3]] = ticks / 10.0
    elif p[1] >= p4:
        game_t[p[3]] = ticks / 10.0 + (p[1] - p4) / 57475.0
    else:
        game_t[p[3]] = -(p3 - p[1]) / 57475.0

# JSON 头
data = open(REPLAY, 'rb').read()
magic, bc = struct.unpack_from('<II', data, 0)
pos = 8
blocks = []
for _ in range(bc):
    (blen,) = struct.unpack_from('<I', data, pos)
    blocks.append(data[pos + 4:pos + 4 + blen])
    pos += 4 + blen
j0 = json.loads(blocks[0].decode('utf-8'))
j1 = json.loads(blocks[1].decode('utf-8'))
veh_info = {int(k): v for k, v in j0['vehicles'].items()}

# ---------- 实体表 ----------
entities = {}
for p in pkts:
    if p[0] != 0x5 or len(p[2]) < 46:
        continue
    (eid,) = struct.unpack_from('<I', p[2], 0)
    (tidx,) = struct.unpack_from('<I', p[2], 4)
    e = entities.setdefault(eid, {'id': eid, 'types': set(), 'creates': 0, 'is_vehicle': False})
    e['types'].add(tidx)
    e['creates'] += 1

# 车辆实体 = JSON avatarSessionID 直接作为实体ID
for vid, info in veh_info.items():
    if vid in entities:
        entities[vid]['is_vehicle'] = True

# 0xA 活跃度 & 轨迹
act = Counter()
tracks = defaultdict(list)   # eid -> [(game_t, x, y, z, yaw)]
for p in pkts:
    if p[0] != 0xA or len(p[2]) < 45:
        continue
    (e, v2) = struct.unpack_from('<II', p[2], 0)
    x, y, z = struct.unpack_from('<fff', p[2], 8)
    yaw = struct.unpack_from('<f', p[2], 32)[0]
    act[e] += 1
    tracks[e].append((game_t[p[3]], round(x, 2), round(y, 2), round(z, 2), round(yaw, 4)))

# ---------- 事件表 ----------
events = []
for p in pkts:
    if p[0] != 0x31:
        continue
    try:
        (nl,) = struct.unpack_from('<I', p[2], 0)
        name = p[2][4:4 + nl].decode('utf-8', 'replace')
        off = 4 + nl
        (dl,) = struct.unpack_from('<I', p[2], off)
        dta = p[2][off + 4:off + 4 + dl]
        obj = bw_loads(dta)
        events.append({
            'pkt': p[3], 'clock': p[1], 'game_t': round(game_t[p[3]], 2),
            'callback': name, 'data': _saferepr(obj)})
    except Exception as ex:
        events.append({'pkt': p[3], 'clock': p[1], 'callback': 'ERR', 'error': str(ex)})


def _saferepr(o):
    if isinstance(o, tuple) and len(o) == 3 and isinstance(o[2], dict):
        d = {}
        for k, v in o[2].items():
            if isinstance(v, bytes):
                d[k] = v.hex()
            elif isinstance(v, str) and any(ord(c) > 127 and ord(c) < 256 for c in v):
                d[k] = v.encode('latin1', 'replace').hex()
            else:
                d[k] = v
        return {'eventID': o[0], 'flag': o[1], 'args': d}
    if isinstance(o, (list, tuple)):
        return list(o)
    return o


# 重新跑一遍 events 用 _saferepr
events = []
for p in pkts:
    if p[0] != 0x31:
        continue
    try:
        (nl,) = struct.unpack_from('<I', p[2], 0)
        name = p[2][4:4 + nl].decode('utf-8', 'replace')
        off = 4 + nl
        (dl,) = struct.unpack_from('<I', p[2], off)
        dta = p[2][off + 4:off + 4 + dl]
        obj = bw_loads(dta)
        events.append({'pkt': p[3], 'clock': p[1], 'game_t': round(game_t[p[3]], 2),
                       'callback': name, 'data': _saferepr(obj)})
    except Exception as ex:
        events.append({'pkt': p[3], 'clock': p[1], 'callback': 'ERR', 'error': str(ex)})

# ---------- 车辆属性更新 (0x24 for player) ----------
ME = j0['playerID']
me_vid = None
for vid, info in veh_info.items():
    if info['name'] == j0['playerName']:
        me_vid = vid
me_events = []
for p in pkts:
    if p[0] != 0x24 or len(p[2]) < 9:
        continue
    (e,) = struct.unpack_from('<I', p[2], 0)
    if e != me_vid:
        continue
    flag = p[2][4]
    (n,) = struct.unpack_from('<I', p[2], 5)
    me_events.append({'pkt': p[3], 'game_t': round(game_t[p[3]], 2), 'flag': flag,
                      'len': n, 'data_hex': p[2][9:9 + n].hex()})

# ---------- 阶段事件 ----------
phase_events = []
for p in pkts:
    if p[0] == 0x16:
        (v,) = struct.unpack('<I', p[2])
        phase_events.append({'pkt': p[3], 'clock': p[1], 'period': v})
    elif p[0] == 0x17:
        (f,) = struct.unpack('<f', p[2])
        phase_events.append({'pkt': p[3], 'clock': p[1], 'timer': round(f, 3)})

# ---------- 相机模式 ----------
camera_events = []
for p in pkts:
    if p[0] == 0x1B:
        (n,) = struct.unpack_from('<I', p[2], 0)
        camera_events.append({'pkt': p[3], 'game_t': round(game_t[p[3]], 2),
                              'mode': p[2][4:4 + n].decode('utf-8', 'replace')})

# ---------- 实体离场 (0x4 = leaveAoI 推测) ----------
leaves = []
for p in pkts:
    if p[0] == 0x4 and len(p[2]) == 4:
        (e,) = struct.unpack('<I', p[2])
        leaves.append({'pkt': p[3], 'game_t': round(game_t[p[3]], 2), 'entity': e})

# ---------- 输出 ----------
out = {
    'meta': {
        'file': REPLAY.split('/')[-1],
        'magic': '0x%08X' % R.magic,
        'block_count': R.block_count,
        'block_sizes': [len(b) for b in R.blocks],
        'gap_hex': R.gap.hex(),
        'gap_fields': {'zlib_decompressed_size': struct.unpack('<I', R.gap[:4])[0],
                        'encrypted_stream_len': struct.unpack('<I', R.gap[4:8])[0]},
        'main_len': len(R.main), 'stream_len': R.stream_len,
        'packet_count': len(pkts), 'consumed': R.consumed,
        'period_clocks': {str(k): v for k, v in periods.items()},
        'clock_unit_note': '客户端墙钟微秒(再录制回放), 战斗段表观速率≈57475/s因变速播放',
        'battle_game_seconds': ticks / 10.0,
    },
    'header_json': j0,
    'entities': [
        {'id': e['id'], 'hex': '0x%08X' % e['id'], 'types': sorted(e['types']),
         'creates': e['creates'], 'is_vehicle': e['is_vehicle'],
         'updates_0xA': act.get(e['id'], 0),
         'name': veh_info[e['id']]['name'] if e['id'] in veh_info else None,
         'vehicleType': veh_info[e['id']]['vehicleType'] if e['id'] in veh_info else None,
         'team': veh_info[e['id']]['team'] if e['id'] in veh_info else None}
        for e in entities.values()],
    'vehicle_tracks': {str(k): v for k, v in tracks.items() if k in veh_info},
    'events': events,
    'player_vehicle_events': me_events,
    'phase_events': phase_events,
    'camera_events': camera_events,
    'leave_aoi': leaves,
}

with open('/home/z/my-project/work/decoded_full.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, ensure_ascii=False, indent=1)

print('实体总数: %d (车辆 %d)' % (len(entities), sum(1 for e in entities.values() if e['is_vehicle'])))
print('事件: %d, 玩家车辆事件: %d, 相机: %d, 离场: %d' % (
    len(events), len(me_events), len(camera_events), len(leaves)))
print('轨迹车辆数: %d' % len(out['vehicle_tracks']))
type_hist = Counter()
for e in entities.values():
    for t in e['types']:
        type_hist[t] += e['creates']
print('createEntity 类型直方图:', dict(type_hist))
print('已保存 /home/z/my-project/work/decoded_full.json')
