# -*- coding: utf-8 -*-
"""analyze_32_37.py — 0x32/0x37 内部结构实证"""
import io
import struct
import sys
from collections import Counter

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

R = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
pkts = R.pkts


def dump(b, limit=200):
    out = []
    for i in range(0, min(len(b), limit), 16):
        chunk = b[i:i + 16]
        hexs = ' '.join('%02x' % c for c in chunk)
        txt = ''.join(chr(c) if 32 <= c < 127 else '.' for c in chunk)
        out.append('    %04x  %-47s  %s' % (i, hexs, txt))
    if len(b) > limit:
        out.append('    ... (%d bytes total)' % len(b))
    return '\n'.join(out)


print('===== 0x32 首 u16 分布 =====')
first16 = Counter()
for p in pkts:
    if p[0] == 0x32 and len(p[2]) >= 6:
        (n,) = struct.unpack_from('<I', p[2], 0)
        if n + 4 == len(p[2]) and n >= 2:
            (v,) = struct.unpack_from('<H', p[2], 4)
            first16[v] += 1
for v, c in first16.most_common(20):
    print('  0x%04x (%d): %d 次' % (v, v, c))

print()
print('===== 0x37 首 u16 分布 =====')
first16b = Counter()
for p in pkts:
    if p[0] == 0x37 and len(p[2]) >= 6:
        (n,) = struct.unpack_from('<I', p[2], 0)
        if n + 4 == len(p[2]) and n >= 2:
            (v,) = struct.unpack_from('<H', p[2], 4)
            first16b[v] += 1
for v, c in first16b.most_common(20):
    print('  0x%04x (%d): %d 次' % (v, v, c))

print()
print('===== pkt#99 (0x32, 车辆列表?) =====')
p = pkts[99]
print('type=0x%X clock=%d len=%d' % (p[0], p[1], len(p[2])))
dump(p[2], 400)

print()
print('===== 全部 clock=0 的 0x32/0x37 (setup 阶段) =====')
for i, p in enumerate(pkts[:1400]):
    if p[0] in (0x32, 0x37) and p[1] == 0:
        print('#%d t=0x%X len=%d' % (i, p[0], len(p[2])))
        dump(p[2], 160)
        print()
