# -*- coding: utf-8 -*-
"""make_charts_v3_0607.py — 图06/07 v3 版
06: 三会话生命周期 — ②录制窗与①实时会话同一时间轴对齐 (证明录制会话=实时会话本身)
07: 左 clock(float秒)→游戏时间 完美 1:1 线性; 右 双会话击杀时刻一致性
"""
import json
import os
import sys
import struct

import matplotlib
import matplotlib.font_manager as fm

fm.fontManager.addfont('/usr/share/fonts/truetype/chinese/SarasaMonoSC-Regular.ttf')
fm.fontManager.addfont('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')

import matplotlib.pyplot as plt

plt.rcParams.update({
    'font.sans-serif': ['Sarasa Mono SC', 'DejaVu Sans'],
    'axes.unicode_minus': False,
    'figure.facecolor': '#FFFFFF', 'axes.facecolor': '#FFFFFF',
    'axes.edgecolor': '#E5E7EB', 'axes.linewidth': 0.8,
    'axes.spines.top': False, 'axes.spines.right': False,
    'axes.grid': False,
    'xtick.major.size': 0, 'ytick.major.size': 0,
    'xtick.labelsize': 9, 'ytick.labelsize': 9,
    'axes.labelsize': 10, 'axes.titlesize': 15, 'axes.titleweight': 'bold', 'axes.titlepad': 14,
    'legend.frameon': False, 'legend.fontsize': 9,
    'figure.dpi': 200, 'savefig.dpi': 200, 'savefig.facecolor': '#FFFFFF',
})

C_BLUE, C_CYAN, C_PURPLE, C_AMBER, C_RED, C_GREEN = '#3B82F6', '#06B6D4', '#8B5CF6', '#F59E0B', '#EF4444', '#10B981'
G900, G700, G500, G400, G300, G200, G100 = '#111827', '#374151', '#6B7280', '#9CA3AF', '#D1D5DB', '#E5E7EB', '#F3F4F6'
OUT = '/home/z/my-project/download/charts'
os.makedirs(OUT, exist_ok=True)

sys.path.insert(0, '/home/z/my-project/scripts')
from wot_replay_lib import ReplayFile

R = ReplayFile('/home/z/my-project/upload/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay')
pkts = R.pkts
def f32(u):
    return struct.unpack('<f', struct.pack('<I', u))[0]
p16 = sorted((f32(p[1]), struct.unpack('<I', p[2][:4])[0]) for p in pkts if p[0] == 0x16)
p2, p3, p4 = (min(c for c, per in p16 if per == k) for k in (2, 3, 4))
t_end = f32(max(p[1] for p in pkts if p[1] != 0xFFFFFFFF))
raw = json.load(open('/home/z/my-project/scripts/align_v2_raw.json'))
OFF = 90.44  # 录制起点 18:01:05.3 − 登录 17:59:34.86

# ═══════════════ 图 06 v3 ═══════════════
fig, axes = plt.subplots(3, 1, figsize=(11.5, 8.8), constrained_layout=True)
rows = [
    ('① 实时战斗会话  09-11 17:59:34 – 18:12:53 (798.5s) · bt↔ts 全程 1.000x', [
        ('车库+登录', 0, 71.8, G300, 'above'),
        ('随机战排队 43.4s', 71.8, 115.2, C_AMBER, 'above'),
        ('加载+等待', 115.2, 125.4, C_CYAN, 'b1'),
        ('倒计时 30s', 125.4, 155.4, C_PURPLE, 'b2'),
        ('战斗 612.49s (1.000x 实时)', 155.4, 767.9, C_GREEN, 'above'),
        ('结算+断开', 767.9, 798.5, G400, 'b1')]),
    ('② .wotreplay 录制窗 (float32 秒 clock 域) — 与①同一时间轴对齐: 起点=18:01:05.3 (回放头 dateTime)', [
        ('装载尾段 4.24s', OFF + 0, OFF + p2, C_CYAN, 'b1'),
        ('倒计时 30.000s', OFF + p2, OFF + p3, C_PURPLE, 'above'),
        ('战斗 612.495s (1x 实时录制)', OFF + p3, OFF + p4, C_GREEN, 'b1'),
        ('结算 6.1s', OFF + p4, OFF + t_end, G400, 'b2')]),
    ('③ 1x 播放会话  09-23 14:04:27 – 14:15:47 (680.8s) · 回放文件的 1x 重演 (内容互证)', [
        ('启动+装载', 0, 12.0, C_CYAN, 'b1'),
        ('等待+倒计时', 12.0, 42.0, C_PURPLE, 'b2'),
        ('战斗 612.28s (1.000x 播放, 内容与①完全等价)', 42.0, 654.3, C_GREEN, 'above'),
        ('结算+停止', 654.3, 680.8, G400, 'b1')]),
]
YL = {'above': 0.30, 'b1': -0.34, 'b2': -0.64}
VA = {'above': 'bottom', 'b1': 'top', 'b2': 'top'}
for ax, (title, phases) in zip(axes, rows):
    for name, s, e, c, lv in phases:
        ax.barh(0, e - s, left=s, height=0.5, color=c, zorder=3)
        if lv != 'none':
            ax.text((s + e) / 2, YL[lv], name, ha='center', va=VA[lv],
                    fontsize=7.6 if lv != 'above' else 8.2,
                    color=G700 if lv == 'above' else G500)
    ax.set_ylim(-0.95, 0.72)
    ax.set_yticks([])
    ax.set_title(title, fontsize=11.5, loc='left', pad=6)
    ax.set_xlabel('会话时间 (秒)')
axes[0].set_xlim(0, 800)
axes[1].set_xlim(0, 800)  # 与①同轴! 录制窗嵌在①的战斗段内
axes[2].set_xlim(0, 700)
axes[1].annotate('录制窗完全嵌于①的战斗段内 (v2 的"第三会话/989s闲置"为整数误读伪影)',
                 xy=(400, 0.62), fontsize=9, color=G500, ha='center')
fig.suptitle('图6 · 三方数据生命周期：① 实时战斗 = ② 回放录制窗 (v3) ；③ 1x 播放为内容重演', fontsize=14,
             fontweight='bold')
fig.savefig(OUT + '/06_会话生命周期.png')
plt.close(fig)
print('06 v3 done')

# ═══════════════ 图 07 v3 ═══════════════
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12.6, 5.9), constrained_layout=True,
                               gridspec_kw={'width_ratios': [1.35, 1]})
# 左: float clock → 游戏时间 (1:1)
kx = [f32(a['clock']) for a in raw['anchors_raw']]
ky = [a['bt_rel'] for a in raw['anchors_raw']]
ax1.plot([0, 620], [0, 620], color=G300, lw=1.2, ls='--', zorder=1, label='y = x (1:1 参考)')
ax1.scatter(kx, ky, s=28, color=C_RED, zorder=4, label='击杀事件 (0x37 载荷内定位, n=25)')
ax1.scatter([p3, p4], [0, 612.275], s=64, marker='*', color=C_BLUE, zorder=5, label='阶段锚 p3/p4')
ax1.set_xlabel('回放内时刻 − 战斗开始 (float32 秒)')
ax1.set_ylabel('游戏时间 · 实时会话 bt (战斗相对秒)')
ax1.set_title('图7·左 · clock(float32秒) → 游戏时间：完美 1:1 线性\n(25 击杀 + 阶段锚全部落在 y=x 上, 偏差 ≤0.23s)')
ax1.legend(loc='upper left')
ax1.set_xlim(0, 620); ax1.set_ylim(0, 620)
maxd = max(abs(a - b) for a, b in zip(kx, ky))
ax1.annotate('最大偏差 %.3fs (网络传播时延)' % maxd, xy=(0.97, 0.05), xycoords='axes fraction',
             ha='right', fontsize=9, color=G500)
# 右: 双会话击杀时刻一致性 (保留)
ok_bt = [b - 139.769 for b, v, k in raw['old_kills']]
nk_bt = [b - 57.172 for b, v, k in raw['new_kills']]
ax2.plot([0, 620], [0, 620], color=G300, lw=1, ls='--', zorder=1)
ax2.scatter(ok_bt, nk_bt, s=30, color=C_GREEN, zorder=3)
maxd2 = max(abs(a - b) for a, b in zip(ok_bt, nk_bt))
ax2.set_xlabel('实时会话击杀时刻 (战斗相对秒)')
ax2.set_ylabel('播放会话击杀时刻 (战斗相对秒)')
ax2.set_title('图7·右 · 实时会话 ↔ 播放会话 击杀时刻\n逐一对应 (最大偏差 %.3fs)' % maxd2)
ax2.set_xlim(0, 620); ax2.set_ylim(0, 620)
fig.savefig(OUT + '/07_观看行为与时间轴对齐.png')
plt.close(fig)
print('07 v3 done')
