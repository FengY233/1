#!/bin/bash
# 抽取 BigWorld entitydef 中所有 addToMD5 实现，汇总为单一参考文件
OUT=/home/z/my-project/work/bigworld_addtomd5_recipes.txt
ED=/home/z/my-project/work/ext/bigworld_src/programming/bigworld/lib/entitydef
{
echo "===== MD5 digest recipe 汇总 (BigWorld 14.4.1 entitydef) ====="
echo "生成时间: $(date)"
echo
echo "########## 1. EntityDescriptionMap::parse 末尾 (digest_ 计算) ##########"
sed -n '285,292p' $ED/entity_description_map.cpp
echo
echo "########## 2. EntityDescriptionMap::addToMD5 ##########"
sed -n '605,625p' $ED/entity_description_map.cpp
echo
echo "########## 3. EntityDescription::addToMD5 ##########"
sed -n '1738,1802p' $ED/entity_description.cpp
echo
echo "########## 4. MemberDescription::addToMD5 ##########"
sed -n '278,296p' $ED/member_description.cpp
echo
echo "########## 5. DataDescription::addToMD5 ##########"
sed -n '428,440p' $ED/data_description.cpp
echo
echo "########## 6. MethodDescription::addToMD5 ##########"
sed -n '1290,1303p' $ED/method_description.cpp
echo
echo "########## 7. MethodArgs::addToMD5 ##########"
sed -n '368,383p' $ED/method_args.cpp
echo
echo "########## 8. data_types/*::addToMD5 全部 ##########"
for f in $ED/data_types/*.cpp; do
  if grep -q "::addToMD5" "$f"; then
    echo "--- $f ---"
    awk '/::addToMD5/{found=1} found{print; if(/^}/){found=0; print ""}}' "$f"
  fi
done
echo
echo "########## 9. DATA_DISTRIBUTION_FLAGS 常量 ##########"
grep -n "DATA_DISTRIBUTION_FLAGS\|#define DATA_FLAG" $ED/data_description.hpp | head -30
echo
echo "########## 10. MD5 类 append/getDigest 签名 ##########"
grep -n "append\|getDigest" /home/z/my-project/work/ext/bigworld_src/programming/bigworld/lib/cstdmf/md5.hpp | head -20
} > "$OUT" 2>&1
echo "written: $OUT ($(wc -l < $OUT) lines)"
