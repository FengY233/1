# worklog — 多代理共享工作日志（append-only）

> 2026-09-24 环境重置说明：原 worklog.md（Task 1–17）已随重置丢失。本文件自 Task 18 起新建；
> Task 1–17 的要点以摘要级复述保存在 findings.md（v1–v8 条目）。
> 2026-09-24 补记：Task 1–17 已依据 FengY233/test 仓库 `会话记录.txt`（253KB，5,887 行，v1→Task22
> 全程对话记录）重建为下节「历史复述」——原文件不可恢复（重置时 /tmp 与工作树同被清空，无副本），
> 重建为摘要级，任务边界为近似划分；技术细节以 findings.md v1–v8 条目 + V1–V7 交付包为准。

---
Task ID: 1–17（历史复述 · 据会话记录.txt 重建）
Agent: Super Z (main, 重置前各轮)
Task: wotreplay 样本从零到全通透（容器/加密/包流/38 包类型/时钟/交叉验证/报告 v1–v7/csi 体系/0x3D 配方）

Work Log（重建，按会话记录时间序）:
- 【资料清点与跑通】解压清点上传资料；replay_setup.py 跑通：156,482 包 / 5.2MB 载荷 / 客户端 2.4.0.0 / 地图 37_caucasus；文件头字节级解析
- 【包类型语义】定位 WGReplayController 引擎实现与 Mercury 消息 ID 注册表，逐一读取写入函数确定 0x00–0x3D 全部类型语义（38 种）；头部四件套确认（0x18=版本串、0x2D=构建串、0x30=脚本目录串、0x3D=实体定义哈希）
- 【图表与交叉验证】生成 8 张分析图表；客户端战斗日志（17:59:34 开机→18:12:53 断开）与回放解码数据逐项交叉验证；全量数据对账（行程 1140m≈mileage 1141、眩晕 192.2s、XP 1052、MVP 4452；玩家终点勘误为 (16.8, -257.0)）
- 【时钟系统两轮纠错】v1「倍速/回跳」推断被新 jsonl 检验推翻；v2 终局：clock 单位 Q20 定点（1/2²⁰ 秒）、差分阶梯精确落在 0.125x–64x 二分档位、战斗段 4x→8x→16x→32x→64x（平均 18.25x）、录制会话为独立第三会话（闲置 989s 后观看 101s）
- 【报告线 v1→v7】v1 初版报告；v2 时钟重写+三会话模型；v3 覆盖度审计量化；v4 交付包（15 文件 5.3MB）；v5 深挖 0x11（多段 zlib：[u16 100][u32 12][pickle(6677,200528740)][u32 6677][外层 zlib]，内嵌任务/储备/结算三段）/0x26（=火炮瞄准圈 gun marker，勘误 v5 前"本地车辆状态快照"）/0x08（=实体方法调用，勘误"属性更新"）；v6 收口 3 开放项；v7 终版（entities.xml 40 实体确名、0x11 校验破解、0x20=setGunReloadTime 15/15 击杀锚点命中、0x3D 定性"会话侧 entityDefs 指纹"）
- 【BigWorld 14.4.1 深挖】1.8GB vanilla 源码全挖：EntityDescriptionMap::digest() 字节级配方逐行提取（entities.xml ClientServerEntities 序 × 实体名+CS 属性[索引/名称/标志0x5F/类型]+方法）；Python 复刻跑通引擎官方 demo（6715b20b…）；LogOnParams HAS_DIGEST 登录流闭环 0x3D 生命周期；0x3D 实际值解码 = 5DF886F75E73B33CFF9D87FB9C69389C
- 【csi 体系破解（v8）】scripts.7z 到货（273 个 .def）；allocateClientServerFullIndexes = parseProperties 后按 streamSize 稳定排序（定长在前升序、变长按 varLenHeaderSize）；回放实测 11→14 锚点全部命中（1=isStrafing、16=avatarID、33=perkEffects、34=perks、13=gunAnglesPacked、14=health、15=engineMode、23=stunInfo 勘误、24=arenaUniqueID…）；40 实体 / 306 条 CS 属性权威表 csi_tables_v8.json；digest 对算未命中 → 15,552 组合暴力未命中（fork 差异，需 Ghidra vtable 槽位数据）
- 【收尾】digest_v9.py 结构 100% 从反编译提取、84 组合暴力差一细节；提出 0x05 创建块属性流 = csi 全类型验证神谕（1,833 块可对账 40 实体 csi 表）；向用户请求 BW::MD5Calculator::vftable 15 指针导出 → 用户导出后随即发生环境重置

Stage Summary:
- 重置前已达成：容器/加密/包流/38 包类型/时钟全通透 + 报告 v1–v7 正式交付 + csi 体系全解
- 交接给 Task 18 的输入：用户 Ghidra 导出的 vtable 15 指针报告 + 0x3D 目标值 + fork 差异待解

---
Task ID: 18
Agent: Super Z (main)
Task: 环境重置后恢复 0x3D 主线；核验用户从 Ghidra 导出的 BW::MD5Calculator vtable 报告并闭合槽位字节编码

Work Log:
- 发现会话环境被完全重置：upload/ 清空、/tmp 清空、findings.md/worklog.md/scripts/digest_fork.py/download/csi_tables_v8.json 全部丢失
- 核验用户导出的 vtable 数据：原始字节↔槽表 17 qword 逐一核对通过；RTTI 邻接零间隙（IMD5Calculator 15 槽 | MD5Calculator COL+15 槽 | AbstractMD5Visitor COL @0x143923130）
- 用 MSVC ABI（vptr=slot0）+ IMD5Calculator 析构写入值 0x143923038 论证 IMD5Calculator 也恰 15 槽（干净继承）
- 修正外部 AI 报告两处错误：① §3.6 对象布局差 8 字节（buf 实为 this+0x20，其"+0x10 ??"= ABCD 状态字）；② T 表索引 0/1 基混用，且 0x57cfb9ed 不在 RFC1321 T 表内（12/13 常量真且位置精确）
- 建立槽位→虚调用偏移→字节编码映射（15 槽全表）；识别 +0x18=slot3 空槽异常（钩子 no-op 假设，不贡献字节，decomp 重传后复核）；记录中无 u16 调用
- 写 scripts/md5calc_ref.py：按反编译语义实现 MD5Calculator（count/ABCD/buf 布局、RFC1321 update/final、update_u32/u16/u8/string/cstr 槽位 API），RFC1321 向量 7 + 随机分块对账 hashlib 500 + 槽位语义 6 项自测全部通过
- 重建 findings.md（v9 条目）并三处同步（root/upload/download，md5 校验）

Stage Summary:
- 0x3D 待闭合项从 2 个减为 1 个：槽位字节编码已闭合（整数小端、string 无 NUL 无前缀、cstr 含 NUL）；仅剩 DAT_1435e0950/DAT_143665890 两字符串值
- 提出三个领先假设（H1 NUL 差异 / H2 长度前缀差异 / H3 DAT 标记串）解释 vanilla 复刻与目标的偏差
- 需用户重传：decomp.zip > scripts.7z > tools/bwxml_decode.py > replay.jsonl > BigWorld tar.gz（无需 1.3GB .gbf）
- 需用户在 Ghidra 顺读：DAT 两值（数据段，伪代码导出不含）；可选 FUN_1403e8140/FUN_1403e82e0/IMD5Calculator 表
- digest_fork.py 的 MD5 层已就绪：from scripts.md5calc_ref import MD5Calculator 即用

---
Task ID: 19
Agent: Super Z (main)
Task: 资源三件套自取（scripts.7z/BigWorld-14.4.1/wot-src@2.4.0.0-cn）；核验外部 AI 的 DAT "type"/"args" 报告；0x3D 主线推进

Work Log:
- 确认 decomp.zip 本轮上传再次失败（upload/ 无文件，全盘搜无残留）；幸存文件：findings.md×3、worklog.md×2、scripts/md5calc_ref.py、download/README.md
- 自行拉取三资源到 repos/：scripts.7z（md5=3291a197… 与丢失原件一致）、BigWorld-Engine-14.4.1-HEAD（1.4GB）、wot-src@59e92351（=wot-cn 2.4.0.0 #942 sd，与回放同版本）；装 py7zr 解压
- 从 wot-src stubs/manifest.json 取得 WorldOfTanks.exe 权威 sha256=2ec886a8…（78,777,520B）供 Ghidra 二进制同一性核验
- 外部 AI DAT 报告核验：其 EXE 读取本机不可复核（无 exe）；其 decomp 引用行号待 decomp.zip 重传后对账；判定 "args"（PyObjectCommand 邻域）疑似与 digest 无关、"type" 为 PyDict 键
- 从 vanilla 源码重建 BWXML/PackedSection 解码器 scripts/bwxml.py：格式全解（含 ChildRecord type()=(this+1) 链式高位）；破解 BLOB=合法回环 Base64（"Chat"/"AccountAdmin"/"base"/"none" 实证）；2881 文件全解
- 从 vanilla 源码提取 digest 配方全链（EntityDescriptionMap::digest 编排 + 全部 addToMD5 + 字段宽度 + 解析顺序），落地 scripts/defparse.py
- 破译 csi 分配机制：parseProperties 后稳定排序（定长在前按字节升序、变长按 varLenHeaderSize 升序、同键保持声明序）
- 验证：40 实体/306 CS 属性与 v8 双吻合；Vehicle 锚点 isStrafing=1✓ avatarID=16✓ perkEffects/perks=28/29≠真值33/34（+5 缺口，数学闭合：缺 5 个先于 Perks_Vehicle 声明的变长属性）
- 归因 +5：WoT 弃用 vanilla <Components>（0 def 使用），fork 组件体系（components.xml + component_defs 127 def/181 CS 属性）运行时挂载注入；判定 0x3D（启动期计算）不受影响，0x07/0x24 csi 表受影响
- vanilla 基线 digest 实算：5CEEFA591EA23A760C64EFCF8101DD9A（≠目标 5DF886F7…，预期内）
- 重建 findings.md v10 条目并三处同步

Stage Summary:
- 主线底座就绪：vanilla 精确基线（defparse.py）+ slot 语义（v9）+ "type"/"args"（外部读）——fork delta 搜索可以开跑
- 关键阻塞：decomp.zip 两连败 → 建议用户切分上传 7 个关键 chunk 或让外部 AI 导出 FUN_142a9b640 全调用链伪代码
- 0x07/0x24 csi 表需按组件注入模型重建（待 replay.jsonl）
- scripts.7z 内容=完整服务器 scripts 树（273 def+pyc 客户端脚本+item_defs 等，192MB）

---
Task ID: 20
Agent: Super Z (main)
Task: fork-delta 参数化搜索（0x3D 收口尝试）

Work Log:
- 修复 defparse.py ARRAY/TUPLE 标签笔误（"ARRAY\0"→"Array\0"）——vanilla 基线由 5CEEFA59… 修正为 562A9B2278044E1EF6401BB7518E7701；两实现逐字节 diff 归零
- digest_search2.py：带 DT 字节缓存的扩展网格，122,880 组合/180s（1.47ms/组）全部未命中（基线自检通过）
- raw_variants.py：原始字节族 14 式（def 拼接/分隔符/解码 XML/名字表/单文件/entities.xml 等）未命中
- last_shots.py：UDO 并入族——先修双重 MD5 bug，后确认 UDO 属性走 PARSE_IGNORE_FLAGS（vanilla user_data_object_description.cpp:85）flags=0 无 CS 属性；18 式未命中
- 追查 "transform" 字串：全局 grep 证明为字符串池邻居（chunk/decal/camera 通用），与 digest 无语义关联，弃线
- 确认动态组件为逐实例（client cgf_script/entity_dyn_components.py：onDynamicComponentCreated→networkID/game_object）→ +5 csi 空间是逐实例的，不可能进静态 per-type digest → 主线（0x3D）用静态属性集判定成立
- 客户端 Vehicle.py 类基仅 BigWorld.Entity+BWEntitiyComponentTracker+BattleAbilitiesComponent；Avatar 的 mixin 对应 entity_defs/interfaces（非 component_defs）

Stage Summary:
- 搜索负结果登记完毕：fork 差异锁定在「喂入内容语义层」（何种数据/顺序/集合），编码层（NUL/宽度/端序/掩码）已系统性排除
- 收口阻塞项：decomp.zip（call-map）与 replay.jsonl（def-dump+组件挂载真值）——均需用户重传
- 本轮产物：scripts/{digest_search2,raw_variants,last_shots}.py；vanilla 基线 562A9B22… 可复现

---
Task ID: 21
Agent: Super Z (main)
Task: 从 FengY233/test 自取 decomp/回放/exe 等全部资源；用 decomp 闭合 0x3D 配方；整理结论并架下载功能

Work Log:
- 盘点 GitHub FengY233/test（HTML 文件列表）：dec.7z.001/002（分卷 decomp，密码 114514.1919810）、replay.jsonl.zip、wotexe.7z、bwxml_decode.py、def_dump.py、replay_setup.py、scripts.7z、wotreplay 原件
- 全部下载成功（raw.githubusercontent.com）；dec 分卷合并解压 → decomp.zip 47MB → repos/decomp/（30 chunks ~320MB + giants + index.tsv）
- wotexe.7z 解出 WorldOfTanks.exe：sha256=2ec886a8… 与 wot-src manifest 权威值逐字节一致 → Ghidra 二进制同一性闭合
- exe 直读验证 DAT 双值：0x1435E0950="type"、0x143665890="args"（邻域字符串全吻合外部 AI 报告）
- 机器码级解决 vtable 基址歧义：FUN_142a9b640 的 lea 指令解码 → vptr=0x1439230B8=slot0 首项；+0x18(slot3)/+0x20(slot4)=0x1402F7290 空函数（单 ret，COMDAT 折叠）→ v9 slot3 异常闭合：所有段标记串（properties/baseMethods/…）经 +0x18 喂给空槽，0 字节贡献
- 解出 visitor 双表：AbstractMD5Visitor@0x143923138、ClientServerTypesMD5Visitor@0x143923290（slot5=onProperty FUN_142a9b870、slot6=onMethod FUN_142a9b810、slot7=过滤+喂实体名 FUN_142a9b6c0）
- 逐函数解出 fork digest 全配方（ EntityType::init→FUN_142a9b640→FUN_142a9b5b0→FUN_142a9b410→FUN_142a93420→onProperty/onMethod→正文喂入器→DataType slot15）：
  * 属性：[csi u32][varLen 条件同 vanilla][name 无NUL][dataFlags&0x5F u32][isVolatile u8 ★增量①][类型]
  * 方法：[varLen][name][flags u8][args 类型][returnValues 类型 ★增量②=0字节][index u32]
  * 类型标签层与 vanilla 逐项一致（47 个 DataType vtable 经 RTTI COL→vftable 全链解析实测）
  * ★增量③：实体 +0x2f0 子描述（组件，FUN_142a8d480 构造 0x338B EntityDescription）的方法并入 digest（三域、exposed 索引连续）——推翻 v10「0x3D 不受组件影响」的方法维度判定（属性维度仍成立）
- "type"/"args" 判决：均为喂入器 label 参数，被 MD5Calculator 忽略（同族 name/flags/size/… 全部 0 字节）；H1/H2/H3 假设全部证伪
- fork 专属 volatile 机制：<Volatile><Properties> 子段（FUN_142a923c0 解析→prop+0xb3=1）；40 实体无一使用（唯一 GunMarkerComponent.gunMarker 在组件）→ 306 个 0x00 字节仍喂入
- MAILBOX 无影响：fork 无 MailBox 类，但 22 个 def 的 MAILBOX 用法（3 属性非 CS + 全部方法参数非 exposed）0 处进 digest；DICT/CLASS 未使用
- def 侧统计：component_defs 127 个（185 属性/3B/41C/28Cl 方法），79 个 <ofEntity> 挂载声明（Vehicle←31、Arena←16、Entity←10…）
- 实算三变体（scripts/digest_fork_test.py）：A=isVolatile 无组件 B6DFA134…；B=+ofEntity 组件 D54806FD…；C=全组件 196E8A39…；均≠目标 5DF886F7… → 剩余自由度锁定在组件挂载规则（集合/顺序/传播/目标解析）
- findings.md 更新至 v11（§7 全解 + §5 假设判决 + §6 开放项刷新）并三处同步
- 架设下载服务：scripts/serve_download.py（白名单单文件下载，无目录列举防卡顿），端口 8642

Stage Summary:
- 0x3D 配方从「黑盒搜索」转为「逐函数白盒」：唯一实质未知量 = 组件挂载规则（FUN_142a99f30 833 行待细读 + def_dump.py/replay_setup.py 待阅）
- 关键坐标与全部证据链已固化 findings.md v11 附录 D；digest_fork_test.py 为后续变体搜索基座
- 资源状态：decomp/replay.jsonl/exe/bwxml_decode.py 全部恢复且校验通过；下载服务已起

---
Task ID: 21-supplement
Agent: Super Z (main)
Task: 下载功能架设记录（补充）

Work Log:
- 直接 nohup/setsid 启动的 HTTP 服务会被沙箱跨命令回收；改用 Python 双 fork 守护进程化后跨命令存活验证通过
- 服务形态：scripts/serve_download.py，端口 8642（0.0.0.0），白名单仅 download/ 下 2 个文件（findings.md 26KB + findings_bundle.zip 46KB），无目录列举、路径穿越 404 —— 响应用户要求"不要共享可见大量文件导致卡顿"
- 平台原生通道：download/ 目录已极简化为同样 2 个文件；根/upload/download 三处 findings.md md5 一致（c4721f8f…）

Stage Summary:
- 下载通道就绪：平台 download/ 目录 + 备用 HTTP 8642 双通道；结论 v11 可取
- 按用户指令停机等下载，下一会话从 findings.md §6 开放项续作（组件挂载规则 → 重跑 digest_fork_test.py 变体）

---
Task ID: 22
Agent: Super Z (main)
Task: 纯执行轮（用户指令：不分析）：①GitHub FengY233/test 全量拉取 ②按预览网关方法架 3000 端口下载门户 ③在 V7 交付包基础上制作 V8

Work Log:
- gh_fetch.py：GitHub API 限流（403）→ 改用早前 curl 拿到的目录快照硬编码清单，raw.githubusercontent.com 全量下载 10/10 文件到 repos/gh_test/（~92MB）
- 校验：10 文件大小全部与 API 元数据一致；md5 与本地已有副本（upload/、repos/scripts.7z）逐一相同（含 scripts.7z=3291a197… 权威值）→ 资源零丢失零漂移
- 用户反馈对账：用户能从官方渠道下载 V2–V7 交付包，但 V7 包内 findings.md 只到 §6（v10 时代快照）；本地 findings.md 为 v11 全量（§0–§7+附录，26143B，md5 c4721f8f… 三处同步确认）
- 停掉 Task 21 的 8642 旧服务（pid 5477，白名单含已移除的 V7 包，防止 404）；download/ 移除 findings_bundle.zip（V7 内容，官方渠道仍可取 V2–V7 历史）
- serve_download.py 升级为网页下载门户：端口 8642→3000（平台 81 网关的代理目标）；新增 /health 健康检查、文件说明表、md5 指纹列、RFC 5987 中文文件名、--daemon 双 fork 守护化（跨工具调用存活，日志留痕 scripts/portal.log）；白名单仍= download/ 实际文件（硬约束：不暴露大量文件）
- 启动验证：3000 存活（pid 5942）；网关 81 → 门户首页 200（标题/内容匹配）；/health 经网关返回 ok
- V8 交付包制作（build_bundle_v8.py）：保持 V7 结构（findings.md + worklog.md + scripts/*.py），内容全部更新为最新 —— findings.md v11 全量（含用户缺失的 §7）、worklog.md 含本 Task、scripts/×18（V7 的 11 + 新增 datatype_vtables / digest_search / digest_search2 / raw_variants / last_shots / gh_fetch / build_bundle_v8）
- 端到端验证：经网关 81 下载 findings_bundle_v8.zip 与 findings.md，md5 与磁盘原件一致

Stage Summary:
- 三指令全部完成：GitHub 全量拉取✓（10/10 校验同源）、3000 门户通道✓（81 网关贯通+守护化）、V8 交付包✓（V7 结构+最新内容）
- download/ 最终形态：findings.md（v11 全量）+ findings_bundle_v8.zip；findings.md 三处同步（c4721f8f…）
- 0x3D 主线状态冻结在 v11（本轮零分析）；下一轮从 findings.md §6 开放项续作（组件挂载规则 FUN_142a99f30 → digest_fork_test.py 变体重跑）

---
Task ID: 23
Agent: Super Z (main)
Task: 纯执行轮：①GitHub 14 文件重拉（含 V7 包/csi 表/会话记录）②解决 repos/ 内存撑爆 ③在 V7 交付包基础上制作 V9（全部结论一个不落，对账会话记录.txt）

Work Log:
- 盘点：项目 4.7GB（repos/BigWorld 1.4G + .git 1.3G + wot-src 653M + tar 548M + decomp 356M + scripts_x 192M + gh_test 88M）→ 内存撑爆根源确认
- 清理：工作树删 repos/{BigWorld,wot-src,decomp,scripts_x,gh_test,tar×2,scripts.7z} + upload/{dec_full.7z,replay.jsonl}（全部可从 GitHub/归档重取）→ 128MB；.git 用 filter-branch 重写甩掉 repos/ 与 upload 大文件历史 + gc --prune=now → 364KB（历史保留 findings/worklog/scripts 演进）；.gitignore 增补 repos/ 与 upload 大文件 → 33 个跟踪文件
- GitHub 重拉：API 快照硬编码 14 文件（修复中文文件名 urllib.parse.quote），10/10 校验同源 + 4 个新文件（WoT回放解析交付包_v7.zip 6.2MB / csi_tables_v8.json 44KB【重置丢失的权威表原件！】/ findings.md 25KB【重置前 v8 全细节版】/ 会话记录.txt 253KB）
- 通读会话记录.txt 全文 5,887 行（v1→Task22 全程对话记录）→ 结论清单对账：V7 报告覆盖 v1-v7；缺 v8（csi 体系）与 v9-v11（0x3D 白盒）两大块 + 4 处需勘误（16.4"不可复算"/附录 D 属性确名/23=stunInfo/工作表计数）
- V9 报告：patch_report_v9.py 10 处补丁全命中——新增 §17（csi 体系：机制/14 锚点/+5 缺口归因）与 §18（0x3D 白盒：vanilla 排除/MD5Calculator 全解/fork 配方逐函数/三增量/三变体实算/挂载规则开放项）；更新 §0 速览两行、§6 0x3D 后记、§16.4 推翻注记、§16.5 增补、§11 交付清单、附录 C 增补 14 条地址坐标、附录 D 量化口径刷新 → 121,626B
- PDF：md2pdf_v9.py（TocDocTemplate+multiBuild、cascade 色板、install_font_fallback、全 Paragraph 表格、图表 Spacer 卫兵、CondPageBreak）→ 57 页；修复 code.sanitize 破坏 esc() 实体问题（chr() 构造绕过）、bullet Helvetica、封面页尺寸归一化；QA 0 错误（11 个标点警告=ReportLab CJK 已知限制）；封面复用 V7 模板 v9 化（poster_validate + cover_validate 全过，html2poster 渲染）
- xlsx：+2 表（v8csi锚点表 / v11_0x3D配方与实算，样式匹配 V7）→ 17 表，validate 0 issues
- JSON：+csi_tables_v8 +fork_digest_v11 两段（20 顶层键）；审计 → 覆盖度终审_v9_audit.json（v5 数字 + v8/v11 修订）
- findings.md → v12：资产恢复终态（csi 表 md5 5ac32922… 寻回）+ §8 交付包沿革；三处同步（a11fdf3f…）
- 打包：WoT回放解析交付包_v9.zip（18 文件 = V7 的 16 + findings.md + csi_tables_v8.json，6.1MB，md5 bad6f1bc…）
- 门户：修复中文文件名 404 bug（路径未 unquote——浏览器必编码）；DESCR 更新为 V9；81 网关端到端下载验证 MD5 一致
- download/ 最终形态：V9 包 + findings.md（移除已过时的 findings_bundle_v8.zip）

Stage Summary:
- 三指令完成：14 文件重拉✓、内存问题根治（4.7G→128MB + .git 364KB + gitignore 防复发）✓、V9 交付包✓
- V9 = V7 结构 + 全部结论：报告 18 章（+§17/§18）、xlsx 17 表、JSON 20 段、csi 权威表、findings v12——会话记录.txt 逐行对账无遗漏
- 门户双通（平台 download/ + 3000 端口网关），中文文件名下载已修复
- 0x3D 主线状态：findings §6 开放项（组件挂载规则 FUN_142a99f30）待下轮续作；分析资源已清理，需要时从 repos/gh_test 重解压

---
Task ID: 24
Agent: Super Z (main)
Task: ①根治内存撑爆（资源移到用户不可见区）②恢复 worklog（据会话记录.txt 重建 Task 1-17）③主线攻坚 0x3D 组件挂载规则 ④制作最新交付包（含 worklog.md）

Work Log:
- 内存根治：md5 校验后把可见区 repos/gh_test(95M) 整体移入 /tmp/wot/gh_test；upload/ 清除 5 个大文件（dec.7z×2/wotexe.7z/replay.jsonl.zip/replay.wotreplay，均与隐藏区副本逐字节一致）；.git 保持 208KB；可见区从 4.7G 降到 29M（skills 61M 为系统）。隐藏区：/tmp/wot/gh_test（14 文件）+ /tmp/my-project/repos（3.2G root 只读：decomp/scripts_x/wot-src/BigWorld）
- worklog 恢复：原文件随重置丢失不可恢复；据 会话记录.txt（5887 行）重建 Task 1-17 摘要级复述（历史时间线：资料清点→38 包类型→图表→交叉验证→时钟两轮纠错→报告 v1-v7→BigWorld 配方→csi 体系→digest_v9 收尾），补记说明已写入文件头
- 主线攻坚（FUN_142a99f30 833 行全读 + 全调用链白盒）：
  * FUN_142a98830 = EntityDescriptionMap::parse 全编排：spaces→挂载索引→ClientServer→扩展→ServerOnly→旧格式兼容→DynamicComponents→扩展
  * FUN_142a971a0 = createEntityTypeToComponentSectionsMap：multimap<实体名,{组件名,section}>，静态边仅来自 components.xml StaticComponents(16) 的 ofEntity；等值键追加序（FUN_142a94570 右子树）
  * FUN_142a900a0 = parseFromSectionList：pairs[0]=主def（Parent→FUN_142a90f20→FUN_142a8ff40 递归同记录）；pairs[1+]=组件→FUN_142a8d480 建 0x338 子描述(type=6)压 +0x2f0
  * decider 三表 RTTI 反查（COL 用 32 位 RVA——修正 v9-v11 盲区）：Entity=side flag（40 实体全 isClientType=1）、Dynamic=scripts/client/<名>.py(c|o|d) 存在性、Space=FUN_140355960(b0 01 c3 恒真)
  * records 真相 = [GeneralSpaceData(spaces.xml 唯一子节点,3 个 Exposed CS 属性)] + 40 实体 + 107 dyncomp(110 唯一-DynamicComponents 有 3 重名被 FNV 去重-3 无脚本) = 148 条
  * 实际挂载边：Account←2/Avatar←1/TeamInfo←2/Vehicle←1（Arena←10 条因 Arena 非 ClientServer 实体而无效）
  * ★fork 增量④：client 方法全部出局——onMethod(FUN_142a9b810) 的 (flags&0xC)!=0 通用过滤 + client 方法禁带 Exposed(报错路径) + 域位 CLIENT=0 → flags 恒 0；方法 varLen 永不喂入；returnValues 5 个 Base 方法全无 Exposed=0 字节
  * ★★fork 增量⑤（本轮最大发现）：FIXED_DICT 的 AllowNone 不再使 streamSize=-1（vanilla fixed_dict_data_type.cpp:441 被 fork 改掉）——DOT_EFFECT=14/BUFF_EFFECT=24/REMOTE_CAMERA_DATA=22/OWN_VEHICLE_POSITION=32/INSPIRED_EFFECT=36 实证；**推翻 v8「+5 缺口=组件属性注入」归因**（实为 6 个 AllowNone 字典移入定长区的排序位移）；修复 defparse 后 40/40 实体 csi+streamSize+flags 全对账
  * 方法属性新语义：AllowUnsafeData(方法)=0x10 位（11 处全在 client→无效）；HasReliableRetry/IsImmediate/IgnoreIfNoClient/version/scope/ReplayExposureLevel 均不进 digest；space 属性 param_5=1（跳 Flags+启用 <Exposed>→OWN_CLIENT 规则）
  * 实算：digest_fork_v2.py 完整模型（148 记录/489 CS 属性/isVolatile=1 仅 gunMarker/134 方法）→ E2E9EBE2…≠；digest_fork_diag.py 24 组合矩阵 + 内联第 25 组合（client 方法原始 flags）全负
  * 未命中收口：记录集/喂入格式/属性层全部白盒验证完毕，剩余嫌疑锁定方法层合并细节（methodID 是排序+range 空间无法直接验证）、dyncomp 内容细节、DT 层未知增量
- def_dump.py/replay_setup.py 已阅（客户端 scripts.pkg 工具+回放解包器，无 digest 真值；证实 scripts.7z=客户端树）

Stage Summary:
- 0x3D 主线从「挂载规则黑盒」推进到「全架构白盒+属性层全对账」：六轮白盒（parse 编排/挂载索引/记录构造/decider/方法语义/类型尺寸）+ 两大 fork 增量新发现（client 方法出局、FIXED_DICT 定长化）
- csi 体系彻底闭合：40/40 三要素对账（历史 +5 缺口根因改写）
- 交付：findings.md v13（+§9 全架构+附录 E）、defparse.py 修复、digest_fork_v2/diag 脚本、worklog 重建
- 下一轮建议：0x05 创建块做 dyncomp csi 对账 / FUN_142aa7c30 子描述索引机制精读 / 47 张 DataType vtable 的 addToMD5 逐字节复核
- 交付包 V10 制作与投递：报告追加 §19（v13 增补：挂载规则全解/records 真相/增量④⑤/csi 终闭合/实算现状）→ md2pdf_v9.py 重生成正文 + 封面 v10 化（html2poster）+ merge_final_v9.py 合并 = 58 页 A4 归一 PDF（§19 在位验证✓）；README v10 化（+worklog/scripts 条目）
- V10 = 22 文件 6.2MB（md5 b2eb8841d7d9993d98fd82f28d1876f5）：V9 全套 + worklog.md（用户指令）+ findings v13 + scripts/（digest_fork_v2/diag/defparse修复版/bwxml）+ 报告 v10
- 门户 DESCR 更新（v10 最新/v9 保留/findings v13），重启守护进程，网关 81 端到端下载 V10 md5 一致✓；暂存区已清理，可见区终检 29M
- 终版：V10 重建纳入完整 worklog（含投递记录），md5=21ae42b432f37aef2de483c764186f26（22 文件/6.2MB），网关 81 端到端复验一致；本行为打包后补记（包内 worklog 止于上行，此行仅存根）

---
Task ID: 25
Agent: Super Z (main)
Task: 继续攻克 0x3D：§6 开放项三路攻坚（方法层合并细节 / dyncomp 内容 / DT 层 47 vtable 复核）

Work Log:
- 环境恢复：/tmp/my-project/repos（decomp/scripts_x/wot-src/BigWorld）与 /tmp/wot/gh_test 全部可读；replay.jsonl 解压就位（156,482 行）
- 方法层终解：重读 walker FUN_142a93420 全函数——onMethod 的 index=walker 第三参计数器（非方法对象字段）；client 域计数器无条件++但全被 onMethod 的 (flags&0xC) 过滤；base/cell 域计数器仅对通过者递增 → index=域内 exposed 连续编号（自有在前组件接续）——与 digest_fork_v2 模型一致，方法层嫌疑排除
- DT 层终解：24 个 addToMD5 feeder 全量导出重审 + exe 直读 DAT 常量（新脚本 dat_strings2.py）："Int"/"Uint"/"Blob"/"User" 均经 slot13 含 NUL 喂入、"name"/"size" 为 0 字节 label——与 defparse 逐字节一致；FixedDict 自定义类/USER 类型全树 0 个 → 模块/实例恒 0 字节；DT 层嫌疑排除
- 全链字节级复核（全部与模型一致）：ExposedForReplay=bit8(0x100) 但全树 32 处扫描 29 处本带 client 位+3 处 space（0x100 在 0x5F 外）→ 零影响；parseProperties 全读（param_5/EDITOR_ONLY 跳过/同名覆盖保留 csi/空 Exposed→0x4 仅 space）；DataDescription::parse 的 isForClient=(flags&0x106)!=0 与 vanilla data_description.cpp:320 逐字一致；parseMethods 域分支（type7 禁 BaseMethods）；空 <Exposed/>→0xC；FUN_142a99f30 迭代序=首遇序+equal_range 仅 mode==1；ReturnValues 恰 5 个全非 exposed；6 个静态挂载组件全扁平；space 无方法段
- ★本轮最大发现——FeatureExtension 体系（§6 剩余嫌疑 (b) 的真身）：
  * wot-src 镜像 sources/res/ 下存在 18 个扩展目录（extension.xml 全部 IsEnabled=true）；v13 的「干净安装=空树」判断被推翻（当时只搜了 scripts 树）
  * paths.xml 列出 18 个对应扩展 pkg（type=sandbox,sd,hd；0x30 包证实客户端为 sd → 全挂载）；pkg 顺序恰为字母序
  * decomp 全解三消费点：挂载索引 Part b（<ext>/scripts/component_defs/<Static>.def，".def"=0x6665642e 直写实锤）+ 扩展循环#1（根 "Entities"→FUN_142a996e0，dir=<ext>）+ 扩展循环#2（根 "Components"→"DynamicComponents"→mode=7）；def 路径构造 FUN_142a8e790 全 mode 支持 <dir>/scripts/<子目录> 前缀；decider 脚本检查同带 dir
  * FeatureExtensionMap::parse（FUN_142a7fbb0）：枚举 FileSystem 根目录→查 <dir>/extension.xml→IsEnabled 过滤（false 跳过）→收集 StaticComponents 名单
  * def 加载失败语义：批次中止返回 false 但总流程继续（digest 仍算）
  * 规模：39 static 挂载边 + 171 dynamic + 10 CS 实体 → records 实为 ~318 条（v13 模型仅 148 条）——25 组合消融矩阵从未触及此维度，完全解释全负
  * 自洽性：0x05 创建块 n≤40 无矛盾（本场无扩展实体创建）；csi per-record 不受影响；server_side_replay 启用与 SERVER_REPLAY 回放模式吻合
- 阻塞确认：扩展 def 不在任何现有资源（scripts.7z=主 scripts.pkg；wot-src 镜像剥除全部 .def 二进制）——需用户从客户端 res/packages/ 的 18 个扩展 pkg 提取
- 产出：scripts/{dat_strings2.py, ext_inventory.py}（后者产出 download/ext_inventory.json）、findings.md v14（§10 + §6 改写 + 附录 F）、门户 DESCR 更新重启（4 文件）

Stage Summary:
- 0x3D 差异收敛到唯一自由度：FeatureExtension 扩展记录内容（39 static + ≤171 dyncomp + 10 CS 实体，顺序待定）
- 主链路（148 记录模型）已 100% 字节级白盒对账——digest_fork_v2.py 无已知偏差
- 下一步：用户提供 18 个扩展 pkg 的 scripts/{entity_defs,component_defs}（含 interfaces）+ client 清单 → 扩展模型重算 digest（顺序假设：pkg/字母序优先，未命中再枚举）

---
Task ID: 26
Agent: Super Z (main)
Task: 制作 V11 交付包（用户指令：先把本轮调查打包，用户同步去提取 18 个扩展 pkg）

Work Log:
- 盘点：V10 包 22 文件结构、findings.md v14 三处同步（9835dd3b…）、本轮新产出 ext_inventory.json（download/）与 scripts/{dat_strings2.py, ext_inventory.py}
- 报告 v11 增补（scripts/patch_report_v11.py，10 锚点全命中 + scripts/append_s20_v11.py）：
  * 头部版本行 v9 定稿→v11 定稿（§17–§20 全列）；§0 速览 +FeatureExtension 行（records ~318/25 组合全负解释/唯一剩余自由度）
  * §11 交付清单刷新（xlsx 19 表、ext_inventory.json、findings v14、脚本集 v8–v14）
  * §19.4 尾部 +v11 后记（三类嫌疑已清算，真缺失=扩展记录维度）；附录 C +v11 坐标表（FUN_142a7fae0/142a7fbb0/142a996e0/142a994c0/142a8e790/0x6665642e/两根段名）
  * 附录 D +v11 版增补（0x3D 剩余未知量再定位）+ 修复历史重复文本（v9 补丁曾致一段 v6 终局语句双写）
  * 文末追加 §20（6 小节：体系结构/三消费点全序/扩展清单 18 行表/全链字节级复核/自洽性/阻塞与下一步，6,035 字）
- PDF 链：md2pdf_v9.py 重生成正文；封面 v11 化（副标题+脚标 V11，poster_validate PASS + cover_validate 0 overlap）→ html2poster → merge_final_v9.py 合并 = 63 页 A4（V10 为 58 页）；pdf_qa WARN 12 条（全部为 ReportLab CJK 标点换行已知限制+封面设计性不对称，与 V9/V10 同 profile，无 FAIL）；§20/v11 版增补/19 工作表等关键词 pymupdf 全文验证在位
- xlsx（scripts/update_xlsx_v11.py）：+2 表（v14扩展清单=18 行数据表 + 合计行；v14全链复核=11 行键值表），样式匹配既有表（表头 645B42 填充/Calibri 11/wrap）；validate 0 issues → 19 表
- JSON（scripts/update_data_v11.py）：解码 JSON +feature_extension_v14 段（21 顶层键，meta→v11）；审计 JSON +v14_revisions（三嫌疑清算+覆盖度口径不变）
- README v11 化：标题/清单表/新增「v11 增补内容」节（6 行攻坚表）

Stage Summary:
- V11 = V10 结构 + Task 25 全部成果：报告 §20（20 章 63 页）、xlsx 19 表、JSON 21 段、ext_inventory.json、findings v14、scripts +2（dat_strings2/ext_inventory）
- 0x3D 主线状态：唯一剩余自由度 = 扩展 def 内容；等用户提取 18 个扩展 pkg 的 scripts 树后 digest_fork_v2.py 扩展模型重算
- （打包投递记录见下方补记行）
