# WoT 回放完全解析 — 交付物清单 (v11 定稿)

输入: `20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay` + 两份会话日志
(`session_20260911_175934.jsonl` 真实战斗实时记录（=本回放的录制会话）/ `session_20260923_140427.jsonl` 本回放的 1x 播放会话)
+ `replay.jsonl` 播放时捕获的逐包解码记录 (v6, 156,482 行, 第三方工具)
+ `replay_setup.py` / `decomp.zip` / `wot_src.7z` 三份资料
+ **v8 起补充**：`scripts.7z`（服务器脚本全量：entity_defs 273 个 .def）、`BigWorld-Engine-14.4.1`（vanilla 引擎源码）、`WorldOfTanks.exe`（sha256 与 manifest 权威值一致）。

| 文件 | 说明 |
|---|---|
| `WoT回放完全解析报告.md` | 主报告 (**v11**, 20 章 + 4 附录)。§17 csi 体系；§18 0x3D 白盒配方；§19 parse 全架构白盒；**§20 v11 增补：FeatureExtension 体系——records 真相 ~318 条与唯一剩余自由度（findings v14）** |
| `WoT回放完全解析报告.pdf` | 同内容精排版, **63 页**, 封面 + 自动目录 |
| `charts/01-08_*.png` | 8 张图表。04=时钟 float32 证明与全程 1x 实时, 06=三方数据生命周期, 07=clock→游戏时间 1:1 线性, 08=瞄准圈轨迹(v6 新增) |
| `WoT回放解析数据包_20260911_caucasus.xlsx` | **19 工作表** (v9 增 "v8csi锚点表" + "v11_0x3D配方与实算"；v11 增 "v14扩展清单" + "v14全链复核") |
| `WoT回放解码数据_20260911_caucasus.json` | 全量解码数据 (v9 增 `csi_tables_v8` + `fork_digest_v11` 段；v11 增 `feature_extension_v14` 段) |
| `ext_inventory.json` | **v11 新增**：18 个 FeatureExtension 的 static/dynamic/实体名单 + IsEnabled + pkg 顺序（scripts/ext_inventory.py 产出） |
| `csi_tables_v8.json` | **v9 新增**：0x07/0x24 属性号权威表（40 实体 / 306 条 CS 属性 / 14 锚点验证） |
| `findings.md` | 结论登记册 **v14**（v1–v14 逐条可溯 + §9 parse 全架构 + §10 FeatureExtension + 证据存根 + 开放项） |
| `worklog.md` | **v10 新增**：多代理工作日志（Task 1–17 据会话记录重建 + Task 18–26 全程实录） |
| `scripts/` | **v10 新增，v11 扩充**：0x3D 实算基座（digest_fork_v2.py 完整模型 + digest_fork_diag.py 消融矩阵 + defparse.py[已修 FIXED_DICT] + bwxml.py 解码器 + dat_strings2.py DAT 常量导出 + ext_inventory.py 扩展清单提取） |
| `报告封面源文件.html` | PDF 封面 HTML 源（v11 版） |
| `覆盖度终审_v9_audit.json` | 覆盖度审计（v5 数字 + v8/v11/v14 修订；取代 v5 版） |

## v9 增补内容 (2026-09-24 定稿) — 在 V7 结构上的全结论升级

**主题：把 v7 的两个"需服务器资料"残留全部打掉**

| 攻坚项 | 结果 |
|---|---|
| **csi 属性号体系（v8）** | **破解**：0x07/0x24 属性号 = clientServer 属性索引，按 streamSize 稳定排序分配（定长在前升序、变长在后、同键保声明序）。权威表 40 实体/306 条、14 锚点全中；v7 遗留的属性 **1=isStrafing / 16=avatarID / 33=perkEffects / 34=perks** 全部 .def 级确名；**勘误 23=stunInfo**（非 v5 的 damageStickers）；+5 缺口归因 fork 组件属性注入 |
| **0x3D 白盒配方（v9–v11）** | v7"本地原理上不可复算"**被推翻**：服务器 273 def + decomp 全链 → 配方逐函数闭合。`BW::MD5Calculator`=标准 MD5（15 槽 vtable）；WoT fork 重写 digest（Visitor 体系）；与 vanilla 差异=isVolatile u8 + returnValues + 组件方法并入（+0x2f0 子描述）；实算三变体 B6DFA134…/D54806FD…/196E8A39… 均≠目标 **5DF886F7…**——**唯一剩余未知量 = 组件挂载规则**（FUN_142a99f30） |

覆盖率口径：结构层 100%；语义层 A 级 99.48%（v8 后 0x07 残留清零）；B 级 0.52% 仅剩 0x32/0x37 节点名映射。

## 历史版本索引

- **v7**（2026-09-23）：无服务器资料收官——0x11 crc32 破解、0x20=setGunReloadTime、实体类型 entities.xml 确名、0x3D 定性收口
- **v6**：播放捕获交叉验证——全流零失配、尾包 MD5、0x26 瞄准圈/0x08 方法调用两项勘误、10Hz 记录主循环
- **v5**：深度语义破解——0x07 十一属性命名、0x32/0x37 语义全景、A 级 87.28%→99.48%
- **v3/v4**：时钟 float32 终局 + 覆盖度审计（C 级=0）
- **v1/v2**：容器/加密/包流/38 类型全解（v2 变速结论已于 v3 撤回）
- **v8**（过渡包，脚本集）：findings + worklog + 分析脚本（非报告形态）


## v10 增补内容 (2026-09-24 定稿)

**主题：0x3D 挂载规则全解 + csi 体系终闭合**

| 攻坚项 | 结果 |
|---|---|
| **挂载规则（§18 开放项①）** | **全解**：EntityDescriptionMap::parse 全架构白盒。挂载索引 = multimap<实体名,{组件名,def节}>，边仅来自 components.xml StaticComponents(16) 的 ofEntity；实际生效 = Account←2 / Avatar←1 / TeamInfo←2 / Vehicle←1（Arena←10 条无效）。records 真相 = GeneralSpaceData + 40 实体 + 107 动态组件 = 148 条 |
| **fork 增量④** | **client 方法全部出局**（onMethod 0xC 通用过滤 + client 禁 Exposed → flags 恒 0）；方法 varLen 永不喂入 |
| **fork 增量⑤** | **FIXED_DICT 定长化**（AllowNone 不再罚 -1）——**推翻 v9 的"+5=组件注入"归因**（实为 6 个 AllowNone 字典移入定长区）；修复后 **40/40 实体 csi+streamSize+flags 全对账**（csi 权威表即正确答案） |
| **实算** | 完整模型 148 记录 → `E2E9EBE2…` ≠ 目标；25 组合消融矩阵全负；剩余差异锁定方法层合并细节/dyncomp 内容/DT 层增量（报告 §19.4） |

覆盖度口径不变：结构层 100%；语义层 A 级 99.48%；B 级 0.52%（0x32/0x37 节点名映射）。

## v11 增补内容 (2026-09-24 定稿)

**主题：FeatureExtension 体系——digest 记录集的缺失维度（本轮最大发现）**

| 攻坚项 | 结果 |
|---|---|
| **体系发现** | 客户端 res/ 存在 **18 个全部 IsEnabled=true 的扩展**（battle_royale/frontline/last_stand…）；paths.xml 列出对应 18 个 pkg（sd 型全部挂载，顺序恰为字母序）；v13 的「干净安装=空树」判断被推翻（勘误：此前只搜了 scripts 树） |
| **三消费点白盒** | ① 挂载索引 Part b：`<ext>/scripts/component_defs/<Static>.def`（".def"=0x6665642e 直写实锤）；② 扩展循环#1：根 Entities → FUN_142a996e0（dir 前缀）；③ 扩展循环#2：DynamicComponents mode=7；路径构造 FUN_142a8e790 全 mode 支持 dir |
| **records 真相** | 记录数组 = [space 1][实体 40][扩展实体 10][dyncomp 107][扩展 dyncomp ≤171] 上界 329，11 个无 client py 的 dyncomp 为 decider 排除候选 → **实估 ~318 条**（v10 模型仅 148 条）——**完全解释 25 组合消融全负** |
| **全链字节级复核** | 方法层（index=域内 exposed 连续编号）/ DataType 层（24 feeder 逐字节一致）/ ExposedForReplay bit8 零影响 / parse 全链——全部与 digest_fork_v2 模型一致；§19.4 三类嫌疑全部排除 |
| **自洽性** | 0x05 创建块 n≤40 无矛盾；csi 40/40 不受影响；SERVER_REPLAY 模式 ↔ server_side_replay 扩展 + ReplayAccount 实体自洽 |
| **阻塞** | 扩展 def 本体不在任何现有资源——待用户从客户端 res/packages/ 的 18 个扩展 pkg 提取 scripts/{entity_defs,component_defs}（含 interfaces）+ client 清单；到货后 digest_fork_v2.py 扩展模型重算（报告 §20.6） |
