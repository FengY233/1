#!/usr/bin/env python3
"""dat_strings2.py — 直读 exe 验证 addToMD5 喂入的 DAT 字符串常量真值
喂入实体（影响 digest 字节）: DAT_143676a60(Int?) DAT_143928948(Uint?)
                             DAT_1437d083c(Blob?) DAT_1437d0d1c(User?)
标签（0 字节，核对即可）:     DAT_1435d2d24(name?) DAT_1435e92e4(size?)
"""
import struct

EXE = '/tmp/wotexe_x/WorldOfTanks.exe'

data = open(EXE, 'rb').read()
pe_off = struct.unpack_from('<I', data, 0x3C)[0]
opt_size = struct.unpack_from('<H', data, pe_off+20)[0]
image_base = struct.unpack_from('<Q', data, pe_off+24+24)[0]
nsec = struct.unpack_from('<H', data, pe_off+6)[0]
sec_off = pe_off + 24 + opt_size
sections = []
for i in range(nsec):
    b = data[sec_off + i*40 : sec_off + (i+1)*40]
    name = b[:8].rstrip(b'\x00').decode()
    vs, va, rs, ro = struct.unpack_from('<IIII', b, 8)
    sections.append((name, vs, va, rs, ro))

def read_va(va, n=48):
    rva = va - image_base
    for name, vs, sva, rs, ro in sections:
        if sva <= rva < sva + max(vs, rs):
            return data[ro + (rva - sva) : ro + (rva - sva) + n]
    return None

targets = {
    'DAT_1435d2d24 (slot13/12 label)': 0x1435D2D24,
    'DAT_143676a60 (Int?)':            0x143676A60,
    'DAT_143928948 (Uint?)':           0x143928948,
    'DAT_1437d083c (Blob?)':           0x1437D083C,
    'DAT_1437d0d1c (User?)':           0x1437D0D1C,
    'DAT_1435e92e4 (size label?)':     0x1435E92E4,
}
for label, va in targets.items():
    raw = read_va(va)
    s = raw.split(b'\x00')[0]
    nxt = raw[len(s)+1:].split(b'\x00')[0]
    print(f'{label}: "{s.decode("latin1")}" (len={len(s)})  raw={raw[:24].hex(" ")}')
    if nxt:
        print(f'    紧邻串: "{nxt.decode("latin1")}"')
