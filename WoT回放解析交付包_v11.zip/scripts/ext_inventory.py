#!/usr/bin/env python3
"""ext_inventory.py — FeatureExtension 体系清单提取（Task 25 产出）
从 wot-src 镜像的 18 个 res/<ext>/extension.xml 提取：
  - StaticComponents / DynamicComponents / Entities(ClientServer+ServerOnly) 名单
  - 扩展 client 脚本可用性（decider 判定的本地近似，pkg 到货后复核）
  - paths.xml 中的 pkg 挂载顺序（扩展列表序的第一假设）
输出 /home/z/my-project/download/ext_inventory.json + 控制台摘要
"""
import json, os, re, glob

RES = '/tmp/my-project/repos/wot-src-59e923510ff067636dd6fe3ad94725179103fc08/sources/res'
PATHS = os.path.join(os.path.dirname(RES), 'paths.xml')
OUT = '/home/z/my-project/download/ext_inventory.json'

def names(seg):
    if not seg:
        return []
    return re.findall(r'<(\w+)>', seg[0])

# paths.xml 中扩展 pkg 顺序（排除 hd 专属与地图变体）
pkg_order = []
for m in re.finditer(r'<Package type="([^"]*)">\.\/res\/packages\/(\w+)\.pkg</Package>',
                     open(PATHS, encoding='utf-8').read()):
    types, name = m.groups()
    if 'hd' in types.split(',') and 'sd' not in types.split(','):
        continue  # hd 专属，sd 客户端不挂载
    if name in ('battle_modifiers','battle_royale','comp7','comp7_core','comp7_light',
                'content_exclude','event_platform','fall_tanks','frontline','fun_random',
                'in_battle_achievements','la_pinger','last_stand','open_bundle',
                'resource_well','server_side_replay','story_mode','white_tiger'):
        if name not in pkg_order:
            pkg_order.append(name)

inv = {}
for xf in sorted(glob.glob(os.path.join(RES, '*/extension.xml'))):
    ext = os.path.basename(os.path.dirname(xf))
    data = open(xf, encoding='utf-8', errors='replace').read()
    enabled = re.search(r'<IsEnabled>(\w+)</IsEnabled>', data)
    feat = re.search(r'<FeatureName>(\w+)</FeatureName>', data)
    entry = {
        'feature': feat.group(1) if feat else ext,
        'enabled': bool(enabled and enabled.group(1).lower() == 'true'),
        'static': names(re.findall(r'<StaticComponents>(.*?)</StaticComponents>', data, re.S)),
        'dynamic': names(re.findall(r'<DynamicComponents>(.*?)</DynamicComponents>', data, re.S)),
        'cs_entities': names(re.findall(r'<ClientServerEntities>(.*?)</ClientServerEntities>', data, re.S)),
        'so_entities': names(re.findall(r'<ServerOnlyEntities>(.*?)</ServerOnlyEntities>', data, re.S)),
    }
    # client 脚本可用性（镜像 loose 树近似）
    cdir = os.path.join(RES, ext, 'scripts', 'client')
    entry['dyn_no_client_py'] = [n for n in entry['dynamic']
                                 if not os.path.exists(os.path.join(cdir, n + '.py'))]
    inv[ext] = entry

result = {
    'pkg_order': pkg_order,
    'extensions': inv,
    'totals': {
        'static': sum(len(v['static']) for v in inv.values()),
        'dynamic': sum(len(v['dynamic']) for v in inv.values()),
        'cs_entities': sum(len(v['cs_entities']) for v in inv.values()),
        'so_entities': sum(len(v['so_entities']) for v in inv.values()),
    },
}
os.makedirs(os.path.dirname(OUT), exist_ok=True)
with open(OUT, 'w', encoding='utf-8') as f:
    json.dump(result, f, ensure_ascii=False, indent=1)

print('扩展数:', len(inv), ' （全部 enabled:', all(v['enabled'] for v in inv.values()), '）')
print('合计: static=%(static)d dynamic=%(dynamic)d cs_entities=%(cs_entities)d so_entities=%(so_entities)d'
      % result['totals'])
print('pkg 顺序 (paths.xml):')
for i, e in enumerate(pkg_order):
    v = inv.get(e, {})
    print(f'  {i+1:2d}. {e:22s} static={len(v.get("static",[])):2d} dyn={len(v.get("dynamic",[])):2d} '
          f'ents={len(v.get("cs_entities",[]))}+{len(v.get("so_entities",[]))} '
          f'缺py={len(v.get("dyn_no_client_py",[]))}')
print('\n输出:', OUT)
