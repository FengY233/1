#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
bwxml.py — BigWorld PackedSection (.def / entities.xml 等 BWXML 二进制) 解码器
依据 BigWorld-Engine-14.4.1 vanilla 源码逐条实现：
  lib/resmgr/packed_section.hpp / packed_section.cpp
格式（vanilla packed_section.cpp L78-114 注释 + 实现）：
  [uint32 magic = 0x62A14E45][uint8 version = 0]
  [字符串表: NUL 结尾串序列，以一个空串（裸 NUL）终止]
  [根块]:
     int16 numChildren
     ChildRecord[numChildren]  (pack(1): int32 dataPos, int16 keyPos = 6 字节)
     int32 finalDataPos        （最后一个孩子的 endPos）
     blob                      （本节自身数据 + 各孩子数据依次拼接）
  ChildRecord[i].dataPos 高 4 位 = 「结束于 startPos 的那段数据」的类型；
  孩子数据区间 = [rec_i.startPos, rec_{i+1}.startPos)，最后一个以 finalDataPos 收尾；
  本节自身数据 = blob[0 : rec_0.startPos]，类型取 rec_0.dataPos 高位
  （源码 pRecords()[-1].endPos()/type() 通过 (this+1) 链式落到 rec_0，无越界）。
值语义：
  TYPE_STRING -> 原始字节即字符串；TYPE_BOOL -> ownDataLen>0 为真；
  TYPE_INT    -> 小端 1/2/4/8 字节（长度 0 = 0）。
类型枚举：DATA_SECTION=0 / STRING=0x1 / INT=0x2 / FLOAT=0x3 / BOOL=0x4 / BLOB=0x5 / ENC_BLOB=0x6 / ERROR=0x7（高 nibble）。
"""
import struct

MAGIC = 0x62A14E45
TYPE_DATA_SECTION = 0x00000000
TYPE_STRING = 0x10000000
TYPE_INT = 0x20000000
TYPE_FLOAT = 0x30000000
TYPE_BOOL = 0x40000000
TYPE_BLOB = 0x50000000
TYPE_ENCRYPTED_BLOB = 0x60000000
TYPE_ERROR = 0x70000000
DATA_POS_MASK = 0x0FFFFFFF
TYPE_MASK = 0xF0000000

TYPE_NAMES = {
    0x0: 'section', 0x1: 'string', 0x2: 'int', 0x3: 'float',
    0x4: 'bool', 0x5: 'blob', 0x6: 'encblob', 0x7: 'error',
}


class Section(object):
    """DataSection 等价物：name / type / data(bytes) / children(list[Section])"""

    __slots__ = ('name', 'type', 'data', 'children', '_strings')

    def __init__(self, name, typ, data, strings):
        self.name = name
        self.type = typ          # 高 nibble（0..7）
        self.data = data         # bytes，本节自身数据（孩子的块则 data=b'' 语义由 type=section 决定）
        self.children = []
        self._strings = strings

    # ---------- 值访问 ----------
    def asString(self, default=''):
        if self.type == 0x1:
            return self.data.decode('utf-8', 'replace')
        if self.type == 0x5:
            # vanilla PackedSection::asString: TYPE_BLOB -> Base64::encode
            # （打包侧 addBestGuess 把"合法回环 Base64 的值"存为解码后的字节）
            import base64 as _b64
            return _b64.b64encode(self.data).decode('ascii')
        if self.type == 0x2:
            return str(self.asInt())
        if self.type == 0x4:
            return 'true' if self.asBool() else 'false'
        if self.type == 0x0 and not self.children and len(self.data) == 0:
            return default
        # float 等在 def 解析中不会作为字符串读；按 vanilla asString 会告警并尽力转换
        return default

    def asBool(self, default=False):
        if self.type == 0x4:
            return len(self.data) > 0
        if self.type == 0x1:
            s = self.asString().strip().lower()
            if s in ('true', '1', 'yes'):
                return True
            if s in ('false', '0', 'no', ''):
                return False
        if self.type == 0x2:
            return self.asInt() != 0
        return default

    def asInt(self, default=0):
        if self.type == 0x2:
            n = len(self.data)
            if n == 0:
                return 0
            if n == 1:
                return struct.unpack('<b', self.data)[0]
            if n == 2:
                return struct.unpack('<h', self.data)[0]
            if n == 4:
                return struct.unpack('<i', self.data)[0]
            if n == 8:
                return struct.unpack('<q', self.data)[0]
        if self.type == 0x1:
            s = self.asString().strip()
            try:
                return int(s, 0)
            except ValueError:
                try:
                    return int(float(s))
                except ValueError:
                    return default
        return default

    def asFloat(self, default=0.0):
        if self.type == 0x3:
            n = len(self.data)
            if n == 4:
                return struct.unpack('<f', self.data)[0]
            if n == 8:
                return struct.unpack('<d', self.data)[0]
        if self.type == 0x2:
            return float(self.asInt())
        if self.type == 0x1:
            s = self.asString().strip()
            try:
                return float(s)
            except ValueError:
                return default
        return default

    # ---------- 子节访问 ----------
    def child(self, name):
        for c in self.children:
            if c.name == name:
                return c
        return None

    def openSection(self, name):
        c = self.child(name)
        return c

    def readString(self, name, default=''):
        c = self.child(name)
        return c.asString(default) if c is not None else default

    def readBool(self, name, default=False):
        c = self.child(name)
        return c.asBool(default) if c is not None else default

    def readInt(self, name, default=0):
        c = self.child(name)
        return c.asInt(default) if c is not None else default

    def readUInt(self, name, default=0):
        return self.readInt(name, default)

    def readFloat(self, name, default=0.0):
        c = self.child(name)
        return c.asFloat(default) if c is not None else default

    def findChild(self, name):
        return self.child(name)

    # ---------- 调试输出 ----------
    def toXML(self, indent=0):
        val = ''
        if self.type == 0x1:
            val = self.asString()
        elif self.type == 0x2:
            val = str(self.asInt())
        elif self.type == 0x4:
            val = 'true' if self.asBool() else 'false'
        elif self.type == 0x3 and self.data:
            val = repr(self.asFloat())
        elif self.type == 0x5:
            val = '<blob %d bytes>' % len(self.data)
        pad = '  ' * indent
        if self.children:
            out = ['%s<%s>' % (pad, self.name)]
            if val:
                out.append('%s  %s' % (pad, val))
            for c in self.children:
                out.append(c.toXML(indent + 1))
            out.append('%s</%s>' % (pad, self.name))
            return '\n'.join(out)
        if val:
            return '%s<%s>%s</%s>' % (pad, self.name, val, self.name)
        return '%s<%s/>' % (pad, self.name)

    def dump(self):
        return self.toXML(0)


def _parse_block(buf, off, name, strings):
    """解析一个 TYPE_DATA_SECTION 块；返回 (Section, 结束偏移)。"""
    if off + 2 > len(buf):
        raise ValueError('block header out of range at %d' % off)
    num_children = struct.unpack_from('<h', buf, off)[0]
    rec_off = off + 2
    rec_size = 6 * num_children + 4
    if rec_off + rec_size > len(buf):
        raise ValueError('records out of range at %d' % off)
    blob_off = rec_off + rec_size

    # 读取 N+1 个 dataPos（含 final）
    datapos = []
    for i in range(num_children + 1):
        datapos.append(struct.unpack_from('<i', buf, rec_off + 6 * i)[0])
    keypos = []
    for i in range(num_children):
        keypos.append(struct.unpack_from('<h', buf, rec_off + 6 * i + 4)[0])

    # 自身数据 = blob[0 : start_0]，类型取 rec_0 高位
    start0 = datapos[0] & DATA_POS_MASK if num_children >= 0 and num_children > 0 else 0
    # numChildren == 0 时：无 rec 数组，只有 final dataPos（= 自身数据长度）
    if num_children == 0:
        own_len = datapos[0] & DATA_POS_MASK
        own_type = (datapos[0] & TYPE_MASK) >> 28
        sec = Section(name, own_type, buf[blob_off:blob_off + own_len], strings)
        return sec, blob_off + own_len

    own_len = start0
    own_type = (datapos[0] & TYPE_MASK) >> 28
    sec = Section(name, own_type, buf[blob_off:blob_off + own_len], strings)

    for i in range(num_children):
        child_start = datapos[i] & DATA_POS_MASK
        child_end = datapos[i + 1] & DATA_POS_MASK      # final 或下一记录
        child_type = (datapos[i + 1] & TYPE_MASK) >> 28  # 类型在「结束字段」高位
        cname = strings[keypos[i]] if 0 <= keypos[i] < len(strings) else '?k%d' % keypos[i]
        cdata = buf[blob_off + child_start:blob_off + child_end]
        if child_type == 0x0:  # TYPE_DATA_SECTION：递归解析块
            csec, _ = _parse_block(buf, blob_off + child_start, cname, strings)
            # 叶子块自身数据已在递归里处理
            sec.children.append(csec)
        else:
            sec.children.append(Section(cname, child_type, cdata, strings))
    end = blob_off + (datapos[num_children] & DATA_POS_MASK)
    return sec, end


def decode(data, root_name='root'):
    """解码 PackedSection 文件字节流 -> Section 树。"""
    if len(data) < 5:
        raise ValueError('too short')
    magic, version = struct.unpack_from('<IB', data, 0)
    if magic != MAGIC:
        raise ValueError('bad magic 0x%08x (expect 0x%08x)' % (magic, MAGIC))
    if version != 0:
        raise ValueError('bad version %d' % version)

    # 字符串表：NUL 结尾串，空串终止
    pos = 5
    strings = []
    while pos < len(data):
        end = data.index(b'\x00', pos)
        s = data[pos:end]
        strings.append(s.decode('utf-8', 'replace'))
        pos = end + 1
        if len(strings[-1]) == 0:
            break
    else:
        raise ValueError('string table not terminated')

    sec, _ = _parse_block(data, pos, root_name, strings)
    return sec


def decode_file(path, root_name=None):
    if root_name is None:
        root_name = path.replace('\\', '/').rsplit('/', 1)[-1]
    with open(path, 'rb') as f:
        return decode(f.read(), root_name)


# ---------------- 自测 ----------------
if __name__ == '__main__':
    import sys
    paths = sys.argv[1:] or [
        '/home/z/my-project/repos/scripts_x/scripts/entities.xml',
        '/home/z/my-project/repos/scripts_x/scripts/entity_defs/Account.def',
    ]
    for p in paths:
        sec = decode_file(p)
        print('=====', p, '=====')
        print(sec.toXML(0)[:3000])
        print('... (children=%d)' % len(sec.children))
        print()
