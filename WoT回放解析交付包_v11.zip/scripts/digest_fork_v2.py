#!/usr/bin/env python3
"""digest_fork_v2.py — 0x3D 完整 fork digest 模型（v13 白盒全解实算）

模型（全部 decomp 实锤，见 findings §9）：
  EntityDescriptionMap::parse (FUN_142a98830) 编排：
    1. spaces.xml 为空（服务器树）→ 0 条 space 记录
    2. createEntityTypeToComponentSectionsMap (FUN_142a971a0)：
       components.xml <StaticComponents> 逐名载 scripts/component_defs/<N>.def
       → 其 <ofEntity> 每实体名 → multimap.insert(实体名→{组件名,section})（插入序）
       （扩展文件 ExternalComponents：干净安装无 → 空）
    3. parseEntitiesBySide(ClientServer) (FUN_142a996e0→FUN_142a99f30, mode=1)：
       40 实体（entities.xml 序），decider=EntityDescriptionHasClientScript
       slot2 = decider+0x28 = side^1 = 1 → 全部 isClientType=1
       +0x2f0 子描述 = equal_range(实体名) = 静态组件（multimap 插入序 = StaticComponents 序）
    4. ServerOnlyEntities 段不存在；FUN_142a99bc0 = 旧格式兼容（no-op）
    5. parseDynamicComponents (FUN_142a994c0, mode=7, 空索引不挂载)：
       113 动态组件（components.xml DynamicComponents 序）
       decider=DynamicComponentsDescriptionHasPythonScript
       slot2 (FUN_142a8e1f0) = Distribution/Client（无 Distribution 段）
                              = scripts/client/<N>.py|.pyc|.pyo|.pyd 存在 → isClientType
  digest 遍历 (FUN_142a9b410)：records 数组全量 0x328 步长，仅 +0x87 过滤
  每记录 (FUN_142a93420)：
    name(slot12 无NUL) → CS 属性[csi i32][varLen u32 条件][name][flags&0x5F i32]
                        [isVolatile u8 ★][类型] → 方法三域
    方法域序 client→base→cell；client 全量、base/cell 仅 exposed；
    自有在前、组件子描述在后，exposed 索引跨自有+组件连续
  组件记录解析：Parent 链（component_defs 内）+ Implements（component_defs/interfaces，
    接口名在子节点值）+ <Volatile><Properties> 标记 isVolatile（GunMarkerComponent.gunMarker=0x01）
"""
import sys, os
sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file
from defparse import (EntityDefParser, EntityDescription, MD5,
                      COMP_BASE, COMP_CELL, COMP_CLIENT,
                      DATA_DISTRIBUTION_FLAGS)

SCRIPTS = '/tmp/my-project/repos/scripts_x/scripts'
CD = os.path.join(SCRIPTS, 'component_defs')
SD = os.path.join(SCRIPTS, 'space_defs')
CLI = os.path.join(SCRIPTS, 'client')
TARGET = '5DF886F75E73B33CFF9D87FB9C69389C'

DATA_PERSISTENT = 0x10
DATA_ID = 0x20


def has_client_script(name):
    """FUN_142a8e660: scripts/client/<name> + .py/.pyc/.pyo/.pyd 存在性"""
    for e in ('.py', '.pyc', '.pyo', '.pyd'):
        if os.path.exists(os.path.join(CLI, name + e)):
            return True
    return os.path.exists(os.path.join(CLI, name, '__init__.py'))


# ---------------- 组件记录解析（顶层记录：属性+方法全进） ----------------
def parse_comp_record(parser, name, _cache):
    if name in _cache:
        return _cache[name]
    ed = EntityDescription(name)
    ed.client_name = name
    _parse_comp_def(parser, ed, name, _cache)
    _cache[name] = ed
    return ed


def _parse_comp_def(parser, ed, name, _cache):
    """Parent 链先解析（fork: FUN_142a90f20 在 map 名索引中解析父记录）"""
    sec = decode_file(os.path.join(CD, name + '.def'), name + '.def')
    parent = sec.readString('Parent')
    if parent:
        _parse_comp_def(parser, ed, parent, _cache)
    ed.name = name
    ed.client_name = name
    _comp_parse_interface(parser, ed, sec, name)


def _comp_parse_interface(parser, ed, sec, iname):
    """组件版 parseInterface：Implements(component_defs/interfaces, 接口名在值)
    → Properties → Methods → Volatile 标记"""
    impl = sec.child('Implements')
    if impl is not None:
        for c in impl.children:
            iname2 = c.asString()
            isec = decode_file(os.path.join(CD, 'interfaces', iname2 + '.def'),
                               iname2 + '.def')
            _comp_parse_interface(parser, ed, isec, iname2)
    props = sec.child('Properties')
    if props is not None:
        parser._parse_properties(ed, props, '')
    parser._parse_methods(ed, sec, iname, '')
    vol = sec.child('Volatile')
    if vol is not None:
        vprops = vol.child('Properties')
        if vprops is not None:
            for k in vprops.children:
                for p in ed.properties:
                    if p.name == k.name:
                        p.is_volatile = 1


# ---------------- space 记录（records[0]：parseSpaces 先于实体解析） ----------------
def _space_parse_props(parser, ed, sec):
    """space 属性规则（FUN_142a91b20: param_5=(type!=2)+1=1 → bit0=跳过 Flags(dataFlags=0)，
    bit1=0 → <Exposed> 子段存在则 dataFlags|=OWN_CLIENT(0x4)）"""
    props = sec.child('Properties')
    if props is None:
        return
    from defparse import Property
    for c in props.children:
        tsec = c.child('Type')
        if tsec is None:
            continue
        dt = parser._build_type(tsec)
        flags = 0                                     # PARSE_IGNORE_FLAGS → 0
        if c.child('Exposed') is not None:
            flags |= 0x4                              # OWN_CLIENT（fork 增量）
        if c.readBool('Persistent', False):
            flags |= DATA_PERSISTENT
        if c.readBool('Identifier', False):
            flags |= DATA_ID
        vlh = 1
        v = c.child('VariableLengthHeaderSize')
        if v is not None:
            vlh = v.asInt(1)
        p = Property(c.name, flags, dt, vlh)
        key = ('', p.name)
        if key in ed.prop_map:
            idx = ed.prop_map[key]
            ed.properties[idx] = p
        else:
            p.index = len(ed.properties)
            ed.properties.append(p)
            ed.prop_map[key] = p.index
            if p.is_client_server:
                p.csi = len(ed.cs_props)
                ed.cs_props.append(p.index)
    ed.allocate_csi()


def parse_space_record(parser):
    """records[0] = GeneralSpaceData（spaces.xml 唯一子节点；mode=2 → space_defs/
    decider=SpaceDescriptionHasPythonScript slot2 恒真 → isClientType=1）"""
    ed = EntityDescription('GeneralSpaceData')
    ed.client_name = 'GeneralSpaceData'
    sec = decode_file(os.path.join(SD, 'GeneralSpaceData.def'), 'GeneralSpaceData.def')
    # parseInterface 序：Implements（space_defs/interfaces，接口名在值）→ Properties → Methods
    impl = sec.child('Implements')
    if impl is not None:
        for k in impl.children:
            iname = k.asString()
            isec = decode_file(os.path.join(SD, 'interfaces', iname + '.def'), iname + '.def')
            _space_parse_props(parser, ed, isec)
    _space_parse_props(parser, ed, sec)
    return ed


# ---------------- 静态组件（子描述：方法 only） ----------------
class SubDesc(object):
    """+0x2f0 子描述：仅方法进 digest"""
    def __init__(self, name):
        self.name = name
        self.client_methods = []
        self.base_methods = []
        self.cell_methods = []


def load_static_comp(parser, name, _cache):
    if name in _cache:
        return _cache[name]
    sec = decode_file(os.path.join(CD, name + '.def'), name + '.def')
    sd = SubDesc(name)
    for dom_name, attr in (('BaseMethods', 'base_methods'),
                           ('CellMethods', 'cell_methods'),
                           ('ClientMethods', 'client_methods')):
        dom = sec.child(dom_name)
        if dom is None:
            continue
        comp_flag = {'BaseMethods': COMP_BASE, 'CellMethods': COMP_CELL,
                     'ClientMethods': COMP_CLIENT}[dom_name]
        lst = getattr(sd, attr)
        for m in dom.children:
            mm = parser._parse_method(m, comp_flag)
            lst.append(mm)
    _cache[name] = sd
    return sd


# ---------------- fork 版喂入 ----------------
DOM_ATTR = {'client': 'client_methods', 'base': 'base_methods', 'cell': 'cell_methods'}


def fork_add_to_md5(ed, md5):
    md5.append(ed.name.encode('utf-8'))
    for p in ed.properties:
        if not p.is_client_server:
            continue
        md5.append_int32(p.csi)
        ss = p.stream_size()
        if ss < 0 and p.var_len_header != 1:
            md5.append_uint32(p.var_len_header)
        md5.append(p.name.encode('utf-8'))
        md5.append_int32(p.flags & DATA_DISTRIBUTION_FLAGS)
        md5.append_uint8(getattr(p, 'is_volatile', 0))   # ★fork 增量①（含 gunMarker=0x01）
        p.dt.add_to_md5(md5)
    # 三域：fork 的 onMethod 过滤 (flags&0xC)!=0 对全部域通用；
    # client 方法 flags=域位=0（Exposed 被禁止）→ 全部不喂；base/cell 仅 exposed；
    # 自有在前组件在后，索引连续（idx 仅对喂入方法递增，FUN_142a93420 铁证）
    for domain, own_list in (
            ('client', ed.client_methods),
            ('base', ed.base_methods),
            ('cell', ed.cell_methods)):
        count = 0
        for m in own_list:
            if domain == 'client':
                continue                          # fork: client 方法 flags=0 → 不喂
            if not m.is_exposed():
                continue
            method_to_md5(md5, m, count)
            count += 1
        for sd in getattr(ed, 'fork_components', []):
            for m in getattr(sd, DOM_ATTR[domain]):
                if domain == 'client':
                    continue
                if not m.is_exposed():
                    continue
                method_to_md5(md5, m, count)
                count += 1


def method_to_md5(md5, m, idx):
    # fork: isForClient_=(domain==CLIENT)，而 client 方法已被 (flags&0xC) 过滤
    # → 方法永无 varLen 前缀；此处保留判定以备万一
    if m.is_for_client:
        if m.var_len_header != 1 and m._stream_size < 0:
            md5.append_uint32(m.var_len_header)
    md5.append(m.name.encode('utf-8'))
    md5.append_uint8(m.flags)
    for a in m.args:
        a.add_to_md5(md5)
    # returnValues：5 个 Base 方法有但全部无 Exposed → 0 字节
    md5.append_int32(idx)


# ---------------- 主流程 ----------------
def main():
    parser = EntityDefParser(SCRIPTS)
    parser.load()

    comps_root = decode_file(os.path.join(SCRIPTS, 'components.xml'), 'components.xml')
    static_list = [k.name for k in comps_root.child('StaticComponents').children]
    dyn_list = [k.name for k in comps_root.child('DynamicComponents').children]
    print(f'StaticComponents: {len(static_list)}  DynamicComponents: {len(dyn_list)}')

    # 挂载索引（StaticComponents 序 = multimap 插入序）
    mounts = {}
    for cname in static_list:
        sec = decode_file(os.path.join(CD, cname + '.def'), cname + '.def')
        ofe = sec.child('ofEntity')
        if ofe is not None:
            for k in ofe.children:
                mounts.setdefault(k.name, []).append(cname)
    print('挂载边: ' + ', '.join(f'{k}←{v}' for k, v in sorted(mounts.items())))

    sub_cache, rec_cache = {}, {}

    # 记录集：spaces 先于实体解析（FUN_142a98830 编排序）
    records = [parse_space_record(parser)]         # records[0] = GeneralSpaceData
    for ed in parser.entities:                     # 40 ClientServer 实体（entities.xml 序）
        ed.fork_components = [load_static_comp(parser, c, sub_cache)
                              for c in mounts.get(ed.name, [])]
        records.append(ed)
    skipped = []
    seen = set()
    for name in dyn_list:                         # 动态组件（DynamicComponents 序，FNV 名字去重）
        if name in seen:
            continue
        seen.add(name)
        if not has_client_script(name):
            skipped.append(name)
            continue
        ed = parse_comp_record(parser, name, rec_cache)
        ed.fork_components = []
        records.append(ed)
    print(f'records = 1 space + {len(parser.entities)} 实体 + {len(dyn_list)-len(skipped)} 动态组件 '
          f'= {len(records)}（排除: {skipped}）')

    # 统计
    n_cs, n_vol = 0, 0
    for ed in records:
        n_cs += sum(1 for p in ed.properties if p.is_client_server)
        n_vol += sum(1 for p in ed.properties
                     if p.is_client_server and getattr(p, 'is_volatile', 0))
    n_meth = sum(sum(1 for m in ed.base_methods if m.is_exposed())
                 + sum(1 for m in ed.cell_methods if m.is_exposed())
                 + sum(sum(1 for m in getattr(sd, 'base_methods') if m.is_exposed())
                       + sum(1 for m in getattr(sd, 'cell_methods') if m.is_exposed())
                       for sd in getattr(ed, 'fork_components', []))
                 for ed in records)
    print(f'CS 属性: {n_cs}（isVolatile=1 的 {n_vol}）  digest 方法(base/cell exposed, client 全出): {n_meth}')

    def run(tag, recs):
        md5 = MD5()
        for ed in recs:
            fork_add_to_md5(ed, md5)
        d = md5.getDigestQuote()
        hit = '★★★ 命中目标!!' if d == TARGET else '≠'
        print(f'[{tag}] {d} {hit}')
        return d

    run('完整模型: space+40实体+静态挂载+110动态组件', records)
    # 消融对照
    run('消融: space+40实体+静态挂载（无动态组件）', records[:1 + len(parser.entities)])
    ents_only = []
    for ed in parser.entities:
        ed2 = ed
        ed2.fork_components = []
        ents_only.append(ed2)
    run('消融: 仅 40 实体（无挂载无动态组件）', ents_only)


if __name__ == '__main__':
    main()
