#!/usr/bin/env python3
"""digest_fork_diag.py — 变体矩阵诊断：定位 0x3D 剩余差异维度
维度: dyncomp集{107脚本,110全,0} × space{入,出} × 静态挂载{开,关} × client方法{出,入}
"""
import sys, os
sys.path.insert(0, '/home/z/my-project/scripts')
import digest_fork_v2 as V
from defparse import MD5
from bwxml import decode_file

TARGET = V.TARGET

def build_records(dyn_mode, with_space, with_mounts):
    parser = V.EntityDefParser(V.SCRIPTS)
    parser.load()
    comps_root = decode_file(os.path.join(V.SCRIPTS, 'components.xml'), 'components.xml')
    static_list = [k.name for k in comps_root.child('StaticComponents').children]
    dyn_list = [k.name for k in comps_root.child('DynamicComponents').children]

    mounts = {}
    for cname in static_list:
        sec = decode_file(os.path.join(V.CD, cname + '.def'), cname + '.def')
        ofe = sec.child('ofEntity')
        if ofe is not None:
            for k in ofe.children:
                mounts.setdefault(k.name, []).append(cname)

    sub_cache, rec_cache = {}, {}
    records = []
    if with_space:
        records.append(V.parse_space_record(parser))
    for ed in parser.entities:
        ed.fork_components = ([V.load_static_comp(parser, c, sub_cache)
                               for c in mounts.get(ed.name, [])] if with_mounts else [])
        records.append(ed)
    seen = set()
    for name in dyn_list:
        if name in seen:
            continue
        seen.add(name)
        if dyn_mode == 'scripts' and not V.has_client_script(name):
            continue
        if dyn_mode == 'none':
            continue
        ed = V.parse_comp_record(parser, name, rec_cache)
        ed.fork_components = []
        records.append(ed)
    return records


def compute(records, client_methods_in):
    md5 = MD5()
    for ed in records:
        V.fork_add_to_md5(ed, md5) if not client_methods_in else _feed_with_client(ed, md5)
    return md5.getDigestQuote()


def _feed_with_client(ed, md5):
    """vanilla 风格: client 方法也喂（flags 含 defparse 强制 0x4）"""
    md5.append(ed.name.encode('utf-8'))
    for p in ed.properties:
        if not p.is_client_server:
            continue
        md5.append_int32(p.csi)
        ss = p.stream_size()
        if ss < 0 and p.var_len_header != 1:
            md5.append_uint32(p.var_len_header)
        md5.append(p.name.encode('utf-8'))
        md5.append_int32(p.flags & V.DATA_DISTRIBUTION_FLAGS)
        md5.append_uint8(getattr(p, 'is_volatile', 0))
        p.dt.add_to_md5(md5)
    for domain, own_list, exposed_only in (
            ('client', ed.client_methods, False),
            ('base', ed.base_methods, True),
            ('cell', ed.cell_methods, True)):
        count = 0
        for m in own_list:
            if exposed_only and not m.is_exposed():
                continue
            V.method_to_md5(md5, m, count)
            count += 1
        for sd in getattr(ed, 'fork_components', []):
            for m in getattr(sd, V.DOM_ATTR[domain]):
                if exposed_only and not m.is_exposed():
                    continue
                V.method_to_md5(md5, m, count)
                count += 1


def main():
    n = 0
    for dyn_mode in ('scripts', 'all', 'none'):
        for with_space in (True, False):
            for with_mounts in (True, False):
                records = build_records(dyn_mode, with_space, with_mounts)
                for cm_in in (False, True):
                    d = compute(records, cm_in)
                    n += 1
                    hit = ' ★★★★★ 命中!!' if d == TARGET else ''
                    print(f'dyn={dyn_mode:7s} space={int(with_space)} mounts={int(with_mounts)} '
                          f'clientMeth={int(cm_in)} → {d}{hit}')
    print(f'\n共 {n} 组合')


if __name__ == '__main__':
    main()
