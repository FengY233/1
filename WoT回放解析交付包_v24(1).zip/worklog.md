# WoT Replay 解析工作日志（全谱系 · 时序合并版）

> **合并说明**（2026-09-25 · 会话F / Task 31）：本文件由三份材料合并而成——
> ① 根目录 worklog.md（**最初环境的原始记录**：会话A Task 1-18 原文，与 upload/ 的 A 时代备份逐字节一致；其后为各恢复轮追加条目）；
> ② V12 交付包内 worklog.md（同源，截至 Task 30，缺 Task 30-补记）；
> ③ GitHub FengY233/test `会话记录.txt`（373KB / 8,389 行，commit 4567b52，最全对话记录）——用于恢复会话C 的 v15/v16 两轮过程条目并校对全谱系。
>
> **会话谱系**（时序）：会话A（Task 1-18，v1-v8 线）→〔重置1〕→ 会话B（Task 18-26 新编号，v9-v14 线，V8-V11 交付）→〔重置2〕→ 会话C（Task 19 起沿用A编号：ext_pkg 十项对账 → v15 攻坚轮 → 版本漂移终局 → v16 终局轮，原始记录随重置丢失）→〔重置3〕→ 会话D（Task 28 系列恢复轮，两阶段：首轮恢复未竟 → 28-补 GitHub 全量重建 → 门户收尾）→ 会话E（Task 29-30：v16 结论恢复 + V12 交付，即对话摘要中自称"会话D=本轮"者）→ 会话F（Task 31：本合并）。
>
> **编号说明**：各会话独立编号，存在同号异会话（Task 18/19/28 各有两个版本、Task 29 在会话C 与会话E 各一条），以分段标题消歧。会话A 段内「Task 5-7」「Task 8-11」合并块与后续逐条明细并存，系原始记录自身原貌，未作改动。会话B worklog 原含「Task 1-17 历史复述」（重置后据旧对话记录重建的摘要），因会话A 原始记录在本文件完整在位，不再重复收录。

===== 第一部分 · 会话A（原始环境 · Task 1-18 · v1-v8 线 · 2026-09-23）=====
> 本段为最初环境的原始记录原文（未经重建）。

---
Task ID: 1
Agent: main
Task: 解压清点上传资料（decomp.zip / wot_src.7z.001+002）

Work Log:
- decomp.zip (45MB) → /home/z/my-project/work/decomp/ ：WorldOfTanks.exe 的 Ghidra 全量反编译转储（180027 函数，chunks/giants/dis/index.tsv），README 说明其用途与边界
- wot_src.7z (合并 63MB) → /home/z/my-project/work/wot_src/ ：wotstat/wot-src 国服客户端源码 dump，版本 2.4.0.0 #942 / 2.4.0.5435，含 sources/ (res/scripts 等 19248 文件、11650 .py)、sources-as3/、locales/、stubs/
- 关键源码定位：res/scripts/client/BattleReplay.py (1456行)、common/ValueReplay.py、client/ReplayEvents.py

Stage Summary:
- 资料性质确认：replay 文件 + 官方源码 dump + exe 反编译转储，三者可交叉验证
- 客户端版本：WoT 2.4.0.0 #942（国服 CN）

---
Task ID: 2-3
Agent: main
Task: 环境搭建 + 文件头字节级解析

Work Log:
- pycryptodome 3.23.0 已装；py7zr 装在 python3.13
- 编写 /home/z/my-project/scripts/wot_replay_lib.py（可复用解析库）
- 跑通 replay_setup.py：156482 包 100% 消费，5229047 载荷字节

文件级布局（实证）:
- [u32 magic=0x11343212][u32 blockCount=2]
- block[0]: len=80068 @8 → 回放头 JSON（玩家/车辆/服务器设置）
- block[1]: len=110228 @80080 → 战斗结果 JSON（list[3]: 全量结果+更新后车辆表+击杀摘要）
- gap 8 字节 @190312: 0f716c00 21ff1b00 = [u32 7106831 = zlib解压后长度✓][u32 1834785 = 有效加密流长度(主流区 1834792B 末尾 7B 为 Blowfish 填充)]
- 主流区 @190320, 1834792 B → Blowfish-ECB解密+前向异或(CBC式, IV=0) → zlib → 7106831 B 包流

块0 JSON 关键内容:
- 玩家: 巅峰荣誉v拍子 (playerID 7049414679), 车 ussr:R52_Object_261 (261工程, 火炮), team 2
- 地图: 37_caucasus 胜利之门, gameplayID=ctf, battleType=1 (随机战), 服务器 频道1, 时间 11.09.2026 18:01:05, regionCode CN, hasMods=true
- vehicles: 30 辆 (15v15), 键为 avatarSessionID (546611517~546611546)
- serverSettings: 15 键 (battle_royale_config, comp7_config, epic_config, ranked_config, spgRedesignFeatures 等)

块1 JSON 关键内容:
- common: winnerTeam=2(玩家队胜), finishReason=1, duration=612s, arenaTypeID=15, arenaCreateTime=1789120856, teamHealth {1:28360, 2:28580}, bonusCapsOverrides {"1":{"remove":["SERVER_REPLAY"]}}
- personal(253字段): damageDealt=1669, kills=1, shots=15, directHits=4, explosionHits=14, damaged=6, stunDuration=192.18s/14次, stunned=8, xp=1052, credits=83066, 存活, markOfMastery=1, achievements=[1614,1616,526]
- item[1]: 战后更新车辆表 (玩家 frags=1); item[2]: 各玩家击杀摘要

包类型普查 (156482 包):
0xA:82439(52.7%) 0x7:37105(23.7%) 0x1A:6321 0x1F:6321 0x36:6092 0x26:5107 0x1D:2824 0x1C:1985 0x32:1837 0x5:1833 0x4:1710 0x8:1265 0x37:1148 0x24:282 0x31:84 0x1B:48 0x20:37 0x35:8 0x16/0x17/0x2B/0x1E:4 0xD:3 0x2E:3 0x18/0x2D/0x30/0x3D/0x12/0x0/0x1/0x2/0xF/0x6/0x22/0x15/0x11:1 0xFFFFFFFF:1
clock 范围 0..1143158129 (末包特殊)

Stage Summary:
- 容器格式 100% 摸清，gap 两字段语义破解（解压长度 + 有效流长）
- 下一步：逐类型包字节级逆向

---
Task ID: 5-7
Agent: main
Task: 逐类型字节级逆向 + pickle 解码 + 实体映射 + 战斗还原

Work Log:
- 在 decomp 定位 WGReplayMessageHandler 全部块写入函数（FUN_1405846e0 开块 + FUN_140584790 追加），提取 38 种类型的完整字段布局
- 破解 0x1F = 客户端性能包: [fps u8][ping 18bit][卡顿标志 0xFF000000]（写入代码 local_38[0] = param_3<<8 | param_2 | flag）
- 破解 0x16=arenaPeriod(1等待/2倒计时/3战斗/4结算) 0x17=阶段倒计时f32(29.94/899.95/60.0)
- BW 定制 pickle 解码器完成（_BWp.FixedDict/Array, Math.Vector2/3, SafeUnpickler 白名单实证）
- 0x31 回调解码: bw_chat2.onActionReceived(prebattlemarker/PREBATTLE_WAYPOINT/VEHICLE_MARKER_TYPE/伤害事件76) + client_vehicle_state_32/128
- 实体映射: 160 实体, 车辆=类型6×30(546611517-546611546), 玩家Avatar=546611552, 特殊实体0x2080EDE1(类型18)
- 游戏时间轴: 战斗窗口 0x36 标记 6014 个 ≈ 601.4 游戏秒(10Hz tick)
- **重大结论——时钟本质**: clock 字段 = 客户端墙钟微秒; 该文件是"服务器回放在线观看的再录制": 用户以 0.5x-64x 变倍速观看(战斗段平均≈17.4x), 证据链:
  a) 0x1A 相邻差分为精确 1638.4×2^k µs = 0.1s游戏tick/2^k倍速
  b) 15发炮弹×13.5s装填 ⇒ 战斗必须≥200s, 排除 35s/67s 解释
  c) results duration=612s + 0x36 tick 计数 6014(10Hz) 一致
  d) fps 97-192(快速播放渲染) + ping 24-450ms(在线流式回放) 
  e) 相机模式串 arty/strategic/arcade/prebattleHighlights = 观看时导播
  f) bonusCapsOverrides 移除 SERVER_REPLAY + 引擎 WGServerSidePlaybackImpl 存在
- 战斗还原: 完整击杀链26条(15:10), 玩家击杀 Deiiv1(t≈351s), 队伍2全歼获胜
- 生成 5 张图表: 包类型分布/战斗时间线/玩家轨迹/性能与倍速/伤害排行 → /home/z/my-project/download/charts/

Stage Summary:
- 38 种包类型全部有字段级布局, 时钟标定完成(墙钟µs+变速播放), 战斗叙事完整
- 剩余: xlsx/json 导出 + MD 报告 + PDF

---
Task ID: 8-11
Agent: main
Task: 图表/数据导出/MD报告/PDF报告 全部交付物生成

Work Log:
- 5 张图表(matplotlib, Sarasa Mono SC 中文字体, charts技能规范): 01包类型分布(对数轴) 02战斗时间线(含阵亡标记) 03玩家轨迹与车辆分布 04性能与播放速度(位域解码+倍速推断) 05伤害排行
- xlsx 数据包(7工作表: 概览/包类型普查/实体表/车辆战绩/击杀链/事件时间线/玩家轨迹), 修复 '='开头玩家名被误存公式问题, validate 通过 0 issues
- JSON 全量解码数据 4.1MB
- MD 技术报告(最详细版): 11章+4附录, 38种类型逐一布局, 时钟专题, 击杀链, 交叉验证表, 引擎函数地址对照, 未解尽边角诚实声明; 内嵌5张图表
- PDF 报告: palette.cascade 配色(暖橄榄技术色系) + TocDocTemplate 自动目录 + Template 01 HUD 封面(通过 poster_validate + cover_validate) + html2poster 渲染 + pypdf 合并
- 修复3轮质检问题: 封面 overflow/间距/徽章重叠 → 正文"0x30 目录"字样触发 toc_validate 误判(TOC关键词碰撞) → 封面页尺寸0.6pt偏差 + 行首破折号
- 最终 pdf_qa.py 全项 PASS (12页)

Stage Summary:
- 交付物: MD报告 + PDF报告 + 封面HTML源 + 5图表PNG + xlsx数据包 + json解码数据 + 11个可复跑脚本
- 全部质检通过

---
Task ID: 5 (会话日志交叉验证)
Agent: main
Task: 彻底分析 session_20260911_175934.jsonl 并与回放解码数据交叉验证

Work Log:
- 解析 7,341 事件/42 类型的客户端会话监控日志, 还原 17:59:34 启动→排队→战斗→结算→18:12:53 断开全生命周期
- 交叉验证: 名单 30/30、四阶段、击杀链 25/25 逐对一致、15 发射击、轨迹范围/里程(1140 vs 1141)全部吻合
- 修正旧报告三处错误: 击杀链实为 25 次(非26)、击杀时间全部修正(旧时间因 AoI 轨迹末点+变速双重失真)、玩家终点(16.8,-257.0)(旧值错误)
- 时间轴重建: 1,124 个轨迹锚点对齐, 发现观看者 ≥5 次回跳重看(true 104-165s 高光段)+高速丢刻(6,012/6,125 tick, 缺 11.29s), 倍速 0.55x-92x
- 源码级命名: messenger_common_chat2.py 推算 chat action ID 表(19/24/26/29/30/38/42/74/76/79); onVehicleKilled 签名核对; onVehicleDestroyed=实体销毁非死亡; onVehicleHealthChanged=AoI 限制(83% 覆盖)
- 更新交付物: MD 报告(第12章+修正9.2/9.3/9.4)、2 张新图表(06/07)、xlsx(11 工作表)、JSON(kill_chain_v2+session_log 段)、PDF(16页, QA 12 PASS)

Stage Summary:
- 会话日志与回放互证闭环, "再录制"结论从推断升级为实证
- 全部交付物已更新至 /home/z/my-project/download/

---
Task ID: 6 (v2 勘误与新 jsonl 分析)
Agent: main
Task: 用户澄清旧jsonl为真实战斗记录并提供回放对应的 session_20260923_140427.jsonl; 重新检验全部时间结论并修订交付物

Work Log:
- 新jsonl画像: 无garage/queue事件、仅1个加载里程碑 → 双击.wotreplay直入战斗的1x本地播放; bt↔ts全程1.000x零倒退; 战斗612.275s; 156射击/147命中/25击杀与实时会话逐项相同 → 回放内容=完整单遍战斗
- 旧jsonl实证: bt↔ts全程1.000x(7319样本)零倒退 → 确为实时战斗记录, 用户所述正确
- 击杀锚点法: 25个击杀在回放内以0x37载荷victim+killer的u32字节对定位(25/25命中), 与播放会话bt对齐 → clock↔游戏时间严格单调, 无任何回跳
- clock单位v2定标: Q20定点(1/2^20s, 0.1s tick=104857.6单位); 证据: 0x1A差分精确落在104857.6/2^k(=0.125x-64x完美二分速度阶梯, 旧µs解读为61.04/2^k不成档) + 锚点分段速度为精确整数(16.00x/63.9x等)
- 权威速度画像: 倒计时0.25x-4x混合(平均1.246x); 战斗 0-40s@4x → 40-100s@8x → 100-220s@16x → 220-480s@32x → 480-612s@64x, 平均18.25x(612.275游戏秒÷33.545观看秒)
- 录制会话时间轴(clock域): 闲置989.44s→观看100.8s→总在机≥1090.2s; 0x15的f64=141061.04与end_time同域, 对应bt≈23.3(timed流起点)
- 撤销v1结论: 0.55x-92x/≥5次回跳重看/丢刻11.29s内容缺失/35.17s观看 — 均为旧对齐法artifacts+µs单位误判; 0x36标记在32x/64x段覆盖率降至64-71%但内容完整(标记≠内容)
- 交付物更新: JSON(meta修正+replay_playback_session+anchor_alignment+speed_profile_v2); 图04/06/07重绘(VLM质检通过, 修复窄段标签重叠); xlsx新增"三会话对比与倍速画像"表(12表, validate 0 issues); MD报告15处补丁(§8整章重写/§12重框定/§12.4勘误/新增§13/§0速览); PDF重新生成(16页, QA通过); README更新

Stage Summary:
- v2定论: .wotreplay=独立第三会话(非两份jsonl任一)中变倍速播放观看的录制, 战斗段精确4→8→16→32→64x阶梯; 内容完整单遍, 与实时会话击杀时刻差≤0.23s
- 用户指正的方法论错误(误用实时会话作对齐基线)已确认并全量勘误; v1报告备份于scripts/report_v1_backup.md

---
Task ID: 7 (v3 终局勘误)
Agent: main
Task: 用户澄清 wotreplay 生成场景就是正常战斗; 重查源码与数据, 彻底解决时钟异常之谜并修订全部交付物

Work Log:
- BattleReplay.py 全文精读: record() 有 if self.isPlaying: return False(播放中禁录); setFpsPingLag 有 if self.isPlaying: return(播放中不写0x1F); 播放倍速档上限仅16x(1/16..16)
- decomp 深挖时钟链: FUN_1405846e0 开块时钟来自 FUN_140574370(控制器,1) → 战斗分支 (float)(FUN_140e4e1c0(conn) - 基值f64); FUN_140e4e1c0 = 包戳/频率+偏移(double秒); FUN_140e549a0 = ±5ms同步环
- 决定性发现: 播放主循环 FUN_140582480(流,i) 取包clock u32 后按 (float) 使用 —— clock 字段是 float32 秒的比特模式, 不是整数!
- 数据验证(全命中): 倒计时 p2→p3 = 30.0000s 精确; 战斗 p3→p4 = 612.495s(期望612.275); 0x1A 相邻差分 96.2% 恰为 0.100s; 25击杀锚点偏差中位+0.030s/最大0.225s; 录制起点由p3/p4两路反推 18:01:05.51/18:01:05.30 = 回放头dateTime(18:01:05); 录制终点 18:11:58.3, 会话末18:12:53前
- 伪影机理: 整数视角每tick比特增量 = 0.1×2^(23-⌊log2 t⌋), 越过2^n秒binade边界精确×2; v2的"4x→64x阶梯/平均18.25x/闲置989s/第三会话"全部是该伪影; 实测94.90%增量与公式吻合; 各档样本数∝binade时长
- v2"四条铁证"驳正: SERVER_REPLAY cap=常规配置; WGServerSidePlaybackImpl=通用能力; prebattleHighlights=实战倒计时片头巡镜(states.py); ping=真实联机遥测+0x1F守卫即实时录制铁证
- 交付物v3修订: MD报告(§0/§8整章/§12.4/§13/§10表/附录C/D/0x15注/交付清单); 图04(时钟float32证明+伪影解剖+墙钟对账)/06(录制窗与实时会话同轴对齐)/07(1:1线性)重绘; xlsx末表重写+概览修正; JSON新增clock_float32_proof段; PDF重建(18页,QA仅封面不对称警告); 交付包zip v3

Stage Summary:
- v3 定论: .wotreplay = 正常战斗的客户端 1x 实时录制, 用户描述完全属实; clock = float32秒(录制起点0.0, 源出服务器时间估计); v1/v2两代"变速"结论均为整数误读浮点比特的伪影, 已全部撤回
- 三方数据归一: ①实时会话=录制会话(录制窗嵌于其战斗段) ②回放=第一手记录 ③播放会话=1x重演; 25击杀三条时间轴逐对一致
- 方法论遗产: u32字段出现多种自洽整数单位解读时必须先排除浮点比特; 绝对锚点(30.000s/dateTime/612s)一票否决

---
Task ID: 8 (v4 覆盖度终审 + 交付重发)
Agent: main
Task: 用户问"回放文件是否研究透彻、所有内容含义都知道了吗"并报告看不到下载; 对 .wotreplay 本体做量化覆盖度审计并重新交付

Work Log:
- 编写 scripts/coverage_audit.py: 按 A(帧结构+字段+位级编码全部命名)/B(结构透彻、个别子字段未命名)/C(未知) 三级对 156,482 包全量分级
- 审计结果: A级 116,392包(74.38%)/载荷4,564,155B(87.28%); B级 40,090包(25.62%)/664,892B(12.72%), 全部集中于 0x07(37,105包)/0x32(1,837)/0x37(1,148); C级 0包0字节; 容器层 2,025,112B 100%定界、包流100%消费、JSON块100%读取
- 交付物v4修订: MD报告§0新增"理解覆盖度审计"行 + 附录D新增量化口径引言; make_pdf_body.py 边界段改为"边界与覆盖度终审"并重新生成PDF(18页, QA 12项通过); JSON新增coverage_audit_final段; xlsx概览表追加6行审计结果(validate 0 issues); README升级v4终审版
- 重建交付包 WoT回放解析交付包_v4.zip(15文件), 删除v1残留的重复图表04_性能与播放速度.png, 新增覆盖度终审_audit.json; 全部文件时间戳刷新以便平台重新同步
- scripts/coverage_audit.py 与 coverage_audit.json 保留为可复跑审计工件

Stage Summary:
- v4 终审: "彻底研究明白"的量化答复 = 结构层100%通透 + 包层A/B/C三级74.38%/25.62%/0%; 没有未知字节, 12.72%载荷字节存在位级命名残留(附录D 7条)
- 交付物: /home/z/my-project/download/ 下 9 项(含v4 zip), 全部为最新v4状态

---
Task ID: 9 (下载通道修复: 交付门户 Web 应用)
Agent: main
Task: 用户报告"下不了啊"; 平台下载面板在用户侧不显示, 需开辟可见的文件投递通道

Work Log:
- 环境探测: FC_CUSTOM_LISTEN_PORT=81 为平台网关(caddy), 显示 Z.ai 等待页=等内部 :3000 应用; 沙箱会回收普通后台进程, 双fork守护化可跨工具调用存活
- 编写 scripts/file_server.py 下载门户: 服务 download/ 全目录, 中文文件名 URL 编码, 文件清单+大小+说明+覆盖度徽章, /health 健康检查, ThreadingHTTPServer
- 守护化启动并全链路验证: 网关81首页 200 / health 200 / zip 经网关下载 5,308,084B 且 MD5 与源一致 / pdf/png 均通
- 外部预览 URL 直连探测(preview-ws-*/preview-c-*等模式)为边缘 404/410, 需经 Complete 激活平台预览链接投递
- 平台文件同步管道确认正常(/tmp/my-project/.pending_clone.json 已含 v4 全部文件), 问题仅在用户侧 UI

Stage Summary:
- 下载门户常驻 :3000(经平台网关 81 对外), 作为 Web 项目交付以激活预览链接
- 用户访问预览链接即见文件清单页, 点击即下载

---
Task ID: 10 (v4.1: 泄露审计 + upload备份 + 38/39类型澄清 + 措辞修正)
Agent: main
Task: 用户确认可下载; 要求①查泄露风险②按建议备份到 upload/ 防回退③核实 38 vs 39 类型④承认"100%消费≠完全搞明白"

Work Log:
- 泄露审计: 门户服务根=download/ 仅交付物; 无隐藏文件; 目录穿越测试(../、%2e%2e等)全部 404; .env/.git/scripts/upload/work 均不在暴露范围; 暴露内容仅用户自己的回放分析产物(含30玩家昵称/ID, 属用户自有数据)
- 备份: upload/backup_v4/ 全量交付物+11个核心脚本+worklog (16MB); upload/ 不在平台快照回退范围(.pending_clone.json 不含 upload 文件)
- 类型数精确重数: 本文件 37 种内容类型 + 0xFFFFFFFF 结束符 = 38 种; 引擎另支持 18 种本战斗未出现类型(0x03/0x0B/0x0C/0x0E/0x10/0x13/0x21/0x23/0x28/0x2C/0x2F/0x33/0x34/0x38/0x39/0x3A/0x3B/0x3C); "39种"说法无法在本地复现, 需对方提供类型清单才能逐项 diff
- 措辞修正(用户指正"不要把100%消费说成完全搞明白"): MD §0 审计行与附录D引言重写为"结构层与语义层分开口径"——结构层100%只说明没有读不动的字节; 语义层载荷字节口径 A级87.28%/B级12.72%; 明确写"不是100%搞明白全部内容"; 附录D 7条中第3/5条已闭合、第4条已解释、第6条属jsonl侧、真正开放=第1/2/7条
- PDF 同步重新生成(18页, QA 通过); README 升级 v4.1; 交付包重建 WoT回放解析交付包_v4.1.zip(15文件); 门户与备份均已同步 v4.1

Stage Summary:
- 安全: 无泄露(仅交付物暴露, 穿越全挡); 备份就位 upload/backup_v4/ (16MB, 不受快照回退影响)
- 诚实口径: 结构层100% + 语义层87.28%全解/12.72%半解; 类型数38(37内容+1结束符, 实测)

---
Task ID: 11 (v5 深度语义破解)
Agent: main
Task: 用户确认38种正确, 要求"把wotreplay文件全部内容彻底搞懂"——系统性破解v4遗留的三大B级项

Work Log:
- 方法论: jsonl会话日志(battle_tick.own真实属性值+state.onVehicleStateUpdated状态流) ↔ 回放包流双向锚定; 对齐基准 0x16 phase3 clock 34.240 ↔ jsonl bt 139.769 (偏移-105.529)
- 0x07 全部11属性号命名: 13=gunAnglesPacked(u16=yaw10b<<6|pitch6b, gun_rotation_shared.py源码公式+jsonl 69.6%逐比特相等); 14=health(114/114配对+满血反推+0xFFFD阵亡编码); 15=engineMode(87.2%逐点); 19=ownVehicleAuxPhysicsData(Ghidra FUN_142605a50位级解码: yaw15b|pitch12b|roll13b|左履带8b|右履带8b|第六值8b); 4=siegeState(共现145); 10=ownVehicleGear; 23=damageStickers; 1=移动标志(10Hz满速率对照实证); 16/33=死亡复位; 34=低频
- 0x07字节审计: 530,054B = 帧内头445,260B + 值84,794B(命名99.89%) → A级99.98%; "单调计数器"之谜告破=偏航角原地转向线性扫掠
- 0x32: 帧格式确证+字符串普查: hull/turret/gun/chassis/compositionRootSlot各×247(视觉部件CGF状态)、07DB载具表、07DF档案(acc.battlesCount/军团标签)、1578×13B开关、SequenceNetworkSync → A级79%
- 0x37: deathOrder击杀事件25条全解码(序号01-25+击杀者/被杀者ID, 击杀链第三方独立印证) + 节点变换族 → A级80.7%
- 实体行为画像: type7×122=AreaDestructibles(高)、29=AvatarInfo(高)、18=环境/天气控制器(中高,原点5Hz tick 652s)、3/28/40=脚手架/分组/UUID区域(中); 勘误"0x06类型361"实为长度字段
- 覆盖度: A级 87.28% → 99.48%(+12.20pp); 剩余B级0.52%(27,233B)=字段级命名残留; 无未知用途字节
- 交付物v5: MD报告新增§14(深度语义破解)+§0/§6/附录D更新; PDF 20页(QA通过,仅封面设计性警告); JSON新增v5_deep_semantics段; xlsx新增"v5属性与实体语义"表(13表,validate 0 issues); README v5; 交付包zip v5(15文件); upload/backup_v5/全量备份(16MB)

Stage Summary:
- v5 终版: 三大B级项全部破解至字段级命名残留; 语义覆盖率99.48%
- 关键新知识资产: 属性13/19位级公式、deathOrder击杀事件结构、实体类型行为画像法
- 37种内容类型+结束符=38种(用户确认); 解析器与审计脚本可复用于任何v2回放

---
Task ID: 12 (v6 播放捕获交叉验证)
Agent: main
Task: 用户提供播放回放时捕获的 replay.jsonl；榨取其解码知识与命名表，交叉验证全部结论并修订交付物

Work Log:
- 文件画像: 27.8MB/156,482 行逐包 JSON, 行数=包数精确相等; type+clock 全流对比零失配 → 同一包流在播放管线的消费侧再证(保真度从推断升级为实测)
- 工具命名表榨取: 0x01 handleEntityVolatile/0x02 +OnGround/0x04 handleEntityPropertyChange/0x06 handleEntityPlayerStateChange/0x07 handleEntityAoIChange/0x0D handleNRLCreate/0x16 handleRecordingOnlyEntityMethod; 与 v5 语义表逐项裁决(0x04 分歧: 载荷4B形状+击杀链25/25 支持维持 leaveAoI)
- 尾包哈希破解: 0xFFFFFFFF 的 16 字节 = MD5(block0||block1) 精确命中 d509e348a47afab6e8afe4da6137178e → 头部 JSON 完整性校验(METADATA_MISMATCH 对应)
- 0x26 勘误: v5"本地车辆状态快照"错误 → 瞄准圈(gun marker)遥测; 证据: BattleReplay.py setGunMarkerParams/setSPGGunMarkerParams + 写入器 FUN_14057f240(16+12+4+8) + 数据实证(地面慢移点中位1.7m/s/高度跟随地形-24~106m/距车中位599.6m/方位角与炮塔yaw 66%吻合/值域匹配261工程1.2km射程)
- 10Hz 记录主循环架构: FUN_14057b220 dt≥0.1s 一拍, 拍内 0x26(门控变化≥0.0004, FUN_14057ec20)→0x1A(FUN_140589070 9参无条件)→0x1F(仅ping≠-1); 一举解释 0x1A=0x1F=6321 同拍孪生/0x26=5107 静止即静默/0x1A 差分96.2%恰0.1s 三个悬案
- 0x08 勘误: "属性更新"→实体方法调用; 工具方法名表 methodID=1 setClientReady(154次)/58 updateArena(53次), 共17种方法号; mid=65 实参="37_bridge_destruction_01_scenario"(t=165.24 桥破坏剧情事件)
- 数值补正: spaceID 7149→7085(v5 十六进制笔误 0x1BAD≠0x1BED; 0x05 全部1,833包/0x0D 三包/0x0F ref/0x01 四处字节互证), 修正报告 5 处
- 握手包全解剖: 0x0F=[ref=7085][84][18][spaces/37_caucasus][4x4单位阵][1] 地图装载; 0x11=[u16 100][u32 12][pickle(6677,200528740)][u32 6677][外层zlib 6677→6666B] 内含 3 段嵌套 zlib(754→1089/1228→2185/4635→9659B: 个人储备/任务加成/结算明细); 0x0D=NRL battle space 创建; 0x20=37包2×f32 周期~26s 摆动(候选天气/阵风)
- 0x0A 位级精化: v20 三分量精确落在 n/2^20 量化格点(20位量化增量通道); v32 值域恰(-π,π]欧拉角; ref≠0 时相对坐标(Avatar 骑挂自己车); 0x32/0x37 首 u32=组件路由号(9×1578/6×378 等)
- 0x07 key 分布(1:3983/4:138/10:179/13:24083/14:114/15:6078/16:15/19:2427/23:54/33:19/34:15)与 v5 属性表逐项相等; body 覆盖 84,794B 与 v5 值区精确相等
- 交付物 v6: MD 报告新增 §15+§0 速览行+附录C 4 函数+附录D 口径更新+0x26/0x08 章节勘误重写+spaceID 5 处修正; 图 08 瞄准圈轨迹(左地图俯视渐变+右距离节奏/高度, VLM 质检 PASS); xlsx 新增 v6 播放捕获交叉验证表(14 表, validate 0 issues); JSON 新增 replay_jsonl_crosscheck_v6 段(含 4,800 点战斗段瞄准轨迹); PDF 22 页(QA 12 项通过, 仅封面设计性警告); README v6; 交付包 zip v6(15 文件); upload/backup_v6/ 全量备份(结构对齐 v5)

Stage Summary:
- v6 定论: replay.jsonl = 第三方语义仲裁者; 全流零失配 + 尾包哈希破解 + 两项定性勘误(0x26 瞄准圈/0x08 方法调用) + 10Hz 主循环架构新知
- 覆盖率口径不变(A 级 99.48%), 语义命名质量提升; 开放项: 0x3D 哈希输入/0x11 的 200528740 校验算法/0x20 确名
- 新数据资产: 4,800 点瞄准圈轨迹(玩家瞄准历史首次可回放)

---
Task ID: 13 (v7 终局攻坚)
Agent: main
Task: 用户问"三个开放项是干什么的/entity_defs 是什么/服务器端脚本 dump 肯定没有了"——解释概念并发现本地仍有未打的牌, 发起无服务器资料的最终攻坚

Work Log:
- 概念澄清: entity_defs=BigWorld 实体定义目录(.def 模板: 属性/方法/可见性); 本 dump 仅存 alias.xml(95KB 类型别名表); sources-as3=AS3 界面代码/sources-gameface=TS 界面/stubs=引擎 pyi 桩
- 重大发现: dump 内 res/scripts/entities.xml(客户端实体注册表, 40 项 ClientServerEntities)此前未被注意——1-based 编号与 7 个实测类型全表对齐: 3=ArenaInfo/6=Vehicle/7=AreaDestructibles/18=EmptyEntity/28=TeamInfo/29=AvatarInfo/40=NetworkEntity; 勘误 v5"type18=天气控制器"(实为 EmptyEntity, CGF 空载体)与"type3=脚手架"; 附录D 第7条闭合
- 0x11 校验算法破解: pickle 真值 (6677, 200229732)而非(6677,200528740)——v6 十进制转写错误; zlib.crc32(6677B 存储 blob)=0x0BEF4364=200229732 逐字节精确命中; pickletools.dis 权威解码 PROTO2/BININT2/BININT/TUPLE2/STOP; 即 BigWorld (size,crc32) 信封
- 0x20 确名 setGunReloadTime(装填计时器): 四重证据——BattleReplay.py:681 双 f32 API; ammo_ctrl.py AmmoReplayRecorder(timeLeft<0→录(0,-1)与装载期三包吻合); 反编译 FUN_140588350 写入器+FUN_1405796f0 录制分支 XOR 0x8000000080000000 符号翻转(播放分支 +0x318=now+f1); 实时会话 arena.onVehicleShot 本车 15 射击 bt 与 15 次零值复位逐对吻合(延迟 0.09-0.34s, 偏移+105.529); A 斜率精确 -1.00/s 饱和于 -B, B=26.419s=261工程装填时长; 撤销 v1"相机朝向"/v6"天气阵风"
- 0x3D 定性收口: 哈希串存 WGReplayMessageHandler+0xa8(std::string SSO), FUN_14057ffc0 流创建传入, FUN_140576380 一次性守卫(DAT_144848008)随头部四件套写出; 错误码枚举 FUN_140572a0 实证 STOPPED=0/VERSION=1/ENTITYDEF=2/METADATA=3/CORRUPTED=4; entities.xml/alias.xml 及组合 md5/sha 全未命中→会话侧 entityDefs 摘要(编译后 .def 指纹), 本地不可复算, 语义/存储/校验路径 100% 钉死
- 附带修复: PDF 脚本残留的 spaceID 7149→7085(v6 应改未改处)
- 交付物 v7: MD 报告 15 处补丁+新增§16(16.1-16.5); JSON 修正 200528740 全部 4 处+新增 final_push_v7 段; xlsx 新增"v7终局攻坚"表(15 表, validate 0 issues)+概览行; PDF 重生成 24 页(QA 12 项通过, 仅封面设计性警告); README v7; 交付包 v7 zip; upload/backup_v7 全量备份(18MB); 门户/网关 200 验证通过

Stage Summary:
- v7 定稿: v6 三开放项全部闭合(0x11 破解/0x20 确名/0x3D 定性收口)+实体类型权威确名+0x11 目标值勘误
- 38 种类型自此每一种都有确定名字与语义(0x20 是最后一个); 覆盖率口径不变(结构层 100%/A 级 99.48%/B 级 0.52%)
- 剩余开放仅两项且均需服务器 .def/CGF 资料: 0x07 属性 1/16/33/34 的 .def 级确名; 0x32/0x37 视觉节点名映射——与"服务器资料没有了"一致, v7 为终版

---
Task ID: 14 (v8 前奏: BigWorld 引擎源码挖掘)
Agent: main
Task: 用户提供 BigWorld-Engine-14.4.1 GitHub 源码 + scripts.7z(未到达); 拉取源码并榨取剩余开放项的引擎侧证据

Work Log:
- git clone 成功: work/ext/bigworld_src/ (36792 文件); scripts.7z 未出现在 upload/(管道无新文件), 需用户重传
- 定位服务器回放体系: baseapp/replay_data_file_writer + py_replay_header + cellapp/replay_data_collector + connection/replay_* (14文件)
- 重大收获①(0x3D 配方): EntityDescriptionMap::digest() 字节级算法全部提取——MD5 over 每实体(entities.xml顺序,仅client类型): name原始字节+每CS属性[int32 csi][varLen条件][name][int32 flags&0x5F][DataType配方]+client全部/base+cell exposed方法[name][u8 flags][args][int32 count]; DataType配方全表(Int/Uint+int32尺寸, Float/String/Tuple/Array/Vector/FixedDict/Class/User...含NUL终结符); Flags命名映射表(CELL_PRIVATE=0...ALL_CLIENTS=0x07); isClientServerData=OTHER|OWN|REPLAY(0x100)
- 重大收获②(0x3D 实际值): 回放 pkt#3 = [u32 32]["5DF886F75E73B33CFF9D87FB9C69389C"] = MD5::Digest::quote() 大写hex格式, 对算目标就绪
- 重大收获③(digest生命周期): LogOnParams HAS_DIGEST——客户端登录上报本地defs摘要, 服务器比对, 回放头存储+播放校验(ENTITYDEF错误码); 完整闭环
- 重大收获④(消息族全景对账): replay_data.hpp BlockType枚举(0-9) + client_interface.hpp消息表 + common_client_interface.hpp avatarUpdate家族(24变体)
  * 0x04=leaveAoI 获vanilla背书: [u32 id][EventNumber×N], 4B载荷=N=0; v5/v6裁决正确, 工具命名表handleEntityPropertyChange系误导
  * 0x05=createEntity: [压缩流][u32 id][u16 type][f32×3 pos][PackedYPR 3B][属性流]
  * 0x06=createCellPlayer: [spaceID][vehicleID][pos][xzScale][dir]+属性; 全量属性=[u8 count][u8 idx+value]×N
  * 0x07=sliceEntityProperty/0x24=nestedEntityProperty: 都作用于selectEntity选中实体(解释无eid); topLevelIndex=clientServerFullIndex=属性键
  * 0x0A=avatarUpdate*家族: PackedXYZ(X/Z各12bit+Y16bit)/PackedXZ量化+IDAlias(u8)别名+relativePosition参考体系; 解释v20量化格点+ref≠0相对坐标; WoT改用量化参数为20bit/通道(fork进化点)
  * 0x0F=spaceData精解: [u32 spaceID=7085][u32 entryID=84][u8 pathLen=18]["spaces/37_caucasus"][4×4单位阵=MappingData.matrix][u8 01]; vanilla value=path+matrix结构获证, WoT字符串改长度前缀
  * WoT消息编号已重排(vanilla spaceData=#7/WoT=0x0F), 语义骨架同源
- 工具产出: scripts/bigworld_defs_digest.py (digest算法Python复刻v2, 正确.def语法: 元素标签名/命名Flags/Exposed子元素/Arg), 在引擎自带demo entity_defs(examples/client_integration)冒烟测试通过 → 6715b20ba049e091a2a29c87b63cd9c4
- 客户端dump复核: entities.xml完整(40 ClientServerEntities, 1-based顺序与7个实测类型ID全对齐); entity_defs/仅alias.xml, .def缺失——scripts.7x是最后拼图

Stage Summary:
- 0x3D 从"定性收口"升级为"配方在手+目标值在手, 只差.def输入": 复算工具已就绪并对官方demo验证
- v5/v6的0x04=leaveAoI裁决获引擎源码背书; 0x07/0x08/0x05/0x0A/0x0F全部vanilla语义确证
- WoT fork进化点清单: 消息重编号/PackedXYZ参数(20bit通道)/字符串长度前缀
- 等scripts.7z: 含entity_defs/*.def则跑bigworld_defs_digest.py对算5DF886F75E73B33CFF9D87FB9C69389C + Vehicle.def给0x07属性1/16/33/34确名

---
Task ID: 15 (还原门户 + 大瘦身 + scripts.7z 到达)
Agent: main
Task: 用户反馈页面仍卡4G内存且影响回复速度, 要求还原下载门户; scripts.7z 已由用户放GitHub

Work Log:
- GitHub拉取 scripts.7z (22,206,492B, md5 3291a19748a129bf8e16cd5983fda4c4) 成功; BigWorld散树(36,792文件)先tar打包(440MB, 39166条目, gzip OK)再删除
- **scripts.7z 内容超预期 = WoT 服务器端 scripts 目录全量**: 12,857文件, 273个.def(entity_defs/ + component_defs/ + user_data_object_defs/ + interfaces/), 另含 cgf_names.xml(0x32/0x37视觉节点名候选!)/arena_defs/item_defs/entities.xml等; 解压至 /tmp/wot_scripts (不入同步)
- 发现 .def 为 EN 二进制格式(魔数 EN a1 62 00 + NUL分隔字符串表 + 索引引用), 非XML; Vehicle.def 字符串表178项, 已锚定属性记录区: 属性名以u16字符串索引出现, 存在 [u16 nameIdx][u32 offset] 属性索引表(health/gunAnglesPacked/engineMode/siegeState等全部命中); 发现WoT扩展Flags MY_VEHICLE 与 Implements 15接口(VehicleAIProxy/BattleFeedback等)
- 服务器 entities.xml 也是EN格式: 41条 [u32][00 10] 记录+字母序名字表; 客户端 entities.xml 为标准XML(40实体)可对照
- 根因诊断(用户页面卡4G/回复变慢): 平台同步队列积压25,364文件(attempts 15), 元凶=work/wot_src 24,929散文件 + 我加的440MB tarball
- 还原与瘦身: 终止file_server.py(双fork守护, pkill成功, :3000无服务); tarball+scripts.7z→/tmp/archive/; work/wot_src→/tmp/wot_src(原7z仍在upload作保险); 工作区63,454→1,716文件(1.6GB); upload回到210MB/155文件(用户原始资料+backup_v5/v6/v7)
- 资料新位置: /tmp/wot_scripts(服务器脚本+273 .def) /tmp/wot_src(客户端源码) /tmp/archive(bigworld tar.gz+scripts.7z原件); 均在/tmp不占同步

Stage Summary:
- scripts.7z 即"最后拼图"服务器脚本, .def为EN二进制需解码器(用户即将提供解码工具)
- 页面卡顿根因=文件数爆炸(我克隆的bigworld 3.7万文件+wot_src散文件2.5万), 已彻底还原瘦身, 门户按用户要求关闭
- EN格式初判: 字符串表+u16索引+[u16 name][u32 offset]属性表, 等解码工具到位即可全量解出→digest对算+属性确名

---
Task ID: 16 (v8 攻坚: bwxml 解码 + csi 体系破解 + fork digest 结构发现)
Agent: main
Task: 用户提供 def_dump.py + 权威版 bwxml_decode.py; 归档全部资料到 upload; 续挖 0x07 属性确名与 0x3D digest

Work Log:
- 归档到 upload/: tools/def_dump.py(用户提供), tools/bwxml_decode.py(用户权威版,替换我的复刻版; wgtk 参考已删), scripts.7z(22MB md5 3291a197), BigWorld-Engine-14.4.1_src.tar.gz(440MB), tools/file_server.py(门户)
- 权威解码器验证: Account.def 7137/7137, alias.xml 202 别名(176 FIXED_DICT, 16 序列, 零 implementedBy, 1处 WoT typo 'AlowNone'), entities.xml 40 实体(与客户端 XML 版逐项同序)
- def_dump 本地化: mini_scripts.pkg(entity_defs 104文件 65KB) + run_def_dump.py(仅改 PKG 路径), --list 102 def 全通
- 引擎源码规则链逐条考证: parse 累积序(Parent→Implements→自有; 接口不跟随 Parent), parseProperties 末尾 allocateClientServerFullIndexes ★csi=稳定排序(定长按 streamSize 升序在前,变长按 -VLH 字节在后)★, isClientServerData=flags&0x106, ExposedForReplay 缺省=isOtherClientData, DataDescription::streamSize(变长→-vlh), 方法 dedup 按名先到先得, ClientMethods 自动 setExposedToAllClients(flags_=0x04), Exposed(''→0xC/OWN_CLIENT→0x8/ALL_CLIENTS→0x4仅CELL)
- **csi 表与回放实测 11 锚点全部吻合**: Vehicle 0=burnoutLevel/1=isStrafing/4=siegeState/13=gunAnglesPacked/14=health/15=engineMode/16=avatarID(死亡复位4B零=Avatar脱离)/22=wheelsState/23=stunInfo(勘误v5"damageStickers"→STUN_INFO定长8B,54包均匀8B佐证)/24=arenaUniqueID/33=perkEffects(死亡前清空=空数组1B零)/34=perks; Avatar 10=ownVehicleGear/19=ownVehicleAuxPhysicsData — v7 遗留"0x07 属性1/16/33/34 确名"全部闭合(1=isStrafing,16=avatarID,33=perkEffects,34=perks)
- 全量产出: download/csi_tables_v8.json — 40 实体全部 CS 属性 csi 权威表(Vehicle 50/Avatar 28/FlockExotic 21/SimulatedVehicle 19...)
- digest 对算: digest_v8.py(vanilla 配方完整复刻)=EBE966BE... 不匹配; 15552 编码组合暴力(digest_fork.py)亦未命中
- **根因发现(反编译深挖)**: WoT fork 重写了 digest — 源文件 D:\BuildAgent\work\wotd_ci_release\wc\programming\shared_libs\entitydef\entity_description_digests.cpp, Visitor 体系(AbstractMD5Visitor/ClientServerTypesMD5Visitor/IMD5Calculator/MD5Calculator), vanilla 14.4.1 无此文件 → task14 的 vanilla 配方前提作废
- fork digest 结构已 ~95% 映射(反编译实证): 实体[name键+name字段]→"properties"节→每CS属性[raw i32 csi][name键][varLenHeaderSize 条件][name=]["dataDistributionFlags"=u32&0x5F][isVolatile=bool★fork扩展][类型块(key=DAT_1435e0950,name="Int"等,size=/dbLen/elementType/allowNone/fields/moduleName/instanceName)]→"clientMethods"/"baseMethods"/"cellMethods"节(接口方法后置★)→每方法[name键][varLen条件][name=]["flags"=u8]["args"节(每参数Arg键+name+类型块)]["returnValues"节★fork扩展][raw i32 count]
- MD5 原语定位: FUN_1403e8140=Init/82f0=Update/8620=transform/82e0=Final; IMD5Calculator 槽位: +0x18串/ +0x28命名u32/ +0x40命名varLen/ +0x50命名u8/ +0x58命名bool/ +0x60命名stdstr/ +0x68命名cstr/ +0x70 getState; DAT_1435d2d24="name", DAT_1435e92e4="size"
- 未能闭合: 槽位字节编码(vtable 在 .rdata, Ghidra dump 未含; 多处 "Could not recover jumptable"), DAT_1435e0950/DAT_143665890 字符串值

Stage Summary:
- 0x07 属性确名 100% 闭合(11 锚点验证), csi_tables_v8.json 为今后任意回放任意实体 0x07/0x24 解码的权威字典
- 0x3D digest: 性质判定完成(fork 重写版键值序列化), 结构 95%, 字节编码待用户提供 Ghidra 的 IMD5Calculator vtable 槽位实现(+0x18/+0x20/+0x28/+0x40/+0x50/+0x58/+0x60/+0x68)与 DAT_1435e0950/DAT_143665890 值
- v5 勘误 2 处: csi23=stunInfo(非damageStickers); csi1=isStrafing(语义与10Hz移动更新相关, 触发条件待细化)

---
Task ID: 17 (结论登记制度建立 + 关键事实全量复验)
Agent: main
Task: 用户指令"把这回的结论写到文件里, 之前调查的[BigWorld 14.4.1 四项成果]如果没问题也写到文件里; 后续确认的成果及时写文件"; 建立持久结论登记册并复验全部待收录事实

Work Log:
- 复验(写入前事实核查, 全部通过): ①0x3D 值 replay.jsonl 第4行 t=61/len=32/全流唯一; ②csi_tables_v8.json 14锚点(12 Vehicle + 2 Avatar)逐项命中, 全表 40 实体/306 条 CS 属性(Vehicle 50/Avatar 28/FlockExotic 21/SimulatedVehicle 19/Flock 15); ③digest_v8.py 复跑可复现 EBE966BE4B0DF76A9374DE0C2AC8AFF9 ≠ 目标; ④273 .def 全树计数(entity_defs 41+component_defs 127+user_data_object_defs 40+散布); ⑤cgf_names.xml 在位(1,921B, 0x32/0x37 候选材料未展开); ⑥upload/tools/ 三件工具在位, bwxml_decode.py 与用户权威版描述一致
- 建立 /home/z/my-project/findings.md(19,375B, md5 45944d77): §0 状态速览 7 项 → §1 v8 csi 体系(规则链/14锚点/勘误2处/306条权威表) → §2 BigWorld 14.4.1 对账①②③④(① 状态修订: vanilla 配方降级为基线, 实算不匹配+根因=fork 重写; ②③④ 全部有效) → §3 fork digest 结构95%(根因/结构/MD5原语与槽位/已排除/待闭合清单) → §4 v1-v7 总表(容器/38类型速查表/时钟float32定论/实体叙事/覆盖度) → §5 资产清单(upload 持久区+tmp 快区+scripts 复现入口) → §6 开放项 4 条 → 附录更新记录
- 三处同步: findings.md(主) + upload/findings.md(防回退) + download/findings.md(用户可见), md5 一致
- 登记制度写入文件头: 只收已验证结论/推测只进 worklog; 每次更新三处同步+附录留痕

Stage Summary:
- findings.md 登记册就位: v1-v8 全部已确认结论收录, 每条带证据与状态; 今后确认的成果按制度及时追加
- ①②③④ 复核结论: ②③④ 维持有效; ① 诚实降级(算法结构仍哺育了 csi 体系, 但作为 0x3D 对算配方已被 fork 根因发现推翻)
- 等用户 Ghidra 数据(IMD5Calculator 槽位字节编码 + DAT_1435e0950/DAT_143665890) → digest_fork.py 补齐后即可对算 5DF886F75E73B33CFF9D87FB9C69389C

---
Task ID: 18 (decomp 终极深挖: digest 全结构提取 + 实现 + 84 组合暴力)
Agent: main
Task: 用户问"decomp 里找不到吗？要用 1.3GB 的 db.1.gbf 吗"——先在 decomp 里把能挖的全挖掉再回答

Work Log:
- 回答前置挖掘(未动用 .gbf/exe, 全部来自现有 decomp):
  ① MD5Calculator 原语全部定位(c_1402c13f0.c 212010-212320): e81e0=cstr带NUL/e8210=stdstr无NUL/e8230=u8/e8260=u16/e8290=u32/e82c0=ctx裸Update; 穷举证明无其他 Update 调用者→begin/end 不可能哈希 name(根 begin 传 NULL)
  ② digest 全调用链通读: 入口 FUN_142a9b640(客户端 BW::EntityType::init c_1402c13f0:143725)→visitor FUN_142a9b5b0→实体迭代 FUN_142a9b410→编排 FUN_142a93420(startProperties→props→startMethods(client,base,cell 各自计数)→接口后置列表 ed+0x2f0)
  ③ 属性 digest FUN_142a894e0(裸csi→begin→[vlh]→name→flags&0x5F→isVolatile→type→end)、方法 FUN_142aa17d0(→flags u8→args节→returnValues节→end→裸idx)、args/rets 节 FUN_142abcbc0(非空才写,每元素begin+类型块+end)
  ④ 22 个类型块全部读出: Int/Uint+size, Float/Float64/String/UnicodeString/Blob/Python/UDO, Vector+维数, Array/Tuple(size+dbLen+elementType), FixedDict(条件module/instance+allowNone+fields), User(未用)
  ⑤ DAT 字符串破译: 1435e0950="type"(len4铁证), 143665890="args"(len4铁证), 143676a60="Int"(len3铁证), 143928948="Uint", 1437d083c="Blob"(BlobDataType毗邻)
  ⑥ MAILBOX 之谜: 客户端 build 无 MailboxDataType(vanilla #if MF_SERVER 条件编译, UNSUPPORTED_TYPE(MAILBOX)); 但普查证明全部 MAILBOX 成员非CS/非暴露→对 digest 无关
  ⑦ 方法 flags u8 语义补全: 组件位(&7)+Exposed(''→0xC/OWN→0x8/ALL_CLIENTS仅cell→0x4)+AllowUnsafeData→0x10(8处)+client自动|=0x4; ReplayExposureLevel→独立字段不进flags
  ⑧ 属性 parse 补读: Persistent→0x20 但 0x5F 掩码不含 0x20(虚惊); Backupable→0x200/AllowUnsafeData→0x400/Identifier→0x80 均被掩掉
  ⑨ vanilla 对照全通过: 旗标枚举位值、parseProperties 覆盖语义(csi继承+原位替换)、allocateClientServerFullIndexes 每层重跑(最终态等价)、MethodArgs 不哈希参数名、EntityDescriptionMap::addToMD5=vector_原序
  ⑩ 客户端 mini_scripts.pkg 解包(104文件): 与服务器 defs 字节级完全相同(103 def+entities.xml md5 全同)→双侧同摘要
- 实现 digest_v9.py: 终版模型(类型树解析+三序方法累积+完整序列化)+84 组合暴力(begin×4 × vlh宽×3 × 方法序×7) → 未命中
- 数据验证: Login 实体逐项吻合; csi 全 40 实体稠密; streamSize[-1,60]无溢出; 方法重名仅 Account.requestToken 1处; vlh分布{1:342,2:5}
- ★发现 csi 验证神谕: 0x05 创建块尾巴=[u8 count][每属性 u8 csi+len前缀值], AreaDestructibles 4空串属性(csi0-3)完美对账; 1833个0x05块可全类型对账(下轮)
- 方法ID锚点试验: setClientReady=1(基方法!)/updateArena=58 与 M1 序 0基57/1基58 部分吻合, setClientReady 矛盾(46位), 工具命名表来源待核
- findings.md 大更新: §3.3-3.7 重写(终版结构/裁决/验证/下轮路径), 三处同步

Stage Summary:
- 用户问题答案: decomp 里几乎全能找到(.rdata 数据除外), 本轮把"待 Ghidra 数据"全部从 decomp 侧面破译——不需要 db.1.gbf!
- digest 从 95%→98%: 算法/结构/字符串/数据全定案+实现, 唯余单一细节未命中(84 组合)
- 新知识资产: MD5Calculator 原语语义、类型块全集、0x05 尾巴 csi 神谕、AllowUnsafeData 位、客户端=服务器 defs 同源
- 下轮路径已备好: 0x05/0x06 全量对账 csi → 定位数据层差异; 或 Ghidra 读 MD5Calculator vtable 终裁

===== 第二部分 · 会话B（第一次重置后 · Task 18-26 新编号 · v9-v14 线 · V8-V11 交付 · 2026-09-23~24）=====
> 本段为 V11 交付包内 worklog.md 原文（Task 18-26，Super Z 署名各条）。

---
Task ID: 18
Agent: Super Z (main)
Task: 环境重置后恢复 0x3D 主线；核验用户从 Ghidra 导出的 BW::MD5Calculator vtable 报告并闭合槽位字节编码

Work Log:
- 发现会话环境被完全重置：upload/ 清空、/tmp 清空、findings.md/worklog.md/scripts/digest_fork.py/download/csi_tables_v8.json 全部丢失
- 核验用户导出的 vtable 数据：原始字节↔槽表 17 qword 逐一核对通过；RTTI 邻接零间隙（IMD5Calculator 15 槽 | MD5Calculator COL+15 槽 | AbstractMD5Visitor COL @0x143923130）
- 用 MSVC ABI（vptr=slot0）+ IMD5Calculator 析构写入值 0x143923038 论证 IMD5Calculator 也恰 15 槽（干净继承）
- 修正外部 AI 报告两处错误：① §3.6 对象布局差 8 字节（buf 实为 this+0x20，其"+0x10 ??"= ABCD 状态字）；② T 表索引 0/1 基混用，且 0x57cfb9ed 不在 RFC1321 T 表内（12/13 常量真且位置精确）
- 建立槽位→虚调用偏移→字节编码映射（15 槽全表）；识别 +0x18=slot3 空槽异常（钩子 no-op 假设，不贡献字节，decomp 重传后复核）；记录中无 u16 调用
- 写 scripts/md5calc_ref.py：按反编译语义实现 MD5Calculator（count/ABCD/buf 布局、RFC1321 update/final、update_u32/u16/u8/string/cstr 槽位 API），RFC1321 向量 7 + 随机分块对账 hashlib 500 + 槽位语义 6 项自测全部通过
- 重建 findings.md（v9 条目）并三处同步（root/upload/download，md5 校验）

Stage Summary:
- 0x3D 待闭合项从 2 个减为 1 个：槽位字节编码已闭合（整数小端、string 无 NUL 无前缀、cstr 含 NUL）；仅剩 DAT_1435e0950/DAT_143665890 两字符串值
- 提出三个领先假设（H1 NUL 差异 / H2 长度前缀差异 / H3 DAT 标记串）解释 vanilla 复刻与目标的偏差
- 需用户重传：decomp.zip > scripts.7z > tools/bwxml_decode.py > replay.jsonl > BigWorld tar.gz（无需 1.3GB .gbf）
- 需用户在 Ghidra 顺读：DAT 两值（数据段，伪代码导出不含）；可选 FUN_1403e8140/FUN_1403e82e0/IMD5Calculator 表
- digest_fork.py 的 MD5 层已就绪：from scripts.md5calc_ref import MD5Calculator 即用

---
Task ID: 19
Agent: Super Z (main)
Task: 资源三件套自取（scripts.7z/BigWorld-14.4.1/wot-src@2.4.0.0-cn）；核验外部 AI 的 DAT "type"/"args" 报告；0x3D 主线推进

Work Log:
- 确认 decomp.zip 本轮上传再次失败（upload/ 无文件，全盘搜无残留）；幸存文件：findings.md×3、worklog.md×2、scripts/md5calc_ref.py、download/README.md
- 自行拉取三资源到 repos/：scripts.7z（md5=3291a197… 与丢失原件一致）、BigWorld-Engine-14.4.1-HEAD（1.4GB）、wot-src@59e92351（=wot-cn 2.4.0.0 #942 sd，与回放同版本）；装 py7zr 解压
- 从 wot-src stubs/manifest.json 取得 WorldOfTanks.exe 权威 sha256=2ec886a8…（78,777,520B）供 Ghidra 二进制同一性核验
- 外部 AI DAT 报告核验：其 EXE 读取本机不可复核（无 exe）；其 decomp 引用行号待 decomp.zip 重传后对账；判定 "args"（PyObjectCommand 邻域）疑似与 digest 无关、"type" 为 PyDict 键
- 从 vanilla 源码重建 BWXML/PackedSection 解码器 scripts/bwxml.py：格式全解（含 ChildRecord type()=(this+1) 链式高位）；破解 BLOB=合法回环 Base64（"Chat"/"AccountAdmin"/"base"/"none" 实证）；2881 文件全解
- 从 vanilla 源码提取 digest 配方全链（EntityDescriptionMap::digest 编排 + 全部 addToMD5 + 字段宽度 + 解析顺序），落地 scripts/defparse.py
- 破译 csi 分配机制：parseProperties 后稳定排序（定长在前按字节升序、变长按 varLenHeaderSize 升序、同键保持声明序）
- 验证：40 实体/306 CS 属性与 v8 双吻合；Vehicle 锚点 isStrafing=1✓ avatarID=16✓ perkEffects/perks=28/29≠真值33/34（+5 缺口，数学闭合：缺 5 个先于 Perks_Vehicle 声明的变长属性）
- 归因 +5：WoT 弃用 vanilla <Components>（0 def 使用），fork 组件体系（components.xml + component_defs 127 def/181 CS 属性）运行时挂载注入；判定 0x3D（启动期计算）不受影响，0x07/0x24 csi 表受影响
- vanilla 基线 digest 实算：5CEEFA591EA23A760C64EFCF8101DD9A（≠目标 5DF886F7…，预期内）
- 重建 findings.md v10 条目并三处同步

Stage Summary:
- 主线底座就绪：vanilla 精确基线（defparse.py）+ slot 语义（v9）+ "type"/"args"（外部读）——fork delta 搜索可以开跑
- 关键阻塞：decomp.zip 两连败 → 建议用户切分上传 7 个关键 chunk 或让外部 AI 导出 FUN_142a9b640 全调用链伪代码
- 0x07/0x24 csi 表需按组件注入模型重建（待 replay.jsonl）
- scripts.7z 内容=完整服务器 scripts 树（273 def+pyc 客户端脚本+item_defs 等，192MB）

---
Task ID: 20
Agent: Super Z (main)
Task: fork-delta 参数化搜索（0x3D 收口尝试）

Work Log:
- 修复 defparse.py ARRAY/TUPLE 标签笔误（"ARRAY\0"→"Array\0"）——vanilla 基线由 5CEEFA59… 修正为 562A9B2278044E1EF6401BB7518E7701；两实现逐字节 diff 归零
- digest_search2.py：带 DT 字节缓存的扩展网格，122,880 组合/180s（1.47ms/组）全部未命中（基线自检通过）
- raw_variants.py：原始字节族 14 式（def 拼接/分隔符/解码 XML/名字表/单文件/entities.xml 等）未命中
- last_shots.py：UDO 并入族——先修双重 MD5 bug，后确认 UDO 属性走 PARSE_IGNORE_FLAGS（vanilla user_data_object_description.cpp:85）flags=0 无 CS 属性；18 式未命中
- 追查 "transform" 字串：全局 grep 证明为字符串池邻居（chunk/decal/camera 通用），与 digest 无语义关联，弃线
- 确认动态组件为逐实例（client cgf_script/entity_dyn_components.py：onDynamicComponentCreated→networkID/game_object）→ +5 csi 空间是逐实例的，不可能进静态 per-type digest → 主线（0x3D）用静态属性集判定成立
- 客户端 Vehicle.py 类基仅 BigWorld.Entity+BWEntitiyComponentTracker+BattleAbilitiesComponent；Avatar 的 mixin 对应 entity_defs/interfaces（非 component_defs）

Stage Summary:
- 搜索负结果登记完毕：fork 差异锁定在「喂入内容语义层」（何种数据/顺序/集合），编码层（NUL/宽度/端序/掩码）已系统性排除
- 收口阻塞项：decomp.zip（call-map）与 replay.jsonl（def-dump+组件挂载真值）——均需用户重传
- 本轮产物：scripts/{digest_search2,raw_variants,last_shots}.py；vanilla 基线 562A9B22… 可复现

---
Task ID: 21
Agent: Super Z (main)
Task: 从 FengY233/test 自取 decomp/回放/exe 等全部资源；用 decomp 闭合 0x3D 配方；整理结论并架下载功能

Work Log:
- 盘点 GitHub FengY233/test（HTML 文件列表）：dec.7z.001/002（分卷 decomp，密码 114514.1919810）、replay.jsonl.zip、wotexe.7z、bwxml_decode.py、def_dump.py、replay_setup.py、scripts.7z、wotreplay 原件
- 全部下载成功（raw.githubusercontent.com）；dec 分卷合并解压 → decomp.zip 47MB → repos/decomp/（30 chunks ~320MB + giants + index.tsv）
- wotexe.7z 解出 WorldOfTanks.exe：sha256=2ec886a8… 与 wot-src manifest 权威值逐字节一致 → Ghidra 二进制同一性闭合
- exe 直读验证 DAT 双值：0x1435E0950="type"、0x143665890="args"（邻域字符串全吻合外部 AI 报告）
- 机器码级解决 vtable 基址歧义：FUN_142a9b640 的 lea 指令解码 → vptr=0x1439230B8=slot0 首项；+0x18(slot3)/+0x20(slot4)=0x1402F7290 空函数（单 ret，COMDAT 折叠）→ v9 slot3 异常闭合：所有段标记串（properties/baseMethods/…）经 +0x18 喂给空槽，0 字节贡献
- 解出 visitor 双表：AbstractMD5Visitor@0x143923138、ClientServerTypesMD5Visitor@0x143923290（slot5=onProperty FUN_142a9b870、slot6=onMethod FUN_142a9b810、slot7=过滤+喂实体名 FUN_142a9b6c0）
- 逐函数解出 fork digest 全配方（ EntityType::init→FUN_142a9b640→FUN_142a9b5b0→FUN_142a9b410→FUN_142a93420→onProperty/onMethod→正文喂入器→DataType slot15）：
  * 属性：[csi u32][varLen 条件同 vanilla][name 无NUL][dataFlags&0x5F u32][isVolatile u8 ★增量①][类型]
  * 方法：[varLen][name][flags u8][args 类型][returnValues 类型 ★增量②=0字节][index u32]
  * 类型标签层与 vanilla 逐项一致（47 个 DataType vtable 经 RTTI COL→vftable 全链解析实测）
  * ★增量③：实体 +0x2f0 子描述（组件，FUN_142a8d480 构造 0x338B EntityDescription）的方法并入 digest（三域、exposed 索引连续）——推翻 v10「0x3D 不受组件影响」的方法维度判定（属性维度仍成立）
- "type"/"args" 判决：均为喂入器 label 参数，被 MD5Calculator 忽略（同族 name/flags/size/… 全部 0 字节）；H1/H2/H3 假设全部证伪
- fork 专属 volatile 机制：<Volatile><Properties> 子段（FUN_142a923c0 解析→prop+0xb3=1）；40 实体无一使用（唯一 GunMarkerComponent.gunMarker 在组件）→ 306 个 0x00 字节仍喂入
- MAILBOX 无影响：fork 无 MailBox 类，但 22 个 def 的 MAILBOX 用法（3 属性非 CS + 全部方法参数非 exposed）0 处进 digest；DICT/CLASS 未使用
- def 侧统计：component_defs 127 个（185 属性/3B/41C/28Cl 方法），79 个 <ofEntity> 挂载声明（Vehicle←31、Arena←16、Entity←10…）
- 实算三变体（scripts/digest_fork_test.py）：A=isVolatile 无组件 B6DFA134…；B=+ofEntity 组件 D54806FD…；C=全组件 196E8A39…；均≠目标 5DF886F7… → 剩余自由度锁定在组件挂载规则（集合/顺序/传播/目标解析）
- findings.md 更新至 v11（§7 全解 + §5 假设判决 + §6 开放项刷新）并三处同步
- 架设下载服务：scripts/serve_download.py（白名单单文件下载，无目录列举防卡顿），端口 8642

Stage Summary:
- 0x3D 配方从「黑盒搜索」转为「逐函数白盒」：唯一实质未知量 = 组件挂载规则（FUN_142a99f30 833 行待细读 + def_dump.py/replay_setup.py 待阅）
- 关键坐标与全部证据链已固化 findings.md v11 附录 D；digest_fork_test.py 为后续变体搜索基座
- 资源状态：decomp/replay.jsonl/exe/bwxml_decode.py 全部恢复且校验通过；下载服务已起

---
Task ID: 21-supplement
Agent: Super Z (main)
Task: 下载功能架设记录（补充）

Work Log:
- 直接 nohup/setsid 启动的 HTTP 服务会被沙箱跨命令回收；改用 Python 双 fork 守护进程化后跨命令存活验证通过
- 服务形态：scripts/serve_download.py，端口 8642（0.0.0.0），白名单仅 download/ 下 2 个文件（findings.md 26KB + findings_bundle.zip 46KB），无目录列举、路径穿越 404 —— 响应用户要求"不要共享可见大量文件导致卡顿"
- 平台原生通道：download/ 目录已极简化为同样 2 个文件；根/upload/download 三处 findings.md md5 一致（c4721f8f…）

Stage Summary:
- 下载通道就绪：平台 download/ 目录 + 备用 HTTP 8642 双通道；结论 v11 可取
- 按用户指令停机等下载，下一会话从 findings.md §6 开放项续作（组件挂载规则 → 重跑 digest_fork_test.py 变体）

---
Task ID: 22
Agent: Super Z (main)
Task: 纯执行轮（用户指令：不分析）：①GitHub FengY233/test 全量拉取 ②按预览网关方法架 3000 端口下载门户 ③在 V7 交付包基础上制作 V8

Work Log:
- gh_fetch.py：GitHub API 限流（403）→ 改用早前 curl 拿到的目录快照硬编码清单，raw.githubusercontent.com 全量下载 10/10 文件到 repos/gh_test/（~92MB）
- 校验：10 文件大小全部与 API 元数据一致；md5 与本地已有副本（upload/、repos/scripts.7z）逐一相同（含 scripts.7z=3291a197… 权威值）→ 资源零丢失零漂移
- 用户反馈对账：用户能从官方渠道下载 V2–V7 交付包，但 V7 包内 findings.md 只到 §6（v10 时代快照）；本地 findings.md 为 v11 全量（§0–§7+附录，26143B，md5 c4721f8f… 三处同步确认）
- 停掉 Task 21 的 8642 旧服务（pid 5477，白名单含已移除的 V7 包，防止 404）；download/ 移除 findings_bundle.zip（V7 内容，官方渠道仍可取 V2–V7 历史）
- serve_download.py 升级为网页下载门户：端口 8642→3000（平台 81 网关的代理目标）；新增 /health 健康检查、文件说明表、md5 指纹列、RFC 5987 中文文件名、--daemon 双 fork 守护化（跨工具调用存活，日志留痕 scripts/portal.log）；白名单仍= download/ 实际文件（硬约束：不暴露大量文件）
- 启动验证：3000 存活（pid 5942）；网关 81 → 门户首页 200（标题/内容匹配）；/health 经网关返回 ok
- V8 交付包制作（build_bundle_v8.py）：保持 V7 结构（findings.md + worklog.md + scripts/*.py），内容全部更新为最新 —— findings.md v11 全量（含用户缺失的 §7）、worklog.md 含本 Task、scripts/×18（V7 的 11 + 新增 datatype_vtables / digest_search / digest_search2 / raw_variants / last_shots / gh_fetch / build_bundle_v8）
- 端到端验证：经网关 81 下载 findings_bundle_v8.zip 与 findings.md，md5 与磁盘原件一致

Stage Summary:
- 三指令全部完成：GitHub 全量拉取✓（10/10 校验同源）、3000 门户通道✓（81 网关贯通+守护化）、V8 交付包✓（V7 结构+最新内容）
- download/ 最终形态：findings.md（v11 全量）+ findings_bundle_v8.zip；findings.md 三处同步（c4721f8f…）
- 0x3D 主线状态冻结在 v11（本轮零分析）；下一轮从 findings.md §6 开放项续作（组件挂载规则 FUN_142a99f30 → digest_fork_test.py 变体重跑）

---
Task ID: 23
Agent: Super Z (main)
Task: 纯执行轮：①GitHub 14 文件重拉（含 V7 包/csi 表/会话记录）②解决 repos/ 内存撑爆 ③在 V7 交付包基础上制作 V9（全部结论一个不落，对账会话记录.txt）

Work Log:
- 盘点：项目 4.7GB（repos/BigWorld 1.4G + .git 1.3G + wot-src 653M + tar 548M + decomp 356M + scripts_x 192M + gh_test 88M）→ 内存撑爆根源确认
- 清理：工作树删 repos/{BigWorld,wot-src,decomp,scripts_x,gh_test,tar×2,scripts.7z} + upload/{dec_full.7z,replay.jsonl}（全部可从 GitHub/归档重取）→ 128MB；.git 用 filter-branch 重写甩掉 repos/ 与 upload 大文件历史 + gc --prune=now → 364KB（历史保留 findings/worklog/scripts 演进）；.gitignore 增补 repos/ 与 upload 大文件 → 33 个跟踪文件
- GitHub 重拉：API 快照硬编码 14 文件（修复中文文件名 urllib.parse.quote），10/10 校验同源 + 4 个新文件（WoT回放解析交付包_v7.zip 6.2MB / csi_tables_v8.json 44KB【重置丢失的权威表原件！】/ findings.md 25KB【重置前 v8 全细节版】/ 会话记录.txt 253KB）
- 通读会话记录.txt 全文 5,887 行（v1→Task22 全程对话记录）→ 结论清单对账：V7 报告覆盖 v1-v7；缺 v8（csi 体系）与 v9-v11（0x3D 白盒）两大块 + 4 处需勘误（16.4"不可复算"/附录 D 属性确名/23=stunInfo/工作表计数）
- V9 报告：patch_report_v9.py 10 处补丁全命中——新增 §17（csi 体系：机制/14 锚点/+5 缺口归因）与 §18（0x3D 白盒：vanilla 排除/MD5Calculator 全解/fork 配方逐函数/三增量/三变体实算/挂载规则开放项）；更新 §0 速览两行、§6 0x3D 后记、§16.4 推翻注记、§16.5 增补、§11 交付清单、附录 C 增补 14 条地址坐标、附录 D 量化口径刷新 → 121,626B
- PDF：md2pdf_v9.py（TocDocTemplate+multiBuild、cascade 色板、install_font_fallback、全 Paragraph 表格、图表 Spacer 卫兵、CondPageBreak）→ 57 页；修复 code.sanitize 破坏 esc() 实体问题（chr() 构造绕过）、bullet Helvetica、封面页尺寸归一化；QA 0 错误（11 个标点警告=ReportLab CJK 已知限制）；封面复用 V7 模板 v9 化（poster_validate + cover_validate 全过，html2poster 渲染）
- xlsx：+2 表（v8csi锚点表 / v11_0x3D配方与实算，样式匹配 V7）→ 17 表，validate 0 issues
- JSON：+csi_tables_v8 +fork_digest_v11 两段（20 顶层键）；审计 → 覆盖度终审_v9_audit.json（v5 数字 + v8/v11 修订）
- findings.md → v12：资产恢复终态（csi 表 md5 5ac32922… 寻回）+ §8 交付包沿革；三处同步（a11fdf3f…）
- 打包：WoT回放解析交付包_v9.zip（18 文件 = V7 的 16 + findings.md + csi_tables_v8.json，6.1MB，md5 bad6f1bc…）
- 门户：修复中文文件名 404 bug（路径未 unquote——浏览器必编码）；DESCR 更新为 V9；81 网关端到端下载验证 MD5 一致
- download/ 最终形态：V9 包 + findings.md（移除已过时的 findings_bundle_v8.zip）

Stage Summary:
- 三指令完成：14 文件重拉✓、内存问题根治（4.7G→128MB + .git 364KB + gitignore 防复发）✓、V9 交付包✓
- V9 = V7 结构 + 全部结论：报告 18 章（+§17/§18）、xlsx 17 表、JSON 20 段、csi 权威表、findings v12——会话记录.txt 逐行对账无遗漏
- 门户双通（平台 download/ + 3000 端口网关），中文文件名下载已修复
- 0x3D 主线状态：findings §6 开放项（组件挂载规则 FUN_142a99f30）待下轮续作；分析资源已清理，需要时从 repos/gh_test 重解压

---
Task ID: 24
Agent: Super Z (main)
Task: ①根治内存撑爆（资源移到用户不可见区）②恢复 worklog（据会话记录.txt 重建 Task 1-17）③主线攻坚 0x3D 组件挂载规则 ④制作最新交付包（含 worklog.md）

Work Log:
- 内存根治：md5 校验后把可见区 repos/gh_test(95M) 整体移入 /tmp/wot/gh_test；upload/ 清除 5 个大文件（dec.7z×2/wotexe.7z/replay.jsonl.zip/replay.wotreplay，均与隐藏区副本逐字节一致）；.git 保持 208KB；可见区从 4.7G 降到 29M（skills 61M 为系统）。隐藏区：/tmp/wot/gh_test（14 文件）+ /tmp/my-project/repos（3.2G root 只读：decomp/scripts_x/wot-src/BigWorld）
- worklog 恢复：原文件随重置丢失不可恢复；据 会话记录.txt（5887 行）重建 Task 1-17 摘要级复述（历史时间线：资料清点→38 包类型→图表→交叉验证→时钟两轮纠错→报告 v1-v7→BigWorld 配方→csi 体系→digest_v9 收尾），补记说明已写入文件头
- 主线攻坚（FUN_142a99f30 833 行全读 + 全调用链白盒）：
  * FUN_142a98830 = EntityDescriptionMap::parse 全编排：spaces→挂载索引→ClientServer→扩展→ServerOnly→旧格式兼容→DynamicComponents→扩展
  * FUN_142a971a0 = createEntityTypeToComponentSectionsMap：multimap<实体名,{组件名,section}>，静态边仅来自 components.xml StaticComponents(16) 的 ofEntity；等值键追加序（FUN_142a94570 右子树）
  * FUN_142a900a0 = parseFromSectionList：pairs[0]=主def（Parent→FUN_142a90f20→FUN_142a8ff40 递归同记录）；pairs[1+]=组件→FUN_142a8d480 建 0x338 子描述(type=6)压 +0x2f0
  * decider 三表 RTTI 反查（COL 用 32 位 RVA——修正 v9-v11 盲区）：Entity=side flag（40 实体全 isClientType=1）、Dynamic=scripts/client/<名>.py(c|o|d) 存在性、Space=FUN_140355960(b0 01 c3 恒真)
  * records 真相 = [GeneralSpaceData(spaces.xml 唯一子节点,3 个 Exposed CS 属性)] + 40 实体 + 107 dyncomp(110 唯一-DynamicComponents 有 3 重名被 FNV 去重-3 无脚本) = 148 条
  * 实际挂载边：Account←2/Avatar←1/TeamInfo←2/Vehicle←1（Arena←10 条因 Arena 非 ClientServer 实体而无效）
  * ★fork 增量④：client 方法全部出局——onMethod(FUN_142a9b810) 的 (flags&0xC)!=0 通用过滤 + client 方法禁带 Exposed(报错路径) + 域位 CLIENT=0 → flags 恒 0；方法 varLen 永不喂入；returnValues 5 个 Base 方法全无 Exposed=0 字节
  * ★★fork 增量⑤（本轮最大发现）：FIXED_DICT 的 AllowNone 不再使 streamSize=-1（vanilla fixed_dict_data_type.cpp:441 被 fork 改掉）——DOT_EFFECT=14/BUFF_EFFECT=24/REMOTE_CAMERA_DATA=22/OWN_VEHICLE_POSITION=32/INSPIRED_EFFECT=36 实证；**推翻 v8「+5 缺口=组件属性注入」归因**（实为 6 个 AllowNone 字典移入定长区的排序位移）；修复 defparse 后 40/40 实体 csi+streamSize+flags 全对账
  * 方法属性新语义：AllowUnsafeData(方法)=0x10 位（11 处全在 client→无效）；HasReliableRetry/IsImmediate/IgnoreIfNoClient/version/scope/ReplayExposureLevel 均不进 digest；space 属性 param_5=1（跳 Flags+启用 <Exposed>→OWN_CLIENT 规则）
  * 实算：digest_fork_v2.py 完整模型（148 记录/489 CS 属性/isVolatile=1 仅 gunMarker/134 方法）→ E2E9EBE2…≠；digest_fork_diag.py 24 组合矩阵 + 内联第 25 组合（client 方法原始 flags）全负
  * 未命中收口：记录集/喂入格式/属性层全部白盒验证完毕，剩余嫌疑锁定方法层合并细节（methodID 是排序+range 空间无法直接验证）、dyncomp 内容细节、DT 层未知增量
- def_dump.py/replay_setup.py 已阅（客户端 scripts.pkg 工具+回放解包器，无 digest 真值；证实 scripts.7z=客户端树）

Stage Summary:
- 0x3D 主线从「挂载规则黑盒」推进到「全架构白盒+属性层全对账」：六轮白盒（parse 编排/挂载索引/记录构造/decider/方法语义/类型尺寸）+ 两大 fork 增量新发现（client 方法出局、FIXED_DICT 定长化）
- csi 体系彻底闭合：40/40 三要素对账（历史 +5 缺口根因改写）
- 交付：findings.md v13（+§9 全架构+附录 E）、defparse.py 修复、digest_fork_v2/diag 脚本、worklog 重建
- 下一轮建议：0x05 创建块做 dyncomp csi 对账 / FUN_142aa7c30 子描述索引机制精读 / 47 张 DataType vtable 的 addToMD5 逐字节复核
- 交付包 V10 制作与投递：报告追加 §19（v13 增补：挂载规则全解/records 真相/增量④⑤/csi 终闭合/实算现状）→ md2pdf_v9.py 重生成正文 + 封面 v10 化（html2poster）+ merge_final_v9.py 合并 = 58 页 A4 归一 PDF（§19 在位验证✓）；README v10 化（+worklog/scripts 条目）
- V10 = 22 文件 6.2MB（md5 b2eb8841d7d9993d98fd82f28d1876f5）：V9 全套 + worklog.md（用户指令）+ findings v13 + scripts/（digest_fork_v2/diag/defparse修复版/bwxml）+ 报告 v10
- 门户 DESCR 更新（v10 最新/v9 保留/findings v13），重启守护进程，网关 81 端到端下载 V10 md5 一致✓；暂存区已清理，可见区终检 29M
- 终版：V10 重建纳入完整 worklog（含投递记录），md5=21ae42b432f37aef2de483c764186f26（22 文件/6.2MB），网关 81 端到端复验一致；本行为打包后补记（包内 worklog 止于上行，此行仅存根）

---
Task ID: 25
Agent: Super Z (main)
Task: 继续攻克 0x3D：§6 开放项三路攻坚（方法层合并细节 / dyncomp 内容 / DT 层 47 vtable 复核）

Work Log:
- 环境恢复：/tmp/my-project/repos（decomp/scripts_x/wot-src/BigWorld）与 /tmp/wot/gh_test 全部可读；replay.jsonl 解压就位（156,482 行）
- 方法层终解：重读 walker FUN_142a93420 全函数——onMethod 的 index=walker 第三参计数器（非方法对象字段）；client 域计数器无条件++但全被 onMethod 的 (flags&0xC) 过滤；base/cell 域计数器仅对通过者递增 → index=域内 exposed 连续编号（自有在前组件接续）——与 digest_fork_v2 模型一致，方法层嫌疑排除
- DT 层终解：24 个 addToMD5 feeder 全量导出重审 + exe 直读 DAT 常量（新脚本 dat_strings2.py）："Int"/"Uint"/"Blob"/"User" 均经 slot13 含 NUL 喂入、"name"/"size" 为 0 字节 label——与 defparse 逐字节一致；FixedDict 自定义类/USER 类型全树 0 个 → 模块/实例恒 0 字节；DT 层嫌疑排除
- 全链字节级复核（全部与模型一致）：ExposedForReplay=bit8(0x100) 但全树 32 处扫描 29 处本带 client 位+3 处 space（0x100 在 0x5F 外）→ 零影响；parseProperties 全读（param_5/EDITOR_ONLY 跳过/同名覆盖保留 csi/空 Exposed→0x4 仅 space）；DataDescription::parse 的 isForClient=(flags&0x106)!=0 与 vanilla data_description.cpp:320 逐字一致；parseMethods 域分支（type7 禁 BaseMethods）；空 <Exposed/>→0xC；FUN_142a99f30 迭代序=首遇序+equal_range 仅 mode==1；ReturnValues 恰 5 个全非 exposed；6 个静态挂载组件全扁平；space 无方法段
- ★本轮最大发现——FeatureExtension 体系（§6 剩余嫌疑 (b) 的真身）：
  * wot-src 镜像 sources/res/ 下存在 18 个扩展目录（extension.xml 全部 IsEnabled=true）；v13 的「干净安装=空树」判断被推翻（当时只搜了 scripts 树）
  * paths.xml 列出 18 个对应扩展 pkg（type=sandbox,sd,hd；0x30 包证实客户端为 sd → 全挂载）；pkg 顺序恰为字母序
  * decomp 全解三消费点：挂载索引 Part b（<ext>/scripts/component_defs/<Static>.def，".def"=0x6665642e 直写实锤）+ 扩展循环#1（根 "Entities"→FUN_142a996e0，dir=<ext>）+ 扩展循环#2（根 "Components"→"DynamicComponents"→mode=7）；def 路径构造 FUN_142a8e790 全 mode 支持 <dir>/scripts/<子目录> 前缀；decider 脚本检查同带 dir
  * FeatureExtensionMap::parse（FUN_142a7fbb0）：枚举 FileSystem 根目录→查 <dir>/extension.xml→IsEnabled 过滤（false 跳过）→收集 StaticComponents 名单
  * def 加载失败语义：批次中止返回 false 但总流程继续（digest 仍算）
  * 规模：39 static 挂载边 + 171 dynamic + 10 CS 实体 → records 实为 ~318 条（v13 模型仅 148 条）——25 组合消融矩阵从未触及此维度，完全解释全负
  * 自洽性：0x05 创建块 n≤40 无矛盾（本场无扩展实体创建）；csi per-record 不受影响；server_side_replay 启用与 SERVER_REPLAY 回放模式吻合
- 阻塞确认：扩展 def 不在任何现有资源（scripts.7z=主 scripts.pkg；wot-src 镜像剥除全部 .def 二进制）——需用户从客户端 res/packages/ 的 18 个扩展 pkg 提取
- 产出：scripts/{dat_strings2.py, ext_inventory.py}（后者产出 download/ext_inventory.json）、findings.md v14（§10 + §6 改写 + 附录 F）、门户 DESCR 更新重启（4 文件）

Stage Summary:
- 0x3D 差异收敛到唯一自由度：FeatureExtension 扩展记录内容（39 static + ≤171 dyncomp + 10 CS 实体，顺序待定）
- 主链路（148 记录模型）已 100% 字节级白盒对账——digest_fork_v2.py 无已知偏差
- 下一步：用户提供 18 个扩展 pkg 的 scripts/{entity_defs,component_defs}（含 interfaces）+ client 清单 → 扩展模型重算 digest（顺序假设：pkg/字母序优先，未命中再枚举）

---
Task ID: 26
Agent: Super Z (main)
Task: 制作 V11 交付包（用户指令：先把本轮调查打包，用户同步去提取 18 个扩展 pkg）

Work Log:
- 盘点：V10 包 22 文件结构、findings.md v14 三处同步（9835dd3b…）、本轮新产出 ext_inventory.json（download/）与 scripts/{dat_strings2.py, ext_inventory.py}
- 报告 v11 增补（scripts/patch_report_v11.py，10 锚点全命中 + scripts/append_s20_v11.py）：
  * 头部版本行 v9 定稿→v11 定稿（§17–§20 全列）；§0 速览 +FeatureExtension 行（records ~318/25 组合全负解释/唯一剩余自由度）
  * §11 交付清单刷新（xlsx 19 表、ext_inventory.json、findings v14、脚本集 v8–v14）
  * §19.4 尾部 +v11 后记（三类嫌疑已清算，真缺失=扩展记录维度）；附录 C +v11 坐标表（FUN_142a7fae0/142a7fbb0/142a996e0/142a994c0/142a8e790/0x6665642e/两根段名）
  * 附录 D +v11 版增补（0x3D 剩余未知量再定位）+ 修复历史重复文本（v9 补丁曾致一段 v6 终局语句双写）
  * 文末追加 §20（6 小节：体系结构/三消费点全序/扩展清单 18 行表/全链字节级复核/自洽性/阻塞与下一步，6,035 字）
- PDF 链：md2pdf_v9.py 重生成正文；封面 v11 化（副标题+脚标 V11，poster_validate PASS + cover_validate 0 overlap）→ html2poster → merge_final_v9.py 合并 = 63 页 A4（V10 为 58 页）；pdf_qa WARN 12 条（全部为 ReportLab CJK 标点换行已知限制+封面设计性不对称，与 V9/V10 同 profile，无 FAIL）；§20/v11 版增补/19 工作表等关键词 pymupdf 全文验证在位
- xlsx（scripts/update_xlsx_v11.py）：+2 表（v14扩展清单=18 行数据表 + 合计行；v14全链复核=11 行键值表），样式匹配既有表（表头 645B42 填充/Calibri 11/wrap）；validate 0 issues → 19 表
- JSON（scripts/update_data_v11.py）：解码 JSON +feature_extension_v14 段（21 顶层键，meta→v11）；审计 JSON +v14_revisions（三嫌疑清算+覆盖度口径不变）
- README v11 化：标题/清单表/新增「v11 增补内容」节（6 行攻坚表）

Stage Summary:
- V11 = V10 结构 + Task 25 全部成果：报告 §20（20 章 63 页）、xlsx 19 表、JSON 21 段、ext_inventory.json、findings v14、scripts +2（dat_strings2/ext_inventory）
- 0x3D 主线状态：唯一剩余自由度 = 扩展 def 内容；等用户提取 18 个扩展 pkg 的 scripts 树后 digest_fork_v2.py 扩展模型重算
- （打包投递记录见下方补记行）

===== 第三部分 · 会话C（第二次重置后 · 沿用会话A 编号 Task 19 起 · ext_pkg 对账 + v15/v16 终局轮 · 2026-09-24 深夜~25）=====
> 会话C 原始 worklog 已随第三次重置丢失。Task 19-27 补录由会话D 自对话摘要恢复；
> 「v15 攻坚轮」与「版本漂移终局 + v16 终局轮」两条过程补录由会话F（Task 31）自最全对话记录.txt 恢复。
> 会话C 内实际时序：ext_pkg 十项对账 → v15 攻坚轮 → 版本漂移澄清 → v16 终局轮。

---
Task ID: 19-27 (补录: 环境重置前完成的工作, 自对话摘要恢复)
Agent: main
Task: ext_pkg 十项对账(C1-C10) + 自研解码器验证 + 版本漂移调查(已于 09-24 完成, 原记录随环境重置丢失)

Work Log (自摘要恢复的要点):
- 材料获取: 从 GitHub FengY233/test 拉取 wot24_ext_defs.zip, 解压至 /tmp/wot/ext_pkg/extracted/wot24_ext_defs/
- 十项对账 verify_ext_pkg.py C1-C10 全过 (95 PASS / 0 FAIL): 18 扩展目录; 210 组件 defs (static 39 / dynamic 171); 10 CS 实体正确在场 + 16 SO 实体正确缺席(so_entities 不随客户端 pkg 发行); IsEnabled 18/18; StaticComponents 核对; dyncomp 脚本真值; _raw/xml 配对 242/242; MANIFEST.tsv 字节数 242/242
- 自研 BWXML 解码器 ext_raw_decode_test.py 独立消费 _raw: 242/242 成功; ofEntity=173 / Parent=3 / Properties=161
- 版本漂移调查 (partial clone --filter=blob:none --depth 2 拉 wotstat/wot-src wot-cn 分支): HEAD=#949(2.4.0.5449, 09-17 03:23 快照), HEAD~1=59e923510ff067636dd6fe3ad94725179103fc08=#942(2.4.0.5435, 09-11 05:58 快照), 与本地镜像目录名逐位一致
- V1→V2 (#942→#949) tree diff 650 文件: 152 个 M 全部与 digest 无关 (GUI 资源 as3/gameface/RES_ICONS, 本地化 .po, item_defs 瑞典 S37_Ambassador 平衡数据, 版本号文件); 扩展目录大量 A (last_stand 71/battle_royale 43/white_tiger 36/story_mode 26/frontline 15); battle_modifiers/content_exclude/holiday_ops 零变更
- 镜像流水线 09-17 起才收录 def 文件 (V1=#942 快照无 def, V2=#949 有) → 主树 def 的 A 状态是流水线行为, 与内容变更不可区分, 与本案脱钩

版本时间线定案 (用户澄清 + 实证交叉):
- 用户客户端一直停在 #942, 未更新 #949; "小版本更新"指 #938→#942 (2.4.0.0 内部)
- 09-11 05:58 镜像快照(59e9235)=#942; 09-11 18:01 回放录制=#942; 09-17 03:23 镜像=#949(2.4.0.1); 09-23/24 用户导出 exe(sha256 与镜像一致)+ext_defs(客户端未更新)
- 结论: 全部材料(exe/decomp/回放/ext_pkg defs)版本对齐于 #942, 版本漂移疑虑解除

Stage Summary:
- ext_pkg 材料可信度定案: C1-C10 全过, mod 干扰已排除(用户确认无改 entityDefs 的 mod), digest 输入=纯 pkg defs
- wot24_ext_defs.zip 内 README.md 与 tools/ 为 AI 撰写, 论断须独立取证 (3 处跨包 Parent 名单 SPGZone/FallTanks/SMVehicle 待自查; 扩展包 interfaces=0 待证; digest 是否消费 Personality/ExternalComponents/cgf 节以 decomp 为准)
- 下一步(主线): digest_fork_v2 扩展版开跑——18 扩展 def 记录按 pkg 字母序并入, 对目标 5DF886F75E73B33CFF9D87FB9C69389C 跑第一轮

---
Task ID: 28 (会话C · v15 攻坚轮 · 补录)
Agent: main
Task: 扩展 def 全模型实算 + u16 真 bug 修复（用户指令："继续攻克，把回放全部内容完全搞懂。wot24_ext_defs.zip里的README.md是那个AI写的，可能不对"）

Work Log (自对话记录.txt 行 7350-7900 恢复; 原记录随重置丢失, 本轮当时曾自记为会话C worklog 的 Task 28):
- 立场: 不采信 README 任何断言, 全部事实用自己的 vanilla 版解码器从 _raw 原件独立重扫; README 的 3 处跨包 Parent / 零接口引用经独立复核属实
- 机器码裁决 (capstone 反汇编 WorldOfTanks.exe, sha256 与 manifest 权威值一致): 扩展循环 FUN_142a996e0 实传同一挂载 multimap (r8=[rsp+0x60]) + dir 前缀 (rbx+0x80) + side=0——Ghidra 反编译在该调用点丢了 param_3/param_4, 汇编没有说谎
- ★推翻 v14 两处判定: ①挂载索引 Part b 读的是根级 <ExternalComponents>, 18 扩展该节全空 → 扩展静态挂载边=0 (v14 "39 static 边"系误归因, 0x6665642e ".def" 拼接证据属 Part a); ②扩展迭代序 = FeatureName 键的有序 std::map (FUN_140313020 拷键实锤) = 字母序, paths.xml 实际顺序佐证
- ★修复 v9 起的真 bug: 方法 flags 喂入宽度是 u16 (2 字节) 非 u8——方法体喂入器走 calculator slot10 (机器码 mov word ptr [rsp+0x40], r8w; r9d=2, 零扩展字节载入后实喂 [flags, 0x00]); v9 "无 u16 调用"结论漏了此调用点; 这解释了主模型自 v13 起从未命中
- digest_fork_v3.py 建成: 318 记录全模型 (1 space + 40 主实体 + 10 扩展实体 + 107 主 dyncomp + 160 扩展 dyncomp); no-ext 消融精确复现 v2 的 E2E9EBE2 → 主模型零回归, 扩展层是唯一增量
- 全层汇编级验证: walker 域序 [+0x218=CLIENT][+0x198=BASE][+0x118=CELL] 每域计数器独立从 0 起; 域标签 (baseMethods/clientMethods/cellMethods) 走 slot3=no-op 不喂字节 (字符串池泄漏出圣杯源文件名 entity_description_digests.cpp, 全树仅一处引用); 属性体喂入序 [name][varLen 门控][flags][isVolatile][type] 与 v2 一致; VLH 默认=1; 10 个自定义类型别名全在主树 alias.xml (其中 4 个带 AllowNone); FLRespawnComponent 的 ReturnValues 在非暴露方法上=0 字节; DefaultKeyName 只进记录 +0x308 显示名不进 feed; 记录追加有全局名字 map 去重, 全部重叠组合 (ext dyncomp vs 主实体/主 dyncomp/space 名) 扫描为空; decider 对 .pyc 包目录形态复核无误 (3 个主排除项双重确认)
- 建模风险清零: ext def 旧式直接 <Arg> 子节点的引擎过滤规则 = 只收名为 "Arg" 的子节点 (FUN_142abdc40); MAILBOX 属性 Flags=base64 回环 "BASE" 无 client 位不进 feed; 两侧根级 Type 段 / Components 内联挂载均为 0
- 实算: 全量 318 记录 = 20E4276E… ≠ 目标 5DF886F7…; 主消融 = FD632272… ≠ 目标
- 收尾: 向用户提出版本同期性三问 (录制后客户端是否更新过 / res_mods 是否有改 entityDefs 的 mod / 扩展 pkg 与回放之间无交叉验证锚); 成果固化 findings.md §11 + 会话C 自身 worklog (后者已随重置丢失, 本条即其恢复)

Stage Summary:
- 结构层至此穷尽: 全部喂序/宽度/过滤器/decider/迭代序均与二进制一致, 剩余偏差指向数据本身 (版本同期性)
- 方法 flags 宽度 u16 与 vanilla uint8 的差异浮出水面; 318 记录模型与 5976CA14 终态之间只差方法层与版本层的最后两步

---
Task ID: 29 (会话C · 版本漂移终局 + v16 终局轮 · 补录; 原始编号未及登记, 按会话内序暂编)
Agent: main
Task: 版本疑云解除 + client 方法真相 + 网络 methodID 机制 + digest 5976CA14 终态（本轮 findings 未及固化即遭第三次重置, 本条自对话记录.txt 行 7900-8389 恢复）

Work Log:
- 版本漂移调查 (实证细节已由会话D 并入上 Task 19-27 补录; 实际时序在本轮前段): wot-src 镜像 .version_name/.publication.json 钉死 V1=#942 (09-11 05:58 快照, 与回放录制同日) / V2=#949 (09-17 03:23); partial clone tree diff 650 文件, 152 个 M 全部与 digest 无关 (GUI 资源/本地化/平衡数据), def 全为 A 状态 = 镜像流水线 09-17 起才收录 def 文件; 用户澄清: 客户端一直停在 #942 未更新 #949, "小版本"指 #938→#942 (tree diff 仅 6 文件: precache/version/manifest, 零 def 变更) → 版本漂移嫌疑整体排除
- 0x3D 方向判定: t=24(版本串)/t=45(构建串)/t=48(客户端类型 "sd")/t=61(digest) 是 clk=0 头部区单调相邻的登录流四件套 = LogOnParams 客户端上行 → 客户端模型对象正确 (最致命嫌疑排除)
- 外围嫌疑清空: 主树 entities.xml 无 ServerOnlyEntities 节; FUN_142a9b410 遍历 {begin,end} 指针对 0x328 步长 = parse 期间 append 物理序无重排; arena_defs = 声音库重映射配置不进 digest; Personality/cgf 节仅被 FeatureExtensionMap::parse (0x142a80xxx 段) 引用, EntityDescriptionMap::parse (0x142a9xxxx 段) 零引用; 扩展 pkg 内只有 extension.xml 无 scripts/entities.xml (all_files.txt 1196 成员全查); 编排函数只读 entities.xml/components.xml/spaces.xml 三文件
- 记录开关机制: 记录 +0x85/86/87 = decider 对象 vtable slot0/1/2 三槽返回值; +0x87 非零才分配记录索引 (+0x82 计数器递增) = "进客户端体系/digest" 总开关, digest slot7 过滤用的正是它; decider 第三参 = {Base,Cell,Client} 三域存在性位图
- ★★client 方法真相 (本轮最大成果): 回放 1,265 个 0x08 方法调用包 (31 eid / 128 对 methodID) = 方法层运行时真值源, 全量命中 (Vehicle 的 showShooting/onHealthChanged/showDamageFromShot、Avatar 的 updateArena 等); onMethod (FUN_142a9b810) 真实过滤 = (flags & 0xC) != 0 (分布位, 与 exposed 标志无关); fork 给 client 方法自动 |=0x4 (机器码 377428-377429: if component==CLIENT, flags|=IS_EXPOSED_TO_ALL_CLIENTS)——v13 "client 方法全部出局"判反, 方法数 163→366 修正; defparse 的 flags 语义本来就对, 错误只在 digest_fork_v2 的过滤层
- ★网络 methodID 机制全解: 域内 isExposed (flags&0xC) → exposedMethods_ 列表 → stable_sort by streamSize (定长在前升序, 变长在后按 varLenHeaderSize) → 0 起编号——与属性 csi 排序同构; 排序器 key 取负致变长组反排的 bug 修复后 128 对真值全命中; digest 喂的 index = legacyExposedIndex (声明序计数器), 与网络 sorted 编号是两套体系, 双 index 变体实验均未命中
- ★entities.xml 真实声明序发现: 非字母序 (Account, Avatar, ArenaInfo, ClientSelectableObject, HangarVehicle, Vehicle=第6, AreaDestructibles=第7…); 0x05 创建块 1,833 个的 n 分布 {3:1, 6:247, 7:1578, 18:1, 28:1, 29:1, 40:4} 与索引对账: n=3=ArenaInfo, n=6=Vehicle (30 辆车 eid 546611517-546611546 全部 n=6), n=7=AreaDestructibles, n=29=AvatarInfo, n=40=NetworkEntity——索引 = space(0) + 声明序(1..40); defparse 本就按声明序加载, 顺序模型无误
- NetworkEntity n=40 载荷铁证: 4 个创建块载荷与 csi 表完美吻合 (scale=1,1,1 / unique_id=UUID / prefab_path="37_bridge_destruction_01" / name="Collisions")
- jsonl 的 m 字段 (方法名标注) = 生成器错位标注, 弃用 (其 README 警告应验)
- 修复后实算: digest = 5976CA145E07E97C627D8B40ED9952CF ≠ 目标 5DF886F75E73B33CFF9D87FB9C69389C; 主消融 = 16AE6853…; isVolatile=1 恰 1 处复核 (BattleRoyaleRadio 是纯 Volatile 空壳无属性); 消融矩阵全负
- 收尾: 本轮战报三条 (版本疑云彻底解除 / client 方法 163→366 / 主实体部分最高置信: 属性 40/40 + 方法全量 + 索引布局均有运行时真值锚); findings §12 未及写入即遭环境重置 (后由会话E Task 29 恢复); 下一步建议 = 录一场大逃杀/前线/背水之战回放取扩展实体与动态组件真值锚

Stage Summary:
- 0x3D 主线: 结构层 + 方法层 + 版本层全部闭合, 方法层有 decomp + vanilla + 0x08 运行时 128 对三方铁证
- 剩余偏差锁定: dyncomp 记录内容 (267/318 = 84% 无真值源); 破口 = 录扩展模式回放

===== 第四部分 · 会话D（第三次重置后 · 恢复轮 · Task 28 系列 · 2026-09-25）=====
> 本段含三条: Task 28（首轮恢复: worklog/findings 自 upload 复位 + 会话C 要点补录, 未竟）→
> Task 28-补（环境再次失守后的 GitHub 全量拉取重建, 自记为第三轮恢复）→ Task 28（门户架设收尾）。

---
Task ID: 28 (环境重置恢复)
Agent: main
Task: 用户问"你看看环境是不是又重置了"——确认重置, 盘点损失, 恢复工作区

Work Log:
- 重置确认: /tmp 全丢(ext_pkg 解压物/wot-src 镜像/partial clone/v1v2_changes.txt/wot_scripts/wot_src); /home/z/my-project 侧 scripts/ 全丢(digest_v8/v9/fork/fork_v2, verify_ext_pkg, ext_raw_decode_test, bwxml, csi_tables 等), download/ 清空(csi_tables_v8.json, ext_inventory.json), worklog.md/findings.md 主位丢失
- 幸存 (upload/ 全在): wotreplay/replay.jsonl/session×2/decomp.zip/BigWorld tar.gz/scripts.7z/wot_src.7z×2/tools/三件/backup_v5-v7/findings.md(至 09-24 第二轮=Task18)/worklog.md(至 Task 18)
- 恢复动作: ①worklog.md/findings.md 从 upload 恢复主位; ②py7zr 装入 venv python3(/home/z/.venv, 注意 pip=/usr/bin/python3 与 python3=.venv 不匹配, 需用 python3 -m pip); ③wot24_ext_defs.zip 重拉 GitHub 成功(528 条目, MANIFEST 243 行, 18 扩展目录, 220 def 含 _raw, 与 09-24 记录一致); ④scripts.7z 后台解压至 /tmp/wot_scripts
- 本 Task 已将 Tasks 19-27 要点自摘要固化补录(见上)

Stage Summary:
- 环境重置影响可控: 全部核心原料在 upload 幸存, 知识库(findings §3.6 digest 终版结构)幸存
- 净损失: digest 线脚本源码(v8/v9/fork/fork_v2)与 ext_inventory.json 需重建——算法知识完整保留于 findings.md §3.3-3.7, 重建路径清晰
- 主线未断: digest_fork_v2(18 扩展按 pkg 字母序并入)对目标 5DF886F7... 第一轮重算, 待 scripts.7z 解压完成后开工

---
Task ID: 28-补 (环境恢复第三轮: GitHub 全量拉取 + 工作区完整重建)
Agent: main
Task: 用户指令"现在别分析，把环境恢复，https://github.com/FengY233/test里的都拉下来，再把下载架上"

Work Log:
- 重置史澄清(本轮为第三次重置): 第一次重置后用户以 FengY233/test 仓库为资产云, 第二次会话(Task 18-26 新体系)完成 v9-v14 线(vtable 闭合/defparse 基线/FeatureExtension 发现/V11 交付包), 第三次会话(本 worklog 前段补录的"Task 19-27")完成 ext_pkg 十项对账+版本漂移调查后再次重置
- git clone FengY233/test 全量: 30 项资产全部落地 /tmp/wot/github_test (md5 抽验: scripts.7z=3291a197✓, replay.jsonl.zip 解压=0a88d349✓ 与 upload 一致, csi_tables_v8.json=5ac32922✓ 44158B)
- 关键恢复: findings(2).md(60216B) = v14 最新结论登记册(MD5Calculator vtable 全解§3/EntityDescriptionMap parse 白盒§9/FeatureExtension 体系§10) → 已置为主位 findings.md; V11 交付包内 scripts/{bwxml,defparse,digest_fork_v2,digest_fork_diag,ext_inventory,dat_strings2}.py → scripts/ 全部恢复
- 材料普查: wotexe.7z=WorldOfTanks.exe(78,777,520B 与 stubs/manifest.json 权威尺寸一致); replay.jsonl.zip=27.8MB md5 与 upload 逐位一致; 会话记录.txt(253KB/5887行)=v1→Task22 全程对话; 11 个 wotreplay 样本(20260905-0912 多地图多车型 + PTZ_10K + WZ-219)
- dec.7z.001/002 合并后打开失败: **AES 加密, 需要用户提供密码**(内容未验, 待问)
- upload/backup_v11_restore/(93MB) 建档: 全部新拉资产+11 回放, 防第四次重置
- download/ 重建: V11 交付包 zip + 报告 PDF/MD + xlsx + 解码 JSON + csi_tables_v8.json + ext_inventory.json + findings v14 + 8 图表 + 11 回放样本 + 封面 HTML + 审计 JSON
- 下载门户 file_server.py 重启(DESC 更新至 v11 版资产)

Stage Summary:
- 环境恢复完成度: findings(v14 主位)/scripts(6 脚本)/download(全部交付物)/upload(双备份) 四区齐备; 主线 digest_fork_v2.py 扩展版随时可开跑(输入 ext_pkg 已在 /tmp/wot, 模型脚本已恢复)
- 待用户: dec.7z 密码(加密分卷, 44MB)
- 会话谱系: 会话A(Task1-18) → 会话B(新Task18-26, v9-v14/V11交付) → 会话C(摘要Task19-27, ext_pkg对账+版本钉死#942) → 会话D(本轮, 恢复)

---
Task ID: 28 (门户架设收尾)
Agent: main
Task: 下载门户架设 + README/findings 同步

Work Log:
- file_server.py 升级(DESC/副标题/徽标 v11 化) → scripts/file_server.py, 双 fork 守护化启动 :3000
- 验证全绿: /health ok; 首页 13 条目渲染; 抽测交付包 zip 200/6254440B, charts png 200/334206B, 回放样本 200/2025112B, csi_tables 200/44158B (中文文件名 URL 编码正常)
- download/README.md 重写为 V11 资产清单; findings.md v14 三处同步 md5=19ead6b9 一致
- 会话B worklog(Task18-26) 已作为附录并入主 worklog

Stage Summary:
- 环境恢复四区齐备: findings(v14)/scripts(6+file_server)/download(全部交付物+11回放)/upload(backup_v11_restore 93MB)
- 门户常驻 :3000 (平台网关 81→3000), 可随时下载
- 待用户: dec.7z 密码(44MB AES 加密分卷); 主线恢复后 digest_fork_v2 扩展版随时开跑

===== 第五部分 · 会话E（续接 · v16 结论恢复 + V12 交付 · Task 29-30 · 2026-09-25）=====
> 即对话摘要中自称"会话D=本轮"的 V12 制作轮; 为避免与第四部分恢复轮混淆, 本合并版按实际时序编为会话E。

---
Task ID: 29 (v16 终局轮结论恢复 + digest_fork_v2 重建)
Agent: main
Task: 用户指令"你重新拉一下 https://github.com/FengY233/test，我更新了对话记录.txt，现在这个对话记录是最全的。findings(2).md 可能是倒数第二轮的，你通过对话记录把最后一轮的结论也恢复出来"

Work Log:
- 重拉仓库: 会话记录.txt 从 253KB/5887 行更新为 373KB/8389 行(+2502 行); 最新 commit 4567b52 (09-25 00:44 UTC)
- 通读会话C全程(行 7281-8389 = ext_pkg 到货后的最后三轮): v15 轮(u16 修复, findings(2).md §11 已收录) + v16 终局轮(对话记录尾部, findings 未及固化即遭第三次重置)
- v16 终局轮结论提取(全部落 findings.md §12): ①版本终局(#942 钉死, #938→#942 仅 6 文件零 def 变更, 0x3D=LogOnParams 客户端上行); ②client 方法自动|=0x4 三方铁证(decomp 377428 机器码 + vanilla 对照 + 0x08 运行时 128 对全命中)——v13「client 全出局」判反, 163→366 方法修正; ③网络 methodID 机制全解(exposedMethods_ stable_sort by streamSize, 与 csi 排序同构; digest index=legacyExposedIndex 两套编号); ④entities.xml 真实声明序发现(非字母序, 索引=space(0)+声明序) + NetworkEntity n=40 载荷铁证; ⑤jsonl m 字段=生成器错位标注弃用; ⑥digest_fork_v2 过滤修复: 三域统一 (flags&0xC)!=0; ⑦修复后 5976CA14 仍≠目标, 剩余偏差锁定 dyncomp 记录(267/318=84% 无真值源); ⑧下一步=录大逃杀/前线/背水之战回放取扩展真值锚
- 脚本重建: defparse.py 补 append_uint16(slot10 u16 喂入器语义); digest_fork_v2.py 从 V11 包 v14 版升级 v16 终态(u16 + 0xC 统一过滤 + 扩展层: loop#1 扩展实体/loop#2 扩展 dyncomp/FeatureName 字母序/多目录 def 跨包 Parent/扩展 decider client_files.txt)
- 调试修复 2 处: BattleRoyaleRadio 纯 Volatile 空壳(实体解析对齐 defparse._parse_interface, 不碰 Volatile 节); parse_ext_dyncomps 空返回路径补二元组
- ★复现验证: v16 模型输出 5976CA145E07E97C627D8B40ED9952CF 与最后一轮对话记录逐位一致; 318 记录(1 space+40 主实体+10 扩展实体+107 主 dyncomp+160 扩展 dyncomp)✓; 排除名单(主 ExtendedSPG/EnemyShotPredictorController/ArenaVehiclesInfo + 扩展 11 个)✓; isVolatile=1 恰 1 处✓
- 口径备注: V12 重建版方法统计 372(全量)/253(主消融) vs 对话记录 366/247, 差 6 为统计函数口径差(统计了 flags&0xC 通过但属静态挂载子描述的方法), digest 喂入流逐位一致(MD5 雪崩效应背书)
- findings.md 更新: 头部版本标记 v15/v16 + §12 全量新增(6 小节) + §6 开放项 v16 改写 + 附录 G(v16 证据坐标)/H(更新记录补遗)

Stage Summary:
- 最后一轮(v16)结论 100% 恢复并登记 findings.md §12; digest_fork_v2.py v16 终态重建并精确复现 5976CA14——重建脚本与丢失原版行为等价(最强验证)
- 0x3D 主线状态: 结构层+方法层+版本层全闭合, 唯一剩余自由度=dyncomp 记录内容(84% 无真值源); 破口路径=录扩展模式回放

---
Task ID: 30 (V12 交付包制作)
Agent: main
Task: 用户指令"之后在V11包的基础上做V12并打包，V12应包含一直到最后的全部结论"

Work Log:
- 增补物制作: 报告 MD +§21「V12 增补: 扩展 def 实算与方法层终闭合(v15-v16)」7 小节(1467→1544 行); xlsx +2 表(v16方法层修正 11 行 / v16方法ID与版本终局 11 行)→21 表; 解码 JSON +feature_extension_v16 段(22 顶层键); 审计 JSON +v16_revisions → 覆盖度终审_v12_audit.json
- 脚本升级: digest_fork_v2.py(v14→v16 终态: u16 + 0xC 统一过滤 + 扩展层 318 记录)+defparse.py(+append_uint16) 随包分发; 新增 update_xlsx_v12.py / update_data_v12.py
- PDF 处理: ReportLab 精排管线(md2pdf_v9/封面/merge)随第三次重置丢失, V12 沿用 V11 定稿 PDF(63 页 §20)——结论增量以 MD §21 + findings v16 为准(诚实声明写入 README)
- V12 包结构 = V11 结构 + 上述增补: 报告 MD/PDF + xlsx 21 表 + JSON 22 键 + csi_tables_v8 + ext_inventory + findings v16 + scripts 8 件 + charts 8 张 + 封面 + 审计 v12 + worklog(全谱系)
- worklog 谱系: 会话A(Task1-18 重建复述) + 会话B(Task18-26 原文附录) + 会话C(补录 19-27) + Task 28(第三轮恢复) + Task 29(v16 结论恢复+脚本重建) + Task 30(本节)

Stage Summary:
- V12 = 截至最后一轮的全部结论: findings v16(§12 终局轮全量登记) + 报告 §21 + 21 表 xlsx + v16 段 JSON + v16 终态脚本(5976CA14 复现验证)
- 0x3D 主线交接状态: 结构/方法/版本三层全闭合, 剩余=dyncomp 84% 无真值区; 破口=录扩展模式回放

---
Task ID: 30-补记 (V12 打包落地)
Agent: main

Work Log:
- V12 包: 27 文件 6.05MB, md5=0a3bbaabb1adcbd3fb3501c07ff5cd35; 已分发 download/ + upload/backup_v12/ + 门户 (下载 200/6343651B 实测)
- findings v16 三处同步 md5 一致; 门户 DESC 升级 V12 置顶

Stage Summary:
- V12 交付完成: 一直到最后一轮的全部结论已固化(findings §12 + 报告 §21 + 21 表 + JSON v16 段 + v16 终态脚本)
- 主线交接: 剩余 dyncomp 84% 无真值区, 破口=录扩展模式回放

===== 第六部分 · 会话F（worklog 全谱系合并 + V12 重打包 · Task 31 · 2026-09-25）=====

---
Task ID: 31 (worklog 全谱系时序合并 + V12 重打包)
Agent: main
Task: 用户指令——"我发现你现在的环境是最初的环境，你根目录的worklog.md保存了最初的记录。现在你根据根目录的worklog.md还有V12的worklog.md以及最新的对话.txt，做一个顺序正确且完整的worklog.md，打包到V12里，并替换掉你根目录的"

Work Log:
- 三源盘点: ①根 worklog.md(83,615B) = 会话A 原始记录(Task 1-18, 与 upload/worklog.md A 时代备份逐字节一致) + 其后各轮追加——但会话B 附录插在会话C 补录与 Task 28 之后, 系按"恢复先后"而非时间顺序拼接; ②V12 包内 worklog.md(83,101B) = 根版本缺 Task 30-补记(diff 仅此一处, 无独有内容); ③对话记录.txt(373KB/8,389 行, commit 4567b52) = 最全对话记录, 覆盖 v1→v16 终局轮全程
- git pull 确认 FengY233/test 无新提交, 对话记录.txt 已是最新
- 合并动作: ①按会话时序重排六段(A 原文 → B 原文 → C 补录+新增两条 → D 恢复轮 → E v16恢复+V12 → F 本轮); ②自对话记录.txt 行 7350-8389 恢复会话C 的「v15 攻坚轮」「版本漂移终局+v16 终局轮」两条过程条目(此前仅有 findings §11/§12 的结论登记, worklog 无过程记录); ③文件头新增合并说明(三源/谱系/重置史/编号说明); ④各段加谱系标题, 会话B 段头注明其"Task 1-17 历史复述"因会话A 原始记录在位不再收录
- 修复门户遗留 bug: scripts/file_server.py 第 22 行 V11 描述文本掉出字符串引号外(SyntaxError——Task 30 时代 DESC 编辑事故, file_server.log 留有重启失败 traceback; 旧进程一直在跑 V11 版页面, "DESC 升级 V12"实际从未生效); 修正该行 + DESC 全面 v12 化(findings v16/21 表/22 段 JSON/审计 v12 条目/徽标改 dyncomp 口径/推荐语文件大小改为动态计算) + 语法校验通过后重启守护进程
- README 更新两行: worklog 描述由"会话A(Task1-18 重建)"更正为"会话A(原始记录)+时序合并版"并补 v15/v16 恢复条目与合并轮
- V12 重打包: 27 文件不变(仅 worklog.md 与 README.md 内容更新), 分发 download/ + upload/backup_v12/ + v12_stage; 根目录 worklog.md 同步替换为合并版, 与包内逐字节一致

Stage Summary:
- worklog 谱系完整闭合: 会话A(原始) → B(V11 原文) → C(补录 + v15/v16 恢复) → D(恢复轮) → E(v16 恢复 + V12) → F(本合并)——时序正确、无缺轮、同号异会话已分段消歧
- V12 包内 worklog 与根目录主位同源同步; 门户 DESC 修复重启后 V12 置顶真正生效
- 主线状态不变: digest 剩余自由度 = dyncomp 记录(84% 无真值源), 破口 = 录扩展模式回放; dec.7z(44MB AES 分卷)密码仍待用户提供

===== 第七部分 · 会话G（11 场新回放真值锚轮 + 三源解压 + V13 交付 · Task 32 · 2026-09-25）=====

---
Task ID: 32 (新回放分析 + decomp/BigWorld/wot-src 三源就位 + V13 交付)
Agent: main
Task: 用户指令——①"仓库里其他的 wotreplay 就是我新提供的（不全是国服 942，但能在 942 客户端上播放）"；②"decomp、BigWorld 还有 wot-src 你看解压过没有，没有的话就解压"；③"看看我新提供的（回放）"；④"记得每次会话都要更新打包交付包"

Work Log:
- dec.7z 密码验证（114514.1919810）：打开成功，内容=decomp.zip 单文件，md5 48683ebc 与 upload/decomp.zip 逐位一致——第四份 decomp 副本，无新信息
- git pull FengY233/test：无新 commit（4567b52 即最新，10 个新回放已在本地）
- 三源解压盘点与补齐：decomp 已解压（356MB，180027 函数三区齐备）；wot_src 从 upload 分卷合并解压（653MB，wot-cn 2.4.0.0 #942，与用户钉死 commit 59e92351 吻合，exe sha256 链条对上，无需重拉 GitHub）；BigWorld-Engine-14.4.1 tar.gz 440MB 同步解压完成（36,792 文件 1.4GB，首次 nohup 后台被杀 378 文件，重跑同步解压成功）
- /tmp/wot_scripts 恢复：scripts.7z 22MB 解压（服务器 scripts，digest_fork_v2 输入材料就位）
- 11 场回放普查（survey_new_replays.py）：block0 元数据 + 包型直方图 + 0x3D 提取。判定 battleType=46（tundra 场）= ARENA_BONUS_TYPE.RANDOM_NP2（constants.py:292）——随机战变体非扩展模式；11 场全部随机战家族
- ★0x3D digest 恒定性发现：11 场（EU×7/NA×1/CN×3、8 天跨期、mods 混合）全部 = 5DF886F75E73B33CFF9D87FB9C69389C（目标值）→ digest 身份终局定性：#942 客户端安装指纹，与对局内容/区域/mods 无关
- 0x05 头格式钉死：[u32 eid][u32 typeID]（jsonl 1,130 对 + 跨场共 1,486 对校准零失配）
- ★typeID = entities.xml 声明序 1 基编号：40 实体全表对齐；网络创建实体集 9 种 {3,6,7,12,13,18,28,29,40}；ArenaInfo/TeamInfo/AvatarInfo/EmptyEntity 每场恰 1；DetachedTurret 3 场（脱炮塔车）、DebugDrawEntity 仅 bt46 场、NetworkEntity 6/11 场（与 §12.4 n=40 铁证互证）；无任何扩展实体
- ★methodID 机制语义级验证（methodid_tables.py 复用 digest_fork_v2 组件装载 + §12.3 排序规则）：每场恰 1 个未识别 0x08 eid（恒晚于全部 0x05 实体）→ 识别为 Avatar（70 client exposed 方法全覆盖 18 观测 mid；Account 41 仅 11 淘汰）；18 mid × 11 场行为学全吻合（stopTracer/updateVehicleAmmo 全场、onRoundFinished 仅 6 场打完、showHittingArea 恰 4 场有 SPG、enemySPGHit 恰 2 场被火炮命中）；Vehicle 表 8/11 方法吻合（showDamageFromShot 1931 次最高频）
- ★jsonl m 字段错位最终实锤：mid=58 = stopTracer 非 updateArena（真 updateArena 是 mid=21）
- findings.md 更新至 v17：头部版本行 + §6 开放项改写（BigWorld 源码备选路径入列）+ §13 全新增（6 小节 + 附录 I 证据坐标）
- V13 交付包制作（基于 V12）：findings v17 + worklog 本轮 + 11 场普查/实体锚/methodID 表 JSON + 6 个新分析脚本 + README 更新

Stage Summary:
- 四项独立成果入库：①digest=客户端安装指纹（11 场恒定实锤，复现目标锚死干净 #942 scripts）②0x05 typeID=声明序 1 基（9 种网络创建实体矩阵）③methodID 机制 11 场语义级验证（Avatar 70 方法表 + 18 mid 行为吻合）④jsonl m 错位实锤
- 主线状态：0x3D 剩余自由度仍为 dyncomp 84% 无真值区（11 场全随机战未覆盖扩展实体）；破口仍是录扩展模式回放；新增备选路径：BigWorld vanilla C++ 源码直接审 exposedMethods_/MD5Calculator 实现（已解压就绪）
- 环境：三源（decomp/wot_src/BigWorld）+ wot_scripts + ext_pkg 全部就位；dec.7z 密码已登记

---
Task ID: 32-补记 (V13 打包落地)
Agent: main

Work Log:
- V13 包: 41 文件平铺 6.42MB, md5=6ad34ecf1cc399b10f40f27a628e5284; 结构 = V12 + data_v17/(4 JSON) + scripts +7 件(共15) + 报告 §22(1586 行) + findings v17(581 行, §13 六小节 + 附录 I) + worklog(847→849 行, 会话G/Task32) + 审计 v13
- 分发: download/(包 + 报告 MD + 审计 v13 + data_v17/ 目录) + upload/backup_v13/(包 + worklog + findings_v17); findings 四处 md5=dc3053f0 一致
- 门户: DESC 全面 v13 化(新增 v13 条目/data_v17 条目/审计 v13), 排序改为版本号降序(最新置顶), 杀旧进程(pid 3642, cmdline 无 file_server 字样 pkill 漏杀)重启; 验证 health ok / v13 zip 200 6.42MB / data_v17 中文路径 200 / v13 置顶首行

Stage Summary:
- V13 交付完成: 11 场新回放真值锚轮全部结论固化(findings §13 + 报告 §22 + data_v17 + 7 脚本)
- 主线交接: digest=客户端安装指纹已实锤, 剩余 dyncomp 84% 无真值区, 破口=扩展模式回放, 备选=BigWorld vanilla 源码白盒

---
Task ID: 33 (会话I · 技能体系分离 + 动态组件通道轮)
Agent: main

Work Log:
- 状态核对：V13 已交付（Task 32-补记）；发现会话H（09-25 02:40-02:58）13个脚本（tier11_skill_probe/p39系列×7/pp_skill_roster/pet_correlation）未入 worklog 即断线——全部重跑恢复并整合
- block0 全字段提取（block0_full.py）：clientVersionFromXml 构建号全表——3×CN#942 + 3×EU#935 + 4×EU#944 + 1×NA#945；用户"仅1场CN942"实证修正为3场（1534/1749/1801，1534与1801同玩家）；外服8场确实均非#942
- ★digest 定性修正：4构建×3区域×6服务器×mods混合全部恒等目标值 → 推翻 v17"#942客户端安装指纹" → 2.4.0.0世代全局统一 EntityDescriptionMap 指纹；§11.5 数据同期性假设①②③全部排除（ findings §14.1）
- 名册矩阵（roster_matrix.py）：314车 vehPostProgression 全量——低4位恒=0x4 的 (位图<<4)|4 packed；同车型 HP 随技能节点浮动（Cz46 2270→2610）；新一代车型几乎全员带vpp
- ★技能体系三分离 def 级实证：csi34 perks(乘员,Perks_Vehicle) vs csi44/45 vehPerks/vehPostProgression(车辆技能)；0x07 键33/34 活跃更新 vs 45 零更新；Vehicle 0x08 mid 差分=纯内容差异(+3/+6/−7)无结构性新mid → 技能不走实体方法通道
- ★0x07 原始格式钉死：[u32 eid][u32 key][u32 blen][body]（p07_align.py 37,105/37,105 全命中）；11场 csi 键空间 max 34-38<50 → 组件属性不走 0x07（准静态）
- ★0x05 创建块全格式：[eid][typeID][10B头][pos][ypr][u32 propBytes][u8 count]×([u8 csi][typed value])；propBytes 100% 自洽；health/avatarID/isCrewActive 语义锚逐车吻合；1,092 车 avatarID join 全唯一
- ★★CSI≥50 扩展区 = 动态组件属性通道（本轮最大发现）：0x05 索引空间 = 实体自身(0-49)+挂载组件(50+)；Vehicle 静态挂载 VehicleInBattleSwitch 为空组件 → 50+ 全部来自运行时 dyncomp；1,092 车扩展区 45-208B；有vpp车 extlen 中位117 vs 无vpp 93（+25% = 技能组件字节签名）——dyncomp 从"网络不可见"变"0x05可观测"，84%无真值区的真值锚通道打开（findings §14.5）
- 0x39 = 游戏对象复制流定性：仅4 EU场、全部=录像玩家本车、全部带vpp+activePetID=1；72B(0x44)/41B(0x25)、const8/seq链/pos+矢量(|v|∈{720,880,1000})；NetworkReplicationPointComponent.def status ARRAY<GAME_OBJECT_STATE_INFO{prefabPath,recreateMethod U8,networkID U32,parentID U32,active BOOL}> 对位——首个同时具备 def 输入与运行时字节流的 dyncomp；宠物装备假设证伪（9/11装备但仅4场有流=部署态遥测）；pet_correlation dbid≠eid bug 定位
- BigWorld vanilla 参考实现就位：client_interface 消息序/replay_data 块枚举/BWEntity::onProperties([u8 size][u8 index][value])/Array|Tuple|String DataType::addToMD5（"Array\0"+size_+dbLen_条件+递归）；defparse.py 逐字节一致获 vanilla 级背书
- findings v18：头部版本行 + §13.2 勘误标记 + §14 全新增（8 小节 + 附录 J）；三处 md5=e4850907 同步
- V14 交付包制作 + 门户刷新

Stage Summary:
- 六项入库：①回放归属终局(构建号全表,digest定性修正,同期性假设清零) ②技能三分离(csi34乘员 vs csi44/45车辆,0x07互证) ③0x07格式钉死 ④0x05全格式+语义锚 ⑤CSI≥50动态组件通道(+25%技能签名) ⑥0x39游戏对象复制流
- 主线状态：dyncomp 84% 无真值区的破口从"扩展模式回放(用户已否决)"切换为"0x05 CSI≥50 扩展区类型驱动全解码"——下一轮(Task 34)目标：组件def库+挂载集推断+逐条目walk，把无真值区压到接近零
- 环境：block0_full/roster_matrix/veh05_ext/veh_decl_table/p07_csi_scan 五份新数据 + 11个新脚本入库；vanilla 参考坐标已登记

---
Task ID: 33-补记 (V14 打包落地)
Agent: main

Work Log:
- V14 包: 66 文件 6.68MB, md5=dd93b88d25099d6b428af3679a19ee7f; 结构 = V13 全量 + data_v18/(7 JSON) + scripts +20件(共35) + findings v18(669行, §14 八小节 + 附录J) + worklog(883行, 会话I/Task33) + 审计 v14
- 分发: download/(包 + data_v18/ 目录实体) + upload/backup_v14/(包 + worklog + findings_v18); findings 三处 md5=e4850907 一致
- 门户: DESC v14 化(新增 v14/data_v18/审计 v14 条目, v13 描述去星改历史口径, badge 全面刷新为技能分离+组件通道结论), 推荐位改 v14(66文件), setsid 重启(直连 nohup 会随会话被杀, 改用 setsid 常驻); 验证 health ok / v14 zip 200 6.68MB / data_v18 目录+中文文件名 200 / v14 置顶

Stage Summary:
- V14 交付完成: 技能体系分离 + 动态组件通道轮全部结论固化(findings §14 + data_v18 + 35 脚本)
- 主线交接: dyncomp 真值锚通道已打开(0x05 CSI≥50 扩展区), Task 34 = 扩展区类型驱动全解码(组件def库+挂载集推断+逐条目walk) → 目标把 84% 无真值区压到接近零

---
Task ID: 34 (会话J · 0x05 属性流终局 + MY_VEHICLE 分层 + 网络索引重排)
Agent: main
Task: 用户指令——"继续，彻底把回放全部内容研究透彻，记得同时参考scripts、decomp、wot-src、bigworld等数据源"

Work Log:
- 状态核对：V14 已交付（Task 33-补记）；Task 34 目标已在 findings §14.5 预登记（扩展区类型驱动全解码）
- 四源联动定位：BigWorld vanilla（线编码/排序/发送侧白盒）+ decomp（客户端解析函数）+ wot_scripts（服务器 def 真值）+ 11 场回放（1,092 车观测）
- ★vanilla 发送侧全解（witness.cpp sendCreate → EntityCache::addOuterDetailLevel → addChangedProperties）：[u8 numToSend][[u8 i][value]] + LoD detailLevel 匹配过滤 + 事件戳条件
- ★客户端解析白盒（decomp FUN_140395c60 区 = PyEntity::initCellEntityFromStream, py_entity.cpp:0xbb）：[u8 count] 循环 [u8 idx] → FUN_142a93050 归属（idx<size 实体 / idx-comp.base 组件）→ FUN_142a8e490 DataDescription → 读值——与 vanilla 逐语句对应
- ★线编码规则全集（vanilla data_types 逐文件）：packedInt(<0xFF 单字节)、定长直出、变长 SEQ=[n][元素]、STRING/PYTHON=[len][B]、FD allow_none=[u8 0/1]、定长 TUPLE 无头直出
- ★四实体 0x05 铁证（other_entities.py）：NetworkEntity count=3 三例逐字节吻合（scale VECTOR3+uuid STRING+prefab_path STRING）、AreaDestructibles count=4 与 jsonl t=5 tail 完全一致、typeID28/29 单例结构可解——0x05 属性流=vanilla 纯格式终局
- ★条目序=事件序钉死：Vehicle 基础段 [1,5,13,14,16,32,15] 乱序观测 + 解析端不依赖顺序——推翻「按 csi 升序」隐含假设
- ★vpp idx=40 铁证（csi_anchor.py）：754/754 有 vpp 车 ARRAY<I32> 值字节前导恒 0x28(40) 零偏差——csi 表 v8 的 45 被推翻
- ★★MY_VEHICLE 分层发现：Vehicle.def DetailLevel=MY_VEHICLE 10 属性（6 变长 crew/enh/setups/setupIdx/vehPerks/disabled + 4 定长 isMyVehicle/quickShellChangerFactor/onRespawnReloadTimeFactor/ownVehiclePosition）——外层 AoI 创建不发、本车专属——0x07 key29/30 仅 2 次、0x39 仅本车、ownVehiclePosition 专属三证据互锁
- ★网络 idx 重排数学全解：变长组剔 5 个 MY_VEHICLE（vpp 前）→ vpp 45→40 ✓；定长组 0-30 原样（0x07 key1-38 全吻合）；0x05=过滤重排版 / 0x07=全属性版双空间模型
- ★alias 级 AllowNone 发现：alias.xml 97/202 带 AllowNone（defparse 漏读，影响线编码 None 标记；digest 影响 Task 35 评估）
- 组件体系三级迭代（compdef_dump→comp_global→comp_table）：components.xml = 16 static + 113 dynamic 注册表 + 85 组件 185 CS 属性表（OwnVehicle 23/Fire 1/HealthComponent 2/VehicleBuff 3/NetworkReplicationPointComponent 2…）
- ★同型车模板恒定性：184 组中 62 组（33%）扩展区逐字节全同（A38_T92 18 辆全同 73B）——组件段=车型模板，玩家值全在实体段
- 尾部骨架熵剖析（tail_align.py，586 车对齐 -44..+47）：恒 0 区/条件区（28 01 vpp 68%）/f32 锚（4976/4884/2624）/09 42 模式定位
- 0x07 key 全表汇总（p07_csi_scan 复用）：11 场 key{1,4,5,13,14,15,16,22,23,27,29,30,33,34,38} 全部与表 v8 streamSize 吻合——0x07 空间确认
- findings.md 更新至 v19：头部版本行 + §15 全新增（7 小节 + 附录 K）
- 残留（Task 35 方向）：①0x05 网络重排表的 41-49 区间锚定（healing/healOT/dogTag 位置）②扩展区组件段 idx 空间规则（每车挂载集顺序编号）③07/15 逐节点条目族归属④09 42 尾部语义⑤defparse 双表输出（digest 表+网络表）⑥alias AllowNone 对 digest 的喂入影响

Stage Summary:
- 六项入库：①0x05 属性流 vanilla 纯格式四实体铁证 ②线编码规则全集（packedInt/FD allow_none/定长 TUPLE 直出）③MY_VEHICLE 分层（10 属性本车专属，三证据互锁）④网络 idx 过滤重排（vpp=40 铁证 + 0x05/0x07 双空间模型）⑤alias AllowNone 97/202（defparse 漏读新维度）⑥组件注册表+CS 属性表+同型模板恒定性
- 主线状态：0x05 解码器所需的「类型系统+索引系统」两层地基已齐——Task 35 = 网络 idx 重排表全锚定 + 组件段 idx 空间规则 + 完整解码器实现，把扩展区从「骨架剖析」推进到「逐条目语义解码」
- 环境：四源全部就位且本轮全部触碰（scripts 12 个新脚本 / decomp 3 个新函数白盒 / wot_src 客户端资源核验（entity_defs 仅 alias.xml，def 从网络解析）/ bigworld 6 个源文件白盒）

---
Task ID: 34-补记 (V15 打包落地)
Agent: main

Work Log:
- V15 包: 81 文件 6.39MB, md5=805589b6dc4932132872b87e05d4fd76; 结构 = V14 全量(66) + data_v19/(2: remap 表 + ext_cluster 1092 车) + scripts +13件(共48) + findings v19(757行, §15 七小节 + 附录K) + worklog(925→934行, 会话J/Task34) + 审计 v15
- 修复打包 bug: V14 解包文件经 tmpfile 中转被循环覆写致内容同质化(0.32MB) → 改 writestr 直写(6.39MB), 大文件抽验完好(5.16MB JSON 头部正确)
- 分发: download/(包 + data_v19/ 目录 + 审计 v15) + upload/backup_v15/(包 + worklog + findings_v19); findings 三处 md5=6cae0619 一致
- 门户: DESC v15 化(新增 v15/data_v19/审计 v15 条目, v14 描述去星改历史口径), 推荐位改 v15(81文件); 进程守护升级: setsid 仍被会话清理 → launch_v15.py double-fork daemonize(PPID=1 脱离); 验证 health ok / v15 zip 200 6.70MB(传输尺寸) / data_v19 目录+JSON 200 / v15 置顶首行 / 推荐段正确
- 门户新增脚本 launch_v15.py(双 fork 守护启动器, 后续会话重启模板)

Stage Summary:
- V15 交付完成: 0x05 属性流终局 + MY_VEHICLE 分层 + 网络索引重排轮全部结论固化(findings §15 + data_v19 + 48 脚本)
- 主线交接: Task 35 = ①网络 idx 重排表 41-49 全锚定 ②扩展区组件段 idx 空间规则(每车挂载集顺序编号) ③07/15 逐节点条目族 ④09 42 尾部语义 ⑤defparse 双表输出 ⑥alias AllowNone 对 digest 喂入影响——目标: 完整 0x05 语义解码器

---
Task ID: 35 (会话K · 0x05 全通道语义解码终局 —— 推翻扩展区 + RULE X 网络表)
Agent: main
Task: 用户指令「继续吧」——执行 Task 35 六项残留（网络 idx 重排表 41-49 锚定 / 扩展区组件段 idx 规则 / 07/15 条目族+09 42 尾部 / defparse 双表 / alias AllowNone digest 影响 / 完整 0x05 解码器）

Work Log:
- 材料四源就位复核：wot_scripts 服务器 def 真值（68 属性 Vehicle.def + 16 接口 + alias）/ decomp（c_1428d1e40 + c_1402c13f0）/ bigworld vanilla / 11 场回放（补上 v19 遗漏的 tundra 场）
- 手工走段三例（UDES/J40/CH74）发现 publicInfo FD 完整走通（name/compDescr/outfit/14 字段, maxHealth=health 双吻合）落在 idx 32 而非 v8 的 37——**v8 变长序被推翻**
- NetworkEntity 63 例 idx 集合恒 {0,1,3}（.prefab 串@3）+ Vehicle vpp@40/publicInfo@32 双锚 → 推导变长组重排；0x07 key23 body=FLOAT8 时间戳（stunInfo）钉死 0x07=同表空间
- key34 body=`01 43`（ARRAY<INT1> 元素）排除 perks(17B 元素)、key38 body=`\x80\x02`+pickle 元组 (1,1,2,0)（PYTHON 专属）——0x07/0x05 单一统一空间三重判别
- dogTag@48 判定：BATTLE_DOG_TAG 双数组+showDogTagToKiller 结构（2×9B 元素 {id i4, progress f4, grade u8}）唯一吻合；v19 尾部锚「2c 01/f32 4976/4884/2624/09 42」全部重定性为 dogTag 值内容
- **RULE X 定案**：定长组 0-30=v8；变长组 31-40=自有 def 变长 1-10 声明序、41-44=Wheels/Perks 接口变长、45-48=自有 11-14、49=perksRibbonNotify
- **验证矩阵全满分**：walk 1124/1124（11 场含 tundra）、eid-join 1092/1092、publicInfo.name==fakeName 1092/1092（WoT 匿名化机制发现——v19 的 6 例 name 不匹配即匿名玩家）、maxHealth/stFrags/team 各 1092/1092、vpp 754/754、字节精确吃满 1124/1124
- ★★历史性推翻：**0x05 根本没有组件扩展段**——v18 §14.5「CSI≥50 动态组件通道」= publicInfo 误走伪影（compDescr/outfit 值字节被当 idx）；「同型车模板恒定/Tier XI 签名/07 XX 08 YY 条目族」全部重定性
- eid==roster.avatarSessionID join 修正（v18 的「csi16 avatarID=avatarSessionID」实为首字段 eid 子串命中）；avatarID 属性值=Avatar 实体 id（eid+27/+57 观测）
- 全实体类型推广：AreaDestructibles(tuple3/tuple5 元素宽) 5679/5679、NetworkEntity 63/63、TeamInfo 11/11、AvatarInfo 11/11、DetachedTurret(compDescr+outfitCD) 10/10、DebugDrawEntity 1/1——**6,899/6,899 字节级 100% 精确零错误**
- ★运行时 def≠wot_scripts 副本铁证：typeID 28 流=4 CS 属性 {INT4,STR×3} vs 副本 TeamInfo.def 仅 1 属性——digest 偏差归因（v16「锁定 18 ext 记录」）需重估，def 内容漂移也是偏差源
- decomp 排序函数白盒：FUN_142a8dff0（N<33 插入/N≥33 归并+baseIndex 赋值）/FUN_142a8c240（比较器=vanilla 逐分支）/FUN_142a89f90（变长 streamSize=-vlh）/parseProperties 360489 区（clientServerFullIndex=size+baseIndex）——排序机制与 vanilla 同构，接口变长后置的 vlh 赋值疑在服务器端 def 差异
- 35-d 闭环：vanilla FD addToMD5 喂 allowNone（1 字节 bool）↔ defparse 已同构实现——alias 级 AllowNone 无漏读
- 0x24 通道侦察：键=(N<<8)|flag，N=17/18 全车辆 eid / N=4/5/6/7 全非车辆——多实体类型属性更新通道，body 含 -1.0 哨兵与战斗时钟 f32——组件属性候选通道（Task 36 主攻）
- findings.md 更新至 v20：头部版本行 + §16 全新增（6 小节 + 附录 L）；v19 §15.4/15.5 标记已被修正
- 交付物：p05_decoder.py（终局解码器）+ net05_table.py（验证器）+ p07_keybody.py/p05_idx_hist.py/p05_entity_scan.py/p05_fulldump.py/vdef_dump.py（取证链）+ net05_table_v20.json + p05_decoded.json(6899 条)+紧凑版

Stage Summary:
- 六项残留全部处置：①41-49 锚定=RULE X（dogTag@48 结构级+三锚验证）②扩展区 idx 规则=不存在（伪影推翻）③07/15 条目族+09 42=outfit/dogTag 内容重定性 ④defparse 双表=网络表以 net05_table_v20.json 交付 ⑤alias AllowNone=无 digest 影响（闭环）⑥完整解码器=6,899/6,899 精确
- 主线交接：Task 36 = ①0x24 通道语义解码（组件属性候选通道，N 键空间+body 类型族）②运行时 def 漂移清单（TeamInfo+3 已证，Vehicle vlh 疑似）→ digest 偏差重归因③41-47/49 推断位的运行时锚定（healing/healOT 更新流）④RULE X 机制解释（服务器 def 差异假设的验证路径）
- 环境：本轮新增脚本 7 件（scripts/ 共 55 件）；四源全部深度触碰（decomp 4 个新函数白盒 + vanilla 3 个源文件 + wot_scripts def 全量 + 11 场回放全量）

===== 第八部分 · 会话L（第4次重置恢复轮 + Task 36 主线 · 2026-09-25）=====

---
Task ID: 36 (会话L · 第4次环境重置确认与全量恢复)
Agent: main
Task: 用户报告「看不到门户下载了（已用官方功能拿到 V16），环境没回退吧？」——体检确认回退并全量恢复

Work Log:
- 回退体检: /tmp 全丢(github_test/wot_scripts/repos/wotexe_x/ext_pkg) + scripts/ 全丢 + download/ 清空 + 根 worklog/findings 主位丢失 + 门户 :3000 下线; upload/ 完好(backup_v5~v16 全谱系 + decomp.zip/scripts.7z/BigWorld tar.gz/wot_src 分卷/11场回放/dec.7z 分卷/wotexe.7z)
- 阶段1(scripts/restore_after_reset4.py): 根 worklog.md(968行全谱系)+findings.md(v20) 复位; scripts/ 62件自 V16 包解出; download/ 36件+zip 本体复位; file_server.py :3000 重启(/health ok)
- 阶段2a(restore2_materials.py, 5min 超时拆分): 11场回放 → /tmp/wot/github_test/; scripts.7z → /tmp/wot_scripts/(Vehicle.def 在位)
- 阶段2b(restore2b_bg.sh 后台): decomp.zip(58条目/355MB) → /tmp/my-project/repos/decomp(index.tsv 验证 FUN_142a7fbb0→c_1428d1e40.c); wot_src_merged.7z/wotexe.7z/BigWorld tar.gz 排队解压中
- 阶段2c(restore2c_dec.py): dec.7z 分卷合并 44.2MB md5=3bf3f80d97fc7bc8920306f35475492a, 密码 OK; ★真相定案: 内层仅 1 条目 = decomp.zip 本身(md5=48683ebc708a9241b6e5be41c9a00d3f) 与 upload/decomp.zip 逐字节一致 —— dec.7z 即 decomp.zip 的 AES 加密容器, 「md5 校验待办」闭环, 无新信息
- ext_pkg 重拉: GitHub FengY233/test wot24_ext_defs.zip(349KB) → /tmp/wot/ext_pkg/extracted/wot24_ext_defs/(528条目/18扩展/220def, 与会话D 记录一致) —— digest_fork_v2.py 输入就位
- 依赖: py7zr 重装(1.1.3); p7zip 原生工具无 root 不可装, 大解压走后台 nohup

Stage Summary:
- 环境四区齐备: 工作区(scripts 65件) / 材料(回放+wot_scripts+ext_pkg+decomp 在位, wot_src/wotexe/BigWorld 后台) / 交付(download V16 完整) / 门户(:3000 上线)
- dec.7z 定案: decomp.zip 的 AES 容器(密码 114514.1919810), 反编译真值=decomp.zip 55 文件
- 主线继续: Task 36 研究项 ①0x24 通道语义解码 ②运行时 def 漂移清单→digest 偏差重归因 ③41-47/49 推断位运行时锚定 ④RULE X 机制解释

---
Task ID: 36-续 (会话L · Task 36 研究项①完成: 0x24 通道全协议白盒)
Agent: main
Task: 环境恢复后继续 Task 36 四项之一 —— 0x24 通道语义解码(组件属性候选通道)

Work Log:
- p24_probe.py 侦察: 5,241 包全部 <64B; hex dump 破译包头 [eid u32][mt u8][len u32][payload](len 恰好吃满 5,241/5,241)
- decomp 白盒: c_140495d70.c L200180 `FUN_1405846e0(puVar4, 0x24, uVar7, iVar5+9)` → FUN_140587300 = WGReplayMessageHandler::getFile(wg_replay_message_handler.cpp:1570), 逐行验证 [eid][isSlice][len][MemoryIStream]
- vanilla 对照: bigworld lib/connection/server_message_handler.hpp:82-85 onNestedEntityProperty(id, data, isSlice) + client_interface.hpp nestedEntityProperty/sliceEntityProperty 双 VARLEN 消息 + server_connection.cpp:1058-1072 处理器 —— 0x24 = 嵌套/切片属性更新(getFile 为 WoT 录制钩子) 三方闭环
- payload 破译: entitydef/property_change_reader.cpp readCompressedPathAndApply + property_change.cpp addCompressedPathToStream 逐行对照 → 压缩路径位流: [1][csi: bitsRequired(numCS)][下钻*][0][Single leafIdx | Slice start/end]; BitReader MSB-first(cstdmf/bit_reader.cpp 逐位移植, 修复 8-take 移植 bug)
- csi 命中: Vehicle 6bits → 33 perkEffects(n=1497)/29 ownVehiclePosition(496)/34 perks(170)/30 inspired(168); AreaDestructibles 2bits → 1 destroyedFragiles(2173)/3 fallenTrees(573)/2 fallenColumns(90)/0 destroyedModules(74) —— 全部 ARRAY/FIXED_DICT 嵌套类型, csi 表(§1)双通道复验
- 旧报告 v6「0x24=火炮瞄准装填参数」推翻: 'ba 01' 开头 = 位流 [1][csi=29 ownVehiclePosition] 字节形态, 非属性号
- 值段深挖(p24_deep/p24_slice/p24_var29): AllowNone FIXED_DICT=[u8 hasValues] 双通道实证(0x07 csi=30 body='00' ↔ fixed_dict_data_type.cpp:108); perks slice(0,2)+0B×159=数组删除; ownVehiclePosition 17B 值字节方差分层([u16 场常量][u16 0][u8{0,1}][f32 -1.0 哨兵][f32 0.1 族尾数][f64 大数 11-14 万]); 19/20B 包 = 位头 0/1 层字段下钻之差
- 类型树就位: defparse 加载 wot_scripts 全模型(76 属性), OWN_VEHICLE_POSITION/INSPIRED_EFFECT/PERK_EFFECTS/PERK_INFO_HUD alias 全解; Perks_Vehicle.def 接口(perkEffects/perks DetailLevel=MY_VEHICLE)
- 交付: p24_probe/p24_decode/p24_bitpath(+BitReader 库)/p24_bitpath2/p24_deep/p24_slice/p24_var29/p24_final 8 件 + p24_keys.json/p24_top_csi.json/p24_final.json(5,241 行)
- findings.md v21 §17 新增(6 小节); dec.7z 真相(AES 容器=decomp.zip)入档 §17.5

Stage Summary:
- Task 36① 完成度: 协议级 100%(包头/位流/csi/slice 语义/全量分类), 值段字段级 ~60%(结构钉死, 场常量 u16 与 f64 大数语义待 Task 37)
- 5,241/5,241 包全分类; 5080 值段可切出; 161 nested 深层包待状态机
- Task 36②③④(def 漂移清单/41-49 锚定/RULE X 解释)未动 —— 与 Task 37 值段细化合并为主线下轮
- 环境: BigWorld 六子树 + wot_src 关键 19 文件就位; wot_src 全量后台解压中(wot_src_extract.py Popen 守护)

---
Task ID: 37 (会话M · 0x24 终局重解轮)
Agent: main
Task: 估算总进度 (~88%) 后继续攻坚 Task 37：0x24 值段字段级语义

Work Log:
- 环境体检: 四区齐备(scripts 62件/worklog/findings V21/download V16-17/门户 :3000 pid 1107 在线)，wot_src 后台解压已完成
- 类型树提取(t37_alias2.py): OWN_VEHICLE_POSITION={VECTOR3,VECTOR3,F32,F32}+AllowNone / INSPIRED_EFFECT={BOOL,F64×4,BOOL,U16}+AllowNone / PERK_EFFECTS={equipment:ARRAY<STRING>}；AreaDestructibles 四数组=TUPLE<u8,3/5>
- 位级手工解码(t37_hand2/t37_bits): 发现 v21 值起点错位；bitsRequired 语义复核(vanilla: 值域 0..n-1)
- ★关键实验 AD fallenTrees(karelia eid 3116316 五连包): 数组增长→slice 位宽 0→1→2→3bit 精确漂移，insert 语义 (k,k)+TUPLE5 全对上 → vanilla 位语义确认，v21 固定 6+6bit 假设推翻
- 通道真身修正: v8 csi 表 31-49 与 v20 RULE X 不一致；33=damageStickers(非 perkEffects!) 34=publicStateModifiers(非 perks!)；33/34 状态机验证 1,667/1,667（含 0x05 重创建重置修正 175 次）
- 7bit 首层假设系统排除(t37_7bit): 58/60/66/68 聚集是 6bit 读法的超集假象；decomp FUN_142a7bfa0→FUN_142a8e570getNumOwnedProperties=desc+0xfc；Harm 接口 BLOB 陷阱破解(b64) 后 76 属性声明序确认
- Vehicle 通道 29/30 状态机(t37_sm3 三迭代): 元素结构钉死 18B/13B；修 per-channel 状态键 + gen 计数 off-by-one → **496/496 + 168/168 = 100%**
- 终态解码器 p24_decode_v2.py: **5,241/5,241 = 100% 全量精确解码** → /tmp/wot/p24_final_v2.json（结构化元素含字段值）
- 字段统计: csi29 A∈[101,502] B≡0 C∈{0,1} D∈{-1.0,15.0} E=每场递增时钟; 0x05 锚 damageStickers params 族连续性确认
- findings.md §18(v22) 追加: 三项 v21 勘误 + 终局模型 + 通道真身表 + 方法论沉淀 + Task 38 交接

Stage Summary:
- **0x24 通道 100% 破解**: 位宽漂移状态机模型(数组长度×bitsRequired) + 0x05 重创建回滚 + RULE X 通道身份；11 场 5,241 包零违例
- v21 三项结论作废(固定位宽/通道身份/161 深层包定性)；v8 csi 表 31-49 段正式废弃(以 RULE X 为准)
- def 漂移新线索: csi29/30 元素结构与客户端 def 类型不符 → fork 历史缓冲包装假设(候选 Task 38)
- 完成度更新: 0x24 值段字段级 ~60%→95%(结构 100%，A/B/C/D 语义待 0x0A 对齐)；总进度 ~88%→**~93%**

---
Task ID: 38 (会话N · 战场技能流语义全解 —— csi29/30 真身判定 · 随机战范围收窄轮)
Agent: main
Task: 用户指令「继续，只需要随机战、别的模式都不需要」+ 前轮遗留「百分比估算」——收窄语料后执行 Task 38：csi29/30 字段语义终判（0x0A 对齐法）

Work Log:
- 环境体检: 四区齐备(scripts 65件/worklog Task37/findings v22/download V16-18/门户 :3000 200 OK)——前轮用户问「环境没回退吧」答案: 未回退
- 模式普查(mode_survey.py): 11场 battleType——10场 bt=1 ctf 随机战; tundra = bt=46 + 14车(7v7) → 按用户指令移出语料, 随机战语料 = 10 场 1,514,067 包
- 直方图普查(hist_survey.py): 0x0A 48.1% / 0x07 28.6% / 中型类型(0x36/0x1A/0x1F/0x26/0x1D/0x1C/0x32/0x04/0x37) v5/v6 已命名复核; 71万 0x0A 全 45B 定长
- 对齐(t38_align.py): csi29/30 与同 eid 0x0A 最近邻 → dclk=0.00s × 496/496(同拍双通道铁证); CBC prev 修复后 664/664 对齐
- 三重排除(t38_tests/t38_cross): A 非量化航向(场内 A 不定 yaw)/非坐标(10 离散值)/E 非线性时钟(karelia2 斜率-38.7)
- 副产物: clk 纪元重定位发现——包#1145 clk 跳 +989.440s(10场恒等), 战斗段 ~100.8 Q20单位 vs 612s 真实(结算JSON duration 权威); 0x1A 差分 0.1/2^k 倍速阶梯复核
- ★决定性突破: wot_scripts 实为客户端脚本包(client/BattleReplay.pyc)——uncompyle6 反编译 Vehicle.pyc 发现 dynamicComponents['ownVehicle']; alias.xml BWXML 解码得 PERK_INFO_HUD{AllowNone, perkID OBJECT_ID, state UINT8, coolDown FLOAT32, lifeTime FLOAT64} / PERK_INFO_RIBBON{AllowNone, perkID, endTime FLOAT64}——与 v22 数据驱动钉死的 18B/13B 元素逐字段吻合(A|B<<16=u32 perkID)
- 权威验证: item_defs/perks/perks.xml 42 技能 ID 空间, 观测 10 值{101,102,104,204,306,401,403,405,407,502}全部命中(101=视野半径/102=乘员+5%/104=瞄准速度/204=瞄准散布/306=极速/40x=装填系/502=乘员+2.5%)
- 语义化解码(t38_final.py): 664 条 → perks_semantic_v23.json; 玩家画像自洽(Object261火炮=aimingDispersion/WZ219=aimSpeed独占/BZ79+HoRi+PTZ=装填系); coolDown=15.0 ⟺ state=1 ⟺ perkID∈{102,104}(93/93)
- 0x07 key 直方图复核: 无 key 29/30(perks 只走 0x24 切片, MY_VEHICLE 自洽)
- RULE X 修正: 运行时变长组从 29 起步(29=perks vlh1/30=perksRibbonNotify vlh2/31=postmortem/32=publicInfo✓...48=dogTag✓); 定长组 0-28; ownVehiclePosition/inspired 降级到尾部候选 47/49; v22「fork 历史缓冲」假设作废(通道名错位)
- findings.md v23 §19 新增(5 小节) + 头部登记; 三处同步(root/upload/download)

Stage Summary:
- ★★csi29/30 真身 = perks/perksRibbonNotify(战场技能 HUD/丝带通知流)——字节级+ID权威+画像自洽三重闭环, 随机战 0x24 值段字段级 95%→~99%
- def 漂移清单第二例(首例重排型): Vehicle 变长组重排(vlh 带宽优化解释)——digest 偏差归因需三源合并(TeamInfo+3/Vehicle重排/dyncomp)
- 百分比估算(答用户): 随机战范围语义字段级 ~96%(0x24 通道今日+4pt); 分领域: 容器/JSON头/结算/0x05=100%, 0x07≈99%, 0x0A≈95%, 0x24≈99%, 0x08≈90%, 0x32/0x37≈85%, 0x39≈70%; 字节口径 ~99%; digest 复现支线 ~90%(机制100%白盒)
- Task 39 交接: ①E(lifeTime/endTime)时钟纪元 ②变长组尾部41-47/49逐位锚定 ③0x05重创建175次触发条件 ④digest三源偏差归因 ⑤0x32/0x37嵌套TLV字段级(v5遗留B级0.52%)

---
Task ID: 39 (会话M续 · Task 39 四联定案轮 —— E纪元/AoI协议链/变长组尾部/0x32-0x37)
Agent: main
Task: 用户指令「继续攻吧」（范围=仅随机战）——Task 38 交接五项中执行 39-a/b/c/e，39-d 留 Task 40

Work Log:
- 环境体检: 四区齐备(scripts 101件/findings v23/download V19+data_v21/门户 :3000 ok)；worklog 尾部 Task 38 确认
- t39_probe.py 三合一侦察: 10场 E 值域/JSON块0时间字段/0x05重创建 858eid 4922事件(typeID 6:185,7:672,12:1)/0x07 key 直方图(key13=274,849 主力, 41-49 全零)
- typeID 定名: 6=Vehicle(1092), 7=AreaDestructibles(5516), 12=DetachedTurret(10), 28/29=TeamInfo/AvatarInfo, 40=NetworkEntity(63)
- vanilla client_interface.hpp 消息序对照: enterAoI/leaveAoI 结构(id+idAlias / id+lastEventNumbers)
- ★0x04=leaveAoI 定案: caucasus_CN 1710/1710 首u32∈0x05-eid集, 4B 定长(fork 去 lastEventNumbers); 10场 0x04=5619 0x05=6721 0x06=17
- ★重创建协议链 100% 闭环(t39_c.py): 4,922/4,922 重创建 0x05 前存在同 eid 0x04; 5,619=4,922+697终局清场; 重创建 per type: AreaDestr 4,118/Vehicle 799/Turret 5; Vehicle 0x0A 中断中位 930,611clk; 0x04 等差周期(26k/52k/78k)=AoI 轮询痕迹
- ★E 纪元定案: 服务器进程时钟(秒)——namerica_CN→caucasus_CN Δunix=8,813s vs ΔE=+8,842.7s 差29.7s 同进程铁证; 跨进程配对全不吻合; span=duration 精确(caucasus 612.00=612); E vs clk 比率 12-26 波动(双时钟体系)
- 39-b 三通道零观测: 0x05 下发白名单15属性(t39_b.py idx 并集) + 0x07 key 41-49 全零 + 0x24 csi {29:496,30:168,33:1460,34:165}(offset9 修复)——变长组 14/21 位零流量不可锚定, 推断表(perks头插+自有序+dogTag@48锚全一致)
- 0x07 定长组 key 身份表: 1=isStrafing/4=siegeState/5=isCrewActive/13=gunAnglesPacked/14=health/15=engineMode/16=avatarID/22=wheelsState/23=stunInfo/27=inspiringEffect
- 0x32/0x37 攻坚(t39_e×3): 0x32=6,822包 81% 13B 短消息; 0x37=13,600包; decomp 定位 FUN_140584f80(0x32)/f90(0x37)/fa0(0x38)/fb0(0x33)/FUN_140585000(0x39)/510(0x34)+0x35/36 空流 → 全走 FUN_14058e4c0 通用转发器([u32 len] 双层封装)——6,822/6,822+13,600/13,600 全量吻合
- v5 报告衔接: 旧帧格式(组件消息/NRL)推广验证 10 场; 内嵌字符串全景 turret×507/chassis×474/compositionRootSlot×466/auxiliaryRocketLauncherComponent×22(BZ-79)/HP_pod×19; TLV 族 [8X 82] 6 类计数
- ★deathOrder 十场击杀链: 220 包 vs 结算 isAlive=0 死亡 220/221 逐场对齐(9场零偏差+karelia2 -1); 13B 短消息 eid∈0x05 创建集 5,526/5,526(AoI 重入视觉重建闭环)
- ★0x37 尾 f32 = 服务器时钟采样: 2,962/12,680 例与 perks E 域逐场同域——三通道时钟统一(E 字段/0x37 尾/clk)
- findings.md v24 §20(5 小节)+头部登记; 交付 data_v22(4件: t39 侦察×2 + deathOrder 220条击杀链 + findings)

Stage Summary:
- 四联定案: ①E=服务器进程时钟(同进程铁证) ②0x05重创建=AoI 离开/重入(0x04=leaveAoI 100%前导) ③变长组尾部 14/21 位零观测+白名单15属性 ④0x32/0x37 写入器+帧格式+击杀链 220/221
- 完成度: 随机战语义 0x32/0x37 结构+击杀链 100%/嵌套参数~60%; AoI 生命周期协议 100%; 0x24 ~99%(E 纪元归属已定)
- Task 40 交接: ①digest 三源偏差归因(TeamInfo+3/Vehicle重排/dyncomp, 39-d 未动主线最大遗留) ②部件状态族嵌套 TLV 参数锚定(jsonl 特效交叉) ③0x37 节点变换族字段级 ④karelia2 deathOrder -1 例 ⑤0x07 key29/30/38 三单例
- 环境: scripts +7(t39×5+probe 修复); 本轮四源触碰(decomp 消息序+通用转发器/vanilla client_interface/wot_scripts 76属性表/10场全量)

===== 第九部分 · 会话N（Task 40 · digest 三源归因攻坚轮）=====

---
Task ID: 40 (会话N · Task 40-a digest 三源偏差归因 —— 喂入链全反编译 + 两实锤修复)
Agent: main
Task: 用户指令「攻」——执行 Task 39 交接清单第①项（主线最大遗留）：digest 三源偏差归因（TeamInfo+3 / Vehicle 变长重排 / dyncomp）

Work Log:
- 环境体检: 四区齐备（scripts 107件/findings v24/download V20+data_v22/门户 :3000 200 OK）；worklog 真实状态 = Task 39 完成、Task 40 五项交接（本会话摘要所述 V17 已过时三轮）
- 三源 diff 侦察(t40_diff.py): TeamInfo 0x05 idx1-3 值 = `80 02 7d 71 01 2e` = pickle proto2 空字典（PYTHON 属性实锤，非 STR）；Vehicle defparse vs 运行时锚 perks→vpp 全 Δ-5/dogTag Δ-1 规律
- ★第一翻案: PoiTeamInfoComponent(capturedPoints)+TIBVS(statuses/positions, Default='{}') = TeamInfo 2 静态组件的 3 个 PYTHON 属性经 baseIndex 并入 csi 空间——「运行时 def 漂移」不存在；vdef_dump 确认 VehicleInBattleSwitch 空、AvatarInBattleSwitch 带 4 属性+vlh=4/2 明文声明
- ★第二翻案(v40_alias/t40_types): wot_scripts 与 wot_src_full 两份 alias.xml 200 别名零差异 → 重推模型: **AllowNone FD=变长（vanilla 规则）** → Vehicle 定长组 0-25/变长组 26-49 声明序，七锚(29/30/32/33/34/40/48)全中零漂移；v8「fork AllowNone=定长」=循环论证误诊
- 决定性判别(t40_key27/keys/keys2): key27 body 恒 9B [08][89×8]=TUPLE<UINT8> → wheelsScroll 实锤（旧模型 inspiringEffect 需 24B 定长，矛盾）；key38=[10][pickle {1:1,2:0}]=setupsIndexes；Avatar key9/10/12/19=isGunLocked/ownVehicleGear(值02档位,5369次)/shouldSendKillcam/ownVehicleAuxPhysicsData(8B,39352次) 全中
- digest 喂入链 100% 反编译复核: FUN_142a93420+142a9b6e0/142a9b870/142a894e0/142abc050/142aa17d0/142abcbc0 逐槽验证——name/属性[csi u32][vlh u32 isForClient门][name][flags&0x5F u32][volatile u8][type]/方法三域[vlh client域][name][flags][args][idx u32]
- ★★v15 误判推翻: 方法 flags = **u8 1 字节**（FUN_142aa17d0 slot+0x50 + vtable 转储 slot10=FUN_1403e8230 + vanilla uint8 flags_ 三重铁证）——v15 把 movzx 单字节装载误读为 u16 槽；v9 以来每方法多喂 1 字节 0x00
- 系统性排除(全 decomp 证据): 组件属性不进 digest（喂入器只走父向量+0x28..0x30）/ +0x87=canBeOnClient 图内记录天然全过 / UDO 净零贡献（FUN_142a998b0 追加条件 record+0x87==0 与 digest 过滤器互斥 + PARSE_IGNORE_FLAGS 双保险）/ 扩展<Components><StaticComponents>39 边不挂载（multimap 只读根级 ExternalComponents）/ 无 ClientName/无 def 级 Components/alias 无包装/编排序 space→40CS→10扩展→ServerOnly(跳)→UDO(零)→107→160
- digest 复现演进: v2=5976CA14 → v4(AllowNone csi)=DFC810E5 → v5(方法flags u8)=BFF232F1 → ★自查捕获第三 bug（realloc 稳定重排保留 v8 残序致变长组锚点全偏+5，修复=排序键加声明位 tiebreak）→ **v5 终值=919053EC** → 目标 5DF886F7 仍未命中；csi_v9 表修复后 Vehicle 十七锚全过
- 修正版 csi 权威表交付: csi_v9.py → /tmp/wot/csi_tables_v9.json（Vehicle 定长 0-25+变长 26-49 声明序全表 / Avatar own 28+组件 4（含 vlh=2/4 声明）/ TeamInfo 4 行全表）
- 剩余偏差收窄: 喂入格式已 100% 穷尽 → 偏差只能来自①wot_scripts/扩展 def vintage 与实际客户端加载集差异（33 主实体+107 dyncomp+170 扩展记录无运行时锚）②排序/解析最后一环
- findings.md v25 §21 新增（5 小节）+ 版本头登记

Stage Summary:
- 三源归因终局: 源1(TeamInfo)=组件属性并入（非漂移）/源2(Vehicle)=v8 AllowNone 误诊（非漂移）/源3(dyncomp)未动——真正缺陷在模型层（已修 2 处实锤）
- 复现值 BFF232F1 仍≠目标，但喂入链 100% 反编译穷尽后偏差空间已收窄至输入侧
- v8 csi 表修正案落地（Vehicle 0-25/26-49 全表 + Avatar 组件 28-31 + TeamInfo 1-3）——p05_decoder 走段不受影响（观测位全部不变）
- Task 41 交接: ①输入侧审计（寻找实际 #942 客户端 scripts.pkg 与 wot_scripts 的 def 级 diff——33 无锚实体+dyncomp+扩展）②digest 剩余偏差继续（排序/解析最后一环假设排查）③Task 40 剩余四项（部件状态族 TLV/0x37 节点变换/karelia2 deathOrder/0x07 三单例已定性——key29/30=perks/prn、key38=setupsIndexes 本轮已解）
- 环境: scripts +13 件（t40 系列 10 + digest_fork_v5/v6 + 修订）；本轮四源深度触碰（decomp 喂入链 7 函数 + vanilla 8 源文件 + wot_scripts/wot_src_full 双 alias 对比 + 10 场回放 key 判别）
- 交付完成: V21 zip（157KB: findings v25 §21 + worklog + data_v23 14件 + csi_tables_v9.json）→ download/ + upload/ 备份 + 门户 :3000 重启（描述已更新）；findings 三处同步（md5 c7b79f6d）

===== 第十部分 · 会话O（Task 41 · 输入侧审计 + digest 算法层全解轮）=====

---
Task ID: 41 (会话O · Task 41 digest 输入侧审计 + entity_description_digests.cpp 算法层完全重解)
Agent: main
Task: 用户指令「upload里那个scripts.7z就是942的完整scripts.pkg」——Task 40 交接第①项输入侧审计 + 算法层深挖

Work Log:
- 环境体检: 四区齐备(scripts 115件/findings v25 §21/download V21+data_v23/门户 :3000 200 OK); scripts.7z(22MB) 定位于 upload/
- ★解压 scripts942(12,857 条目: entity_defs 41 def + component_defs 127 + UDO 40): **与 wot_scripts 11,536 文件 md5 零差异** → wot_scripts 即 942 完整 scripts.pkg, 主树 def vintage 差异假设彻底排除(Task 41-① 主树部分完成)
- entities.xml 解码: 40 CS 实体声明序与 v2 模型一致(Vehicle 6th/AreaDestructibles 7th); 41 def − 40 声明 = RepairBase 孤儿 ✓
- 分区消融(v7): A基线318/B无扩展148/C仅扩实体158/D仅扩dyn/F换序/G无space/H前置 —— 7 变体全不中(旧模型)
- vanilla 源码选择性解压(BigWorld-Engine-14.4.1 → bw_src/entitydef+bwentity+cstdmf): FLAG_MAP ✓ DATA 常量 ✓ Exposed 位(0x4/0x8) ✓ Component 枚举(CLIENT=0/CELL=1/BASE=2) ✓ MethodArgs pair<name,type> 旧式名="" ✓ isForClient=isClientServerData ✓
- ExposedForReplay 全扫(t41_scan): 25 显式标签全在 Avatar/Vehicle 且 flags 均已含 OWN/OTHER 位 → CS 判定不变, 疑点排除; Volatile 标记仅 GunMarkerComponent.def 1 处(组件不进 digest) → 主实体 isVolatile 恒 0
- ★★★算法层完全重解(decomp 深挖): 错误信息泄露魔改源文件 entity_description_digests.cpp(vanilla 无此文件) —— WoT 重写 digest 为**结构化 visitor 序列化**:
  · 顶层链: FUN_142a9b640(MD5Calculator 创建+init) → 142a9b5b0(换 ClientServerTypesMD5Visitor vtable, 开头喂 visitString(NULL,0)) → 142a9b410(0x328 步长, +0x87 过滤) → 142a93420(每实体)
  · calc(MD5Calculator) vtable 槽全解: +0x18(str,flag 值/域标记) / +0x28(field,u32) / +0x40(field"varLenHeaderSize") / +0x50(field,u8 "flags") / +0x58(field,u8 "isVolatile") / +0x60("name",BW::string*) / +0x68("name",类型名) / +0x70(getState 裸喂用)
  · 常量破译: DAT_1435d2d24="name"(memcmp len4 实锤) DAT_1435e0950="type"(len4 上下文 XML section 模式) DAT_1435e92e4="size" DAT_143676a60="Int"(注册表 len3) DAT_143928948="Uint"(与 Int 家族对称) DAT_143676a50="Bool" DAT_143665890="Argument"(9B TypeDescriptor 偏移用法)
  · 类型层 visit 全解(decomp 逐函数): INT→"name","Int"/"Uint"+"size",n; VECTOR→"Vector"+"size",n; ARRAY/TUPLE→"name"+"size"+[dbLen]+递归(elem,"elementType"); FIXED_DICT→+moduleName/instanceName+"allowNone"+("fields"域)+每字段{名+"name"+名+递归}; FLOAT/STRING/PYTHON/MailBox 简单式; 类型用集实测 9 种(INT2101/FLOAT612/STRING397/FD258/ARRAY247/VECTOR153/PYTHON116/MAILBOX75/TUPLE19)
  · 方法喂入: name/[vlh 条件]/"name"+name/"flags"u8/args{("Argument"标记+每arg{名空串+类型递归})}/returnValues{**942 def 4 处全空恒跳过**}/idx 4B
  · ★visitMethod 槽实现(FUN_142a9b810)三域统一 (flags&0xC)!=0 过滤 —— client 域也过滤(推翻 FUN_142a93420 表面无过滤读数, |=0x4 假设成为必要条件)
  · MD5 finalize(FUN_1403e8410)标准 padding+LE 位长 ✓; 底层 append 族(81e0 cstr含NUL/8210 BW::string/8230 u8/8260 u16/8290 u32/82c0 blob)全解
- 消融矩阵四轮: v8(1728) v9(20736) v10(9216) v11(98304) = **129,984 组合全不中** → 结构化格式空间基本穷尽, 剩余偏差锁定「记录集内容」(160 扩展记录无运行时锚)或未识别结构细节
- paths.xml 实锤(wot_src_full = wot-cn 2.4.0.0 #942 文本源): **18 扩展 pkg 与 scripts.pkg 同列启动挂载清单**(type=sandbox,sd,hd 字母序) → 「登录期无扩展」假设排除, 记录集 318 维持; 扩展迭代序=字母序=paths.xml 序 ✓
- 扩展包结构核查: ext_pkg/_raw(BWXML def+extension.xml)+client_files.txt 清单完好; parse_ext_dyncomps 去重/decider 逻辑与 decomp 一致

Stage Summary:
- ★输入侧主树 def = 942 权威(零差异) + 18 扩展启动挂载实锤 —— 记录集构成理论全部对齐
- ★★★digest 算法层从 vanilla 模型彻底翻案为结构化 visitor 模型(槽/常量/类型层/方法层全解, 6 常量破译) —— 复现工具链(v8-v11)已就绪, 13 万组合消融完成
- 复现仍未命中(129,984 组合): 偏差空间收敛至「160 扩展记录的 def 解析内容」(无运行时锚)或「嵌套递归第三参 r8 残留」等残余结构自由度
- vanilla 交叉核对 8 项全过; 两个历史误判(u16 flags/isVolatile 缺失)均获直接证据维持
- Task 42 交接: ①扩展 def 内容人工核对(取 FLAvatarComponent 等 3 样本逐字段 diff defparse) ②0x08 methodID 锚验证扩展记录方法集(battle_modifiers 等通用扩展随机战活跃?) ③FUN_142a93420 的 +0x8/+0x20 槽实现补挖(wrapper vtable) ④0x05 块属性数全实体 CS 属性集强校验 ⑤未消融残余: VLH=3 仅值型/域标记 NUL 分立已入 v11 但嵌套递归名只有 3 态
- 环境: scripts +8 件(t41_scan×2 + digest_fork v7-v11 ×5 + bw_src 解压); 本轮五源深度触碰(decomp 喂入链 15+ 函数 + vanilla 12 源文件 + scripts942 全量 + wot_src_full paths.xml + ext_pkg)
- 交付完成: V22 zip(293KB: findings v26 §22 + worklog + data_v24 14件: digest_fork v7-v11 消融引擎×5 + t41_scan/t42_extaudit + scripts942 解压日志 + csi_tables_v9 副本) → download/ + upload/ 备份; findings 三处同步(md5 一致); 门户 :3000 200 OK 无需重启

---
Task ID: 43 (会话P · Task 43 EXE 白盒终局轮 —— digest 全链逐字节验证 + 双实锤修复)
Agent: main
Task: 用户指令「攻」+ 提供新材料（GitHub wotexe.7z = 942 客户端 EXE + 另一 AI 的 MD5Calculator vtable 转储）——充分利用 EXE/decomp/wot_src/scripts/bigworld 四源，攻 digest 复现

Work Log:
- 环境体检: worklog 真实状态 = Task 41 完成（V17 摘要过时三轮）；门户 :3000 存活；scripts942 已解压且 = wot_scripts（Task 41 已证零差异）
- 材料落地: 下载 wotexe.7z(17MB) → WorldOfTanks.exe(78.8MB, PE64, ver 2.4.0.10161)；装 pefile+capstone
- ★交叉验证另一 AI 的 MD5Calculator vtable 转储: 17/17 逐字节命中（表头 COL/slot0-14/表尾邻类 COL）→ 转储为真 + EXE 与 decomp 同布局（可作真值锚）；基类 IMD5Calculator 14 槽全 _purecall 亦验证
- ★★★ClientServerTypesMD5Visitor vtable 完全解剖(RTTI 反推): slot0@0x143923290, 8 槽 = dtor/startProperties/endProperties(stub)/startMethods/endMethods(stub)/visitProperty/visitMethod/visitEntity(+0x87 过滤)；栈对象 S={vptr, inner=MD5Calculator, bool} 由 FUN_142a9b5b0 构造，walk 前后换 vptr
- ★决定性反转#1: MD5Calculator 槽1-4 = 空钩子(0x1402F7290=ret) ⇒ 所有域标记("properties"/"clientMethods"/"baseMethods"/"cellMethods"/"fields"/"type"/"elementType")与一切 slot3 调用 = 零字节! v8-v11 的 15 维标签假设空间全数作废
- ★决定性反转#2: 裸反汇编证明 slot5/8/10/11 的 rdx 标签被覆盖丢弃、仅 r8d 值入哈希; slot12=BW::string 无NUL/slot13=cstr 含NUL(逐指令验证) ⇒ "name"/"dataDistributionFlags"/"flags"/"isVolatile"/"size"/"varLenHeaderSize" 等全部字段名常量零字节
- 类型层全解(25 类): IntegerDataType<C/E/F/G/H>/LongIntegerDataType<I/_J/_K> 模板类定位, visit = "Int\0"/"Uint\0"+u32(size); Float<M/N>="Float\0"/"Float64\0"(无size!); Vector2/3/4="Vector\0"+u32(n); String/Python/UnicodeString/Blob="名字\0"; UDO_REF="UserDataObjectLinkDataType\0"; User="User\0"+mod+inst(无NUL); Array/Tuple="名字\0"+u32(seq)+[u32(dbLen)>0]+递归elem; FixedDict="FixedDict\0"+[mod+inst 门控]+u8(allowNone)+每字段{name+类型}
- ★MAILBOX=零字节: MAILBOX→SimpleMetaDataType<UnsupportedDataType>→visit 仅打错误日志"used in external interface"、零喂入(59 处 CS 位 MAILBOX 全部零贡献)——推翻旧"MailBox\0"模型
- 类型注册表架构解明: SimpleMetaDataType<T> 3 槽小 vtable+紧随名字串; 内置名→具体类映射全表(MAILBOX→Unsupported/UDO_REF→UserDataObject/...)
- 方法 idx 计数规则钉死: client 域计数器数全部(slot6 内过滤)/base/cell 域 dispatcher 预过滤+计数仅计喂入; 接口方法在 +0x2f0 表(942 entities.xml 零接口但 def 的 Implements 合并入主表——vanilla parseInterface 顺序 Implements→Properties→Methods 与 defparse 一致)
- vanilla 全套 addToMD5 原型对照(EntityDescription/DataDescription/MethodDescription/MemberDescription/MethodArgs/allocateClientServerFullIndexes): fork digest = vanilla addToMD5 + isVolatile 扩展 + visitor 间接化; csi=stable_sort(定长升序→变长按vlh升序,稳定)铁证; VLH 门=isForClient&&ss<0&&vlh!=1(属性 isForClient=isClientServerData/方法=comp==CLIENT)
- 0x3D 包结构钉死: [u32 32][32字节ASCII大写hex]; 发送方=Python 侧读 DAT_14483e028(EntityType::init 单点计算)设置 "digest" 属性; 11 场回放(含 hasMods=False 纯净场)全部=5DF886F7 → 目标=纯 def 集稳定真值
- ★字节模型收敛证明: v12 精确模型输出 = 919053EC...(= Task 40 v5 终值) ⇒ wrapper 字节格式早已收敛, Task 40-41 的 129,984 组合全在探索死维度——偏差从来都在记录内容
- ★★★实锤修复#1(静态组件属性并入): build_parts 从未把 StaticComponents 挂载组件的【属性】并入实体——Avatar 少 4(vehicleSpawnList/isVehicleConfirmed/spawnInfoForVehicle/spawnPoints ← AvatarInBattleVehicleSwitch)、TeamInfo 少 3(capturedPoints/statuses/positions)——csi_tables_v9 权威表+0x05 idx1-3 pickle 铁证双重确认; v13 实现并入(声明序追加+挂载序)
- ★★★实锤修复#2(csi 分块式): 权威表 Avatar isVehicleConfirmed(U8) 在 csi 28(非13) → 分块铁证(自有排序块+各组件排序块接 running baseIndex, 非整体排序); v13 realloc_csi_blocks 实现, 修复后 Avatar 32/TeamInfo 4 CS 属性与权威表逐项吻合
- ★实锤修复#3(VLH 门): 排序与 VLH 门用 getServerToClientStreamSize 语义——AllowNone FD = 变长 -vlh(spawnInfoForVehicle ss=-2 铁证); 语料 p.stream_size() 对 AllowNone FD 返回正数 → spawnInfoForVehicle(vlh=2) 的 4 字节 VLH 曾漏喂; v13 gsc_stream_size 修正
- 全量排除审计(全部通过): ClientName 零声明(全实体 canBeOnClient=1)/Volatile 全景(15 处声明,唯一生效=GunMarkerComponent.gunMarker=1,语料已含)/FD ModuleName 零声明(门控 moot)/persistAsBlob 零使用/TUPLE seq=0=vanilla 默认/别名解析抽查全对/主扩展 def 名零冲突/dyncomp 过滤双向验证(3 排除项在扩展包也无脚本)/扩展编排五阶段反编译实锤(A 顺序)/重复声明 113=110 唯一-3 无脚本=107/BWXML blob 陷阱两例破解("BASE"=b64(040484)、"Harm"=b64(1daae6),均 asString 正确解读,虚警)
- ★GunMarkerComponent 逐字节验证: 106B 输出与 def+反编译语义手工预期 100% 一致(含 isVolatile=1/allowNone=1/Vector 嵌套)
- digest_fork_v12/v13 交付: v12=EXE 白盒终版字节模型; v13=+静态组件属性并入+分块csi+VLH门修正; 56 组合矩阵(7 记录集×8 配置)仍不中(A/000=E726F5E4)
- 剩余偏差定位: wrapper/算法/类型层/主实体内容全部证毕 → 偏差唯一存活空间 = 267 dyncomp + 10 ext 记录的 defparse 保真度(84% 无运行时真值锚)——与 Task 41 结论一致但自由度从「5 项结构假设」坍缩为「纯内容 diff」

Stage Summary:
- ★EXE 到手并验证为 decomp 同布局真值锚; 另一 AI 的 vtable 转储 17/17 验证为真
- ★★★digest 字节模型 100% 闭环(逐指令级): 域标记/字段名标签全部零字节、MAILBOX 零字节、25 类类型 visit 全解、idx 计数规则钉死——v8-v11 假设空间全数作废, wrapper 收敛证明(v12≡v5 终值)
- ★★三实锤修复落地: 静态组件属性并入(7 属性)+csi 分块式+VLH 门 gsc 语义——Avatar/TeamInfo/Vehicle 与运行时权威表逐项吻合
- 复现仍不中(E726F5E4≠5DF886F7): 偏差坍缩至无锚记录内容(defparse 对个别 dyncomp/ext def 的解析保真度)
- 完成度: digest 支线 ~90%→95%(机制 100% 逐字节证毕+3 bug 修复+内容锚定面扩大); 随机战总语义 ~96% 维持
- Task 44 交接: ①无锚记录内容 diff(267 dyncomp 抽样逐字段 vs def 原文, 重点 Parent 链/接口/别名深嵌套) ②录制扩展模式回放(大逃杀/前线)获取 ext 记录运行时锚 ③0x05 通道对 107 dyncomp 的 CSI≥50 观测面(v19 已开)反哺 digest 校验 ④karelia2 deathOrder -1 例遗留
- 环境: scripts +3 件(t43_exe/t43_visitor/digest_fork_v12/v13); 五源深度触碰(EXE 裸字节+decomp 全链+vanilla 8 源文件+scripts942+csi 权威表)

===== 第十一部分 · 会话Q（Task 44 · V24 全量重打包 + 0x32-0x39 协议架构全解 · 2026-09-26）=====

---
Task ID: 44 (会话Q · V24 全量重打包 + ClientHub/NRL 架构轮)
Agent: main
Task: 用户三指令——①澄清「录扩展回放」是否随机战也需要（答：不需要）②从 V16 到 V23 越打越瘦，重打全量 V24 并备份到 upload③继续攻克（充分利用 exe/decomp/wot_src/scripts/bigworld）

Work Log:
- 环境体检: my-project 四区齐备（scripts 133 件/download V16-V23 全谱系/findings v26/worklog Task43），/tmp 五源材料全在; **upload/ 已被清空**（历史 backup_v5~v16 全失）——印证用户"重打包+备份"诉求
- 范围终裁: 扩展回放建议正式撤销——该建议仅服务于 digest 支线最后 5%（160 扩展 dyncomp+10 扩展实体记录的 defparse 保真验证），这些记录在随机战流量中永不出现; digest 是登录期客户端指纹，不影响任何随机战解析; 随机战主线不需要用户再录任何东西
- V24 Phase A 安全快照（scripts/pack_v24.py）: V16 底座（报告 MD/PDF+xlsx+charts+JSON+csi_v8+ext_inventory+覆盖度终审+封面）+ data_v17~v25 全部增量 + data_v26 历史补充工件（0x24 键空间/csi 分布/Vehicle 属性表等 6 件首次入包）+ 133 脚本 + findings v26 + worklog = **211 文件 7.66MB**, md5=2ce372a1...; 分发 download/ + upload/backup_v24/（包+findings+worklog+audit）
- Task 44 研究（0x32/0x37 嵌套 TLV 字段级——v5 遗留最大 B 级块）:
  * EXE vtable 白盒（t44_vtable/vtable2/slots）: 定位 WGReplayMessageHandler 41 槽接口表 @0x1436066e8; 逐槽提取记录类型常量 → slot→type 全映射; **0x32-0x39 = 8 个连续 fork 扩展虚方法（slot33-40）**; 纯尾调用 jmp FUN_14058e4c0 → **只录不转发**（汇编确认 rdx 不进 child）⇒ 服务器专供回放录制的注记流; v6 勘误: 首 u32"组件路由号"=录制器加的 [u32 len]
  * 类链实证（t44_child/dis）: **WGReplayConnection : ClientHub : BWEndPoint**（构造函数 FUN_14057cbe0 三级 vtable 符号: WGReplayConnection::vftable @0x143606340 / ClientHub / BWEndPoint + std::_Ref_count_obj2<BW::BWEndPoint>）; NRL::EndPoint（FUN_140e5c1d0）; 播放分发器 FUN_140574dd0 全表: 0x32/33/34=onReceivedMessage(ch0/2/6), 0x35/36=onReceivedFlagMessage, 0x37=整块 blob→(hub+0xb8)MemoryOStream 缓冲, 0x38/39=onReceived 多消息循环; 断言串还原方法名（client_hub.cpp: processUpdateNode/onReceivedMessage/onReceivedFlagMessage）
  * MemoryIStream vtable 钉死 @0x1435df260（5 槽: dtor/retrieve/remaining/finish/readU8——t44_stream）
  * 消息文法（t44_dis2 汇编级）: 首消息 [u16 BE class<<8|sub]+body; 后续 [u8 X][u8 b0][u8 class][u8 sub]+body（X<6 普通分发/X==6 processUpdateNode）; 分发器 FUN_140e74040 class 0-5 槽位表（+0x58/0x60/0x68/0x70/0x78 = FUN_140e73f30/cf0/743b0/73aa0/74250）; class 0 = [u16 objId][u8 regKey]+节点 vt+0x18 body; 13B 短消息 = [class0][sub][objId=1][regKey=1][eid] ×5,526
  * CGF Python 侧（scripts942 反编译 + wot_src stubs）: GenericComponents.py（StateSwitcher 四态/compositionRootSlot）; NetworkVehicleHierarchy.def = hierarchyInfo ARRAY<VEHICLE_HIERARCHY_INFO>; **alias: VEHICLE_HIERARCHY_INFO = FIXED_DICT{slotName STRING, networkID UINT32}**; cgf_network 引擎 API（processCreate/DestroyDynamicComponent/getGameObjectByNetworkID/ObjectCommand）; SequenceNetworkSync（动画同步属性族）
  * hierarchyInfo 全量提取（t44_join/join2）: 980+ 车辆层级（chassis/turret/compositionRootSlot/hull/gun/gun1/SightPointer/HP_loaders → networkID, 值域 1..~200）; BE 端序对撞 0x37 首 nid: 4 场命中 25-42%（LE 误读 0% → BE 正解）; 未中值 2013/666/670 = 非车辆节点（2013 在 1801 场 ×554 恒定更新, 疑镜头/观察者节点）
  * 0x37 组文法（t44_hand/catalog）: [u16 BE nid][op][sub][值] 循环; (02,03)7B+(02,06)10B 成对组共享 u16 高字节; (01,13/14) 长组 `8X YY 01 0a ZZ...` 编码族; (00,05) f32 组（-1.0/0.0）; deathOrder=v5 已解的 pickle 子族
  * 0x39 文法: 多消息循环 [X=06][b0][class][sub] → processUpdateNode 序列 = 弹道复制（§14.6 语义在文法层闭环）
  * 全量目录（t44_catalog.py）: 0x32 消息族 112 个 (class,sub) 组合 + 字符串普查（ShotsReceiver_41XX/SequenceNetworkSync_41XX 组件实例名）+ 0x37 组族目录 → t44_catalog.json; t44_hierarchy_maps.json（260 实体）
- findings.md 更新至 v28: 头部版本行 + §24 全新增（8 小节）; 三处同步
- 报告 §23 增补（v17-v26 增补总览 + Task 44 架构轮）

Stage Summary:
- 六项入库: ①41 槽处理器接口表+0x32-0x39 只录不转发定性 ②类链 WGReplayConnection:ClientHub:BWEndPoint+NRL::EndPoint+播放分发表 ③消息文法（首消息/后续消息/class 0-5 分发表）④hierarchyInfo 字典全量提取（980+ 车, v5 遗留"节点 ID→视觉节点名"钥匙）⑤0x37 NRL 组文法+nid 空间对撞 ⑥CGF Python 侧全解
- v6 勘误一处（"组件路由号"=[u32 len]）; 随机战 0x32/0x37 语义覆盖 85%→~93%
- V24 = 211 文件全量包 + upload/backup_v24 备份就位
- Task 45 交接: ①各 (class,sub) 族 body 字节级语义（112 族清单在 t44_catalog.json）②0x37 变换值数学定标 ③NRL 非车辆节点命名 ④karelia2 deathOrder -1 例 ⑤digest 支线维持冻结（随机战语料内无解）
