#!/usr/bin/env python3
"""digest_fork_v6.py — Task 40-a 终局轮: 六修正版 (v5 + UDO 记录块)

v5 (AllowNone变长 csi + 方法flags u8 + 组件属性不进digest) + :
  修正4 ★UDO 记录块: 编排 FUN_142a98830 真实顺序 = space → 40主CS → 10扩展实体
       → ServerOnly(side=1, +0x87=0 跳过) → ★UDO(FUN_142a998b0 追加 0x328 记录!)
       → 107主dyncomp → 160扩展dyncomp
       decider = HasScriptOrTagDistributionDecider: <Distribution><Client> 标签优先,
       否则 scripts/client/<名>.py 存在 → 14 个 UDO 过 (v2 的 318 记录集漏了整个 UDO 块!)
       UDO def = user_data_object_defs/<名>.def, 属性 Flags 正常读, 方法未见
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bwxml import decode_file
from defparse import (EntityDefParser, EntityDescription, MD5,
                      DATA_DISTRIBUTION_FLAGS)
from digest_fork_v2 import (SCRIPTS, EXT_ROOT, CD, CLI, TARGET,
                            _has_script, DefLocator, parse_comp_record,
                            load_static_comp, parse_space_record,
                            iter_extensions, parse_ext_entities,
                            parse_ext_dyncomps, DOM_ATTR)
from digest_fork_v5 import (vanilla_stream_size, realloc_csi_v3,
                            _prop_to_md5, _method_to_md5_v5, fork_add_to_md5_v5)

UDO_DIR = f'{SCRIPTS}/user_data_object_defs'


def load_udo_records(parser, rec_cache):
    """UDO 记录: user_data_objects.xml 声明序 × decider(client 脚本/Distribution)"""
    udo_xml = decode_file(f'{SCRIPTS}/user_data_objects.xml', 'user_data_objects.xml')
    out = []
    for c in udo_xml.children:
        name = c.name
        if name in rec_cache:
            continue
        dpath = f'{UDO_DIR}/{name}.def'
        if not os.path.exists(dpath):
            continue
        sec = decode_file(dpath, name + '.def')
        # decider: Distribution/Client 优先, 否则 client 脚本
        verdict = None
        d = sec.child('Distribution')
        if d is not None and d.child('Client') is not None:
            verdict = d.child('Client').asBool()
        if verdict is None:
            verdict = _has_script(CLI, name)
        if not verdict:
            continue
        ed = EntityDescription(name)
        ed.client_name = name
        _parse_udo_def(parser, ed, name, set())
        ed.fork_components = []
        realloc_csi_v3(ed)
        out.append(ed)
        rec_cache[name] = ed
    return out


def _parse_udo_def(parser, ed, name, seen):
    """UDO def 递归解析 (Parent/Implements 链 → Properties → Methods)
    ★ UserDataObjectDescription::parseProperties = PARSE_IGNORE_FLAGS:
      dataFlags_ = 0 → 属性全非 CS → 不进 digest (记录 = 纯名字)"""
    if name in seen:
        return
    seen.add(name)
    dpath = f'{UDO_DIR}/{name}.def'
    if not os.path.exists(dpath):
        return
    sec = decode_file(dpath, name + '.def')
    parent = sec.readString('Parent')
    if parent:
        _parse_udo_def(parser, ed, parent, seen)
    ed.name = name
    ed.client_name = name
    impl = sec.child('Implements')
    if impl is not None:
        for k in impl.children:
            iname = k.asString()
            for cand in (f'{UDO_DIR}/interfaces/{iname}.def',
                         f'{SCRIPTS}/entity_defs/interfaces/{iname}.def'):
                if os.path.exists(cand):
                    parser._parse_interface(ed, decode_file(cand, iname + '.def'),
                                            iname, '')
                    break
    # PARSE_IGNORE_FLAGS: 属性全部 dataFlags=0 → 非 CS，不进 digest —— 直接跳过解析
    props = sec.child('Properties')
    if props is not None:
        from defparse import Property
        for c in props.children:
            if any(p.name == c.name for idx in () for p in
                   [x for x in ed.properties if x.name == c.name]):
                continue
            tsec = c.child('Type')
            if tsec is None:
                continue
            dt = parser._build_type(tsec)
            p = Property(c.name, 0, dt, 1)   # flags=0 → 非 CS
            p.index = len(ed.properties)
            ed.properties.append(p)
            ed.prop_map[('', p.name)] = p.index
    parser._parse_methods(ed, sec, name, '')
    ed.allocate_csi()


def build_records():
    parser = EntityDefParser(SCRIPTS)
    parser.load()

    comps_root = decode_file(os.path.join(SCRIPTS, 'components.xml'),
                             'components.xml')
    static_list = [k.name for k in comps_root.child('StaticComponents').children]
    dyn_list = [k.name for k in comps_root.child('DynamicComponents').children]

    mounts = {}
    for cname in static_list:
        sec = decode_file(os.path.join(CD, cname + '.def'), cname + '.def')
        ofe = sec.child('ofEntity')
        if ofe is not None:
            for k in ofe.children:
                mounts.setdefault(k.name, []).append(cname)

    sub_cache, rec_cache, comp_cache = {}, {}, {}
    locator = DefLocator([])

    records = [parse_space_record(parser)]
    for ed in parser.entities:
        ed.fork_components = [load_static_comp(parser, locator, c, sub_cache)
                              for c in mounts.get(ed.name, [])]
        realloc_csi_v3(ed)
        records.append(ed)
        rec_cache[ed.name] = ed
    n_main = len(records) - 1

    exts = iter_extensions()
    n_ext_ent = 0
    for ext in exts:
        eloc = DefLocator([os.path.join(EXT_ROOT, ext, '_raw')])
        for ed in parse_ext_entities(parser, eloc, ext, rec_cache):
            realloc_csi_v3(ed)
            records.append(ed)
            n_ext_ent += 1

    # ★ 修正4: UDO 块 (ServerOnly 跳过, UDO 在扩展实体之后、主 dyncomp 之前)
    udos = load_udo_records(parser, rec_cache)
    records.extend(udos)

    seen = set()
    for name in dyn_list:
        if name in seen:
            continue
        seen.add(name)
        if not _has_script(CLI, name):
            continue
        ed = parse_comp_record(parser, locator, name, comp_cache)
        ed.fork_components = []
        realloc_csi_v3(ed)
        records.append(ed)
        rec_cache[ed.name] = ed
    n_main_dyn = len(records) - 1 - n_main - n_ext_ent - len(udos)

    n_ext_dyn = 0
    for ext in exts:
        eloc = DefLocator([os.path.join(EXT_ROOT, ext, '_raw')])
        eds, sk = parse_ext_dyncomps(parser, eloc, ext, rec_cache, comp_cache)
        for ed in eds:
            realloc_csi_v3(ed)
            records.append(ed)
            n_ext_dyn += 1

    print(f'records = 1 space + {n_main} 主 + {n_ext_ent} 扩展实体 + '
          f'{len(udos)} UDO★ + {n_main_dyn} 主dyn + {n_ext_dyn} 扩展dyn = {len(records)}')
    n_cs = sum(len(ed.cs_props) for ed in udos)
    print(f'UDO CS 属性: {n_cs}')
    return records


def main():
    records = build_records()
    print(f'[目标] {TARGET}')
    md5 = MD5()
    for ed in records:
        fork_add_to_md5_v5(ed, md5)
    d = md5.getDigestQuote()
    hit = '★★★★★ 命中目标!!!!!!' if d == TARGET else '≠'
    print(f'[v6 = v5 + UDO块] {d} {hit}')


if __name__ == '__main__':
    main()
