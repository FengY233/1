#!/usr/bin/env python3
"""t40_keys.py — 0x07 全 key 直方图(10场) + key27/28/26/44 判别
新模型: 26=steeringAngles 27=wheelsScroll 28=perkEffects 42=inspiringEffect
        43=healingEffect 44=dotEffect 45=inspired 46=healing 47=healOverTime 49=ovp
"""
import sys, struct, collections
sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import load_pkts, REPLAYS

hist = collections.Counter()
body_lens = collections.defaultdict(collections.Counter)
samples = {}
for tag, path in REPLAYS:
    for ty, c, pl in load_pkts(path):
        if ty != 7 or len(pl) < 12:
            continue
        eid, key, blen = struct.unpack_from('<III', pl, 0)
        hist[key] += 1
        body_lens[key][len(pl[12:12 + blen])] += 1
        if key not in samples:
            samples[key] = (tag, pl[12:12 + blen].hex())

print('=== 0x07 key 全直方图（10 场随机战）===')
for key in sorted(hist):
    lens = dict(sorted(body_lens[key].items())[:8])
    tag, s = samples[key]
    print(f'  key{key:>3}: {hist[key]:>7,} 包  body长度{lens}  样例[{tag}] {s[:44]}')
