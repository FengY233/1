#!/usr/bin/env python3
"""t40_udo.py — UDO 记录集枚举: 谁过 HasScriptOrTagDistributionDecider
canBeOnClient = <Distribution><Client> 标签优先, 否则 scripts/client/<名>.py 存在
"""
import sys, os
sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file

SCRIPTS = '/tmp/wot_scripts/scripts'
PY_EXT = ('.py', '.pyc', '.pyo', '.pyd')


def has_client_script(name):
    d = f'{SCRIPTS}/client'
    for e in PY_EXT:
        if os.path.exists(f'{d}/{name}{e}'):
            return 'file'
    for e in PY_EXT:
        if os.path.exists(f'{d}/{name}/__init__{e}'):
            return 'pkg'
    return None


udo_xml = decode_file(f'{SCRIPTS}/user_data_objects.xml', 'user_data_objects.xml')
names = [c.name for c in udo_xml.children]
print(f'user_data_objects.xml: {len(names)} 个 UDO')

rows = []
for n in names:
    dpath = f'{SCRIPTS}/user_data_object_defs/{n}.def'
    dist_client = None
    nprops = ncs = nmeth = 0
    if os.path.exists(dpath):
        sec = decode_file(dpath, n + '.def')
        d = sec.child('Distribution')
        if d is not None and d.child('Client') is not None:
            dist_client = d.child('Client').asBool()
        props = sec.child('Properties')
        if props:
            nprops = len(props.children)
            for c in props.children:
                fl = c.readString('Flags')
                if fl:  # 有 Flags 才可能 CS
                    ncs += 1
        nmeth = sum(len(sec.child(t).children) for t in
                    ('ClientMethods', 'BaseMethods', 'CellMethods')
                    if sec.child(t) is not None)
    else:
        dpath = '<缺def>'
    script = has_client_script(n)
    verdict = dist_client if dist_client is not None else bool(script)
    rows.append((n, dist_client, script, verdict, nprops, ncs, nmeth, dpath))

passed = [r for r in rows if r[3]]
print(f'\n过 decider (进 digest): {len(passed)} 个')
print(f'{"UDO":<28} {"DistClient":>10} {"script":>7} {"verdict":>7} props cs meth')
for n, dc, sc, v, np_, nc, nm, dp in rows:
    print(f'{n:<28} {str(dc):>10} {str(sc):>7} {str(v):>7} {np_:>5} {nc:>2} {nm:>4}')

print(f'\n=== 汇总 ===')
print(f'总数 {len(rows)}, 过 {len(passed)}, 不过 {len(rows)-len(passed)}')
print(f'过的: {[r[0] for r in passed]}')
