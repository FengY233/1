#!/usr/bin/env python3
"""t40_vlh.py — 全量普查 VariableLengthHeaderSize 声明 + 静态组件属性合并清单
A) 所有 def 文件中的 vlh 声明（entity_defs + component_defs + interfaces + 扩展）
B) 16 静态组件的挂载边与属性贡献（ofEntity → props）
C) 受影响实体的 csi 空间重算（own + component 合并, baseIndex 机制）
"""
import sys, os, glob
sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file

SCRIPTS = '/tmp/wot_scripts/scripts'
EXT_ROOT = '/tmp/wot/ext_pkg/extracted/wot24_ext_defs/ext_defs'


def find_vlh(path, tag):
    """递归找 def 文件中的 VariableLengthHeaderSize 声明"""
    hits = []
    try:
        root = decode_file(path)
    except Exception:
        return hits

    def walk(node, prop_chain):
        if node.name == 'VariableLengthHeaderSize':
            try:
                v = node.asString()
            except Exception:
                v = '?'
            hits.append((prop_chain, v))
        for c in (node.children or []):
            walk(c, prop_chain if node.name in ('Properties', 'ClientMethods',
                                                'BaseMethods', 'CellMethods',
                                                'Volatile') else
                 (f'{prop_chain}.{node.name}' if prop_chain else node.name))
    walk(root, '')
    return hits


print('=== A) 全 def 树 VariableLengthHeaderSize 声明 ===')
total = 0
for base, tag in [(SCRIPTS, 'main'), (EXT_ROOT, 'ext')]:
    for p in glob.glob(f'{base}/**/*.def', recursive=True):
        hits = find_vlh(p, tag)
        if hits:
            rel = os.path.relpath(p, base)
            for chain, v in hits:
                print(f'  [{tag}] {rel}: {chain} = vlh {v}')
                total += 1
print(f'共 {total} 处 vlh 声明')

print()
print('=== B) 16 静态组件属性贡献 ===')
comps = decode_file(f'{SCRIPTS}/components.xml', 'components.xml')
static = [k.name for k in comps.child('StaticComponents').children]
print(f'StaticComponents 声明序: {static}')
CD = f'{SCRIPTS}/component_defs'
for cname in static:
    p = f'{CD}/{cname}.def'
    if not os.path.exists(p):
        print(f'  {cname}: def 不存在!')
        continue
    root = decode_file(p, cname)
    ofe = root.child('ofEntity')
    targets = [k.name for k in ofe.children] if ofe else []
    props = root.child('Properties')
    prows = []
    if props:
        for c in props.children:
            t = c.child('Type')
            tname = t.asString() if t is not None else '?'
            vlh = ''
            v = c.child('VariableLengthHeaderSize')
            if v is not None:
                vlh = f' vlh={v.asString()}'
            flags = c.readString('Flags') or ''
            prows.append(f'{c.name}:{tname}[{flags}]{vlh}')
    dl = root.readString('DetailLevel') or ''
    print(f'  {cname} -> ofEntity={targets} DL={dl!r} props={prows}')

print()
print('=== C) 客户端 entities.xml CS 实体序（对照挂载目标）===')
ents = decode_file(f'{SCRIPTS}/entities.xml', 'entities.xml')
cs = ents.child('ClientServerEntities')
names = [k.name for k in cs.children] if cs else []
print(f'{len(names)} 实体: {names}')
