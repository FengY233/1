#!/usr/bin/env python3
"""t40_diff.py — Task 40-a 第一步: 运行时观测 vs defparse(wot_scripts) 精确 diff
A) TeamInfo: 11 场 0x05 全量采集 3 个 STR 实际值（猜属性名）
B) Vehicle: defparse 声明序/尺寸/vlh/csi dump vs 运行时 7 锚
C) 推导运行时 def 最小变更集
"""
import sys, os, json, struct
sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import load_pkts, get_b0, REPLAYS, R, w_str
from defparse import EntityDefParser

SCRIPTS = '/tmp/wot_scripts/scripts'

# ============ A) TeamInfo 运行时值 ============
print('=' * 70)
print('A) TeamInfo typeID=28 运行时 0x05 全量采集')
print('=' * 70)
ti_rows = []
for tag, path in REPLAYS:
    try:
        pkts = load_pkts(path)
    except Exception as e:
        print(f'  {tag}: FAIL {e}')
        continue
    for ty, c, pl in pkts:
        if ty != 5 or len(pl) < 47:
            continue
        eid, typeID = struct.unpack_from('<II', pl, 0)
        if typeID != 28:
            continue
        body = pl[46:]
        count = body[0]
        r = R(body, 1)
        props = []
        for i in range(count):
            idx = r.u8()
            if idx == 0:
                v = struct.unpack('<I', r.take(4))[0]
            else:
                v = w_str(r)
            props.append((idx, v))
        exact = (r.q == len(body))
        ti_rows.append({'tag': tag, 'eid': eid, 'props': props, 'exact': exact})
        print(f'  {tag} eid={eid} exact={exact} props={props}')
print(f'  共 {len(ti_rows)} 条, exact {sum(1 for x in ti_rows if x["exact"])}/{len(ti_rows)}')
# STR 值集合
vals = {}
for row in ti_rows:
    for idx, v in row['props']:
        if idx != 0:
            vals.setdefault(idx, {}).setdefault(repr(v), []).append(row['tag'])
for idx in sorted(vals):
    print(f'  idx={idx} 值域: {list(vals[idx].items())[:6]}')

# ============ B) Vehicle defparse 现状 ============
print()
print('=' * 70)
print('B) Vehicle defparse (wot_scripts #942 副本) vs 运行时锚')
print('=' * 70)
parser = EntityDefParser(SCRIPTS)
parser.load()
veh = None
for ed in parser.entities:
    if ed.name == 'Vehicle':
        veh = ed
        break
print(f'Vehicle CS 属性数: {len(veh.cs_props)}')
print(f'{"csi":>3} {"decl":>3} {"size":>4} {"vlh":>3}  name')
rows = []
for idx in veh.cs_props:
    p = veh.properties[idx]
    ss = p.stream_size()
    rows.append((p.csi, idx, ss, p.var_len_header, p.name))
for csi, decl, ss, vlh, name in sorted(rows):
    mark = ''
    print(f'{csi:>3} {decl:>3} {ss:>4} {vlh:>3}  {name}')

# 运行时锚 (§19.4 + §20.3)
ANCHORS = {29: 'perks', 30: 'perksRibbonNotify', 31: 'postmortemViewPointName',
           32: 'publicInfo', 33: 'damageStickers', 34: 'publicStateModifiers',
           40: 'vehPostProgression', 48: 'dogTag'}
print('\n运行时锚比对:')
csi_by_name = {name: csi for csi, decl, ss, vlh, name in rows}
for k in sorted(ANCHORS):
    name = ANCHORS[k]
    got = csi_by_name.get(name)
    print(f'  运行时 {k}={name}: defparse csi={got} {"✓" if got == k else "✗ (Δ%+d)" % (0 if got is None else got - k)}')

# ============ C) TeamInfo defparse 现状 ============
print()
print('=' * 70)
print('C) TeamInfo defparse 现状')
print('=' * 70)
for ed in parser.entities:
    if ed.name == 'TeamInfo':
        print(f'CS 属性数: {len(ed.cs_props)}')
        for idx in ed.cs_props:
            p = ed.properties[idx]
            print(f'  csi={p.csi} decl={idx} size={p.stream_size()} vlh={p.var_len_header} '
                  f'name={p.name} type={p.dt.name}')

# ============ D) 定长组身份 vs 0x07 key 观测 ============
print()
print('=' * 70)
print('D) Vehicle 定长组身份 vs 0x07 key 观测 (§20.3)')
print('=' * 70)
# §20.3 0x07 key 观测: 1=isStrafing/4=siegeState/5=isCrewActive/13=gunAnglesPacked/
#   14=health/15=engineMode/16=avatarID/22=wheelsState/23=stunInfo/27=inspiringEffect
KEY07 = {1: 'isStrafing', 4: 'siegeState', 5: 'isCrewActive', 13: 'gunAnglesPacked',
         14: 'health', 15: 'engineMode', 16: 'avatarID', 22: 'wheelsState',
         23: 'stunInfo', 27: 'inspiringEffect'}
for k in sorted(KEY07):
    name = KEY07[k]
    got = csi_by_name.get(name)
    print(f'  0x07 key{k}={name}: defparse csi={got} {"✓" if got == k else "✗"}')
