#!/usr/bin/env python3
"""csi_v9.py — 修正版 csi 权威表生成器 (v25 模型)
修正: ①AllowNone FD=变长(vanilla 规则) ②静态组件 CS 属性经 baseIndex 并入
输出: /tmp/wot/csi_tables_v9.json + 三实体新表打印
"""
import sys, os, json
sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file
from defparse import EntityDefParser

SCRIPTS = '/tmp/wot_scripts/scripts'
CD = f'{SCRIPTS}/component_defs'


def vanilla_stream_size(p):
    ss = p.stream_size()
    if ss >= 0 and p.dt.kind == 'FIXED_DICT' and p.dt.allow_none:
        return -1
    return ss


def realloc(ed):
    def key(idx):
        ss = vanilla_stream_size(ed.properties[idx])
        return ((0, ss) if ss >= 0 else (1, -ss), idx)
    ed.cs_props.sort(key=key)
    for i, idx in enumerate(ed.cs_props):
        ed.properties[idx].csi = i


def dt_desc(dt):
    k = dt.kind
    if k == 'INT':
        return ('I' if dt.signed else 'U') + str(dt.size * 8)
    if k == 'FLOAT':
        return 'F32' if dt.size == 4 else 'F64'
    if k == 'VECTOR':
        return f'V{dt.n}'
    if k in ('ARRAY', 'TUPLE'):
        return ('ARR' if k == 'ARRAY' else 'TUP') + '<' + dt_desc(dt.elem) + '>'
    if k == 'FIXED_DICT':
        return 'FD' + ('?' if dt.allow_none else '') + '{' + \
               ','.join(dt_desc(t) for _, t in (dt.fields or [])) + '}'
    return k


parser = EntityDefParser(SCRIPTS)
parser.load()
for ed in parser.entities:
    realloc(ed)

# 静态组件挂载
comps = decode_file(f'{SCRIPTS}/components.xml', 'components.xml')
static_list = [k.name for k in comps.child('StaticComponents').children]
mounts = {}
for cname in static_list:
    sec = decode_file(f'{CD}/{cname}.def', cname + '.def')
    ofe = sec.child('ofEntity')
    if ofe:
        for k in ofe.children:
            mounts.setdefault(k.name, []).append(cname)


def comp_props(cname, parser, cache={}):
    if cname in cache:
        return cache[cname]
    p = f'{CD}/{cname}.def'
    if not os.path.exists(p):
        cache[cname] = []
        return []
    sec = decode_file(p, cname + '.def')
    rows = []
    props = sec.child('Properties')
    if props:
        for c in props.children:
            m = parser._parse_property(c)
            if m is None or not m.is_client_server:
                continue
            v = c.child('VariableLengthHeaderSize')
            rows.append((m.name, dt_desc(m.dt), vanilla_stream_size(m),
                         v.asInt(1) if v is not None else 1))
    cache[cname] = rows
    return rows


out = {'_meta': {
    'version': 'v9',
    'model': 'AllowNone FD=variable (vanilla) + static-component CS props merged via baseIndex',
    'date': '2026-09-25',
    'supersedes': 'csi_tables_v8.json (Vehicle 25-30 / Avatar 28+ / TeamInfo 1-3 rows)'}}

print('=' * 78)
for name in ['Vehicle', 'Avatar', 'TeamInfo']:
    ed = [e for e in parser.entities if e.name == name][0]
    rows = []
    for idx in ed.cs_props:
        p = ed.properties[idx]
        rows.append({'csi': p.csi, 'name': p.name, 'type': dt_desc(p.dt),
                     'streamSize': vanilla_stream_size(p),
                     'vlh': p.var_len_header, 'source': 'own'})
    # 组件属性并入
    base = len(ed.cs_props)
    for cname in mounts.get(name, []):
        crows = comp_props(cname, parser)
        order = sorted(range(len(crows)),
                       key=lambda i: (0, crows[i][2]) if crows[i][2] >= 0 else (1, -crows[i][2]))
        for pos, i in enumerate(order):
            nm, tp, ss, vlh = crows[i]
            rows.append({'csi': base + pos, 'name': nm, 'type': tp,
                         'streamSize': ss, 'vlh': vlh,
                         'source': f'component:{cname}'})
        base += len(crows)
    out[name] = {'properties': rows}
    print(f'\n{name}: own {len(ed.cs_props)} + 组件 {sum(1 for r in rows if r["source"] != "own")} = {len(rows)} CS')
    for r in rows:
        mark = ' ★' if r['name'] in ('perks', 'perksRibbonNotify', 'publicInfo',
                                     'damageStickers', 'publicStateModifiers',
                                     'vehPostProgression', 'dogTag') else ''
        print(f"  {r['csi']:>3} {r['streamSize']:>4} {r['vlh']} {r['name']:<28} "
              f"{r['type'][:40]:<40} {r['source'][:32]}{mark}")

json.dump(out, open('/tmp/wot/csi_tables_v9.json', 'w'), ensure_ascii=False, indent=1)
print('\n→ /tmp/wot/csi_tables_v9.json')
