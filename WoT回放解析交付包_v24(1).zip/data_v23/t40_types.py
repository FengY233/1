#!/usr/bin/env python3
"""t40_types.py — dump 关键属性的完整类型树（找 VariableLengthHeaderSize 声明）
覆盖: Wheels/Perks_Vehicle 接口 + Vehicle.def 自有 6 属性 + 相关 alias
"""
import sys, os
sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file

ED = '/tmp/wot_scripts/scripts/entity_defs'


def ttree(node, depth=0):
    """类型节点树: 节名 + 关键子节点（of/Size/AllowNone/VariableLengthHeaderSize）"""
    out = node.name
    kv = []
    for cc in (node.children or []):
        if cc.name in ('of', 'size', 'Size', 'AllowNone', 'allowNone',
                       'VariableLengthHeaderSize', 'Implements'):
            try:
                v = cc.asString()
            except Exception:
                v = '?'
            kv.append(f'{cc.name}={v}')
        elif cc.name == 'Type' or (cc.children and depth < 6):
            sub = ttree(cc, depth + 1)
            if sub:
                kv.append(sub)
    if kv:
        out += '{' + ','.join(kv) + '}'
    return out


def dump_def_props(path, want=None, tag=None):
    sec = decode_file(path, os.path.basename(path))
    props = sec.child('Properties')
    if props is None:
        print(f'  [{tag or path}] 无 Properties')
        return
    print(f'--- {tag or os.path.basename(path)} ---')
    for c in props.children:
        if want and c.name not in want:
            continue
        t = c.child('Type')
        s = ttree(t) if t is not None else '(无Type)'
        print(f'  {c.name}: {s}')


# 接口
dump_def_props(f'{ED}/interfaces/Wheels.def', tag='Wheels 接口')
dump_def_props(f'{ED}/interfaces/Perks_Vehicle.def', tag='Perks_Vehicle 接口')

# Vehicle 自有关键属性
dump_def_props(f'{ED}/Vehicle.def',
               want={'inspired', 'dogTag', 'ownVehiclePosition', 'healing',
                     'healOverTime', 'publicInfo', 'damageStickers',
                     'publicStateModifiers', 'vehPostProgression',
                     'disabledSwitches', 'engineMode'},
               tag='Vehicle.def 自有')

# alias.xml 中相关别名
print('--- alias.xml 相关别名 ---')
alias = decode_file(f'{ED}/alias.xml', 'alias.xml')
WANT = {'INSPIRED_EFFECT', 'OWN_VEHICLE_POSITION', 'BATTLE_DOG_TAG',
        'BUFF_EFFECT_INACTIVATION', 'HOT_EFFECT', 'PERK_INFO_HUD',
        'PERK_INFO_RIBBON', 'PERK_EFFECTS', 'PUBLIC_VEHICLE_INFO',
        'BUFF_EFFECT', 'STUN_INFO', 'DOT_EFFECT'}
for c in alias.children:
    if c.name in WANT:
        print(f'  <{c.name}>: {ttree(c)}')
