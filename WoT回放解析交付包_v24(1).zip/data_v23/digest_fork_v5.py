#!/usr/bin/env python3
"""digest_fork_v5.py — Task 40-a 终局轮: 五修正版 digest 复现器

v16 模型 (digest_fork_v2) + Task 40 修正:
  修正1 AllowNone FD = -1 变长 (vanilla fixed_dict_data_type.cpp:441)
       实证: key27=wheelsScroll 9B TUPLE / Vehicle 变长组 26-49 七锚 / Avatar 4 键
  修正2 方法 flags = u8 1 字节 (slot10=+0x50=FUN_1403e8230, FUN_142aa17d0 反编译:
       *param_2+0x50(param_2,"flags",*(u8*)(this+0x70)) — movzx 单字节装载)
       → 推翻 v15「u16 2 字节」误判 (把调用点 movzx 误读为 u16 槽证据)
  修正3 组件 CS 属性不进 digest (喂入器 FUN_142a93420 属性循环只走父向量 +0x28..0x30,
       子描述 +0x2f0 只进方法域) — 实证: TeamInfo 0x05 idx1-3=组件属性(Python pickle 空字典)
       只影响网络 csi 空间 (baseIndex 链), 不进 digest 喂入
  (修正4/5 = v2 原有正确项: 属性 flags u32 slot5+0x28 / isVolatile u8 slot11+0x58)

喂入格式 (每记录, FUN_142a93420 + FUN_142a9b6e0/142a894e0/142abc050/142aa17d0 全链反编译验证):
  name(slot12 无NUL) → 逐 CS 属性(声明序, flags&0x106 过滤):
    [csi u32][vlh u32 if isForClient&&ss<0&&vlh≠1][name slot12][flags&0x5F u32][isVolatile u8][type]
  → 方法三域 client(2)→base(1)→cell(4), 各域 (flags&0xC)!=0 过滤, 自有在前组件在后:
    [vlh u32 if client域&&var&&vlh≠1][name][flags u8 ★][args][idx u32]
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bwxml import decode_file
from defparse import (EntityDefParser, EntityDescription, MD5,
                      COMP_BASE, COMP_CELL, COMP_CLIENT,
                      DATA_DISTRIBUTION_FLAGS)
from digest_fork_v2 import (SCRIPTS, EXT_ROOT, CD, SD, CLI, TARGET,
                            _has_script, ext_client_has_script, DefLocator,
                            parse_comp_record, load_static_comp,
                            parse_space_record, iter_extensions,
                            parse_ext_entities, parse_ext_dyncomps,
                            DOM_ATTR)

DATA_PERSISTENT = 0x10
DATA_ID = 0x20


def vanilla_stream_size(p):
    """修正1: FD+AllowNone → -1 (vanilla streamSize_(allowNone_ ? -1 : 0))"""
    ss = p.stream_size()
    if ss >= 0 and p.dt.kind == 'FIXED_DICT' and p.dt.allow_none:
        return -1
    return ss


def realloc_csi_v3(ed):
    def key(idx):
        ss = vanilla_stream_size(ed.properties[idx])
        # (定长在前/变长 vlh 升序) + 声明序 tiebreak（cs_props 已被 v8 规则排过序，
        # 稳定排序会保留 v8 残序而非声明序 —— 必须显式用声明位 idx 做 tiebreak）
        return ((0, ss) if ss >= 0 else (1, -ss), idx)
    ed.cs_props.sort(key=key)
    for i, idx in enumerate(ed.cs_props):
        ed.properties[idx].csi = i


def _prop_to_md5(md5, p, csi):
    ss = vanilla_stream_size(p)
    md5.append_int32(csi)
    if ss < 0 and p.var_len_header != 1:
        md5.append_uint32(p.var_len_header)
    md5.append(p.name.encode('utf-8'))
    md5.append_int32(p.flags & DATA_DISTRIBUTION_FLAGS)
    md5.append_uint8(getattr(p, 'is_volatile', 0))
    p.dt.add_to_md5(md5)


def _method_to_md5_v5(md5, m, idx, domain='client'):
    """修正2: flags = u8 1 字节 (推翻 v15 u16)"""
    if domain == 'client':
        if m.var_len_header != 1 and m._stream_size < 0:
            md5.append_uint32(m.var_len_header)
    md5.append(m.name.encode('utf-8'))
    md5.append_uint8(m.flags)          # ★ u8 (was uint16 in v2!)
    for a in m.args:
        a.add_to_md5(md5)
    md5.append_int32(idx)


def fork_add_to_md5_v5(ed, md5):
    md5.append(ed.name.encode('utf-8'))
    for p in ed.properties:
        if not p.is_client_server:
            continue
        _prop_to_md5(md5, p, p.csi)
    for domain, own_list in (
            ('client', ed.client_methods),
            ('base', ed.base_methods),
            ('cell', ed.cell_methods)):
        count = 0
        for m in own_list:
            if not (m.flags & 0xC):
                continue
            _method_to_md5_v5(md5, m, count, domain)
            count += 1
        for sd in getattr(ed, 'fork_components', []):
            for m in getattr(sd, DOM_ATTR[domain]):
                if not (m.flags & 0xC):
                    continue
                _method_to_md5_v5(md5, m, count, domain)
                count += 1


def build_records():
    parser = EntityDefParser(SCRIPTS)
    parser.load()

    comps_root = decode_file(os.path.join(SCRIPTS, 'components.xml'),
                             'components.xml')
    static_list = [k.name for k in comps_root.child('StaticComponents').children]
    dyn_list = [k.name for k in comps_root.child('DynamicComponents').children]

    mounts = {}
    for cname in static_list:
        sec = decode_file(os.path.join(CD, cname + '.def'), cname + '.def')
        ofe = sec.child('ofEntity')
        if ofe is not None:
            for k in ofe.children:
                mounts.setdefault(k.name, []).append(cname)

    sub_cache, rec_cache, comp_cache = {}, {}, {}
    locator = DefLocator([])

    records = [parse_space_record(parser)]
    for ed in parser.entities:
        ed.fork_components = [load_static_comp(parser, locator, c, sub_cache)
                              for c in mounts.get(ed.name, [])]
        realloc_csi_v3(ed)
        records.append(ed)
        rec_cache[ed.name] = ed
    n_main = len(records) - 1

    exts = iter_extensions()
    n_ext_ent = 0
    for ext in exts:
        eloc = DefLocator([os.path.join(EXT_ROOT, ext, '_raw')])
        for ed in parse_ext_entities(parser, eloc, ext, rec_cache):
            realloc_csi_v3(ed)
            records.append(ed)
            n_ext_ent += 1

    seen = set()
    for name in dyn_list:
        if name in seen:
            continue
        seen.add(name)
        if not _has_script(CLI, name):
            continue
        ed = parse_comp_record(parser, locator, name, comp_cache)
        ed.fork_components = []
        realloc_csi_v3(ed)
        records.append(ed)
        rec_cache[ed.name] = ed
    n_main_dyn = len(records) - 1 - n_main - n_ext_ent

    n_ext_dyn = 0
    for ext in exts:
        eloc = DefLocator([os.path.join(EXT_ROOT, ext, '_raw')])
        eds, sk = parse_ext_dyncomps(parser, eloc, ext, rec_cache, comp_cache)
        for ed in eds:
            realloc_csi_v3(ed)
            records.append(ed)
            n_ext_dyn += 1

    print(f'records = 1 + {n_main} + {n_ext_ent} + {n_main_dyn} + {n_ext_dyn} '
          f'= {len(records)}')
    return records


def run(tag, records, meth_u8=True, allownone=True):
    global vanilla_stream_size, _method_to_md5_v5
    orig_ss = vanilla_stream_size
    orig_m = _method_to_md5_v5
    if not allownone:
        vanilla_stream_size = lambda p: p.stream_size()

    def m16(md5, m, idx, domain='client'):
        if domain == 'client':
            if m.var_len_header != 1 and m._stream_size < 0:
                md5.append_uint32(m.var_len_header)
        md5.append(m.name.encode('utf-8'))
        md5.append_uint16(m.flags)
        for a in m.args:
            a.add_to_md5(md5)
        md5.append_int32(idx)

    if not meth_u8:
        _method_to_md5_v5 = m16

    md5 = MD5()
    for ed in records:
        fork_add_to_md5_v5(ed, md5)
    d = md5.getDigestQuote()
    hit = '★★★ 命中目标!!!' if d == TARGET else '≠'
    print(f'[{tag}] {d} {hit}')
    _method_to_md5_v5 = orig_m
    vanilla_stream_size = orig_ss
    return d


def main():
    records = build_records()
    print(f'[目标] {TARGET}')
    # 消融矩阵 (csi 已按各变体独立重建)
    run('v5 = AllowNone变长 + 方法flags u8', records, True, True)
    run('方法flags u8 + 旧AllowNone(定长)', records, True, False)


if __name__ == '__main__':
    main()
