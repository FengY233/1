#!/usr/bin/env python3
"""t40_aliascmp.py — wot_scripts(BWXML) vs client wot_src(XML) alias.xml 全量对比
三源归因关键证据: 客户端与服务器 alias 是否漂移
"""
import sys, hashlib
import xml.etree.ElementTree as ET
sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file


def canon_bw(node):
    """BWXML section -> 规范化元组 (name, value, [children])"""
    try:
        v = node.asString()
    except Exception:
        v = ''
    return (node.name, v or '', tuple(canon_bw(c) for c in (node.children or [])))


def canon_xml(elem):
    """XML element -> 同构规范化元组"""
    return (elem.tag, (elem.text or '').strip(),
            tuple(canon_xml(c) for c in elem))


def load_bw(path):
    root = decode_file(path)
    return {c.name: canon_bw(c) for c in root.children}


def load_xml(path):
    tree = ET.parse(path)
    return {c.tag: canon_xml(c) for c in tree.getroot()}


a = load_bw('/tmp/wot_scripts/scripts/entity_defs/alias.xml')
b = load_xml('/tmp/my-project/repos/wot_src_full/sources/res/scripts/entity_defs/alias.xml')
print(f'wot_scripts(#942 BWXML): {len(a)} 个别名')
print(f'client wot_src(XML):     {len(b)} 个别名')
print(f'仅在 wot_scripts: {sorted(set(a) - set(b))}')
print(f'仅在 client:     {sorted(set(b) - set(a))}')

diff = sorted(k for k in set(a) & set(b) if a[k] != b[k])
print(f'\n内容不同: {len(diff)} 个')
for k in diff:
    print(f'\n=== {k} ===')
    print(f'  wot_scripts: {a[k]}')
    print(f'  client:      {b[k]}')

# 重点别名专项检查
FOCUS = ['INSPIRED_EFFECT', 'OWN_VEHICLE_POSITION', 'BATTLE_DOG_TAG',
         'PERK_EFFECTS', 'PERK_INFO_HUD', 'PERK_INFO_RIBBON']
print('\n--- 重点别名状态 ---')
for k in FOCUS:
    where = []
    if k in a:
        where.append('wot_scripts✓')
    if k in b:
        where.append('client✓')
    same = (k in a and k in b and a[k] == b[k])
    print(f'  {k}: {"=".join(where)} {"SAME" if same else ("DIFF" if (k in a and k in b) else "")}')
