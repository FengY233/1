#!/usr/bin/env python3
"""t40_key27.py — 决定性判别: 0x07 key27 body 形态
  新模型: 27=wheelsScroll (TUPLE<UINT8> = [pi n][n×u8], n≈2-16, 短包)
  旧模型: 27=inspiringEffect (BUFF_EFFECT = F32+F64+F64+F32 = 24B 定长)
同时采集 key22(wheelsState u64=8B)/key23(stunInfo F64=8B)/key5(isCrewActive u8=1B) 对照
"""
import sys, struct, collections
sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import load_pkts, REPLAYS

bodies = collections.defaultdict(list)
for tag, path in REPLAYS[:4]:
    for ty, c, pl in load_pkts(path):
        if ty != 7 or len(pl) < 12:
            continue
        eid, key, blen = struct.unpack_from('<III', pl, 0)
        if key in (5, 22, 23, 27, 28, 26, 44, 42, 43):
            bodies[key].append((tag, pl[12:12 + blen]))

for key in sorted(bodies):
    bs = bodies[key]
    lens = collections.Counter(len(b) for _, b in bs)
    print(f'key={key}: n={len(bs)} body长度分布: {dict(sorted(lens.items())[:12])}')
    for tag, b in bs[:3]:
        print(f'   [{tag}] {b.hex()}')
    print()
