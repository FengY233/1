#!/usr/bin/env python3
"""t40_keys2.py — 0x07 key 直方图按实体类型分组（Vehicle eid vs 其他）
判别目标:
  1) key27(1,618×9B TUPLE<U8>) 是否全落 Vehicle eid → wheelsScroll 实锤
  2) 新模型 AllowNone-FD 位 42=inspiringEffect/43=healingEffect/44=dotEffect/
     45=inspired/46=healing/47=healOverTime/49=ovp 的 body 形态
     (AllowNone FD = [u8 hasValues][fields], None 时 1B '00')
  3) key19(39,352×8B) 归属哪个实体
"""
import sys, struct, collections
sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import load_pkts, REPLAYS

for tag, path in REPLAYS[:6]:
    # 建 eid → typeID 映射（0x05 创建集）
    eid_type = {}
    pkts = load_pkts(path)
    for ty, c, pl in pkts:
        if ty == 5 and len(pl) >= 47:
            eid, typeID = struct.unpack_from('<II', pl, 0)
            eid_type[eid] = typeID
    hist_v = collections.Counter()   # Vehicle
    hist_o = collections.defaultdict(collections.Counter)  # 其他按 typeID
    lens_v = collections.defaultdict(collections.Counter)
    samples = {}
    for ty, c, pl in pkts:
        if ty != 7 or len(pl) < 12:
            continue
        eid, key, blen = struct.unpack_from('<III', pl, 0)
        t = eid_type.get(eid)
        if t == 6:
            hist_v[key] += 1
            lens_v[key][len(pl[12:12 + blen])] += 1
            if key not in samples:
                samples[key] = pl[12:12 + blen].hex()
        elif t is not None:
            hist_o[t][key] += 1
    print(f'=== {tag} ===')
    print('  Vehicle keys:', {k: v for k, v in sorted(hist_v.items())})
    for k in sorted(lens_v):
        if k in (27, 42, 43, 44, 45, 46, 47, 49, 28, 26):
            print(f'    key{k}: lens={dict(sorted(lens_v[k].items()))} 样例 {samples.get(k, "")[:60]}')
    print('  其他实体 keys:', {t: dict(sorted(h.items())[:8]) for t, h in sorted(hist_o.items())})
    print()
