#!/usr/bin/env python3
"""t40_alias.py — dump Vehicle 相关 alias 全字段类型 + defparse streamSize 判定
目的: 找出 变长组(-1) vs 尾组(≤-2) 的类型学差异
"""
import sys, os
sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file
from defparse import EntityDefParser, DT

SCRIPTS = '/tmp/wot_scripts/scripts'
parser = EntityDefParser(SCRIPTS)
parser.load()

WANT = ['BUFF_EFFECT', 'BUFF_EFFECT_INACTIVATION', 'HOT_EFFECT', 'INSPIRED_EFFECT',
        'OWN_VEHICLE_POSITION', 'DOT_EFFECT', 'STUN_INFO', 'PERK_INFO_HUD',
        'PERK_INFO_RIBBON', 'PERK_EFFECTS', 'VEHICLE_HIT_POINT', 'EXTRA_ID',
        'PUBLIC_VEHICLE_INFO', 'BATTLE_DOG_TAG', 'REMOTE_CAMERA_DATA']

def dt_desc(dt, depth=0):
    k = dt.kind
    if k in ('INT',):
        return f"{'I' if dt.signed else 'U'}{dt.size*8}"
    if k == 'FLOAT':
        return f"F{32 if dt.size==4 else 64}"
    if k == 'VECTOR':
        return f"V{dt.n}"
    if k in ('ARRAY', 'TUPLE'):
        return f"{'ARR' if k=='ARRAY' else 'TUP'}<{dt_desc(dt.elem, depth+1)}>" + \
               (f"[{dt.seq_size}]" if dt.seq_size != 0 else '')
    if k == 'FIXED_DICT':
        fs = ', '.join(f"{n}:{dt_desc(t, depth+1)}" for n, t in (dt.fields or []))
        return f"FD{'?' if dt.allow_none else ''}{{{fs}}}"
    return k

print(f'{"alias":<24} {"streamSize":>9}  结构')
for name in WANT:
    dt = parser.alias.get(name)
    if dt is None:
        print(f'{name:<24} {"(不在alias)":>9}')
        continue
    print(f'{name:<24} {dt.streamSize():>9}  {dt_desc(dt)}')

# Vehicle 全变长组属性的类型 + streamSize（defparse 口径）
print()
print('=== Vehicle 变长组（defparse wot_scripts 口径）===')
veh = [e for e in parser.entities if e.name == 'Vehicle'][0]
for idx in veh.cs_props:
    p = veh.properties[idx]
    ss = p.stream_size()
    if ss < 0:
        print(f'  decl={idx:>2} vlh={p.var_len_header} size={ss:>2} '
              f'{p.name:<24} {dt_desc(p.dt)}')

print()
print('=== Vehicle 定长组尾部（csi 24-30）===')
for idx in veh.cs_props:
    p = veh.properties[idx]
    ss = p.stream_size()
    if 0 <= ss and p.csi >= 24:
        print(f'  csi={p.csi:>2} decl={idx:>2} size={ss:>2} '
              f'{p.name:<24} {dt_desc(p.dt)}')
