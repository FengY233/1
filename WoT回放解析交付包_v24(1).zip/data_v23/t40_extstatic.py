#!/usr/bin/env python3
"""t40_extstatic.py — 扩展 <Components><StaticComponents> 全量枚举
v2 模型只处理根级 ExternalComponents(空) + DynamicComponents；
<Components><StaticComponents> 若被 fork 挂载 → 组件方法进父记录 digest + 属性进 csi!
"""
import sys, os
sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file

EXT_ROOT = '/tmp/wot/ext_pkg/extracted/wot24_ext_defs/ext_defs'
SCRIPTS = '/tmp/wot_scripts/scripts'

# CS 实体集（挂载目标必须在此）
ents = decode_file(f'{SCRIPTS}/entities.xml', 'entities.xml')
cs_names = {k.name for k in ents.child('ClientServerEntities').children}
print(f'CS 实体: {len(cs_names)} 个')

total_edges = 0
edge_rows = []
for ext in sorted(os.listdir(EXT_ROOT)):
    p = f'{EXT_ROOT}/{ext}/_raw/extension.xml'
    if not os.path.exists(p):
        continue
    sec = decode_file(p, 'extension.xml')
    comps = sec.child('Components')
    if comps is None:
        continue
    stat = comps.child('StaticComponents')
    if stat is None or not stat.children:
        continue
    for k in stat.children:
        name = k.name
        # ofEntity 从组件 def 读取（ext _raw/component_defs 优先, 回退主树）
        dpath = None
        for cand in (f'{EXT_ROOT}/{ext}/_raw/component_defs/{name}.def',
                     f'{SCRIPTS}/component_defs/{name}.def'):
            if os.path.exists(cand):
                dpath = cand
                break
        targets, nprops, nmeth = [], 0, 0
        if dpath:
            dsec = decode_file(dpath, name + '.def')
            ofe = dsec.child('ofEntity')
            if ofe:
                targets = [x.name for x in ofe.children]
            props = dsec.child('Properties')
            nprops = len(props.children) if props else 0
            nmeth = sum(len(dsec.child(t).children) for t in
                        ('ClientMethods', 'BaseMethods', 'CellMethods')
                        if dsec.child(t) is not None)
        else:
            targets = ['<def不存在>']
        valid = [t for t in targets if t in cs_names]
        total_edges += len(targets)
        edge_rows.append((ext, name, targets, valid, nprops, nmeth))

print(f'\n扩展 StaticComponents 边总数: {total_edges}')
print(f'\n{"扩展":<22} {"组件":<38} {"ofEntity":<28} {"有效":<10} props methods')
for ext, name, targets, valid, nprops, nmeth in edge_rows:
    print(f'{ext:<22} {name:<38} {",".join(targets) or "-":<28} '
          f'{",".join(valid) or "-":<10} {nprops:>5} {nmeth:>7}')

nv = sum(len(v) for _, _, _, v, _, _ in edge_rows)
print(f'\n落在 CS 实体上的有效挂载边: {nv}')
