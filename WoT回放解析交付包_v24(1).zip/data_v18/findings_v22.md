# WoT 回放逆向 · 结论登记册（findings.md）

- 重建时间：2026-09-24（会话环境曾被完全重置一次：`upload/` 清空、`/tmp` 清空、原 findings.md / worklog.md / scripts / csi_tables_v8.json 丢失。本文件依据会话摘要 + 本轮新证据重建；v1–v8 为摘要级复述，细节论证过程已失；v9 起为逐字可验的新结论。）
- **v12（2026-09-24）**：全部失散资产已从 FengY233/test 恢复（csi_tables_v8.json / V7 交付包 / 会话记录.txt，见附录 A）；重置前原版 findings.md（v8 全细节版）亦在仓库中寻回；本册为当前最全结论登记。
- **v13（2026-09-24）**：§9 新增——EntityDescriptionMap::parse 全架构白盒（挂载规则全解 + records 集合真相）；§5/§7 增补 fork 增量④⑤（client 方法出局 / FIXED_DICT 定长化，后者推翻 v8 的「+5=组件注入」归因，40/40 实体 csi 全对账）；§6 开放项刷新；附录 E 新证据坐标。
- **v14（2026-09-24）**：**§10 新增——FeatureExtension 体系发现（本轮最大突破）**：客户端存在 18 个全部 IsEnabled=true 的 res/<ext>/extension.xml，向 digest 贡献扩展记录（v13 的「干净安装=空树」判断被推翻，records 集合实为 318 条而非 148 条）；另完成全链字节级复核（walker 计数器/isForClient/ExposedForReplay/DT 层 24 feeder/parseProperties 全链/迭代序），全部与模型一致；§6 开放项改写；附录 F 新证据坐标。
- **v15（2026-09-24 深夜）**：§11——扩展 def 到货（wot24_ext_defs.zip 十项对账 95 PASS）→ 318 记录全模型实算（20E4276E）+ u16 真 bug 修复（方法 flags 2 字节，v9-v13 集体漏读 slot10）；推翻 v14 两处（Part b=ExternalComponents 全空→0 扩展挂载边；FeatureName 键有序 map→字母序双成立）；「全层汇编级验证」时代。
- **v16（2026-09-24 终局轮）**：**§12 新增——最后一轮全部结论**：版本疑云彻底解除（#942 钉死，#938→#942 仅 6 文件零 def 变更）；0x3D 方向判定（LogOnParams 上行）；★client 方法自动 |=0x4 三方铁证（decomp+vanilla+0x08 运行时 128 对全命中）——v13「client 全出局」判反，163→366 方法修正；★网络 methodID 机制全解（exposedMethods_ stable_sort by streamSize，与 csi 排序同构）；★entities.xml 真实声明序发现（非字母序）+ NetworkEntity n=40 索引布局铁证；修复后 digest=5976CA14（V12 重建脚本精确复现）仍≠目标；剩余偏差锁定 dyncomp 记录（84% 无真值源）。
- **v17（2026-09-25 · 11 场回放真值锚轮）**：**§13 新增——新回放真值锚大样本扩充**：★digest 版本指纹恒定性实锤（11 场 EU/NA/CN 混合样本 0x3D 全部=5DF886F7 目标值，与区域/日期/mods 全无关）；★0x05 头格式钉死 [u32 eid][u32 typeID]（1,486 对 jsonl 校准零失配）+ typeID=entities.xml 声明序 1 基编号全表对齐（9 种网络创建实体）；★未识别实体识别为 Avatar + methodID 表 70 方法跨场语义级验证（18 mid × 11 场行为吻合，methodID 机制验证从 1 场 128 对升级到 11 场语义级）；★jsonl m 字段错位标注最终实锤（mid=58=stopTracer 非 updateArena）。11 场全为随机战家族（含 battleType=46=RANDOM_NP2 变体），无扩展模式。〔v18 勘误：§13.2「#942 客户端安装指纹」定性被 block0 构建号证据推翻，见 §14.1〕
- **v18（2026-09-25 · 技能体系分离 + 动态组件通道轮）**：**§14 新增**：★回放归属终局（block0 clientVersionFromXml 构建号：3×CN#942 + 3×EU#935 + 4×EU#944 + 1×NA#945）→ digest 定性修正为「2.4.0.0 世代跨构建跨区域统一 EntityDescriptionMap 指纹」，§11.5 数据同期性假设①②③全部排除；★技能体系三分离 def 级实证（csi34=perks 乘员 vs csi44/45=vehPerks/vehPostProgression 车辆技能，0x07 键观测互证）；★0x07 原始格式钉死 [u32 eid][u32 key][u32 blen][body]（37,105/37,105 全命中）；★0x05 创建块全格式（[u32 propBytes][u8 count]×[u8 csi][typed value]，health/avatarID 语义锚）；★**CSI≥50 扩展区 = 动态组件属性通道（本轮最大发现）**——0x05 索引空间 = 实体自身(0-49)+挂载组件(50+)，1,092 车全量观测 45-208B/车，dyncomp 从「网络不可见」变为「0x05 可观测」，真值锚通道打开；★有 vpp 车 extlen 中位 117 vs 无 vpp 93（+25% = 技能组件字节签名）；★0x39 = 游戏对象复制流（NetworkReplicationPointComponent，首个获运行时观测的 dyncomp）；BigWorld vanilla 参考实现全席就位（onProperties/数据类型 addToMD5）。
- **v19（2026-09-25 · 0x05 属性流终局 + MY_VEHICLE 分层 + 网络索引重排 · §15.4/15.5 已被 v20 修正）**：**§15 新增**：★0x05 属性流 vanilla 纯格式四实体铁证（NetworkEntity count=3: scale VECTOR3+uuid STRING+prefab_path STRING 逐字节吻合）；★PyEntity::initCellEntityFromStream 客户端白盒（[u8 count][[u8 idx][value]]，idx→desc 经 FUN_142a93050 baseIndex 归属）；★线编码规则全集钉死（packedInt 变长头 <0xFF 单字节 / FD allow_none=[u8 0/1] / 定长 TUPLE 直出）；★**DetailLevel=MY_VEHICLE 分层发现（本轮最大发现之一）**——Vehicle 10 属性本车专属（crewCompactDescrs/enhancements/setups/setupsIndexes/vehPerks/disabledSwitches/isMyVehicle/quickShellChangerFactor/onRespawnReloadTimeFactor/ownVehiclePosition）；★**网络 idx MY_VEHICLE 过滤重排数学全解**——变长组剔 5 个 MY_VEHICLE 后 vpp 从 45 移到 **40（754/754 车零偏差铁证）**，0x05 idx=过滤重排版、0x07 key=全属性版（key1-38 全吻合无移位组）；★alias 级 AllowNone 97/202 发现（defparse 漏读项，digest 主线影响待评估）；★全局组件注册表（components.xml 16 static + 113 dynamic）+ 85 组件 185 CS 属性表；★同型车扩展区模板恒定性 33%（184 组 62 组全同）；★尾部骨架熵剖析（`21 00`×619 / `22 00`×1058 / `30 02`×1092 / `28 01`+vpp×754 / `2c 01`×788 / `09 42`×639，f32 锚 4976/4884/2624）。

- **v20（2026-09-25 · 0x05 全通道语义解码终局）**：**§16 新增——Task 35 决定性轮**：★★推翻 §14.5「CSI≥50 扩展区=动态组件通道」（publicInfo 误走伪影，0x05 无组件段）；★★RULE X 网络 idx 表（定长组=v8 + 变长组 31-49 重排：publicInfo@32/vpp@40/dogTag@48 三锚全验证）；★eid==roster.avatarSessionID join 修正（1092/1092）；★publicInfo.name=fakeName 匿名化机制（1092/1092）；★0x07/0x05 同表三判别（key23=stunInfo FLOAT8 / key34=ARRAY&lt;INT1&gt; / key38=pickle）；★运行时 def≠wot_scripts 副本铁证（TeamInfo +3 属性）→ digest 偏差归因需重估；★35-d 闭环（alias AllowNone 已入 defparse FD 喂入，与 vanilla 一字节 bool 同构）；★终局解码器 p05_decoder.py：11 场 × 7 实体类型 6,899/6,899 字节级 100% 精确（含 v19 遗漏的 tundra 场）。
- **v21（2026-09-25 · 0x24 通道全协议白盒 · 本册当前版本）**：**§17 新增——Task 36 决定性轮（第 4 次环境重置后同日恢复+攻坚）**：★★0x24 = 嵌套/切片属性更新通道全白盒（decomp 写入器 FUN_140587300 = `WGReplayMessageHandler::getFile` ↔ vanilla `onNestedEntityProperty(id, data, isSlice)` 双消息 nestedEntityProperty/sliceEntityProperty 三方闭环）；★★payload 压缩路径位流全解（MSB-first BitReader 逐位白盒 + 首层 index=csi 位宽 bitsRequired(numCS)，写入端 addCompressedPathToStream 逐行对照）；★11 场 5,241 包 100% len 吃满 + 全量分类落定（perkEffects×1,497 / destroyedFragiles×2,173 / ownVehiclePosition×496 / perks×170 / inspired×168 / fallenTrees×573…）；★旧报告 v6「0x24=火炮瞄准装填参数」推断推翻（`ba 01` 实为位流 [1][csi=29 ownVehiclePosition]）；★perks slice(0,2)+0B×159 = 数组删除语义实证；★AllowNone=[u8 hasValues] 流格式双通道实证（0x07 csi=30 body='00' ↔ vanilla FixedDictStartStreamElement）；★dec.7z 真相定案（=decomp.zip 的 AES 容器，内层 md5 逐字节一致）；★第 4 次重置全量恢复（BigWorld 核心源码子树 + wot_src 关键文件 + ext_pkg 重拉，门户重启）。
- 同步位置：`/home/z/my-project/findings.md` ≡ `upload/findings.md` ≡ `download/findings.md`（三处 md5 一致）
- 登记制度（用户指令）：新结论确认后及时写入本册并在附录留痕，每次更新三处同步。

## 0. 对象与目标
- 样本：`20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay`（2.4.0.0 CN 客户端录制，1x 实时）
- 已通透（v1–v7）：容器格式 / 加密 / 包流 / 38 种包类型 / 时钟（float32 秒）
- 当前主线：**0x3D 包 = entityDefs 摘要**
  - 目标值：`5DF886F75E73B33CFF9D87FB9C69389C`（replay.jsonl 第 4 行，t=61，MD5 quote 大写 hex，全流唯一；replay.jsonl 已从 FengY233/test 恢复并核对此行）

## 1. [v8 · 已闭环] 0x07/0x24 属性号 = csi
- 40 实体 / 306 条 CS 属性，14 锚点验证；权威表 `csi_tables_v8.json`（**v12 已从 FengY233/test 恢复**，md5 `5ac32922ca7a61fd0cd144b52405cd86`，44,158B；已随 V9 交付包分发）。
- 遗留属性确名：**1=isStrafing、16=avatarID、33=perkEffects、34=perks**。
- 服务器 273 个 .def（EN/pxml）可用用户权威版 `tools/bwxml_decode.py`（勿替换）全量解码；**v11 起已恢复**（upload/bwxml_decode.py，3930B）。

## 2. [v8→v11] 0x3D 算法归属与配方状态
- 0x3D = **WoT fork 重写版** entity_description_digests（IMD5Calculator/MD5Visitor 体系；vanilla 14.4.1 无此架构）。
- **v11：fork 完整配方已从 decomp 逐函数解出**（见 §7），与 vanilla 的差异收敛为三个确定项 + 一个待定项（组件挂载规则）。
- 已排除：vanilla 全复刻、15,552 组合暴力、122,880 结构族网格、原始字节族 14 式、UDO 并入族 18 式、编码层（NUL/宽度/端序/掩码）系统性排除。

## 3. [v9 · 2026-09-24] BW::MD5Calculator vtable 全解 —— 0x3D 的 MD5 层闭合

### 3.1 表结构（用户 Ghidra 导出 + 本机交叉验证通过）
- `BW::MD5Calculator::vftable`：COL 指针在 `0x1439230B0`（值 `0x143EA00A8` → `.?AVMD5Calculator@BW@@`），**slot0 在 `0x1439230B8`，共 15 槽**；对象 vptr = slot0 地址（MSVC ABI）。
- 原始字节 ↔ 槽表 17 个 qword 逐一核对一致（0x142A9B580 | 4×0x1402F7290 | 0x1403E8290/260/230/290/260/230/230/210/1E0 | 0x1402ED600）。
- RTTI 零间隙邻接（交叉验证边界）：
  - IMD5Calculator slot0 = `0x143923038`（其析构 FUN_142a9b550 写入 vptr 的值；MSVC ABI 要求该值 = slot0 地址）
  - `0x143923038 + 15×8 = 0x1439230B0` = MD5Calculator 的 COL → **IMD5Calculator 也恰 15 槽**（干净继承：全量覆写、不加槽；其 1–14 槽全为 `_purecall`@0x142C96CB2 = 纯虚）
  - `0x1439230B0 + 8 + 15×8 = 0x143923130` = AbstractMD5Visitor 的 COL → 零间隙

### 3.2 槽位 → 虚调用偏移 → 字节编码（**v11 机器码级终验**）
| 槽 | 偏移 | 语义 | 函数 | 字节贡献 |
|---|---|---|---|---|
| 0 | +0x00 | scalar deleting dtor | FUN_142a9b580 | — |
| 1–4 | +0x08..+0x20 | **空壳**（COMDAT 折叠进 AkStompAllocatorInitForThread，单条 ret） | 0x1402F7290 | **无（no-op 钩子）** |
| 5 | +0x28 | update(u32) 族A | FUN_1403e8290 | 4 字节 LE |
| 6 | +0x30 | update(u16) 族A | FUN_1403e8260 | 2 字节 LE |
| 7 | +0x38 | update(u8) 族A | FUN_1403e8230 | 1 字节 |
| 8 | +0x40 | update(u32) 族B | FUN_1403e8290 | 4 字节 LE |
| 9 | +0x48 | update(u16) 族B | FUN_1403e8260 | 2 字节 LE |
| 10 | +0x50 | update(u8) 族B | FUN_1403e8230 | 1 字节 |
| 11 | +0x58 | update(u8) 族B' | FUN_1403e8230 | 1 字节 |
| 12 | +0x60 | update(std::string) | FUN_1403e8210 | size 字节，**无 NUL、无长度前缀**；第 2 参数（标签名）被忽略 |
| 13 | +0x68 | update(const char*) | FUN_1403e81e0 | strlen+1 字节，**含 NUL**；第 2 参数（标签名）被忽略 |
| 14 | +0x70 | digest() | FUN_1402ed600 | return this+8（兼作「取 state 指针」惯用法：调用点先 slot14 再直调 worker FUN_1403e82c0 喂 4 字节） |

**v11 铁证**：FUN_142a9b640 机器码 `48 8d 05 45 7a e8 00`（lea rax,[rip+…]）解码目标 = **0x1439230B8**，即 vptr = slot0 首项，无 COL 位移歧义。slot3（+0x18）/slot4（+0x20）确为**空函数**（0x1402F7290 实测单字节 `c3` ret）→ **v9 的「+0x18 slot3 异常」闭合：所有经 +0x18 的调用（"properties"/"baseMethods"/"clientMethods"/"cellMethods" 段标记、成员名 no-op 预告）和经 +0x20 的 endSection 全部不贡献任何字节**。

### 3.3 对象布局（0x60 = 96 字节，Init/Final 机器验证）
`+0x00 vptr | +0x08 count(8B) | +0x10 A,B,C,D（Init 直写 67452301/efcdab89/98badcfe/10325476，与 RFC1321 逐项吻合）| +0x20 buf[64]`。
FUN_1403e8140=Init(state=this+8)、FUN_1403e82e0=Final（转 FUN_1403e8410，RFC1321 标准填充）、FUN_1403e82f0=MD5Update worker（v9 已逐行对账）。

### 3.4 对外部 AI 报告的核验结论（v9，v11 增补）
- **通过**：原始字节↔槽表全对；RTTI 邻接零间隙；worker 与 RFC1321 逐行吻合；SSO 判据；cstr 含 NUL；0x60 布局。
- **修正**：① 布局差 8 字节（buf 实为 this+0x20）；② T 表索引 0/1 基混用；③ `0x57cfb9ed` 非 RFC1321 常量。
- **v11 判决**：其 DAT "type"/"args" 读值正确（本机 exe 直读复核，见 §7.4），但两值**均为喂入器 label 参数、被 MD5Calculator 忽略**，不进入 digest 字节流；「疑似与 digest 无关」的谨慎判断部分正确——它们在 digest 路径上出现但贡献 0 字节。

## 4. [v10 · 2026-09-24] 资源恢复 + vanilla 配方全链复刻 + csi 机制破译

### 4.1 资源三件套（本机 `/home/z/my-project/repos/`）
- `scripts.7z`（FengY233/test）**md5=3291a19748a129bf8e16cd5983fda4c4 与丢失原件逐字节一致**；解压 → `scripts_x/scripts/`（192MB）。
- `BigWorld-Engine-14.4.1-HEAD/`（v2v3v4 镜像，1.4GB vanilla 源码）。
- `wot-src-59e92351…/`（wotstat，653MB）= **wot-cn 2.4.0.0 #942 sd 客户端资源树**。
- **v11 新增（FengY233/test 自取）**：`dec.7z.001/002`（合并→`dec_full.7z`，密码 114514.1919810）→ `decomp.zip`（47MB）→ `repos/decomp/`（30 chunks ≈320MB + giants + index.tsv 8.7MB + funcs_all.txt）；`replay.jsonl.zip`（156,482 行，t=61 目标行核对✓）；`wotexe.7z` → **WorldOfTanks.exe sha256 = `2ec886a84004be8ac1873a7d3d62d61e8d102a57fa34a8873afe67ca24ef9045`（78,777,520B）= wot-src stubs/manifest.json 权威值，逐字节一致 —— Ghidra 分析二进制与录制回放客户端同一性闭合**；`replay.wotreplay` 原件、`bwxml_decode.py`（用户权威版）、`def_dump.py`、`replay_setup.py`（两个新脚本待阅）。
- decomp.zip 覆盖度：主 digests 链路全部函数均在（c_1428d1e40.c 含 entity_description_digests.cpp 全簇 + entity_description.cpp 全簇 + data_types 全簇；c_1402c13f0.c 含 MD5Calculator 槽函数群）。

### 4.2 BWXML/PackedSection 解码器重建（`scripts/bwxml.py`，vanilla 源码级）
- 格式：`uint32 magic=0x62A14E45 | uint8 ver=0 | 字符串表(NUL串,空串终止) | 根块`；块=`int16 nChildren + ChildRecord[n](pack(1): int32 dataPos,int16 keyPos) + int32 finalPos + blob`。
- **类型在「下一记录」dataPos 高 4 位**（`ChildRecord::type() = (this+1)->dataPos_ & TYPE_MASK`）。
- 值语义：STRING=裸字节；BOOL=len>0；INT=小端1/2/4/8B；**BLOB=合法回环 Base64 的值**（实证：`b'\x04\x04\x84'`→"BASE"、`b'\n\x16\xad'`→"Chat"；Vehicle.def 的 arena 属性 Flags 即此形态）。2881 文件全解。
- ⚠️ 解码坑（v11 实录）：**有子节点的段 type 字段也可能标成 1（STRING）**，判断「是否为段」必须看 `children` 非空而非 type==0。

### 4.3 vanilla digest 配方全链（源码级，全部落地 `scripts/defparse.py`）
- 编排：`EntityDescriptionMap::digest()` = MD5 逐实体 `EntityDescription::addToMD5`（entities.xml **ClientServerEntities 文件序**，isClientType 过滤——fork 侧由 visitor slot7 检查 `entity+0x87` 等价实现）。
- 每实体：`name(无NUL无长度)` → 每 CS 属性（`dataFlags & 0x106`，即 OTHER_CLIENT|OWN_CLIENT|REPLAY）`[csi int32][varLenHeaderSize uint32 仅当 isForClient && streamSize<0 && ≠1][name 无NUL][dataFlags&0x5F int32][DataType::addToMD5]` → client 方法全量、base/cell 仅 exposed（`flags & 0xC`），各带计数器 `[同 Member 前缀][flags uint8][各 arg 类型][legacyExposedIndex int32]`。
- DataType 喂入全表（vanilla 源码 `md5.append( "Tag", sizeof("Tag") )` = **含 NUL**）：Int/Uint+size int32；Float/Float64/String/Blob/MailBox/Python/UnicodeString 单标签；Vector+NUM_ELEMENTS int32；User+module+instance(无NUL)；Array/Tuple=标签+size int32+dbLen int32(仅>0)+元素；FixedDict=标签+[!isCustomClassImplInited_||hasCustomClass() 时 module+instance]+allowNone u8+每字段 name(无NUL)+类型；UDO_REF="UserDataObjectLinkDataType\0"。
- **csi 分配破译**：每次 parseProperties 后 stable_sort（定长在前按 streamSize 升序、变长按 |−streamSize| 升序、同键保持声明序）再重编号。
- vanilla 基线实算：**`562A9B2278044E1EF6401BB7518E7701`**（≠目标 5DF886F7…，预期内）。
- fork-delta 搜索（负结果登记）：①结构族网格 122,880 组合；②原始字节族 14 式；③UDO 并入族 18 式——全部未命中 → 差异在语义层（v11 证实：isVolatile + 组件方法）。

### 4.4 锚点验证与 +5 缺口
- 40 实体 ✓ / 306 CS 属性 ✓（=v8 表）；Vehicle：isStrafing=1 ✓、avatarID=16 ✓、perkEffects=28/perks=29 ≠ 真值 33/34（+5 缺口 = 组件属性，见 §7.5 归因修正）。
- v10 判定「0x3D 不受组件影响」**在属性维度成立**（digest walker 只走 entity+0x28 自有属性向量），**在方法维度被 v11 推翻**（组件方法经 +0x2f0 进 digest，见 §7.5）。

## 5. [v11→v13 判决] 领先假设（解释 vanilla 复刻 ≠ 目标）
- ~~H1：fork 以 cstr 槽喂 def 名/路径（多 NUL）~~ **证伪**：名字一律 slot12（std::string，无 NUL）。
- ~~H2：长度前缀差异~~ **证伪**：无任何前缀。
- ~~H3：DAT 标记串混入输入流~~ **证伪**：标记串全部喂给空槽（slot3/slot4），贡献 0 字节。
- **v11 实况**：真差异 = ①每 CS 属性多 1 字节 isVolatile(u8)；②方法 returnValues 列表（本 def 集 0 字节）；③组件方法并入（+0x2f0 子描述）。
- **v13 增量④**：**client 方法全部出局**——onMethod（FUN_142a9b810）的 `(m+0x70 & 0xC)!=0` 过滤对全部域通用，而 fork 的方法解析禁止 client 方法带 `<Exposed>`（报错路径「Unable to use \<Exposed\> tag in client method」）、域位 CLIENT=0 → client 方法 flags 恒为 0（AllowUnsafeData 置的 0x10 在 0xC 掩码外）→ 全部被过滤。全 def 集 0 个 client 方法带 Exposed（与禁止规则自洽）。
- **v13 增量⑤（本轮最大）**：**FIXED_DICT 的 AllowNone 不再使 streamSize=-1**——vanilla `streamSize_( allowNone_ ? -1 : 0 )` 被改为无条件字段定长和。实证：DOT_EFFECT=8+4+1+1=14、BUFF_EFFECT=24、REMOTE_CAMERA_DATA=22、OWN_VEHICLE_POSITION=32、INSPIRED_EFFECT=36，与回放验证的 csi 表全部吻合；修复后 **40/40 实体 csi+streamSize+flags&0x5F 三要素全对账通过**（此前 39/40，Vehicle 变长区错位）。
- **+5 缺口新解（推翻 v8/v10 归因）**：Vehicle perkEffects/perks 28/29→真值 33/34 的 +5 从来不是「组件属性注入」——是上述 6 个 AllowNone FIXED_DICT（dotEffect 14/remoteCamera 22/inspiringEffect 24/healingEffect 24/ownVehiclePosition 32/inspired 36）从变长区(-1)移入定长区引发的排序位移。v10「动态组件为逐实例→不可能进静态 digest」的判定出子错因但仍成立；「0x3D 不受组件属性影响」在属性维度的结论不变。

## 6. [v17 改写] 开放项 / 下一步
1. **0x3D 剩余偏差 = dyncomp 记录内容**（84% 记录无真值源，见 §12.5）：
   - 主链路全绿：版本漂移已排除（§12.1）、方向已判定（客户端上行）、318 记录集/顺序/过滤/宽度/decider 全部汇编级+运行时双重验证（§11.4 + §12.4）；
   - 主实体部分最高置信：属性 40/40 + 方法全量 + 索引布局全部有运行时锚，且 §13 已将 methodID 机制升级到 11 场语义级验证；
   - **破口路径：录一场大逃杀/前线/背水之战回放**——0x05/0x08 包给出扩展实体与动态组件真值锚，无真值区压到接近零（本轮 11 场新回放全为随机战家族，未覆盖）；
   - 备选：Ghidra 终审 dyncomp 记录构造器的属性向量填充差异（FUN_142a900a0 组件分支 vs 实体分支）；BigWorld-Engine-14.4.1 vanilla 源码已解压就绪（/tmp/wot/bigworld，36,792 文件），可直接审 exposedMethods_/MD5Calculator 的 C++ 原始实现。
2. （已结 v15）扩展静态挂载边 = 0（ExternalComponents 全空，v14「39 边」误归因已推翻）。
3. （已结 v16）方法层三域语义三层闭合（decomp+vanilla+运行时）；网络 methodID 机制全解（§12.3）+ 11 场跨场语义级验证（§13.4）。
4. （已结 v16）版本同期性：全部材料对齐 #942（#938→#942 零 def 变更）。
5. （已结 v17）digest 身份：#942 客户端安装指纹（11 场跨区域恒定，§13.2）。
6. csi 表 v8 已全部正确（40/40 复验 + NetworkEntity n=40 新锚）；0x07/0x24 解码即查即用。
7. 实算基座：`scripts/digest_fork_v2.py`（v16 终态：318 记录 + u16 + 0xC 统一过滤 + 扩展层）+ `scripts/defparse.py`（+append_uint16）——V12 重建并复现 5976CA14；§13 新增 6 个回放分析脚本（survey/extract_entities/mid_signatures×2/methodid_tables/entity_decl_order）。
8. 小开放点：0x39 包类型（仅 3 场 EU karelia/WZ-219 出现，5-6 千个/场）语义未鉴定；BattleRoyaleRadio 等扩展实体的 def 与网络行为仍无运行时样本。

## 7. [v11 · 2026-09-24] decomp 全解 —— fork digest 配方逐函数闭合

### 7.1 调用链顶层（entity_type.cpp:0xe0，`BW::EntityType::init`，c_1402c13f0.c:143725）
```
FUN_140394440 = EntityType::init:
  打开 scripts/entities.xml
  FUN_142a98830(map@0x14483e050, …) = EntityDescriptionMap::parse   ← 解析全部实体/接口/组件
  FUN_142a9b640(&out, map, FUN_142a9b5b0) = 计算digest → 存全局 0x14483e028/030
  FUN_142a9b3e0(map) = 实体计数（<1 报错；计数不进 digest）
  逐实体（0x328 步长）：isClientType(+0x87) → 解析 client 脚本路径
```
栈哈希器 FUN_142a9b640：`local_88=MD5Calculator::vftable → Init(state=obj+8) → visitor 回调 FUN_142a9b5b0(map, &calc) → Final(state, out)`。

### 7.2 Visitor 双表架构（entity_description_digests.cpp 全簇，c_1428d1e40.c 367936–368300）
- `FUN_142a9b5b0` = 顶层 visitor 装配：`calc->slot3(0,0)`(no-op) → 建 **ClientServerTypesMD5Visitor**（栈对象 {vptr, calc_ptr@+8, inSection@+0x10}）→ `FUN_142a9b410(map, &visitor)` 遍历 → 两层 `calc->slot4()`(no-op) 收尾。
- **AbstractMD5Visitor vftable @ 0x143923138**（8 槽 + 字符串池）：slot1=FUN_142a9b7f0(startProperties→calc slot3 no-op)、slot2/slot4=FUN_1404397b0(endSection→calc slot4 no-op)、slot3=FUN_142a9b750(startMethods(domain)：1/2/4→"baseMethods"/"clientMethods"/"cellMethods"→calc slot3 no-op)、slot5/6/7=空(纯虚)。
- **ClientServerTypesMD5Visitor vftable @ 0x143923290**（覆盖 slot5/6/7）：slot5=**FUN_142a9b870(onProperty)**、slot6=**FUN_142a9b810(onMethod)**、slot7=**FUN_142a9b6c0(实体过滤+喂名)**。
- `FUN_142a9b410`：按 0x328 步长遍历 map 实体数组 → `visitor->slot7(entity)` 过滤 → 通过则 `FUN_142a93420(entity, visitor)` 逐实体喂入。
- `FUN_142a9b6c0`：`entity+0x87 != 0`（isClientType）→ `FUN_142a9b6e0`：`calc->slot3(name_data,0)`(no-op) + **`calc->slot12("name", &entity->name)` = 喂实体名（无 NUL）**。
- **`FUN_142a93420`（逐实体编排，顺序铁证）**：
```
startProperties → 遍历 entity+0x28..0x30（0xf0 步长）onProperty → endProperties
startMethods(client=2) → 遍历 entity+0x218..0x220（0x170 步长）onMethod(m, idx++)
                       → 遍历 entity+0x2f0..0x2f8 的每个子描述的 +0x218..0x220 onMethod(m, idx++)
endMethods(2) → startMethods(base=1) → 自有 +0x198（exposed 过滤 0xC）+ 子描述同域（idx 连续）
endMethods(1) → startMethods(cell=4) → 自有 +0x118（exposed 过滤）+ 子描述同域
endMethods(4)
```
- **onProperty（FUN_142a9b870）**：`(prop+0x78 & 0x106)!=0`（=vanilla isClientServerData）→ 经 slot14 惯用法喂 `[csi u32（prop+0x9c）]` → `FUN_142a894e0` 正文。
- **onMethod（FUN_142a9b810）**：`(m+0x70 & 0xC)!=0` → `FUN_142aa17d0` 正文 → 经 slot14 惯用法喂 `[index u32]`。

### 7.3 Member 正文喂入器（与 vanilla 逐项对照）
**属性 FUN_142a894e0**（DataDescription::addToMD5 fork 版）：
```
[slot3(name,0) no-op]
FUN_142abc050:  [varLenHeaderSize u32 仅当 +0x55(isForClient) && streamSize<0 && ≠1] + [name slot12 无NUL]
slot5(+0x28)("dataDistributionFlags", flags&0x5F)   → u32
slot11(+0x58)("isVolatile", *(prop+0xb3))           → u8  ★fork 增量①（vanilla 无此喂入）
prop->type(+0x70)->slot15(calc, "type")             → DataType::addToMD5
[slot4() no-op]
```
**方法 FUN_142aa17d0**（MethodDescription::addToMD5 fork 版）：
```
[slot3(name,0) no-op]
FUN_142abc050:  [varLenHeaderSize 判定同上] + [name slot12 无NUL]
slot10(+0x50)("flags", *(m+0x70))                   → u8（vanilla flags_ uint8 同位）
FUN_142abcbc0(m+0x80, calc, "args")                 → 逐 arg 仅喂 DataType（arg 名经 slot3=no-op；列表空则 0 字节）
FUN_142abcbc0(m+0xa0, calc, "returnValues")         → ★fork 增量②（vanilla 不喂返回值；本 def 集全空=0 字节）
[slot4() no-op]
（onMethod 随后喂 index u32 = vanilla legacyExposedIndex，语义相同：每域 0..N-1，自有+组件连续）
```
**FUN_142abc050 的 varLenHeaderSize 条件与 vanilla 完全一致**（isForClient_@+0x55、streamSize 经虚调用、默认值 1=Mercury::DEFAULT_VARIABLE_LENGTH_HEADER_SIZE）。

### 7.4 "type"/"args" 之谜 —— 已彻底解决
- exe 直读（VA→文件偏移）：`0x1435E0950 = "type"`（邻域 "No such entity type '%s'"/"transform"/"properties" 与外部 AI 报告吻合）、`0x143665890 = "args"`（邻域 "execute"/"({%}) -> unicode"/"PyGuiApplication" 吻合）。
- **角色**：两者都是喂入器 API 的 **label 参数**，随调用传入后被 MD5Calculator 实现忽略：
  - `"type"`：属性类型喂入 `DataType::addToMD5(calc, label="type")`（DataType vtable slot15 @+0x78）；
  - `"args"` / `"returnValues"`：方法参数/返回值列表喂入 `FUN_142abcbc0(list, calc, label)`；
  - 同族的 label 还有 "name"(0x1435D2D24)、"flags"、"size"、"dataDistributionFlags"、"isVolatile"、"varLenHeaderSize"、"moduleName"、"instanceName"、"allowNone"、"dbLen"、"elementType"、"fields"、"baseMethods"/"clientMethods"/"cellMethods"/"properties" —— **全部 0 字节贡献**（ visitor API 为多消费者共享设计；FUN_1403e8170/81a0 属于另一个 calculator 实现，其 +0x08/+0x18 语义不同，勿混）。
- 外部 AI 报告的 decomp 引用行号（c_140b9d8b0.c:255971 PyDict_GetItemString 等）属于 Python 桥接层，与 digest 路径无字节交集。

### 7.5 ★fork 增量③：组件方法进 digest（+0x2f0 子描述体系）
- `FUN_142a8d480`：构造 **0x338 字节的新 EntityDescription**（`std::_Ref_count_obj2<BW::EntityDescription>` 包装）并 push 进实体 `+0x2f0` 向量 —— 组件以「子实体描述」形态挂载，**方法并入 digest、属性不并入**（walker 只走 entity+0x28 的自有属性向量 → 组件属性不进 0x3D，解释 v8 +5 csi 缺口为何只出现在 0x07/0x24）。
- 挂载机制：`FUN_142a900a0`（建子描述）← 两路调用：`FUN_142a8ff40`（EntityDescription::parseComponents 路径，vanilla `<Components>` 机制，**41 个 entity def 均未使用**）与 `FUN_142a99f30`（map 级 parse，833 行，内含 FNV-1a 名字去重映射 + 0x328 实体记录管理 —— **静态挂载真值源头，待细读**）。
- def 侧素材：`component_defs/*.def` 127 个（**185 属性 / 3 Base / 41 Cell / 28 Client 方法**），其中 **79 个声明 `<ofEntity>`**（Account←2、Arena←16、ArenaInfo←5、Avatar←6、AvatarInfo←1、Entity←10、StaticDeathZone←1、TeamInfo←7、Vehicle←31）；`components.xml` 另列 StaticComponents 16 + DynamicComponents 113（仅名单，无挂载关系）。
- 组件方法语义：与实体方法同一喂入器（旧式 `<Arg>TYPE</Arg>` 形态），三域过滤规则一致（client 全量、base/cell exposed）。

### 7.6 fork 专属 volatile 属性机制
- 解析函数 `FUN_142a923c0 = EntityDescription::parseVolatileProperties(entity, section)`：把段的子节点当**属性名列表**，逐个 `FUN_142a83cb0` 查属性 → 插入 csi 树 → **`prop+0xb3 = 1`**；查无此属性则报 `"Volatile property \"%s\" does not refer to a valid property…"`；已 IsReliable/SendLatestOnly 的属性报暗示性警告。
- 调用点：`EntityDescription::parseInterface`（FUN_142a90940）末尾，段 = **`<Volatile><Properties>`**（entity+0x58 类型 ∉{3,4} 时）。
- def 实况：41 个 entity def 的 `<Volatile>` 段全是 vanilla 形态（position/yaw/roll/pitch）；**唯一 `<Volatile><Properties>` 在 component_defs/GunMarkerComponent.def（gunMarker）** —— 组件属性本就不进 digest → **40 实体全部 CS 属性 isVolatile=0x00，但该字节仍逐属性喂入（增量①的 306 个 0x00）**。

### 7.7 类型标签层：fork ≡ vanilla（逐函数对账）
fork 各 DataType vtable slot15(+0x78) 实测喂入（RTTI→COL→vftable 全链解析 47 表）：
| 类型 | 喂入 | vanilla 对照 |
|---|---|---|
| IntegerDataType<C/E/F/G/H> + LongIntegerDataType<I/_J/_K> | `"Int"`/`"Uint"`(含NUL) + size u32 | ✓ 同（integer_data_type.cpp:145） |
| FloatDataType<M>/<N> | `"Float"` / `"Float64"` | ✓ 同 |
| StringDataType / BlobDataType / UnicodeStringDataType / PythonDataType | `"String"`/`"Blob"`/`"UnicodeString"`/`"Python"` | ✓ 同 |
| UserDataType | `"User"` + module + instance（slot12 无NUL） | ✓ 同 |
| UserDataObjectDataType（fork 具体类） | `"UserDataObjectLinkDataType"`（与 vanilla UDORefDataType 同标签；UserDataObjectLinkDataType@BW 为抽象基类无 COL） | ✓ 同 |
| VectorDataType<Vector2/3/4> | `"Vector"` + N u32 | ✓ 同 |
| ArrayDataType / TupleDataType | `"Array"`/`"Tuple"` + Sequence 喂入（size u32 + dbLen u32 仅>0 + 元素 slot15） | ✓ 同 |
| FixedDictDataType | `"FixedDict"` + [!isCustomClassImplInited_‖hasCustomClass() 时 module+instance] + allowNone u8 + 每字段 name(slot12)+类型 | ✓ 同（fixed_dict_data_type.cpp:917 条件逐字一致） |
| UnsupportedDataType | （387200 行起，异常路径） | — |
- **fork 无 MailBoxDataType / Dict / Class 类型类**：MAILBOX 在 22 个 def 中出现但 **0 处进入 digest**（3 个属性全非 CS——CELL_PRIVATE/BASE；全部方法参数都在非 exposed 的 base/cell 方法上）；DICT/CLASS 未在 def 中使用。→ 对 0x3D 零影响。

### 7.8 fork 解析顺序 ≡ vanilla（方法合并顺序依据）
`EntityDescription::parseInterface`（FUN_142a90940）实测顺序：`FUN_142a84690`（Base 版 parseInterface：**parseImplements 递归（虚 +0x18 → FUN_142a83da0：开 `<defs>/interfaces/<name>.def` → 对同一实体递归 parseInterface）→ parseProperties**）→ VolatileInfo/AppealRadius/bools → parseMethods（FUN_142a91030：Base→Cell→Client）→ parseTempProperties → parseVolatileProperties。与 vanilla entity_description.cpp:381-444 一致 → **接口方法在解析期并入实体方法表（接口在前、自有在后），digest 的 +0x218 即此合并序；组件方法在合并表之后（+0x2f0）**。

### 7.9 实算测试（v13 更新，scripts/digest_fork_v2.py + digest_fork_diag.py）
- 旧 A/B/C（digest_fork_test.py，**含 csi 错位 bug**）：A=B6DFA134…、B=D54806FD…、C=196E8A39…，均≠目标（历史值仅作参考，csi 修复后全部失效）。
- v13 完整模型（csi 修复后）：records=148（space+40 实体+107 dyncomp），CS 属性 489（isVolatile=1 仅 gunMarker），digest 方法 134（base/cell exposed）→ `E2E9EBE2131D9580DDA9D6BE7288AAB3` ≠。
- 25 组合消融矩阵全负（见 §6.1）。目标 `5DF886F75E73B33CFF9D87FB9C69389C` 仍未命中，剩余自由度见 §6。

## 9. [v13 · 2026-09-24] EntityDescriptionMap::parse 全架构白盒 —— 挂载规则与 records 集合真相

### 9.1 顶层编排（FUN_142a98830 = EntityDescriptionMap::parse，c_1428d1e40.c:365735）
```
读 scripts/spaces.xml（FUN_142b79900）→ local_120
读 scripts/components.xml（FUN_142b79880）→ local_128
计数 = calculateEntitiesSize(FUN_142a96bc0: ClientServerEntities+ServerOnlyEntities 子数)
       + spaces.xml 子数 + components.xml/<DynamicComponents> 子数 → 预留 0x328 记录数组
① FUN_142a9b170 = parseSpaces（mode=2，decider=SpaceDescriptionHasPythonScript）→ records[0]
② FUN_142a7fae0 = FeatureExtensionManager 单例（扫 extension.xml；干净安装=空树）
③ FUN_142a971a0 = createEntityTypeToComponentSectionsMap（挂载索引，见 9.2）
④ FUN_142a996e0 = parseEntitiesBySide(param_5=0) → "ClientServerEntities" 40 实体（mode=1）
⑤ 扩展文件循环#1：逐文件读根 "Components" 子段 → 再解析实体（无扩展 → 跳过）
⑥ FUN_142a996e0(param_5=1) → "ServerOnlyEntities"（服务器树无此段 → 跳过）
⑦ FUN_142a99bc0 = 旧格式兼容（ClientServerEntities 存在时 no-op）
⑧ FUN_142a994c0 = parseDynamicComponents（mode=7，空索引不挂载）→ 110 唯一动态组件
⑨ 扩展文件循环#2：扩展文件的 DynamicComponents（无 → 跳过）
```
错误串铁证：`EntityDescriptionMap::parseSpaces/parseEntitiesBySide/parseDynamicComponents: Failed to load or parse def for …`、`calculateEntitiesSize: … doesn't have a <ClientServerEntities> section. Reverting to old-style parsing…`。

### 9.2 挂载索引（FUN_142a971a0 = createEntityTypeToComponentSectionsMap）
- **结构**：`std::multimap<实体名, {组件名, shared_ptr<DataSection>}>`（节点 0x68：KEY 串@+0x20、VALUE 串@+0x40、ptr@+0x60；插入函数 FUN_142a94570，等值键走右子树=**追加序**）。
- **Part a（静态）**：components.xml `<StaticComponents>`（16 名）逐名载 `scripts/component_defs/<名>.def`（FUN_142a96400）→ 其 `<ofEntity>` 每个实体名一条边。错误串：`Component definition file %s not found` / `no <ofEntity> section found in component %s`。
- **Part b（扩展）**：FeatureExtension 文件的 `<ExternalComponents>` 同样处理（干净安装为空）。错误串：`no <ofEntity> section found in external component %s, file %s`。
- **关键判定**：DynamicComponents 的 ofEntity（79 个组件声明中约 63 个属动态）**不进索引**——索引只由 StaticComponents(16)+扩展构成。16 条静态边：Arena←10、Account←2、TeamInfo←2、Avatar←1、Vehicle←1。
- **实际生效挂载**（目标实体须在 digest 记录集内）：**Account←[AccountFairplayComponent, AccountPBHComponent]、Avatar←[AvatarInBattleVehicleSwitch]、TeamInfo←[PoiTeamInfoComponent, TeamInfoInBattleVehicleSwitch]、Vehicle←[VehicleInBattleSwitch]**（"Arena" 不在 ClientServerEntities → 其 10 条边无效）。

### 9.3 parseFromSectionList（FUN_142a900a0）与记录构造（FUN_142a99f30）
- FUN_142a99f30（通用 def 批量入 map）：FNV-1a 名字去重收集 → 0x328 数组扩容 → 逐条：`FUN_142a8ee00(mode,名,dir)` 载主 def（目录由 mode 定：1=entity_defs、2=space_defs、3=service_defs、5=event_topics、7=component_defs）→ pairs=[(主def,"")]++equal_range(实体名)命中 → `FUN_142a900a0(记录,pairs,mode,名)`。
- FUN_142a900a0：pairs[0]（空名）走主解析（**Parent 段 → FUN_142a90f20 → FUN_142a8ff40 → 递归 parseFromSectionList 同记录**——继承链）；pairs[1+]（有名）逐个 `FUN_142a8d480` 建 0x338 子描述（**type=6**）压入记录+0x2f0（重名报 `Double static entity component definition %s for entity %s`）。记录+0x80=typeIndex、+0x82=clientIndex、+0x87=isClientType、+0x58=DescriptionType、+0x60=目录串。
- mode==7 附加：记录+0x2f=+0x4f=1、读 `DefaultKeyName`→+0x308。

### 9.4 decider 三表（isClientType 的来源，parseFromSectionList 末尾三连虚调用 → 记录+0x85/86/87）
| decider | vftable | slot2（→+0x87）语义 |
|---|---|---|
| EntityDescriptionHasClientScript | 0x143922908 | `return this+0x28`（= side^1）→ **ClientServer 侧全部 40 实体 isClientType=1，ServerOnly=0** |
| DynamicComponentsDescriptionHasPythonScript | 0x143922930 | Distribution/Client 有则用之；否则 `scripts/client/<名>.py/.pyc/.pyo/.pyd` 存在（FUN_142a8e660+FUN_142a8fc10+FUN_142a92970，四扩展名序试） |
| SpaceDescriptionHasPythonScript | 0x143922958 | FUN_140355960 = `b0 01 c3`（mov al,1; ret）**恒真** |
RTTI 反查方法：COL 用 32 位 RVA（非 64 位 VA）——v13 修正了 v9-v11 的反查盲区。

### 9.5 records 集合与顺序（digest 遍历集，FUN_142a9b410 从数组头全量 0x328 步长）
```
records = [GeneralSpaceData（spaces.xml 唯一子节点；space_defs/GeneralSpaceData.def：
           Implements SpaceRecording(recorderFragment 非 CS)；CS 属性 3 个——itemsVisibilityMask
           (UINT32)/environment(STRING)/replicableHash(UINT64)，均带 <Exposed> 子段]
         + 40 ClientServer 实体（entities.xml 序，各挂 §9.2 静态组件）
         + 110 唯一 DynamicComponents 中 107 个（排除 ExtendedSPG/EnemyShotPredictorController/
           ArenaVehiclesInfo——无 scripts/client 脚本；DynamicComponents 列表有 3 个重名
           (SecondaryGunComponent/NetworkReplicationPointComponent/NetworkVehicleHierarchy×2)被 FNV 去重）
         ] 共 148 条
```
- space 属性规则（param_5=1）：跳过 Flags（dataFlags=0）+ `<Exposed>` 子段→OWN_CLIENT(0x4)；实体/组件（param_5=2）：读 Flags + 跳过 Exposed 规则。
- 组件记录解析：Parent 链（NextClipsReloader→GunReloadBoost）+ Implements（component_defs/interfaces，接口名在子节点值：ShotsReceiver 等 3 个→ReplicableComponent、2 个→SecondaryGunActivatorInterface）+ `<Volatile><Properties>` 标记（仅 GunMarkerComponent.gunMarker=0x01）。

### 9.6 方法层 fork 语义（v13 新解，与 vanilla 的差异汇总）
- 域常量：CLIENT=0/CELL=1/BASE=2（FUN_142a91030 三调用实证）+ bit3(0x8)=跳过 Args 读。
- flags 字节 = 域位 | exposed 位（CELL+ALL_CLIENTS→0x4；OWN_CLIENT→0x8；空→0xC；BASE+ALL_CLIENTS→报错）| **0x10=AllowUnsafeData**（11 处全在 client 方法→被过滤→无效）；HasReliableRetry/IsImmediate/IgnoreIfNoClient→独立字节；ReplayExposureLevel→+0xdc 枚举；version→+0x78 u16；scope→+0x74——均不进 digest。
- **client 方法禁带 `<Exposed>`**（报错）→ flags 恒 0 → onMethod 通用过滤出局（§5 增量④）。
- 方法 varLen 前缀永不喂入（isForClient=域==CLIENT，而 client 方法已出局）。
- returnValues：全 def 集仅 5 个 Base 方法有（Account×3/Avatar×1/BattleResultProcessor×1），全部无 Exposed → 0 字节（§7.3 增量②的「def 无 ReturnValues」表述修正为「有但全不喂」）。
- 挂载组件方法贡献：仅 Avatar 的 3 个 exposed cell 方法（confirmVehicleSelection/chooseVehicle/switchSetup）；PoiTeamInfoComponent 的 3 个 client 方法被增量④过滤。

## 10. [v14 · 2026-09-24] FeatureExtension 体系 —— records 集合的缺失维度（本轮最大发现）

### 10.1 体系结构（decomp + wot-src 镜像 + paths.xml 三方实证）
- **FeatureExtensionManager（FUN_142a7fae0 单例）**：首次访问时内联执行 FUN_142a7fbb0 = FeatureExtensionMap::parse——枚举文件系统根的全部一级目录，逐个检查 `<dir>/extension.xml` 存在性（FUN_142b819b0），读文件（FUN_142b79900）→ **readBool("IsEnabled")，false 则跳过**（错误串 "Extension %s is disabled in config file."）→ 读 FeatureName 注册 → 收集 `<Components><StaticComponents>` 子名到向量（挂载索引 Part b 的数据源）→ 读 `<cgf><script><module>`（cgf 模块注册）。
- **真实客户端实证**：wot-src 镜像 `sources/res/` 下有 18 个扩展目录（battle_modifiers/battle_royale/comp7/comp7_core/comp7_light/content_exclude/event_platform/fall_tanks/frontline/fun_random/in_battle_achievements/la_pinger/last_stand/open_bundle/resource_well/server_side_replay/story_mode/white_tiger），**全部 IsEnabled=true**；`sources/paths.xml` 列有对应的 18 个 `res/packages/<ext>.pkg`（type="sandbox,sd,hd"，0x30 包证实本客户端为 sd 型 → 全部挂载）；pkg 在 paths.xml 中的出现顺序恰为字母序。
- **v13 勘误**：「② FeatureExtensionManager 单例（扫 extension.xml；干净安装=空树）」的"空树"判断错误——当时只在 scripts 树（scripts.7z=scripts.pkg 内容）中找过 extension.xml，未查 res/ 一级目录与 pkg 体系。

### 10.2 三个扩展消费点（FUN_142a98830 = EntityDescriptionMap::parse 全序）
```
① parseSpaces（records[0]）
② FeatureExtensionManager 单例（惰性扫描，18 个全 enabled）
③ 挂载索引 FUN_142a971a0：
     Part a：components.xml <StaticComponents>（16 名）→ scripts/component_defs/<N>.def → ofEntity 边
     Part b：逐扩展（列表序）逐 static 名 → <ext>/scripts/component_defs/<N>.def（尾部拼 ".def" 实锤
             0x6665642e）→ ofEntity 边（在 Part a 之后追加 → 同实体名的挂载序 = Part a 先、扩展后）
④ ClientServerEntities（40 实体，dir=""）
⑤ 扩展循环#1：逐扩展重读 extension.xml → 打开根 "Entities"(0x143920128) 子段
   → FUN_142a996e0（ClientServerEntities 分支，dir=<扩展名>）
   → def 路径 = <ext>/scripts/entity_defs/<E>.def（FUN_142a8e790 mode=1 的 dir 前缀分支）
⑥ ServerOnlyEntities（entities.xml 无此段 → 跳过；扩展的 SO 实体在客户端同样不解析）
⑦ 旧格式兼容 FUN_142a99bc0（no-op）
⑧ parseDynamicComponents：components.xml <DynamicComponents>（110 名 FNV 去重→107）
⑨ 扩展循环#2：逐扩展重读 extension.xml → 打开根 "Components"(0x1439200e8) → 其 "DynamicComponents"
   子段 → FUN_142a994c0（mode=7，dir=<扩展名>）→ def 路径 = <ext>/scripts/component_defs/<D>.def
⑩ 收尾：type!=7 的记录做 max 属性数等统计（不进 digest）
```
- **记录数组全貌**：`[space][40 实体][扩展实体（扩展列表序）][107 dyncomp][扩展 dyncomp（扩展列表序）]` ≈ 1+40+10+107+≤171 ≈ **~318 条**（v13 模型仅 148 条）。
- **def 加载失败语义（FUN_142a99f30）**：FUN_142a8ee00 返回空 → 清理后 goto LAB_142a9b067 → **返回 false**（该批次整体中止），但 EntityDescriptionMap::parse 继续执行其余步骤（bVar8 &= …），digest 仍会计算——即"缺 def 的扩展批次"会让整批记录缺席而非崩溃。
- **decider 与 dir 前缀的全局一致性**：FUN_142a8e790 的 mode 1/2/3/5/7 分支均支持 `<dir>/scripts/<子目录>` 前缀；dyncomp decider 的脚本检查（FUN_142a8e660→FUN_142a8fc10）同样吃 dir——扩展 dyncomp 判 `<ext>/scripts/client/<D>.py|.pyc|.pyo|.pyd` 存在性（镜像 loose 树有这些 .py；12 个组件在镜像中无 py → decider 排除候选，pkg 到货后复核）。
- **FNV 去重是每次 FUN_142a99f30 调用独立的**（局部哈希集）→ 跨批次同名（如扩展 dyncomp 与主树 dyncomp 同名）不会被去重，会双记录入数组（名字 map 亦双条目）。

### 10.3 扩展清单（scripts/ext_inventory.py 提取，download/ext_inventory.json）
| # | 扩展 | static | dynamic | CS实体 | 镜像缺py |
|---|---|---|---|---|---|
| 1 | battle_modifiers | 0 | 0 | 0 | 0 |
| 2 | battle_royale | 3 | 34 | 6 (Mine/Loot/Placement/InfluenceZone/BattleRoyaleRadio/ThunderStrike) | 4 |
| 3 | comp7 | 3 | 2 | 1 (Comp7Lighting) | 0 |
| 4 | comp7_core | 0 | 7 | 1 (ApplicationPoint) | 0 |
| 5 | comp7_light | 2 | 2 | 0 | 0 |
| 6 | content_exclude | 0 | 0 | 0 | 0 |
| 7 | event_platform | 3 | 0 | 0 | 0 |
| 8 | fall_tanks | 1 | 3 | 0 | 0 |
| 9 | frontline | 6 | 9 | 0 | 3 |
| 10 | fun_random | 3 | 0 | 0 | 0 |
| 11 | in_battle_achievements | 1 | 2 | 0 | 1 |
| 12 | la_pinger | 1 | 0 | 0 | 0 |
| 13 | last_stand | 5 | 66 | 0 | 3 |
| 14 | open_bundle | 1 | 0 | 0 | 0 |
| 15 | resource_well | 1 | 0 | 0 | 0 |
| 16 | server_side_replay | 1 | 0 | 1 (ReplayAccount) | 0 |
| 17 | story_mode | 4 | 21 | 1 | 0 |
| 18 | white_tiger | 4 | 25 | 0 | 0 |
- 合计：39 static 挂载边 + 171 dynamic + 10 CS 实体（SO 实体 16 个客户端不解析）。本回放为 SERVER_REPLAY 模式（bonus cap），server_side_replay 扩展启用——与 ReplayAccount 的存在自洽。

### 10.4 与既有验证的自洽性
- 0x05 创建块 n∈{3,6,7,18,28,29,40} 全 ≤40：本场随机战斗未创建扩展实体，无矛盾（且 n=7=Vehicle/n=6=AreaDestructibles/n=40=NetworkEntity 与数组布局吻合）。
- csi 表 40/40：csi 是 per-record 编号，扩展记录不影响 40 实体的 csi 值——对账依然成立。
- 25 组合消融全负：矩阵从未触及"扩展记录"维度——与"唯一剩余自由度=扩展内容"的判定一致。
- 扩展 def 的存在性间接证据：①游戏支持 BR/frontline 等模式，客户端必须有这些实体 def 才能创建客户端实体；②引擎专门实现了 `<ext>/scripts/{entity_defs,component_defs}` 路径与挂载/循环代码；③镜像扩展树含全部 client .py（decider 设计目标）；④paths.xml 专门列出 18 个扩展 pkg。**但 def 文件本体不在任何现有资源**（scripts.7z=主 pkg；wot-src 镜像无任何 .def）。

## 附录 A：资产恢复终态（v12 结算）
- 重置损失已 **100% 恢复**：`replay.jsonl✓ / decomp.zip✓(dec.7z 分卷) / scripts.7z✓(md5 3291a197…) / BigWorld tar.gz✓ / tools/bwxml_decode.py✓ / csi_tables_v8.json✓(md5 5ac32922…)`；`scripts/digest_fork.py` 功能已被 digest_fork_test.py 覆盖。
- **v12 新寻回**（FengY233/test 仓库）：`csi_tables_v8.json`（重置丢失的权威表原件）、`WoT回放解析交付包_v7.zip`（正式交付包 V7 全套 16 文件）、`会话记录.txt`（253KB 全程对话记录，结论对账依据）、重置前原版 findings.md（v8 全细节，含 §0 状态速览——细节可向该版本回溯）。
- 恢复渠道：`https://github.com/FengY233/test`（14 文件，gh_fetch.py 全量拉取 + md5 校验）。

## 8. 交付包沿革（v13 登记）
- **v1–v7**（正式报告线，官方下载渠道可取）：报告 MD/PDF + xlsx + json + 8 图表 + 封面 + 审计。v7=无服务器资料收官版。
- **v8**（过渡包，仅脚本集）：findings_bundle_v8.zip = findings + worklog + 18 脚本（非报告形态，已被 v9 取代）。
- **v9**（FengY233/test 官方渠道）：`WoT回放解析交付包_v9.zip` —— V7 全套 16 文件内容升级（报告 +§17/§18、xlsx 17 表、json +2 段、审计 v9、README v9）+ findings.md（v12）与 csi_tables_v8.json；57 页 PDF。
- **v10（本轮，最新）**：V9 结构 + **worklog.md（用户指令新增）** + findings.md v13 + digest_fork_v2/diag 脚本 + defparse 修复。

## 附录 D：v11 证据存根
- exe：`/tmp/wotexe_x/WorldOfTanks.exe`（v13 注：exe 在隐藏区 /tmp，sha256 校验同前）（sha256=2ec886a8… ✓ manifest 权威值）。本机直读脚本：`scripts/dat_verify.py`（DAT 双值）、`scripts/vtable_resolve.py`（vptr=0x1439230B8 机器码铁证 + vtable 区直读）、`scripts/visitor_vtables.py`（visitor 双表 + FUN_142a9b6e0 反汇编）、`scripts/datatype_vtables2.py`（47 DataType vtable RTTI 全链）、`scripts/read_feeders.py`（全部 addToMD5 批量导出）。
- decomp 关键坐标：digest 顶层 c_1402c13f0.c:143725（EntityType::init）；栈哈希器 c_1428d1e40.c:368056；visitor 簇 367936–368300；walker FUN_142a93420@361589；onProperty/onMethod FUN_142a9b870/810@368194/368174；属性/方法正文 FUN_142a894e0@353568 / FUN_142aa17d0@372497；Member 前缀 FUN_142abc050@394282；args 列表 FUN_142abcbc0@394897；parseVolatileProperties FUN_142a923c0@360730；parseInterface FUN_142a90940@359328；parseImplements FUN_142a83da0@349241；组件子描述 FUN_142a8d480@356666；map 级挂载 FUN_142a99f30@366955（833 行待细读）；MD5 槽函数群 c_1402c13f0.c:211996–212175。
- def 侧：`repos/scripts_x/scripts/{entity_defs(41+interfaces 61), component_defs(127), components.xml, spaces.xml, entities.xml, alias.xml}`；组件统计脚本内嵌于 `scripts/digest_fork_test.py`（185 属性/3B/41C/28Cl；ofEntity 79 个）。
- 实算：`scripts/digest_fork_test.py`（A/B/C 三变体 + 组件解析/挂载框架，可直接扩展变体）。

## 附录 B：v9 证据存根
- 用户导出（Ghidra，只读未改码）：vtable 15 槽原始字节（0x1439230B0 起 136 字节）、槽函数伪代码引用、RTTI 邻接类。
- `scripts/md5calc_ref.py`：RFC1321 自测 507 项 + 槽位语义 6 项全通过；T 表锚点 12 常量位置精确；0x57cfb9ed 非 MD5 常量。

## 附录 C：v10 证据存根
- `repos/scripts.7z` md5=3291a19748a129bf8e16cd5983fda4c4（=原件）；wot-src `.publication.json` commit_subject=2.4.0.0 #942（wot-cn sd）。
- `scripts/bwxml.py`：PackedSection 解码（2881 文件实测；blob=Base64 回环实证 6 例）；`scripts/defparse.py`：vanilla digest 全链（40 实体/306 CS 与 v8 双吻合；锚点 1/16 命中、33/34 差 5 且数学闭合）。
- vanilla 源码依据：entity_description_map.cpp L287-289/L608-622、entity_description.cpp L1740-1802/L381-444、member_description.cpp L281-296、data_description.cpp L415-439（v11 复核为 431-439）、method_description.cpp L1294-1302、method_args.cpp L372-382、data_types/*（md5String 全表）、packed_section.hpp/cpp。

## 附录 E：v13 证据存根
- **资源位置（本轮重组）**：分析资源已全部移至用户不可见区（根治内存撑爆）：`/tmp/wot/gh_test`（FengY233/test 14 文件）+ `/tmp/my-project/repos`（decomp 356M / scripts_x 192M / wot-src 653M / BigWorld 1.4G + tar×2，root 属主只读）；可见区仅 29MB 交付物。worklog Task 1–17 已据 会话记录.txt 重建。
- **decomp 新坐标（本轮白盒）**：EntityDescriptionMap::parse FUN_142a98830@365735；parseSpaces FUN_142a9b170@367788；createEntityTypeToComponentSectionsMap FUN_142a971a0@364520（静态装载器 FUN_142a96400@363757）；parseEntitiesBySide FUN_142a996e0@366519；parseDynamicComponents FUN_142a994c0@366406；旧格式兼容 FUN_142a99bc0@366790；通用记录构造 FUN_142a99f30@366955（833 行已全读）；parseFromSectionList FUN_142a900a0@358890；Parent 解析 FUN_142a90f20@359596 + FUN_142a8ff40@358825；子描述构造 FUN_142a8d480@356666（type=6）；方法解析 FUN_142aa1fa0@372941（域常量/Exposed/AllowUnsafeData=0x10/version/scope/ReplayExposureLevel）；方法列表解析 FUN_142aa7540@377206（+0x100=cell/+0x180=base/+0x200=client）；parseProperties FUN_142a91b20@360236（param_5=(type≠2)+1：space=1 跳 Flags+启用 Exposed 规则，其余=2）；DataDescription::parse FUN_142a8a1f0@354356（Flags 表@0x144341530：CELL_PRIVATE=0/CELL_PUBLIC=1/OTHER_CLIENTS=3/OWN_CLIENT=4/BASE=8/BASE_AND_CLIENT=0xC/CELL_PUBLIC_AND_OWN=5/ALL_CLIENTS=7/EDITOR_ONLY=0x40；Backupable=0x200/AllowUnsafeData=0x400/Identifier=0x80 均在 0x5F 掩码外）；模式→目录 FUN_142a8e790@357668；脚本存在性 FUN_142a8e660@357596（.py/.pyc/.pyo/.pyd @0x1435d5a04 区）；FeatureExtensionManager FUN_142a7fae0@345742（"extension.xml"）。
- **decider vtable 解析脚本**：`/tmp/wot/decider_final.py`（COL 32 位 RVA 反查）；**判定函数**：FUN_140b99eb0@381337（this+0x28）、FUN_142a8e1f0@357365（脚本检查）、FUN_140355960@94530（b0 01 c3 恒真）。
- **csi 修复与对账**：defparse.py FIXED_DICT streamSize 去 AllowNone 罚则 → 40/40 实体 csi+streamSize+flags&0x5F 三要素对 csi_tables_v8.json 全对账（对账脚本本轮内联，Vehicle 变长区 25-49 全对）。
- **实算**：`scripts/digest_fork_v2.py`（148 记录完整模型 → E2E9EBE2…）、`scripts/digest_fork_diag.py`（24 组合矩阵）、+内联第 25 组合（client 方法原始 flags）——全部 ≠ 目标。
- **vanilla 源码对照**：fixed_dict_data_type.cpp:441（streamSize_(allowNone?-1:0)——fork 改动点）、:769-779；member_description.cpp:281-296（isForClient 门控 varLen）；method_description.cpp:335-470（Exposed/Args/ReturnValues）、:1289-1303（setExposedMsgID）；entity_method_descriptions.cpp:197-215（exposed 排序+range）；entity_description.cpp:831-886（csi 排序）、:1740-1802（addToMD5）。

## 附录 F：v14 证据存根
- **本轮字节级复核（全部与模型一致，负结果登记）**：
  - walker FUN_142a93420 重读：onMethod 的 index=walker 第三参计数器；client 域计数器无条件++（但全被过滤→无关）；base/cell 域计数器仅对通过 (flags&0xC) 者递增 → index=域内 exposed 连续编号（自有+组件接续）。
  - onMethod FUN_142a9b810 / onProperty FUN_142a9b870 重读：csi 读 prop+0x9c（u32）；过滤掩码 0x106 确认。
  - ExposedForReplay：DataDescription::parse 读两处（非 CS 路径 default=0 + CS 路径 default=isOtherClients 即 bit1），置 dataFlags bit8(0x100)；全 def 树 32 处扫描：29 处本就带 client 位、3 处为 space 记录（经 <Exposed>→0x4 已进模型）→ 对 digest 零影响（0x100 在 0x5F 外、过滤位已过）。
  - DT 层：24 个 addToMD5 feeder 全量导出（/tmp/wot/feeders_v11.txt，read_feeders.py 路径已改 /tmp/my-project/repos）+ exe 直读 DAT 常量（scripts/dat_strings2.py）：DAT_143676a60="Int"/DAT_143928948="Uint"/DAT_1437d083c="Blob"/DAT_1437d0d1c="User"（slot13=含 NUL 喂入）、DAT_1435d2d24="name"/DAT_1435e92e4="size"（label 0 字节）——与 defparse 逐字节一致；Sequence 的 dbLen 条件 0<dbLen、FixedDict 的 [!inited‖hasCustom] 模块/实例喂入（全树 0 个自定义类/USER 类型 → 恒 0 字节）一致。
  - parseProperties FUN_142a91b20 全读：type==3 报错；type==6 用记录名做组件名；type==7 置标记；param_5=(type≠2)+1；EDITOR_ONLY(bit6) 属性跳过；同名覆盖=原位替换+保留旧 csi（读旧+0x9c）；csi=cs_props.size()+base(+0xf8)（等效模型的多轮 allocate_csi，已证稳定排序等价）。
  - DataDescription::parse FUN_142a8a1f0：Flags 表查表（param_5 bit0=跳过→space dataFlags=0）；空 <Exposed/> 且 (param_5&2)==0 → |=0x4（space 专属规则实锤）；MemberDescription::parse FUN_142abc1e0 的 isForClient=param_4 ← DataDescription::parse 传 (flags&0x106)!=0（与 vanilla data_description.cpp:320 逐字一致）；<tags> 段入 +0xb8 map（不进 digest）。
  - parseMethods FUN_142a91030 全读：type∈{1,6} 三域；type==7 禁 BaseMethods（报错）→ 仅 Cell+Client；type==3 服务型；列表头 +0x100(cell)/+0x180(base)/+0x200(client)，vector 在 +0x18 处（= walker 的 +0x118/+0x198/+0x218 ✓）；"Methods"/"Events" 标签拒绝。
  - 方法 Exposed 语义精读：CELL+ALL_CLIENTS→0x4；OWN_CLIENT→0x8；**空 <Exposed/>→0xC**；BASE+ALL_CLIENTS→报错；client+任意 Exposed→报错（"Unable to use <Exposed> tag in client method"）。
  - FUN_142a99f30 重读：FNV-1a 去重=首遇序（子节点序），记录索引=base+i 顺序填入；**equal_range 仅 mode==1**（实体）→ 挂载只发生在实体批次；def 加载失败→批次中止返回 false。
  - space/挂载组件/ReturnValues 内容核查：GeneralSpaceData+SpaceRecording 无方法段；6 个静态挂载组件全扁平（无 Parent/Implements，Avatar 3 exposed cell + AccountFairplay 0 + Poi 3 client）；ReturnValues 全树恰 5 个（Account×3/Avatar×1/BattleResultProcessor×1 接口）全非 exposed → 0 字节；component_defs 3 个 Base 方法全在静态组件（挂 Arena——非记录集）→ 0 贡献。
  - 实体/组件 def 格式：Avatar 等用旧式 <Arg>（直接子节点）、组件用新式 <Args>（具名子节点）——defparse 两式均处理 ✓。
- **FeatureExtension 证据坐标**：FeatureExtensionMap::parse=FUN_142a7fbb0@345786（IsEnabled 过滤+FeatureName+StaticComponents 向量收集+cgf/script 注册）；目录枚举 FUN_142b822d0@153333（FileSystem 根）+ 挂载根收集 FUN_142b87610@157392（mount+0x88==1 过滤）+ FUN_14037f0a0@127602（vector insert，非 sort——顺序=挂载序+枚举序，具体待 def 到货后枚举验证）；扩展消费点三处见 §10.2（"Entities"=0x143920128 / "Components"=0x1439200e8 / "DynamicComponents"=0x143920110 / "StaticComponents"=0x1439200f8 / ".def"=0x6665642e 直写）；def 路径构造 FUN_142a8e790@357668（mode 1/2/3/5/7 的 <dir>/scripts/<子目录> 前缀分支）；decider 脚本检查 FUN_142a8e660@357596→FUN_142a8fc10；wot-src 镜像 res/ 18 扩展目录 + paths.xml 18 pkg（字母序）；泄漏构建路径 "D:\BuildAgent\work\wotd_ci_release\wc\programming\shared_libs\entitydef\entity_description.cpp"（FUN_142a8e740 内 ERROR_MSG，证实 fork 把 vanilla lib/entitydef 重组为 shared_libs/entitydef）。
- **新脚本**：`scripts/dat_strings2.py`（exe DAT 直读）、`scripts/ext_inventory.py`（扩展清单→download/ext_inventory.json）、`scripts/read_feeders.py`（路径修复 /tmp/my-project/repos）。
- **待用户供给**：18 个扩展 pkg 的 scripts/{entity_defs,component_defs}（含 interfaces）+ scripts/client 清单（详见 §6 执行清单）。

## 11. [v15 · 2026-09-24] 扩展 def 到货 → 全模型实算 + u16 真 bug 修复 —— 0x3D 进入"全层汇编级验证"时代

### 11.1 用户材料核验（wot24_ext_defs.zip，GitHub FengY233/test）
- 包结构：18 扩展目录（entity/component/arena_defs 解码 XML + _raw 原始 BWXML + extension.xml + client_files.txt）+ MANIFEST.tsv(242 行) + INDEX.tsv + README + tools×4（用户侧 AI 的导出器）
- `scripts/verify_ext_pkg.py` 十项对账 95 PASS / 0 FAIL：C1 目录 18/18；C2 component_defs 210 == static(39)∪dynamic(171)；C3 entity_defs 10 == cs_entities（so_entities 16 个正确缺席——extension.xml ServerOnlyEntities 有名单但服务器侧 def 不随客户端发行）；C4 IsEnabled 全 true；C5 StaticComponents 名单 18/18；C7 dyncomp 脚本真值（client_files.txt 精确路径）与镜像推断完全吻合（BR 4/前线 3/IBA 1/背水 3 无脚本）；C8 xml↔_raw 242/242；C10 MANIFEST 字节数全对
- `scripts/ext_raw_decode_test.py`：自研 vanilla 版解码器独立消费 242/242；`scripts/ext_facts.py` 从 _raw 独立提取全部建模事实（不信 README）
- README 独立复核：3 处跨包 Parent ✓（FallTanksRespawnComponent→VehicleRespawnComponent / SPGZone→AreaOfEffect / SMVehicleRespawnComponent→VehicleRespawnComponent）；零接口引用 ✓；white_tiger 小写 vehicle ofEntity 原样 ✓

### 11.2 模型修正（推翻 v14 两处）
- **✗ 推翻「39 static 挂载边进 digest」**：挂载索引 Part b（else 分支）打开的是 extension.xml **根级 <ExternalComponents>**——18 个扩展全部为空/缺失 → 0 条扩展挂载边。v14 的「Part b 逐 static 名载 <ext>/scripts/component_defs/<N>.def（尾部拼 .def 实锤 0x6665642e）」系**误归因**：0x6665642e 写点在 Part a（主 components.xml 静态装载器 FUN_142a96400），行号 fun_142a971a0_full.c:377 实锤。ExternalComponents 子节点=内联组件定义（须自带 ofEntity 子段，缺失报 "no <ofEntity> section found in external component %s, file %s"）
- **✗ 修正「pkg 顺序恰为字母序」的依据**：paths.xml 整体并非字母序（shared_content part3<part2<part1），但 18 扩展 pkg 在其中的出现序恰为字母序；且管理器容器为 **FeatureName 键的有序 map**（FUN_140313020 拷贝 FeatureName 为键 + memcmp 插入比较 + isnil 树遍历）→ 迭代序=字母序 双重成立
- 机器码裁决（disas_call_sites.py）：扩展循环#1 调用 FUN_142a996e0 传入 **同一个挂载 multimap**（r8=[rsp+0x60]）+ **dir=rbx+0x80**（FeatureExtension 对象内目录名串）+ **side=0 仅 ClientServer**（[rsp+0x20]=0）——Ghidra 反编译丢失了参数，机器码没有说谎；扩展 SO 实体客户端永不解析
- 记录集 = 1 space + 40 主实体 + 10 扩展实体 + 107 主 dyncomp + 160 扩展 dyncomp = **318**；FUN_142a99f30 的全局名字 map 去重（pvVar7==local_1e0 才追加）——全部名字组合重叠检查为空，无去重影响

### 11.3 ★ 本轮最大发现：方法 flags 是 u16 不是 u8（v9-v13 集体漏读）
- **证据链**：方法体喂入器 FUN_142aa17d0（disas 全文）第 4 步 `(calc+0x50)(calc,"flags",method+0x70)` = calculator **slot10**；MD5Calculator vtable(0x1439230B8) slot10=0x1403e8260 = **u16 喂入器**（`mov word ptr [rsp+0x40], r8w; mov r9d,2`）；调用点 `movzx r8d, byte ptr [rdi+0x70]` 零扩展 → 实喂 2 字节 LE **[flags, 0x00]**
- v9 的槽位表判定"记录中无 u16 调用"是因为只追了属性/名字喂入器，漏了方法体喂入器的 slot10；v11「方法：…[flags u8]…」自此勘误
- 影响面：全部喂入方法（主 134 + 扩展 29 = 163 个），每个多 1 字节 0x00——**主模型自 v13 起从未命中由此解释**
- 修复：defparse.MD5.append_uint16 + digest_fork_v2.method_to_md5 改 append_uint16(m.flags)

### 11.4 全层汇编级复核（本轮二轮验证，全部一致）
- 属性体 FUN_142a894e0：[slot3 名字标签 no-op]→FUN_142abc050[varLen u32 条件(slot8)][名字 slot12 无NUL]→[flags&0x5F u32(slot5)]→[isVolatile u8(slot11)]→[类型 slot15]——与 v2 喂序逐字节一致；slot3/4=0x1402f7290=`ret` 纯 no-op；slot12=0x1403e8210 按串长度喂（无 NUL）；slot14=0x1402ed600=`lea rax,[rcx+8]; ret` 无副作用
- 方法体 FUN_142aa17d0：[slot3 no-op]→FUN_142abc050[varLen 仅 client 域(+0x55)][名字]→[flags **u16** slot10]→args 喂入器 FUN_142abcbc0（仅类型、参数名 slot3 no-op、空集 0 字节）→returnValues 同构（FLRespawnComponent.updateVehicleOnRespawn=BOOL 但非 exposed → 0 字节）→[index i32 由 onMethod 补]
- walker FUN_142a93420：域序 [+0x218=CLIENT 全量无预过滤][+0x198=BASE 预过滤][+0x118=CELL 预过滤]（parse 侧 Base→+0x180 wrapper/Cell→+0x100/Client→+0x200，向量在 wrapper+0x18）；onDomain 参数 2/1/4 = visitor 枚举（1="baseMethods"/2="clientMethods"/4="cellMethods"，FUN_142a9b750 标签→slot3 no-op 0 字节）；client 方法 flags 恒 0（FUN_142aa1fa0 无隐式 exposed 位）→ onMethod 的 (flags&0xC) 全灭；每域计数器独立从 0 起、跨自有+子描述连续、仅对通过者递增
- decider 三槽（+0x85/86/87=slot0/1/2）汇编：Entity=读对象+0x28 字节（side^1，恒 1）；Dynamic=分发码(1=声明/2=缺省)或脚本存在；Space=`mov al,1; ret` 恒真
- VLH 默认=1（FUN_142abc1e0: readInt("VariableLengthHeaderSize", 1)）→ 缺省不喂；ARRAY size 默认=0=变长（vanilla sequence_data_type.cpp 源码复核 + size_==0 即 trust DataSource）
- flags 表 @0x144341530 九项 exe 直读：CELL_PRIVATE=0/CELL_PUBLIC=1/OTHER_CLIENTS=3/OWN_CLIENT=4/BASE=8/BASE_AND_CLIENT=0xC/CELL_PUBLIC_AND_OWN=5/ALL_CLIENTS=7/EDITOR_ONLY=0x40——与 defparse 完全一致
- digest 顶层：FUN_142a9b640(MD5Calculator init→回调→final)→FUN_142a9b5b0(slot3(0,0) no-op→FUN_142a9b410 全量 0x328 步长遍历)——无版本/计数前后缀；EntityType::init(c_1402c13f0:143725)确认 parse→digest 同一全局 map(DAT_14483e050) 且顺序执行
- 静态子描述属性不进父记录：csi_tables_v8 权威表 Avatar=28 条/TeamInfo=1 条均无组件属性（0x05 块回放验证过）→ 子描述仅方法进 digest 维持
- 29 个扩展 exposed 方法对账 = 27 自有 + 2 继承（FallTanksRespawnComponent/SMVehicleRespawnComponent 自 VehicleRespawnComponent.chooseSpawnGroup）；story_mode 2 个静态组件（StoryModeAccountComponent/StoryModeAvatarComponent）的 3 个 exposed 方法按修正模型不挂载不喂

### 11.5 实算现状与剩余自由度
- 主消融（无扩展）= FD632272DB2A3B151A2AA1D6EB1B8E39（v13 的 E2E9EBE2 + u16 修复后）；全量 318 记录 = **20E4276EECFABCE2D667889230F03CD1** ≠ 目标 5DF886F75E73B33CFF9D87FB9C69389C
- digest_variants.py 十变体全负（扩展位置/逆序/含无脚本/消融组合）
- vanilla 基线漂移说明：defparse.entity_digest()=EBE966BE（v13 AllowNone 定长化修复的预期效果，非回归）
- **全部结构层已汇编级穷尽验证** → 剩余偏差指向数据同期性：①回放录制(09-11 18:01)与扩展导出(09-24)之间客户端是否微更新（exe FileVersion=2.4.0.10161 #2616763，回放 0x2D="17, 1, 0, 5" 来源未定位，无法排除）；②res_mods 是否有改 entityDefs 的 mod；③主树（与回放数据 100% 自洽：csi 40/40 + 0x05 块 + 方法锚点）与扩展 pkg 是否同期
- 新脚本：verify_ext_pkg / ext_raw_decode_test / ext_facts / disas_call_sites / disas_full_flow / disas_ext_key / digest_fork_v3 / digest_variants；新数据：download/ext_facts.json

---

## 12. [v16 · 2026-09-24 终局轮] 版本终局 + client 方法真相 + 网络 methodID 机制 —— 0x3D 剩余偏差锁定 dyncomp 记录

> 本节由 V12 恢复轮从最全会话记录（FengY233/test 会话记录.txt 8,389 行版）逐段还原，
> digest 值 5976CA14 已由 V12 重建脚本精确复现（318 记录/排除名单/digest 逐位一致）。

### 12.1 版本疑云终局（用户三答 + git 加深 diff 双重裁决）
- **0x3D 方向判定**（最致命嫌疑排除）：t=24(版本"2.4.0.0")/t=45(构建"17,1,0,5")/t=48("sd")/t=61(digest) 是 clk=0 头部区单调相邻的**登录流四件套——全部是客户端→服务器 LogOnParams 上行字段**（服务器回放从服务器视角录制，录的是它收到的上行包）→ 0x3D = 客户端算的 digest，模型对象正确。
- 主树 entities.xml 只有 ClientServerEntities 40 个、**无 ServerOnlyEntities 节** → 主树 SO 记录嫌疑排除。
- **#938→#942 diff 仅 6 个文件**（precache.xml、version.xml、manifest、元数据）——零 def/实体定义变更：即使用户对录制版本记忆有偏差，938/942 的 defs 完全相同。
- V2 #949 的 152 个 M 全部与 digest 无关（GUI/本地化/平衡数据）；镜像流水线 09-10→09-17 之间开始收录 def 文件（V1 无 V2 有，A 状态会掩盖真实 def 内容变更——已与本案脱钩）。
- 用户三答落位：①客户端一直停在 #942 未更新 #949；②「小版本」指 #938→#942（同版本内 build 变化）；③无改 entityDefs 的 mod。**全部材料（exe/decomp/回放/ext_pkg defs/scripts.7z）版本对齐 #942，版本漂移嫌疑整体排除。**
- 版本时间线（北京时间）：09-11 05:58 wot-cn 镜像快照 #942（2.4.0.5435，59e9235）→ 09-11 18:01 回放录制（=V1 defs）→ 09-18 03:23 镜像 #949（2.4.0.5449，2.4.0.1 上线）→ 09-23/24 用户导出 exe（sha256 与 #942 manifest 一致✓）+ ext_defs（#942 客户端✓）。

### 12.2 ★client 方法自动 |=0x4（本轮最大模型修复，三方铁证）
- **运行时真值源**：回放 0x08 实体方法调用包 1,265 个 / 31 eid / 128 (eid, methodID) 对——网络 methodID 真值锚。
- **证据链**：
  1. **decomp**：FUN_142aa7540（EntityMethodDescriptions::init）377428-377429 机器码 `if (param_3 == 0) { flags |= 4; }`（component==CLIENT → IS_EXPOSED_TO_ALL_CLIENTS）——vanilla 无此规则，fork 独有；FUN_142aa1060 构造清零 +0x70（flags 初值 0）在 parse 前执行。
  2. **vanilla 对照**：vanilla flags_=uint8 且 client 方法禁带 Exposed、无自动 0x4——fork 改了规则（这是 fork/vanilla 方法层唯一行为差异）；vanilla isExposed() = flags & (ALL_CLIENTS|OWN_CLIENT) = flags & 0xC 与 onMethod 过滤一致。
  3. **运行时**：0x08 真值全量命中——Avatar client 域 flags=0x4 方法全部可调用（updateResourceAmount 等 70 个）、Vehicle mid=1=showShooting（开火）、mid=4=onHealthChanged、mid=10=showDamageFromShot。
- **修复**：digest_fork_v2 的方法过滤从「client 全 skip + base/cell 用 is_exposed()(0x2 位)」改为**三域统一 (flags & 0xC) != 0**（分布位，与 exposed 位无关）——client 方法全部进 digest（自动 0x4）；base/cell 纯 exposed(0x2) 方法出局（此前被误喂）。模型方法数 163→366（V12 重建版同口径统计 372，差异为统计函数口径，digest 喂入流逐位一致）。
- defparse 的 flags 解析语义本来就是对的（client 自动 |=0.4、Exposed 标签 0x4/0x8/0xC）——错误只在 digest_fork_v2 的过滤层。
- **方法层语义三层闭合**（decomp + vanilla + 运行时）：exposedMethods_ 收集条件 (flags & 0xC)!=0；comp 位枚举 CLIENT=0/CELL=1/BASE=2（vanilla 确认）；Exposed 处理 CELL+ALL→|4、OWN→|8、空→|0xC、client 禁用（报错路径确认）。

### 12.3 ★网络 methodID 机制全解（与 csi 排序同构）
- **网络 methodID ≠ digest index**——两套编号：digest index = legacyExposedIndex（声明序计数器，仅通过者递增）；网络 methodID = 域内 exposedMethods_（isExposed = flags&0xC）**stable_sort by streamSize**（定长升序在前、变长在后按 varLenHeaderSize）后 0 起编号——与属性 csi 的 allocateClientServerFullIndexes 排序**同族同构**。
- streamSize(true) 语义：定长=args streamSize 和（cell exposed 且服务器方向 +4），变长=-varLenHeaderSize。
- 实证：Avatar mid=23×28 次=updateArena（28 次 arena 更新，语义吻合）；mid=58 body 1249B 内嵌 pickle arena 配置 = updateArena 参数（jsonl 的 m 字段"setClientReady"等是生成器错位标注——**README 警告应验，m 字段弃用**）。
- 排序 bug 教训：排序键元组 (-vlh, 1) 首元素为负导致变长组反排在定长组前——修正后 Vehicle 全部调用 = client 域方法 100% 命中。
- 0x05 创建块 n 字段 = 实体类型索引（=记录 +0x82 计数器，正是 FUN_142a99f30 的分配索引）；分布 {3:ArenaInfo×1, 6:Vehicle×30车, 7:AreaDestructibles, 18/28/29:各1, 40:NetworkEntity×4}——**n=40 的载荷与 NetworkEntity csi 表完美吻合（scale=1,1,1 / unique_id=UUID / prefab_path="37_bridge_destruction_01" / name="Collisions"）——索引布局铁证**。
- **entities.xml 真实声明序非字母序**：Account, Avatar, ArenaInfo, ClientSelectableObject, HangarVehicle, Vehicle(第6), AreaDestructibles(第7)…——与 0x05 真值完美吻合；**索引 = space(0) + 声明序(1..40)**。defparse 按声明序加载 ✓（顺序模型没错）。
- Avatar eid=546611552（类型索引 2，登录期创建故无 0x05 块，自洽）；ArenaInfo eid=545320414。

### 12.4 模型层其余闭合项（本轮逐个排除）
- **digest 遍历顺序闭合**：EntityType::init → FUN_142a9b640(out, &DAT_14483e050, FUN_142a9b5b0) → FUN_142a9b410 遍历 DAT_14483e050 对象 {begin,end} 0x328 步长 = **parse 期间 append 物理序，无重排**；v3 顺序模型（space→主CS→扩展CS→主dyncomp→扩展dyncomp）与 FUN_142a98830 编排一致。
- **arena_defs 不进 digest**：= 声音库重映射配置（extraSoundRemapping/loadBanks）；编排函数只读 entities.xml/components.xml/spaces.xml 三文件（前奏 scripts/spaces.xml(18字符)+scripts/components.xml(22字符)+entities.xml）；模式表（FUN_142a8e790）：1=entity_defs/2=space_defs/3=service_defs/5=event_topics/7=component_defs——arena_defs 不在 digest 路径。
- **Personality/cgf 不进 digest**：全部引用集中在 0x142a80xxx 段 = FeatureExtensionMap::parse（加载期个性化配置）；EntityDescriptionMap::parse（0x142a9xxxx 段）对它们零引用。
- **扩展 pkg 内只有 extension.xml**（无 scripts/entities.xml、components.xml——all_files.txt 1196 成员全查）→ 扩展循环读的就是 extension.xml 的段。
- **+0x87 三槽 decider 语义最终确认**：+0x85/86/87 = 同一 decider 对象三个虚方法（vtable slot0/1/2）返回值，slot2 写 +0x87 = 索引/digest 总开关（非零才分配记录索引 +0x82，fun_142a99f30.c:641）；调用前构造 {Base,Cell,Client} 三域存在性位图（FUN_142ba0820 查标签，(b^1)+1 → 1/2 编码）作第三参。三 decider：Entity=side 字节、Dynamic=分发码(1=声明/2=缺省)或脚本存在、Space=恒真。
- **loop#2 机器码只读 DynamicComponents**（100% 闭环）；扩展 dyncomp 挂载索引为空（动态组件永不挂载）。
- **10 个扩展实体全有 client 脚本**（decider 语义不影响）；11 个扩展排除项无包目录（排除成立）。
- **同名去重全局查空**：FUN_142a99f30 记录追加有全局名字 map 去重（pvVar7==local_1e0 才追加）——ext dyncomp vs 主实体名 / ext 实体 vs 主 dyncomp 名 / vs space 名全部组合为空，318 记录集无懈可击。
- **主树 DynamicComponents 纯名字列表**（无分发码）→ 3 个主排除（ExtendedSPG/EnemyShotPredictorController/ArenaVehiclesInfo）正确，双重确认（decider=0 且 +0x87 过滤）。
- **vanilla 的 args 喂入结构**：varLen 在前名字在后 ✓、args 无标签 ✓、varLenHeaderSize 4 字节 ✓；getServerToClientStreamSize（varLen 条件流大小）与 defparse _stream_size 同义 ✓。
- **VLH 默认=1**（FUN_142abc1e0: readInt("VariableLengthHeaderSize", 1)）；引擎 def 解析错误会**中止整批**（该扩展全部记录消失）——defparse 容忍性扫描三类致命构造（BASE+Exposed(ALL_CLIENTS)、client 方法带 Exposed、ReturnValues 类型有效性）均未触发。
- **DATA_DISTRIBUTION_FLAGS 掩码 0x5F 两侧一致**（exe flags 表 @0x144341530 直读复核）。
- **嵌套接口仅 2 处**（61 个 interfaces 中）——嵌套顺序影响方法合并顺序的嫌疑排除。
- **唯一 isVolatile=1 = GunMarkerComponent.gunMarker**（BattleRoyaleRadio 是纯 Volatile 空壳——Volatile 节只有 position 自动属性、无声明属性，Volatile 计数无遗漏）。
- **组件接口结构简单**（亲审 dyncomp def 解析语义）；有效挂载组件 3 个带 CS 属性（TeamInfo←1+2、Avatar←4）但**子描述属性不进父记录**（csi 表 28+1 条无组件属性——0x05 块验证）。
- **FLRespawnComponent 的 ReturnValues 在非暴露方法**（updateVehicleOnRespawn 无 Exposed）→ 全部 5 处 RV 方法在新语义下依然出局（RV=0 字节确认）。
- **DefaultKeyName 只进记录 +0x308 显示名字段**（仅 dyncomp）不进喂入；ApplicationPoint 根级标量（AppealRadius/shouldBackup）不进 feed；defparse 对无 size 的 ARRAY 喂 0（vanilla 确认 size=0=变长）；KillCamDataComponent 1 属性=1684B（KILL_CAM_DATA 巨型嵌套 FIXED_DICT 含 ARRAY size=0，DT 层解剖无异常）。
- **exe 版本 = 2.4.0.10161 #2616763**（与回放构建串"17, 1, 0, 5"格式不同——后者来源无法直接定位，但 #942 版本对齐已由用户确认 + sha256 钉死）；WG 固定构建时间戳无法定年（已无关紧要）。
- **回放仅单 digest 锚**（全流唯一 0x3D，无第二样本可交叉定位）。
- **双 index 变体实验均负**（digest 喂声明序计数器 vs sorted 序）；消融矩阵全负但系统性排除了多个层。

### 12.5 实算终态与剩余自由度
- **修复链**：v13 过滤（163 方法）→ v15 u16（20E4276E 全量 / FD632272 主消融 / E2E9EBE2 no-ext 复现=零回归）→ v16 client 方法修复（**5976CA145E07E97C627D8B40ED9952CF** 全量 318 记录）——仍 ≠ 目标 5DF886F75E73B33CFF9D87FB9C69389C。
- **V12 重建验证**：本册配套 digest_fork_v2.py（v16 终态）从 V11 包 v14 版 + 两补丁（u16 + 0xC 过滤）+ 扩展层重建，输出 5976CA14 与最后一轮逐位一致；318 记录构成（1+40+10+107+160）、排除名单（主 3 + 扩展 11）全部吻合。
- **主实体部分已达最高置信**：属性 40/40 + 方法全量 + 索引布局都有运行时真值锚（0x05 csi 神谕 + 0x08 methodID 对账 + NetworkEntity n=40）。
- **剩余偏差锁定 dyncomp 记录**：267/318 = 84% 的记录（107 主 + 160 扩展 dyncomp）没有运行时真值源——digest 不匹配的唯一剩余嫌疑区。
- **下一步（对话记录原建议）**：打一场大逃杀/前线/背水之战并录回放——那种回放的 0x05/0x08 包会给出扩展实体和动态组件的真值锚，可把无真值区压到接近零，digest 即可能收口。

### 12.6 消融值速查（复现入口）
| 模型 | digest | 备注 |
|---|---|---|
| vanilla 基线（defparse.entity_digest） | EBE966BE→562A9B22 | v13 AllowNone 定长化修复的预期漂移 |
| v14 口径（client 出局 + u8 flags） | E2E9EBE2 | no-ext 消融，v15 曾复现=零回归 |
| v15（u16 修复） | 20E4276E（全量）/ FD632272（主消融） | 方法 flags 2 字节 |
| **v16 终态（0xC 过滤统一）** | **5976CA14（全量 318）/ 16AE6853（主消融）** | V12 重建复现值 |
| 目标 | 5DF886F75E73B33CFF9D87FB9C69389C | replay.jsonl t=61，全流唯一 |

### 附录 G：v16 证据坐标（终局轮）
- FUN_142aa7540（EntityMethodDescriptions::init）377428-377429：`if (param_3==0) flags|=4`——client 方法自动 |=0x4 机器码铁证；FUN_142aa1060 = 构造清零 +0x70
- FUN_142a9b410 遍历 DAT_14483e050 {begin,end} 0x328 步长 = parse append 物理序；FUN_142a98830 编排（space→主CS→扩展CS→主dyncomp→扩展dyncomp）
- FUN_142a8e790 模式表：1=entity_defs/2=space_defs/3=service_defs/5=event_topics/7=component_defs
- FUN_142a99f30:641（fun_142a99f30.c）：+0x87 非零才分配记录索引（+0x82 计数器）——digest 总开关
- replay.jsonl：0x08 包 1,265 个（31 eid/128 对）；0x05 块 n 分布 {3,6,7,18,28,29,40}；t=61 digest 锚；jsonl m 字段=生成器错位标注（弃用）
- 0x05 n=40 载荷：NetworkEntity csi 表完美吻合（scale/unique_id/prefab_path="37_bridge_destruction_01"/name="Collisions"）
- wot-src partial clone：#938→#942 diff 6 文件（precache.xml/version.xml/manifest/元数据）；#942→#949 152 M 全非 digest 输入
- V12 重建复现：digest_fork_v2.py v16 → 5976CA145E07E97C627D8B40ED9952CF（318 记录：1 space+40 主实体+10 扩展实体+107 主 dyncomp+160 扩展 dyncomp；排除主 3 + 扩展 11）

### 附录 H：更新记录补遗
- **2026-09-25（V12 恢复轮）**：据 FengY233/test 最全会话记录（8,389 行版）恢复 v16 终局轮全部结论（本册 §12）；V11 包内 v14 版 digest_fork_v2.py 补两修复（u16+0xC 过滤）+ 扩展层重建 → 精确复现 5976CA14；findings 三处同步；V12 交付包制作。

## 13. [v17 · 2026-09-25] 11 场新回放真值锚大样本扩充 —— digest 身份终局 + methodID 机制语义级验证

### 13.1 材料与动机
- 用户提供 FengY233/test 仓库内 10 个新回放（20260905-0912 多地图多车型 + PTZ_10K + WZ-219）+ 原主分析对象 20260911_1801 = **11 场样本**：EU×7 / NA×1 / CN×3，2026-09-05~12 跨 8 天，battleType 1×10 + 46×1，mods 有无混合，全部可在 #942 客户端播放（README 自证 wot-cn 2.4.0.0 #942）。
- 动机：寻找扩展实体/动态组件真值锚（大逃杀/前线/背水之战等模式的 0x05/0x08），压缩 dyncomp 无真值区。
- **结论：11 场全部为随机战家族**（gameplayID=ctf；battleType=46 经源码鉴定 = `ARENA_BONUS_TYPE.RANDOM_NP2`（constants.py:292，battle_pass_integration 注册为 15v15 随机战队形）——非扩展模式）。**dyncomp 真值锚本轮仍未获得**，但收获四项独立成果（13.2-13.5）。

### 13.2 ★digest 版本指纹恒定性（身份终局定性）
- **11 场（EU/NA/CN 混合）0x3D 包 digest 全部 = `5DF886F75E73B33CFF9D87FB9C69389C`**（主分析目标值）；每场恰 1 个 0x3D 包，载荷 = [u32 len=0x20][32B ASCII hex]。
- 跨变因全覆盖：区域（EU/NA/CN）、日期（8 天）、有无 mods、地图（9 张）、battleType（1 与 46）、玩家/车辆——**digest 与对局内容完全无关**。
- **digest 身份终局定性：#942 客户端安装指纹**（LogOnParams 上行、服务器侧版本校验值）；复现目标从此锚定为「干净 #942 客户端 scripts 的 EntityDescriptionMap fork MD5」，排除了「对局相关动态成分」的最后可能。
- 附带：dec.7z（AES 分卷，密码 114514.1919810）内容 = decomp.zip（md5 48683ebc 与 upload 逐位一致）——第四份 decomp 副本，无新信息。

### 13.3 ★0x05 头格式钉死 + typeID = entities.xml 声明序 1 基编号
- 0x05 载荷头 = **[u32 eid][u32 typeID]**：以 20260911_1801 jsonl 的 (eid, n) 1,130 对全量校准 + 其余场 1,486 对零失配。
- **typeID = entities.xml `<ClientServerEntities>` 声明序 1 基编号**（v16 发现的"真实声明序"再获运行时确证）：40 实体全表对齐——ArenaInfo(3)/Vehicle(6)/AreaDestructibles(7)/DetachedTurret(12)/DebugDrawEntity(13)/EmptyEntity(18)/TeamInfo(28)/AvatarInfo(29)/NetworkEntity(40)。
- **网络创建实体集（0x05 观测，11 场）**：
  | typeID | 实体 | 出现 | 特征 |
  |---|---|---|---|
  | 3 | ArenaInfo | 11/11 恰 1 | 每场唯一 |
  | 6 | Vehicle | 11/11，32-247/场 | 30 车 + 召唤物/复制品 |
  | 7 | AreaDestructibles | 11/11，107-1802/场 | 地图可破坏物；CN 服务器回放模式场（1534/1801）数量 9-10 倍于 EU/NA 场 |
  | 12 | DetachedTurret | 3/11 | 有脱炮塔机制车辆的对局（karelia/namerica/PTZ_10K） |
  | 13 | DebugDrawEntity | 1/11 | 仅 tundra bt46 场 1 个 |
  | 18 | EmptyEntity | 11/11 恰 1 | 每场唯一 |
  | 28 | TeamInfo | 11/11 恰 1 | 每场唯一 |
  | 29 | AvatarInfo | 11/11 恰 1 | 每场唯一 |
  | 40 | NetworkEntity | 6/11，2-46/场 | 与 §12.4 n=40 索引布局铁证互证 |
- **无任何扩展实体**（BattleRoyale* 等 18 扩展的 10 CS 实体零出现）——与"全随机战"自洽，也再次印证扩展实体仅在对应模式对局中实例化。

### 13.4 ★methodID 机制 11 场语义级验证（从 128 对到行为学）
- **未识别实体识别 = Avatar**：11 场每场恰 1 个 eid 不在 0x05 映射（eid 恒大于该场全部 0x05 实体——战斗加载后期创建）、methodID 签名跨场高度一致；模型表对比：Avatar client 域 70 个 exposed 方法全覆盖观测 18 个 mid（Account 41 个仅覆盖 11，次优排除）。
- **Avatar 18 个观测 mid 的语义-行为吻合**（methodid_tables.py 生成 + 11 场计数交叉）：
  | mid | 方法 | 出现 | 行为学吻合 |
  |---|---|---|---|
  | 28 | setUpdatedGoodiesSnapshot (vlh=2) | 11/11 | 每场必发的 goodies 快照同步 |
  | 37 | onAutoAimVehicleLost (ss=1) | 11/11 | 自动瞄准持续丢失 |
  | 54 | updateState (ss=13) | 11/11 | 高频状态更新 |
  | 58 | **stopTracer** (ss=16) | 11/11 | 每场都有射击的弹道终止 |
  | 62 | updateVehicleAmmo (ss=18) | 11/11 | 每场都开炮的弹药更新 |
  | 67 | battleEventsSummary (ss=34) | 11/11 | 战斗事件汇总 |
  | 10 | onRandomReserveOffer | 10/11 | 随机储备优惠推送 |
  | 38 | onKickedFromArena (ss=1) | 10/11 | 断线/重连类通知 |
  | 29 | onRandomEvent | 8/11 | 占点/空袭等随机事件 |
  | 30 | notifyCannotStartRecovering (ss=0) | 8/11 | 维修通知 |
  | 68 | updateTargetingInfo (ss=36) | 7/11 | 瞄准信息 |
  | 40 | onRoundFinished (ss=2) | 6/11 | **仅完整打完的 6 场收到回合结束** |
  | 23 | updateCarriedFlagPositions | 4/11 | ctf 夺旗事件 |
  | 65 | showHittingArea (ss=34) | 4/11 | **火炮瞄准警告（恰为有 SPG 的对局）** |
  | 7 | updateSpawnList (vlh=2) | 2/11 | 出生列表 |
  | 27 | handleScriptEventFromServer | 2/11 | 脚本事件 |
  | 33 | leavingProtectionZone (ss=1) | 2/11 | 离开保护区 |
  | 53 | enemySPGHit (ss=12) | 2/11 | **被敌火炮命中（恰 2 场）** |
- Vehicle 表同样吻合：观测 8/11 方法——mid=1 showDamageFromShot(1,931 次)/mid=10 onStaticCollision(1,908)/mid=4 onPushed(1,216)/mid=8 showRammingEffect(1,250) 全场高频，mid=3 showShooting 仅 5 次等。
- ArenaInfo client 域仅 1 个 exposed 方法 showCarpetBombing——与"typeID=3 实体零 0x08 记录"自洽（地毯轰炸未触发）。
- **结论：§12.3 的 methodID 分配规则（域内 exposedMethods_ stable_sort by streamSize 定长升序在前变长按 vlh）从单场 128 对升级为 11 场语义级全验证。**

### 13.5 ★jsonl m 字段错位标注最终实锤
- jsonl 生成器对 0x08 标注的 "m":"updateArena"（eid 546611552 / mid=58）系错位：Avatar 表 mid=58 = stopTracer（真 updateArena 是 mid=21）；findings §12 "弃用 m 字段" 的判定获得方法名级实锤。

### 13.6 本轮工具与产物（scripts/ 新增 6 件）
- `survey_new_replays.py`（11 场普查：block0 元数据/包型直方图/0x3D 提取）→ /tmp/wot/new_replay_survey.json
- `extract_entities.py`（0x05 (eid,typeID) 提取 + jsonl 校准）→ /tmp/wot/entity_anchor.json
- `mid_signatures.py` / `mid_signatures2.py`（0x08 跨场矩阵 + 未识别 eid 定位）→ /tmp/wot/mid_matrix.json
- `methodid_tables.py`（复用 digest_fork_v2 组件装载 + §12.3 排序规则生成 methodID 分配表）→ /tmp/wot/methodid_tables.json（14 实体 168 方法）
- `entity_decl_order.py`（entities.xml 声明序 ↔ 0x05 观测对齐表）
- `dec7z_open.py`（dec.7z 密码验证）

### 附录 I：v17 证据坐标（11 场回放轮）
- 11 场 0x3D digest 恒定：/tmp/wot/new_replay_survey.json（digests 字段 11 条全 20000000+ASCII）
- 0x05 头校准：extract_entities.py 输出 "ok=1486 bad=0"
- typeID 对齐表：entity_decl_order.py 输出（9 typeID × 11 场矩阵）
- Avatar methodID 表：methodid_tables.json['Avatar']（70 方法含 ss/vlh/fl 元数据）
- battleType=46 鉴定：wot_src sources/res/scripts/common/constants.py:292 RANDOM_NP2 = 46；battle_pass_integration.py:168
- BigWorld vanilla 源码就绪：/tmp/wot/bigworld/bigworld_src/programming/{bigworld,fantasydemo}（36,792 文件 1.4GB，tar 440MB 解压）

## 14. [v18 · 2026-09-25] 技能体系三分离 + CSI≥50 动态组件通道 —— dyncomp 真值锚通道打开

> 本轮输入：用户三项纠正（①仅 1 场可能 CN942，其余外服但可在 942 客户端播放；②全部随机战；
> ③十一级车有车辆特殊技能、乘员技能是另一套系统，分析 0x05/0x08 时必须分别识别不得混淆）。
> 会话 H（02:40-02:58 未入 worklog 的断线段，13 个脚本）工作已恢复并整合入本节。

### 14.1 ★回放归属终局（block0 clientVersionFromXml 构建号）→ digest 定性修正
- **11 场构建号全表**（`clientVersionFromXml` 字段，block0_full.py）：
  | 场 | 构建 | 区域 | 服务器 | 玩家 |
  |---|---|---|---|---|
  | 0905 siegfried / 0906 karelia / 0907 lakeville | **#935** | EU | EU1/EU2 | DarknessHunterKIller 等 |
  | 0910 caucasus | **#945** | NA | US Central | solisjr98_10 |
  | 0911 1534 namerica / 1749 tundra / 1801 caucasus | **#942** | CN | 频道1/频道2 | 巅峰荣誉v拍子×2 + One_kvm |
  | 0912 greatwall / karelia2 / PTZ / WZ-219 | **#944** | EU | EU1/EU2/EU5 | Lemming_SkyHunt3r 等 |
- **用户"仅 1 场 CN942"实证修正为 3 场**（1534/1749/1801 同为 #942；1534 与 1801 同玩家"巅峰荣誉v拍子"，间隔 2.5h）。外服 8 场确实均非 #942（#935×3/#944×4/#945×1），用户核心论点成立。
- **digest 定性修正（推翻 §13.2）**：0x3D digest 在 **4 个构建（#935→#945）× 3 区域（EU/NA/CN）× 6 服务器 × mods 混合**下全部恒等 = 5DF886F7…89C。→ digest 不是「#942 客户端安装指纹」，而是 **2.4.0.0 世代全局统一的 EntityDescriptionMap 指纹**（构建间 def 内容零漂移）。
- **连带排除 §11.5 三条数据同期性假设**：①客户端微更新（#935-#945 十构建窗口 digest 不变→世代内任意时点导出均有效）；②res_mods 改 entityDefs（无 mods 场同 digest）；③主树与扩展 pkg 同期性（同理放宽）。
- 复现目标不变：仍以 #942 scripts + ext_pkg 为输入（世代内自洽），但**输入时点敏感性归零**——剩余偏差 100% 收敛于模型对 dyncomp 记录的解析细节。

### 14.2 ★技能体系三分离（用户纠正③的 def 级实证）
- Vehicle csi 表（csi_tables_v8）中三套系统天然分离：
  | 系统 | csi | 属性 | 类型 | 来源 | 线行为 |
  |---|---|---|---|---|---|
  | **乘员技能** | 33/34/35 | perkEffects / perks / perksRibbonNotify | FIXED_DICT / ARRAY / ARRAY | Perks_Vehicle 接口 | 0x07 键 33/34 战斗中活跃更新（karelia2: 33×17 + 34×10 次） |
  | **车辆技能(十一级)** | 44/45 | vehPerks / vehPostProgression | PYTHON / ARRAY | Vehicle 自有 | 创建时一次性下发，0x07 零更新 |
  | 车辆战斗系统 | ≥50 扩展区 | 动态组件属性 | 见 §14.5 | 运行时挂载 dyncomp | 创建时一次性下发 |
- **roster 侧锚**（block0 vehicles.vehPostProgression，roster_matrix.py）：314 车全量分布——`[]`×84 / `[1073741812]`×78（=0x3FFFFFF4 满树）/ 小值 ×N。**全部非空值低 4 位恒 =0x4**（(技能位图<<4)|4，bit2=基础节点恒开）。同车型 maxHealth 随节点数浮动（Cz46_Vz_63P: 2270→2610，Taschenratte: 3500→3940）→ HP 加成节点直接实证。
- 新一代车型（Cz46/G187/G197/G189/Ch70/Ch67/It43/J53/Ch71/F135/F143/S41/R228/S36/F136/J52…）几乎全员带 vpp（15-16/17、13/13、15/15、10/10…）；G198_Kampfpanzer_67 0/12、GB41_Challenger 0/4 为例外 → vpp 资格车型表可从 11 场样本精确枚举。
- **Vehicle 0x08 mid 差分 = 纯战斗内容差异**（tier11_skill_probe.py 重跑）：外服 vs CN942 基线最多 +mid3(showShooting)/+mid6、−mid7，无任何结构性新 mid → **技能不走实体方法通道**，走组件属性通道（§14.5）。

### 14.3 ★0x07 原始格式钉死（跨回放解码解锁）
- **格式 = [u32 eid][u32 key(csi)][u32 blen][body]**（p07_align.py：CN942 场 jsonl 37,105 条 clk+eid 全命中，0 失配）。
- 0x07 body 形态字典（karelia2 Vehicle）：key1/4=1B、key13/14/15=2B、key16=4B（与 csi 表 streamSize 严格一致）；**key29/30/33/34 出现 1 字节 0x00 body** = None 标记（AllowNone/可空类型的空值线编码）。
- **Vehicle csi 键空间观测（11 场）**：max=34-38 < 50，无越界键 → 组件属性**不走 0x07 更新通道**（准静态，创建时一次下发）——与 §14.5 扩展区只在 0x05 出现互证。

### 14.4 0x05 创建块全格式（Vehicle）
- **[u32 eid][u32 typeID][10B fork 头（含每场常量）][pos 3×f32][ypr 3×f32][u32 propBytes][u8 count] × ([u8 csi][typed value])**。
- propBytes 自洽率 100%（len−46 == propBytes，逐场验证）；语义锚：csi14 health=roster maxHealth 逐车吻合（CAV=2100/AS_XX=2200/BV_111=2200）、csi16 avatarID=avatarSessionID（1,092 车 join 全唯一）、csi5 isCrewActive=1。
- 变长属性线编码：定长 TUPLE（如 engineMode ss=2）无计数头直出 N 字节；ARRAY/变长 = [计数/长度头][数据]；可空 = [0x00] 空标记。
- 已知残留：count 语义未完全钉死（基础段走通即止），wheelsScroll= TUPLE<UINT8> 8 元素无头直出（观测"07 64 5f 75 5f 73 5f 6e"=首元素 7）。

### 14.5 ★★CSI≥50 扩展区 = 动态组件属性通道（本轮最大发现）
- **0x05 创建块的属性索引空间 = 实体自身 CS 属性（Vehicle: 0-49）+ 运行时挂载组件属性（50+）**。证据链：基础段走通后残余区出现 idx 52-248（远超实体自身 50 上限，且 0x07 从不更新这些键）+ vanilla `clientServerProperty(n)` 索引机制 + Vehicle 静态挂载 VehicleInBattleSwitch 为**空组件**（无属性无方法）→ 50+ 全部来自**运行时动态挂载的 dyncomp**。
- **1,092 车全量统计**（veh05_ext.py，10 场 join roster）：扩展区 45-208 字节/车，含该车全部挂载 dyncomp 的初始属性值。
- **Tier XI 字节签名**：有 vpp 车 extlen 中位 **117**（n=754）vs 无 vpp **93**（n=338），均值 124 vs 104（**+25%**）→ 技能组件的属性字节贡献直接可测。
- 车型粒度示例：Taschenratte 有 vpp 中位 177 / Kampfpanzer_67 无 vpp 中位 118 / T92 无 vpp 中位 73。
- **对 digest 主线的意义**：§12.5 的「dyncomp 84% 无真值区」从此**不再是网络不可见**——0x05 扩展区可提取：①每车挂载组件集（车型×技能的函数）②组件挂载顺序（csi 50+ 的分配序）③各组件属性布局与类型宽度④属性初值。这四类观测可反推 dyncomp def 的解析正确性（属性声明序/csi 分配/类型编码）——正是 84% 区需要的运行时真值锚。
- 下一步（Task 34）：扩展区类型驱动全解码（组件 def 库 + 挂载集推断 + 逐条目 walk 校验），目标把 dyncomp 无真值区从 84% 压到接近零。

### 14.6 0x39 = 游戏对象复制流（首个获运行时观测的 dyncomp）
- 出现面：仅 4 个 EU 场（siegfried 30 / karelia 5,832 / karelia2 4,762 / WZ-219 6,304 包），**全部 = 录像玩家自己的车**（eid→avatarID→roster join 证实），全部带 vpp 技能树 + activePetID=1。
- 结构（p39 系列）：72B 子型（首 u32=0x44）+ 41B 子型（首 u32=0x25）；共享每场常量 const8（疑 networkID+parentID 对）；seqA/seqB 链式（5,372/5,615 衔接）；72B 含 pos 3×f32 + 矢量 3×f32（|v|∈{720, 880, 1000} 精确圆值，段内恒定）。
- 行为学：轨迹从本车出生点出发 → 400m 外低速游弋（相邻包位移中位 0.11m）→ 长时悬停 → 换段机动；52 段（karelia）。
- def 对位：`NetworkReplicationPointComponent.def`：`status: ARRAY<GAME_OBJECT_STATE_INFO> ALL_CLIENTS` + `removed: ARRAY<UINT32> ALL_CLIENTS`；GAME_OBJECT_STATE_INFO（alias.xml）= STRUCT{prefabPath STRING, recreateMethod UINT8, networkID UINT32, parentID UINT32, active BOOL}。与 NetworkEntity 的 prefab 系统（§12.4 prefab_path="37_bridge_destruction_01"）同族。
- 假设排除记录：宠物装备假设证伪（9/11 玩家 activePetID≥1 但仅 4 场有流——0x39 = **部署态**遥测而非装备态）；射手=宠物主相关性检验的 dbid≠eid bug 已定位（pet_correlation.py 用名册键 dbid 对比 eid）。
- 0x39 与 digest 主线关系：NetworkReplicationPointComponent 成为**首个同时具备 def 输入与运行时字节流的 dyncomp**——其 status/removed 的线序列化（ARRAY 头 + STRUCT 成员序）可直接校验模型类型解析。

### 14.7 BigWorld vanilla 参考实现全席就位（备选路径落地）
- 消息层：client_interface.hpp 消息声明序（authenticate=0…createEntity/createEntityDetailed/enterAoI/leaveAoI…detailedPosition/nestedEntityProperty/sliceEntityProperty/updateEntity/entityMethod range/entityProperty range）；common_client_interface（tickSync/relativePosition 系/setVehicle/selectEntity/selectPlayerEntity/forcedPosition/avatarUpdate 系）。
- 回放层：replay_data.hpp 块枚举（ENTITY_CREATE/VOLATILE/VOLATILE_ON_GROUND/METHOD/PROPERTY_CHANGE/DELETE/PLAYER_STATE_CHANGE/PLAYER_AOI_CHANGE/SPACE_DATA/FINAL）——WoT fork 重排但语义族对齐（0x05=创建/0x07=属性/0x08=方法/0x0A=volatile 大流量）。
- 属性流：`BWEntity::onProperties` = **[u8 size][size × ([u8 index][value])]**（vanilla 原型）；WoT fork 增加了 [u32 propBytes] 外壳（§14.4）。
- 类型层：ArrayDataType::addToMD5 = "Array\0" + size_(int32) + dbLen_(>0 时 int32) + 元素递归；TupleDataType = "Tuple\0" + 同序；StringDataType = "String\0"。defparse.py 实现与源码逐字节一致（含 NUL、dbLen_ 条件、无类型名等细节）——模型类型层获 vanilla 级背书。

### 14.8 本轮工具与产物（scripts/ 新增 11 件）
- `block0_full.py`（11 场 block0 全字段 → /tmp/wot/block0_full.json）
- `roster_matrix.py`（314 车名册×vpp×prestige 矩阵 → /tmp/wot/roster_matrix.json）
- `p07_align.py`（jsonl↔原始包对齐钉死 0x07 格式）
- `p07_csi_scan.py`（11 场 0x07 全量 csi 键直方图 → /tmp/wot/p07_csi_scan.json）
- `p07_bodies.py`（0x07 各键 body 形态字典）
- `veh05_join.py`（载荷↔名册 avatarID join → /tmp/wot/veh05_join.json）
- `veh05_layout.py` / `veh05_props.py` / `veh05_decl.py`（0x05 布局锚定迭代）
- `veh05_ext.py`（★CSI≥50 扩展区统计 → /tmp/wot/veh05_ext.json，1,092 车）
- `p39_identify.py` / `pet_correlation.py` 等会话 H 脚本恢复重跑（tier11_probe/p39_decode/p39_full_decode/p39_roster/p39_roster2/p39_traj/p39_shooter/pp_skill_roster）
- 声明序全表：/tmp/wot/veh_decl_table.json（Vehicle 76 属性 decl#↔csi 映射，含 26 非 CS）

### 附录 J：v18 证据坐标（技能分离 + 组件通道轮）
- 构建号全表：/tmp/wot/block0_full.json（clientVersionFromXml 字段 11 条）
- vpp 位模式与 HP 浮动：/tmp/wot/roster_matrix.json（314 行）
- 0x07 格式对齐：p07_align.py 输出 "clk+eid 命中 37105 / 未命中 0"
- 0x05 propBytes 自洽：veh05_layout.py 三场三车 100% + veh05_ext.py 1,092 车 walk ok
- 扩展区统计：/tmp/wot/veh05_ext.json（每车 extoff/extlen/ext_head/base_ents + roster join 字段）
- 0x39 结构：p39_full_decode.py 输出（恒定偏移表 + seq 链 + magic 分组）
- GAME_OBJECT_STATE_INFO 定义：wot_scripts/scripts/entity_defs/alias.xml（BWXML 解码）
- vanilla 参考：bigworld/lib/connection/{client_interface,common_client_interface,replay_data}.hpp + bw_entity.cpp onProperties + data_types/{array,tuple,string}_data_type.cpp addToMD5
- VehicleInBattleSwitch 空组件：component_defs/VehicleInBattleSwitch.def（无 Properties/无 Methods/无 Parent）
- digest 恒定跨构建：new_replay_survey.json × block0_full.json 交叉（4 构建 11 场同值）

## 15. [v19 · 2026-09-25] 0x05 属性流终局 + MY_VEHICLE 分层 + 网络索引重排 —— Task 34 扩展区类型驱动解码轮

> 本轮输入：用户指令「彻底把回放全部内容研究透彻，同时参考 scripts、decomp、wot-src、bigworld 四数据源」。
> 四源联动：BigWorld vanilla 源码（线编码/排序白盒）+ decomp（客户端解析函数白盒）+ wot_scripts（服务器 def 真值）+ 11 场回放观测（1,092 车大样本）。

### 15.1 ★0x05 属性流 = vanilla 纯格式（四实体铁证）
- **格式终局**：`[u32 propBytes(fork 外壳)][u8 count][count × ([u8 idx][typed value])]`——与 vanilla `EntityCache::addChangedProperties`（entity_cache.cpp:247）逐语义吻合：`stream << uint8(numToSend)` + 每属性 `stream << uint8(i)` + `addToStream`。
- **四实体铁证**（caucasus CN942 场 0x05 typeID 全分布 {7:1578, 28:1, 3:1, 6:247, 40:4, 29:1, 18:1}）：
  - **NetworkEntity(typeID 40)**：count=3 → `(idx0, VECTOR3 scale=1,1,1)(idx1, STRING len=0x24 UUID)(idx3, STRING len=0x21 "37_bridge_destruction_01_scenario")` 逐字节吻合（propBytes=87/99/64 三例全验）；
  - **AreaDestructibles(typeID 7)**：count=4 → `(0,00)(1,00)(2,00)(3,00)`（propBytes=9）与 jsonl t=5 tail `040000010002000300` 完全一致（录制器只截尾部 9B，恰为完整属性流）；
  - **typeID 28**（单例）：count=4，`(0, ARRAY n=2 空元素×2)(1/2/3, STRING len=6 ×3)`——`06 80 02 7d 71 01 2e` 3 组相同结构；
  - **typeID 29**（单例）：count=1，`(0, 4B=0x2094a160)`。
- **条目序 = 事件序（乱序合法）**：Vehicle 基础段观测 [1,5,13,14,16,32,15]——csi32(wheelsScroll) 出现在 csi15(engineMode) 前；vanilla 遍历序为 clientServerProperty(i) 的 i 升序，**fork 服务器按「属性事件戳/touch 序」发送**（同 LoD 内乱序），解析端不依赖顺序。
- **PyEntity::initCellEntityFromStream 客户端白盒**（decomp c_1402c13f0.c:164150 区，py_entity.cpp:0xbb）：`[u8 count] do { [u8 idx] → FUN_142a93050(desc,&out,idx) 归属 → FUN_142a8e490 DataDescription → 读值 set 属性 } while(--count)`——与 vanilla 逐语句对应。
- **FUN_142a93050/FUN_142a92db0 idx 归属机制**：`idx < 自身size → 实体属性`；否则遍历 `+0x2f0~0x2f8` 组件数组按 `idx - comp.baseIndex(+0xf8) < comp.size` 归属组件——**全局 idx 空间 = 实体段 + 各组件段拼接**，与 §14.5 的 CSI≥50 发现互证。

### 15.2 ★线编码规则全集（vanilla data_types + binary_stream 逐文件钉死）
| 类型 | 线编码 | 源码锚 |
|---|---|---|
| INT/FLOAT/VECTOR | 定长直出 | integer/float_data_types.cpp |
| 定长 TUPLE (size>0) | 无头直出（engineMode U8×2=2B 实证） | sequence_data_type.cpp:78 |
| 变长 ARRAY/TUPLE (size==0) | `[packedInt n][n×元素]` | sequence_data_type.cpp:76 |
| STRING | `[packedInt len][len B]` | string_data_type.cpp |
| PYTHON | `[packedInt len][pickle]` | python_data_type.cpp:53 |
| FIXED_DICT allow_none | `[u8 0=None / 1=有值]+字段` | fixed_dict_data_type.cpp:89 |
| **packedInt** | `<0xFF` 单字节；`0xFF+3B` | binary_stream.hpp:287 |
- **0x07 None 实证回填**（§14.3 的 key29/30/33/34 单字节 0x00 body）= FD allow_none 的 None 分支 ✓。
- **alias 级 AllowNone 大发现**：alias.xml 202 个 alias 中 **97 个带 AllowNone=1**（SIEGE_STATE_STATUS/BURNOUT_WARNING/DROWN_LEVEL/BUFF_EFFECT_INACTIVATION/HOT_EFFECT/FIRE_INFO/VEHICLE_HEALTH_INFO/TARGETING_INFO/DUAL_GUN_STATUS…）——**defparse 只读实体属性级 AllowNone、漏读 alias 级**，影响：①FIXED_DICT streamSize 计算（AllowNone 不影响定长和，维持 v8 结论）②线编码（None 标记字节）③**digest 主线待评估**（addToMD5 的 DT 层 feeder 是否喂 AllowNone 位——下轮核）。

### 15.3 ★★DetailLevel=MY_VEHICLE 分层（本轮最大发现之一）
- **Vehicle.def 10 个 MY_VEHICLE 属性**（服务器 def DetailLevel 标签全表）：`crewCompactDescrs, enhancements, setups, setupsIndexes, vehPerks, disabledSwitches`（6 变长）+ `isMyVehicle(csi10), quickShellChangerFactor(csi20), onRespawnReloadTimeFactor(csi21), ownVehiclePosition(csi29)`（4 定长）。
- **LoD 机制**（vanilla addChangedProperties：`detailLevel() == detailLevel_` 才发送）：外层 AoI 创建只发公共 LoD 属性；MY_VEHICLE 级仅录像玩家本车创建/更新时下发——**0x07 观测 key29/30 仅 2 次**（本车 ownVehiclePosition/inspired 更新）✓ 自洽。
- **跨证据互锁**：0x39 复制流只在 4 场的录像玩家本车（§14.6）、ownVehiclePosition 本车专属、jsonl 本车事件密集——MY_VEHICLE 分层是「为什么某些数据只见本车」的统一答案。

### 15.4 ★★网络 idx MY_VEHICLE 过滤重排（vpp=40 数学全解）
- **观测铁证**：vehPostProgression 的 ARRAY<I32> 值字节 `[n][roster 值 LE]` 在 **754/754 有 vpp 车**中前导字节恒 = **0x28(40)**，零偏差（csi_anchor.py 全量复验）。
- **表 v8 偏差**：defparse 给 vpp csi=45（变长组声明序第 15 位）。45−40=5 = vpp 前 MY_VEHICLE 变长属性数（crewCompactDescrs/enhancements/setups/setupsIndexes/vehPerks）。
- **重排模型**：0x05 网络 idx = **「MY_VEHICLE 变长剔除后重排」**——定长组 0-30 原样保留（含 4 个 MY_VEHICLE 定长占位），公共变长 31-43（steering, wheels, perkEff, **perks(34)✓**, ribbon, postmortem, publicInfo, stickers, stateMod, **vpp(40)✓**, healing, healOT, dogTag），MY_VEHICLE 变长 44-49。
- **0x07 key 空间 = 全属性版（表 v8）**：11 场 key 汇总 {1:42601, 4:1045, 5:5, 13:287728, 14:1216, 15:74233, 16:141, 22:6, 23:137, 27:1618, 29:2, 30:2, 33:188, 34:137, 38:1}——全部 ≤38 且与表 v8 streamSize 逐键吻合（1/4=1B、13/14/15=2B、16=4B、22/23=8B、27=24B、29=32B、30=36B）；**key 33/34/38 在重排版与表 v8 中同值**（剔除发生在 decl31+，38 之前的变长无移位）——0x07/0x05 两套 idx 空间在 ≤38 区间无区分度，唯一判别锚 = vpp 40（0x05 独有，0x07 从不更新 40+）。
- **两条 0x05 尾部恒定锚**：`21 00`（perkEff 空数组）×619 车、`22 00`（perks 空/None）×1058 车、`30 02`×1092 车全量、`28 01+4B vpp`×754 车、`2c 01`×788 车、`09 42/48`×639 车。

### 15.5 扩展区（组件段）结构进展
- **同型车模板恒定性**：184 个（场次×车型）组中 62 组（33%）扩展区**逐字节全同**（如 caucasus CN 场 A38_T92 18 辆全同 73B）——**组件段 = 车型模板初始值**（与玩家无关），玩家相关值全在实体段（health/avatarID/wheelsScroll 等）。
- **全局组件注册表**：components.xml = StaticComponents(16) + DynamicComponents(113)，每组件 def 的 CS 属性已建表（85 组件 185 CS 属性；OwnVehicle 23 CS/Fire 1/HealthComponent 2/DeathComponent 0/VehicleBuff 3/NetworkReplicationPointComponent 2/DogTagComponent 3/GunReloadBoost 3/VehicleRespawnComponent 7…）。
- **idx 空间归属**（每车独立）：同组件跨车 idx 不同（Cz46 的 VehicleBuff@63 vs karelia2 的 @61）→ **idx = 该车挂载组件集的顺序编号**（非全局表）——挂载集与挂载序推断为下一轮（Task 35）主攻。
- **前导模式**：扩展区开头恒为 4-7 对 `[u8 idx][u8 00]`（默认值组件条目，489 车为 6 对）；idx 跨车高频聚集 204-207（公共尾部组件段）。
- **中段模式**：轮式车出现 `07 XX 08 YY 8c 01 02` 6-7B ×N 重复条目（BV111 8×8 轮式 4 条）；`15 XX 03 YY 91 02 05` 同构——逐节点状态条目族。
- **尾部骨架**（锚点熵剖析 tail_align.py，586 车对齐）：`[...-11..-5: 7×00 恒定][-10..-4: 高熵值区][21 00][22 00][28 01 vpp?][30 02][中段变化][+23: 00 恒][...][2c 01][00 00 00][f32: 4976/4884/2624 锚][09][42/48][00×4-9][01]`——f32 高 3 字节 `XX XX 43/45` 为强锚（0x439e8000=4976.0 / 0x459a8800=4884.0 / 0x45111000=2624.0）。

### 15.6 csi 表 v8 修正清单（digest 主线影响）
| 属性 | 表 v8 | 网络实测 | 判定 |
|---|---|---|---|
| csi 0-30 定长组 | ✓ | 0x07 key 全吻合 | 不变 |
| 31 steeringAngles / 32 wheelsScroll / 33 perkEffects / 34 perks | ✓ | 0x05/0x07 双证 | 不变 |
| 35-39 ribbon/postmortem/publicInfo/stickers/stateMod | ✓（38 有 0x07 key=1 次实证） | 无移位 | 不变 |
| **40 vehPostProgression** | 45 | **40（754 车铁证）** | **修正** |
| 41 healing / 42 healOverTime / 43 dogTag | 47/48/49 | 推断（重排模型） | 待 0x07/更多锚 |
| 44-49 | crew/enh/setups/setupIdx/vehPerks/disabled | MY_VEHICLE 区 | 本车专属 |
- **digest 计算不受影响**（digest 遍历 properties_ 全集按声明序，与网络 idx 重排无关）——但 **defparse 需双表输出**（digest 表 + 网络 idx 表）支撑后续解码工具。
- **csi_tables_v8.json 的使用警告**：其 csi 列为「digest/全属性视角」，0x05 解码需用「网络重排视角」（§15.4 模型）。

### 15.7 本轮工具与产物（scripts/ 新增 12 件）
- `ext_probe.py`（扩展区原始 dump 侦察）
- `ext_dump.py`（单流完整 hex dump）
- `base_dump.py`（基础段字节对照）
- `ext_cluster.py`（★1,092 车扩展区聚类 + 前导 idx 直方图 + 同型骨架 diff → /tmp/wot/ext_cluster.json）
- `veh_types.py`（Vehicle 全属性类型树 dump）
- `compdef_dump.py` / `comp_global.py` / `comp_table.py`（组件 def 解析三级迭代 → 全局组件属性表）
- `csi_anchor.py`（★vpp 字节锚定位 → idx=40 铁证）
- `csi_solve.py`（联合回溯求解器 v1）
- `tail_align.py`（★锚点熵剖析 586 车）
- `other_entities.py`（四实体 0x05 干净样本验证）
- `verify_v19.py`（综合验证六项固化）

### 附录 K：v19 证据坐标（属性流终局轮）
- vpp idx=40：csi_anchor.py 输出「命中 754 / 未中 0」；ext_cluster.json 每车 ext hex
- NetworkEntity 三例：other_entities.py 输出（eid 545320419/545320418/545508173）
- jsonl t=5 tail：/tmp/wot/rjsonl/replay.jsonl（AreaDestructibles tail=040000010002000300）
- MY_VEHICLE 10 属性：wot_scripts/scripts/entity_defs/Vehicle.def DetailLevel 标签（bwxml 解码）
- alias AllowNone 97/202：wot_scripts/scripts/entity_defs/alias.xml（verify_v19.py 输出）
- 0x07 key 全表：/tmp/wot/p07_csi_scan.json（11 场汇总 max=38）
- 客户端解析白盒：decomp c_1402c13f0.c FUN_140395c60/164150 区（py_entity.cpp:0xbb）+ c_1428d1e40.c FUN_142a92db0/142a93050/142a8e490
- vanilla 线编码：bigworld/lib/cstdmf/binary_stream.hpp:287（packedInt）+ entitydef/data_types/{sequence,string,python,fixed_dict}_data_type.cpp + entitydef/entity_description.cpp:831（排序比较器）+ server/cellapp/{witness,entity_cache}.cpp（发送侧）
- 组件注册表：wot_scripts/scripts/components.xml（Static16+Dynamic113）+ component_defs/*.def（128 文件）
- 尾部熵剖析：tail_align.py 输出（-44..+47 偏移熵表）
- 同型模板恒定：ext_cluster.py 输出（184 组 62 组全同，A38_T92 18 辆 73B 全同）

## 16. [v20 · 2026-09-25] 0x05 全通道语义解码终局 —— 推翻扩展区理论 + RULE X 网络表 + 全实体 100% 精确解码 —— Task 35 决定性轮

> 本轮输入：用户指令「继续」推进 Task 35 六项残留。本轮产出：**0x05 通道 11 场 × 7 实体类型 6,899/6,899 字节级 100% 精确语义解码**，并推翻 v18/v19 两项核心误判。

### 16.1 ★★推翻 §14.5「CSI≥50 扩展区 = 动态组件通道」——0x05 根本没有组件段
- **伪影根源**：v18 walk_base 把 publicInfo（FD 14 字段，含 name/compDescr/outfit 三个变长 STRING）的**值字节**误读为后续 [idx][value] 条目，walk 在值中间崩溃后把剩余字节统称「扩展区」。所谓「idx 52-248」「同型车模板恒定性 62/184 组」「Tier XI 字节签名（extlen 中位 117 vs 93）」「轮式车 07 XX 08 YY 8c 01 02 条目族」**全部是 publicInfo.compDescr/outfit（载具描述符/涂装配置二进制串）与 dogTag 值的内容伪影**。
- **铁证**：正确解码后 1,124 个 Vehicle 创建流（含 v19 遗漏的 tundra 场）+ 5,679 AreaDestructibles + 63 NetworkEntity + 11 TeamInfo + 11 AvatarInfo + 10 DetachedTurret + 1 DebugDrawEntity = **6,899/6,899 propBytes 字节级精确吃满、零错误、零剩余**——不存在任何组件属性段。
- **连带修正**：v19 §15.5 的「idx=该车挂载组件集的顺序编号」假设作废；§15.4 的「MY_VEHICLE 变长剔除重排」机制作废（正确机制见 §16.2）；「f32 锚 4976/4884/2624」= dogTag 组件 progress 值；「09 42/48 尾部模式」= dogTag defaultDogTag 组件 id 低字节（0x42/0x48=66/72）。
- **组件属性的真正通道**：0x05 不发。候选 = 0x24 通道（键 = (N<<8)|flag 结构，N∈{3..20}，其中 N=17/18 全部命中车辆 eid、N=4/5/6/7 全部非车辆 eid——多实体类型共用通道，N 疑似逐类型属性族编号；body 含 -1.0 哨兵 f32 与战斗时钟 f32）——**Task 36 主攻**。

### 16.2 ★★RULE X 网络 idx 表（本轮核心成果）
- **定长组 0-30 = v8 表原样**（streamSize 升序稳定排序）——三项独立实证：idx5=isCrewActive（1092/1092 恒值 1，roster customRoleSlotTypeId 分布 0/3/5 排除备选）、idx4=siegeState（156 次， siege 模式切换）、idx6=customRoleSlotTypeId（373 次，值与 roster 吻合）。
- **变长组 31-49 = RULE X（实测定案）**：
  | 区间 | 属性 | 证据强度 |
  |---|---|---|
  | 31-40 | postmortemViewPointName, **publicInfo**, **damageStickers**, **publicStateModifiers**, crewCompactDescrs(MY), enhancements(MY), setups(MY), setupsIndexes(MY), vehPerks(MY), **vehPostProgression** | publicInfo/damageStickers/publicStateModifiers/vpp 四锚全验证 |
  | 41-44 | steeringAngles, wheelsScroll, perkEffects(MY), perks(MY) | 无观测（MY 或创建时空值），推断位 |
  | 45-48 | disabledSwitches(MY), healing, healOverTime, **dogTag** | dogTag@48 结构级验证 |
  | 49 | perksRibbonNotify(MY) | 无观测，推断位 |
- **验证矩阵（全满分）**：walk 1124/1124、eid-join 1092/1092（10 场 roster 对齐；tundra 场 roster 键制同）、publicInfo.name==fakeName **1092/1092**（WoT 匿名化机制：线上名 = fakeName，缺省=name；v19 的 6 例 name 不匹配即匿名玩家）、maxHealth 1092/1092、stFrags 1092/1092、team 1092/1092、vpp 754/754、字节精确吃满 1124/1124。
- **dogTag@48 判定性证据**：BATTLE_DOG_TAG = FD{dogTag{components ARRAY<FD{id i4, progress f4, grade u8}>}, defaultDogTag{同构}, showDogTagToKiller u8}——观测值 `30 02 [e1 9B][e2 9B] 02 [e3 9B][e4 9B] 01` 双数组+尾 u8 结构逐场吻合（样例：dogTag=[{640,594.0,0},{639,594.0,0}], default=[{300,0,9},{66,0,0}], show=1）；perks(PERK_INFO_HUD 17B 元素)与 perksRibbonNotify(12B 元素)均与 9B 观测元素不符，唯一吻合。
- **0x07 与 0x05 同表**：key23=stunInfo（FLOAT8 时间戳+0.0 清零，137 次 body 全验）、key34=publicStateModifiers（body `00`/`01 43`——n=1 元素 0x43 的 ARRAY<INT1> 形态，排除 perks 的 17B 元素）、key38=setups（body = `\x80\x02` pickle protocol2 头 + (1,1,2,0) 元组——PYTHON 类型专属铁证）。v19 §15.4「0x07=全属性版(v8)」的变长区判读随之修正（33/34/38 实为 damageStickers/publicStateModifiers/setups 而非 perkEffects/perks/damageStickers）。
- **排序机制残留之谜**：vanilla 比较器（entity_description.cpp:841）+ fork 排序函数（FUN_142a8dff0：N<33 插入排序稳定 / N≥33 归并，比较器与 vanilla 逐分支一致）+ 变长 streamSize = -VariableLengthHeaderSize（FUN_142a89f90 双虚调用，defparse Property.stream_size 同构）——但 wot_scripts 副本中全部 vlh=1（且实体 def 无 VariableLengthHeaderSize 声明），无法从现有材料推出接口变长属性后置+dogTag@48 的确切 vlh 赋值；结合 §16.4 的运行时 def 漂移证据，**最可能解释 = 服务器端 def 与 wot_scripts 副本存在内容差异（vlh/属性集）**。

### 16.3 ★eid == roster.avatarSessionId + 0x05 全格式终版
- **join 键修正**：v18 §14.4「csi16 avatarID=avatarSessionID」实为 0x05 载荷首字段 eid 的子串命中（avatarID 属性值是另一族 id，caucasus 场观测 avatarID=eid+27/+57 的 Avatar 实体 id）。**正确 join：eid == roster.avatarSessionID**，1092/1092 全命中。
- **0x05 终版格式**：`[u32 eid][u32 typeID][10B fork 头][pos 3×f32][ypr 3×f32][u32 propBytes][u8 count][count × ([u8 idx][typed value])]`——属性区**单段平铺**，条目序=事件序（乱序合法、重复合法——观测 engineMode 前置、gunAnglesPacked 乱插）。
- **typeID 表修正**：28 ≠ wot_scripts TeamInfo（实测 4 CS 属性 {INT4,STR,STR,STR} vs 副本 1 属性）——见 §16.4；12 = DetachedTurret（5 CS 属性，karelia 场 compDescr[21B]+outfitCD[56B] 精确吻合）；13 = DebugDrawEntity。

### 16.4 ★运行时 def ≠ wot_scripts 副本（digest 主线新变量）
- TeamInfo 铁证：0x05 typeID 28 流 = (0, u32 teamID 1/2)(1/2/3, 同值 6B 串×3)——wot_scripts TeamInfo.def 仅 teamID 一个 CS 属性，**运行时 def 多 3 个属性**。
- 推论：digest 偏差（defparse EBE966BE… vs 实测 5DF886F7…）的归因需要修正——v16「偏差锁定 18 个扩展 def 记录」不完整，**wot_scripts 副本与服务器 def 的内容漂移（TeamInfo +3 属性为实证，Vehicle vlh 疑似）也是偏差源**。digest 主线（Task 36+）需按此重估。

### 16.5 35-d 闭环：alias AllowNone 对 digest 无漏读
- vanilla FixedDictDataType::addToMD5（fixed_dict_data_type.cpp:917）喂入 `md5.append(&allowNone_, sizeof(allowNone_))`（1 字节 bool）；defparse FIXED_DICT add_to_md5 已有 `append_uint8(allow_none)` 同构实现——**v19 §15.2 的「alias 级 AllowNone 漏读」担忧排除**（defparse 读到且喂到；97/202 的价值在 None 线编码标记，本轮 healing/healOT 解码已实际使用）。

### 16.6 本轮工具与产物（scripts/ 新增 8 件）
- `p05_fulldump.py`（全载荷 hex dump 侦察）
- `p05_entity_scan.py`（指定 typeID 全流 dump——NetworkEntity 63 例 idx 集合 {0,1,3} 判定）
- `vdef_dump.py`（Vehicle.def 全属性/DetailLevel/接口树 dump）
- `net05_table.py`（★RULE X 表 + 全量验证器——四重 roster 验证矩阵）
- `p05_idx_hist.py`（count 段 idx 直方图——MY 区零观测判定）
- `p07_keybody.py`（0x07 指定 key body 采集——stunInfo/ARRAY<INT1>/pickle 三判别）
- `p05_decoder.py`（★终局解码器：11 场 × 7 实体类型 6,899/6,899 精确）
- 产物：`/tmp/wot/net05_table_v20.json`（网络表）+ `/tmp/wot/p05_decoded.json`（6899 条全量解码）+ 紧凑版

### 附录 L：v20 证据坐标（0x05 终局轮）
- 全量验证矩阵：net05_table.py 输出（1124 walk / 1092 join / 1092 name(fake) / 1092 maxHealth / 1092 stFrags / 1092 team / 754 vpp / 1124 exact 全满分）
- dogTag 结构：p05_decoder.py w_dogtag（样例 eid 550629025: [{640,487.0,0},{639,487.0,0}]+[{300,0,9},{66,0,0}]+show）
- fakeName 匿名化：siegfried eid 550629014（publicInfo.name=hoangbiao_2015 vs roster.name=DarknessHunterKIller, roster.fakeName=hoangbiao_2015）
- 0x07 同表三判别：p07_keybody.py key23/34/38 输出
- 排序函数白盒：c_1428d1e40.c FUN_142a8dff0（排序+baseIndex 赋值）/ FUN_142a8c240（插入排序比较器=vanilla）/ FUN_142a89f90（DataDescription::streamSize 变长=-vlh）/ 360489 区（parseProperties cs_props push + clientServerFullIndex=size+baseIndex）
- TeamInfo 漂移：p05_entity_scan.py 28 输出（siegfried/karelia/lakeville 三场同构 (0,u32)(1/2/3,STR6)）
- DetachedTurret：p05_entity_scan.py 12 输出（karelia compDescr[21]+outfitCD[56]=propBytes 89 精确）
- 0x24 通道候选：0x24 key 直方图（N∈{3,4,5,6,7,14,15,17,18,19,20}，N=17/18 全车辆 eid / N=4/5/6/7 全非车辆 eid）
- vanilla FD allowNone 入 digest：bigworld …/entitydef/data_types/fixed_dict_data_type.cpp:917-932

## 17. [v21 · 2026-09-25] 0x24 通道全协议白盒 —— 嵌套/切片属性更新 · Task 36 决定性轮

### 17.1 包头结构（写入器级白盒，5,241/5,241 全验证）
- **写入器**：decomp `FUN_140587300` = `BW::WGReplayMessageHandler::getFile`（wg_replay_message_handler.cpp:1570，源码路径由函数内 MF_ASSERT 字符串直接给出）。
- 线格式：`[eid u32][isSlice u8][len u32][payload × len]`，len 恰好吃满包尾（11 场 5,241/5,241 零失配）。
- **语义归属**：`getFile(eid, MemoryIStream, isSlice)` 是客户端 `ServerMessageHandler::onNestedEntityProperty(id, data, isSlice)` 的 WoT 录制钩子。vanilla 双消息对（connection/client_interface.hpp + server_connection.cpp:1058-1072）：
  - `nestedEntityProperty`（VARLEN）→ `onNestedEntityProperty(selectedEntityID_, stream, false)`
  - `sliceEntityProperty`（VARLEN）→ `onNestedEntityProperty(selectedEntityID_, stream, true)`
  - 两者均依赖 select*Entity 前置消息携带目标 eid（csi_tables 说明中「selectEntity 目标实体」口径的来源）。
- 历史勘误：v6 报告「0x24=火炮瞄准/装填参数（0xBA/0xBC 属性）」推断**推翻**——`ba 01` 开头实为压缩路径位流 `[1][csi=29 ownVehiclePosition]` 的字节形态，非属性号。

### 17.2 payload 压缩路径位流（vanilla 逐行对照）
- 消费端：`TopLevelPropertyOwner::setNestedPropertyFromExternalStream` → `PropertyChangeReader::readCompressedPathAndApply`（entitydef/property_change_reader.cpp:83-132）。
- 写入端：`PropertyChange::addCompressedPathToStream`（property_change.cpp:69-102）。
- 位流格式（MSB-first，cstdmf/bit_reader.cpp 逐位移植验证）：
  1. `while [1 bit=1]`：下钻一层，读 `bitsRequired(numProps)` bits 子索引；**首层 numProps=numClientServerProperties、首 index=csi**（写入端 L78-80 明确 `bitsRequired(numClientServerProperties), clientServerID`）——0x24 与 0x07 同 csi 表（§1 结论在本通道同样成立）。
  2. `[1 bit=0]` 停止（此时 pOwner=叶子属性值的 PropertyOwner）。
  3. isSlice=0（Single）：`leafIndex = bitsRequired(ownerN)` bits；isSlice=1（Slice）：`start/end` 各 `bitsRequired(ownerN+1)` bits。
  4. 值段从下一**整字节**边界开始（BitReader retrieve 整字节不退还）。
- **csi 首层命中**（Vehicle numCS=50→6bits；AreaDestructibles numCS=4→2bits）：33=perkEffects、29=ownVehiclePosition、34=perks、30=inspired、1=destroyedFragiles、3=fallenTrees、2=fallenColumns、0=destroyedModules——全部为 ARRAY/FIXED_DICT 嵌套类型属性，与 slice/nested 更新用途完全自洽。

### 17.3 全量统计（11 场 × 5,241 包，p24_final.json）
| 类型 | 属性 | isSlice | n | 值长观测 |
|---|---|---|---|---|
| AreaDestructibles | destroyedFragiles | 1 | 2,173 | 2-3B |
| Vehicle | perkEffects | 1/0 | 982+515 | 14-16B |
| AreaDestructibles | fallenTrees | 1 | 573 | 4-5B（对上 0x05 的 TUPLE5 元素宽） |
| Vehicle | ownVehiclePosition | 0/1 | 459+37 | 16-18B |
| Vehicle | perks | 1 | 170 | 0B×159 / 1B×9 |
| Vehicle | inspired | 0/1 | 133+35 | 11-13B |
| AreaDestructibles | fallenColumns | 1 | 90 | 2-3B |
| AreaDestructibles | destroyedModules | 1 | 74 | 2-3B |

### 17.4 值段格式观测（待 Task 37 字段级细化）
- **AllowNone 头**：FIXED_DICT(AllowNone=true) 值段首字节 `[u8 hasValues]`（0=None）——0x07 csi=30 body='00'（inspired 置 None）与 vanilla FixedDictStartStreamElement::fromStreamToSink（fixed_dict_data_type.cpp:108-128）双向实证。
- **perks 删除语义**：slice(0,2)+0B 值 ×159（w=2 → 数组当前长度 2）= setOwnedSlice 空数据删除区间元素。
- **ownVehiclePosition 17B 值**：`[u16 场内恒定(502/403/407/204/104，场间不同)][u16 0][u8 {0,1}][f32 -1.0 恒定哨兵][f32 尾数模式 0xcc/0x33/0x66 族][f64 大数(11.3万~14.1万，疑服务器时钟或压缩坐标)]`——场内恒定 u16 与 f64 的语义归属为 Task 37 主攻点（候选：streamID / 打包格式前缀 / 半精度坐标）。
- **inspired 13B 值**：`[u16 场常量][u16 0][f64 大数]`（与 BUFF_EFFECT_INACTIVATION startTime 结构候选吻合）。
- **perkEffects 15/16B 值**：`[3-4B 零头][0c/07/0d/10 XX 双字节模式][f32/f64 数据]`，与 PERK_EFFECTS{equipment:ARRAY<STRING>} 的元素序列化待对齐。
- 20B 包 vs 19B 包：位头多一层字段下钻（fieldIdx 层，w=3 → 运行时 FIXED_DICT 字段数 5-8，与 Task 35「运行时 def 漂移」互相印证）。

### 17.5 环境与材料（第 4 次重置恢复记录）
- 回退范围：/tmp 全丢 + scripts/download/根 worklog/findings 清空 + 门户下线；upload/ 全部幸存。
- dec.7z 定案：分卷合并 md5=3bf3f80d97fc7bc8920306f35475492a，AES 密码验证通过，内层仅 1 条目=decomp.zip（md5 48683ebc708a9241b6e5be41c9a00d3f，与 upload/decomp.zip 逐字节一致）——**dec.7z 即 decomp.zip 的加密容器，无增量信息**。
- BigWorld 源码就位：tar.gz 440MB 经 wildcards 选择性解压（network/entitydef/entitydef_script/connection/bwentity/cstdmf 六子树，54 秒）；全量解压因 overlayfs 小文件创建慢（62ms/文件）不经济。
- wot_src：py7zr targets 模式 7.3 秒精准解压 19 个关键文件（BattleReplay/Vehicle/OwnVehicle/ValueReplay 等）；全量后台进行中。
- ext_pkg：GitHub FengY233/test 重拉 wot24_ext_defs.zip（528 条目/18 扩展/220 def，与历史记录一致）。

### 17.6 Task 37 交接（开放项）
1. ownVehiclePosition/perkEffects/inspired 值段字段级语义（场常量 u16、f64 大数归属、0c/07/0d 模式）——候选路径：decomp 搜 setOwnedSlice 的 WoT fork 实现（PyFixedDictPropertyOwner vtable）+ 服务器 .pyc 反编译（equipment_ctrl.pyc 已见 perkEffects 引用）。
2. AreaDestructibles 值段（2-3B 碎片状态）与 122 可破坏物实体 join。
3. 0x24 与 0x39（NetworkReplicationPointComponent 复制流）的通道分工。
4. 161 个 nested 深层包（多层下钻）的完整路径解析（需运行时数组长度状态机）。

## 18. [v22 · 2026-09-25] 0x24 终局重解 —— 位宽漂移状态机 + RULE X 通道真身 + 100% 精确解码 —— Task 37 决定性轮

### 18.1 v21 勘误（本轮推翻的三项）
1. **固定 6+6bit slice 位宽假设作废**：v21 假设 slice start/end 恒 6+6bit（ownerN=50）→ 全部 Vehicle 值起点错位 1-2 字节，「u16 场常量/f32 尾数/f64 大数」的分层是对错位字节的伪模式拟合。
2. **「perkEffects(csi33)/perks(csi34)/ownVehiclePosition(csi29)=v8 csi 表」通道身份作废**：v8 csi 表 31-49 段与 v20 RULE X 表不一致（43=perkEffects 非 33）。真身（RULE X）：**33=damageStickers、34=publicStateModifiers**——均为 ARRAY，slice 合法性自洽。csi 0-30 段两表一致。
3. **「161 个 nested 深层包」定性作废**：实为 csi=34 perks×错位的 2B 小包（v21 解码器在错误位宽下 val 提取失败的伪影）。

### 18.2 终局模型（vanilla 位语义 + 数组长度状态机）
- 消息层：`[eid u32][isSlice u8][len u32][body]`（不变）。
- **body = 位路径 + 值**：`[1][csi: bitsRequired(numCS)]`（首层= RULE X 网络索引；Vehicle 50→6bit，AreaDestructibles 4→2bit）→ 下钻层（本数据集全无）→ `[0]` 停 → Single: `[idx: bitsRequirement(arrlen)]` / Slice: `[s][e] 各 bitsRequirement(arrlen+1)` → 值从下一整字节边界起（BitReader 整字节消费，vanilla cstdmf/bit_reader.cpp 逐位复核）。
- **★位宽随数组当前长度漂移**：len=0→0bit，1→1bit，2-3→2bit，4-7→3bit，8-15→4bit…… fallenTrees 序列 0→1→2→3bit 三连跳与包长 6→7B 精确对应（karelia eid 3116316 五连包铁证）。
- **★0x05 重创建重置**：同 eid 多个 0x05（AoI 重入，175 次/11 场）→ 数组状态回滚到该次 0x05 初始值（damageStickers 重创建后 4→0 铁证，karelia eid 550629016 双 0x05）。
- **slice 语义**：`newLen = s + nnew + (oldLen - e)`，s≤e≤oldLen（insert: s=e；replace: s<e；delete: 值 0B）。Single = 原位替换第 idx 元素。
- **验证：5,241/5,241 = 100%，11 场零违例**（scripts/t37_sm2.py + t37_sm3.py + p24_decode_v2.py 三重独立实现）。

### 18.3 通道真身与元素结构（全量观测）
| 实体 | csi | 属性 | 元素 | 结构 |
|---|---|---|---|---|
| Vehicle | 29 | ownVehiclePosition | 18B | `[u8 hasValues][u16 A][u16 B][u8 C][f32 D][f64 time]` AllowNone |
| Vehicle | 30 | inspired | 13B | `[u8 hasValues][u16 A][u16 B][f64 time]` AllowNone |
| Vehicle | 33 | damageStickers | 16B | `{networkID i32, segment i64, params i32}`（0x05 锚：params 族 33887267/50664514 与 0x24 值差 ±1-2 连续） |
| Vehicle | 34 | publicStateModifiers | 1B | `u8`（0x05 锚：[66,169] 族） |
| AreaDestructibles | 0-3 | destroyedModules/destroyedFragiles/fallenColumns/fallenTrees | 3/3/3/5B | TUPLE<u8×n>（insert-only 增长） |

### 18.4 字段统计与开放语义（csi=29 ownVehiclePosition）
- **A(u16@1)**：范围 [101,502]，分布 {407:139, 204:97, 104:86, 102:61, 502:32, 403:30, 405:28, 306:17}——有界 <512，场内多值。候选：量化坐标/角度/压缩位置分量（与 0x0A volatile 位置流对齐可终判）。
- **B(u16@3)**：496/496 恒 0。
- **C(u8@5)**：{0:288, 1:208} 布尔。
- **D(f32@6)**：{-1.0:400, 15.0:93, ~14420:3}——双峰。
- **E(f64@10)**：每场独立递增时钟（siegfried 140968.5 / karelia 113990.6 / lakeville 283672.5 / caucasus_NA 22555.5 / namerica 132635.3 / caucasus_CN 141706.3 / greatwall 6184.3 / karelia2 14436.5 / PTZ 145317.7 / WZ219 48910.0）——服务器/空间时钟假设。
- inspired(csi30) 元素 {A, B, time} 同族（BUFF_EFFECT_INACTIVATION 时间结构候选）。
- **def 漂移线索**：元素结构与客户端 def 的 OWN_VEHICLE_POSITION{VECTOR3,VECTOR3,F32,F32}/INSPIRED_EFFECT{BOOL,F64×4,BOOL,U16} 不符——服务器侧类型/或 fork 客户端 owner=插值历史缓冲（asOwner 返回包装对象）二选一，digest 已证客户端 def 类型无误（类型流喂入且复现），故倾向 fork 历史缓冲包装（Task 38 候选：decomp 定位 ownVehiclePosition 的 asOwner/包装类）。

### 18.5 方法论沉淀（可复用）
1. **位宽状态机**：0x24 解码必须维护每 (eid, 0x05代, csi) 的数组长度状态，位宽=当前长度的函数——离线解码器与客户端实时行为逐位等价。
2. **0x05 重创建回滚**：eid 复用（AoI 重入）时 0x05 会重发全量属性，数组状态必须回滚——否则后续全部错位（本轮 BAD 从 424→0 的两步修正之一）。
3. **通道身份锚定优先级**：0x05 初始值 join（强锚）> 0x07 None 特征（弱锚）> csi 表推导（需 RULE X 校正）。
4. **BWXML BLOB 陷阱**：def 中 3 字节 TYPE_BLOB 值 = Base64 编码的字符串（'Harm'=b64(\x1d\xaa\xe6)、'BASE'=b64(\x04\x04\x84)、'BOOL'=b64(\x04\xe3\x8b)）——vehicle Implements #6 = Harm 接口（0 属性，仅 7 CellMethods，decl 序不受影响）。

### 18.6 本轮工件
- `scripts/t37_alias2.py`（alias 类型树深钻）/ `t37_hand2.py`+`t37_bits.py`（位级手工注解）/ `t37_7bit.py`（7bit 反证）/ `t37_sm.py`/`t37_sm2.py`/`t37_sm3.py`（状态机三迭代）/ `t37_decl.py`（76 属性声明序表重建）
- **`scripts/p24_decode_v2.py`（终态解码器，5,241/5,241）** → `/tmp/wot/p24_final_v2.json`（全量结构化元素）
- `/tmp/wot/veh_decl_table.json`（Vehicle 76 属性声明序）
- decomp 新锚点：FUN_142a7bfa0→FUN_142a8e570（EntityPropertyOwner::getNumOwnedProperties=desc+0xfc）、FUN_142a93050（属性索引=组件回退查找：主向量+0x2f0 组件向量+0xf8 基址）、FUN_142a7bbb0（SimpleClientEntity::EntityPropertyOwner 构造）、FUN_142a7bde0（getChildPropertyOwner=GetAttrString+DataType vtable+0x70=asOwner）
- vanilla 新锚点：entity_description.cpp parseProperties/allocateClientServerFullIndexes（RULE X 排序机制源码级确认：定长升序在前+变长按 vlh 升序+稳定排序）、property_owner.hpp（基类 setOwnedSlice 默认空实现）

### 18.7 Task 38 交接（更新后开放项）
1. csi29/30 字段语义终判：A/B/C/D 与 0x0A volatile 位置流同时钟对齐（同 clk 包的位置比对）；fork 历史缓冲假设的 decomp 验证（ownVehiclePosition 的 asOwner 包装类）。
2. 0x24 下钻层（[1][idx] 深层路径）样本采集：本数据集 11 场全无下钻包——需大逃杀/前线等扩展模式回放。
3. 0x05 重创建的完整语义（175 次/11 场的触发条件：AoI 重入 vs 其他）。
4. digest 侧影响：dyncomp 记录真值锚（Task 36② 延续）。
