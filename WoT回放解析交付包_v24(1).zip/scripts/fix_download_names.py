# -*- coding: utf-8 -*-
"""fix_download_names.py — 修复 cp437→UTF-8 文件名乱码（V16 zip 解包产物）"""
import os

DL = '/home/z/my-project/download'
fixed = 0
for name in os.listdir(DL):
    try:
        good = name.encode('cp437').decode('utf-8')
    except (UnicodeEncodeError, UnicodeDecodeError):
        continue
    if good != name:
        src, dst = os.path.join(DL, name), os.path.join(DL, good)
        if not os.path.exists(dst):
            os.rename(src, dst)
            fixed += 1
            print(f'  {name[:28]:30s} → {good}')
# data 子目录里的文件（如有）
for sub in ('data_v17', 'data_v18', 'data_v19', 'data_v20', 'charts'):
    d = os.path.join(DL, sub)
    if not os.path.isdir(d):
        continue
    for name in os.listdir(d):
        try:
            good = name.encode('cp437').decode('utf-8')
        except (UnicodeEncodeError, UnicodeDecodeError):
            continue
        if good != name and not os.path.exists(os.path.join(d, good)):
            os.rename(os.path.join(d, name), os.path.join(d, good))
            fixed += 1
print(f'共修复 {fixed} 个文件名')
print('\n当前 download/ 清单:')
for name in sorted(os.listdir(DL)):
    p = os.path.join(DL, name)
    sz = os.path.getsize(p) if os.path.isfile(p) else sum(
        os.path.getsize(os.path.join(dp, f)) for dp, _, fs in os.walk(p) for f in fs)
    print(f'  {"DIR " if os.path.isdir(p) else "    "}{name}  ({sz/1048576:.2f} MB)')
