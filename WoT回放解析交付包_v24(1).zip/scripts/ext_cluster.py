#!/usr/bin/env python3
"""ext_cluster.py — Task34: 扩展区结构聚类分析
1) 同车型多车扩展区 diff (找恒定 idx 骨架)
2) 全场收集「前导 1B 值条目」idx 分布
3) 与 roster join 找 vpp 差分
"""
import json, struct, zlib
from collections import Counter, defaultdict
from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])

REPLAYS = [
    ("siegfried_EU_935", "/tmp/wot/github_test/20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay"),
    ("karelia_EU_935", "/tmp/wot/github_test/20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay"),
    ("lakeville_EU_935", "/tmp/wot/github_test/20260907_1321_germany-G197_Pz_Kpfw_Neu_07_lakeville.wotreplay"),
    ("caucasus_NA_945", "/tmp/wot/github_test/20260910_1057_china-Ch67_BZ_79_37_caucasus.wotreplay"),
    ("namerica_CN_942", "/tmp/wot/github_test/20260911_1534_ussr-R52_Object_261_44_north_america.wotreplay"),
    ("caucasus_CN_942", "/tmp/wot/github_test/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay"),
    ("greatwall_EU_944", "/tmp/wot/github_test/20260912_1036_france-F143_Fauteur_59_asia_great_wall.wotreplay"),
    ("karelia2_EU_944", "/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay"),
    ("PTZ_EU_944", "/tmp/wot/github_test/PTZ_10K.wotreplay"),
    ("WZ219_EU_944", "/tmp/wot/github_test/WZ-219.wotreplay"),
]

CSI = {}
d = json.load(open('/home/z/my-project/download/csi_tables_v8.json'))
for p in d['entities']['Vehicle']['properties']:
    CSI[p['csi']] = (p['name'], p['streamSize'])


def load_pkts(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from('<I', data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b'\x00' * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        dd = cipher.decrypt(main[i:i + 8])
        dd = bytes(a ^ b for a, b in zip(dd, prev))
        prev = dd
        out += dd
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from('<III', stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


def get_b0(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos = 8
    (blen,) = struct.unpack_from('<I', data, pos)
    return json.loads(data[pos + 4:pos + 4 + blen])


def walk_base(pl):
    """基础段: 变长 TUPLE<UINT8> = [u8 n][n B]; 定长直出; STRING=[u8 len][data]"""
    propBytes, = struct.unpack_from('<I', pl, 42)
    if 46 + propBytes != len(pl):
        return None, 'propBytes'
    q = 46
    count = pl[q]; q += 1
    ents = []
    nfixed = 0
    for i in range(count):
        if q >= len(pl):
            return None, 'overrun'
        idx = pl[q]
        if idx >= 50:
            break
        q += 1
        if idx not in CSI:
            return None, f'badidx{idx}'
        name, ss = CSI[idx]
        # TUPLE<UINT8> (steeringAngles/wheelsScroll/crewCompactDescrs?) = [u8 n][n*1B]
        # 定长 = 直出; STRING/ARRAY = [u8 len][data]; FIXED_DICT 定长直出(不含STRING字段时)
        if name in ('steeringAngles', 'wheelsScroll'):
            if q >= len(pl):
                return None, 'vlover'
            n = pl[q]
            q += 1 + n
            ents.append((idx, f'tuple{n}'))
        elif ss > 0:
            q += ss
            ents.append((idx, 'fx'))
        else:
            if q >= len(pl):
                return None, 'vlover'
            n = pl[q]
            q += 1 + n
            ents.append((idx, f'vl{n}'))
        if q > len(pl):
            return None, 'over2'
    return (ents, q, count), None


def main():
    # 收集全部车辆
    all_rows = []
    for tag, path in REPLAYS:
        b0 = get_b0(path)
        roster = {}
        for dbid, v in (b0.get('vehicles') or {}).items():
            sid = v.get('avatarSessionID')
            if sid:
                roster[int(sid)] = v
        pkts = load_pkts(path)
        veh = [pl for ty, c, pl in pkts if ty == 5 and len(pl) >= 47
               and struct.unpack_from('<I', pl, 4)[0] == 6]
        for pl in veh:
            r, why = walk_base(pl)
            if r is None:
                continue
            ents, extoff, count = r
            hits = [aid for aid in roster if struct.pack('<I', aid) in pl]
            ent = roster[hits[0]] if len(hits) >= 1 else {}
            ext = pl[extoff:]
            all_rows.append({
                'tag': tag, 'eid': struct.unpack_from('<I', pl, 0)[0],
                'vtype': ent.get('vehicleType'), 'vpp': ent.get('vehPostProgression'),
                'count': count, 'base_n': len(ents),
                'base_idx': [i for i, _ in ents],
                'extlen': len(ext), 'ext': ext.hex(),
            })
    print(f'walk ok: {len(all_rows)} 车')
    json.dump(all_rows, open('/tmp/wot/ext_cluster.json', 'w'), ensure_ascii=False)

    # 1) 前导 1B 值条目假设: 收集 ext 开头 [u8 idx][u8 00] 对的 idx
    lead = Counter()
    npair_hist = Counter()
    for r in all_rows:
        ext = bytes.fromhex(r['ext'])
        np = 0
        q = 0
        while q + 1 < len(ext) and ext[q + 1] == 0x00 and np < 12:
            lead[ext[q]] += 1
            np += 1
            q += 2
        npair_hist[np] += 1
    print('\n== 前导 [idx][00] 对数分布 ==')
    for k in sorted(npair_hist):
        print(f'  {k} 对: {npair_hist[k]} 车')
    print('== 前导 idx 值 top30 ==')
    for k, v in lead.most_common(30):
        print(f'  idx={k:3d} (0x{k:02x}): {v}')

    # 2) 同车型聚类 diff
    bytype = defaultdict(list)
    for r in all_rows:
        bytype[(r['tag'], r['vtype'])].append(r)
    print('\n== 同场次同车型 ≥2 辆的组 (扩展区骨架 diff) ==')
    shown = 0
    for (tag, vt), rs in sorted(bytype.items(), key=lambda kv: -len(kv[1])):
        if len(rs) < 2 or not vt:
            continue
        exts = [bytes.fromhex(r['ext']) for r in rs]
        # 逐字节比较: 恒定位 vs 变化位
        m = min(len(e) for e in exts)
        skel = ''
        for i in range(m):
            col = {e[i] for e in exts}
            if len(col) == 1:
                skel += f'{col.pop():02x}'
            else:
                skel += '**'
        print(f'-- {tag} {vt} n={len(rs)} extlens={[len(e) for e in exts]}')
        print(f'   skeleton: {skel[:160]}')
        shown += 1
        if shown >= 12:
            break

    # 3) count 字段 vs base_n 关系
    cc = Counter()
    for r in all_rows:
        cc[(r['count'], r['base_n'])] += 1
    print('\n== (count, base_n) 分布 top15 ==')
    for (c, b), v in cc.most_common(15):
        print(f'  count={c} base_n={b}: {v} 车')


if __name__ == '__main__':
    main()
