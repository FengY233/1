#!/usr/bin/env python3
"""comp_global.py — Task34 核心: 构建全局组件属性表 (idx>=50) 并验证观测
模型: idx = 50 + Σ(前序组件 CS 属性数) + 组件内 csi (组件内也按 streamSize 排序)
组件顺序候选: components.xml 的 Static 后 Dynamic / Dynamic 后 Static / 仅 Dynamic
"""
import os, sys, json
sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file
from defparse import EntityDefParser

CDIR = '/tmp/wot_scripts/scripts/component_defs'


def build_component_table(order_mode):
    """解析组件 def, 返回 [(组件名, [属性列表(排序后)])] 按 order_mode 排序"""
    root = decode_file('/tmp/wot_scripts/scripts/components.xml')
    sc = [c.name for c in root.children[0].children]   # Static 16
    dc = [c.name for c in root.children[1].children]   # Dynamic 113

    if order_mode == 'static_first':
        order = sc + dc
    elif order_mode == 'dynamic_first':
        order = dc + sc
    else:
        order = dc

    table = []
    for comp in order:
        path = os.path.join(CDIR, comp + '.def')
        if not os.path.exists(path):
            table.append((comp, [], 'nofile'))
            continue
        try:
            sec = decode_file(path)
        except Exception as e:
            table.append((comp, [], f'err:{e}'))
            continue
        props = None
        for c in sec.children:
            if c.name == 'Properties':
                props = c
                break
        plist = []
        if props is not None:
            # 用 defparse 的 _parse_property 逻辑: 直接构建 mini parser
            for c in props.children:
                plist.append(c.name)  # 先收集名字; 类型后面再说
        table.append((comp, plist, 'ok'))
    return table


def main():
    for mode in ('static_first', 'dynamic_first', 'dynamic_only'):
        t = build_component_table(mode)
        ncs = sum(len(p) for _, p, _ in t)
        print(f'== {mode}: {len(t)} 组件, 属性总数(未过滤CS)={ncs}')
        # 累计分布: idx 起点
        base = 50
        marks = {}
        for comp, plist, st in t:
            marks[comp] = base
            base += len(plist)
        # 打印关键组件起点
        for k in ('OwnVehicle', 'VehicleInBattleSwitch', 'Fire', 'HealthComponent',
                  'VehicleBuff', 'GunReloadBoost', 'VehicleSkillCounter',
                  'WheeledDashController', 'NetworkReplicationPointComponent'):
            if k in marks:
                print(f'   {k}: base={marks[k]}')
        print(f'   总 idx 上限 = {base}')
        print()


if __name__ == '__main__':
    main()
