#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
p24_final.py — Task36① 终局: 0x24 通道全量结构解码器（11 场 × 5241 包）
== 协议白盒成果（本轮 decomp+vanilla+数据三方实证）==
写入器: FUN_140587300 = WGReplayMessageHandler::getFile (wg_replay_message_handler.cpp:1570)
  [eid u32][isSlice u8][len u32][payload × len]   ← len 恰好吃满(5241/5241)
语义: onNestedEntityProperty(id, data, isSlice)
  = vanilla ServerConnection::nestedEntityProperty(slice=0)/sliceEntityProperty(slice=1)
payload = BigWorld 压缩路径位流(MSB-first):
  [1 bit 下潜][csi: bitsRequired(numCS) bits]([1][childIdx: bitsRequired(childN)][..])*[0]
  isSlice=0: [leafIdx: w bits]    w=bitsRequired(ownerN)
  isSlice=1: [start: w][end: w]   w=bitsRequired(ownerN+1)
  值段: 下一整字节起
csi 命中(Vehicle 6bits): 33 perkEffects×1497 / 29 ownVehiclePosition×496 /
  34 perks×170 / 30 inspired×168; AreaDestructibles(2bits): 1 destroyedFragiles×2173 /
  3 fallenTrees×573 / 2 fallenColumns×90 / 0 destroyedModules×74
值段观测: AllowNone FIXED_DICT 带 [u8 hasValues](0x07 csi=30 实证 body='00');
  csi=29 17B: [u16 场常量][u16 0][u8 {0,1}][f32 -1.0][f32 frac][f64 大数]
  csi=30 13B: [u16 场常量][u16 0][f64 大数(~11万, 疑服务器时钟/压缩坐标)]
  perks slice(0,2)+0B ×159 = 数组清空(删除语义)
"""
import json
import struct
import sys
from collections import Counter, defaultdict

sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import REPLAYS, load_pkts  # noqa: E402
from p24_bitpath import BitReader, bits_required  # noqa: E402


def load_tables():
    t = json.load(open('/home/z/my-project/download/csi_tables_v8.json'))
    names = {}
    ncs = {}
    for etype, e in t['entities'].items():
        for p in e.get('properties', []):
            names[(etype, p['csi'])] = p['name']
        ncs[etype] = len(e.get('properties', []))
    return names, ncs


def decode_body(body, ncs, is_slice):
    """结构级解码: 返回 (csi, path下钻层, start/end 或 leafIdx, 值hex, 停止位)"""
    br = BitReader(body)
    path = []
    if br.get(1) == 0:
        # flat: 无下钻, 直接顶层叶子(单字段属性更新)
        idx = br.get(bits_required(ncs)) if ncs > 1 else 0
        w = bits_required(ncs)
        nhead = (1 + w + (2 * w if is_slice else w) + 7) // 8
        return idx, path, None, None, body[nhead:].hex(), nhead
    csi = br.get(bits_required(ncs)) if ncs > 1 else 0
    # 下钻一层(类型树状态依赖, 停在属性值 owner 层)
    more = br.get(1)
    if more:
        # 子层宽未知(需运行时类型状态) → 记录后续原始位
        return csi, path + ['nested'], None, None, None, None
    w = bits_required(ncs + 1) if is_slice else bits_required(ncs)
    try:
        if is_slice:
            s = br.get(w)
            e = br.get(w)
        else:
            s = br.get(w)
            e = None
    except IndexError:
        return csi, path, None, None, None, None
    nhead = (8 + (2 * w if is_slice else w) + 7) // 8
    return csi, path, (s, e), None, body[nhead:].hex(), nhead


def main():
    names, ncs_tab = load_tables()
    import json as J
    p05 = J.load(open('/tmp/wot/p05_decoded.json'))
    eid2type = {r['eid']: r['typeName'] for r in p05}

    out_rows = []
    stats = Counter()
    vlen_by_csi = defaultdict(Counter)
    for tag, path in REPLAYS:
        pkts = load_pkts(path)
        for ty, c, pl in pkts:
            if ty != 0x24 or len(pl) < 10:
                continue
            eid, = struct.unpack_from('<I', pl, 0)
            is_slice = pl[4]
            body = pl[9:]
            tn = eid2type.get(eid, f'T?{eid>>24}')
            ncs = ncs_tab.get(tn, 0)
            if ncs == 0:
                stats[(tn, 'noCS')] += 1
                continue
            csi, pathd, se, _, valhex, nhead = decode_body(body, ncs, is_slice)
            nm = names.get((tn, csi), f'?{csi}')
            stats[(tn, nm, is_slice)] += 1
            if valhex is not None:
                vlen_by_csi[(tn, nm)][len(valhex) // 2] += 1
            out_rows.append({
                'tag': tag, 'clk': c, 'eid': eid, 'type': tn, 'isSlice': is_slice,
                'csi': csi, 'name': nm, 'slice': se, 'nested': bool(pathd),
                'val': valhex, 'bodyLen': len(body)})
    print('== 0x24 终局统计 (类型, 属性, isSlice) ==')
    for (tn, nm, sl), n in stats.most_common(30):
        print(f'  {tn:18s} {nm:22s} slice={sl}  n={n}')
    print('\n== 值长分布 ==')
    for (tn, nm), cnt in sorted(vlen_by_csi.items()):
        print(f'  {tn:18s} {nm:22s} {dict(cnt.most_common(5))}')
    out = '/tmp/wot/p24_final.json'
    J.dump(out_rows, open(out, 'w'), ensure_ascii=False)
    print(f'\n[saved] {out} rows={len(out_rows)}')
    # 摘要
    ok = sum(1 for r in out_rows if r['val'] is not None)
    print(f'值段可切出: {ok}/{len(out_rows)}')


if __name__ == '__main__':
    main()
