#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
t37_7bit.py — Task 37 ⑤：Vehicle 0x24 首层索引 7bit 假设检验
若 Vehicle 实例 numOwnedProperties = 50(def) + dyncomp(≥14) ≥ 64 → bitsRequired = 7
则 body[0..1] = [1][csi 7b][stop=MSB(body[1])] ...
观测: 7bit csi 分布应集中于 50+（dyncomp 区），stop 位后 leaf/slice 结构自洽
对照: 6bit 假设下 csi 集中于 27-34（v21 的 perkEffects 等解释——已被类型矛盾证伪）
"""
import struct, sys, collections
sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import REPLAYS, load_pkts

def bits_of(bs): return ''.join(f'{x:08b}' for x in bs)

allc6 = collections.Counter()
allc7 = collections.Counter()
stop7 = collections.Counter()
per_tag = collections.defaultdict(collections.Counter)

for TAG, RP in REPLAYS:
    pkts = load_pkts(RP)
    eid2ty = {}
    for ty, clk, pl in pkts:
        if ty == 5 and len(pl) >= 8:
            e, n = struct.unpack_from('<II', pl, 0)
            eid2ty[e] = n
    p24 = [(c, pl) for ty, c, pl in pkts if ty == 0x24]
    for clk, pl in p24:
        eid, isl, ln = struct.unpack_from('<IBI', pl, 0)
        if eid2ty.get(eid) != 6: continue   # 只看 Vehicle
        body = pl[9:9+ln]
        if len(body) < 2 or not (body[0] & 0x80): continue
        b = bits_of(body[:3])
        c6 = int(b[1:7], 2); stop6 = b[7]
        c7 = int(b[1:8], 2); stop7bit = b[8]
        allc6[c6] += 1
        allc7[c7] += 1
        stop7[(c7, stop7bit)] += 1
        per_tag[TAG][c7] += 1

print('=== 6bit 假设 csi 分布 (v21 的解读) ===')
for c, n in sorted(allc6.items()): print(f'  csi6={c:2d}: {n:5d}')
print('=== 7bit 假设 csi 分布 ===')
for c, n in sorted(allc7.items()): print(f'  csi7={c:2d}: {n:5d}  {"←dyncomp" if c>=50 else ""}')
print('=== 7bit 假设 (csi7, stopbit) 分布 top20 ===')
for (c, s), n in stop7.most_common(20): print(f'  csi7={c:2d} stop={s}: {n:5d}')
print('=== 每场 7bit csi 分布 ===')
for tag, cc in per_tag.items():
    print(f'  {tag:20s}', dict(sorted(cc.items())))
