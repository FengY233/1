#!/usr/bin/env python3
"""digest_fork_v3.py — Task 40-a: 三修正版 0x3D digest 复现器

基于 v16 终态 (digest_fork_v2) + Task 40 三大修正（全部运行时实证）:
  修正1 ★AllowNone FD = 变长 (vanilla fixed_dict_data_type.cpp:441
        streamSize_(allowNone_ ? -1 : 0)) —— 推翻 v8「fork AllowNone=定长」
        (循环论证误诊)。实证: key27=wheelsScroll 9B TUPLE / key19=
        ownVehicleAuxPhysicsData 8B / Vehicle 变长组 26-49 全锚 / Avatar keys。
  修正2 ★静态组件 CS 属性经 baseIndex 并入父实体 csi 空间（FUN_142a8dff0:
        fullIndex = baseIndex + 排序位）—— 推翻 v13「子描述仅方法」。
        实证: TeamInfo 0x05 idx1-3 = 3×PYTHON pickle 空字典
        (= PoiTeamInfoComponent.capturedPoints + TIBVS.statuss/positions,
        Default='{}')。
  修正3 组件属性 vlh≠1 时喂入（AvatarInBattleVehicleSwitch:
        spawnInfoForVehicle vlh=2 / vehicleSpawnList vlh=4）。

csi 分配 (新规则):
  排序键: (0, ss) if ss>=0 else (1, -ss), ss = vanilla_stream_size
  vanilla_stream_size: FD+AllowNone → -1; 其余同 v2
  父实体: own 排序 0..N-1; 每组件独立排序, baseIndex 累进
digest 喂入 (每记录):
  name → [own props 声明序 + 组件 props 挂载序×声明序]:
    [csi][vlh if ss<0 and vlh≠1][name][flags&0x5F][isVolatile][type]
  → 方法三域 (v16 规则不变)
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bwxml import decode_file
from defparse import (EntityDefParser, EntityDescription, MD5,
                      COMP_BASE, COMP_CELL, COMP_CLIENT,
                      DATA_DISTRIBUTION_FLAGS)
import digest_fork_v2 as v2
from digest_fork_v2 import (SCRIPTS, EXT_ROOT, CD, SD, CLI, TARGET,
                            _has_script, ext_client_has_script, DefLocator,
                            parse_comp_record, load_static_comp,
                            parse_space_record, iter_extensions, ext_xml,
                            parse_ext_entities, parse_ext_dyncomps,
                            method_to_md5, DOM_ATTR)

DATA_PERSISTENT = 0x10
DATA_ID = 0x20


# ---------------- 修正1: vanilla FD streamSize ----------------
def vanilla_stream_size(p):
    ss = p.stream_size()          # defparse 原口径
    if ss >= 0 and p.dt.kind == 'FIXED_DICT' and p.dt.allow_none:
        return -1                 # vanilla: AllowNone FD 恒变长
    return ss


def realloc_csi_v3(ed):
    """新规则 csi 重分配（覆盖 defparse.allocate_csi 的结果）"""
    def key(idx):
        ss = vanilla_stream_size(ed.properties[idx])
        return (0, ss) if ss >= 0 else (1, -ss)
    ed.cs_props.sort(key=key)
    for i, idx in enumerate(ed.cs_props):
        ed.properties[idx].csi = i


# ---------------- 修正2: 静态组件属性解析 ----------------
class CompProps(object):
    """组件属性包: 声明序属性列表 + 独立排序 csi (baseIndex 在合并时赋)"""
    __slots__ = ('name', 'props')

    def __init__(self, name):
        self.name = name
        self.props = []          # [(Property, 原EntityDescription)] 声明序


def load_static_comp_props(parser, locator, name, _cache):
    """解析静态组件的 CS 属性（Implements 链 + Properties; Volatile 标记）"""
    if name in _cache:
        return _cache[name]
    path = locator.find('comp', name)
    if path is None:
        _cache[name] = None
        return None
    sec = decode_file(path, name + '.def')
    cp = CompProps(name)
    _comp_props_recursive(parser, locator, cp, sec, name, set())
    _cache[name] = cp
    return cp


def _comp_props_recursive(parser, locator, cp, sec, name, seen):
    """Parent/Implements 链先递归，再收 Properties（对齐 defparse 声明序）"""
    if name in seen:
        return
    seen.add(name)
    parent = sec.readString('Parent')
    if parent:
        ppath = locator.find('comp', parent)
        if ppath:
            _comp_props_recursive(parser, locator, cp,
                                  decode_file(ppath, parent + '.def'),
                                  parent, seen)
    impl = sec.child('Implements')
    if impl is not None:
        for k in impl.children:
            iname = k.asString()
            ipath = os.path.join(CD, 'interfaces', iname + '.def')
            if not os.path.exists(ipath):
                d = os.path.dirname(locator.find('comp', name) or 'x')
                ipath = os.path.join(d, 'interfaces', iname + '.def')
            if os.path.exists(ipath):
                _comp_props_recursive(parser, locator, cp,
                                      decode_file(ipath, iname + '.def'),
                                      iname, seen)
    props = sec.child('Properties')
    if props is not None:
        have = {id(p) for p in cp.props}
        for c in props.children:
            p = parser._parse_property(c)
            if p is None or not p.is_client_server:
                continue
            if any(p0.name == p.name for p0 in cp.props):
                continue          # 首定义保留
            cp.props.append(p)
    # Volatile
    vol = sec.child('Volatile')
    if vol is not None:
        vprops = vol.child('Properties')
        if vprops is not None:
            for k in vprops.children:
                for p in cp.props:
                    if p.name == k.name:
                        p.is_volatile = 1


def merge_component_props(ed, mounts, parser, locator, cp_cache):
    """把挂载组件的 CS 属性并入父记录:
    - 返回 [(CompProps, baseIndex, {prop: csi})]
    - 组件内独立排序 (修正1 规则), csi = baseIndex + 排序位"""
    out = []
    base = len(ed.cs_props)       # own 排序后的数量
    for cname in mounts:
        cp = load_static_comp_props(parser, locator, cname, cp_cache)
        if cp is None or not cp.props:
            continue
        order = sorted(range(len(cp.props)),
                       key=lambda i: _ss_key(cp.props[i]))
        csis = {}
        for pos, i in enumerate(order):
            csis[id(cp.props[i])] = base + pos
        out.append((cp, base, csis))
        base += len(cp.props)
    return out


def _ss_key(p):
    ss = vanilla_stream_size(p)
    return (0, ss) if ss >= 0 else (1, -ss)


# ---------------- 修正版喂入 ----------------
def fork_add_to_md5_v3(ed, md5, comp_prop_info=None):
    md5.append(ed.name.encode('utf-8'))
    # own 属性 (声明序)
    for p in ed.properties:
        if not p.is_client_server:
            continue
        _prop_to_md5(md5, p, p.csi)
    # 修正2: 组件属性 (挂载序 × 声明序)
    if comp_prop_info:
        for cp, base, csis in comp_prop_info:
            for p in cp.props:
                _prop_to_md5(md5, p, csis[id(p)])
    # 方法三域 (v16 规则不变)
    for domain, own_list in (
            ('client', ed.client_methods),
            ('base', ed.base_methods),
            ('cell', ed.cell_methods)):
        count = 0
        for m in own_list:
            if not (m.flags & 0xC):
                continue
            method_to_md5(md5, m, count, domain)
            count += 1
        for sd in getattr(ed, 'fork_components', []):
            for m in getattr(sd, DOM_ATTR[domain]):
                if not (m.flags & 0xC):
                    continue
                method_to_md5(md5, m, count, domain)
                count += 1


def _prop_to_md5(md5, p, csi):
    ss = vanilla_stream_size(p)
    md5.append_int32(csi)
    if ss < 0 and p.var_len_header != 1:
        md5.append_uint32(p.var_len_header)   # 修正3
    md5.append(p.name.encode('utf-8'))
    md5.append_int32(p.flags & DATA_DISTRIBUTION_FLAGS)
    md5.append_uint8(getattr(p, 'is_volatile', 0))
    p.dt.add_to_md5(md5)


# ---------------- 主流程 ----------------
def main():
    parser = EntityDefParser(SCRIPTS)
    parser.load()

    comps_root = decode_file(os.path.join(SCRIPTS, 'components.xml'),
                             'components.xml')
    static_list = [k.name for k in comps_root.child('StaticComponents').children]
    dyn_list = [k.name for k in comps_root.child('DynamicComponents').children]

    mounts = {}
    for cname in static_list:
        sec = decode_file(os.path.join(CD, cname + '.def'), cname + '.def')
        ofe = sec.child('ofEntity')
        if ofe is not None:
            for k in ofe.children:
                mounts.setdefault(k.name, []).append(cname)

    sub_cache, rec_cache, comp_cache, cp_cache = {}, {}, {}, {}
    locator = DefLocator([])

    records = []          # (ed, comp_prop_info)
    records.append((parse_space_record(parser), None))
    for ed in parser.entities:
        ed.fork_components = [load_static_comp(parser, locator, c, sub_cache)
                              for c in mounts.get(ed.name, [])]
        realloc_csi_v3(ed)                       # 修正1
        cpi = merge_component_props(ed, mounts.get(ed.name, []),
                                    parser, locator, cp_cache)  # 修正2
        records.append((ed, cpi))
        rec_cache[ed.name] = ed
    n_main = len(records) - 1

    exts = iter_extensions()
    print(f'扩展: {len(exts)} 个')
    n_ext_ent = 0
    for ext in exts:
        eloc = DefLocator([os.path.join(EXT_ROOT, ext, '_raw')])
        for ed in parse_ext_entities(parser, eloc, ext, rec_cache):
            realloc_csi_v3(ed)
            records.append((ed, None))
            n_ext_ent += 1

    seen = set()
    skipped_main = []
    for name in dyn_list:
        if name in seen:
            continue
        seen.add(name)
        if not _has_script(CLI, name):
            skipped_main.append(name)
            continue
        ed = parse_comp_record(parser, locator, name, comp_cache)
        ed.fork_components = []
        realloc_csi_v3(ed)
        records.append((ed, None))
        rec_cache[ed.ed.name if hasattr(ed, 'ed') else ed.name] = ed
    n_main_dyn = len(records) - 1 - n_main - n_ext_ent

    n_ext_dyn = 0
    for ext in exts:
        eloc = DefLocator([os.path.join(EXT_ROOT, ext, '_raw')])
        eds, sk = parse_ext_dyncomps(parser, eloc, ext, rec_cache, comp_cache)
        for ed in eds:
            realloc_csi_v3(ed)
            records.append((ed, None))
            n_ext_dyn += 1

    print(f'records = 1 + {n_main} 主实体 + {n_ext_ent} 扩展实体 '
          f'+ {n_main_dyn} 主 dyncomp + {n_ext_dyn} 扩展 dyncomp = {len(records)}')

    # 统计
    n_cs = sum(len(ed.cs_props) for ed, _ in records)
    n_cprop = sum(len(cp.props) for ed, cpi in records if cpi for cp, _, _ in cpi)
    n_vlh = 0
    for ed, cpi in records:
        for idx in ed.cs_props:
            p = ed.properties[idx]
            if vanilla_stream_size(p) < 0 and p.var_len_header != 1:
                n_vlh += 1
        if cpi:
            for cp, _, _ in cpi:
                for p in cp.props:
                    if vanilla_stream_size(p) < 0 and p.var_len_header != 1:
                        n_vlh += 1
    print(f'own CS 属性: {n_cs} + 组件并入属性: {n_cprop}; vlh≠1 喂入: {n_vlh}')

    md5 = MD5()
    for ed, cpi in records:
        fork_add_to_md5_v3(ed, md5, cpi)
    d = md5.getDigestQuote()
    hit = '★★★ 命中目标!!' if d == TARGET else '≠'
    print(f'[v3 三修正完整模型: {len(records)} 记录] {d} {hit}')
    print(f'[目标] {TARGET}')

    # 变体消融: 仅修正1 / 仅修正2 / 1+2
    def run_variant(tag, use_fix1, use_fix2):
        global vanilla_stream_size
        orig = vanilla_stream_size
        if not use_fix1:
            vanilla_stream_size = lambda p: p.stream_size()
        m2 = MD5()
        for ed, cpi in records:
            if not use_fix2:
                cpi = None
            fork_add_to_md5_v3(ed, m2, cpi)
        vanilla_stream_size = orig
        print(f'[{tag}] {m2.getDigestQuote()}')

    print('--- 消融 ---')
    run_variant('仅修正2(组件并入, 无AllowNone)', False, True)
    run_variant('仅修正1(AllowNone, 无组件并入)', True, False)
    run_variant('v2 基线复算', False, False)


if __name__ == '__main__':
    main()
