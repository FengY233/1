#!/usr/bin/env python3
"""pack_v24.py — Task 44 Phase A: V24 全量重打包（安全快照版）

背景: V16 是最后一个全量包(98文件), V17-V23 越打越瘦(最后仅7文件)。
V24 = V16 全量底座 + data_v21~v25 全部增量 + data_v26 历史补充工件
      + 133 脚本 + findings v26 + worklog + 审计 v24。
分发: download/ + upload/backup_v24/（upload 已被清空, 本轮重建备份）
注: Phase C(本轮研究完成后) 会以 report §23 + findings v27 + 新数据刷新本包。
"""
import zipfile, os, hashlib, json, time, shutil

BASE = '/home/z/my-project'
DL = os.path.join(BASE, 'download')
SC = os.path.join(BASE, 'scripts')
STAGE = '/tmp/wot/v24_stage'
ZIPNAME = 'WoT回放解析交付包_v24.zip'
ZIP = os.path.join(STAGE, ZIPNAME)

os.makedirs(STAGE, exist_ok=True)

def md5(p):
    h = hashlib.md5()
    with open(p, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()

files = {}   # arcname -> diskpath

# ── 1) 顶层交付物（V16 时代恢复的全量件） ─────────────────────────
TOP = [
    'WoT回放完全解析报告.md',
    'WoT回放完全解析报告.pdf',
    'WoT回放解析数据包_20260911_caucasus.xlsx',
    'WoT回放解码数据_20260911_caucasus.json',
    'csi_tables_v8.json',
    'ext_inventory.json',
    '报告封面源文件.html',
    '覆盖度终审_v13_audit.json',
    '覆盖度终审_v14_audit.json',
]
for f in TOP:
    p = os.path.join(DL, f)
    if os.path.exists(p):
        files[f] = p
    else:
        print(f'!! 缺失: {f}')

# ── 2) charts ─────────────────────────────────────────────────────
cdir = os.path.join(DL, 'charts')
for f in sorted(os.listdir(cdir)):
    p = os.path.join(cdir, f)
    if f.endswith('.png') and os.path.isfile(p):
        files[f'charts/{f}'] = p

# ── 3) data_v17..v25 历史增量目录（原样收拢） ─────────────────────
for sub in sorted(os.listdir(DL)):
    dpath = os.path.join(DL, sub)
    if os.path.isdir(dpath) and sub.startswith('data_v') and sub != 'data_v26':
        for root, _, fs in os.walk(dpath):
            for f in sorted(fs):
                fp = os.path.join(root, f)
                arc = os.path.relpath(fp, DL)
                files[arc] = fp

# ── 4) data_v26 历史补充工件（从未入包的 /tmp/wot 研究数据） ──────
d26 = os.path.join(DL, 'data_v26')
os.makedirs(d26, exist_ok=True)
SUPP = [
    ('/tmp/wot/p24_keys.json',          'data_v26/0x24键空间_p24_keys.json'),
    ('/tmp/wot/p24_top_csi.json',       'data_v26/0x24顶层csi分布_p24_top_csi.json'),
    ('/tmp/wot/vdef_props.json',        'data_v26/Vehicle运行时属性表68条_vdef_props.json'),
    ('/tmp/wot/veh_decl_table.json',    'data_v26/Vehicle声明序表76属性_veh_decl_table.json'),
    ('/tmp/wot/t37_ext.json',           'data_v26/0x05扩展观测1124条_t37_ext.json'),
    ('/tmp/wot/csi_tables_v9.json',     'data_v26/csi_tables_v9_副本.json'),
    ('/tmp/wot/t44_hierarchy_maps.json','data_v26/0x32层级字典_260实体_t44_hierarchy_maps.json'),
    ('/tmp/wot/t44_catalog.json',       'data_v26/0x32消息族目录_t44_catalog.json'),
]
for src, arc in SUPP:
    if os.path.exists(src):
        dst = os.path.join(DL, arc)
        if not os.path.exists(dst):
            shutil.copy2(src, dst)
        files[arc] = dst
    else:
        print(f'!! 补充缺失: {src}')

# ── 5) scripts 全量 ───────────────────────────────────────────────
for f in sorted(os.listdir(SC)):
    p = os.path.join(SC, f)
    if f.endswith('.py') and os.path.isfile(p):
        files[f'scripts/{f}'] = p

# ── 6) findings + worklog（当前 live 版本） ────────────────────────
files['findings.md'] = os.path.join(BASE, 'findings.md')
files['worklog.md'] = os.path.join(BASE, 'worklog.md')

# ── 7) README（包内） ─────────────────────────────────────────────
README = '''# WoT 回放解析交付包 V24（全量重打包）

> 2026-09-26 · Task 44 · V24 = **全量收拢版（终版）**
> 定位：V16 之后各包（V17–V23）越打越瘦，V24 把全部内容重新收拢成一个完整包。
> 主分析对象：11 场回放（CN×3 / EU×7 / NA×1，2.4.0.0 世代），研究范围=随机战（bt=1 ctf 10 场 + bt=46 变体 1 场）。

## 包结构（按目录）

| 内容 | 说明 |
|---|---|
| `WoT回放完全解析报告.md` | 主报告 §0–§23（V13 时代定稿 + v10–v13 增补 + §23 v18–v26 总览与 ClientHub/NRL 架构轮） |
| `WoT回放完全解析报告.pdf` | PDF 版（V16 时代排版，63 页，内容截至 §20；MD 较新，以 MD 为准） |
| `WoT回放解析数据包_20260911_caucasus.xlsx` | 数据包 21 工作表（V12 时代） |
| `WoT回放解码数据_20260911_caucasus.json` | 首场回放全量解码 JSON |
| `charts/` | 8 张分析图 |
| `csi_tables_v8.json` | csi 权威表 v8（历史版；31–49 段已被 v20 RULE X / v25 csi_v9 修正） |
| `ext_inventory.json` | 18 扩展 pkg 清单（v14） |
| `data_v17/` | 11 场回放普查 / methodID 分配表 / methodID 跨场矩阵 / 实体锚矩阵（v17） |
| `data_v18/` | 0x05 扩展区观测 / 名册 join / block0 构建号归属 / 314 车名册 / Vehicle 76 属性 / 0x24 全量精确解码（v18/v22） |
| `data_v19/` | ext_cluster / network_idx_remap（v19，已被 v20 部分修正） |
| `data_v20/` | 0x05 全量解码 6899 条（11 场 100% 精确）/ RULE X 网络 idx 表（v20） |
| `data_v21/` | perks 语义解码 / 0x24 对齐（v23） |
| `data_v22/` | deathOrder 击杀链 220 条 / AoI 协议链 / E 纪元侦察（v24） |
| `data_v23/` | csi_tables_v9 + digest_fork_v5/v6 + t40 系列（v25） |
| `data_v24/` | digest_fork_v7–v11 消融引擎 + t41/t42 审计（v26） |
| `data_v25/` | digest_fork_v12/v13（EXE 白盒终版）+ t43 系列（Task 43） |
| `data_v26/` | 历史补充工件（0x24 键空间 / csi 分布 / Vehicle 属性表 / **0x32 层级字典 260 实体** / **0x32 消息族目录 112 族**） |
| `scripts/` | 全部分析脚本（145 件，t37–t44 系列 + 解码器 + digest 引擎 + 打包/门户） |
| `findings.md` | ★ 结论登记册 v28（最全最权威的知识载体，§0–§24 + 附录 A–L） |
| `worklog.md` | 全谱系工作日志（会话 A–P，Task 1–43，历次重置与恢复均有记录） |
| `audit_v24.json` | 本包审计（v17–v26 各轮结论速览 + 覆盖度口径） |
| `覆盖度终审_v13/v14_audit.json` | 历史覆盖度审计 |
| `报告封面源文件.html` | PDF 封面源 |

## v17–v26 各轮核心结论速览（V16 之后的增量）

- **v17（§13）**：digest 11 场恒定实锤；0x05 头格式 [eid][typeID] 钉死；typeID=entities.xml 声明序 1 基；methodID 表 70 方法跨场语义验证。
- **v18（§14）**：block0 构建号全表（digest=2.4.0.0 世代全局指纹）；技能三分离（乘员 perks vs 车辆 vehPerks/vpp）；0x07/0x05 原始格式钉死。〔§14.5 CSI≥50 扩展区理论已被 v20 推翻〕
- **v19（§15）**：0x05 属性流 vanilla 纯格式四实体铁证；MY_VEHICLE 分层；网络 idx 过滤重排（vpp@40）。〔变长组序已被 v23 修正〕
- **v20（§16）**：★★RULE X 网络 idx 表；0x05 无组件段（推翻扩展区理论）；11 场 6899/6899 字节级 100% 精确解码；publicInfo.name=匿名化机制。
- **v21–v22（§17–§18）**：0x24 = 嵌套/切片属性更新通道全白盒；位宽漂移状态机；5,241/5,241 = 100% 精确解码。
- **v23（§19）**：csi29/30 = perks/perksRibbonNotify（战场技能流）；perks.xml 42 ID 权威验证；clk 纪元重定位。
- **v24（§20）**：E=服务器进程时钟；0x05 重创建=AoI 离开/重入（0x04=leaveAoI 100% 前导）；0x32/0x37 写入器族+通用转发器；deathOrder 220/221。
- **v25（§21）**：digest 三源偏差翻案（TeamInfo+3=组件属性并入 / Vehicle 重排=v8 误诊 / 方法 flags=u8）；csi_v9 权威表。
- **v26（§22）**：★★digest 算法层完全翻案（结构化 visitor 协议，v2–v25 裸喂入模型作废）；scripts942=wot_scripts 零差异；18 扩展启动挂载实锤。
- **Task 43（data_v25）**：EXE 白盒终局（域标记/字段名标签全零字节、MAILBOX 零字节、25 类 visit 全解）；三实锤修复（静态组件属性并入+csi 分块+VLH 门）；复现值 E726F5E4，偏差坍缩至无锚记录内容。
- **Task 44（本包新增）**：★★41 槽消息处理器接口表（0x32–0x39 = 8 个连续 fork 扩展槽，只录不转发=服务器专供回放注记流）；★类链 WGReplayConnection:ClientHub:BWEndPoint + NRL::EndPoint + 播放分发表；★ClientHub 消息文法（class 0–5 分发 + processUpdateNode）；★★hierarchyInfo 全量提取（980+ 车辆层级字典）；★0x37 NRL 组文法 + nid 空间对撞；CGF Python 侧全解；v6 勘误（"组件路由号"=[u32 len]）。

## 覆盖度口径（随机战范围）

- 容器 / JSON 头 / 结算 JSON / 0x05 属性流 / 0x24：**100%**（字节级精确解码）
- 0x07 属性更新 ≈99% · 0x0A 移动流 ≈95% · 0x08 方法调用 ≈90%（methodID 全解，部分 args 未逐字段）
- 0x32/0x37 ≈**93%**（架构/文法/字典层已解，值级字段开放）· 0x39 ≈75%（文法闭环+语义挂靠）
- digest 复现支线 ~95%（机制 100% 逐字节证毕；剩余偏差=160 扩展记录无运行时锚，不影响任何随机战解析）

## 数据与结论的版本演进提醒

findings.md 是唯一逐轮勘误的权威登记册——历史 data_v*/scripts 中被后续轮修正的结论（v8 csi 表 31–49 段、v19 变长组序、v21 固定位宽等）以 findings 勘误栏为准。
'''
readme_path = os.path.join(STAGE, 'README.md')
with open(readme_path, 'w', encoding='utf-8') as f:
    f.write(README)
files['README.md'] = readme_path

# ── 8) audit_v24.json ─────────────────────────────────────────────
audit = {
 "version": "v24",
 "date": time.strftime('%Y-%m-%d %H:%M'),
 "task": "Task 44: V24 全量重打包终版（V16 底座 + v17-v28 全部增量 + ClientHub/NRL 架构轮成果）",
 "headline": [
  "V24 终版: 211+ 文件全量收拢——报告§23(v18-v26总览+架构轮) + findings v28(§24) + data_v26(层级字典/消息族目录) + 全部脚本",
  "upload/backup_v24/ 重建备份（upload 曾被清空, V24 起为恢复基线）",
  "Task 44 架构突破: 41槽处理器接口表 / WGReplayConnection:ClientHub:BWEndPoint 类链 / ClientHub 消息文法 / hierarchyInfo 980+车辆层级字典 / 0x37 NRL组文法",
  "0x32-0x39 = 服务器专供回放注记流(只录不转发); v6 勘误: 首 u32 组件路由号实为 [u32 len]",
  "研究范围终裁: 仅随机战; 扩展回放建议撤销; digest 支线剩余偏差不影响任何随机战解析"
 ],
 "coverage": {
  "scope": "随机战(bt=1, 10场)",
  "container_json_0x05_0x24": "100%",
  "0x07": "~99%", "0x0A": "~95%", "0x08": "~90%",
  "0x32_0x37": "~93%(架构/文法/字典层已解, 值级字段开放)", "0x39": "~75%",
  "digest_reproduction": "~95%(机制100%逐字节证毕)"
 },
 "base_package": "V16(98文件)",
 "files": len(files)
}
audit_path = os.path.join(STAGE, 'audit_v24.json')
with open(audit_path, 'w', encoding='utf-8') as f:
    json.dump(audit, f, ensure_ascii=False, indent=1)
files['audit_v24.json'] = audit_path

# ── 9) 打包 ───────────────────────────────────────────────────────
if os.path.exists(ZIP):
    os.remove(ZIP)
manifest = {}
with zipfile.ZipFile(ZIP, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for arc in sorted(files):
        z.write(files[arc], arc)
        manifest[arc] = {'size': os.path.getsize(files[arc]), 'md5': md5(files[arc])}

size = os.path.getsize(ZIP)
zm = md5(ZIP)
print(f'V24 打包完成: {ZIP}')
print(f'  文件数: {len(files)}  包大小: {size:,} B  md5: {zm}')

# ── 10) 分发 download/ + upload/backup_v24/ ───────────────────────
dst_dl = os.path.join(DL, ZIPNAME)
shutil.copy2(ZIP, dst_dl)
print(f'  -> download/{ZIPNAME}')

bdir = '/home/z/upload/backup_v24'
os.makedirs(bdir, exist_ok=True)
shutil.copy2(ZIP, os.path.join(bdir, ZIPNAME))
shutil.copy2(files['findings.md'], os.path.join(bdir, 'findings.md'))
shutil.copy2(files['worklog.md'], os.path.join(bdir, 'worklog.md'))
shutil.copy2(audit_path, os.path.join(bdir, 'audit_v24.json'))
print(f'  -> upload/backup_v24/ (包 + findings + worklog + audit)')

# manifest 存根
with open(os.path.join(STAGE, 'manifest_v24.json'), 'w', encoding='utf-8') as f:
    json.dump({'zip_md5': zm, 'zip_size': size, 'files': manifest}, f, ensure_ascii=False, indent=1)
print(f'  manifest: {STAGE}/manifest_v24.json')
