#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
t39_e.py — Task 39-e: 0x32/0x37 嵌套 TLV 通道字段级侦察（随机战 10 场）
"""
import json, struct, sys
from collections import Counter, defaultdict

sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import REPLAYS, load_pkts

RB = [r for r in REPLAYS if r[0] != 'tundra_CN_942']

for TY in (0x32, 0x37):
    print('=' * 20, '0x%02X' % TY, '=' * 20)
    allb = []
    for tag, path in RB:
        pkts = load_pkts(path)
        for ty, clk, body in pkts:
            if ty == TY:
                allb.append((tag, clk, body))
    print('包数:', len(allb))
    sz = Counter(len(b) for _, _, b in allb)
    print('len 分布 top15:', dict(sorted(sz.items(), key=lambda x: -x[1])[:15]))
    # 首字节/前8字节形态
    fb = Counter(b[0] for _, _, b in allb if b)
    print('首字节 top10:', dict(fb.most_common(10)))
    # 按场分布
    per = Counter(t for t, _, _ in allb)
    print('按场:', dict(per.most_common()))
    # 样本 hex（不同长度的前 3 例）
    seen = set()
    n = 0
    for tag, clk, b in allb:
        if len(b) in seen: continue
        seen.add(len(b))
        print('  [%s len=%d] %s' % (tag, len(b), b[:48].hex()))
        n += 1
        if n >= 12: break
    print()
