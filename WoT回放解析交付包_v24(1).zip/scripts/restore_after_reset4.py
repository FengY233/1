# -*- coding: utf-8 -*-
"""restore_after_reset4.py — 第4次环境重置后的工作区恢复（阶段1：工作区 + 门户）
来源：upload/backup_v16/（V16 交付包，Task 35 / 会话K 终局版）
恢复目标：
  1. 根 worklog.md / findings.md
  2. scripts/（V16 包内 84 件工作脚本）
  3. download/（V16 交付物：zip + 根级文档 + data_v17~v20 + charts）
  4. 启动 file_server.py :3000 门户
"""
import os
import shutil
import subprocess
import zipfile

BASE = '/home/z/my-project'
UP = f'{BASE}/upload'
BK = f'{UP}/backup_v16'
V16 = f'{BK}/WoT回放解析交付包_v16.zip'

# 1. 根 worklog / findings
shutil.copy2(f'{BK}/worklog.md', f'{BASE}/worklog.md')
shutil.copy2(f'{BK}/findings_v20.md', f'{BASE}/findings.md')
print('[1] 根 worklog.md + findings.md 已恢复')

# 2+3. 解压 V16 包
os.makedirs(f'{BASE}/scripts', exist_ok=True)
os.makedirs(f'{BASE}/download', exist_ok=True)
z = zipfile.ZipFile(V16)
n_script = n_dl = 0
for info in z.infolist():
    name = info.filename
    if name.endswith('/'):
        continue
    # scripts/ → 工作区 scripts/（门户不暴露工作脚本）
    if name.startswith('scripts/'):
        dst = f'{BASE}/{name}'
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        with z.open(info) as src, open(dst, 'wb') as out:
            shutil.copyfileobj(src, out)
        n_script += 1
    else:
        # 根级文件 + data_v17~v20 + charts → download/
        dst = f'{BASE}/download/{name}'
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        with z.open(info) as src, open(dst, 'wb') as out:
            shutil.copyfileobj(src, out)
        n_dl += 1
# zip 本体也放 download/
shutil.copy2(V16, f'{BASE}/download/WoT回放解析交付包_v16.zip')
print(f'[2] scripts/ 恢复 {n_script} 件')
print(f'[3] download/ 恢复 {n_dl} 件 + zip 本体')

# 4. 启动门户（守护化）
portal = f'{BASE}/scripts/file_server.py'
subprocess.Popen(
    ['python3', portal],
    stdout=open('/tmp/portal_v16.log', 'w'),
    stderr=subprocess.STDOUT,
    start_new_session=True)
print('[4] file_server.py :3000 已守护化启动（日志 /tmp/portal_v16.log）')

# 自检
import urllib.request
import time
time.sleep(1.2)
try:
    r = urllib.request.urlopen('http://127.0.0.1:3000/health', timeout=5)
    print('[自检] /health ->', r.read().decode())
except Exception as e:
    print('[自检] 失败:', e)
print('阶段1 完成')
