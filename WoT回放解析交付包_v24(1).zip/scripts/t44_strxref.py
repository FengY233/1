#!/usr/bin/env python3
"""t44_strxref.py — 在 EXE 中定位关键字符串并找 .text 引用
字符串: deathOrder, SequenceNetworkSync, hierarchyInfo, prefabPath, networkID
方法: .rdata 搜串 → rip 相对 lea/mov 引用扫描
"""
import pefile, struct

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

secs = []
for s in pe.sections:
    secs.append((s.Name.decode().rstrip('\0'), imgbase + s.VirtualAddress,
                 s.Misc_VirtualSize, s.PointerToRawData, s.SizeOfRawData))

def off_to_va(off):
    for n, va, vs, raw, rs in secs:
        if raw and raw <= off < raw + rs:
            return va + (off - raw)
    return None

def va_to_off(va):
    for n, v, vs, raw, rs in secs:
        if v <= va < v + max(vs, rs):
            return raw + (va - v) if raw else None
    return None

def find_str(s):
    """返回 .rdata/.data 中 字符串 的 VA 列表"""
    out = []
    pat = s.encode() + b'\x00'
    off = 0
    while True:
        i = data.find(pat, off)
        if i < 0:
            break
        va = off_to_va(i)
        if va:
            out.append(va)
        off = i + 1
    return out

def xrefs(target_va, limit=12):
    """扫描 .text 中 rip 相对引用 (lea/mov)"""
    res = []
    tsec = [s for s in secs if s[0] == '.text'][0]
    raw, rs = tsec[3], tsec[4]
    text = data[raw:raw+rs]
    for i in range(len(text) - 7):
        b = text[i]
        # lea r64, [rip+d32]: 48 8d xx disp ; mov: 48 8b xx disp
        if b == 0x48 and text[i+1] in (0x8d, 0x8b) and (text[i+2] & 0xC7) == 0x05:
            disp = struct.unpack('<i', text[i+3:i+7])[0]
            va = tsec[1] + i
            if va + 7 + disp == target_va:
                res.append(va)
                if len(res) >= limit:
                    break
    return res

for s in ['deathOrder', 'SequenceNetworkSync', 'hierarchyInfo', 'prefabPath',
          'slotName', 'compositionRootSlot', 'recreateMethod']:
    vas = find_str(s)
    print(f'\n"{s}": {len(vas)} 处 -> {[hex(v) for v in vas[:4]]}')
    for va in vas[:2]:
        xr = xrefs(va)
        if xr:
            print(f'   引用: {[hex(x) for x in xr]}')
