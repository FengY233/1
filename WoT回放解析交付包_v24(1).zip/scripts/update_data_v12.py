#!/usr/bin/env python3
"""update_data_v12.py — 解码 JSON 加 v16 终局段 + 审计 JSON 加 v16_revisions"""
import json, shutil, os

os.makedirs('/tmp/wot/v12_stage', exist_ok=True)

# 1. 解码 JSON
src = '/tmp/wot/v11_unpack/WoT回放解码数据_20260911_caucasus.json'
dst = '/tmp/wot/v12_stage/WoT回放解码数据_20260911_caucasus.json'
shutil.copy(src, dst)
d = json.load(open(dst, encoding='utf-8'))

d['feature_extension_v16'] = {
    '_meta': {
        'version': 'v12 增补（2026-09-25）',
        'source': '最全会话记录（FengY233/test 会话记录.txt 8389 行版）恢复的终局轮结论',
        'scope': 'v15（u16 修复 + 扩展实算）与 v16（client 方法真相 + 版本终局 + 网络 methodID）',
    },
    'records_model': {
        'total': 318,
        'composition': '1 space + 40 主实体 + 10 扩展实体 + 107 主 dyncomp + 160 扩展 dyncomp',
        'order': 'space→主CS→扩展CS→主dyncomp→扩展dyncomp（parse append 物理序，FUN_142a9b410 0x328 步长无重排）',
        'ext_iteration': 'FeatureName 键有序 map = 字母序（机器码裁决 FUN_140313020）',
        'ext_static_mount_edges': 0,
        'ext_static_mount_note': 'Part b=根级 ExternalComponents 全空；v14「39 边」系误归因（0x6665642e 证据属 Part a）',
        'main_dyncomp_excluded': ['ExtendedSPG', 'EnemyShotPredictorController', 'ArenaVehiclesInfo'],
        'ext_dyncomp_excluded_count': 11,
        'global_dedup': 'FUN_142a99f30 全局名字 map 去重——全部名字组合重叠为空',
    },
    'method_layer_fixes': {
        'flags_width': 'u16（2 字节 [flags,0x00]，calculator slot10=FUN_1403e8260；v9-v13 漏读）',
        'filter': '三域统一 (flags & 0xC) != 0（分布位）',
        'client_auto_expose': 'component==CLIENT → flags|=4（FUN_142aa7540:377428 机器码；vanilla 无此规则）',
        'method_count': '163→366（主消融 105→247）',
        'varLen_activation': 'client 方法进 digest → isForClient varLen u32 前缀激活（vlh 分布 {1:342, 2:5}）',
        'three_way_proof': 'decomp 机器码 + vanilla 对照 + 0x08 运行时 128 对全命中',
    },
    'network_methodid': {
        'mechanism': '域内 exposedMethods_ stable_sort by streamSize（定长升序在前、变长按 vlh 在后）后 0 起编号',
        'vs_digest_index': 'digest index=legacyExposedIndex（声明序计数）——两套编号',
        'csi_isomorphism': '与属性 csi 的 allocateClientServerFullIndexes 排序同族同构',
        'anchors': {'Vehicle': {'1': 'showShooting', '4': 'onHealthChanged', '10': 'showDamageFromShot'},
                    'Avatar': {'23': 'updateArena(×28)'}},
        'jsonl_m_field': '生成器错位标注，弃用（README 警告应验）',
    },
    'index_layout': {
        'entities_xml_order': '真实声明序非字母序：Account, Avatar, ArenaInfo, ClientSelectableObject, HangarVehicle, Vehicle(6th), AreaDestructibles(7th)…',
        'formula': '索引 = space(0) + 声明序(1..40)',
        'n_distribution': {'3': 'ArenaInfo×1', '6': 'Vehicle×30', '7': 'AreaDestructibles',
                           '18': '×1', '28': 'TeamInfo×1', '29': 'AvatarInfo×1', '40': 'NetworkEntity×4'},
        'networkentity_proof': 'n=40 载荷与 csi 表逐字段吻合（scale=1,1,1/unique_id=UUID/prefab_path="37_bridge_destruction_01"/name="Collisions"）',
    },
    'version_final': {
        'direction': '0x3D = 客户端→服务器 LogOnParams 上行（登录流四件套 t=24/45/48/61，clk=0 头部区）',
        'build_alignment': '全部材料对齐 #942（exe sha256↔manifest ✓ / 回放录制 ✓ / ext_defs 导出 ✓）',
        'diff_938_942': '仅 6 文件（precache.xml/version.xml/manifest/元数据）——零 def 变更',
        'diff_942_949': '152 个 M 全部与 digest 无关（GUI/本地化/平衡数据）',
        'timeline_beijing': ['09-11 05:58 镜像快照 #942（2.4.0.5435）', '09-11 18:01 回放录制',
                             '09-18 03:23 镜像 #949（2.4.0.5449，2.4.0.1 上线）', '09-23/24 用户导出'],
        'mod_interference': '无改 entityDefs 的 mod → digest 输入=纯 pkg defs',
    },
    'digest_values': {
        'v14_noext': 'E2E9EBE2', 'v15_full': '20E4276E', 'v15_main_ablation': 'FD632272',
        'v16_full': '5976CA145E07E97C627D8B40ED9952CF', 'v16_main_ablation': '16AE6853',
        'target': '5DF886F75E73B33CFF9D87FB9C69389C', 'status': '≠（剩余偏差锁定 dyncomp 记录）',
    },
    'remaining_freedom': {
        'locked_to': 'dyncomp 记录内容（267/318 = 84% 无运行时真值源）',
        'main_entities_confidence': '最高：属性 40/40 + 方法全量 + 索引布局全部有运行时真值锚',
        'breakthrough_path': '录一场大逃杀/前线/背水之战回放——0x05/0x08 给扩展实体与动态组件真值锚',
    },
}
json.dump(d, open(dst, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('解码 JSON: feature_extension_v16 段已加，21 个顶层键' if len(d) == 21 else f'解码 JSON: {len(d)} 键')

# 2. 审计 JSON
src2 = '/tmp/wot/v11_unpack/覆盖度终审_v9_audit.json'
dst2 = '/tmp/wot/v12_stage/覆盖度终审_v12_audit.json'
shutil.copy(src2, dst2)
a = json.load(open(dst2, encoding='utf-8'))
a['v16_revisions'] = {
    'date': '2026-09-25',
    'note': 'V12 恢复轮：从最全会话记录恢复 v15/v16 终局轮结论；覆盖度口径不变',
    'model_fixes': ['方法 flags u16（slot10 漏读）', '三域统一 (flags&0xC)!=0 过滤',
                    'client 方法自动 |=0x4（163→366）'],
    'digest': 'v16 全量 318 记录 = 5976CA14...（V12 重建精确复现）≠ 目标 5DF886F7...',
    'version_alignment': '#942 全材料对齐（#938→#942 零 def 变更）',
    'remaining': 'dyncomp 记录内容（84% 无真值源）',
}
json.dump(a, open(dst2, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('审计 JSON: v16_revisions 已加')
