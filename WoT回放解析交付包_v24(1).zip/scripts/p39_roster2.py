#!/usr/bin/env python3
"""p39_roster2.py — block1 明文 JSON 解析: 车辆名册 + SPG + 技能字段排查
0x39 出现条件 hunting: 对比 4 个出现场 vs 7 个零出现场
"""
import json
import struct
import sys

REPLAYS = [
    ("siegfried_EU_39", "/tmp/wot/github_test/20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay"),
    ("karelia_EU_39", "/tmp/wot/github_test/20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay"),
    ("lakeville_EU_0", "/tmp/wot/github_test/20260907_1321_germany-G197_Pz_Kpfw_Neu_07_lakeville.wotreplay"),
    ("caucasus_NA_0", "/tmp/wot/github_test/20260910_1057_china-Ch67_BZ_79_37_caucasus.wotreplay"),
    ("namerica_CN_0", "/tmp/wot/github_test/20260911_1534_ussr-R52_Object_261_44_north_america.wotreplay"),
    ("tundra_CN_0", "/tmp/wot/github_test/20260911_1749_uk-GB156_Black_Prince_II_63_tundra.wotreplay"),
    ("caucasus_CN942_0", "/tmp/wot/github_test/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay"),
    ("greatwall_EU_0", "/tmp/wot/github_test/20260912_1036_france-F143_Fauteur_59_asia_great_wall.wotreplay"),
    ("karelia2_EU_39", "/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay"),
    ("PTZ_10K_EU_0", "/tmp/wot/github_test/PTZ_10K.wotreplay"),
    ("WZ219_EU_39", "/tmp/wot/github_test/WZ-219.wotreplay"),
]


def get_blocks(path):
    data = open(path, "rb").read()
    (magic, bc) = struct.unpack_from("<II", data, 0)
    pos = 8
    blocks = []
    for _ in range(bc):
        (blen,) = struct.unpack_from("<I", data, pos)
        blocks.append(data[pos + 4:pos + 4 + blen])
        pos += 4 + blen
    return blocks


def main():
    for tag, path in REPLAYS:
        blocks = get_blocks(path)
        if len(blocks) < 2 or not blocks[1]:
            print(f"{tag}: block1 空")
            continue
        try:
            data = json.loads(blocks[1])
        except Exception as e:
            print(f"{tag}: JSON 解析失败 {e}")
            continue
        # 结构: [ {personal: {...}}, {vehicles: {...}} ... ] 或 dict?
        if isinstance(data, list):
            secs = {list(s.keys())[0] if isinstance(s, dict) and len(s) == 1 else "?": s for s in data}
            keys = [list(s.keys()) for s in data]
            flat = {}
            for s in data:
                if isinstance(s, dict):
                    flat.update(s)
        else:
            flat = data
        print(f"\n===== {tag} =====")
        print("  顶层段:", [list(s.keys())[:2] for s in data][:8] if isinstance(data, list) else list(data)[:8])
        veh = flat.get("vehicles") or {}
        if isinstance(veh, dict) and veh:
            print(f"  vehicles 数: {len(veh)}")
            # 每车: vehicleType, clan, etc.
            spg = []
            types = []
            for dbid, v in list(veh.items())[:40]:
                vt = v.get("vehicleType", "?")
                types.append(vt)
            from collections import Counter
            ct = Counter(t.split(":")[0] if ":" in t else t for t in types)
            print("  车型计数:", dict(ct))
            # 逐车字段名集合(第一辆)
            first = list(veh.values())[0]
            print("  单车字段:", sorted(first.keys()))
            # 找技能相关字段
            for k in first:
                if any(w in k.lower() for w in ("skill", "abilit", "perk", "crew", "progress")):
                    print(f"    [技能相关] {k} = {json.dumps(first[k], ensure_ascii=False)[:200]}")
        else:
            print("  vehicles 段形态不同:", type(veh))


if __name__ == "__main__":
    main()
