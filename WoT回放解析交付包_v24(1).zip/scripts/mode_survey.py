#!/usr/bin/env python3
"""mode_survey.py — 用户指令「只需要随机战」：11 场回放 battleType/gameplayID 归属普查
复用 survey_new_replays.py 的 load()（magic 0x11343212 + 分块 + blowfish 主流）"""
import json
import struct
import glob

def load(path):
    data = open(path, "rb").read()
    (magic, bc) = struct.unpack_from("<II", data, 0)
    assert magic == 0x11343212, hex(magic)
    pos = 8
    blocks = []
    for _ in range(bc):
        (blen,) = struct.unpack_from("<I", data, pos)
        blocks.append(data[pos + 4:pos + 4 + blen])
        pos += 4 + blen
    return blocks

# WoT battleType 常见映射（2.x 时代）:
#  1 = 随机战 (random, 含 ctfg 标准 / domination 遭遇 / assault 进攻)
#  2 = 连队, 3 = 公会战, 4 = 训练房, 7 = 七人制?, 8 = 排位?, 11/13 = 要塞/军团
GP = {
    "ctfg": "标准模式",
    "domination": "遭遇战",
    "assault": "进攻战",
    "epic": "前线",
    "fallout": "坦克大乱斗(末日)",
    "race": "竞速",
    "bob": "大逃杀(Battle Royale)",
    "event": "活动模式",
}

print("%-58s %-8s %-12s %-10s %-6s %s" % ("文件", "bt", "gameplay", "模式名", "ver#", "玩家"))
for f in sorted(glob.glob("/tmp/wot/github_test/*.wotreplay")):
    try:
        b0 = load(f)[0]
        j = json.loads(b0)
        bt = j.get("battleType")
        gp = j.get("gameplayID", "?")
        ver = j.get("clientVersionFromXml", "?").split("#")[-1].strip()
        name = j.get("playerName", "?")
        print("%-58s %-8s %-12s %-10s %-6s %s" % (
            f.split("/")[-1][:58], bt, gp, GP.get(gp, gp), ver, name))
    except Exception as e:
        print("%-58s ERR %s" % (f.split("/")[-1][:58], str(e)[:70]))
