#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
p24_deep.py — Task36①: 0x24 值段深挖（csi 分通道验证）
已知(位流白盒): 头 = [1][csi 6bits][0][slice start/end 各 w bits] → 值从整字节起
实验: csi=29 ownVehiclePosition 坐标性 / csi=34 perks 元素17B模态 / csi=33 perkEffects
"""
import struct
import sys
from collections import Counter, defaultdict

sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import REPLAYS, load_pkts  # noqa: E402
from p24_bitpath import BitReader, bits_required  # noqa: E402


def main():
    p05 = json = None
    import json as _json
    p05 = _json.load(open('/tmp/wot/p05_decoded.json'))
    eid2type = {r['eid']: r['typeName'] for r in p05}
    # 车辆名册 (拿地图名校验坐标)
    from p05_decoder import get_b0
    tag_roster = {}
    for tag, path in REPLAYS:
        b0 = get_b0(path)
        tag_roster[tag] = {v.get('avatarSessionID'): v.get('fakeName') or v.get('name')
                           for v in (b0.get('vehicles') or {}).values()}

    data = defaultdict(list)     # csi → [(tag, clk, eid, isSlice, value_bytes)]
    for tag, path in REPLAYS:
        pkts = load_pkts(path)
        for ty, c, pl in pkts:
            if ty != 0x24 or len(pl) < 10:
                continue
            eid, = struct.unpack_from('<I', pl, 0)
            is_slice = pl[4]
            body = pl[9:]
            tn = eid2type.get(eid)
            if tn != 'Vehicle' or not body:
                continue
            br = BitReader(body)
            dive = br.get(1)
            csi = br.get(bits_required(50))
            # 确定头字节数: 1+6+[1] + (isSlice? 2w : w2) bits, w 未知 → 记录全部候选
            data[csi].append((tag, c, eid, is_slice, dive, body))

    for csi in (29, 33, 34, 30):
        rows = data.get(csi, [])
        if not rows:
            continue
        print(f'\n======== csi={csi} n={len(rows)} ========')
        # 尝试 w=3 (FIXED_DICT 4 字段 → bitsRequired(5)=3): 头=14bits=2B
        for w in (3, 4, 5):
            ok = lens = Counter()
            vals = []
            for tag, clk, eid, sl, dive, body in rows:
                # 位消费 = 1+6+1 + (2w if sl else w)
                nbits = 8 + (2 * w if sl else w)
                if dive == 0:
                    nbits = 1 + 6 + (2 * w if sl else w)
                nhead = (nbits + 7) // 8
                val = body[nhead:]
                lens[len(val)] += 1
                if len(vals) < 60:
                    vals.append((tag, clk, eid, sl, dive, val))
            top3 = lens.most_common(5)
            print(f'  w={w}: 值长 top5 {top3}')
            if csi == 29 and w == 4:
                # f64@8 坐标检验
                hits = tot = 0
                xs, zs = [], []
                for tag, clk, eid, sl, dive, val in vals:
                    if len(val) >= 16:
                        tot += 1
                        x = struct.unpack_from('<d', val, 8)[0]
                        if -1000 < x < 1000:
                            hits += 1
                            xs.append(x)
                print(f'    f64@8 ∈(-1000,1000): {hits}/{tot}', end='')
                if xs:
                    print(f' 样本 {xs[:5]}')
                else:
                    print()
        # csi=34 perks: 17B 模态
        if csi == 34:
            for w in (5, 6, 7):
                lens = Counter()
                for tag, clk, eid, sl, dive, body in rows:
                    nbits = 8 + (2 * w if sl else w)
                    nhead = (nbits + 7) // 8
                    lens[len(body[nhead:])] += 1
                print(f'  perks w={w}: {lens.most_common(4)}')

    # 样本打印
    print('\n== csi=29 值段样本（头2B 假设）==')
    for tag, clk, eid, sl, dive, body in data.get(29, [])[:8]:
        val = body[2:]
        print(f'  {tag[:12]} clk={clk} eid={eid} sl={sl} dive={dive} val({len(val)})={val[:24].hex()}')
    print('\n== csi=33 perkEffects 值段样本（头2B）==')
    for tag, clk, eid, sl, dive, body in data.get(33, [])[:8]:
        val = body[2:]
        print(f'  {tag[:12]} clk={clk} eid={eid} sl={sl} dive={dive} val({len(val)})={val[:28].hex()}')


if __name__ == '__main__':
    main()
