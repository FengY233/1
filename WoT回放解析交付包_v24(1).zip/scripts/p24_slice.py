#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
p24_slice.py — Task36①: 0x24 slice 区间模式统计（区分 [a:a]/[a:b] 语义）
位头: [1][csi 6b][0][start w bits][end w bits], w=bitsRequired(leafSize+1)
csi=33 perkEffects(FIXED_DICT): w 假设 1 (1字段) → 观察 start/end 分布
csi=29 ownVehiclePosition(FIXED_DICT 4字段): w=3
csi=34 perks(ARRAY): w=bitsRequired(len+1) 变化
"""
import struct
import sys
from collections import Counter, defaultdict

sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import REPLAYS, load_pkts  # noqa: E402
from p24_bitpath import BitReader, bits_required  # noqa: E402


def main():
    import json
    p05 = json.load(open('/tmp/wot/p05_decoded.json'))
    eid2type = {r['eid']: r['typeName'] for r in p05}

    # csi → (w 假设, 说明)
    W = {29: (3, 'ownVehiclePosition 4字段'), 33: (1, 'perkEffects 1字段'),
         34: (None, 'perks ARRAY 变长'), 30: (3, 'inspired 7字段→3bits')}
    out = defaultdict(lambda: defaultdict(Counter))
    samples = defaultdict(list)
    for tag, path in REPLAYS:
        pkts = load_pkts(path)
        for ty, c, pl in pkts:
            if ty != 0x24 or len(pl) < 10:
                continue
            eid, = struct.unpack_from('<I', pl, 0)
            is_slice = pl[4]
            body = pl[9:]
            if eid2type.get(eid) != 'Vehicle' or not body:
                continue
            br = BitReader(body)
            if br.get(1) == 0:
                continue
            csi = br.get(bits_required(50))
            if csi not in (29, 30, 33, 34) or not is_slice:
                continue
            w = W[csi][0]
            if w is None:
                # perks: 扫 w=2..7 全部
                for w2 in (2, 3, 4, 5):
                    try:
                        br2 = BitReader(body)
                        br2.get(1)
                        br2.get(6)
                        s = br2.get(w2)
                        e = br2.get(w2)
                    except IndexError:
                        continue
                    nhead = (1 + 6 + 1 + 2 * w2 + 7) // 8
                    if nhead <= len(body):
                        out[34][f'w={w2}'][(s, e, len(body) - nhead)] += 1
                continue
            try:
                s = br.get(w)
                e = br.get(w)
            except IndexError:
                continue
            nhead = (8 + 2 * w + 7) // 8
            val = body[nhead:]
            out[csi]['slice'][(s, e)] += 1
            out[csi]['vlen'][(s, e, len(val))] += 1
            if len(samples[csi]) < 400:
                samples[csi].append((tag[:10], c, eid, s, e, val))

    for csi in (29, 30, 33):
        print(f'\n== csi={csi} {W[csi][1]} ==')
        print('  slice 区间:', dict(out[csi]['slice'].most_common(8)))
        print('  (s,e,值长):', dict(out[csi]['vlen'].most_common(10)))
    print('\n== csi=34 perks 各 w 假设的 (s,e,len) ==')
    for wk, cnt in out[34].items():
        print(f'  {wk}: {cnt.most_common(6)}')

    # csi=29 按 (s,e) 分组打印样本
    print('\n== csi=29 样本按区间 ==')
    seen = Counter()
    for tag, clk, eid, s, e, val in samples[29]:
        k = (s, e)
        if seen[k] < 3:
            seen[k] += 1
            print(f'  s={s} e={e} val({len(val)})={val.hex()[:44]}')
    print('\n== csi=33 样本按区间 ==')
    seen = Counter()
    for tag, clk, eid, s, e, val in samples[33]:
        k = (s, e)
        if seen[k] < 4:
            seen[k] += 1
            print(f'  s={s} e={e} val({len(val)})={val.hex()[:46]}')


if __name__ == '__main__':
    main()
