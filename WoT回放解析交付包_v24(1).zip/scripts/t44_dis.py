#!/usr/bin/env python3
"""t44_dis.py — 反汇编 0x32-0x39 写入器 thunk + getFile, 核对是否有被丢失的尾调用/转发
"""
import pefile
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

def va_to_off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

md = Cs(CS_ARCH_X86, CS_MODE_64)
md.detail = False

for name, va, n in [
    ('0x32写入器', 0x140584f80, 48),
    ('0x37写入器', 0x140584f90, 48),
    ('getFile(0x24)', 0x140587300, 96),
    ('转发器FUN_14058e4c0头', 0x14058e4c0, 64),
    ('slot33真实处理?FUN_140588ed0', 0x140588ed0, 64),
]:
    off = va_to_off(va)
    print(f'\n===== {name} @{hex(va)} =====')
    code = data[off:off+n]
    for ins in md.disasm(code, va):
        print(f'  {ins.address:#x}: {ins.mnemonic} {ins.op_str}')
        if ins.mnemonic in ('ret', 'jmp') and ins.address > va + 8:
            break
