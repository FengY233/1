#!/usr/bin/env python3
"""mid_signatures.py — methodID 跨场一致性验证

逻辑：0x05 (eid→typeID) 建立每场实体类型映射，0x08 (eid→methodID) 取方法集，
按 (typeID, methodID) 聚合 → 每个实体类型在网络层暴露的 methodID 全集跨场对比。
预期：同类型 methodID 集合跨场一致（版本恒定），场次间差异 = 玩法差异（哪些方法被调用）。
"""
import json
import struct
import sys
import zlib
from collections import defaultdict

from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])

REPLAYS = [
    ("siegfried_EU", "/tmp/wot/github_test/20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay"),
    ("karelia_EU", "/tmp/wot/github_test/20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay"),
    ("lakeville_EU", "/tmp/wot/github_test/20260907_1321_germany-G197_Pz_Kpfw_Neu_07_lakeville.wotreplay"),
    ("caucasus_NA", "/tmp/wot/github_test/20260910_1057_china-Ch67_BZ_79_37_caucasus.wotreplay"),
    ("namerica_CN", "/tmp/wot/github_test/20260911_1534_ussr-R52_Object_261_44_north_america.wotreplay"),
    ("tundra_CN_bt46", "/tmp/wot/github_test/20260911_1749_uk-GB156_Black_Prince_II_63_tundra.wotreplay"),
    ("caucasus_CN", "/tmp/wot/github_test/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay"),
    ("greatwall_EU", "/tmp/wot/github_test/20260912_1036_france-F143_Fauteur_59_asia_great_wall.wotreplay"),
    ("karelia2_EU", "/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay"),
    ("PTZ_10K_EU", "/tmp/wot/github_test/PTZ_10K.wotreplay"),
    ("WZ219_EU", "/tmp/wot/github_test/WZ-219.wotreplay"),
]

TYPE_NAMES = {3: "ArenaInfo", 6: "Vehicle", 7: "AreaDestructibles", 12: "DetachedTurret",
              13: "DebugDrawEntity", 18: "EmptyEntity", 28: "TeamInfo", 29: "AvatarInfo",
              40: "NetworkEntity"}


def load_pkts(path):
    data = open(path, "rb").read()
    (magic, bc) = struct.unpack_from("<II", data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from("<I", data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b"\x00" * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        d = cipher.decrypt(main[i:i + 8])
        d = bytes(a ^ b for a, b in zip(d, prev))
        prev = d
        out += d
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from("<III", stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


def main():
    # (typeID, methodID) → {tag: count}
    grid = defaultdict(lambda: defaultdict(int))
    # typeID → {methodID}（全集）
    tmap_all = defaultdict(set)
    for tag, path in REPLAYS:
        pkts = load_pkts(path)
        eid2type = {}
        for ty, clk, pl in pkts:
            if ty == 5 and len(pl) >= 8:
                eid, n = struct.unpack_from("<II", pl, 0)
                eid2type[eid] = n
        for ty, clk, pl in pkts:
            if ty == 8 and len(pl) >= 8:
                eid, mid = struct.unpack_from("<II", pl, 0)
                t = eid2type.get(eid, "?")
                grid[(t, mid)][tag] += 1
                tmap_all[t].add(mid)
    # 输出
    print("=== 实体类型 × methodID 跨场矩阵 ===")
    rows = []
    for (t, mid), per in sorted(grid.items(), key=lambda kv: (str(kv[0][0]), kv[0][1])):
        total = sum(per.values())
        nfields = len(per)
        rows.append({"typeID": t, "entity": TYPE_NAMES.get(t, "?"), "methodID": mid,
                     "fields": nfields, "total": total, "per": dict(per)})
        per_s = " ".join(f"{k.split('_')[0][:4]}:{v}" for k, v in sorted(per.items())[:6])
        print(f"  [{TYPE_NAMES.get(t, str(t)):16s}] mid={mid:3d}  场次={nfields:2d}/11  总计={total:5d}  {per_s}")
    print("\n=== 每类型 methodID 全集 ===")
    for t in sorted(tmap_all, key=str):
        print(f"  {TYPE_NAMES.get(t, str(t)):16s} ({t}): {sorted(tmap_all[t])}")
    with open("/tmp/wot/mid_matrix.json", "w") as f:
        json.dump(rows, f, ensure_ascii=False, indent=1)
    print("\n[saved] /tmp/wot/mid_matrix.json")


if __name__ == "__main__":
    main()
