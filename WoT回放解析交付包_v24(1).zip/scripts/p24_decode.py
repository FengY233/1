#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
p24_decode.py — Task36①: 0x24 通道全量解析（11 场）
实测结构（本轮 hex dump 破译）:
    [eid u32][msgType u8][len u32][payload × len]   ← len 恰好吃满包尾
payload 首键 u16（442/444/224/160...）→ 0x24 独立键空间（非 0-49 csi）
本轮:
  1. 结构验证: 全部 0x24 包 len 吃满率
  2. eid → 0x05 实体类型 join（车辆/非车辆键空间分离验证）
  3. 键空间: (typeName, key) 矩阵 + 每键值长度分布 + 样本值
"""
import json
import struct
import sys
from collections import Counter, defaultdict

sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import REPLAYS, load_pkts  # noqa: E402


def f32(b):
    return struct.unpack('<f', b)[0]


def f64(b):
    return struct.unpack('<d', b)[0]


def main():
    # eid → 实体类型（来自 0x05）
    p05 = json.load(open('/tmp/wot/p05_decoded.json'))
    eid2type = {}
    for r in p05:
        eid2type[r['eid']] = r['typeName']
    # 车辆 eid 集合
    veh_eids = {r['eid'] for r in p05 if r['typeID'] == 6}

    struct_ok = struct_bad = 0
    msg_types = Counter()
    # (typeName, key) → 统计
    key_n = Counter()
    key_vlen = defaultdict(Counter)     # (typeName,key) → 值长分布
    key_samples = defaultdict(list)     # (typeName,key) → 最多3个样本(payload after key)
    key_eids = defaultdict(set)         # (typeName,key) → 涉及 eid 数
    unresolved = Counter()              # join 不上的 eid 段

    for tag, path in REPLAYS:
        pkts = load_pkts(path)
        for ty, c, pl in pkts:
            if ty != 0x24 or len(pl) < 10:
                continue
            eid, = struct.unpack_from('<I', pl, 0)
            mt = pl[4]
            ln, = struct.unpack_from('<I', pl, 5)
            if 9 + ln != len(pl):
                struct_bad += 1
                continue
            struct_ok += 1
            msg_types[mt] += 1
            body = pl[9:]
            if not body:
                continue
            tn = eid2type.get(eid)
            if tn is None:
                unresolved[eid >> 20] += 1
                tn = f'eid@{eid >> 20}x'
            # payload 首键 u16 + 余下值
            if len(body) >= 2:
                key, = struct.unpack_from('<H', body, 0)
                val = body[2:]
                kk = (tn, key)
                key_n[kk] += 1
                key_vlen[kk][len(val)] += 1
                key_eids[kk].add(eid)
                if len(key_samples[kk]) < 3:
                    key_samples[kk].append(val)

    print(f'== 结构验证 ==  len 吃满 {struct_ok} / 不符 {struct_bad}')
    print(f'== msgType 分布 == {dict(msg_types)}')
    print(f'\n== join 不上的 eid 段 (eid>>20) == {dict(unresolved.most_common(6))}')

    print('\n== 键空间矩阵 (typeName × key) ==')
    by_type = defaultdict(list)
    for (tn, key), n in key_n.items():
        by_type[tn].append((key, n, len(key_eids[(tn, key)])))
    for tn in sorted(by_type, key=lambda t: -sum(x[1] for x in by_type[t])):
        rows = sorted(by_type[tn])
        tot = sum(x[1] for x in rows)
        print(f'\n--- {tn} (总 {tot} 包, {len(rows)} 键) ---')
        for key, n, neid in rows:
            vls = key_vlen[(tn, key)]
            vdist = ','.join(f'{v}B×{c}' for v, c in sorted(vls.items())[:4])
            print(f'  key={key:5d} (0x{key:04x})  n={n:4d}  eid数={neid:3d}  值长[{vdist}]')

    print('\n== 每键样本值 ==')
    for (tn, key) in sorted(key_n, key=lambda k: -key_n[k])[:25]:
        for i, v in enumerate(key_samples[(tn, key)][:2]):
            interp = []
            if len(v) == 4:
                interp.append(f'f32={f32(v):.4g}')
            elif len(v) == 8:
                interp.append(f'f64={f64(v):.6g}')
            elif len(v) >= 12:
                interp.append(f'f64@0={f64(v[:8]):.6g}')
                if len(v) >= 12:
                    interp.append(f'f32@8={f32(v[8:12]):.4g}')
            if len(v) >= 4:
                interp.append(f'u32@0={struct.unpack_from("<I", v, 0)[0]}')
            print(f'  {tn} key={key}: {v.hex()}  {"; ".join(interp)}')

    # 保存机器可读
    out = {
        'struct_ok': struct_ok, 'struct_bad': struct_bad,
        'msg_types': dict(msg_types),
        'keys': {f'{tn}|{key}': {'n': n, 'eids': len(key_eids[(tn, key)]),
                                 'vlen': dict(key_vlen[(tn, key)]),
                                 'samples': [v.hex() for v in key_samples[(tn, key)]]}
                 for (tn, key), n in key_n.items()},
    }
    json.dump(out, open('/tmp/wot/p24_keys.json', 'w'), ensure_ascii=False, indent=1)
    print('\n[saved] /tmp/wot/p24_keys.json')


if __name__ == '__main__':
    main()
