#!/usr/bin/env python3
"""pack_v15.py — V15 交付包制作 (基于 V14 + 本轮 Task 34 成果)"""
import os, zipfile, hashlib, shutil

BASE = '/home/z/my-project'
DL = f'{BASE}/download'
STAGE = '/tmp/wot/v15_stage'
PACKNAME = 'WoT回放解析交付包_v15.zip'

# 清空暂存
if os.path.exists(STAGE):
    shutil.rmtree(STAGE)
os.makedirs(STAGE)

files = []

# 1) 核心: findings v19 + worklog
files.append((f'{BASE}/findings.md', 'findings.md'))
files.append((f'{BASE}/worklog.md', 'worklog.md'))

# 2) V14 全量 (旧包解包取内容)
with zipfile.ZipFile(f'{DL}/WoT回放解析交付包_v14.zip') as z:
    for n in z.namelist():
        if n in ('findings.md', 'worklog.md'):
            continue
        files.append((None, n, z.read(n)))

# 3) data_v19 新数据
for fn in os.listdir(f'{DL}/data_v19'):
    files.append((f'{DL}/data_v19/{fn}', f'data_v19/{fn}', None))

# 4) 新脚本 (V14 后新增)
NEW_SCRIPTS = ['ext_probe.py', 'ext_dump.py', 'base_dump.py', 'ext_cluster.py',
               'veh_types.py', 'compdef_dump.py', 'comp_global.py', 'comp_table.py',
               'csi_anchor.py', 'csi_solve.py', 'tail_align.py', 'other_entities.py',
               'verify_v19.py']
for s in NEW_SCRIPTS:
    p = f'{BASE}/scripts/{s}'
    if os.path.exists(p):
        files.append((p, f'scripts/{s}', None))

# 打包
out = f'{STAGE}/{PACKNAME}'
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for item in files:
        if len(item) == 3 and item[0] is None:
            z.writestr(item[1], item[2])
        else:
            z.write(item[0], item[1])

md5 = hashlib.md5(open(out, 'rb').read()).hexdigest()
sz = os.path.getsize(out)
print(f'V15 包: {len(files)} 文件 {sz/1048576:.2f}MB md5={md5}')

# 分发
shutil.copy(out, f'{DL}/{PACKNAME}')
os.makedirs(f'{BASE}/upload/backup_v15', exist_ok=True)
shutil.copy(out, f'{BASE}/upload/backup_v15/{PACKNAME}')
shutil.copy(f'{BASE}/worklog.md', f'{BASE}/upload/backup_v15/worklog.md')
shutil.copy(f'{BASE}/findings.md', f'{BASE}/upload/backup_v15/findings_v19.md')
print('分发完成: download/ + upload/backup_v15/')

# 审计 JSON
import json
audit = {
    'version': 'v15',
    'task': '34 (会话J · 0x05 属性流终局 + MY_VEHICLE 分层 + 网络索引重排)',
    'files': len(files),
    'md5': md5,
    'size_bytes': sz,
    'findings_version': 'v19 (757 行, §15 七小节 + 附录 K)',
    'worklog_lines': len(open(f'{BASE}/worklog.md').readlines()),
    'new_scripts': len(NEW_SCRIPTS),
    'new_data': ['data_v19/network_idx_remap_v19.json'],
    'key_results': [
        '0x05 属性流 vanilla 纯格式四实体铁证 (NetworkEntity count=3 逐字节)',
        '线编码规则全集 (packedInt/FD allow_none/定长 TUPLE 直出)',
        'MY_VEHICLE 分层: 10 属性本车专属 (DetailLevel 标签)',
        '网络 idx 重排: vpp=40 (754/754 零偏差), 0x05/0x07 双空间',
        'alias AllowNone 97/202 (defparse 漏读)',
        '组件注册表 16+113, 85 组件 185 CS 属性',
        '同型车扩展区模板恒定 33%',
    ],
}
json.dump(audit, open(f'{DL}/覆盖度终审_v15_audit.json', 'w'), ensure_ascii=False, indent=1)
print('审计: download/覆盖度终审_v15_audit.json')
