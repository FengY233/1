#!/usr/bin/env python3
"""veh05_decl.py — Vehicle 全属性声明序索引表 + 0x05 创建块重解析
假设: 0x05 条目索引 = properties_ 数组位(含非CS), 0x07 键 = csi(仅CS排序)
值编码: 定长=裸字节; AllowNone 类型=[u8 flag][值?]; 变长=[头][数据]"""
import json, struct, zlib, sys, os
sys.path.insert(0, '/home/z/my-project/scripts')
from defparse import EntityDefParser
from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])
SCRIPTS = '/tmp/wot_scripts/scripts'


def load_pkts(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from('<I', data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b'\x00' * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        d = cipher.decrypt(main[i:i + 8])
        d = bytes(a ^ b for a, b in zip(d, prev))
        prev = d
        out += d
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from('<III', stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


def main():
    parser = EntityDefParser(SCRIPTS)
    parser.load()
    ed = next(e for e in parser.entities if e.name == 'Vehicle')
    print(f'Vehicle 全属性 {len(ed.properties)} 个:')
    decl = []
    for i, p in enumerate(ed.properties):
        ss = p.stream_size()
        decl.append((i, p.name, ss, p.is_client_server, p.csi,
                     p.dt.kind if p.dt else '?',
                     getattr(p, 'var_len_header', 1)))
        print(f'  decl#{i:2d} csi={p.csi:2d} cs={int(p.is_client_server)} '
              f'ss={ss:4d} {p.dt.kind:10s} vlh={getattr(p,"var_len_header",1)} {p.name}')
    # 声明索引 → (ss, kind, vlh)
    bydecl = {i: (ss, k, vlh) for i, nm, ss, cs, csi, k, vlh in decl
              for i in [i]}
    json.dump([{'decl': i, 'name': nm, 'ss': ss, 'cs': cs, 'csi': csi,
                'kind': k, 'vlh': vlh} for i, nm, ss, cs, csi, k, vlh in decl],
              open('/tmp/wot/veh_decl_table.json', 'w'), indent=1)

    RP = '/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay'
    pkts = load_pkts(RP)
    veh = [pl for ty, c, pl in pkts if ty == 5 and len(pl) >= 47
           and struct.unpack_from('<I', pl, 4)[0] == 6]

    def value_size(pl, q, ss, kind, vlh):
        """返回 (nbytes, ok)"""
        if ss > 0:
            return (ss, q + ss <= len(pl))
        # 变长: [vlh 字节长度][数据]
        if q + vlh > len(pl):
            return (0, False)
        n = int.from_bytes(pl[q:q + vlh], 'little')
        return (vlh + n, q + vlh + n <= len(pl))

    ok = 0
    for pl in veh:
        propBytes, = struct.unpack_from('<I', pl, 42)
        if 46 + propBytes != len(pl):
            continue
        q = 46
        count = pl[q]; q += 1
        ents = []
        good = True
        for i in range(count):
            if q >= len(pl):
                good = False; break
            idx = pl[q]; q += 1
            if idx not in bydecl:
                good = False; break
            ss, k, vlh = bydecl[idx]
            n, okk = value_size(pl, q, ss, k, vlh)
            if not okk:
                good = False; break
            ents.append((idx, pl[q:q + n].hex()))
            q += n
        if good and q == len(pl):
            ok += 1
            if ok <= 2:
                print(f'\n★ 走通: len={len(pl)} count={count}')
                for idx, v in ents:
                    ss, k, vlh = bydecl[idx]
                    print(f'   decl#{idx:2d} ss={ss:4d} {k:10s} {v}')
    print(f'\n声明索引口径: {ok}/{len(veh)} 走通')


if __name__ == '__main__':
    main()
