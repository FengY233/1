#!/usr/bin/env python3
"""p07_keybody.py — Task35: 0x07 指定 key 的 body 全量采集 (判别 idx 空间模型)
用法: python3 p07_keybody.py <key> [max_show]
"""
import struct, sys
from collections import Counter
from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])

REPLAYS = [
    ("siegfried_EU_935", "/tmp/wot/github_test/20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay"),
    ("karelia_EU_935", "/tmp/wot/github_test/20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay"),
    ("lakeville_EU_935", "/tmp/wot/github_test/20260907_1321_germany-G197_Pz_Kpfw_Neu_07_lakeville.wotreplay"),
    ("caucasus_NA_945", "/tmp/wot/github_test/20260910_1057_china-Ch67_BZ_79_37_caucasus.wotreplay"),
    ("namerica_CN_942", "/tmp/wot/github_test/20260911_1534_ussr-R52_Object_261_44_north_america.wotreplay"),
    ("caucasus_CN_942", "/tmp/wot/github_test/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay"),
    ("greatwall_EU_944", "/tmp/wot/github_test/20260912_1036_france-F143_Fauteur_59_asia_great_wall.wotreplay"),
    ("karelia2_EU_944", "/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay"),
    ("PTZ_EU_944", "/tmp/wot/github_test/PTZ_10K.wotreplay"),
    ("WZ219_EU_944", "/tmp/wot/github_test/WZ-219.wotreplay"),
]


def load_pkts(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from('<I', data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b'\x00' * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        dd = cipher.decrypt(main[i:i + 8])
        dd = bytes(a ^ b for a, b in zip(dd, prev))
        prev = dd
        out += dd
    import zlib
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from('<III', stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


def main():
    key = int(sys.argv[1])
    max_show = int(sys.argv[2]) if len(sys.argv) > 2 else 12
    bodies = Counter()
    per_tag = {}
    for tag, path in REPLAYS:
        pkts = load_pkts(path)
        n = 0
        for ty, c, pl in pkts:
            if ty != 7 or len(pl) < 12:
                continue
            eid, k, blen = struct.unpack_from('<III', pl, 0)
            if k != key:
                continue
            body = pl[12:12 + blen]
            bodies[body.hex()] += 1
            per_tag.setdefault(tag, []).append(body.hex())
            n += 1
    print(f'key={key} 总更新 {sum(bodies.values())}, 不同 body {len(bodies)}')
    for b, c in bodies.most_common(max_show):
        print(f'  {b}  ×{c}')
    print('\n按场次前3:')
    for tag, bs in per_tag.items():
        print(f'  {tag}: {len(bs)} 次, 样例 {bs[:3]}')


if __name__ == '__main__':
    main()
