#!/usr/bin/env python3
"""pp_skill_roster.py — vehPostProgression(车辆特殊技能) 跨 11 场名册 + 0x39 关联分析

发现: block1 data[1][dbid] 含 vehPostProgression 字段(技能ID列表) = 用户所说"车的技能"
目标: ①每场多少车带技能 ②带技能车是否与 0x39 出现相关 ③技能ID清单
"""
import json
import struct
from collections import Counter

REPLAYS = [
    ("siegfried_EU_39", "/tmp/wot/github_test/20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay"),
    ("karelia_EU_39", "/tmp/wot/github_test/20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay"),
    ("lakeville_EU_0", "/tmp/wot/github_test/20260907_1321_germany-G197_Pz_Kpfw_Neu_07_lakeville.wotreplay"),
    ("caucasus_NA_0", "/tmp/wot/github_test/20260910_1057_china-Ch67_BZ_79_37_caucasus.wotreplay"),
    ("namerica_CN_0", "/tmp/wot/github_test/20260911_1534_ussr-R52_Object_261_44_north_america.wotreplay"),
    ("tundra_CN_0", "/tmp/wot/github_test/20260911_1749_uk-GB156_Black_Prince_II_63_tundra.wotreplay"),
    ("caucasus_CN942_0", "/tmp/wot/github_test/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay"),
    ("greatwall_EU_0", "/tmp/wot/github_test/20260912_1036_france-F143_Fauteur_59_asia_great_wall.wotreplay"),
    ("karelia2_EU_39", "/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay"),
    ("PTZ_10K_EU_0", "/tmp/wot/github_test/PTZ_10K.wotreplay"),
    ("WZ219_EU_39", "/tmp/wot/github_test/WZ-219.wotreplay"),
]

# 0x39 计数(已知)
N39 = {"siegfried_EU_39": 30, "karelia_EU_39": 5832, "lakeville_EU_0": 0,
       "caucasus_NA_0": 0, "namerica_CN_0": 0, "tundra_CN_0": 0,
       "caucasus_CN942_0": 0, "greatwall_EU_0": 0, "karelia2_EU_39": 4762,
       "PTZ_10K_EU_0": 0, "WZ219_EU_39": 6304}


def get_blocks(path):
    data = open(path, "rb").read()
    (magic, bc) = struct.unpack_from("<II", data, 0)
    pos = 8
    blocks = []
    for _ in range(bc):
        (blen,) = struct.unpack_from("<I", data, pos)
        blocks.append(data[pos + 4:pos + 4 + blen])
        pos += 4 + blen
    return blocks


def main():
    all_skill_ids = Counter()
    for tag, path in REPLAYS:
        blocks = get_blocks(path)
        if len(blocks) < 2 or not blocks[1]:
            print(f"{tag}: block1 空")
            continue
        data = json.loads(blocks[1])
        d1 = data[1]
        pp_count = 0
        skills = []
        veh_types = {}
        for dbid, v in d1.items():
            pp = v.get("vehPostProgression") or []
            if pp:
                pp_count += 1
                skills.extend(pp)
        # 车型名: 找 data[1] 里可能的字段
        sample = list(d1.values())[0]
        n39 = N39.get(tag, -1)
        print(f"\n===== {tag} | 0x39={n39} =====")
        print(f"  带 vehPostProgression 的车: {pp_count}/{len(d1)}")
        print(f"  技能ID: {sorted(set(skills))}")
        for s in set(skills):
            all_skill_ids[s] += skills.count(s)
        # 其他可能相关字段
        extra_fields = [k for k in sample if any(w in k.lower() for w in
                        ("progress", "skill", "abilit", "directives", "boost"))]
        print(f"  相关字段名: {extra_fields}")
        for k in extra_fields:
            vals = [v.get(k) for v in d1.values() if v.get(k)]
            print(f"    {k}: 非空 {len(vals)}/{len(d1)} 样例{vals[:3]}")
    print("\n===== 跨场技能ID 汇总 =====")
    for sid, n in sorted(all_skill_ids.items()):
        print(f"  {sid}: 出现 {n} 次")


if __name__ == "__main__":
    main()
