#!/usr/bin/env python3
"""t44_child.py — 找 WGReplayMessageHandler vtable 的 .text 引用(构造函数)
     → child handler 注册点 → child vtable → 0x32/0x37 真正的解析函数
"""
import pefile, struct

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

def va_to_off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress) if s.PointerToRawData else None
    return None

def off_to_va(off):
    for s in pe.sections:
        if s.PointerToRawData and s.PointerToRawData <= off < s.PointerToRawData + s.SizeOfRawData:
            return imgbase + s.VirtualAddress + (off - s.PointerToRawData)
    return None

VT = 0x1436066e8
# lea 指令引用: 48 8d 05 xx xx xx xx (lea rax,[rip+X]) / 48 8d 0d (rcx) / 48 8d 15 (rdx)...
print('=== 搜索 vtable VA 的 rip 相对引用 ===')
hits = []
for i in range(len(data) - 7):
    if data[i] == 0x48 and data[i+1] == 0x8d and data[i+2] in (0x05, 0x0d, 0x15, 0x1d, 0x25, 0x2d, 0x35, 0x3d):
        disp = struct.unpack('<i', data[i+3:i+7])[0]
        va = off_to_va(i)
        if va is None:
            continue
        target = va + 7 + disp
        if target == VT:
            hits.append((va, i, data[i+2]))
print(f'共 {len(hits)} 处引用:')
for va, off, modrm in hits:
    print(f'  @{hex(va)} (file {hex(off)}) lea reg, [WG_vtable]  modrm={hex(modrm)}')

# 也搜绝对地址引用 (mov reg, imm64)
pat = struct.pack('<Q', VT)
off = 0
print('\n=== 搜索 vtable VA 绝对值(qword) ===')
while True:
    i = data.find(pat, off)
    if i < 0:
        break
    va = off_to_va(i)
    if va and 0x140001000 <= va < 0x135b452c + 0x140001000:  # .text 内
        print(f'  .text @{hex(va)}')
    off = i + 1
