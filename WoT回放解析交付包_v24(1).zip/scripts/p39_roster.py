#!/usr/bin/env python3
"""p39_roster.py — 0x39 出现场 vs 零出现场的对局构成对比（block1 车辆名册解码）

目的: 找出 0x39 包(仅 4 场 EU: karelia×2/WZ-219/siegfried30个)的出现条件
  - SPG 数量? 特定车辆? 十一级车技能? 地图?
block1 = zlib 压缩的 packed section (RJSON), 尝试解压后 grep 车辆标记
"""
import struct
import zlib
import re
import sys

REPLAYS = [
    ("siegfried_EU_39", "/tmp/wot/github_test/20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay"),
    ("karelia_EU_39", "/tmp/wot/github_test/20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay"),
    ("lakeville_EU_0", "/tmp/wot/github_test/20260907_1321_germany-G197_Pz_Kpfw_Neu_07_lakeville.wotreplay"),
    ("caucasus_NA_0", "/tmp/wot/github_test/20260910_1057_china-Ch67_BZ_79_37_caucasus.wotreplay"),
    ("namerica_CN_0", "/tmp/wot/github_test/20260911_1534_ussr-R52_Object_261_44_north_america.wotreplay"),
    ("tundra_CN_0", "/tmp/wot/github_test/20260911_1749_uk-GB156_Black_Prince_II_63_tundra.wotreplay"),
    ("caucasus_CN942_0", "/tmp/wot/github_test/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay"),
    ("greatwall_EU_0", "/tmp/wot/github_test/20260912_1036_france-F143_Fauteur_59_asia_great_wall.wotreplay"),
    ("karelia2_EU_39", "/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay"),
    ("PTZ_10K_EU_0", "/tmp/wot/github_test/PTZ_10K.wotreplay"),
    ("WZ219_EU_39", "/tmp/wot/github_test/WZ-219.wotreplay"),
]


def get_blocks(path):
    data = open(path, "rb").read()
    (magic, bc) = struct.unpack_from("<II", data, 0)
    pos = 8
    blocks = []
    for _ in range(bc):
        (blen,) = struct.unpack_from("<I", data, pos)
        blocks.append(data[pos + 4:pos + 4 + blen])
        pos += 4 + blen
    return blocks


def try_decode_block1(b1):
    """block1: 尝试 zlib 解压, 输出原始文本片段"""
    try:
        raw = zlib.decompress(b1)
        return raw
    except Exception:
        return None


def main():
    for tag, path in REPLAYS:
        blocks = get_blocks(path)
        b1 = blocks[1] if len(blocks) > 1 else b""
        raw = try_decode_block1(b1)
        print(f"\n===== {tag} (block1 {len(b1)}B) =====")
        if raw is None:
            print("  [zlib 解压失败] 头16B:", b1[:16].hex())
            continue
        print(f"  解压后 {len(raw)}B, 头32B: {raw[:32].hex()}")
        # 找车辆名(nation-vehName 内部名格式)
        vehs = set(re.findall(rb"[a-z]{4,12}-[A-Z][A-Za-z0-9_]{2,20}", raw))
        vehs = sorted(v.decode() for v in vehs if b"-" in v)
        print(f"  车辆标记 {len(vehs)} 个: {vehs[:40]}")
        # SPG 判定线索: internal name 含 SPG 的很少; 查 "SPG"/"artillery" 字样
        for kw in (b"SPG", b"spg", b"artiller"):
            n = raw.count(kw)
            if n:
                print(f"  关键字 {kw!r}: {n} 次")


if __name__ == "__main__":
    main()
