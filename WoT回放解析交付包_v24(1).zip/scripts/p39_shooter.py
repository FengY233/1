#!/usr/bin/env python3
"""p39_shooter.py — 0x39 精细轨迹: 单射手 vs 多射手判别 + 射手身份定位

方法:
  1) 全量 72B 轨迹: 相邻包位移直方图, >50m 瞬移计数(=射手切换), 中位速度
  2) 瞬移分段: 每段起点接近某 0x05 车辆出生点? (位置匹配半径 30m)
  3) 段内 |dir| 是否恒定(同一门炮)
  4) 与 41B(0x25) 子型的时序关系
"""
import math
import struct
import zlib
from collections import Counter

from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])

SRC = {
    "karelia_EU": "/tmp/wot/github_test/20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay",
    "WZ219_EU": "/tmp/wot/github_test/WZ-219.wotreplay",
}


def load_pkts(path):
    data = open(path, "rb").read()
    (magic, bc) = struct.unpack_from("<II", data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from("<I", data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b"\x00" * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        d = cipher.decrypt(main[i:i + 8])
        d = bytes(a ^ b for a, b in zip(d, prev))
        prev = d
        out += d
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from("<III", stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


def main():
    for tag, path in SRC.items():
        pkts = load_pkts(path)
        # 0x05 车辆出生点
        spawns = []
        for ty, clk, pl in pkts:
            if ty == 5 and len(pl) >= 30:
                eid, n = struct.unpack_from("<II", pl, 0)
                if n == 6:
                    try:
                        x, y, z = struct.unpack_from("<fff", pl, 18)
                        spawns.append((eid, x, y, z))
                    except Exception:
                        pass
        p72 = [(c, p) for ty, c, p in pkts if ty == 0x39 and len(p) == 72]
        print(f"\n########## {tag}: 72B={len(p72)} 车辆出生点={len(spawns)} ##########")
        # 轨迹分段
        segs = []
        cur = []
        for clk, pl in p72:
            x, y, z = struct.unpack_from("<fff", pl, 42)
            seq, = struct.unpack_from("<I", pl, 15)
            spd = math.sqrt(sum(v * v for v in struct.unpack_from("<fff", pl, 54)))
            if cur:
                lx, ly, lz = cur[-1][2], cur[-1][3], cur[-1][4]
                if math.dist((x, y, z), (lx, ly, lz)) > 50:
                    segs.append(cur)
                    cur = []
            cur.append((clk, seq, x, y, z, spd))
        segs.append(cur)
        print(f"轨迹分段数(>50m 瞬移): {len(segs)}")
        for i, s in enumerate(segs):
            (c0, q0, x0, y0, z0, sp0) = s[0]
            (c1, q1, x1, y1, z1, sp1) = s[-1]
            # 起点匹配出生点
            near = [e for e, sx, sy, sz in spawns
                    if math.dist((x0, y0, z0), (sx, sy, sz)) < 40]
            # 段内速度值集合
            spds = sorted(set(round(p[5]) for p in s))
            dur = (c1 - c0)
            # 段内移动总程
            pathlen = sum(math.dist(s[i][2:5], s[i + 1][2:5]) for i in range(len(s) - 1))
            print(f"  段{i}: n={len(s):5d} clk={c0}..{c1} 起点({x0:7.1f},{y0:5.1f},{z0:7.1f}) "
                  f"炮速={spds} 路程={pathlen:7.1f}m 近出生点eid={near[:4]}")
        # 相邻包位移直方图(段内)
        allp = [(struct.unpack_from('<fff', p, 42)) for c, p in p72]
        dd = [math.dist(a, b) for a, b in zip(allp, allp[1:])]
        buckets = Counter()
        for d in dd:
            buckets['<0.5' if d < 0.5 else '<2' if d < 2 else '<10' if d < 10 else '<50' if d < 50 else '>=50'] += 1
        print("相邻位移分布:", dict(buckets))
        # 41B 时序: 是否落在段边界附近
        p41 = [c for ty, c, p in pkts if ty == 0x39 and len(p) == 41]
        if p41 and segs:
            seg_starts = [s[0][0] for s in segs]
            matched = sum(1 for c in p41
                          if any(abs(c - s0) < 30000 for s0 in seg_starts))
            print(f"41B 包落在段起点±30k clk 内: {matched}/{len(p41)}")


if __name__ == "__main__":
    main()
