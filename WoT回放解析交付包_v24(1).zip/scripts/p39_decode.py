#!/usr/bin/env python3
"""p39_decode.py — 0x39 包载荷结构解析（外服独有包型）

出现场: karelia_EU(5832) / karelia2_EU(4762) / WZ-219(6304) / siegfried_EU(仅30)
零出现: 全部 CN/NA 场 + lakeville/greatwall/PTZ_10K
假设检验:
  H1: 0x39 与 eid 关联（载荷含 eid 且命中 0x05 实体表）→ 实体级事件
  H2: 载荷结构 = 固定头 + 变体 → 语义通道
  H3: 出现时间分布（clk 聚簇 or 均匀）→ 触发式 or 持续式
"""
import struct
import sys
import zlib
from collections import Counter, defaultdict

from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])

SRC = {
    "karelia_EU": "/tmp/wot/github_test/20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay",
    "karelia2_EU": "/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay",
    "WZ219_EU": "/tmp/wot/github_test/WZ-219.wotreplay",
    "siegfried_EU": "/tmp/wot/github_test/20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay",
}


def load_pkts(path):
    data = open(path, "rb").read()
    (magic, bc) = struct.unpack_from("<II", data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from("<I", data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b"\x00" * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        d = cipher.decrypt(main[i:i + 8])
        d = bytes(a ^ b for a, b in zip(d, prev))
        prev = d
        out += d
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from("<III", stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


def analyze(tag, path):
    pkts = load_pkts(path)
    eid2type = {}
    for ty, clk, pl in pkts:
        if ty == 5 and len(pl) >= 8:
            eid, n = struct.unpack_from("<II", pl, 0)
            eid2type[eid] = n
    p39 = [(clk, pl) for ty, clk, pl in pkts if ty == 0x39]
    print(f"\n===== {tag}: n39={len(p39)} =====")
    if not p39:
        return
    # 长度分布
    print("len_hist:", dict(Counter(len(pl) for _, pl in p39).most_common(10)))
    # 首 4 字节作为 u32 直方图 —— 看是否是 eid
    first_u32 = Counter(struct.unpack_from("<I", pl, 0)[0] for _, pl in p39 if len(pl) >= 4)
    print("first_u32 top10:", [(hex(k), v) for k, v in first_u32.most_common(10)])
    # 命中 eid 表?
    hits = sum(v for k, v in first_u32.items() if k in eid2type)
    veh_hits = sum(v for k, v in first_u32.items() if eid2type.get(k) == 6)
    print(f"first_u32 命中 0x05 实体表: {hits}/{sum(first_u32.values())} (其中 Vehicle: {veh_hits})")
    # 载荷样例
    for i, (clk, pl) in enumerate(p39[:6]):
        e = struct.unpack_from("<I", pl, 0)[0] if len(pl) >= 4 else -1
        print(f"  [{i}] clk={clk} len={len(pl)} eid_guess={e}({eid2type.get(e,'?')}) hex={pl.hex()[:96]}")
    # clk 分布: 首末包与总时长
    clks = sorted(c for c, _ in p39)
    if len(clks) > 2:
        span = clks[-1] - clks[0]
        print(f"clk span: {clks[0]}..{clks[-1]} ({span})  n={len(clks)}")
        # 聚簇度: 分 10 桶
        buckets = [0] * 10
        for c in clks:
            b = min(9, (c - clks[0]) * 10 // max(1, span))
            buckets[b] += 1
        print("时间分布(10桶):", buckets)
    # 长度>4 时的第 5-8 字节
    b58 = Counter(pl[4:8].hex() for _, pl in p39 if len(pl) >= 8)
    print("bytes[4:8] top8:", b58.most_common(8))
    # 与 0x08 的 mid 对齐检查: 若 0x39 与 0x08 同 eid 同 clk, 可能是方法回包
    p08 = defaultdict(set)
    for ty, clk, pl in pkts:
        if ty == 8 and len(pl) >= 8:
            e, m = struct.unpack_from("<II", pl, 0)
            p08[e].add(m)
    inter = sum(1 for k in first_u32 if k in p08)
    print(f"first_u32 ∩ 0x08 eid 集: {inter}/{len(first_u32)}")


def main():
    for tag, path in SRC.items():
        analyze(tag, path)


if __name__ == "__main__":
    main()
