#!/usr/bin/env python3
"""veh05_join.py — Vehicle 0x05 载荷 ↔ block0 名册 join (avatarID u32 搜索)
输出: 每场每车的 (车型, vpp技能, 载荷长, 载荷) → 技能/乘员属性定位分析的地基"""
import json, struct, zlib, re
from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])

REPLAYS = [
    ("siegfried_EU", "/tmp/wot/github_test/20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay"),
    ("karelia_EU", "/tmp/wot/github_test/20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay"),
    ("lakeville_EU", "/tmp/wot/github_test/20260907_1321_germany-G197_Pz_Kpfw_Neu_07_lakeville.wotreplay"),
    ("caucasus_NA", "/tmp/wot/github_test/20260910_1057_china-Ch67_BZ_79_37_caucasus.wotreplay"),
    ("namerica_CN", "/tmp/wot/github_test/20260911_1534_ussr-R52_Object_261_44_north_america.wotreplay"),
    ("tundra_CN_bt46", "/tmp/wot/github_test/20260911_1749_uk-GB156_Black_Prince_II_63_tundra.wotreplay"),
    ("caucasus_CN942", "/tmp/wot/github_test/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay"),
    ("greatwall_EU", "/tmp/wot/github_test/20260912_1036_france-F143_Fauteur_59_asia_great_wall.wotreplay"),
    ("karelia2_EU", "/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay"),
    ("PTZ_10K_EU", "/tmp/wot/github_test/PTZ_10K.wotreplay"),
    ("WZ219_EU", "/tmp/wot/github_test/WZ-219.wotreplay"),
]

SHOOTERS = {"karelia_EU": 8332904, "WZ219_EU": 543485522,
            "karelia2_EU": 539312076, "siegfried_EU": 550629014}


def load_pkts(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from('<I', data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b'\x00' * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        d = cipher.decrypt(main[i:i + 8])
        d = bytes(a ^ b for a, b in zip(d, prev))
        prev = d
        out += d
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from('<III', stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


def get_b0(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos = 8
    (blen,) = struct.unpack_from('<I', data, pos)
    return json.loads(data[pos + 4:pos + 4 + blen])


def main():
    out = {}
    for tag, path in REPLAYS:
        b0 = get_b0(path)
        roster = b0.get('vehicles') or {}
        # avatarSessionID(u32) → 名册条目
        id2ent = {}
        for dbid, v in roster.items():
            sid = v.get('avatarSessionID')
            if sid:
                id2ent[int(sid)] = v
        pkts = load_pkts(path)
        veh = []
        for ty, clk, pl in pkts:
            if ty == 5 and len(pl) >= 8:
                eid, n = struct.unpack_from('<II', pl, 0)
                if n == 6:
                    # 在载荷中找 avatarID: 搜索所有名册 u32
                    hits = []
                    for aid in id2ent:
                        if struct.pack('<I', aid) in pl:
                            hits.append(aid)
                    veh.append({'eid': eid, 'len': len(pl),
                                'aid_hits': hits, 'hex': pl.hex()})
        # join 结果统计
        joined = sum(1 for v in veh if len(v['aid_hits']) == 1)
        multi = sum(1 for v in veh if len(v['aid_hits']) > 1)
        zero = sum(1 for v in veh if not v['aid_hits'])
        print(f'{tag}: Vehicle×{len(veh)} join: 唯一={joined} 多命中={multi} 零={zero}')
        # 0x39 源头车身份
        sh = SHOOTERS.get(tag)
        if sh:
            sv = next((v for v in veh if v['eid'] == sh), None)
            if sv and len(sv['aid_hits']) == 1:
                ent = id2ent[sv['aid_hits'][0]]
                print(f'   ★0x39源头: eid={sh} 玩家={ent.get("name")} '
                      f'车型={ent.get("vehicleType")} '
                      f'vpp={ent.get("vehPostProgression")} '
                      f'pet={ent.get("activePetID")} hp={ent.get("maxHealth")}')
            else:
                print(f'   0x39源头 eid={sh} 未join到名册 hits={sv["aid_hits"] if sv else None}')
        # 保存(截断hex, 后续分析用原始)
        for v in veh:
            v['hex'] = v['hex'][:200000]
        out[tag] = {
            'roster_ids': sorted(id2ent.keys()),
            'vehicles': [{k: v[k] for k in ('eid', 'len', 'aid_hits')} for v in veh],
        }
        # 附带: 名册完整镜像
        out[tag]['roster'] = {str(k): {'vehicleType': w.get('vehicleType'),
                                       'name': w.get('name'),
                                       'vehPostProgression': w.get('vehPostProgression'),
                                       'prestigeLevel': w.get('prestigeLevel'),
                                       'maxHealth': w.get('maxHealth'),
                                       'team': w.get('team'),
                                       'activePetID': w.get('activePetID')}
                              for k, w in id2ent.items()}
    json.dump(out, open('/tmp/wot/veh05_join.json', 'w'), ensure_ascii=False)
    print('\n[saved] /tmp/wot/veh05_join.json')


if __name__ == '__main__':
    main()
