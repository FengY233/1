#!/usr/bin/env python3
"""mid_signatures2.py — 未识别 eid 段分析 + ArenaInfo eid 定位

问题：大量 0x08 的 eid 不在 0x05 映射里（回放开始前已存在的实体，如 ArenaInfo/Avatar）。
手段：
  1. 每场 typeID=3 的 eid vs mid=58(updateArena) 的 eid —— 是否同一实体
  2. 未识别 eid 的 16 位段分布（BigWorld eid 分配有段结构）
  3. 每个未识别 eid 的 methodID 签名（跨场稳定性）
"""
import struct
import sys
import zlib
from collections import Counter, defaultdict

from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])

REPLAYS = [
    ("siegfried_EU", "/tmp/wot/github_test/20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay"),
    ("karelia_EU", "/tmp/wot/github_test/20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay"),
    ("lakeville_EU", "/tmp/wot/github_test/20260907_1321_germany-G197_Pz_Kpfw_Neu_07_lakeville.wotreplay"),
    ("caucasus_NA", "/tmp/wot/github_test/20260910_1057_china-Ch67_BZ_79_37_caucasus.wotreplay"),
    ("namerica_CN", "/tmp/wot/github_test/20260911_1534_ussr-R52_Object_261_44_north_america.wotreplay"),
    ("tundra_CN_bt46", "/tmp/wot/github_test/20260911_1749_uk-GB156_Black_Prince_II_63_tundra.wotreplay"),
    ("caucasus_CN", "/tmp/wot/github_test/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay"),
    ("greatwall_EU", "/tmp/wot/github_test/20260912_1036_france-F143_Fauteur_59_asia_great_wall.wotreplay"),
    ("karelia2_EU", "/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay"),
    ("PTZ_10K_EU", "/tmp/wot/github_test/PTZ_10K.wotreplay"),
    ("WZ219_EU", "/tmp/wot/github_test/WZ-219.wotreplay"),
]


def load_pkts(path):
    data = open(path, "rb").read()
    (magic, bc) = struct.unpack_from("<II", data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from("<I", data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b"\x00" * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        d = cipher.decrypt(main[i:i + 8])
        d = bytes(a ^ b for a, b in zip(d, prev))
        prev = d
        out += d
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from("<III", stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


def main():
    for tag, path in REPLAYS:
        pkts = load_pkts(path)
        eid2type = {}
        for ty, clk, pl in pkts:
            if ty == 5 and len(pl) >= 8:
                eid, n = struct.unpack_from("<II", pl, 0)
                eid2type[eid] = n
        # typeID=3 / 28 / 29 的 eid
        t3 = [e for e, t in eid2type.items() if t == 3]
        t28 = [e for e, t in eid2type.items() if t == 28]
        t29 = [e for e, t in eid2type.items() if t == 29]
        # 0x08 未识别 eid
        unk_sigs = defaultdict(set)
        for ty, clk, pl in pkts:
            if ty == 8 and len(pl) >= 8:
                eid, mid = struct.unpack_from("<II", pl, 0)
                if eid not in eid2type:
                    unk_sigs[eid].add(mid)
        print(f"\n=== {tag}")
        print(f"  0x05 typeID=3 eid: {[hex(x) for x in t3]}  typeID=28: {[hex(x) for x in t28]}  typeID=29: {[hex(x) for x in t29]}")
        print(f"  未识别 0x08 eid 共 {len(unk_sigs)} 个:")
        for e in sorted(unk_sigs):
            print(f"    eid={e:#010x} ({e:10d})  mids={sorted(unk_sigs[e])}")


if __name__ == "__main__":
    main()
