#!/usr/bin/env python3
"""veh05_layout.py — Vehicle 0x05 载荷布局锚定
锚: position(3f) / avatarID(u32=roster avatarSessionID, csi16) / health(u16=roster maxHealth, csi14)
推导: 固定属性段起点 + 变长属性段(31-49)逐项边界"""
import json, struct, zlib
from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])
RP = '/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay'


def load_pkts(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from('<I', data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b'\x00' * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        d = cipher.decrypt(main[i:i + 8])
        d = bytes(a ^ b for a, b in zip(d, prev))
        prev = d
        out += d
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from('<III', stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


def get_b0(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos = 8
    (blen,) = struct.unpack_from('<I', data, pos)
    return json.loads(data[pos + 4:pos + 4 + blen])


def main():
    b0 = get_b0(RP)
    roster = {}
    for dbid, v in (b0.get('vehicles') or {}).items():
        sid = v.get('avatarSessionID')
        if sid:
            roster[int(sid)] = v
    pkts = load_pkts(RP)
    veh = []
    for ty, clk, pl in pkts:
        if ty == 5 and len(pl) >= 8:
            eid, n = struct.unpack_from('<II', pl, 0)
            if n == 6:
                veh.append(pl)
    print(f'Vehicle 0x05 × {len(veh)}')

    # 锚点统计
    from collections import Counter
    aid_offs, hp_offs = Counter(), Counter()
    ok = 0
    for pl in veh:
        hits = [(aid, pl.find(struct.pack('<I', aid))) for aid in roster
                if struct.pack('<I', aid) in pl]
        if len(hits) != 1:
            continue
        aid, off = hits[0]
        hp = roster[aid].get('maxHealth')
        aid_offs[off] += 1
        # health u16 搜索(限定在 aid 前后)
        for ho in range(max(0, off - 12), off):
            if struct.unpack_from('<H', pl, ho)[0] == hp:
                hp_offs[ho] += 1
                break
        ok += 1
    print(f'join ok={ok}')
    print('avatarID 偏移分布:', dict(aid_offs.most_common(6)))
    print('health 偏移分布(相对搜索窗):', dict(hp_offs.most_common(8)))

    # 对前3个载荷: 详细 dump 头 60B + 变长段
    for pl in veh[:3]:
        eid, n = struct.unpack_from('<II', pl, 0)
        hits = [aid for aid in roster if struct.pack('<I', aid) in pl]
        r = roster[hits[0]] if len(hits) == 1 else {}
        print(f'\n--- eid={eid} len={len(pl)} 车型={r.get("vehicleType")} '
              f'vpp={r.get("vehPostProgression")} ---')
        print('  head:', pl[:8].hex())
        print('  transform区[8:42]:', pl[8:42].hex())
        print('  [42:60]:', pl[42:60].hex())
        aid = hits[0] if len(hits) == 1 else None
        if aid:
            off = pl.find(struct.pack('<I', aid))
            print(f'  avatarID@{off}')
            print(f'  [aid_off-20:aid_off+40]:', pl[max(0,off-20):off+40].hex())
        print('  尾部[-90:]:', pl[-90:].hex())


if __name__ == '__main__':
    main()
