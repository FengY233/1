#!/usr/bin/env python3
"""尝试用用户提供的密码打开 dec.7z（AES 加密分卷合并版）并列出内容"""
import sys, io

import py7zr

ARC = "/tmp/wot/dec.7z"
PWD = "114514.1919810"

def main():
    try:
        with py7zr.SevenZipFile(ARC, mode="r", password=PWD) as z:
            names = z.getnames()
            print(f"[OK] 密码正确，档案可打开。共 {len(names)} 个条目：")
            for n in sorted(names):
                print("  ", n)
            # 顺便打印档案头信息
            info = z.archiveinfo()
            print("\n--- archiveinfo ---")
            print(f"uncompressed: {info.uncompressed}")
            print(f"compressed:   {info.compressed}")
    except py7zr.exceptions.Bad7zFile as e:
        print(f"[FAIL] 不是合法7z或分卷不完整: {e}")
        sys.exit(2)
    except py7zr.PasswordRequired:
        print("[FAIL] 需要密码（密码错误时通常在读取时报错）")
        sys.exit(3)
    except Exception as e:
        # py7zr 密码错误往往表现为 CRC/LZMA 解码错误
        print(f"[FAIL/可能是密码错误] {type(e).__name__}: {e}")
        sys.exit(4)

if __name__ == "__main__":
    main()
