#!/usr/bin/env python3
"""t38_tests.py — 对齐数据的相关性判定（T1~T5）"""
import json, math
from collections import Counter, defaultdict

R = json.load(open("/tmp/wot/t38_align.json"))
c29 = [r for r in R if r["csi"] == 29]
c30 = [r for r in R if r["csi"] == 30]
print(f"csi29={len(c29)}  csi30={len(c30)}")

Q20 = 1.0 / (1 << 20)

def speed_of(r):
    """0x0A pos 的模长无关; 用 v20 模长与 pos 直接给"""
    p = r["pos"]; return math.sqrt(sum(x*x for x in p))

def yaw_deg(r):
    v = r["v32"]
    return [math.degrees(x) for x in v]

print("\n== T1: time(E) vs clk 关系（csi29）==")
# clk Q20 秒; E 疑似 ms。 逐场做差: E/1000 - clk*Q20
per_tag = defaultdict(list)
for r in c29:
    per_tag[r["tag"]].append(r["time"]/1000.0 - r["clk"]*Q20)
for tag, ds in sorted(per_tag.items()):
    ds.sort()
    n = len(ds)
    print("  %-18s n=%-3d offset(min/med/max)=%9.3f / %9.3f / %9.3f  极差=%.3f" %
          (tag, n, ds[0], ds[n//2], ds[-1], ds[-1]-ds[0]))

print("\n== T1b: dclk 分布（csi29 最近邻时钟差, Q20 秒）==")
dd = Counter()
for r in c29:
    dd[round(r["dclk"]*Q20, 2)] += 1
for k, v in sorted(dd.items())[:12]:
    print("   dclk=%8.2fs  ×%d" % (k, v))

print("\n== T2: A vs v32 欧拉角量化 / 速度（csi29）==")
# A 分布
ac = Counter(r["A"] for r in c29)
print("  A 分布:", ac.most_common(12))
# 检验 A 是否 = f(yaw)。先看 A 与 v32 分量的单调关系
# 对每个 A 值收集 v32 三分量的统计
byA = defaultdict(list)
for r in c29:
    byA[r["A"]].append(r["v32"])
print("  A值 |  n | v32[0]均值 | v32[1]均值 | v32[2]均值")
for a, lst in sorted(byA.items(), key=lambda kv: -len(kv[1]))[:10]:
    m = [sum(x[i] for x in lst)/len(lst) for i in range(3)]
    print("  %4d | %3d | %8.3f  | %8.3f  | %8.3f" % (a, len(lst), m[0], m[1], m[2]))

print("\n== T2b: A vs 位置（检查是否量化坐标分量）==")
byA2 = defaultdict(list)
for r in c29:
    byA2[r["A"]].append(r["pos"])
for a, lst in sorted(byA2.items(), key=lambda kv: -len(kv[1]))[:6]:
    m = [sum(x[i] for x in lst)/len(lst) for i in range(3)]
    sp = [max(x[i] for x in lst)-min(x[i] for x in lst) for i in range(3)]
    print("  A=%4d n=%3d pos均值=(%9.1f,%9.1f,%9.1f) 极差=(%8.1f,%8.1f,%8.1f)" %
          (a, len(lst), m[0], m[1], m[2], sp[0], sp[1], sp[2]))

print("\n== T3: C vs tail/ref/运动状态（csi29）==")
cc = Counter((r["C"], r["tail"]) for r in c29)
print("  (C, 0x0A tail):", cc.most_common())
# C vs 速度(v20模长)
import statistics
for cval in (0, 1):
    vmods = [math.sqrt(sum(x*x for x in r["v20"])) for r in c29 if r["C"] == cval]
    if vmods:
        print("  C=%d: v20模长 min=%.5f med=%.5f max=%.5f (n=%d)" %
              (cval, min(vmods), statistics.median(vmods), max(vmods), len(vmods)))

print("\n== T4: D vs 运动状态（csi29）==")
for dval in sorted(set(r["D"] for r in c29)):
    sub = [r for r in c29 if r["D"] == dval]
    vmods = [math.sqrt(sum(x*x for x in r["v20"])) for r in sub]
    pmov = []
    for r in sub:
        pmov.append(math.sqrt(sum(x*x for x in r["pos"])))
    print("  D=%10.2f n=%3d v20模长(med)=%.5f  pos模长(med)=%.1f" %
          (dval, len(sub), statistics.median(vmods) if vmods else -1,
           statistics.median(pmov) if pmov else -1))

print("\n== T5: B 复核（csi29+30）==")
print("  B 分布(c29):", Counter(r["B"] for r in c29).most_common())
print("  B 分布(c30):", Counter(r["B"] for r in c30).most_common())

print("\n== csi30(inspired) 字段概览 ==")
print("  A 分布:", Counter(r["A"] for r in c30).most_common(8))
print("  time 范围: %.1f ~ %.1f" % (min(r["time"] for r in c30), max(r["time"] for r in c30)))
print("  csi30 无 C/D 字段（13B 元素 {A,B,time}）")
