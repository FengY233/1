#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
t37_hand2.py — Task 37 ③：csi=29/30/27/28/33/34 全位级手工解码
0x24 线: [eid u32][isSlice u8][len u32][body]
body 位流(MSB-first): [1][csi:6b] 循环[1][idx]... [0] + Single:leafIdx / Slice:start+end
值从下一整字节开始。本次枚举 leafOwnerN，找出 slice 索引与值长全自洽的假设。
"""
import struct, sys, collections
sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import REPLAYS, load_pkts

class BitReader:
    def __init__(self, data):
        self.d = data; self.pos = 0  # bit pos
    def get(self, n):
        v = 0
        for _ in range(n):
            byte = self.d[self.pos >> 3]; bit = (byte >> (7 - (self.pos & 7))) & 1
            v = (v << 1) | bit; self.pos += 1
        return v
    def used_bytes(self):
        return (self.pos + 7) >> 3

def bits_required(n):
    if n <= 1: return 1
    r = 0
    while (1 << r) < n: r += 1
    return r

# 找 CN942 caucasus 基准场
TAG, REPLAY = None, None
for t, p in REPLAYS:
    if '1801' in t: TAG, REPLAY = t, p; break
if REPLAY is None: TAG, REPLAY = REPLAYS[0]

pkts = load_pkts(REPLAY)
p24 = [(c, pl) for ty, c, pl in pkts if ty == 0x24]
print(f'{TAG}: 0x24 包数 {len(p24)}')

TARGET_CSI = {27, 28, 29, 30, 33, 34}
rows = collections.defaultdict(list)
for clk, pl in p24:
    eid, isl, ln = struct.unpack_from('<IBI', pl, 0)
    body = pl[9:9+ln]
    br = BitReader(body)
    if br.get(1) != 1: continue
    csi = br.get(6)
    if csi not in TARGET_CSI: continue
    # 下钻层
    depth = 0; idxs = []
    while br.get(1) == 1:
        idxs.append(br.get(bits_required(50)))  # 占位——用 6bit 读（仅观测形态）
        depth += 1
        if depth > 3: break
    rows[csi].append((eid, isl, ln, depth, idxs, body[br.used_bytes():]))

for csi in sorted(rows):
    rs = rows[csi]
    print(f'\n=== csi={csi} n={len(rs)} ===')
    # depth 分布
    print('  depth 分布:', dict(collections.Counter(r[3] for r in rs)))
    print('  isSlice 分布:', dict(collections.Counter(r[1] for r in rs)))
    print('  值长分布:', dict(collections.Counter(len(r[5]) for r in rs)))
    for r in rs[:8]:
        eid, isl, ln, depth, idxs, val = r
        print(f'  eid={eid} isl={isl} len={ln} depth={depth} idxs={idxs} val={val.hex()}')
