#!/usr/bin/env python3
"""launch_v15.py — 门户守护启动 (double-fork 完全脱离会话)"""
import os, sys, subprocess

LOG = '/tmp/wot/file_server.log'
cmd = [sys.executable, '/home/z/my-project/scripts/file_server.py']

# double-fork daemonize
if os.fork() > 0:
    os.waitpid(0, 0) if False else None
    sys.exit(0)
os.setsid()
if os.fork() > 0:
    sys.exit(0)

# 孙进程: 重定向标准流并 exec
logf = open(LOG, 'ab', buffering=0)
devnull = open(os.devnull, 'rb')
os.dup2(devnull.fileno(), 0)
os.dup2(logf.fileno(), 1)
os.dup2(logf.fileno(), 2)
os.execv(cmd[0], cmd)
