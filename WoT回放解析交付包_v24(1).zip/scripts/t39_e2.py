#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
t39_e2.py — 0x32/0x37 TLV 递归试探解析
骨架假设: [u32 len][u16 objID][u16 tag][u8][eid u32][body...]
body 中的观察模式:
  [u8 00/01][u16 ?][u16 objID 复现][02][u8][u16 strlen][ascii]...  (资源路径)
  [u8][u16]... 84/85/83/86/82 族 TLV
  f32 参数组 (000080bf=-1.0, 0000f041=30.0...)
本脚本: ①骨架验证全量 ②objID/tag 域统计 ③body 首层节点类型统计
"""
import json, struct, sys
from collections import Counter, defaultdict

sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import REPLAYS, load_pkts

RB = [r for r in REPLAYS if r[0] != 'tundra_CN_942']

def collect(TY):
    out = []
    for tag, path in RB:
        for ty, clk, body in load_pkts(path):
            if ty == TY:
                out.append((tag, clk, body))
    return out

for TY in (0x32, 0x37):
    pk = collect(TY)
    print('=' * 16, '0x%02X  n=%d' % (TY, len(pk)), '=' * 16)
    # ①骨架验证: u32len == len(body)-4?
    ok = 0
    for tag, clk, b in pk:
        if len(b) >= 4:
            (n,) = struct.unpack_from('<I', b, 0)
            if n == len(b) - 4: ok += 1
    print('u32len==len-4: %d/%d' % (ok, len(pk)))
    # ②objID/tag 域
    objids = Counter(); tags = Counter(); third = Counter()
    bad = 0
    for tag_, clk, b in pk:
        if len(b) < 13: bad += 1; continue
        oid, t2 = struct.unpack_from('<HH', b, 4)
        b3 = b[8]
        objids[oid] += 1; tags[t2] += 1; third[b3] += 1
    print('骨架不足13B: %d' % bad)
    print('tag2 域:', dict(tags.most_common(8)))
    print('第9字节:', dict(third.most_common(8)))
    print('objID top20:', [hex(x) for x, _ in objids.most_common(20)])
    # objID 与 eid 关联: 存 eid→objID 映射, 看 objID 是否随 eid
    m = defaultdict(set)
    for tag_, clk, b in pk:
        if len(b) < 13: continue
        oid = struct.unpack_from('<H', b, 4)[0]
        (eid,) = struct.unpack_from('<I', b, 9)
        m[eid].add(oid)
    multi = sum(1 for v in m.values() if len(v) > 1)
    print('eid 数=%d, 同 eid 多 objID=%d' % (len(m), multi))
    # ③body 首层节点: body 起点13, 看 [u8][u16] 分布
    node = Counter()
    for tag_, clk, b in pk:
        if len(b) <= 13: node['<empty>'] += 1; continue
        node['b13=%02x' % b[13]] += 1
    print('body[0]@13 分布:', dict(node.most_common(12)))
    # ④0x32 objID 是否==0x24 的其他实体? 抽查 objID 与 typeID12(DetachedTurret) eid 对照
    #    以及 0x37 的 0005 族 vs 0x32 的 0001 族
    print()
