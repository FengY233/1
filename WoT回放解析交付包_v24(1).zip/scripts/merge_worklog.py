# -*- coding: utf-8 -*-
"""merge_worklog.py — worklog 全谱系时序合并（会话F / Task 31）

三源合并:
  ① /home/z/my-project/worklog.md          根目录(最初环境原始记录 + 后续追加, 顺序按恢复拼接)
  ② V12 包内 worklog.md                     同源缺 Task 30-补记(无独有内容, 已 diff 证实)
  ③ /tmp/wot/github_test/会话记录.txt        最全对话记录(373KB/8389行), 用于恢复会话C v15/v16 轮过程条目

输出: /tmp/wot/v12_stage/pack/worklog.md  (六段时序: A原文→B原文→C补录+v15/v16→D恢复轮→E→F)
"""
import sys

ROOT_WL = '/home/z/my-project/worklog.md'
OUT = '/tmp/wot/v12_stage/pack/worklog.md'

lines = open(ROOT_WL, encoding='utf-8').read().split('\n')


def find_line(substr, start=0):
    """返回包含 substr 的行号(0-based), 找不到则报错退出"""
    for i in range(start, len(lines)):
        if substr in lines[i]:
            return i
    raise SystemExit(f'FATAL: 找不到标记: {substr!r}')


# ---- 定位各块边界 (每块以独立 "---" 行起始) ----
def dash_before(idx):
    """给定 Task ID 行号, 返回其上方紧邻的 '---' 行号"""
    i = idx - 1
    while i >= 0 and lines[i].strip() == '':
        i -= 1
    assert lines[i].strip() == '---', f'行{idx}上方不是---而是: {lines[i]!r}'
    return i

i_bulu = find_line('Task ID: 19-27 (补录')                 # 会话C 补录
i_28a = find_line('Task ID: 28 (环境重置恢复)')             # 会话D1
i_appendix = find_line('===== 附录: 会话B 完整工作日志')     # 附录头
i_28b = find_line('Task ID: 28-补 (环境恢复第三轮')         # 会话D2
i_28c = find_line('Task ID: 28 (门户架设收尾)')             # 会话D2 门户
i_29 = find_line('Task ID: 29 (v16 终局轮结论恢复')         # 会话E
i_30 = find_line('Task ID: 30 (V12 交付包制作)')
i_30p = find_line('Task ID: 30-补记 (V12 打包落地)')
# 会话B 的 Task 18 (区别于会话A 的 Task 18): 在附录头之后
i_b18 = find_line('Task ID: 18', start=i_appendix)
i_a18 = find_line('Task ID: 18 (decomp 终极深挖')           # 会话A 的 Task 18 (校验用)

assert i_a18 < i_bulu < i_28a < i_appendix < i_b18 < i_28b < i_28c < i_29 < i_30 < i_30p, '块序校验失败'

d_bulu, d_28a = dash_before(i_bulu), dash_before(i_28a)
d_28b, d_28c = dash_before(i_28b), dash_before(i_28c)
d_29, d_30, d_30p = dash_before(i_29), dash_before(i_30), dash_before(i_30p)


def block(a, b):
    """取行区间 [a, b) 并去掉首尾空行"""
    seg = lines[a:b]
    while seg and seg[0].strip() == '':
        seg.pop(0)
    while seg and seg[-1].strip() == '':
        seg.pop()
    return seg


A_part = block(0, d_bulu)            # 会话A 全部(含标题行)
C_bulu = block(d_bulu, d_28a)        # 会话C 补录 Task 19-27
D_28a = block(d_28a, i_appendix)     # 会话D1 Task 28 (附录头之前)
B_part = block(i_appendix + 1, d_28b)  # 会话B Task 18-26 (跳过旧附录头)
D_28b = block(d_28b, d_28c)
D_28c = block(d_28c, d_29)
E_29 = block(d_29, d_30)
E_30 = block(d_30, d_30p)
E_30p = block(d_30p, len(lines))

print(f'[切片] A={len(A_part)} C补录={len(C_bulu)} D28a={len(D_28a)} '
      f'B={len(B_part)} D28b={len(D_28b)} D28c={len(D_28c)} '
      f'E29={len(E_29)} E30={len(E_30)} E30补={len(E_30p)}')
assert A_part[0].startswith('# WoT'), 'A段应以标题开头'
assert C_bulu[1].startswith('Task ID: 19-27'), 'C补录块头错误'
assert B_part[1] == 'Task ID: 18', f'B段头错误: {B_part[1]!r}'

# ================= 新增文本块 =================

HEADER = """# WoT Replay 解析工作日志（全谱系 · 时序合并版）

> **合并说明**（2026-09-25 · 会话F / Task 31）：本文件由三份材料合并而成——
> ① 根目录 worklog.md（**最初环境的原始记录**：会话A Task 1-18 原文，与 upload/ 的 A 时代备份逐字节一致；其后为各恢复轮追加条目）；
> ② V12 交付包内 worklog.md（同源，截至 Task 30，缺 Task 30-补记）；
> ③ GitHub FengY233/test `会话记录.txt`（373KB / 8,389 行，commit 4567b52，最全对话记录）——用于恢复会话C 的 v15/v16 两轮过程条目并校对全谱系。
>
> **会话谱系**（时序）：会话A（Task 1-18，v1-v8 线）→〔重置1〕→ 会话B（Task 18-26 新编号，v9-v14 线，V8-V11 交付）→〔重置2〕→ 会话C（Task 19 起沿用A编号：ext_pkg 十项对账 → v15 攻坚轮 → 版本漂移终局 → v16 终局轮，原始记录随重置丢失）→〔重置3〕→ 会话D（Task 28 系列恢复轮，两阶段：首轮恢复未竟 → 28-补 GitHub 全量重建 → 门户收尾）→ 会话E（Task 29-30：v16 结论恢复 + V12 交付，即对话摘要中自称"会话D=本轮"者）→ 会话F（Task 31：本合并）。
>
> **编号说明**：各会话独立编号，存在同号异会话（Task 18/19/28 各有两个版本、Task 29 在会话C 与会话E 各一条），以分段标题消歧。会话A 段内「Task 5-7」「Task 8-11」合并块与后续逐条明细并存，系原始记录自身原貌，未作改动。会话B worklog 原含「Task 1-17 历史复述」（重置后据旧对话记录重建的摘要），因会话A 原始记录在本文件完整在位，不再重复收录。
"""

P1 = """
===== 第一部分 · 会话A（原始环境 · Task 1-18 · v1-v8 线 · 2026-09-23）=====
> 本段为最初环境的原始记录原文（未经重建）。
"""

P2 = """
===== 第二部分 · 会话B（第一次重置后 · Task 18-26 新编号 · v9-v14 线 · V8-V11 交付 · 2026-09-23~24）=====
> 本段为 V11 交付包内 worklog.md 原文（Task 18-26，Super Z 署名各条）。
"""

P3 = """
===== 第三部分 · 会话C（第二次重置后 · 沿用会话A 编号 Task 19 起 · ext_pkg 对账 + v15/v16 终局轮 · 2026-09-24 深夜~25）=====
> 会话C 原始 worklog 已随第三次重置丢失。Task 19-27 补录由会话D 自对话摘要恢复；
> 「v15 攻坚轮」与「版本漂移终局 + v16 终局轮」两条过程补录由会话F（Task 31）自最全对话记录.txt 恢复。
> 会话C 内实际时序：ext_pkg 十项对账 → v15 攻坚轮 → 版本漂移澄清 → v16 终局轮。
"""

V15 = """---
Task ID: 28 (会话C · v15 攻坚轮 · 补录)
Agent: main
Task: 扩展 def 全模型实算 + u16 真 bug 修复（用户指令："继续攻克，把回放全部内容完全搞懂。wot24_ext_defs.zip里的README.md是那个AI写的，可能不对"）

Work Log (自对话记录.txt 行 7350-7900 恢复; 原记录随重置丢失, 本轮当时曾自记为会话C worklog 的 Task 28):
- 立场: 不采信 README 任何断言, 全部事实用自己的 vanilla 版解码器从 _raw 原件独立重扫; README 的 3 处跨包 Parent / 零接口引用经独立复核属实
- 机器码裁决 (capstone 反汇编 WorldOfTanks.exe, sha256 与 manifest 权威值一致): 扩展循环 FUN_142a996e0 实传同一挂载 multimap (r8=[rsp+0x60]) + dir 前缀 (rbx+0x80) + side=0——Ghidra 反编译在该调用点丢了 param_3/param_4, 汇编没有说谎
- ★推翻 v14 两处判定: ①挂载索引 Part b 读的是根级 <ExternalComponents>, 18 扩展该节全空 → 扩展静态挂载边=0 (v14 "39 static 边"系误归因, 0x6665642e ".def" 拼接证据属 Part a); ②扩展迭代序 = FeatureName 键的有序 std::map (FUN_140313020 拷键实锤) = 字母序, paths.xml 实际顺序佐证
- ★修复 v9 起的真 bug: 方法 flags 喂入宽度是 u16 (2 字节) 非 u8——方法体喂入器走 calculator slot10 (机器码 mov word ptr [rsp+0x40], r8w; r9d=2, 零扩展字节载入后实喂 [flags, 0x00]); v9 "无 u16 调用"结论漏了此调用点; 这解释了主模型自 v13 起从未命中
- digest_fork_v3.py 建成: 318 记录全模型 (1 space + 40 主实体 + 10 扩展实体 + 107 主 dyncomp + 160 扩展 dyncomp); no-ext 消融精确复现 v2 的 E2E9EBE2 → 主模型零回归, 扩展层是唯一增量
- 全层汇编级验证: walker 域序 [+0x218=CLIENT][+0x198=BASE][+0x118=CELL] 每域计数器独立从 0 起; 域标签 (baseMethods/clientMethods/cellMethods) 走 slot3=no-op 不喂字节 (字符串池泄漏出圣杯源文件名 entity_description_digests.cpp, 全树仅一处引用); 属性体喂入序 [name][varLen 门控][flags][isVolatile][type] 与 v2 一致; VLH 默认=1; 10 个自定义类型别名全在主树 alias.xml (其中 4 个带 AllowNone); FLRespawnComponent 的 ReturnValues 在非暴露方法上=0 字节; DefaultKeyName 只进记录 +0x308 显示名不进 feed; 记录追加有全局名字 map 去重, 全部重叠组合 (ext dyncomp vs 主实体/主 dyncomp/space 名) 扫描为空; decider 对 .pyc 包目录形态复核无误 (3 个主排除项双重确认)
- 建模风险清零: ext def 旧式直接 <Arg> 子节点的引擎过滤规则 = 只收名为 "Arg" 的子节点 (FUN_142abdc40); MAILBOX 属性 Flags=base64 回环 "BASE" 无 client 位不进 feed; 两侧根级 Type 段 / Components 内联挂载均为 0
- 实算: 全量 318 记录 = 20E4276E… ≠ 目标 5DF886F7…; 主消融 = FD632272… ≠ 目标
- 收尾: 向用户提出版本同期性三问 (录制后客户端是否更新过 / res_mods 是否有改 entityDefs 的 mod / 扩展 pkg 与回放之间无交叉验证锚); 成果固化 findings.md §11 + 会话C 自身 worklog (后者已随重置丢失, 本条即其恢复)

Stage Summary:
- 结构层至此穷尽: 全部喂序/宽度/过滤器/decider/迭代序均与二进制一致, 剩余偏差指向数据本身 (版本同期性)
- 方法 flags 宽度 u16 与 vanilla uint8 的差异浮出水面; 318 记录模型与 5976CA14 终态之间只差方法层与版本层的最后两步
"""

V16 = """---
Task ID: 29 (会话C · 版本漂移终局 + v16 终局轮 · 补录; 原始编号未及登记, 按会话内序暂编)
Agent: main
Task: 版本疑云解除 + client 方法真相 + 网络 methodID 机制 + digest 5976CA14 终态（本轮 findings 未及固化即遭第三次重置, 本条自对话记录.txt 行 7900-8389 恢复）

Work Log:
- 版本漂移调查 (实证细节已由会话D 并入上 Task 19-27 补录; 实际时序在本轮前段): wot-src 镜像 .version_name/.publication.json 钉死 V1=#942 (09-11 05:58 快照, 与回放录制同日) / V2=#949 (09-17 03:23); partial clone tree diff 650 文件, 152 个 M 全部与 digest 无关 (GUI 资源/本地化/平衡数据), def 全为 A 状态 = 镜像流水线 09-17 起才收录 def 文件; 用户澄清: 客户端一直停在 #942 未更新 #949, "小版本"指 #938→#942 (tree diff 仅 6 文件: precache/version/manifest, 零 def 变更) → 版本漂移嫌疑整体排除
- 0x3D 方向判定: t=24(版本串)/t=45(构建串)/t=48(客户端类型 "sd")/t=61(digest) 是 clk=0 头部区单调相邻的登录流四件套 = LogOnParams 客户端上行 → 客户端模型对象正确 (最致命嫌疑排除)
- 外围嫌疑清空: 主树 entities.xml 无 ServerOnlyEntities 节; FUN_142a9b410 遍历 {begin,end} 指针对 0x328 步长 = parse 期间 append 物理序无重排; arena_defs = 声音库重映射配置不进 digest; Personality/cgf 节仅被 FeatureExtensionMap::parse (0x142a80xxx 段) 引用, EntityDescriptionMap::parse (0x142a9xxxx 段) 零引用; 扩展 pkg 内只有 extension.xml 无 scripts/entities.xml (all_files.txt 1196 成员全查); 编排函数只读 entities.xml/components.xml/spaces.xml 三文件
- 记录开关机制: 记录 +0x85/86/87 = decider 对象 vtable slot0/1/2 三槽返回值; +0x87 非零才分配记录索引 (+0x82 计数器递增) = "进客户端体系/digest" 总开关, digest slot7 过滤用的正是它; decider 第三参 = {Base,Cell,Client} 三域存在性位图
- ★★client 方法真相 (本轮最大成果): 回放 1,265 个 0x08 方法调用包 (31 eid / 128 对 methodID) = 方法层运行时真值源, 全量命中 (Vehicle 的 showShooting/onHealthChanged/showDamageFromShot、Avatar 的 updateArena 等); onMethod (FUN_142a9b810) 真实过滤 = (flags & 0xC) != 0 (分布位, 与 exposed 标志无关); fork 给 client 方法自动 |=0x4 (机器码 377428-377429: if component==CLIENT, flags|=IS_EXPOSED_TO_ALL_CLIENTS)——v13 "client 方法全部出局"判反, 方法数 163→366 修正; defparse 的 flags 语义本来就对, 错误只在 digest_fork_v2 的过滤层
- ★网络 methodID 机制全解: 域内 isExposed (flags&0xC) → exposedMethods_ 列表 → stable_sort by streamSize (定长在前升序, 变长在后按 varLenHeaderSize) → 0 起编号——与属性 csi 排序同构; 排序器 key 取负致变长组反排的 bug 修复后 128 对真值全命中; digest 喂的 index = legacyExposedIndex (声明序计数器), 与网络 sorted 编号是两套体系, 双 index 变体实验均未命中
- ★entities.xml 真实声明序发现: 非字母序 (Account, Avatar, ArenaInfo, ClientSelectableObject, HangarVehicle, Vehicle=第6, AreaDestructibles=第7…); 0x05 创建块 1,833 个的 n 分布 {3:1, 6:247, 7:1578, 18:1, 28:1, 29:1, 40:4} 与索引对账: n=3=ArenaInfo, n=6=Vehicle (30 辆车 eid 546611517-546611546 全部 n=6), n=7=AreaDestructibles, n=29=AvatarInfo, n=40=NetworkEntity——索引 = space(0) + 声明序(1..40); defparse 本就按声明序加载, 顺序模型无误
- NetworkEntity n=40 载荷铁证: 4 个创建块载荷与 csi 表完美吻合 (scale=1,1,1 / unique_id=UUID / prefab_path="37_bridge_destruction_01" / name="Collisions")
- jsonl 的 m 字段 (方法名标注) = 生成器错位标注, 弃用 (其 README 警告应验)
- 修复后实算: digest = 5976CA145E07E97C627D8B40ED9952CF ≠ 目标 5DF886F75E73B33CFF9D87FB9C69389C; 主消融 = 16AE6853…; isVolatile=1 恰 1 处复核 (BattleRoyaleRadio 是纯 Volatile 空壳无属性); 消融矩阵全负
- 收尾: 本轮战报三条 (版本疑云彻底解除 / client 方法 163→366 / 主实体部分最高置信: 属性 40/40 + 方法全量 + 索引布局均有运行时真值锚); findings §12 未及写入即遭环境重置 (后由会话E Task 29 恢复); 下一步建议 = 录一场大逃杀/前线/背水之战回放取扩展实体与动态组件真值锚

Stage Summary:
- 0x3D 主线: 结构层 + 方法层 + 版本层全部闭合, 方法层有 decomp + vanilla + 0x08 运行时 128 对三方铁证
- 剩余偏差锁定: dyncomp 记录内容 (267/318 = 84% 无真值源); 破口 = 录扩展模式回放
"""

P4 = """
===== 第四部分 · 会话D（第三次重置后 · 恢复轮 · Task 28 系列 · 2026-09-25）=====
> 本段含三条: Task 28（首轮恢复: worklog/findings 自 upload 复位 + 会话C 要点补录, 未竟）→
> Task 28-补（环境再次失守后的 GitHub 全量拉取重建, 自记为第三轮恢复）→ Task 28（门户架设收尾）。
"""

P5 = """
===== 第五部分 · 会话E（续接 · v16 结论恢复 + V12 交付 · Task 29-30 · 2026-09-25）=====
> 即对话摘要中自称"会话D=本轮"的 V12 制作轮; 为避免与第四部分恢复轮混淆, 本合并版按实际时序编为会话E。
"""

P6 = """
===== 第六部分 · 会话F（worklog 全谱系合并 + V12 重打包 · Task 31 · 2026-09-25）=====
"""

T31 = """---
Task ID: 31 (worklog 全谱系时序合并 + V12 重打包)
Agent: main
Task: 用户指令——"我发现你现在的环境是最初的环境，你根目录的worklog.md保存了最初的记录。现在你根据根目录的worklog.md还有V12的worklog.md以及最新的对话.txt，做一个顺序正确且完整的worklog.md，打包到V12里，并替换掉你根目录的"

Work Log:
- 三源盘点: ①根 worklog.md(83,615B) = 会话A 原始记录(Task 1-18, 与 upload/worklog.md A 时代备份逐字节一致) + 其后各轮追加——但会话B 附录插在会话C 补录与 Task 28 之后, 系按"恢复先后"而非时间顺序拼接; ②V12 包内 worklog.md(83,101B) = 根版本缺 Task 30-补记(diff 仅此一处, 无独有内容); ③对话记录.txt(373KB/8,389 行, commit 4567b52) = 最全对话记录, 覆盖 v1→v16 终局轮全程
- git pull 确认 FengY233/test 无新提交, 对话记录.txt 已是最新
- 合并动作: ①按会话时序重排六段(A 原文 → B 原文 → C 补录+新增两条 → D 恢复轮 → E v16恢复+V12 → F 本轮); ②自对话记录.txt 行 7350-8389 恢复会话C 的「v15 攻坚轮」「版本漂移终局+v16 终局轮」两条过程条目(此前仅有 findings §11/§12 的结论登记, worklog 无过程记录); ③文件头新增合并说明(三源/谱系/重置史/编号说明); ④各段加谱系标题, 会话B 段头注明其"Task 1-17 历史复述"因会话A 原始记录在位不再收录
- 修复门户遗留 bug: scripts/file_server.py 第 22 行 V11 描述文本掉出字符串引号外(SyntaxError——Task 30 时代 DESC 编辑事故, file_server.log 留有重启失败 traceback; 旧进程一直在跑 V11 版页面, "DESC 升级 V12"实际从未生效); 修正该行 + DESC 全面 v12 化(findings v16/21 表/22 段 JSON/审计 v12 条目/徽标改 dyncomp 口径/推荐语文件大小改为动态计算) + 语法校验通过后重启守护进程
- README 更新两行: worklog 描述由"会话A(Task1-18 重建)"更正为"会话A(原始记录)+时序合并版"并补 v15/v16 恢复条目与合并轮
- V12 重打包: 27 文件不变(仅 worklog.md 与 README.md 内容更新), 分发 download/ + upload/backup_v12/ + v12_stage; 根目录 worklog.md 同步替换为合并版, 与包内逐字节一致

Stage Summary:
- worklog 谱系完整闭合: 会话A(原始) → B(V11 原文) → C(补录 + v15/v16 恢复) → D(恢复轮) → E(v16 恢复 + V12) → F(本合并)——时序正确、无缺轮、同号异会话已分段消歧
- V12 包内 worklog 与根目录主位同源同步; 门户 DESC 修复重启后 V12 置顶真正生效
- 主线状态不变: digest 剩余自由度 = dyncomp 记录(84% 无真值源), 破口 = 录扩展模式回放; dec.7z(44MB AES 分卷)密码仍待用户提供
"""


def join_blocks(*blocks):
    out = []
    for b in blocks:
        out.extend(b)
        out.append('')  # 块间空行
    return '\n'.join(out).rstrip('\n') + '\n'


# 标题块(A 段自带原标题行 → 去掉, 用新头部)
A_body = A_part[1:]  # 跳过旧标题行, 保留空行+内容
while A_body and A_body[0].strip() == '':
    A_body.pop(0)

merged = join_blocks(
    HEADER.strip('\n').split('\n'),
    P1.strip('\n').split('\n'), A_body,
    P2.strip('\n').split('\n'), B_part,
    P3.strip('\n').split('\n'), C_bulu,
    V15.strip('\n').split('\n'),
    V16.strip('\n').split('\n'),
    P4.strip('\n').split('\n'), D_28a, D_28b, D_28c,
    P5.strip('\n').split('\n'), E_29, E_30, E_30p,
    P6.strip('\n').split('\n'), T31.strip('\n').split('\n'),
)

open(OUT, 'w', encoding='utf-8').write(merged)

# ---- 统计与自检 ----
n_task = merged.count('\nTask ID:')
n_part = merged.count('===== 第')
import hashlib
md5 = hashlib.md5(open(OUT, 'rb').read()).hexdigest()
print(f'[OK] 输出 {OUT}')
print(f'     行数={len(merged.splitlines())} 字节={len(merged.encode())} Task条目={n_task} 段标题={n_part} md5={md5}')

# 自检: 按合并后真实时序逐一定位关键 Task ID (必须递增出现)
seq = ['Task ID: 1\n',            # 会话A Task1
       'Task ID: 18 (decomp',      # 会话A Task18
       'Task ID: 19-27',           # 会话C 补录
       'Task ID: 28 (会话C · v15',  # 会话C v15 轮(新恢复)
       'Task ID: 29 (会话C',        # 会话C v16 终局轮(新恢复)
       'Task ID: 28 (环境重置恢复)',  # 会话D1
       'Task ID: 28-补',            # 会话D2
       'Task ID: 28 (门户架设收尾)',  # 会话D 门户
       'Task ID: 29 (v16 终局轮结论恢复',  # 会话E
       'Task ID: 30 (V12',          # 会话E
       'Task ID: 30-补记',          # 会话E
       'Task ID: 31 (worklog']      # 会话F
flat = merged
pos = -1
ok = True
for marker in seq:
    p = flat.find(marker, pos + 1)
    if p < 0:
        print(f'[FAIL] 缺失或乱序: {marker!r}')
        ok = False
        break
    pos = p
# B 段 Task 18(无后缀) 应在 19-27 补录之前
pb = flat.find('Task ID: 18\n')
pc = flat.find('Task ID: 19-27')
if not (0 < pb < pc):
    print('[FAIL] 会话B Task18 未在会话C 补录之前')
    ok = False
print('[自检]', '全部通过' if ok else '失败')
sys.exit(0 if ok else 1)
