#!/usr/bin/env python3
"""vdef_dump.py — Task35: Vehicle.def 全属性 dump (name/type/flags/DetailLevel/Identifier)
输出 /tmp/wot/vdef_props.json
"""
import sys, json
sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file


def sec_text(s):
    """section 文本值(优先) / 子节点名拼接"""
    if s.type == 1:
        return s.asString()
    if s.children:
        return None  # 复杂节点
    if s.type == 0 and not s.data:
        return None
    if s.type == 2:
        return str(s.asInt())
    if s.type == 4:
        return 'true' if s.asBool() else 'false'
    return s.data.hex()


def dump_props(path, out_json):
    root = decode_file(path)
    props = root.findChild('Properties')
    rows = []
    for c in props.children:  # 属性 section
        row = {'section': c.name}
        for cc in c.children:
            t = cc.name
            if t in ('Type',):
                row['type'] = sec_text(cc)
                row['type_node'] = type_tree(cc)
            elif t == 'Flags':
                row['flags'] = sec_text(cc)
            elif t == 'DetailLevel':
                row['dl'] = sec_text(cc)
            elif t == 'Identifier':
                row['ident'] = sec_text(cc)
            elif t == 'DatabaseLength':
                row['dbLen'] = sec_text(cc)
            elif t == 'EditableInUFF':
                row['uff'] = sec_text(cc)
            else:
                row[t.lower()] = sec_text(cc)
        rows.append(row)
    json.dump(rows, open(out_json, 'w'), ensure_ascii=False, indent=1)
    return rows


def type_tree(node, depth=0):
    """类型节点树: name + 关键属性(size/allow_none) + 递归"""
    out = {'name': node.name}
    for cc in node.children:
        if cc.name in ('Size', 'size'):
            out['size'] = sec_text(cc)
        elif cc.name in ('AllowNone', 'allowNone'):
            out['allowNone'] = sec_text(cc)
        elif cc.name in ('DBLength', 'DatabaseLength'):
            out['dbLen'] = sec_text(cc)
        elif cc.name not in ('Properties',):
            # 嵌套类型节点 (如 FixedDict 的字段)
            if cc.children:
                out.setdefault('fields', []).append(type_tree(cc, depth + 1))
            else:
                out.setdefault('attrs', {})[cc.name] = sec_text(cc)
    if 'Properties' in [cc.name for cc in node.children]:
        pw = node.findChild('Properties') if hasattr(node, 'findChild') else None
        if pw:
            for f in pw.children:
                entry = {'field': f.name}
                for fc in f.children:
                    if fc.name == 'Type':
                        entry['type'] = type_tree(fc, depth + 1)
                    else:
                        entry[fc.name.lower()] = sec_text(fc)
                out.setdefault('fields', []).append(entry)
    return out


if __name__ == '__main__':
    rows = dump_props('/tmp/wot_scripts/scripts/entity_defs/Vehicle.def',
                      '/tmp/wot/vdef_props.json')
    print(f'{len(rows)} 属性 section')
    for i, r in enumerate(rows):
        print(f"{i:3d} {r['section']:28s} type={str(r.get('type')):34s} "
              f"flags={str(r.get('flags')):24s} dl={r.get('dl','')}")
