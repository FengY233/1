#!/usr/bin/env python3
"""tail_align.py — 以 '21002200' 锚对齐 1092 车, 字节位多样性剖析
高多样性位=值位, 低多样性=结构位/恒定位
"""
import json
from collections import Counter

rows = json.load(open('/tmp/wot/ext_cluster.json'))

# 含 21002200 的车
al = []
no_anchor = 0
for r in rows:
    ext = bytes.fromhex(r['ext'])
    i = ext.find(b'\x21\x00\x22\x00')
    if i >= 0:
        al.append((r, ext, i))
    else:
        no_anchor += 1
print(f'含锚: {len(al)} / 无锚: {no_anchor}')

# 对齐: 锚前 -40..+4, 锚后 +4..+44
PRE, POST = 44, 48
prof = {}
for off in range(-PRE, POST):
    c = Counter()
    n = 0
    for r, ext, i in al:
        p = i + off
        if 0 <= p < len(ext):
            c[ext[p]] += 1
            n += 1
    prof[off] = (n, c)

print(f'\n{"off":>4} {"n":>5}  {"top6 字节:计数":<44} 熵')
import math
for off in range(-PRE, POST):
    n, c = prof[off]
    if n == 0:
        print(f'{off:>4} {0:>5}  -')
        continue
    top = c.most_common(6)
    H = -sum((v / n) * math.log2(v / n) for v in c.values())
    tops = ' '.join(f'{k:02x}:{v * 100 // n}%' for k, v in top)
    bar = '#' * int(H * 4)
    print(f'{off:>4} {n:>5}  {tops:<46} H={H:.2f} {bar}')
