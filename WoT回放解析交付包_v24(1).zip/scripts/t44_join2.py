#!/usr/bin/env python3
"""t44_join2.py — BE 端序重做 0x37↔hierarchy networkID 对撞
0x37 组格式假设: [u16 BE nid][u8 op][u8 sub][body...]
同时检查 0x37 全部 u16 位置的字段(不只首部)是否命中 nid 空间
"""
import struct, sys, glob, json
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter

REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
tundra = [f for f in REPLAYS if 'tundra' in f][0]
RND = [f for f in REPLAYS if f != tundra]

def parse_hierarchy_array(p):
    for start in range(0, min(len(p), 400)):
        n = p[start]
        if not (3 <= n <= 12):
            continue
        pos = start + 1
        items = []
        ok = True
        for _ in range(n):
            if pos >= len(p):
                ok = False; break
            ln = p[pos]; pos += 1
            if not (2 <= ln <= 32) or pos + ln + 4 > len(p):
                ok = False; break
            name = p[pos:pos+ln].decode('utf-8', 'replace')
            pos += ln
            nid = struct.unpack_from('<I', p, pos)[0]
            pos += 4
            items.append((name, nid))
        if ok and pos == len(p) and items:
            return start, items
    return None, None

for f in RND:
    blocks, declared, slen, pkts = load(f)
    p32 = [(i, c, p) for i, (t, c, p) in enumerate(pkts) if t == 0x32]
    p37 = [(i, c, p) for i, (t, c, p) in enumerate(pkts) if t == 0x37]
    # nid 空间(带槽名)
    nid2slot = {}
    for i, c, p in p32:
        stream = p[4:]
        start, items = parse_hierarchy_array(stream)
        if items and any(s in ('hull', 'turret', 'gun', 'chassis') for s, _ in items):
            for s, nid in items:
                nid2slot.setdefault(nid, set()).add(s)
    # 0x37: 首u16 BE + 组内模式
    hit_first = miss_first = 0
    hit_any = 0
    miss_samples = Counter()
    # 组模式: 假设 [u16 BE nid][u8 op][u8 sub][...] 循环 — 先只统计首 u16 BE 与全部 u16 BE 滑窗
    for i, c, p in p37:
        if len(p) >= 6:
            u_be = struct.unpack_from('>H', p, 4)[0]
            if u_be in nid2slot:
                hit_first += 1
            else:
                miss_first += 1
                miss_samples[u_be] += 1
        # 滑窗全部 BE u16
        found = False
        for off in range(4, len(p) - 1):
            if struct.unpack_from('>H', p, off)[0] in nid2slot:
                found = True
                break
        if found:
            hit_any += 1
    n = len(p37)
    print(f'{f.split("/")[-1][:40]:42s} nid空间={len(nid2slot):4d} 0x37首u16(BE)命中={hit_first:5d}/{n} 滑窗任意命中包={hit_any:5d}/{n}')
    if miss_samples:
        top = miss_samples.most_common(6)
        print(f'   未中首u16(BE) top: {[(hex(v), c) for v, c in top]}')
