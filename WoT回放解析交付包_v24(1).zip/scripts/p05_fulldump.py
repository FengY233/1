#!/usr/bin/env python3
"""p05_fulldump.py — Task35: 0x05 Vehicle 全载荷逐字节 dump + 手工走段对照
用途: 打印完整 payload hex + 按 v8 表走基础段, 观察扩展区起始结构
"""
import json, struct, zlib, sys
from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])

REPLAYS = [
    ("siegfried_EU_935", "/tmp/wot/github_test/20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay"),
    ("karelia_EU_935", "/tmp/wot/github_test/20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay"),
    ("caucasus_CN_942", "/tmp/wot/github_test/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay"),
    ("karelia2_EU_944", "/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay"),
]

CSI = {}
d = json.load(open('/home/z/my-project/download/csi_tables_v8.json'))
for p in d['entities']['Vehicle']['properties']:
    CSI[p['csi']] = (p['name'], p['streamSize'])


def load_pkts(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from('<I', data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b'\x00' * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        dd = cipher.decrypt(main[i:i + 8])
        dd = bytes(a ^ b for a, b in zip(dd, prev))
        prev = dd
        out += dd
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from('<III', stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


def get_b0(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos = 8
    (blen,) = struct.unpack_from('<I', data, pos)
    return json.loads(data[pos + 4:pos + 4 + blen])


def main():
    tag_want = sys.argv[1] if len(sys.argv) > 1 else 'caucasus_CN_942'
    vtype_want = sys.argv[2] if len(sys.argv) > 2 else None
    for tag, path in REPLAYS:
        if tag != tag_want:
            continue
        b0 = get_b0(path)
        roster = {}
        for dbid, v in (b0.get('vehicles') or {}).items():
            sid = v.get('avatarSessionID')
            if sid:
                roster[int(sid)] = v
        pkts = load_pkts(path)
        veh = [pl for ty, c, pl in pkts if ty == 5 and len(pl) >= 47
               and struct.unpack_from('<I', pl, 4)[0] == 6]
        print(f'{tag}: Vehicle 0x05 数 {len(veh)}')
        shown = 0
        for pl in veh:
            eid = struct.unpack_from('<I', pl, 0)[0]
            propBytes, = struct.unpack_from('<I', pl, 42)
            count = pl[46]
            # roster join
            hits = [aid for aid in roster if struct.pack('<I', aid) in pl]
            ent = roster[hits[0]] if hits else {}
            vt = ent.get('vehicleType')
            if vtype_want and vt != vtype_want:
                continue
            print(f'\n== eid={eid} vtype={vt} vpp={ent.get("vehPostProgression")} '
                  f'plen={len(pl)} propBytes={propBytes} count@46={count}')
            # 头部
            print('fork头(8..42):', pl[8:42].hex(' '))
            print('pos:', struct.unpack_from('<3f', pl, 12))
            print('ypr:', struct.unpack_from('<3f', pl, 24))
            # 完整属性区 hex (46..end)
            body = pl[46:]
            print(f'属性区 {len(body)}B:')
            for off in range(0, len(body), 16):
                print(f'  +{off:3d}: ' + body[off:off+16].hex(' '))
            shown += 1
            if shown >= 3:
                break


if __name__ == '__main__':
    main()
