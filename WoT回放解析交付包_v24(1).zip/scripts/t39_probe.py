#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
t39_probe.py — Task 39 侦察（仅随机战 10 场，tundra 移出）
39-a: E 字段(lifeTime/endTime)时钟纪元判定材料
39-b: 变长组尾部 41-47/49 锚定材料（0x07 key + 0x24 csi + 0x05 idx 直方图）
39-c: 0x05 重创建事件全表（触发条件判定材料）
"""
import json, struct, sys, os
from collections import defaultdict, Counter

sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import REPLAYS, load_pkts

RB = [r for r in REPLAYS if r[0] != 'tundra_CN_942']   # 随机战 10 场
print('随机战场次:', len(RB))

# ============ 39-a: 各场 JSON 头时间字段 ============
def json_blocks(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos, blocks = 8, []
    for _ in range(bc):
        (blen,) = struct.unpack_from('<I', data, pos)
        pos += 4
        blocks.append(data[pos:pos + blen])
        pos += blen
    return blocks

print('\n===== 39-a 各场时间字段（块0 战前 + 尾块 结算）=====')
binfo = {}
for tag, path in RB:
    blks = json_blocks(path)
    b0 = json.loads(blks[0])
    common = b0.get('common', {})
    row = {
        'dateTime': b0.get('dateTime'),
        'arenaCreateTime': b0.get('arenaCreateTime'),
        'duration': common.get('duration'),
        'endingWinCode': common.get('endingWinCode'),
        'playTime': common.get('playTime'),
    }
    if len(blks) > 1:
        try:
            last = json.loads(blks[-1])
            row['last_blk_keys'] = sorted(last.keys())[:8]
        except Exception as e:
            row['last_blk_keys'] = 'non-json(%s)' % e
    binfo[tag] = row
    print('%-18s dt=%s act=%s dur=%s play=%s lastblk=%s' % (
        tag, row['dateTime'], row['arenaCreateTime'], row['duration'],
        row['playTime'], str(row.get('last_blk_keys'))[:70]))

# ============ E 值按场统计 ============
print('\n===== 39-a E 值（perks lifeTime / ribbon endTime）=====')
sem = json.load(open('/tmp/wot/perks_semantic_v23.json'))
E = defaultdict(list)
for r in sem:
    t = r.get('lifeTime') or r.get('endTime')
    if t: E[(r['tag'], r['channel'])].append(t)
for k in sorted(E):
    v = E[k]
    print('%-34s n=%3d  min=%.2f  max=%.2f  span=%.2f' % (str(k), len(v), min(v), max(v), max(v) - min(v)))

# arenaCreateTime 秒 → 与 E 对比
print('\narenaCreateTime(秒) 与 E 中位对比:')
for tag, row in binfo.items():
    if tag in [k[0] for k in E]:
        act = row['arenaCreateTime']
        if act:
            acts = act / 1000.0 if act > 10**12 else act
            ev = [x for (t, c), xs in E.items() for x in xs if t == tag]
            if ev:
                import statistics
                med = statistics.median(ev)
                print('%-18s act=%d  E_med=%.1f  E-act%%1000=%.1f  E-act=%.1f' % (
                    tag, int(acts), med, (med - acts) % 1000, med - acts))

# ============ 39-c: 0x05 重创建事件 ============
print('\n===== 39-c 0x05 重创建事件（同 eid 多次创建）=====')
# p05_decoded.json: {tag, eid, typeID, pos, ypr, props}; 但无包序号 → 重扫包流
recreate = defaultdict(list)   # (tag,eid) -> [clk,...]
first05 = {}                   # (tag,eid) -> clk
total05 = 0
TYPEID_NAME = {1: 'Vehicle', 2: 'AreaDestr', 3: 'TeamInfo', 4: 'AvatarInfo'}
# 从 p05_decoded 拿 eid→typeID 映射
p05 = json.load(open('/tmp/wot/p05_decoded.json'))
et = {}
for r in p05:
    if r['tag'] != 'tundra_CN_942':
        et[(r['tag'], r['eid'])] = r.get('typeID')

for tag, path in RB:
    pkts = load_pkts(path)
    seen = {}
    for i, (ty, clk, body) in enumerate(pkts):
        if ty != 0x05: continue
        total05 += 1
        (eid,) = struct.unpack_from('<I', body, 0)
        k = (tag, eid)
        if k in seen:
            recreate[k].append((len(seen[k]), clk))
            seen[k].append(clk)
        else:
            seen[k] = [clk]

n_ev = sum(len(v) for v in recreate.values())
n_eid = len(recreate)
print('0x05 总数=%d, 重创建 eid 数=%d, 重创建事件=%d' % (total05, n_eid, n_ev))
tc = Counter(et.get(k, '?') for k in recreate)
print('重创建 eid typeID 分布:', dict(tc))
# 次数分布
cc = Counter(len(v) for v in recreate.values())
print('每 eid 重创建次数分布:', dict(sorted(cc.items())))

# ============ 39-b: 0x07 key 直方图（Vehicle eid 集）+ 0x24 csi 直方图 ============
print('\n===== 39-b 0x07 key 直方图（按实体类）=====')
veh_eids = defaultdict(set)   # tag -> set(eid)
for (tag, eid), tid in et.items():
    veh_eids[tag].add(eid)

key_hist = defaultdict(Counter)
for tag, path in RB:
    pkts = load_pkts(path)
    vset = veh_eids[tag]
    for ty, clk, body in pkts:
        if ty != 0x07: continue
        if len(body) < 4: continue
        eid = struct.unpack_from('<I', body, 0)[0]
        key = body[4]
        isveh = 'V' if eid in vset else 'N'
        key_hist[isveh][key] += 1

for grp in ('V', 'N'):
    h = key_hist[grp]
    tot = sum(h.values())
    print('--- %s (总 %d) top30:' % ('Vehicle-eid' if grp == 'V' else '非Vehicle', tot))
    for k, c in sorted(h.items(), key=lambda x: -x[1])[:30]:
        print('    key %2d : %6d' % (k, c))

# 尾部段 41-49 专查
print('--- Vehicle key 41-49 段:')
for k in range(41, 50):
    c = key_hist['V'].get(k, 0)
    print('    key %d : %d' % (k, c))

json.dump({'binfo': binfo,
           'recreate': {('%s|%d' % k): v for k, v in recreate.items()},
           'key_hist_V': {int(k): int(v) for k, v in key_hist['V'].items()},
           'key_hist_N': {int(k): int(v) for k, v in key_hist['N'].items()}},
          open('/tmp/wot/t39_probe.json', 'w'))
print('\n→ /tmp/wot/t39_probe.json')
