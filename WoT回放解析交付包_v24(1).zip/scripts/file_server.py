# -*- coding: utf-8 -*-
"""file_server.py — 交付物下载门户 (v2)
- 服务 /home/z/my-project/download 目录(含子目录 charts/)
- 首页: 中文文件清单 + 大小 + 说明 + 下载
- /health: 平台健康检查
- 正确处理中文文件名(URL 编码)与 Content-Disposition
- 端口 3000 (平台网关 81 -> 3000), 双fork守护化启动
"""
import html
import os
import urllib.parse
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

ROOT = '/home/z/my-project/download'
PORT = 3000

UNIT = lambda n: f'{n/1048576:.2f} MB' if n >= 1048576 else f'{n/1024:.1f} KB'
ICON = {'.zip': '🗂', '.pdf': '📕', '.md': '📘', '.xlsx': '📊', '.json': '🧾',
        '.png': '🖼', '.html': '🌐', '.py': '🐍'}
DESC = {
    'WoT回放解析交付包_v24.zip': '⭐⭐ 最新·全量重打包（Task 44 · v28 · ClientHub/NRL 架构轮）：227 文件收拢 V16 底座+v17-v28 全部增量（报告§23/findings v28 §24/data_v26 层级字典/全即脚本）；★41槽处理器接口表（0x32-0x39=8个连续fork扩展槽，只录不转发=服务器专供回放注记流）；★类链 WGReplayConnection:ClientHub:BWEndPoint+NRL::EndPoint+播放分发表；★ClientHub 消息文法（class 0-5 分发+processUpdateNode）；★★hierarchyInfo 全量提取（980+车辆层级字典：hull/turret/gun/chassis→networkID）；★0x37 NRL组文法+nid空间对撞；v6勘误（"组件路由号"=[u32 len]）；随机战 0x32/0x37 语义 85%→93%',
    'WoT回放解析交付包_v23.zip': 'V23 增量（Task 43 · EXE 白盒终局）：digest 字节模型 100% 闭环（域标记/字段名全零字节、MAILBOX 零字节、25 类 visit 全解）+三实锤修复（静态组件属性并入/csi 分块/VLH 门）；digest_fork_v12/v13；复现 E726F5E4，偏差坍缩至无锚记录内容',
    'WoT回放解析交付包_v22.zip': 'V22 增量（Task 41 · 输入侧审计+算法层重解）：★★digest 算法层完全翻案（结构化 visitor 协议 entity_description_digests.cpp）；scripts942=942 权威零差异；129,984 组合消融',
    'WoT回放解析交付包_v21.zip': 'V21 增量（v25 · Task 40 digest 攻坚）：三源偏差翻案（TeamInfo+3=组件属性并入/Vehicle重排=v8误诊/key27=wheelsScroll）；方法flags=u8；csi_tables_v9 修正版权威表；复现 919053EC',
    'WoT回放解析交付包_v15.zip': '⭐ 最新 — V15 全量交付（v19 · 0x05 属性流终局轮：★0x05=vanilla 纯格式四实体铁证（NetworkEntity count=3 逐字节）/ 线编码规则全集（packedInt/FD allow_none/定长 TUPLE 直出）/ ★★MY_VEHICLE 分层（10 属性本车专属，DetailLevel 标签）/ ★网络 idx 过滤重排（vpp=40，754/754 零偏差，0x05/0x07 双空间）/ alias AllowNone 97·202 / 组件注册表 16+113、185 CS 属性 / 同型车扩展区模板恒定 33% / findings v19 §15 / data_v19 / 脚本 48 件 / worklog 十段全谱系）',
    'WoT回放解析交付包_v14.zip': 'V14（v18 · 技能体系分离 + 动态组件通道轮：digest 定性修正为 2.4.0.0 世代指纹 / 乘员技能 csi34 vs 车辆技能三分离 / CSI≥50 扩展区=动态组件通道（1,092 车，+25% 技能签名）/ 0x39=游戏对象复制流 / findings v18 §14 / data_v18）',
    'WoT回放解析交付包_v13.zip': 'V13（v17 · 11 场新回放真值锚轮：digest 恒定性实锤 / 0x05 typeID=声明序 / methodID 11 场语义级验证 / findings v17 §13 / 报告 §22 / data_v17 新数据 4 件）',
    'WoT回放解析交付包_v12.zip': 'V12（v16 终局轮：findings §12 / 报告 §21 / digest_fork_v2 v16 终态 5976CA14 复现版 / worklog 全谱系时序合并版）',
    'WoT回放解析交付包_v11.zip': 'V11 交付（v14 时代：FeatureExtension 体系发现轮；报告 20 章 63 页 PDF/MD、xlsx 19 表、解码 JSON、csi 权威表、ext_inventory、findings v14、6 个复现脚本）',
    'WoT回放完全解析报告.pdf': '主报告 V11 定稿，20 章 63 页，含 §20 FeatureExtension 体系（18 扩展/digest 剩余自由度）',
    'WoT回放完全解析报告.md': '主报告源文档（23 章 1653 行：§0-§22 原有 + §23 v18-v26 总览与 ClientHub/NRL 架构轮；MD 为权威）',
    'WoT回放解析数据包_20260911_caucasus.xlsx': '21 工作表：概览/包类型/实体/车辆战绩/击杀链/事件时间线/轨迹/三方对账/v14 扩展清单/v14 全链复核/v16 方法层修正/v16 方法ID与版本终局',
    'WoT回放解码数据_20260911_caucasus.json': '全量解码数据（22 段，含 feature_extension_v16）',
    'csi_tables_v8.json': 'csi 权威表：40 实体 / 306 条 CS 属性（0x07/0x24 属性号字典，14+1 锚点验证）',
    'ext_inventory.json': '18 扩展清单：pkg_order / static 39 / dynamic 171 / CS 实体 10 / SO 实体 16',
    'data_v19/': 'v19 新数据：网络 idx 重排表 v19（vpp=40 铁证 / MY_VEHICLE 清单 / 0x07 key 全表 / 尾部骨架 / 组件注册表）/ 1,092 车扩展区聚类全量',
    'data_v18/': 'v18 数据 7 件：11 场 block0 全字段（构建号归属）/ 314 车名册矩阵（vpp 技能）/ 0x05 扩展区动态组件通道（1,092 车）/ 载荷名册 join / Vehicle 声明序全表 / 11 场 0x07 csi 键空间 / 回放普查',
    'data_v17/': 'v17 新数据 4 件：11 场回放普查 / 0x05 实体锚矩阵（typeID 声明序对齐）/ methodID 跨场矩阵 / methodID 分配表（14 实体 168 方法）',
    'findings.md': '结论登记册 v19（vtable 全解 / parse 白盒 / FeatureExtension / v15 u16 / v16 终局轮 §12 / v17 真值锚轮 §13 / v18 技能分离 §14 / v19 属性流终局+MY_VEHICLE 分层 §15）',
    '覆盖度终审_v15_audit.json': '覆盖度审计 v15（v19 轮 Task 34 全部入库项）',
    '覆盖度终审_v14_audit.json': '覆盖度审计 v14（v9-v13 口径 + v18 revisions）',
    '覆盖度终审_v13_audit.json': '覆盖度审计 v13（v9 口径 + v16 + v17 revisions）',
    '覆盖度终审_v12_audit.json': '覆盖度审计 v12（历史口径）',
    '覆盖度终审_v9_audit.json': '覆盖度审计 v9（历史口径）',
    '报告封面源文件.html': 'PDF 封面 HTML 源文件',
    'replays/': '11 个 wotreplay 样本（20260905-0912 多地图多车型，含主分析对象 20260911_1801 caucasus）',
    'charts/': '8 张分析图表（包类型/时间线/轨迹/时钟证明/伤害排行/会话生命周期/时间轴对齐/瞄准圈）',
}


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=ROOT, **kw)

    def end_headers(self):
        self.send_header('Cache-Control', 'no-store')
        super().end_headers()

    def translate_path(self, path):
        return super().translate_path(urllib.parse.unquote(path))

    def do_GET(self):
        p = urllib.parse.unquote(self.path.split('?')[0]).rstrip('/')
        if p in ('', '/'):
            return self.send_index()
        if p == '/health':
            body = b'{"status":"ok"}'
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            return self.wfile.write(body)
        return super().do_GET()

    def send_index(self):
        entries = []
        for name in sorted(os.listdir(ROOT)):
            p = os.path.join(ROOT, name)
            if os.path.isfile(p):
                entries.append((name, os.path.getsize(p), False))
            elif os.path.isdir(p):
                sz = sum(os.path.getsize(os.path.join(dp, f))
                         for dp, _, fs in os.walk(p) for f in fs)
                entries.append((name + '/', sz, True))
        # 推荐的 zip 排最前（版本号降序 → 最新置顶）
        import re
        def _verkey(n):
            m = re.search(r'_v(\d+)\.zip', n)
            return (0, -int(m.group(1))) if m else (1, n)
        entries.sort(key=lambda e: (_verkey(e[0]) if e[0].startswith('WoT回放解析交付包') else (2, e[0]),))
        v15sz = next((s for n, s, _ in entries if n == 'WoT回放解析交付包_v15.zip'), 0)
        rows = []
        for name, sz, isdir in entries:
            icon = '📁' if isdir else ICON.get(os.path.splitext(name)[1].lower(), '📄')
            href = urllib.parse.quote(name)
            label = html.escape(name)
            desc = html.escape(DESC.get(name.rstrip('/'), DESC.get(name, '')))
            star = '⭐' if name.startswith('WoT回放解析交付包') else ''
            rows.append(
                f'<tr><td style="padding:12px 14px;white-space:nowrap">{icon} {star}'
                f'<a href="/{href}" style="color:#1a5fb4;text-decoration:none;font-weight:600">{label}</a></td>'
                f'<td style="padding:12px 14px;color:#666;white-space:nowrap">{UNIT(sz)}</td>'
                f'<td style="padding:12px 14px;color:#7a745c;font-size:13.5px">{desc}</td></tr>')
        page = f'''<!DOCTYPE html><html lang="zh"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>WoT 回放解析 — 交付物下载</title><style>
body{{font-family:-apple-system,'PingFang SC','Noto Sans SC','Microsoft YaHei',sans-serif;
background:#f4f2ec;margin:0;padding:40px 16px;color:#2d2a24}}
.card{{max-width:960px;margin:0 auto;background:#fff;border-radius:14px;
box-shadow:0 6px 28px rgba(60,50,20,.12);overflow:hidden}}
h1{{font-size:22px;margin:0;padding:26px 32px 6px;color:#4a4318}}
p.sub{{margin:0;padding:0 32px 18px;color:#8a8264;font-size:14px}}
table{{width:100%;border-collapse:collapse;font-size:15px}}
tr:nth-child(even){{background:#faf9f4}} tr:hover{{background:#f2efe2}}
td{{border-top:1px solid #eee9dc;vertical-align:top}}
.badge{{display:inline-block;margin:0 0 10px 32px;padding:3px 12px;background:#eef0dc;
border:1px solid #d5d8b0;color:#5c5a2a;border-radius:99px;font-size:12.5px}}
.tip{{max-width:960px;margin:14px auto;color:#8a8264;font-size:13px;line-height:1.7}}
</style></head><body>
<div class="card">
<h1>WoT 2.4.0 wotreplay 完全解析 — 交付物</h1>
<p class="sub">回放 2,025,112 字节逐字节解析 · V14 定稿 · 技能体系分离 + 动态组件通道轮完成 · 2026-09-25</p>
<span class="badge">覆盖度：结构层 100% / digest=2.4.0.0 世代指纹（4 构建×3 区域恒定） · 乘员技能 csi34 vs 车辆技能 csi44/45 三分离 · ★CSI≥50 扩展区=动态组件属性通道（1,092 车 +25% 技能签名） · 破口 = dyncomp 84% 无真值区 → 0x05 扩展区类型驱动解码</span>
<table>{''.join(rows)}</table></div>
<p class="tip">💡 点击文件名即下载，中文文件名已做 URL 编码处理。<br>
推荐先下载 <b>WoT回放解析交付包_v15.zip</b>（{UNIT(v15sz)}，81 个文件一站式打包，含 0x05 属性流终局 + MY_VEHICLE 分层 + 网络索引重排全部结论 + worklog 十段全谱系）。<br>
服务器常驻运行；若链接失效，回会话说一声即可重新拉起。</p>
</body></html>'''
        body = page.encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def guess_type(self, path):
        if path.endswith('.md'):
            return 'text/markdown; charset=utf-8'
        return super().guess_type(path)

    def log_message(self, fmt, *args):
        pass


if __name__ == '__main__':
    srv = ThreadingHTTPServer(('0.0.0.0', PORT), Handler)
    srv.daemon_threads = True
    print(f'file portal on :{PORT} -> {ROOT}', flush=True)
    srv.serve_forever()
