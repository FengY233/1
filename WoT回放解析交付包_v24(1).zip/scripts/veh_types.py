#!/usr/bin/env python3
"""veh_types.py — Vehicle 全属性类型树 dump (defparse)"""
import sys, json
sys.path.insert(0, '/home/z/my-project/scripts')
from defparse import EntityDefParser

p = EntityDefParser('/tmp/wot_scripts/scripts')
p.load()

veh = p.entities.get('Vehicle')
print('Vehicle 属性 (声明序):')


def dump_dt(dt, ind=0):
    k = dt.kind
    if k in ('ARRAY', 'TUPLE'):
        print(' ' * ind + f'{k} seq_size={dt.seq_size} allow_none={dt.allow_none}')
        dump_dt(dt.elem, ind + 4)
    elif k == 'FIXED_DICT':
        print(' ' * ind + f'FIXED_DICT allow_none={dt.allow_none}')
        for n, t in dt.fields:
            print(' ' * (ind + 4) + f'.{n}:')
            dump_dt(t, ind + 8)
    else:
        print(' ' * ind + f'{k} signed={dt.signed} size={dt.size} n={dt.n} db_len={dt.db_len}')


for i, dd in enumerate(veh.properties):
    print(f'--- decl{i}: {dd.name}')
    dump_dt(dd.dataType, 4)
