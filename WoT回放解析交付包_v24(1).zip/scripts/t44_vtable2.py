#!/usr/bin/env python3
"""t44_vtable2.py — 精确界定制录 handler vtable + RTTI 类名 + 槽→函数名解析
"""
import pefile, struct, re

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
IDX = '/tmp/my-project/repos/decomp/decomp/index.tsv'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

# 函数名表 addr -> name
fn = {}
with open(IDX) as f:
    next(f)
    for line in f:
        p = line.rstrip('\n').split('\t')
        if len(p) >= 2:
            fn[int(p[0], 16)] = p[1]

def va_to_off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            if s.PointerToRawData == 0:
                return None
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

def rq(va):
    off = va_to_off(va)
    return struct.unpack('<Q', data[off:off+8])[0] if off is not None else None

def rd(va, n):
    off = va_to_off(va)
    return data[off:off+n] if off is not None else b''

def rtti_name(col_va):
    """COL -> TypeDescriptor -> name"""
    col_off = va_to_off(col_va)
    if col_off is None:
        return None
    sig, off2, td = struct.unpack('<III', data[col_off:col_off+12])
    if sig != 1:
        return None
    td_off = va_to_off(td)
    if td_off is None:
        return None
    name = data[td_off+16:td_off+16+120].split(b'\x00')[0]
    return name.decode('utf-8', 'replace')

VT = 0x1436066e8   # 候选 vtable 基址(slot0)
# 检查 vtable-8 的 RTTI
col = rq(VT - 8)
print(f'vtable-8 = {hex(col) if col else None}')
if col:
    print(f'  RTTI 类名: {rtti_name(col)}')

# 向前向后确定表边界: 连续 text 指针
def is_code(va):
    off = va_to_off(va)
    if off is None:
        return False
    for s in pe.sections:
        if s.PointerToRawData and s.PointerToRawData <= off < s.PointerToRawData + s.SizeOfRawData:
            return b'.text' in s.Name
    return False

lo = VT
while is_code(rq(lo - 8)):
    lo -= 8
hi = VT
while is_code(rq(hi + 8)):
    hi += 8
print(f'vtable: {hex(lo)} .. {hex(hi)}  共 {(hi-lo)//8+1} 槽\n')

# dump 每槽
va = lo
i = 0
rows = []
while va <= hi:
    v = rq(va)
    name = fn.get(v, '?')
    rows.append((i, va, v, name))
    va += 8
    i += 1
for i, va, v, name in rows:
    print(f'slot[{i:3d}] @{hex(va)} {hex(v)} {name}')
