#!/usr/bin/env python3
"""t44_dis2.py — 反汇编 FUN_140e5c6f0(剩余消息循环) + FUN_140e73cf0(class1) + FUN_140e5c5d0头部
目的: 精确确认每条子消息的字节读取序列
"""
import pefile
from capstone import *

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()

def va_to_off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

md = Cs(CS_ARCH_X86, CS_MODE_64)

def dis(va, n, title):
    off = va_to_off(va)
    print(f'\n===== {title} @{hex(va)} =====')
    cnt = 0
    for ins in md.disasm(data[off:off+n], va):
        print(f'  {ins.address:#x}: {ins.mnemonic:8s} {ins.op_str}')
        cnt += 1
        if ins.mnemonic == 'ret' and cnt > 8:
            break
        if cnt > 110:
            break

dis(0x140e5c6f0, 420, 'FUN_140e5c6f0 剩余消息循环')
dis(0x140e73cf0, 380, 'FUN_140e73cf0 class1处理器')
