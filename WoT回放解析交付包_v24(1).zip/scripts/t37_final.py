#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
t37_final.py — Task 37 ③c：csi=29/30 值段终审
1. 原始 body 全 hex + 两种对齐切分
2. [u16 场常量] 与 block0 JSON 已知字段对账（spaceID? arenaID?）
3. f64 尾数 = 服务器时钟假设检验（单调性 + 与 0x05/0x07 clk 的换算）
"""
import struct, sys, json, collections
sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import REPLAYS, load_pkts, get_b0

def f32(b, o): return struct.unpack_from('<f', b, o)[0]
def f64(b, o): return struct.unpack_from('<d', b, o)[0]
def u16(b, o): return struct.unpack_from('<H', b, o)[0]

for TAG, RP in REPLAYS:
    if TAG not in ('caucasus_CN_942', 'karelia_EU_935'): continue
    pkts = load_pkts(RP)
    p24 = [(c, pl) for ty, c, pl in pkts if ty == 0x24]
    # 本场 block0 常量
    b0 = get_b0(RP)
    print(f'\n########## {TAG} ##########')
    cands = {}
    for k in ('spaceID', 'arenaID', 'arenaTypeId', 'mapId', 'playerID', 'arenaCreateTime', 'arenaUniqueID'):
        v = b0.get(k)
        if v is not None: cands[k] = v
    print('block0 候选常量:', cands)
    # 搜 block0 里的数字型值 = 观测 u16
    flat = []
    def walk(o, path):
        if isinstance(o, dict):
            for k, v in o.items(): walk(v, path + '.' + str(k))
        elif isinstance(o, list):
            for i, v in enumerate(o): walk(v, f'{path}[{i}]')
        elif isinstance(o, (int, float)) and not isinstance(o, bool):
            flat.append((path, o))
    walk(b0, '')
    obs_u16s = collections.Counter()
    samples = []
    for clk, pl in p24:
        eid, isl, ln = struct.unpack_from('<IBI', pl, 0)
        body = pl[9:9+ln]
        if not body or (body[0] >> 1) >> 2 != 29:  # 粗判: b0 高7位
            # 精判: [1][csi6]
            b = body[0] if body else 0
            csi = (b >> 1) & 0x3F
            if not (b & 0x80) or csi != 29: continue
        b = body[0]
        if not (b & 0x80) or ((b >> 1) & 0x3F) != 29: continue
        # 对齐A: val=body[2:] (slice 3+3b / single 2b)
        valA = body[2:]
        if len(valA) < 10: continue
        obs_u16s[u16(valA, 0)] += 1
        samples.append((clk, eid, isl, body, valA))
    print('csi=29 valA[0:2] u16 分布:', dict(obs_u16s))
    hit = {}
    for (path, v) in flat:
        for o in obs_u16s:
            if abs(v - o) < 1e-6: hit.setdefault(o, []).append(path)
    print('u16 ↔ block0 字段命中:', {k: v[:4] for k, v in hit.items()})
    print('--- 样本 ---')
    for clk, eid, isl, body, valA in samples[:10]:
        pre = valA[:-12]
        m = f32(valA, len(valA)-12) if len(valA) >= 12 else None
        t = f64(valA, len(valA)-8)
        print(f'clk={clk} eid={eid} isl={isl} bodylen={len(body)}')
        print(f'  body = {body.hex()}')
        print(f'  valA = {valA.hex()}')
        print(f'  解析: prefix={pre.hex()} | f32@-12={m:.4g} | f64@-8={t:.6g}')
