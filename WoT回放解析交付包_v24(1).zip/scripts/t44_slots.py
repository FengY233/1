#!/usr/bin/env python3
"""t44_slots.py — 遍历 41 槽, 从 decomp 函数体提取各自记录的回放类型常量
输出 slot -> (FUN, 记录类型, 证据行)
"""
import re, os

D = '/tmp/my-project/repos/decomp/decomp'
CH = os.path.join(D, 'chunks')

# addr -> (chunk, line) 检索表
where = {}
with open(os.path.join(D, 'index.tsv')) as f:
    next(f)
    for line in f:
        p = line.rstrip('\n').split('\t')
        if len(p) >= 5:
            where[int(p[0], 16)] = (p[3], int(p[4]))

slots = {
 0:'1405851a0', 1:'1405855b0', 2:'140585bb0', 3:'140311590', 4:'140586160',
 5:'140585d40', 6:'1402f7290', 7:'140586900', 8:'1405862d0', 9:'140586b30',
 10:'140587300', 11:'140584f50', 12:'140584f70', 13:'1405868b0', 14:'1402f40f0',
 15:'140586620', 16:'1402f7290', 17:'140586110', 18:'140311590', 19:'140584f60',
 20:'1402f7290', 21:'1402f7290', 22:'140588720', 23:'1405888a0', 24:'140588a00',
 25:'140587540', 26:'140584d30', 27:'14058e000', 28:'1402f7290', 29:'140588c40',
 30:'140585a40', 31:'140587a60', 32:'140588ed0', 33:'140584f80', 34:'140584fb0',
 35:'140585010', 36:'140584fc0', 37:'140585020', 38:'140584f90', 39:'140584fa0',
 40:'140585000',
}

# 已知写入器
KNOWN = {
 '140584f80':'0x32','140584fb0':'0x33','140585010':'0x34','140584fc0':'0x35',
 '140585020':'0x36','140584f90':'0x37','140584fa0':'0x38','140585000':'0x39',
 '140587300':'0x24(getFile)',
}

results = {}
for slot, addr in slots.items():
    if addr in KNOWN:
        results[slot] = (addr, KNOWN[addr], '已知写入器')
        continue
    if addr in ('1402f7290',):
        results[slot] = (addr, '-', '空函数(ret)')
        continue
    if addr in ('140311590',):
        results[slot] = (addr, '-', 'Bytes(小函数)')
        continue
    if addr == '1402f40f0':
        results[slot] = (addr, '-', 'Reserve(小函数)')
        continue
    a = int(addr, 16)
    if a not in where:
        results[slot] = (addr, '?', 'index未收录')
        continue
    chunk, ln = where[a]
    path = os.path.join(CH, chunk)
    # 读函数体: 从行号开始到下一个 FUNC
    with open(path, errors='replace') as f:
        lines = f.readlines()
    body = []
    i = ln - 1
    if i < 0 or 'FUNC' not in lines[i]:
        # 行号校准: 向上找
        for j in range(max(0, ln-50), min(len(lines), ln+5)):
            if f'FUNC 0x{addr}' in lines[j]:
                i = j
                break
    while i < len(lines):
        body.append(lines[i].rstrip())
        if len(body) > 1 and '==================== FUNC' in lines[i] and len(body) > 3:
            body.pop()
            break
        i += 1
        if len(body) > 2500:
            break
    text = '\n'.join(body)
    # 找 FUN_1405846e0( ... , 0xNN, ...) 或 FUN_14058e4c0(...,0xNN,...)
    ev = []
    for m in re.finditer(r'FUN_1405846e0\(([^;]{0,200}?)\);', text, re.S):
        args = [a.strip() for a in m.group(1).split(',')]
        ev.append('block:' + ','.join(args[:3]))
    for m in re.finditer(r'FUN_14058e4c0\(([^;]{0,120}?)\);', text, re.S):
        args = [a.strip() for a in m.group(1).split(',')]
        ev.append('fwd:' + ','.join(args[:3]))
    # 找 vtable 转发槽位(如 (**(code **)(...+ 0xNN))() )
    vf = set(re.findall(r'\*\*\(code \*\*\)\(([^)]{0,120}?)\+ (0x[0-9a-f]+)\)', text))
    results[slot] = (addr, ev if ev else ('转发' if vf else '?'), f'{len(body)}行' + (f' vslot:{sorted(vf)[:4]}' if vf else ''))

for slot in sorted(results):
    addr, t, note = results[slot]
    print(f'slot[{slot:3d}] FUN_{addr}: {t}   [{note}]')
