# -*- coding: utf-8 -*-
"""restore2c_dec.py — dec.7z 分卷合并 + 密码验证 + 与 decomp.zip 内容对账（md5 重跑）"""
import hashlib
import io
import os
import tempfile
import zipfile

import py7zr

B11 = '/home/z/my-project/upload/backup_v11_restore'
UP = '/home/z/my-project/upload'
W = '/tmp/wot'


def md5_bytes(b):
    return hashlib.md5(b).hexdigest()


def md5_file(p, bs=1 << 20):
    h = hashlib.md5()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(bs), b''):
            h.update(c)
    return h.hexdigest()


os.makedirs(W, exist_ok=True)
dec = f'{W}/dec.7z'
with open(dec, 'wb') as out:
    for part in (f'{B11}/dec.7z.001', f'{B11}/dec.7z.002'):
        with open(part, 'rb') as src:
            while True:
                c = src.read(1 << 24)
                if not c:
                    break
                out.write(c)
print(f'dec.7z 合并完成 {os.path.getsize(dec)/1048576:.1f}MB md5={md5_file(dec)}')

with py7zr.SevenZipFile(dec, mode='r', password='114514.1919810') as z:
    names = z.getnames()
    info = z.archiveinfo()
    print(f'密码 OK：{len(names)} 条目，解压后 {info.uncompressed/1048576:.0f}MB')
    dz = zipfile.ZipFile(f'{UP}/decomp.zip')
    dnames = [x for x in dz.namelist() if not x.endswith('/')]
    # 归一化对比：dec.7z 条目名 vs decomp.zip 条目名（都可能带 decomp/ 前缀）
    norm7 = sorted(n.lstrip('./').removeprefix('decomp/') for n in names if not n.endswith('/'))
    normz = sorted(n.removeprefix('decomp/') for n in dnames)
    same_set = norm7 == normz
    print(f'条目集合对比: dec.7z={len(norm7)} decomp.zip={len(normz)} '
          f'{"完全一致" if same_set else "不一致"}')
    if not same_set:
        only7 = set(norm7) - set(normz)
        onlyz = set(normz) - set(norm7)
        print('  仅 dec.7z:', list(only7)[:5])
        print('  仅 decomp.zip:', list(onlyz)[:5])
    # 抽样 md5 对账（首/中/尾各1）
    picks = [norm7[0], norm7[len(norm7)//2], norm7[-1]]
    with tempfile.TemporaryDirectory() as td:
        z.extractall(td)
        for p in picks:
            fp = None
            for root, _, fs in os.walk(td):
                if p in fs:
                    fp = os.path.join(root, p)
                    break
            if not fp:
                print(f'  抽样 {p}: 未找到')
                continue
            m7 = md5_file(fp)
            dzname = f'decomp/{p}'
            mzip = md5_bytes(dz.read(dzname)) if dzname in dz.namelist() else 'N/A'
            print(f'  抽样 {p}: dec={m7} zip={mzip} {"一致" if m7 == mzip else "!!不一致"}')
print('dec.7z 对账完成（解压物用 decomp.zip 的副本，dec.7z 留档不解压）')
