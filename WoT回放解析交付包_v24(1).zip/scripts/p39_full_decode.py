#!/usr/bin/env python3
"""p39_full_decode.py — 0x39 两种子型全字段解码（72B/0x44 与 41B/0x25）

已确认结构线索:
  - [u32 0x44][u16 6][u8 01] + 8B 每场唯一常量 + 递增u32对(当前/前一) + 魔数30d6c3c4
  - 尾部 4B 疑似 float 坐标缓慢漂移
  - 41B 变体头 [u32 0x25]...
本脚本: 全偏移 float 扫描 + 41B 样例 + 跨场字段对齐
"""
import struct
import zlib
from collections import Counter

from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])

SRC = {
    "karelia_EU": "/tmp/wot/github_test/20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay",
    "WZ219_EU": "/tmp/wot/github_test/WZ-219.wotreplay",
}


def load_pkts(path):
    data = open(path, "rb").read()
    (magic, bc) = struct.unpack_from("<II", data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from("<I", data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b"\x00" * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        d = cipher.decrypt(main[i:i + 8])
        d = bytes(a ^ b for a, b in zip(d, prev))
        prev = d
        out += d
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from("<III", stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


def f32(b, off):
    try:
        return struct.unpack_from("<f", b, off)[0]
    except Exception:
        return None


def annotate(pl):
    """按已识别骨架注释 72B 载荷"""
    if len(pl) == 72:
        u32a, = struct.unpack_from("<I", pl, 0)
        u16a, = struct.unpack_from("<H", pl, 4)
        u8a = pl[6]
        c8 = pl[7:15].hex()
        seqA, = struct.unpack_from("<I", pl, 15)
        seqB, = struct.unpack_from("<I", pl, 19)
        magic = pl[23:27].hex()
        rest = pl[27:]
        return (f"sub={u32a:#x} t?={u16a} f={u8a} const8={c8} seqA={seqA}({seqA:#x}) "
                f"seqB={seqB}({seqB:#x}) magic={magic} rest={rest.hex()}")
    return pl.hex()


def main():
    for tag, path in SRC.items():
        pkts = load_pkts(path)
        p39 = [(clk, pl) for ty, clk, pl in pkts if ty == 0x39]
        print(f"\n########## {tag} n39={len(p39)} ##########")
        # 72B 子型: 逐字段稳定性统计
        p72 = [pl for _, pl in p39 if len(pl) == 72]
        p41 = [pl for _, pl in p39 if len(pl) == 41]
        print(f"-- 72B 子型 {len(p72)} 个, 41B 子型 {len(p41)} 个")
        # 逐字节变化率
        var = []
        for off in range(72):
            vals = Counter(pl[off] for pl in p72[:2000])
            var.append((off, len(vals), vals.most_common(2)))
        stable = [o for o, n, _ in var if n == 1]
        print("恒定偏移(72B):", stable)
        # 浮点扫描: 打印前5包每个4B对齐偏移的 float 值
        print("\n-- 前6个72B包全字段注释:")
        for i, (clk, pl) in enumerate([(c, p) for c, p in p39 if len(p) == 72][:6]):
            print(f"[{i}] clk={clk}")
            print("   ", annotate(pl))
        # 浮点视角
        print("\n-- 前6个72B包 float@23..71 (跳过magic):")
        for i, (clk, pl) in enumerate([(c, p) for c, p in p39 if len(p) == 72][:6]):
            fs = []
            for off in range(23, 72, 4):
                v = f32(pl, off)
                fs.append(f"{off}:{v:.3f}" if v is not None and abs(v) < 1e6 else f"{off}:{pl[off:off+4].hex()}")
            print(f"[{i}] " + " ".join(fs))
        # 41B 样例
        if p41:
            print("\n-- 前6个41B包:")
            for i, pl in enumerate(p41[:6]):
                u32a, = struct.unpack_from("<I", pl, 0)
                print(f"[{i}] head={u32a:#x} hex={pl.hex()}")
            # 41B 恒定偏移
            var41 = [(o, len(set(pl[o] for pl in p41))) for o in range(41)]
            print("41B 恒定偏移:", [o for o, n in var41 if n == 1])
        # seq 连续性检查(72B)
        seqs = [struct.unpack_from("<I", pl, 15)[0] for pl in p72]
        gaps = [(a, b) for a, b in zip(seqs, seqs[1:]) if b - a != 1]
        print(f"\n72B seq: 首={seqs[0]:#x} 末={seqs[-1]:#x} 非递增1的跳变数={len(gaps)} (样例{gaps[:5]})")
        # seqB 是不是前一包的 seqA
        ok_prev = sum(1 for a, b in zip(p72, p72[1:])
                      if struct.unpack_from("<I", b, 19)[0] == struct.unpack_from("<I", a, 15)[0])
        print(f"seqB == 前一包seqA 的对数: {ok_prev}/{len(p72)-1}")
        # 41B 与 72B 的 seq 关系(若有)
        if p41:
            seqs41 = [struct.unpack_from("<I", pl, 4)[0] for pl in p41 if len(pl) >= 8]
            print("41B 首4字段(hex):", [pl[:8].hex() for pl in p41[:3]])


if __name__ == "__main__":
    main()
