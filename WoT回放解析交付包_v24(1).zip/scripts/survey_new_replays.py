#!/usr/bin/env python3
"""survey_new_replays.py — 11 个回放批量普查：block0 元数据 + 0x3D digest 真值 + 包类型直方图

用户提供的 10 个新回放（不全是国服 #942，但能在 #942 客户端播放）。
关键问题：
  Q1 各回放的游戏模式（找大逃杀/前线/背水之战类扩展模式）
  Q2 各回放 0x3D 的 digest 值（#942 应恒等于 5DF886F7...；非 942 的给出版本敏感性真值对）
  Q3 包类型分布（0x05/0x32/0x08 数量——实体与方法的真值锚密度）
"""
import json
import struct
import sys
import zlib
from collections import Counter

from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])

REPLAYS = [
    "/tmp/wot/github_test/20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay",
    "/tmp/wot/github_test/20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay",
    "/tmp/wot/github_test/20260907_1321_germany-G197_Pz_Kpfw_Neu_07_lakeville.wotreplay",
    "/tmp/wot/github_test/20260910_1057_china-Ch67_BZ_79_37_caucasus.wotreplay",
    "/tmp/wot/github_test/20260911_1534_ussr-R52_Object_261_44_north_america.wotreplay",
    "/tmp/wot/github_test/20260911_1749_uk-GB156_Black_Prince_II_63_tundra.wotreplay",
    "/tmp/wot/github_test/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay",
    "/tmp/wot/github_test/20260912_1036_france-F143_Fauteur_59_asia_great_wall.wotreplay",
    "/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay",
    "/tmp/wot/github_test/PTZ_10K.wotreplay",
    "/tmp/wot/github_test/WZ-219.wotreplay",
]


def load(path):
    data = open(path, "rb").read()
    (magic, bc) = struct.unpack_from("<II", data, 0)
    assert magic == 0x11343212, hex(magic)
    pos = 8
    blocks = []
    for _ in range(bc):
        (blen,) = struct.unpack_from("<I", data, pos)
        blocks.append(data[pos + 4:pos + 4 + blen])
        pos += 4 + blen
    (declared,) = struct.unpack_from("<I", data, pos)
    pos += 4
    (stream_len,) = struct.unpack_from("<I", data, pos)
    pos += 4
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b"\x00" * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        d = cipher.decrypt(main[i:i + 8])
        d = bytes(a ^ b for a, b in zip(d, prev))
        prev = d
        out += d
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from("<III", stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return blocks, declared, stream_len, pkts


def survey(path):
    name = path.split("/")[-1]
    r = {"file": name}
    try:
        blocks, declared, stream_len, pkts = load(path)
    except Exception as e:
        return {"file": name, "error": f"{type(e).__name__}: {e}"}
    r["size"] = sum(12 + len(p[2]) for p in pkts)
    r["npkts"] = len(pkts)
    # block0 元数据
    try:
        b0 = json.loads(blocks[0].decode("utf-8", "replace"))
        r["player"] = b0.get("playerName")
        r["vehicle"] = (b0.get("vehicle") or {}).get("vehicleName") or b0.get("playerVehicle")
        r["map"] = b0.get("mapName") or b0.get("map")
        r["gameplayID"] = b0.get("gameplayID")
        r["battleType"] = b0.get("battleType")
        r["datetime"] = b0.get("dateTime")
        r["regionCode"] = b0.get("regionCode")
        r["hasMods"] = b0.get("hasMods")
        r["clientVersionFromExe"] = b0.get("clientVersionFromExe")
        r["serverSettings"] = sorted((b0.get("serverSettings") or {}).keys())
        if len(blocks) > 1:
            try:
                b1 = json.loads(blocks[1].decode("utf-8", "replace"))
                r["block1_len"] = len(blocks[1])
            except Exception:
                r["block1_len"] = len(blocks[1]) if len(blocks) > 1 else 0
    except Exception as e:
        r["b0_error"] = str(e)
    # 包类型直方图
    types = Counter(p[0] for p in pkts)
    r["types"] = {f"0x{t:02X}": c for t, c in types.most_common()}
    # 0x3D digest 包（取载荷 hex；每个出现位置都记）
    d3 = [(i, p[1], p[2].hex()) for i, p in enumerate(pkts) if p[0] == 0x3D]
    r["n_0x3D"] = len(d3)
    r["digests"] = [d[2] for d in d3[:6]]
    # 0x18 版本串 / 0x2D 构建串（前几个可打印串）
    ver = []
    for ty, clk, pl in pkts:
        if ty in (0x18, 0x2D) and len(ver) < 4:
            s = pl.split(b"\x00")[0].decode("utf-8", "replace")
            ver.append((f"0x{ty:02X}", clk, s))
    r["version_strings"] = ver
    return r


def main():
    out = []
    for p in REPLAYS:
        r = survey(p)
        out.append(r)
        if "error" in r:
            print(f"[FAIL] {r['file']}: {r['error']}")
            continue
        print(f"\n=== {r['file']}")
        print(f"  player={r.get('player')}  vehicle={r.get('vehicle')}")
        print(f"  map={r.get('map')}  gameplayID={r.get('gameplayID')}  battleType={r.get('battleType')}")
        print(f"  dt={r.get('datetime')}  region={r.get('regionCode')}  mods={r.get('hasMods')}"
              f"  ver={r.get('clientVersionFromExe')}")
        print(f"  pkts={r['npkts']}  0x3D={r['n_0x3D']}  digests={r['digests'][:3]}")
        print(f"  types={dict(list(r['types'].items())[:12])}")
        print(f"  version_strings={r['version_strings']}")
    with open("/tmp/wot/new_replay_survey.json", "w") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    print("\n[saved] /tmp/wot/new_replay_survey.json")


if __name__ == "__main__":
    main()
