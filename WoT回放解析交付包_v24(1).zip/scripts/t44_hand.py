#!/usr/bin/env python3
"""t44_hand.py — 手工精解 class-0 的 44B/60B 长变体 + 0x37 组边界验证
"""
import struct, sys, glob
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load

F = '/tmp/wot/github_test/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay'
blocks, declared, slen, pkts = load(F)

# 找 44B / 60B 的 0x32
shown = 0
for i, (t, c, p) in enumerate(pkts):
    if t == 0x32 and len(p) in (44, 60):
        print(f'=== pkt#{i} len={len(p)}')
        print('   ', p.hex(' '))
        # 可打印串
        s = p[4:]
        j = 0
        while j < len(s):
            n = s[j]
            if 3 <= n <= 40 and j+1+n <= len(s) and all(32 <= x < 127 for x in s[j+1:j+1+n]):
                print(f'    str@{j}: {s[j+1:j+1+n].decode()}')
                j += 1 + n
            else:
                j += 1
        shown += 1
        if shown >= 6:
            break

# 0x37: 全部 21B 包逐字节 + 349B 大包头部
print('\n=== 0x37 21B 样本(核对组结构) ===')
n = 0
for i, (t, c, p) in enumerate(pkts):
    if t == 0x37 and len(p) == 21:
        s = p[4:]
        nid = struct.unpack_from('>H', s, 0)[0]
        print(f'  nid={nid} ({hex(nid)}): {s.hex(" ")}')
        n += 1
        if n >= 6:
            break

print('\n=== 0x37 349B 大包(pkt#1218 前部+后部) ===')
for i, (t, c, p) in enumerate(pkts):
    if t == 0x37 and len(p) == 349:
        s = p[4:]
        print('头 80B:', s[:80].hex(' '))
        print('尾 60B:', s[-60:].hex(' '))
        break

# 0x37 长度-组数关系: 假设组 = 7B 或 10B
from collections import Counter
lens = Counter(len(p)-4 for _, (t, c, p) in enumerate(pkts) if t == 0x37)
print('\n0x37 流长度分布(前20):', sorted(lens.items())[:20])
