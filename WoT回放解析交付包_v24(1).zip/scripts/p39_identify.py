#!/usr/bin/env python3
"""p39_identify.py — 0x39 追踪车辆的型号识别

0x05 Vehicle 载荷含变长字符串(vehicleType/name 等), 对 karelia/WZ-219:
  1) 找出轨迹起点附近的候选 eid
  2) dump 这些 eid 的 0x05 载荷中的 ASCII 串
  3) 对应 block1 名册 → 车型 + 队伍 + 玩家
"""
import json
import math
import re
import struct
import zlib

from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])

SRC = {
    "karelia_EU": ("/tmp/wot/github_test/20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay",
                   (236.3, 44.1, 334.3)),
    "WZ219_EU": ("/tmp/wot/github_test/WZ-219.wotreplay",
                 (24.1, 7.3, -435.5)),
    "karelia2_EU": ("/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay",
                    (-318.1, 44.3, -265.1)),
    "siegfried_EU": ("/tmp/wot/github_test/20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay",
                     None),
}


def load_pkts(path):
    data = open(path, "rb").read()
    (magic, bc) = struct.unpack_from("<II", data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from("<I", data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b"\x00" * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        d = cipher.decrypt(main[i:i + 8])
        d = bytes(a ^ b for a, b in zip(d, prev))
        prev = d
        out += d
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from("<III", stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


def get_blocks(path):
    data = open(path, "rb").read()
    (magic, bc) = struct.unpack_from("<II", data, 0)
    pos = 8
    blocks = []
    for _ in range(bc):
        (blen,) = struct.unpack_from("<I", data, pos)
        blocks.append(data[pos + 4:pos + 4 + blen])
        pos += 4 + blen
    return blocks


def main():
    for tag, (path, start_pos) in SRC.items():
        pkts = load_pkts(path)
        # 0x05 车辆: eid + 位置 + 载荷
        veh05 = {}
        for ty, clk, pl in pkts:
            if ty == 5 and len(pl) >= 30:
                eid, n = struct.unpack_from("<II", pl, 0)
                if n == 6:
                    x, y, z = struct.unpack_from("<fff", pl, 18)
                    veh05[eid] = (x, y, z, pl)
        # 0x39 首包位置
        p72 = [(c, p) for ty, c, p in pkts if ty == 0x39 and len(p) == 72]
        if not p72:
            continue
        if start_pos is None:
            start_pos = struct.unpack_from("<fff", p72[0][1], 42)
        x0, y0, z0 = start_pos
        print(f"\n########## {tag}: 0x39 起点({x0:.1f},{y0:.1f},{z0:.1f}) ##########")
        # 附近候选(半径 60m)
        cands = sorted(veh05.items(),
                       key=lambda kv: math.dist((kv[1][0], kv[1][1], kv[1][2]), start_pos))
        near = [(eid, v, math.dist((v[0], v[1], v[2]), start_pos)) for eid, v in cands[:6]]
        # block1 名册
        blocks = get_blocks(path)
        data = json.loads(blocks[1])
        d1 = data[1]
        # avatarSessionID → dbid 映射(名册里)
        print("距离起点最近的车辆:")
        for eid, v, dist in near:
            x, y, z, pl = v
            # 载荷中的 ASCII 串
            strs = re.findall(rb"[\x20-\x7e]{4,}", pl)
            strs = [s.decode() for s in strs if not s.isdigit()][:6]
            print(f"  eid={eid} d={dist:5.1f}m pos=({x:6.1f},{y:5.1f},{z:6.1f}) len={len(pl)}")
            print(f"      strings: {strs}")
        # 载荷里含 : 的串(车型格式 nation-Name)
        print("全部 0x05 车辆的车型串:")
        vt_count = {}
        for eid, (x, y, z, pl) in veh05.items():
            for s in re.findall(rb"[a-z]{3,12}:[A-Za-z0-9_\-]{3,30}", pl):
                vt_count.setdefault(s.decode(), []).append(eid)
        for vt, eids in sorted(vt_count.items(), key=lambda kv: -len(kv[1])):
            print(f"  {vt}: {len(eids)} 辆 {eids[:4]}")


if __name__ == "__main__":
    main()
