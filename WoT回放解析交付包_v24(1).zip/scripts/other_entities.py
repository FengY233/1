#!/usr/bin/env python3
"""other_entities.py — 非 Vehicle 实体的 0x05 属性流分析 (干净样本)
typeID: 3=ArenaInfo, 7=AreaDestructibles, 40=NetworkEntity, 18/28/29=?
验证 [u8 count][[u8 idx][val]] 模型 + 无组件时的纯实体流
"""
import struct, zlib, sys
from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])

sys.path.insert(0, '/home/z/my-project/scripts')


def load_pkts(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from('<I', data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b'\x00' * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        dd = cipher.decrypt(main[i:i + 8])
        dd = bytes(a ^ b for a, b in zip(dd, prev))
        prev = dd
        out += dd
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from('<III', stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


path = "/tmp/wot/github_test/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay"
pkts = load_pkts(path)
e05 = [pl for ty, c, pl in pkts if ty == 5]
from collections import Counter
tc = Counter(struct.unpack_from('<I', pl, 4)[0] for pl in e05)
print('0x05 typeID 分布:', dict(tc))

# 各类型首例 dump
seen = set()
for pl in e05:
    tid = struct.unpack_from('<I', pl, 4)[0]
    if tid in seen or tid == 6:
        continue
    seen.add(tid)
    eid = struct.unpack_from('<I', pl, 0)[0]
    propBytes = struct.unpack_from('<I', pl, 42)[0]
    count = pl[46] if len(pl) > 46 else -1
    print(f'\n== typeID={tid} eid={eid} plen={len(pl)} propBytes={propBytes} count={count}')
    h = pl[46:46 + 96].hex()
    for k in range(0, len(h), 64):
        print(f'   {h[k:k+64]}')
    if len(seen) >= 6:
        break

# AvatarInfo/TeamInfo 若存在: 0x05 里可能没有 (登录期创建)
# NetworkEntity (40): 看 3 例
print('\n== NetworkEntity (40) 全部:')
n = 0
for pl in e05:
    if struct.unpack_from('<I', pl, 4)[0] == 40:
        eid = struct.unpack_from('<I', pl, 0)[0]
        pb = struct.unpack_from('<I', pl, 42)[0]
        print(f'  eid={eid} plen={len(pl)} propBytes={pb} count={pl[46]}')
        print(f'   {pl[46:46+80].hex()}')
        n += 1
        if n >= 3:
            break
