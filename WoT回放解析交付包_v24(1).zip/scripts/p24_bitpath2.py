#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
p24_bitpath2.py — Task36①: 0x24 压缩路径位流 v2（写入端白盒校准）
关键修正(addCompressedPathToStream 白盒):
  首层位宽 = bitsRequired(numClientServerProperties), 首 index = csi（非 76 声明序!）
  后续层位宽 = bitsRequired(indexLength)（子 owner 属性数, 由父类型决定）
  isSlice=0 (nestedEntityProperty): 只嵌套路径, 尾 = Single leafIndex
  isSlice=1 (sliceEntityProperty): 尾 = start/end 双宽位
"""
import json
import struct
import sys
from collections import Counter

sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import REPLAYS, load_pkts  # noqa: E402
from p24_bitpath import BitReader, bits_required  # noqa: E402


def load_csi_names():
    t = json.load(open('/home/z/my-project/download/csi_tables_v8.json'))
    names = {}
    for etype, e in t['entities'].items():
        for p in e.get('properties', []):
            names[(etype, p['csi'])] = p['name']
        names[(etype, 'nCS')] = len(e.get('properties', []))
    return names


def main():
    csin = load_csi_names()
    p05 = json.load(open('/tmp/wot/p05_decoded.json'))
    eid2type = {r['eid']: (r['typeName'], r['typeID']) for r in p05}

    # 每类型 numCS（csi 表实体条目数）
    NCS = {}
    for (etype, k) in csin:
        if k == 'nCS':
            NCS[etype] = csin[(etype, k)]
    print('numCS:', {k: v for k, v in sorted(NCS.items())})

    top = Counter()          # (typeName, csi) 分布
    veh_samples = []
    for tag, path in REPLAYS:
        pkts = load_pkts(path)
        for ty, c, pl in pkts:
            if ty != 0x24 or len(pl) < 10:
                continue
            eid, = struct.unpack_from('<I', pl, 0)
            is_slice = pl[4]
            body = pl[9:]
            tn, tid = eid2type.get(eid, ('?', -1))
            ncs = NCS.get(tn)
            if not ncs:
                continue
            br = BitReader(body)
            if br.get(1) == 0:
                csi = br.get(bits_required(ncs))
                top[(tn, csi, 'flat')] += 1
                continue
            csi = br.get(bits_required(ncs))
            top[(tn, csi, 'nested')] += 1
            if tn == 'Vehicle' and len(veh_samples) < 24:
                veh_samples.append((csi, is_slice, body[:20].hex()))

    print('\n== (类型, csi, 模式) top45 ==')
    for (tn, csi, mode), n in top.most_common(45):
        nm = csin.get((tn, csi), '?')
        print(f'  {tn:18s} csi={csi:3d} {mode:6s} {nm:26s} n={n}')
    print('\n== Vehicle 样本 (csi, isSlice, body前20B) ==')
    for s in veh_samples:
        print('  ', s)

    json.dump({f'{tn}|{csi}|{m}': n for (tn, csi, m), n in top.items()},
              open('/tmp/wot/p24_top_csi.json', 'w'), ensure_ascii=False, indent=1)
    print('\n[saved] /tmp/wot/p24_top_csi.json')


if __name__ == '__main__':
    main()
