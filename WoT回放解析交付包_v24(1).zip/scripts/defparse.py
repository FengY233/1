#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
defparse.py — WoT 服务器 entity_defs 解析 + vanilla EntityDescriptionMap::digest() 复刻
依据 BigWorld-Engine-14.4.1 源码逐条实现（详见 findings.md v10）。

用法：
  from defparse import EntityDefParser
  p = EntityDefParser(scripts_dir)
  p.load()
  print(p.entity_digest())          # vanilla 语义 digest（大写 hex）
"""
import os
import struct
import hashlib
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bwxml import decode_file

# ---------------- MD5（分块喂入等价标准 MD5；分界不影响结果，仅为对齐 vanilla append 调用） ----------------
class MD5(object):
    def __init__(self):
        self.h = hashlib.md5()

    def append(self, data):
        if data:
            self.h.update(bytes(data))

    def append_int32(self, v):
        self.append(struct.pack('<i', v))

    def append_uint32(self, v):
        self.append(struct.pack('<I', v))

    def append_uint8(self, v):
        self.append(struct.pack('<B', v & 0xFF))

    def append_uint16(self, v):
        """v16 修复：fork 方法 flags 走 calculator slot10 = u16 喂入器
        (FUN_1403e8260: mov word ptr [rsp+0x40], r8w; r9d=2)，
        调用点 movzx 零扩展 → 实喂 2 字节 LE [flags, 0x00]"""
        self.append(struct.pack('<H', v & 0xFFFF))

    def getDigestQuote(self):
        return self.h.hexdigest().upper()


# ---------------- 数据类型 ----------------
class DT(object):
    """DataType 等价物。kind ∈ {'INT','FLOAT','VECTOR','STRING','UNICODE_STRING','BLOB',
    'MAILBOX','PYTHON','UDO_REF','ARRAY','TUPLE','FIXED_DICT','CLASS','USER'}"""
    __slots__ = ('kind', 'signed', 'size', 'n', 'elem', 'seq_size', 'db_len',
                 'fields', 'allow_none', 'module', 'instance')

    def __init__(self, kind, **kw):
        self.kind = kind
        self.signed = kw.get('signed', True)
        self.size = kw.get('size', 0)          # INT 字节数
        self.n = kw.get('n', 0)                # VECTOR 元素数
        self.elem = kw.get('elem', None)       # ARRAY/TUPLE 元素类型
        self.seq_size = kw.get('seq_size', 0)  # ARRAY/TUPLE size（-1 变长）
        self.db_len = kw.get('db_len', 0)
        self.fields = kw.get('fields', None)   # [(name, DT)]
        self.allow_none = kw.get('allow_none', False)
        self.module = kw.get('module', '')
        self.instance = kw.get('instance', '')

    # ---- streamSize（vanilla 各 DataType::streamSize） ----
    def streamSize(self):
        k = self.kind
        if k == 'INT':
            return self.size
        if k == 'FLOAT':
            return 4 if self.size == 4 else 8
        if k == 'VECTOR':
            return 4 * self.n
        if k == 'MAILBOX':
            return 24  # sizeof(EntityMailBoxRef) — 见下文说明（不进 CS 属性，实际不会用到）
        if k == 'UDO_REF':
            return 16  # sizeof(UniqueID)
        if k in ('STRING', 'UNICODE_STRING', 'PYTHON', 'USER'):
            return -1
        if k == 'BLOB':
            return -1  # blob_data_type streamSize 未覆写？vanilla 未列出 -> DataType 基类？见备注
        if k in ('ARRAY', 'TUPLE'):
            s = self.elem.streamSize()
            v = self.seq_size * s
            return v if v > 0 else -1
        if k == 'FIXED_DICT':
            # fork 实测（v8 回放锚点验证）：AllowNone 不再使 streamSize=-1，
            # 一律为字段定长和（DOT_EFFECT=14/BUFF_EFFECT=24/REMOTE_CAMERA_DATA=22 实证）
            total = 0
            for _n, t in self.fields:
                fs = t.streamSize()
                if fs == -1:
                    return -1
                total += fs
            return total
        if k == 'CLASS':
            return -1
        raise ValueError(k)

    # ---- addToMD5（vanilla 各 DataType::addToMD5，逐字节对齐） ----
    def add_to_md5(self, md5):
        k = self.kind
        if k in ('ARRAY', 'TUPLE'):
            md5.append((('Array' if k == 'ARRAY' else 'Tuple') + '\0').encode('ascii'))  # sizeof("Array") 含 NUL
            # SequenceDataType::addToMD5
            md5.append_int32(self.seq_size)
            if self.db_len > 0:
                md5.append_int32(self.db_len)
            self.elem.add_to_md5(md5)
            return
        if k == 'BLOB':
            md5.append(b'Blob\x00')
            return
        if k == 'CLASS':
            md5.append(b'Class\x00')
            md5.append_uint8(1 if self.allow_none else 0)   # sizeof(bool)=1
            for name, t in self.fields:
                md5.append(name.encode('utf-8'))            # 无 NUL
                t.add_to_md5(md5)
            return
        if k == 'FIXED_DICT':
            md5.append(b'FixedDict\x00')
            # SCRIPT_PYTHON 下：!isCustomClassImplInited_ || hasCustomClass()
            # digest 在启动期计算 -> isCustomClassImplInited_=false -> 恒喂（空串=0字节）
            md5.append(self.module.encode('utf-8'))
            md5.append(self.instance.encode('utf-8'))
            md5.append_uint8(1 if self.allow_none else 0)
            for name, t in self.fields:
                md5.append(name.encode('utf-8'))
                t.add_to_md5(md5)
            return
        if k == 'MAILBOX':
            md5.append(b'MailBox\x00')
            return
        if k == 'PYTHON':
            md5.append(b'Python\x00')
            return
        if k == 'STRING':
            md5.append(b'String\x00')
            return
        if k == 'UDO_REF':
            md5.append(b'UserDataObjectLinkDataType\x00')
            return
        if k == 'UNICODE_STRING':
            md5.append(b'UnicodeString\x00')
            return
        if k == 'USER':
            md5.append(b'User\x00')
            md5.append(self.module.encode('utf-8'))
            md5.append(self.instance.encode('utf-8'))
            return
        if k == 'INT':
            md5.append((('Int' if self.signed else 'Uint') + '\0').encode('ascii'))
            md5.append_int32(self.size)
            return
        if k == 'FLOAT':
            md5.append(b'Float\x00' if self.size == 4 else b'Float64\x00')
            return
        if k == 'VECTOR':
            md5.append(b'Vector\x00')
            md5.append_int32(self.n)
            return
        raise ValueError(k)

    def signature(self):
        """方法签名比较用（isSignatureEqual 的粗等价：类型树相同即可）"""
        return (self.kind, self.signed, self.size, self.n,
                self.elem.signature() if self.elem else None,
                self.seq_size, self.db_len,
                [(n, t.signature()) for n, t in self.fields] if self.fields is not None else None,
                self.allow_none, self.module, self.instance)


# ---------------- Flags 映射（data_description.cpp s_entityDataFlagMappings） ----------------
DATA_GHOSTED = 0x01
DATA_OTHER_CLIENT = 0x02
DATA_OWN_CLIENT = 0x04
DATA_BASE = 0x08
DATA_CLIENT_ONLY = 0x10
DATA_PERSISTENT = 0x20
DATA_EDITOR_ONLY = 0x40
DATA_ID = 0x80
DATA_REPLAY = 0x100
DATA_DISTRIBUTION_FLAGS = (DATA_GHOSTED | DATA_OTHER_CLIENT | DATA_OWN_CLIENT |
                           DATA_BASE | DATA_CLIENT_ONLY | DATA_EDITOR_ONLY)
CS_MASK = DATA_OTHER_CLIENT | DATA_OWN_CLIENT | DATA_REPLAY   # isClientServerData

FLAG_MAP = {
    'CELL_PRIVATE': 0,
    'CELL_PUBLIC': DATA_GHOSTED,
    'OTHER_CLIENTS': DATA_GHOSTED | DATA_OTHER_CLIENT,
    'OWN_CLIENT': DATA_OWN_CLIENT,
    'BASE': DATA_BASE,
    'BASE_AND_CLIENT': DATA_OWN_CLIENT | DATA_BASE,
    'CELL_PUBLIC_AND_OWN': DATA_GHOSTED | DATA_OWN_CLIENT,
    'ALL_CLIENTS': DATA_GHOSTED | DATA_OTHER_CLIENT | DATA_OWN_CLIENT,
    'EDITOR_ONLY': DATA_EDITOR_ONLY,
}

# MethodDescription::Component
COMP_CLIENT, COMP_CELL, COMP_BASE = 0, 1, 2
IS_EXPOSED_TO_ALL_CLIENTS = 0x4
IS_EXPOSED_TO_OWN_CLIENT = 0x8


class Property(object):
    __slots__ = ('name', 'flags', 'dt', 'var_len_header', 'index', 'csi', 'is_client_server',
                 'is_volatile')

    def __init__(self, name, flags, dt, vlh):
        self.name = name
        self.flags = flags
        self.dt = dt
        self.var_len_header = vlh          # uint，默认 1
        self.index = -1
        self.csi = -1
        self.is_client_server = bool(flags & CS_MASK)
        self.is_volatile = 0               # fork: prop+0xb3（<Volatile><Properties> 标记）

    def stream_size(self):
        s = self.dt.streamSize()
        if s < 0:
            return -self.var_len_header
        return s


class Method(object):
    __slots__ = ('name', 'flags', 'args', 'var_len_header', 'is_for_client', '_stream_size', '_internal')

    def __init__(self, name, flags, args, vlh, is_for_client):
        self.name = name
        self.flags = flags
        self.args = args
        self.var_len_header = vlh
        self.is_for_client = is_for_client

    def is_exposed(self):
        return bool(self.flags & (IS_EXPOSED_TO_ALL_CLIENTS | IS_EXPOSED_TO_OWN_CLIENT))

    def signature_equal(self, other):
        return len(self.args) == len(other.args) and all(
            a.signature() == b.signature() for a, b in zip(self.args, other.args))


class EntityDescription(object):
    def __init__(self, name):
        self.name = name
        self.client_name = name
        self.properties = []          # list[Property]（覆盖式替换）
        self.prop_map = {}            # name -> index in properties（含组件前缀，见 parser）
        self.cs_props = []            # list[property index]（csi 排序池）
        self.client_methods = []
        self.base_methods = []
        self.cell_methods = []
        self.client_map = {}
        self.base_map = {}
        self.cell_map = {}

    def allocate_csi(self):
        # stable_sort by (定长在前, |size| 升序)，等价比较器见 entity_description.cpp 841-886
        def key(idx):
            s = self.properties[idx].stream_size()
            return (0, s) if s >= 0 else (1, -s)
        self.cs_props.sort(key=key)   # Python sort 即稳定排序
        for i, idx in enumerate(self.cs_props):
            self.properties[idx].csi = i

    def add_to_md5(self, md5):
        md5.append(self.name.encode('utf-8'))                 # 无 NUL 无长度
        for p in self.properties:
            if not p.is_client_server:
                continue
            md5.append_int32(p.csi)                           # clientServerFullIndex
            # DataDescription::addToMD5
            #   MemberDescription::addToMD5
            ss = p.stream_size()
            if ss < 0 and p.var_len_header != 1:
                md5.append_uint32(p.var_len_header)
            md5.append(p.name.encode('utf-8'))                # 无 NUL
            #   dataFlags & DATA_DISTRIBUTION_FLAGS
            md5.append_int32(p.flags & DATA_DISTRIBUTION_FLAGS)
            #   pDataType_->addToMD5
            p.dt.add_to_md5(md5)
        # client 方法：全部，count 从 0
        count = 0
        for m in self.client_methods:
            self._method_to_md5(md5, m, count)
            count += 1
        # base 方法：仅 exposed
        count = 0
        for m in self.base_methods:
            if m.is_exposed():
                self._method_to_md5(md5, m, count)
                count += 1
        # cell 方法：仅 exposed
        count = 0
        for m in self.cell_methods:
            if m.is_exposed():
                self._method_to_md5(md5, m, count)
                count += 1

    @staticmethod
    def _method_to_md5(md5, m, legacy_exposed_index):
        # MemberDescription::addToMD5
        if m.is_for_client:
            ss = -1  # MethodDescription::getServerToClientStreamSize：方法参数流大小
            # 见 parser 中计算（var len 判定）
            if m.var_len_header != 1 and m._stream_size < 0:
                md5.append_uint32(m.var_len_header)
        md5.append(m.name.encode('utf-8'))
        # flags_ (uint8)
        md5.append_uint8(m.flags)
        # args
        for a in m.args:
            a.add_to_md5(md5)
        # legacyExposedIndex (int32)
        md5.append_int32(legacy_exposed_index)


class EntityDefParser(object):
    def __init__(self, scripts_dir):
        self.scripts = scripts_dir
        self.entities = []            # vector_ 顺序
        self.alias = {}               # 名称 -> DT
        self._warn = []

    # ---------------- 顶层 ----------------
    def load(self):
        self._load_aliases()
        ents = decode_file(os.path.join(self.scripts, 'entities.xml'), 'entities.xml')
        cse = ents.child('ClientServerEntities')
        assert cse is not None, 'entities.xml 缺 ClientServerEntities'
        for c in cse.children:
            ed = EntityDescription(c.name)
            self._parse_entity_def(ed, c.name, '')
            self.entities.append(ed)
        # services.xml（若存在）追加但非 client type，不进 digest —— 略

    def entity_digest(self):
        md5 = MD5()
        for ed in self.entities:
            if ed.name == ed.client_name:   # isClientType
                ed.add_to_md5(md5)
        return md5.getDigestQuote()

    # ---------------- def 解析 ----------------
    def _defs_dir(self):
        return os.path.join(self.scripts, 'entity_defs')

    def _open_def(self, path):
        if not os.path.exists(path):
            raise FileNotFoundError(path)
        return decode_file(path, os.path.basename(path))

    def _parse_entity_def(self, ed, name, component):
        """EntityDescription::parse(name, componentName, decider=HasClientScript(true))"""
        path = os.path.join(self._defs_dir(), name + '.def')
        sec = self._open_def(path)
        parent = sec.readString('Parent')
        if parent:
            self._parse_entity_def(ed, parent, component)
        ed.name = name
        ed.client_name = sec.readString('ClientName', '') or name
        self._parse_interface(ed, sec, name, component)

    def _parse_interface(self, ed, sec, interface_name, component):
        """EntityDescription::parseInterface（含 BaseUserDataObjectDescription 部分）"""
        # Implements -> 每个 interface 的 .def 递归 parseInterface（虚分发到实体版）
        impl = sec.child('Implements')
        if impl is not None:
            for c in impl.children:
                iname = c.asString()
                ipath = os.path.join(self._defs_dir(), 'interfaces', iname + '.def')
                isec = self._open_def(ipath)
                self._parse_interface(ed, isec, iname, component)
        # Properties
        props = sec.child('Properties')
        if props is not None:
            self._parse_properties(ed, props, component)
        # Methods: Base -> Cell -> Client
        self._parse_methods(ed, sec, interface_name, component)
        # TempProperties：不进 digest，略
        # Components
        comps = sec.child('Components')
        if comps is not None:
            self._parse_components(ed, comps, interface_name)

    def _parse_components(self, ed, comps, interface_name):
        for c in comps.children:
            ctype = c.name
            cpath = os.path.join(self.scripts, 'component_defs', ctype + '.def')
            csec = self._open_def(cpath)
            cname = c.readString('name', ctype)
            # parseComponent: Properties -> TempProperties -> Methods
            props = csec.child('Properties')
            if props is not None:
                self._parse_properties(ed, props, cname)
            self._parse_methods(ed, csec, interface_name, cname)

    def _parse_properties(self, ed, props, component):
        for c in props.children:
            p = self._parse_property(c)
            if p is None:
                continue
            key = (component, p.name)
            if key in ed.prop_map:
                idx = ed.prop_map[key]
                old = ed.properties[idx]
                if p.is_client_server and old.is_client_server:
                    p.csi = old.csi
                    p.index = idx
                    ed.cs_props[old.csi] = idx if False else ed.cs_props[old.csi]
                    # 覆盖：properties_[index] = 新描述（csi 保持）
                    ed.properties[idx] = p
                elif p.is_client_server:
                    # 旧的不是 CS（理论上不可能：同名同位置 flags 变化）——按 vanilla 逻辑走 else 分支
                    p.index = idx
                    ed.properties[idx] = p
                    p.csi = len(ed.cs_props)
                    ed.cs_props.append(idx)
                else:
                    p.index = idx
                    ed.properties[idx] = p
                    if old.is_client_server:
                        # 覆盖后不再是 CS：vanilla 会保留 cs_props 条目但属性已非 CS —— addToMD5 只看
                        # isClientServerData，故 cs_props 里的陈旧条目不再喂。csi 池保留（保守处理）。
                        pass
            else:
                p.index = len(ed.properties)
                ed.properties.append(p)
                ed.prop_map[key] = p.index
                if p.is_client_server:
                    p.csi = len(ed.cs_props)
                    ed.cs_props.append(p.index)
        ed.allocate_csi()

    def _parse_property(self, c):
        name = c.name
        tsec = c.child('Type')
        if tsec is None:
            raise ValueError('property %s missing Type' % name)
        dt = self._build_type(tsec)
        flags_str = c.readString('Flags')
        if flags_str not in FLAG_MAP:
            raise ValueError('property %s: bad Flags %r' % (name, flags_str))
        flags = FLAG_MAP[flags_str]
        if c.readBool('Persistent', False):
            flags |= DATA_PERSISTENT
        if c.readBool('Identifier', False):
            flags |= DATA_ID
        # EDITOR_ONLY -> 整个属性跳过（非编辑器构建）
        if flags & DATA_EDITOR_ONLY:
            return None
        vlh = 1
        v = c.child('VariableLengthHeaderSize')
        if v is not None:
            vlh = v.asInt(1)
        return Property(name, flags, dt, vlh)

    def _parse_methods(self, ed, sec, interface_name, component):
        base = sec.child('BaseMethods')
        if base is not None:
            self._parse_method_list(ed, base, COMP_BASE, interface_name, component)
        cell = sec.child('CellMethods')
        if cell is not None:
            self._parse_method_list(ed, cell, COMP_CELL, interface_name, component)
        client = sec.child('ClientMethods')
        if client is not None:
            self._parse_method_list(ed, client, COMP_CLIENT, interface_name, component)

    def _parse_method_list(self, ed, sec, comp, interface_name, component):
        lst, mp = {
            COMP_BASE: (ed.base_methods, ed.base_map),
            COMP_CELL: (ed.cell_methods, ed.cell_map),
            COMP_CLIENT: (ed.client_methods, ed.client_map),
        }[comp]
        for c in sec.children:
            m = self._parse_method(c, comp)
            if m.name in mp:
                old = lst[mp[m.name]]
                if not m.signature_equal(old):
                    raise ValueError('method %s redefined with different signature' % m.name)
                continue  # 首定义保留
            mp[m.name] = len(lst)
            lst.append(m)

    def _parse_method(self, c, comp):
        name = c.name
        flags = comp & 0x3      # component 位（CLIENT=0 不置位）
        exp = c.child('Exposed')
        if exp is not None:
            if comp == COMP_CLIENT:
                raise ValueError('client method %s has Exposed' % name)
            s = exp.asString()
            if comp == COMP_CELL and s == 'ALL_CLIENTS':
                flags |= IS_EXPOSED_TO_ALL_CLIENTS
            elif s == 'OWN_CLIENT':
                flags |= IS_EXPOSED_TO_OWN_CLIENT
            elif s == '':
                flags |= IS_EXPOSED_TO_ALL_CLIENTS | IS_EXPOSED_TO_OWN_CLIENT
            else:
                raise ValueError('method %s: bad Exposed %r' % (name, s))
        if comp == COMP_CLIENT:
            flags |= IS_EXPOSED_TO_ALL_CLIENTS    # 所有 client 方法视为 exposed
        # args
        args_sec = c.child('Args')
        args = []
        if args_sec is not None:
            for a in args_sec.children:
                args.append(self._build_type(a))
        else:
            # 旧式：直接子节点里名为 Arg 的（WoT def 不用；遇到即报错）
            for a in c.children:
                if a.name == 'Arg':
                    args.append(self._build_type(a))
        vlh = 1
        v = c.child('VariableLengthHeaderSize')
        if v is not None:
            vlh = v.asInt(1)
        m = Method(name, flags, args, vlh, comp == COMP_CLIENT)
        # 方法流大小（getServerToClientStreamSize -> args streamSize 和，任一变长则 -1）
        ss = 0
        for a in args:
            s = a.streamSize()
            if s == -1:
                ss = -1
                break
            ss += s
        m._stream_size = ss
        return m

    # ---------------- 类型构造（DataType::buildDataType） ----------------
    def _load_aliases(self):
        apath = os.path.join(self._defs_dir(), 'alias.xml')
        if not os.path.exists(apath):
            self._warn.append('no alias.xml')
            return
        asec = decode_file(apath, 'alias.xml')
        for c in asec.children:
            dt = self._build_type(c)
            if dt is not None:
                self.alias[c.name] = dt

    SIMPLE = {
        'INT8': ('INT', True, 1), 'INT16': ('INT', True, 2),
        'INT32': ('INT', True, 4), 'INT64': ('INT', True, 8),
        'UINT8': ('INT', False, 1), 'UINT16': ('INT', False, 2),
        'UINT32': ('INT', False, 4), 'UINT64': ('INT', False, 8),
        'FLOAT32': ('FLOAT', False, 4), 'FLOAT': ('FLOAT', False, 4),
        'FLOAT64': ('FLOAT', False, 8),
        'VECTOR2': ('VECTOR', False, 2), 'VECTOR3': ('VECTOR', False, 3),
        'VECTOR4': ('VECTOR', False, 4),
        'STRING': ('STRING',), 'UNICODE_STRING': ('UNICODE_STRING',),
        'BLOB': ('BLOB',), 'MAILBOX': ('MAILBOX',),
        'PYTHON': ('PYTHON',), 'UDO_REF': ('UDO_REF',),
    }

    def _build_type(self, sec):
        """sec：作为类型描述的 DataSection（值=类型名，子节点=参数）"""
        tname = sec.asString()
        if tname in self.alias:
            return self.alias[tname]
        if tname in self.SIMPLE:
            s = self.SIMPLE[tname]
            if s[0] == 'INT':
                return DT('INT', signed=s[1], size=s[2])
            if s[0] == 'FLOAT':
                return DT('FLOAT', size=s[2])
            if s[0] == 'VECTOR':
                return DT('VECTOR', n=s[2])
            return DT(s[0])
        if tname in ('ARRAY', 'TUPLE'):
            size = sec.readInt('size', 0)
            pab = sec.readBool('persistAsBlob', False)
            of = sec.child('of')
            if of is None:
                raise ValueError('%s missing <of>' % tname)
            elem = self._build_type(of)
            db_len = 16777215 if pab else 0
            # 注意 vanilla readInt("size",0)；def 里变长数组通常写 <size>-1</size> 或不写
            return DT(tname, elem=elem, seq_size=size, db_len=db_len)
        if tname == 'FIXED_DICT':
            fields = []
            psec = sec.child('Parent')
            if psec is not None:
                pdt = self._build_type(psec)
                if pdt.kind != 'FIXED_DICT':
                    raise ValueError('FIXED_DICT Parent must be FIXED_DICT')
                fields = list(pdt.fields)
            props = sec.child('Properties')
            if props is None and not fields:
                raise ValueError('FIXED_DICT missing Properties')
            if props is not None:
                for c in props.children:
                    t = c.child('Type')
                    if t is None:
                        raise ValueError('FIXED_DICT field %s missing Type' % c.name)
                    fields.append((c.name, self._build_type(t)))
            allow_none = sec.readBool('AllowNone', False)
            impl = sec.readString('implementedBy')
            module = instance = ''
            if impl:
                pos = impl.rfind('.')
                module, instance = impl[:pos], impl[pos + 1:]
            return DT('FIXED_DICT', fields=fields, allow_none=allow_none,
                      module=module, instance=instance)
        if tname == 'CLASS':
            fields = []
            psec = sec.child('Parent')
            if psec is not None:
                pdt = self._build_type(psec)
                if pdt.kind != 'CLASS':
                    raise ValueError('CLASS Parent must be CLASS')
                fields = list(pdt.fields)
            props = sec.child('Properties')
            if props is None and not fields:
                raise ValueError('CLASS missing Properties')
            if props is not None:
                for c in props.children:
                    t = c.child('Type')
                    if t is None:
                        raise ValueError('CLASS field %s missing Type' % c.name)
                    fields.append((c.name, self._build_type(t)))
            allow_none = sec.readBool('AllowNone', False)
            return DT('CLASS', fields=fields, allow_none=allow_none)
        if tname == 'USER_TYPE':
            impl = sec.readString('implementedBy')
            if not impl:
                raise ValueError('USER_TYPE missing implementedBy')
            pos = impl.rfind('.')
            return DT('USER', module=impl[:pos], instance=impl[pos + 1:])
        raise ValueError('unknown data type %r' % tname)


# ---------------- main ----------------
if __name__ == '__main__':
    scripts_dir = sys.argv[1] if len(sys.argv) > 1 else \
        '/home/z/my-project/repos/scripts_x/scripts'
    p = EntityDefParser(scripts_dir)
    p.load()
    print('entities:', len(p.entities))
    print('digest:', p.entity_digest())
    if p._warn:
        print('warnings:', p._warn)
