#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
t37_sm.py — Task 37 ⑧：0x24 四通道全状态机验证（RULE X 映射 + vanilla 位语义 + 数组长度状态机）
通道(RULE X): 29=ownVehiclePosition 30=inspired 33=damageStickers(ARRAY<STICKER16B>) 34=publicStateModifiers(ARRAY<u16?>)
规则:
  path = [1][csi 6b][0] + Single:leafIdx bitsRequired(n) / Slice:start,end 各 bitsRequired(n+1)
  值 = body[ceil(bits/8):]
  damageStickers: 元素16B, 初始长度=0x05 的数组长度, slice(start,end)+值 → 新长度 = start + nnew + (len-end)
  验证: start≤len, end≤len, 值长%16==0, 且 nnew = 值长/16
"""
import struct, sys, json, collections
sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import REPLAYS, load_pkts

def bits_required(n):
    if n <= 1: return 0
    r = 0
    while (1 << r) < n: r += 1
    return r

class BR:
    def __init__(self, b): self.b = b; self.p = 0
    def get(self, n):
        v = 0
        for _ in range(n):
            v = (v << 1) | ((self.b[self.p >> 3] >> (7 - (self.p & 7))) & 1); self.p += 1
        return v
    def used(self): return (self.p + 7) >> 3

# 0x05 初始 damageStickers/publicStateModifiers 长度 per (tag, eid)
init = {}
d = json.load(open('/tmp/wot/p05_decoded.json'))
for r in d:
    if r.get('typeName') == 'Vehicle':
        p = r.get('props', {})
        init[(r['tag'], r['eid'])] = {
            'ds': len(p.get('damageStickers') or []),
            'psm': len(p.get('publicStateModifiers') or []),
        }

total = {'ok': 0, 'bad': 0}
bad_samples = []
for TAG, RP in REPLAYS:
    pkts = load_pkts(RP)
    eid2ty = {}
    for ty, clk, pl in pkts:
        if ty == 5 and len(pl) >= 8:
            e, n = struct.unpack_from('<II', pl, 0)
            eid2ty[e] = n
    p24 = [(c, pl) for ty, c, pl in pkts if ty == 0x24]
    state = {}  # eid -> {'ds': n, 'psm': m}
    for clk, pl in p24:
        eid, isl, ln = struct.unpack_from('<IBI', pl, 0)
        if eid2ty.get(eid) != 6: continue
        body = pl[9:9+ln]
        if len(body) < 2 or not (body[0] & 0x80): continue
        br = BR(body)
        if br.get(1) != 1: continue
        csi = br.get(6)
        if br.get(1) != 0: continue   # 只看无下钻包
        st = state.setdefault(eid, dict(init.get((TAG, eid), {'ds': 0, 'psm': 0})))
        if csi == 33:   # damageStickers ARRAY, elem 16B
            n = st['ds']
            nb = bits_required(n + 1)
            if isl:
                s, e = br.get(nb), br.get(nb)
                val = body[br.used():]
                ok = s <= n and e <= n and e <= s and len(val) % 16 == 0
                # BigWorld setOwnedSlice: 替换 [s,e) 为新元素
                st['ds'] = s + len(val)//16 + (n - e)
            else:
                idx = br.get(bits_required(n)) if n > 1 else 0
                val = body[br.used():]
                ok = idx < n and len(val) == 16
                st['ds'] = n
            total['ok' if ok else 'bad'] += 1
            if not ok and len(bad_samples) < 10:
                bad_samples.append((TAG, clk, eid, isl, n, body.hex()))
        elif csi == 34:  # publicStateModifiers ARRAY, elem 2B?
            n = st['psm']
            nb = bits_required(n + 1)
            if isl:
                s, e = br.get(nb), br.get(nb)
                val = body[br.used():]
                ok = s <= n and e <= n and e <= s and len(val) % 2 == 0
                st['psm'] = s + len(val)//2 + (n - e)
            else:
                idx = br.get(bits_required(n)) if n > 1 else 0
                val = body[br.used():]
                ok = idx < n and len(val) == 2
            total['ok' if ok else 'bad'] += 1
            if not ok and len(bad_samples) < 20:
                bad_samples.append((TAG, clk, eid, isl, n, body.hex()))

print('damageStickers+publicStateModifiers 状态机验证:', total)
for s in bad_samples[:10]:
    print('  BAD:', s)
