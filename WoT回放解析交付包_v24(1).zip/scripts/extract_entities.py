#!/usr/bin/env python3
"""extract_entities.py — 跨 11 场回放提取 0x05 实体创建与 0x08 方法调用真值锚

第一步：用 20260911_1801 的 jsonl (eid, n) 对校准 0x05 头格式假设 [u32 eid][u32 typeID]
第二步：11 场全量提取：
  - 0x05: (eid, typeID) → typeID 直方图 + eid 段分析
  - 0x08: (eid, methodID) → methodID 覆盖矩阵（验证 methodID 版本恒定性）
输出 /tmp/wot/entity_anchor.json
"""
import json
import struct
import sys
import zlib
from collections import Counter, defaultdict

from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])

REPLAYS = [
    ("siegfried_EU", "/tmp/wot/github_test/20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay"),
    ("karelia_EU", "/tmp/wot/github_test/20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay"),
    ("lakeville_EU", "/tmp/wot/github_test/20260907_1321_germany-G197_Pz_Kpfw_Neu_07_lakeville.wotreplay"),
    ("caucasus_NA", "/tmp/wot/github_test/20260910_1057_china-Ch67_BZ_79_37_caucasus.wotreplay"),
    ("namerica_CN", "/tmp/wot/github_test/20260911_1534_ussr-R52_Object_261_44_north_america.wotreplay"),
    ("tundra_CN_bt46", "/tmp/wot/github_test/20260911_1749_uk-GB156_Black_Prince_II_63_tundra.wotreplay"),
    ("caucasus_CN", "/tmp/wot/github_test/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay"),
    ("greatwall_EU", "/tmp/wot/github_test/20260912_1036_france-F143_Fauteur_59_asia_great_wall.wotreplay"),
    ("karelia2_EU", "/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay"),
    ("PTZ_10K_EU", "/tmp/wot/github_test/PTZ_10K.wotreplay"),
    ("WZ219_EU", "/tmp/wot/github_test/WZ-219.wotreplay"),
]


def load_pkts(path):
    data = open(path, "rb").read()
    (magic, bc) = struct.unpack_from("<II", data, 0)
    pos = 8
    blocks = []
    for _ in range(bc):
        (blen,) = struct.unpack_from("<I", data, pos)
        blocks.append(data[pos + 4:pos + 4 + blen])
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b"\x00" * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        d = cipher.decrypt(main[i:i + 8])
        d = bytes(a ^ b for a, b in zip(d, prev))
        prev = d
        out += d
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from("<III", stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


def calibrate_with_jsonl():
    """用 jsonl 的 (eid, n) 校准 0x05 格式"""
    jmap = {}
    for line in open("/tmp/wot/rjsonl/replay.jsonl"):
        r = json.loads(line)
        if r.get("t") == 5 and "n" in r and "eid" in r:
            jmap[r["eid"]] = r["n"]
    print(f"[calib] jsonl 0x05 行含 n 的: {len(jmap)} 条")
    pkts = load_pkts(REPLAYS[6][1])  # caucasus_CN
    ok, bad = 0, 0
    for ty, clk, pl in pkts:
        if ty != 5 or len(pl) < 8:
            continue
        eid, n = struct.unpack_from("<II", pl, 0)
        if eid in jmap:
            if jmap[eid] == n:
                ok += 1
            else:
                bad += 1
                if bad <= 3:
                    print(f"  [mismatch] eid={eid} jsonl.n={jmap[eid]} raw.n={n}")
    print(f"[calib] 假设 [u32 eid][u32 typeID] 验证: ok={ok} bad={bad}")
    return ok > 0 and bad == 0


def survey(tag, path):
    pkts = load_pkts(path)
    r = {"tag": tag}
    # 0x05: (eid, typeID)
    e05 = []
    for ty, clk, pl in pkts:
        if ty == 5 and len(pl) >= 8:
            eid, n = struct.unpack_from("<II", pl, 0)
            e05.append((eid, n))
    r["n05"] = len(e05)
    r["typeIDs"] = dict(Counter(n for _, n in e05))
    r["eid_min"] = min((e for e, _ in e05), default=0)
    r["eid_max"] = max((e for e, _ in e05), default=0)
    # 0x08: (eid, methodID)
    m08 = []
    for ty, clk, pl in pkts:
        if ty == 8 and len(pl) >= 8:
            eid, mid = struct.unpack_from("<II", pl, 0)
            m08.append((eid, mid))
    r["n08"] = len(m08)
    # eid → methodID 集合（去重后的稳定签名）
    sig = defaultdict(set)
    for e, m in m08:
        sig[e].add(m)
    r["eid_count"] = len(sig)
    # methodID 直方图
    r["mid_hist"] = dict(Counter(m for _, m in m08))
    # 存每场 eid 签名（eid, sorted mid set）
    r["eid_sigs"] = {str(e): sorted(s) for e, s in sig.items()}
    # ArenaInfo methodID=58 特征验证（updateArena）
    r["mid58_bodies"] = []
    for ty, clk, pl in pkts:
        if ty == 8 and len(pl) >= 8:
            eid, mid = struct.unpack_from("<II", pl, 0)
            if mid == 58 and len(r["mid58_bodies"]) < 2:
                r["mid58_bodies"].append(pl[8:24].hex())
    return r


def main():
    if not calibrate_with_jsonl():
        print("[ABORT] 0x05 格式校准失败")
        sys.exit(1)
    out = []
    for tag, path in REPLAYS:
        r = survey(tag, path)
        out.append(r)
        print(f"\n=== {tag}: 0x05={r['n05']} types={dict(sorted(r['typeIDs'].items()))}")
        print(f"    0x08={r['n08']} eids={r['eid_count']} mid_hist_top={dict(Counter(r['mid_hist']).most_common(8))}")
    with open("/tmp/wot/entity_anchor.json", "w") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    print("\n[saved] /tmp/wot/entity_anchor.json")


if __name__ == "__main__":
    main()
