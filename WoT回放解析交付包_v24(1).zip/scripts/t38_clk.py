#!/usr/bin/env python3
"""t38_clk.py — clk 纪元三段定标：预战斗段/战斗段单位/重定位点 + csi29/30 真实战斗时刻重算 + E 回归复测"""
import struct, zlib, json, glob
from collections import Counter
from Crypto.Cipher import Blowfish

KEY = bytes([0xDE,0x72,0xBE,0xA0,0xDE,0x04,0xBE,0xB1,0xDE,0xFE,0xBE,0xEF,0xDE,0xAD,0xBE,0xEF])

def load_pkts(path):
    data = open(path, "rb").read()
    magic, bc = struct.unpack_from("<II", data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from("<I", data, pos); pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    out = b""; prev = b"\x00"*8
    for i in range(0, len(main), 8):
        d = cipher.decrypt(main[i:i+8])
        d = bytes(a^b for a,b in zip(d, prev)); prev = d; out += d
    stream = zlib.decompress(bytes(out))
    pkts = []; q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from("<III", stream, q)
        pkts.append((ty, clock, stream[q+12:q+12+size])); q += 12 + size
    return pkts

Q20 = 1/(1<<20)

def analyze(path, tag):
    pkts = load_pkts(path)
    # 1. 找重定位点: 正向大跳变
    rebase = None; pre_max = 0
    for i in range(1, len(pkts)):
        d = pkts[i][1] - pkts[i-1][1]
        if d > 500 * (1<<20) // 1000:   # >500 Q20-s 跳变
            rebase = (i, pkts[i][1]*Q20, pkts[i-1][1]*Q20)
            break
        pre_max = max(pre_max, pkts[i][1]*Q20)
    # 2. 0x36 tick: 战斗段范围与中位差分
    t36 = [c for ty, c, _ in pkts if ty == 0x36]
    t1a = [c for ty, c, _ in pkts if ty == 0x1A]
    d36 = Counter()
    for a, b in zip(t36, t36[1:]):
        if b > a: d36[round((b-a)*Q20, 4)] += 1
    # 3. 战斗段总跨度
    battle_clks = [c for ty, c, _ in pkts if c*Q20 > (rebase[1]-5) if True]
    bmin = min(c for _, c, _ in pkts if c*Q20 >= rebase[1]-1)
    bmax = max(c for _, c, _ in pkts)
    unit = None
    if t36:
        n36 = len(t36)
        span36 = (t36[-1]-t36[0])*Q20
        # 若 0x36=10Hz 游戏tick: 游戏秒 = n36*0.1; 单位 = span/n36*10
        unit = span36 / (n36*0.1)
    print(f"\n== {tag} ==")
    print(f"  重定位: 包#{rebase[0]}  clk {rebase[2]:.3f} → {rebase[1]:.3f} (跳 +{rebase[1]-rebase[2]:.1f}s)")
    print(f"  预战斗段最后clk: {pre_max:.3f}s")
    print(f"  0x36: n={len(t36)}  范围[{t36[0]*Q20:.3f}, {t36[-1]*Q20:.3f}]  中位Δ={d36.most_common(3)}")
    print(f"  0x1A: n={len(t1a)}")
    print(f"  战斗段clk跨度: {bmin*Q20:.3f} → {bmax*Q20:.3f} = {(bmax-bmin)*Q20:.3f} Q20s")
    if unit:
        print(f"  → 战斗段单位: 1 Q20s = {unit:.4f} 游戏秒 (0x36 10Hz 假设)" if unit else "")
    return rebase, unit, bmin, bmax

FILES = [
    ("caucasus_CN_942", "20260911_1801_ussr-R52_Object_261_37_caucasus"),
    ("WZ219_EU_944", "WZ-219"),
    ("karelia2_EU_944", "20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia"),
    ("PTZ_EU_944", "PTZ_10K"),
]
info = {}
for tag, name in FILES:
    info[tag] = analyze(f"/tmp/wot/github_test/{name}.wotreplay", tag)

# csi29/30 真实战斗时刻重算
print("\n\n== csi29/30 真实战斗时刻重算 ==")
R = json.load(open("/tmp/wot/t38_align.json"))
for tag, (rebase, unit, bmin, bmax) in info.items():
    sub = [r for r in R if r["tag"] == tag and r["csi"] in (29, 30)]
    if not sub: continue
    bt = [(r["clk"]*Q20 - rebase[1]) * (unit or 6) for r in sub]  # 战斗相对秒
    es = [r["time"] for r in sub]
    pairs = sorted(zip(bt, es))
    print(f"  {tag}: 战斗时刻 {bt and min(bt):.1f}~{max(bt):.1f}s | E范围 {min(es):.0f}~{max(es):.0f}")
    if len(pairs) > 5:
        # E(ms?) vs 战斗秒 的斜率
        n = len(pairs); sx = sum(p[0] for p in pairs); sy = sum(p[1] for p in pairs)
        sxx = sum(p[0]**2 for p in pairs); sxy = sum(p[0]*p[1] for p in pairs)
        slope = (n*sxy-sx*sy)/(n*sxx-sx*sx)
        inter = (sy-slope*sx)/n
        res = [p[1]-(slope*p[0]+inter) for p in pairs]
        print(f"    E=f(战斗秒): slope={slope:.2f} inter={inter:.1f} |res|max={max(abs(x) for x in res):.1f}")
