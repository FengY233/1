#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
t37_ad.py — Task 37 ④：destroyedFragiles 数组增长 × slice 位宽漂移检验
AreaDestructibles numCS=4 → csi 2bit。csi=1 (destroyedFragiles)。
vanilla: path=[1][csi 2b][0] + start/end 各 bitsRequired(arrlen+1)
  → 值起点字节数 = ceil((4 + 2*nbits)/8)，随 arrlen 增长从 1B → 2B → 3B
fork(固定6bit): 恒定 3B（csi 用 6bit 读?）或其它
观测: 按时间序输出 (clk, body, 推断数组长度, 两种假设下的值)
"""
import struct, sys
sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import REPLAYS, load_pkts

def bits_of(bs): return ''.join(f'{x:08b}' for x in bs)

TAG, RP = None, None
for t, p in REPLAYS:
    if 'karelia2' in t or 'karelia_EU' in t: TAG, RP = t, p; break

pkts = load_pkts(RP)
p24 = [(c, pl) for ty, c, pl in pkts if ty == 0x24]
print(f'{TAG}: 0x24 n={len(p24)}')

# 只看 AreaDestructibles 的 csi=1 (eid 是 AD 实体)
n = 0
arrstate = {}  # eid -> 猜测数组长度
for clk, pl in p24:
    eid, isl, ln = struct.unpack_from('<IBI', pl, 0)
    body = pl[9:9+ln]
    if not body: continue
    b = body[0]
    if not (b & 0x80): continue
    csi = (b >> 1) & 0x3F
    if csi != 1: continue
    if isl != 1: continue
    # AreaDestructibles: numCS=4 → bitsRequired(4)=2
    # vanilla 位流: [1][csi 2b][0][start nb][end nb]  n=bitsRequired(arrlen+1)
    curlen = arrstate.get(eid, 1)
    nb = max(1, (curlen).bit_length())  # bitsRequired(len+1): len=1→1, 3→2, 7→3, 15→4...
    total_bits = 1 + 2 + 1 + 2*nb
    voff_vanilla = (total_bits + 7) // 8
    bstr = bits_of(body)
    start_v = int(bstr[4:4+nb], 2) if len(bstr) >= 4+nb else -1
    end_v = int(bstr[4+nb:4+2*nb], 2) if len(bstr) >= 4+2*nb else -1
    val_v = body[voff_vanilla:]
    val_fixed3 = body[3:]
    print(f'clk={clk} eid={eid} len={ln} body={body.hex()}')
    print(f'   假设len={curlen} nb={nb} bits={bstr[:16]} start={start_v} end={end_v} 值(范)={val_v.hex()} | 值(固3B)={val_fixed3.hex()}')
    # 更新数组长度猜测: 0x05 初始=1, 每个非空 slice 至少 +1
    if val_v and len(val_v) >= 2:
        arrstate[eid] = max(curlen, start_v + (len(val_v)//2) + 1, end_v + 1)
    n += 1
    if n >= 25: break
