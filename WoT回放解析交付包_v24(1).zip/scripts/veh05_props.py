#!/usr/bin/env python3
"""veh05_props.py — Vehicle 0x05 属性段全量解析器 + 11场验证
格式假设: [u32 eid][u32 typeID][10B头][pos 3f][ypr 3f][u32 propBytes][u8 count]×([u8 csi][typed value])
定长属性: streamSize 字节; 变长属性: [vlh 字节长度][数据]
输出: 每场解析通过率 + csi 出现矩阵 + perks/vehPostProgression 原始blob提取"""
import json, struct, zlib
from collections import Counter, defaultdict
from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])

REPLAYS = [
    ("siegfried_EU_935", "/tmp/wot/github_test/20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay"),
    ("karelia_EU_935", "/tmp/wot/github_test/20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay"),
    ("lakeville_EU_935", "/tmp/wot/github_test/20260907_1321_germany-G197_Pz_Kpfw_Neu_07_lakeville.wotreplay"),
    ("caucasus_NA_945", "/tmp/wot/github_test/20260910_1057_china-Ch67_BZ_79_37_caucasus.wotreplay"),
    ("namerica_CN_942", "/tmp/wot/github_test/20260911_1534_ussr-R52_Object_261_44_north_america.wotreplay"),
    ("tundra_CN_942", "/tmp/wot/github_test/20260911_1749_uk-GB156_Black_Prince_II_63_tundra.wotreplay"),
    ("caucasus_CN_942", "/tmp/wot/github_test/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay"),
    ("greatwall_EU_944", "/tmp/wot/github_test/20260912_1036_france-F143_Fauteur_59_asia_great_wall.wotreplay"),
    ("karelia2_EU_944", "/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay"),
    ("PTZ_EU_944", "/tmp/wot/github_test/PTZ_10K.wotreplay"),
    ("WZ219_EU_944", "/tmp/wot/github_test/WZ-219.wotreplay"),
]

# Vehicle csi 表 → (name, streamSize, vlh)
CSI = {}
d = json.load(open('/home/z/my-project/download/csi_tables_v8.json'))
for p in d['entities']['Vehicle']['properties']:
    vlh = 1
    CSI[p['csi']] = (p['name'], p['streamSize'], vlh)


def load_pkts(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from('<I', data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b'\x00' * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        dd = cipher.decrypt(main[i:i + 8])
        dd = bytes(a ^ b for a, b in zip(dd, prev))
        prev = dd
        out += dd
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from('<III', stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


def parse_props(pl, strict=True):
    """返回 (ok, entries, fail_reason) entries=[(csi, raw_value_bytes)]"""
    if len(pl) < 47:
        return False, None, 'short'
    propBytes, = struct.unpack_from('<I', pl, 42)
    if 46 + propBytes != len(pl):
        return False, None, f'propBytes {propBytes} != {len(pl)-46}'
    q = 46
    count = pl[q]; q += 1
    entries = []
    for i in range(count):
        if q >= len(pl):
            return False, entries, f'overrun @{i}'
        idx = pl[q]; q += 1
        if idx not in CSI:
            return False, entries + [(idx, None)], f'badidx {idx}@{i}'
        name, ss, vlh = CSI[idx]
        if ss > 0:
            if q + ss > len(pl):
                return False, entries, f'fixedoverrun @{i}'
            entries.append((idx, pl[q:q + ss]))
            q += ss
        else:
            if q + vlh > len(pl):
                return False, entries, f'vlhoverrun @{i}'
            n = int.from_bytes(pl[q:q + vlh], 'little'); q += vlh
            if q + n > len(pl):
                return False, entries, f'varoverrun @{i} n={n}'
            entries.append((idx, pl[q:q + n]))
            q += n
    if q != len(pl):
        return False, entries, f'trailing {len(pl)-q}B count={count}'
    return True, entries, None


def main():
    result = {}
    for tag, path in REPLAYS:
        pkts = load_pkts(path)
        veh = [pl for ty, c, pl in pkts if ty == 5 and len(pl) >= 47
               and struct.unpack_from('<I', pl, 4)[0] == 6]
        ok = 0
        fails = Counter()
        csi_seen = Counter()
        samples = []
        for pl in veh:
            good, entries, why = parse_props(pl)
            if good:
                ok += 1
                for idx, val in entries:
                    csi_seen[idx] += 1
                if len(samples) < 40:
                    samples.append({'len': len(pl),
                                    'entries': [(i, v.hex() if v is not None else None)
                                                for i, v in entries]})
            else:
                fails[why.split('@')[0] if why else '?'] += 1
        n = len(veh)
        print(f'{tag}: Vehicle×{n} 解析OK {ok} ({100*ok//max(n,1)}%)  失败: {dict(fails)}')
        print(f'   csi出现: {sorted(csi_seen.keys())}')
        result[tag] = {'n': n, 'ok': ok, 'fails': dict(fails),
                       'csi_seen': dict(csi_seen), 'samples': samples}
    json.dump(result, open('/tmp/wot/veh05_props.json', 'w'))
    print('\n[saved] /tmp/wot/veh05_props.json')


if __name__ == '__main__':
    main()
