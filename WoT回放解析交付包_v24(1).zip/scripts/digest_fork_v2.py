#!/usr/bin/env python3
"""digest_fork_v2.py — 0x3D 完整 fork digest 模型（v16 终态，V12 交付版）

演进：v13 白盒全解 → v15 u16 修复（方法 flags 2 字节）→ v16 client 方法真相
（fork 给 client 方法自动 |=0x4 → 三域统一 (flags&0xC)!=0 过滤）+ 扩展层并入。

模型（全部 decomp/机器码/0x08 运行时真值三层实证，见 findings §9-§12）：
  EntityDescriptionMap::parse (FUN_142a98830) 编排：
    0. spaces.xml → GeneralSpaceData 记录（decider 恒真）
    1. createEntityTypeToComponentSectionsMap (FUN_142a971a0)：
       Part a: components.xml <StaticComponents> 逐名载 scripts/component_defs/<N>.def
               → 其 <ofEntity> 每实体名 → multimap.insert(实体名→{组件名,section})
       Part b: extension.xml 根级 <ExternalComponents>——18 扩展全空 → 0 条扩展挂载边
               （v14「39 static 边」系误归因：.def 拼接证据 0x6665642e 属 Part a）
    2. 主实体 parseEntitiesBySide(ClientServer) (FUN_142a996e0)：40 实体
       （entities.xml 真实声明序，非字母序——0x05 真值：Account,Avatar,ArenaInfo,
        ClientSelectableObject,HangarVehicle,Vehicle(6th),AreaDestructibles(7th)…）
    3. loop#1 扩展实体：FeatureName 键有序 map（字母序）迭代 18 扩展，
       每扩展 extension.xml <Entities><ClientServerEntities>（side=0 仅 CS）
       → 10 扩展实体记录；dir=扩展名（机器码裁决 r8=[rsp+0x60] 同一挂载 multimap）
    4. parseDynamicComponents(主) (FUN_142a994c0, 空索引不挂载)：107 dyncomp
       （113 声明 − 3 无 client 脚本排除；decider=DynamicComponentsDescriptionHasPythonScript）
    5. loop#2 扩展 dyncomp：18 扩展字母序 × <Components><DynamicComponents>
       → 160 dyncomp（171 − 11 排除）
    记录集 = 1 + 40 + 10 + 107 + 160 = 318（FUN_142a99f30 全局名字 map 去重，无重叠）
  digest 遍历 (FUN_142a9b410)：DAT_14483e050 数组物理序 0x328 步长，仅 +0x87 过滤
  每记录 (FUN_142a93420)：
    name(slot12 无NUL) → CS 属性[csi i32][varLen u32 条件][name][flags&0x5F i32]
                        [isVolatile u8][类型] → 方法三域
    方法域序 client→base→cell；过滤 = (flags & 0xC) != 0（分布位，非 exposed 位）
    ★v16: fork 给 client 方法自动 |=0x4（FUN_142aa7540:377428 if(comp==CLIENT)
      flags|=4）→ client 方法全部进 digest；base/cell 纯 exposed(0x2) 方法出局
    ★v15: 方法 flags 喂 u16（slot10 2 字节 [flags,0x00]）
    自有在前、组件子描述在后；索引仅对通过者递增
  0x08 真值锚（1265 包/128 对全命中）：网络 methodID = 域内 exposedMethods_
    stable_sort by streamSize（定长升序在前、变长按 vlh 在后）后 0 起编号
    （与属性 csi 排序同构）；digest index = legacyExposedIndex（声明序计数）——两套编号
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bwxml import decode_file
from defparse import (EntityDefParser, EntityDescription, MD5,
                      COMP_BASE, COMP_CELL, COMP_CLIENT,
                      DATA_DISTRIBUTION_FLAGS)

# ---- 材料路径（V12 环境适配）----
SCRIPTS = '/tmp/wot_scripts/scripts'                       # 服务器 scripts.7z 解包（#942）
EXT_ROOT = '/tmp/wot/ext_pkg/extracted/wot24_ext_defs/ext_defs'   # 18 扩展（#942 客户端导出）
CD = os.path.join(SCRIPTS, 'component_defs')
SD = os.path.join(SCRIPTS, 'space_defs')
CLI = os.path.join(SCRIPTS, 'client')
TARGET = '5DF886F75E73B33CFF9D87FB9C69389C'

DATA_PERSISTENT = 0x10
DATA_ID = 0x20
PY_EXT = ('.py', '.pyc', '.pyo', '.pyd')


def _has_script(dirpath, name):
    """FUN_142a8e660: <dirpath>/<name>+ext 存在 或 <dirpath>/<name>/__init__+ext（包目录）
    v16 勘误：包目录判定含 __init__.pyc/.pyo/.pyd（不只 .py）"""
    for e in PY_EXT:
        if os.path.exists(os.path.join(dirpath, name + e)):
            return True
    for e in PY_EXT:
        if os.path.exists(os.path.join(dirpath, name, '__init__' + e)):
            return True
    return False


def ext_client_has_script(ext, name):
    """扩展 dyncomp decider：主树 client/ 回退 + 扩展 pkg client 清单
    （扩展 pkg 挂载后其 scripts/client 并入搜索路径；client_files.txt 为 pkg 真值清单）"""
    if _has_script(CLI, name):
        return True
    cf = os.path.join(EXT_ROOT, ext, 'client_files.txt')
    if os.path.exists(cf):
        for line in open(cf, encoding='utf-8', errors='replace'):
            line = line.strip()
            if line.endswith(f'/scripts/client/{name}.pyc') or \
               line.endswith(f'/scripts/client/{name}.py'):
                return True
            if line.endswith(f'/scripts/client/{name}/__init__.pyc') or \
               line.endswith(f'/scripts/client/{name}/__init__.py'):
                return True
    return False


# ---------------- 多目录 def 查找（扩展 def ↔ 主树 def 跨包 Parent/组件引用）----------------
class DefLocator(object):
    """先扩展目录、后主树；覆盖 entity_defs 与 component_defs"""
    def __init__(self, ext_dirs):
        self.ext_dirs = ext_dirs      # [(kind_dir, ...)]: 扩展的 _raw/entity_defs 等
        self.main = SCRIPTS

    def find(self, kind, name):
        """kind ∈ {'entity','comp'}; 返回 def 文件路径或 None"""
        sub = 'entity_defs' if kind == 'entity' else 'component_defs'
        for d in self.ext_dirs:
            p = os.path.join(d, sub, name + '.def')
            if os.path.exists(p):
                return p
        p = os.path.join(self.main, sub, name + '.def')
        return p if os.path.exists(p) else None


# ---------------- 组件记录解析（顶层记录：属性+方法全进）----------------
def parse_comp_record(parser, locator, name, _cache):
    if name in _cache:
        return _cache[name]
    ed = EntityDescription(name)
    ed.client_name = name
    _parse_comp_def(parser, locator, ed, name, _cache)
    _cache[name] = ed
    return ed


def _parse_comp_def(parser, locator, ed, name, _cache):
    """Parent 链先解析（fork: FUN_142a90f20 在 map 名索引中解析父记录）——跨包查找"""
    path = locator.find('comp', name)
    if path is None:
        raise FileNotFoundError(f'component def not found: {name}')
    sec = decode_file(path, name + '.def')
    parent = sec.readString('Parent')
    if parent:
        _parse_comp_def(parser, locator, ed, parent, _cache)
    ed.name = name
    ed.client_name = name
    _comp_parse_interface(parser, locator, ed, sec, name)


def _comp_parse_interface(parser, locator, ed, sec, iname):
    """组件版 parseInterface：Implements(component_defs/interfaces, 接口名在值)
    → Properties → Methods → Volatile 标记（扩展 def 实测零接口引用，逻辑保留）"""
    impl = sec.child('Implements')
    if impl is not None:
        for c in impl.children:
            iname2 = c.asString()
            ipath = locator.find('comp', os.path.join('interfaces', iname2)) \
                if False else None
            # interfaces 子目录查找
            for d in [os.path.dirname(locator.find('comp', iname) or 'x')] + [CD]:
                p = os.path.join(d, 'interfaces', iname2 + '.def')
                if os.path.exists(p):
                    ipath = p
                    break
            if ipath is None:
                ipath = os.path.join(CD, 'interfaces', iname2 + '.def')
            isec = decode_file(ipath, iname2 + '.def')
            _comp_parse_interface(parser, locator, ed, isec, iname2)
    props = sec.child('Properties')
    if props is not None:
        parser._parse_properties(ed, props, '')
    parser._parse_methods(ed, sec, iname, '')
    vol = sec.child('Volatile')
    if vol is not None:
        vprops = vol.child('Properties')
        if vprops is not None:
            for k in vprops.children:
                for p in ed.properties:
                    if p.name == k.name:
                        p.is_volatile = 1


# ---------------- space 记录（records[0]：parseSpaces 先于实体解析）----------------
def _space_parse_props(parser, ed, sec):
    """space 属性规则（FUN_142a91b20: dataFlags=0，<Exposed> → |=OWN_CLIENT(0x4)）"""
    props = sec.child('Properties')
    if props is None:
        return
    from defparse import Property
    for c in props.children:
        tsec = c.child('Type')
        if tsec is None:
            continue
        dt = parser._build_type(tsec)
        flags = 0
        if c.child('Exposed') is not None:
            flags |= 0x4                              # OWN_CLIENT（fork 增量）
        if c.readBool('Persistent', False):
            flags |= DATA_PERSISTENT
        if c.readBool('Identifier', False):
            flags |= DATA_ID
        vlh = 1
        v = c.child('VariableLengthHeaderSize')
        if v is not None:
            vlh = v.asInt(1)
        p = Property(c.name, flags, dt, vlh)
        key = ('', p.name)
        if key in ed.prop_map:
            idx = ed.prop_map[key]
            ed.properties[idx] = p
        else:
            p.index = len(ed.properties)
            ed.properties.append(p)
            ed.prop_map[key] = p.index
            if p.is_client_server:
                p.csi = len(ed.cs_props)
                ed.cs_props.append(p.index)
    ed.allocate_csi()


def parse_space_record(parser):
    """records[0] = GeneralSpaceData（spaces.xml 唯一子节点；decider 恒真）"""
    ed = EntityDescription('GeneralSpaceData')
    ed.client_name = 'GeneralSpaceData'
    sec = decode_file(os.path.join(SD, 'GeneralSpaceData.def'), 'GeneralSpaceData.def')
    impl = sec.child('Implements')
    if impl is not None:
        for k in impl.children:
            iname = k.asString()
            isec = decode_file(os.path.join(SD, 'interfaces', iname + '.def'),
                               iname + '.def')
            _space_parse_props(parser, ed, isec)
    _space_parse_props(parser, ed, sec)
    return ed


# ---------------- 静态组件（子描述：方法 only）----------------
class SubDesc(object):
    """+0x2f0 子描述：仅方法进 digest"""
    def __init__(self, name):
        self.name = name
        self.client_methods = []
        self.base_methods = []
        self.cell_methods = []


def load_static_comp(parser, locator, name, _cache):
    if name in _cache:
        return _cache[name]
    path = locator.find('comp', name)
    if path is None:
        raise FileNotFoundError(f'static comp def not found: {name}')
    sec = decode_file(path, name + '.def')
    sd = SubDesc(name)
    for dom_name, attr in (('BaseMethods', 'base_methods'),
                           ('CellMethods', 'cell_methods'),
                           ('ClientMethods', 'client_methods')):
        dom = sec.child(dom_name)
        if dom is None:
            continue
        comp_flag = {'BaseMethods': COMP_BASE, 'CellMethods': COMP_CELL,
                     'ClientMethods': COMP_CLIENT}[dom_name]
        lst = getattr(sd, attr)
        for m in dom.children:
            mm = parser._parse_method(m, comp_flag)
            lst.append(mm)
    _cache[name] = sd
    return sd


# ---------------- fork 版喂入（v16 终态）----------------
DOM_ATTR = {'client': 'client_methods', 'base': 'base_methods', 'cell': 'cell_methods'}


def fork_add_to_md5(ed, md5):
    md5.append(ed.name.encode('utf-8'))
    for p in ed.properties:
        if not p.is_client_server:
            continue
        md5.append_int32(p.csi)
        ss = p.stream_size()
        if ss < 0 and p.var_len_header != 1:
            md5.append_uint32(p.var_len_header)
        md5.append(p.name.encode('utf-8'))
        md5.append_int32(p.flags & DATA_DISTRIBUTION_FLAGS)
        md5.append_uint8(getattr(p, 'is_volatile', 0))   # ★fork 增量①（含 gunMarker=0x01）
        p.dt.add_to_md5(md5)
    # ★v16: 三域统一 (flags & 0xC) != 0 过滤（onMethod FUN_142a9b810 真实语义，分布位）
    #   fork 给 client 方法自动 |=0x4（FUN_142aa7540:377428）→ client 方法全部进 digest
    #   base/cell 纯 exposed(0x2) 方法出局（v13「client 全出局」判反，0x08 真值 128 对全命中证伪）
    #   自有在前组件在后，索引连续（idx 仅对喂入方法递增）
    for domain, own_list in (
            ('client', ed.client_methods),
            ('base', ed.base_methods),
            ('cell', ed.cell_methods)):
        count = 0
        for m in own_list:
            if not (m.flags & 0xC):
                continue
            method_to_md5(md5, m, count, domain)
            count += 1
        for sd in getattr(ed, 'fork_components', []):
            for m in getattr(sd, DOM_ATTR[domain]):
                if not (m.flags & 0xC):
                    continue
                method_to_md5(md5, m, count, domain)
                count += 1


def method_to_md5(md5, m, idx, domain='client'):
    # ★v16 激活: client 方法进 digest → isForClient_=(domain==CLIENT) 的 varLen 分支生效
    #   （vlh 分布 {1:342, 2:5}: showGUI/updateSpawnList/explodeProjectile/
    #     updateQuestProgress/setUpdatedGoodiesSnapshot 五处触发）
    if domain == 'client':
        if m.var_len_header != 1 and m._stream_size < 0:
            md5.append_uint32(m.var_len_header)
    md5.append(m.name.encode('utf-8'))
    md5.append_uint16(m.flags)      # ★v15: slot10 u16 喂入 [flags, 0x00]
    for a in m.args:
        a.add_to_md5(md5)
    # returnValues：全部 5 处 RV 方法无分布位 → 0 字节（新语义复核）
    md5.append_int32(idx)


# ---------------- 扩展层（v16 并入：18 扩展字母序 = FeatureName 有序 map）----------------
def iter_extensions():
    """FeatureName 键有序 std::map → 字母序迭代（目录名=FeatureName=pkg 名）"""
    exts = sorted(d for d in os.listdir(EXT_ROOT)
                  if os.path.isdir(os.path.join(EXT_ROOT, d)))
    # IsEnabled 全 true（十项对账 C4）；仍读 extension.xml 防御性确认
    out = []
    for e in exts:
        x = os.path.join(EXT_ROOT, e, 'extension.xml')
        enabled = True
        if os.path.exists(x):
            txt = open(x, encoding='utf-8', errors='replace').read()
            if '<IsEnabled>False</IsEnabled>' in txt:
                enabled = False
        if enabled:
            out.append(e)
    return out


def ext_xml(ext):
    """扩展 extension.xml（BWXML _raw 原件——digest 输入以此为准）"""
    return decode_file(os.path.join(EXT_ROOT, ext, '_raw', 'extension.xml'),
                       f'{ext}/extension.xml')


def parse_ext_entities(parser, locator, ext, rec_cache):
    """loop#1: <Entities><ClientServerEntities> 逐名（side=0 仅 CS；
    ServerOnlyEntities 有名单但客户端不解析——16 个 SO 正确缺席）"""
    root = ext_xml(ext)
    ents = root.child('Entities')
    if ents is None:
        return []
    cs = ents.child('ClientServerEntities')
    if cs is None:
        return []
    out = []
    for c in cs.children:
        name = c.name
        if name in rec_cache:
            out.append(rec_cache[name])
            continue
        ed = EntityDescription(name)
        ed.client_name = name
        _parse_ext_entity_def(parser, locator, ed, name)
        ed.fork_components = []       # ofEntity 边全部指向主树实体 → 扩展实体无静态挂载
        rec_cache[name] = ed
        out.append(ed)
    return out


def _parse_ext_entity_def(parser, locator, ed, name):
    """扩展实体 def：Parent 链跨包（SPGZone→AreaOfEffect 主树）；
    结构对齐 defparse._parse_interface（Implements→Properties→Methods，
    实体 Volatile=position 等自动属性不进声明列表，忽略）"""
    path = locator.find('entity', name)
    if path is None:
        raise FileNotFoundError(f'ext entity def not found: {name}')
    sec = decode_file(path, name + '.def')
    parent = sec.readString('Parent')
    if parent:
        _parse_ext_entity_def(parser, locator, ed, parent)
    ed.name = name
    ed.client_name = name
    impl = sec.child('Implements')
    if impl is not None:
        for k in impl.children:
            iname = k.asString()
            ipath = os.path.join(SCRIPTS, 'entity_defs', 'interfaces', iname + '.def')
            if os.path.exists(ipath):
                isec = decode_file(ipath, iname + '.def')
                parser._parse_interface(ed, isec, iname, '')
    props = sec.child('Properties')
    if props is not None:
        parser._parse_properties(ed, props, '')
    parser._parse_methods(ed, sec, name, '')
    ed.allocate_csi()


def parse_ext_dyncomps(parser, locator, ext, rec_cache, comp_cache):
    """loop#2: <Components><DynamicComponents> 逐名（decider=client 脚本存在性）"""
    root = ext_xml(ext)
    comps = root.child('Components')
    if comps is None:
        return [], []
    dyn = comps.child('DynamicComponents')
    if dyn is None:
        return [], []
    out, skipped = [], []
    for c in dyn.children:
        name = c.name
        if name in rec_cache:
            out.append(rec_cache[name])
            continue
        if not ext_client_has_script(ext, name):
            skipped.append(name)
            continue
        ed = parse_comp_record(parser, locator, name, comp_cache)
        ed.fork_components = []       # parseDynamicComponents 传空挂载索引（机器码确认）
        rec_cache[name] = ed
        out.append(ed)
    return out, skipped


# ---------------- 主流程 ----------------
def main():
    parser = EntityDefParser(SCRIPTS)
    parser.load()

    comps_root = decode_file(os.path.join(SCRIPTS, 'components.xml'), 'components.xml')
    static_list = [k.name for k in comps_root.child('StaticComponents').children]
    dyn_list = [k.name for k in comps_root.child('DynamicComponents').children]
    print(f'StaticComponents: {len(static_list)}  DynamicComponents: {len(dyn_list)}')

    # 挂载索引 Part a（StaticComponents 序 = multimap 插入序；Part b=ExternalComponents 全空）
    mounts = {}
    for cname in static_list:
        sec = decode_file(os.path.join(CD, cname + '.def'), cname + '.def')
        ofe = sec.child('ofEntity')
        if ofe is not None:
            for k in ofe.children:
                mounts.setdefault(k.name, []).append(cname)

    sub_cache, rec_cache, comp_cache = {}, {}, {}
    locator = DefLocator([])      # 主树定位器（静态组件全在主树）

    # 记录集：space → 40 主实体 → 10 扩展实体 → 107 主 dyncomp → 160 扩展 dyncomp
    records = [parse_space_record(parser)]
    for ed in parser.entities:
        ed.fork_components = [load_static_comp(parser, locator, c, sub_cache)
                              for c in mounts.get(ed.name, [])]
        records.append(ed)
        rec_cache[ed.name] = ed
    n_main = len(records) - 1

    exts = iter_extensions()
    print(f'扩展: {len(exts)} 个（字母序）: {", ".join(exts)}')
    n_ext_ent = 0
    for ext in exts:
        eloc = DefLocator([os.path.join(EXT_ROOT, ext, '_raw')])
        for ed in parse_ext_entities(parser, eloc, ext, rec_cache):
            records.append(ed)
            n_ext_ent += 1

    skipped_main = []
    seen = set()
    for name in dyn_list:
        if name in seen:
            continue
        seen.add(name)
        if not _has_script(CLI, name):
            skipped_main.append(name)
            continue
        ed = parse_comp_record(parser, locator, name, comp_cache)
        ed.fork_components = []
        records.append(ed)
        rec_cache[ed.name] = ed
    n_main_dyn = len(records) - 1 - n_main - n_ext_ent

    n_ext_dyn, ext_skipped = 0, []
    for ext in exts:
        eloc = DefLocator([os.path.join(EXT_ROOT, ext, '_raw')])
        eds, sk = parse_ext_dyncomps(parser, eloc, ext, rec_cache, comp_cache)
        ext_skipped += [f'{ext}:{s}' for s in sk]
        for ed in eds:
            records.append(ed)
            n_ext_dyn += 1

    print(f'records = 1 space + {n_main} 主实体 + {n_ext_ent} 扩展实体 '
          f'+ {n_main_dyn} 主 dyncomp + {n_ext_dyn} 扩展 dyncomp = {len(records)}')
    print(f'排除: 主 {skipped_main} / 扩展 {len(ext_skipped)} 个')

    # 统计（v16 新口径：三域 (flags&0xC)!=0）
    n_cs, n_vol, n_meth = 0, 0, 0
    for ed in records:
        n_cs += sum(1 for p in ed.properties if p.is_client_server)
        n_vol += sum(1 for p in ed.properties
                     if p.is_client_server and getattr(p, 'is_volatile', 0))
        for lst in (ed.client_methods, ed.base_methods, ed.cell_methods):
            n_meth += sum(1 for m in lst if m.flags & 0xC)
        for sd in getattr(ed, 'fork_components', []):
            for attr in ('client_methods', 'base_methods', 'cell_methods'):
                n_meth += sum(1 for m in getattr(sd, attr) if m.flags & 0xC)
    print(f'CS 属性: {n_cs}（isVolatile=1 的 {n_vol}）  digest 方法(0xC 分布位口径): {n_meth}')

    def run(tag, recs):
        md5 = MD5()
        for ed in recs:
            fork_add_to_md5(ed, md5)
        d = md5.getDigestQuote()
        hit = '★★★ 命中目标!!' if d == TARGET else '≠'
        print(f'[{tag}] {d} {hit}')
        return d

    def count_meth(recs):
        n = 0
        for ed in recs:
            for lst in (ed.client_methods, ed.base_methods, ed.cell_methods):
                n += sum(1 for m in lst if m.flags & 0xC)
            for sd in getattr(ed, 'fork_components', []):
                for attr in ('client_methods', 'base_methods', 'cell_methods'):
                    n += sum(1 for m in getattr(sd, attr) if m.flags & 0xC)
        return n

    run(f'完整模型 v16: {len(records)} 记录', records)
    main_only = records[:1 + n_main]
    print(f'[方法统计] 主消融: {count_meth(main_only)}  全量: {count_meth(records)}')
    run(f'主消融: space+{n_main} 主实体+静态挂载（无扩展/无 dyncomp）', main_only)


if __name__ == '__main__':
    main()
