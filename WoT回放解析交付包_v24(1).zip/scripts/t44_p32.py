#!/usr/bin/env python3
"""t44_p32.py — Task 44: 0x32/0x37 载荷结构重析(新知识驱动)
新知识:
  - 0x32 记录载荷 = [u32 len][原始流]
  - NetworkVehicleHierarchy.hierarchyInfo = ARRAY<VEHICLE_HIERARCHY_INFO{slotName STRING, networkID UINT32}>
  - 0x37 节点对引用 networkID → 与 hierarchy join 得节点名
步骤: dump 样本字节 → 识别帧结构 → 建 networkID→slotName 映射 → join 0x37
"""
import struct, sys, json, glob
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load

F = '/tmp/wot/github_test/20260910_1057_china-Ch67_BZ_79_37_caucasus.wotreplay'
blocks, declared, slen, pkts = load(F)
print(f'包数 {len(pkts)}')

p32 = [(i, c, p) for i, (t, c, p) in enumerate(pkts) if t == 0x32]
p37 = [(i, c, p) for i, (t, c, p) in enumerate(pkts) if t == 0x37]
print(f'0x32: {len(p32)} 包  0x37: {len(p37)} 包')

def strings_in(b):
    """[u8 len][ascii] 模式普查"""
    out = []
    i = 0
    while i < len(b) - 1:
        n = b[i]
        if 3 <= n <= 32 and i + 1 + n <= len(b):
            s = b[i+1:i+1+n]
            if all(32 <= x < 127 for x in s):
                out.append((i, s.decode()))
                i += 1 + n
                continue
        i += 1
    return out

# ── 样本 dump: 含层级字符串的 0x32 ──
print('\n===== 含 hull/turret 的 0x32 样本 =====')
shown = 0
for i, c, p in p32:
    ss = strings_in(p)
    names = [s for _, s in ss]
    if any(s in ('hull', 'turret', 'gun', 'chassis', 'compositionRootSlot') for s in names):
        print(f'\n-- pkt#{i} clk={c} 载荷{len(p)}B')
        print('  hex头64:', p[:64].hex(' '))
        print('  字符串:', [(hex(off), s) for off, s in ss])
        shown += 1
        if shown >= 4:
            break

# ── 样本 dump: 13B 短消息 ──
print('\n===== 13B 短 0x32 样本 =====')
shown = 0
for i, c, p in p32:
    if len(p) == 13:
        print(f'pkt#{i} clk={c}: {p.hex(" ")}')
        shown += 1
        if shown >= 12:
            break

# ── 0x37 样本 ──
print('\n===== 0x37 样本(前12包) =====')
for i, c, p in p37[:12]:
    ss = strings_in(p)
    print(f'pkt#{i} clk={c} len={len(p)}: {p[:48].hex(" ")}' + (f'  strs={[s for _,s in ss][:4]}' if ss else ''))

# ── 0x32 首 u32 分布 ──
from collections import Counter
c32 = Counter()
for i, c, p in p32:
    if len(p) >= 8:
        u = struct.unpack_from('<I', p, 4)[0]  # 跳过 recorder 加的 [u32 len]
        c32[u] += 1
print('\n0x32 流内首 u32 分布:', c32.most_common(15))
c37 = Counter()
for i, c, p in p37:
    if len(p) >= 8:
        u = struct.unpack_from('<I', p, 4)[0]
        c37[u] += 1
print('0x37 流内首 u32 分布:', c37.most_common(15))
