#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
t37_sm2.py — Task 37 ⑧b：0x24 全状态机验证 v2（0x05 重创建重置版）
修正: 同 eid 多个 0x05（AoI 重入/重创建）→ 数组状态在每个 0x05 处重置为该次初始值
通道: 33=damageStickers(elem16B) 34=publicStateModifiers(elem1B)
规则: path=[1][csi6][0] + Single:idx bitsRequired(n) / Slice:s,e 各 bitsRequired(n+1)
      新长度 = s + nnew + (n - e)
"""
import struct, sys, json
sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import REPLAYS, load_pkts

def br(n):
    if n <= 1: return 0
    r = 0
    while (1 << r) < n: r += 1
    return r

class B:
    def __init__(s, b): s.b = b; s.p = 0
    def get(s, n):
        v = 0
        for _ in range(n): v = (v << 1) | ((s.b[s.p >> 3] >> (7 - (s.p & 7))) & 1); s.p += 1
        return v
    def used(s): return (s.p + 7) >> 3

# 预解码 0x05: (tag, eid, clk) -> 初始数组状态
p05init = {}
d = json.load(open('/tmp/wot/p05_decoded.json'))
# p05_decoded 可能有多条同 (tag,eid) —— 需要按出现序; 重读原始流拿顺序
for TAG, RP in REPLAYS:
    pkts = load_pkts(RP)
    eid2ty = {}
    creates = []  # (clk, eid, ds, psm)
    for ty, clk, pl in pkts:
        if ty == 5 and len(pl) >= 8:
            e, n = struct.unpack_from('<II', pl, 0)
            eid2ty[e] = n
    # p05_decoded 行序 == 原始序
    rows = [r for r in d if r['tag'] == TAG and r.get('typeName') == 'Vehicle']
    ri = 0
    # 直接从 p05_decoded 拿初始值(按行序); clk 对齐靠 eid 顺序一致性(创建序一致)
    for r in rows:
        p = r.get('props') or {}
        p05init.setdefault((TAG, r['eid']), []).append(
            (len(p.get('damageStickers') or []), len(p.get('publicStateModifiers') or [])))

total = {'ok': 0, 'bad': 0}
bads = []
recreates = 0
for TAG, RP in REPLAYS:
    pkts = load_pkts(RP)
    eid2ty = {}
    p05seq = {}  # eid -> list of (ds, psm) 按序
    for ty, clk, pl in pkts:
        if ty == 5 and len(pl) >= 8:
            e, n = struct.unpack_from('<II', pl, 0)
            eid2ty[e] = n
            if n == 6:
                p05seq.setdefault(e, []).append(clk)
    # 用预解码的初始值(与 p05seq 顺序对齐)
    state = {}   # eid -> {'ds':, 'psm':, 'ci': 创建序号}
    for clk, pl in [(c, pl) for ty, c, pl in pkts if ty == 0x24]:
        eid, isl, ln = struct.unpack_from('<IBI', pl, 0)
        if eid2ty.get(eid) != 6: continue
        body = pl[9:9+ln]
        if len(body) < 2 or not (body[0] & 0x80): continue
        b = B(body)
        if b.get(1) != 1: continue
        csi = b.get(6)
        if csi not in (33, 34): continue
        if b.get(1) != 0: continue
        # 该 clk 之前最近的 0x05 序号
        seq = p05seq.get(eid, [0])
        ci = sum(1 for c in seq if c < clk) - 1
        if ci < 0: ci = 0
        inits = p05init.get((TAG, eid), [(0, 0)])
        if ci >= len(inits): ci = len(inits) - 1
        st = state.get(eid)
        if st is None or st['ci'] != ci:
            # 重创建 → 重置
            if st is not None: recreates += 1
            ds0, psm0 = inits[ci]
            st = state[eid] = {'ds': ds0, 'psm': psm0, 'ci': ci}
        if csi == 33:
            n = st['ds']; nb = br(n + 1)
            if isl:
                s, e = b.get(nb), b.get(nb)
                val = body[b.used():]
                ok = s <= e <= n and len(val) % 16 == 0
                if ok: st['ds'] = s + len(val) // 16 + (n - e)
            else:
                idx = b.get(br(n))
                val = body[b.used():]
                ok = idx < n and len(val) == 16
        else:
            n = st['psm']; nb = br(n + 1)
            if isl:
                s, e = b.get(nb), b.get(nb)
                val = body[b.used():]
                ok = s <= e <= n
                if ok: st['psm'] = s + len(val) + (n - e)
            else:
                idx = b.get(br(n))
                val = body[b.used():]
                ok = idx < n and len(val) == 1
        total['ok' if ok else 'bad'] += 1
        if not ok and len(bads) < 12:
            bads.append((TAG, clk, eid, isl, csi, n, ci, body.hex()))

print('验证结果:', total, ' 重创建重置次数:', recreates)
for x in bads: print('  BAD:', x)
