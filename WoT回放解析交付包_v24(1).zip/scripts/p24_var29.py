#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
p24_var29.py — csi=29 ownVehiclePosition 值段字节方差分析
17B 值恒定长度 → 按字节统计取值集大小/样本，钉死字段边界
"""
import struct
import sys
from collections import Counter, defaultdict

sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import REPLAYS, load_pkts  # noqa: E402
from p24_bitpath import BitReader, bits_required  # noqa: E402


def main():
    vals = []          # (tag, clk, eid, 17B值)
    vals20 = []
    for tag, path in REPLAYS:
        pkts = load_pkts(path)
        for ty, c, pl in pkts:
            if ty != 0x24 or len(pl) < 10:
                continue
            eid, = struct.unpack_from('<I', pl, 0)
            body = pl[9:]
            if eid2type(eid) != 'Vehicle' or len(body) < 3:
                continue
            br = BitReader(body)
            if br.get(1) == 0:
                continue
            csi = br.get(bits_required(50))
            if csi != 29:
                continue
            # 19B 包: 头2B; 20B 包: 头3B(多一层下钻)
            if len(body) == 19:
                vals.append((tag, c, eid, body[2:]))
            elif len(body) == 20:
                vals20.append((tag, c, eid, body[3:]))
    print(f'19B 包 {len(vals)} 个, 20B 包 {len(vals20)} 个')
    # 17B 值字节方差（19B 包）
    print('\n== 19B 包值 17B 的字节分布 ==')
    for off in range(17):
        c = Counter(v[3][off] for v in vals if len(v[3]) == 17)
        print(f'  [{off:2d}] 取值{len(c):3d}种  top: {c.most_common(4)}')
    # 20B 包值（17B）同样分析
    if vals20:
        print('\n== 20B 包值(头3B切) 17B 字节分布 ==')
        for off in range(17):
            c = Counter(v[3][off] for v in vals20 if len(v[3]) == 17)
            print(f'  [{off:2d}] 取值{len(c):3d}种  top: {c.most_common(4)}')
    # 相关性: 每场的前缀 u16
    print('\n== 按场前缀分布 ==')
    per = defaultdict(Counter)
    for tag, c, eid, v in vals:
        per[tag][v[:2].hex()] += 1
    for tag, cnt in per.items():
        print(f'  {tag[:14]:16s}: {cnt.most_common(3)}')
    # 相邻时间序列: 同一 eid 的 (clk, f64@9)
    print('\n== 单车时间序列 (f64@9) ==')
    seq = defaultdict(list)
    for tag, c, eid, v in vals:
        if len(v) == 17:
            seq[(tag, eid)].append((c, struct.unpack_from('<d', v, 9)[0],
                                    struct.unpack_from('<f', v, 5)[0]))
    for k, lst in list(seq.items())[:3]:
        lst.sort()
        print(f'  {k[0][:10]} eid={k[1]}:')
        for c, d, f in lst[:8]:
            print(f'    clk={c} f64@9={d:.4f} f32@5={f:.2f}')


def eid2type(eid):
    import json
    global _E
    try:
        return _E[eid]
    except NameError:
        pass
    global _P
    try:
        _P
    except NameError:
        _P = json.load(open('/tmp/wot/p05_decoded.json'))
        _E = {r['eid']: r['typeName'] for r in _P}
    return _E.get(eid)


if __name__ == '__main__':
    main()
