#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
t39_b.py — Task 39-b: 变长组尾部 41-47/49 逐位锚定
材料: 0x07 key 29/30/38 单例 body 深挖 + 0x24 全 csi 直方图 + 0x05 idx 41-49 值类型
"""
import json, struct, sys
from collections import defaultdict, Counter

sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import REPLAYS, load_pkts

RB = [r for r in REPLAYS if r[0] != 'tundra_CN_942']

p05 = json.load(open('/tmp/wot/p05_decoded.json'))
et = {}
for r in p05:
    if r['tag'] != 'tundra_CN_942':
        et[(r['tag'], r['eid'])] = r.get('typeID')

# ---- 1. 0x07 key 29/30/38/16/22/5 单例 body ----
print('===== 1. 0x07 稀有 key 的 body 全样本 =====')
WATCH = {29, 30, 38, 16, 22, 5, 33, 34}
for tag, path in RB:
    pkts = load_pkts(path)
    vset = {eid for (t, eid), tid in et.items() if t == tag and tid == 6}
    for ty, clk, body in pkts:
        if ty != 0x07 or len(body) < 5: continue
        eid = struct.unpack_from('<I', body, 0)[0]
        if eid not in vset: continue
        key = body[4]
        if key in WATCH:
            print('%-16s clk=%-11d key=%2d len=%3d  %s' % (tag, clk, key, len(body), body[5:42].hex()))

# ---- 2. 0x24 全 csi 直方图（随机战 10 场）----
print()
print('===== 2. 0x24 csi 直方图（按 typeID）=====')
csi_hist = defaultdict(Counter)
for tag, path in RB:
    pkts = load_pkts(path)
    for ty, clk, body in pkts:
        if ty != 0x24: continue
        if len(body) < 1: continue
        eid = struct.unpack_from('<I', body, 0)[0]
        b = body[5:]
        # 首位=1 → csi 在后续 bitsRequired(numCS) 位
        # Vehicle numCS=50 → 6bit; AreaDestr numCS=4 → 2bit
        tid = et.get((tag, eid), -1)
        numCS = {6: 50, 7: 4, 12: 50, 40: 50, 28: 4, 29: 4}.get(tid, 50)
        nb = 0
        while (1 << nb) < numCS: nb += 1
        if not (b[0] & 0x80): continue     # 首位非1 → 异常
        v = 0
        for i in range(nb):
            byte = b[(1 + i) >> 3]
            v = (v << 1) | ((byte >> (7 - ((1 + i) & 7))) & 1)
        csi_hist[tid][v] += 1

TN = {6: 'Vehicle', 7: 'AreaDestr', 12: 'DetachedTurret', 40: 'NetworkEntity', 28: 'TeamInfo', 29: 'AvatarInfo'}
for tid in sorted(csi_hist):
    print('typeID %d (%s):' % (tid, TN.get(tid, '?')), dict(sorted(csi_hist[tid].items())))

# ---- 3. 0x05 idx 41-49 的值类型（p05_decoded Vehicle props）----
print()
print('===== 3. 0x05 Vehicle idx 41-49 值类型 =====')
# p05_decoded props 是 {name: value} 还是按 idx? 看结构
sample = [r for r in p05 if r['tag'] != 'tundra_CN_942' and r.get('typeID') == 6][:2]
if sample:
    print('props 键型:', type(sample[0].get('props')).__name__)
    pr = sample[0].get('props')
    if isinstance(pr, dict):
        print('首例键:', list(pr.keys()))
# 若是列表则按位置取
for r in [x for x in p05 if x['tag'] != 'tundra_CN_942' and x.get('typeID') == 6][:3]:
    pr = r.get('props')
    if isinstance(pr, list):
        print('eid=%d idx41-49:' % r['eid'])
        for i in range(41, 50):
            if i < len(pr):
                v = pr[i]
                s = v if not isinstance(v, (dict, list)) else json.dumps(v, ensure_ascii=False)[:80]
                print('   idx%d = %s' % (i, str(s)[:100]))
    break
