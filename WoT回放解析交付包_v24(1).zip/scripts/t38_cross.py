#!/usr/bin/env python3
"""t38_cross.py — A 的跨场交叉表 + E 时钟回归 + D=15 子集画像 + csi30 到期语义检验"""
import json, math
from collections import Counter, defaultdict

R = json.load(open("/tmp/wot/t38_align.json"))
c29 = [r for r in R if r["csi"] == 29]
c30 = [r for r in R if r["csi"] == 30]
Q20 = 1.0 / (1 << 20)

print("== A × battle 交叉表 (csi29) ==")
xt = defaultdict(Counter)
for r in c29:
    xt[r["A"]][r["tag"]] += 1
tags = sorted({r["tag"] for r in c29})
print("  A   | " + " | ".join(t.replace("_EU","").replace("_CN","").replace("_NA","")[:9] for t in tags))
for a in sorted(xt):
    print("  %3d | " % a + " | ".join("%3d" % xt[a].get(t, 0) for t in tags))

print("\n== A × battle 交叉表 (csi30 inspired) ==")
xt2 = defaultdict(Counter)
for r in c30:
    xt2[r["A"]][r["tag"]] += 1
tags2 = sorted({r["tag"] for r in c30})
for a in sorted(xt2):
    print("  %3d | " % a + " | ".join("%3d" % (xt2[a].get(t,0)) for t in tags2))

print("\n== 同场内 A 是否随时间切换（csi29, 每场 A 序列前 20）==")
bt = defaultdict(list)
for r in sorted(c29, key=lambda r: r["clk"]):
    bt[r["tag"]].append((r["clk"]*Q20, r["A"], r["C"], r["D"]))
for tag in sorted(bt):
    seq = bt[tag]
    # 压缩连续重复
    comp = []
    for t, a, c, d in seq:
        if not comp or comp[-1][1:] != (a, c, d):
            comp.append((t, a, c, d))
    print("  %-18s %d样本→%d段: %s" % (tag, len(seq), len(comp),
          " ".join("%.0fs:A%d,C%d,D%.0f" % x for x in comp[:14])))

print("\n== E(time) vs clk 线性回归 (csi29, 每场) ==")
for tag in sorted({r["tag"] for r in c29}):
    pts = [(r["clk"]*Q20, r["time"]) for r in c29 if r["tag"] == tag]
    n = len(pts)
    if n < 3: continue
    sx = sum(p[0] for p in pts); sy = sum(p[1] for p in pts)
    sxx = sum(p[0]*p[0] for p in pts); sxy = sum(p[0]*p[1] for p in pts)
    slope = (n*sxy - sx*sy) / (n*sxx - sx*sx)
    inter = (sy - slope*sx) / n
    # 残差
    res = [p[1] - (slope*p[0]+inter) for p in pts]
    print("  %-18s n=%-3d slope=%9.3f inter=%11.1f 残差(|max|)=%8.1f" %
          (tag, n, slope, inter, max(abs(x) for x in res)))

print("\n== csi30: time - clk_sec (若是到期时间戳应为正的余量) ==")
for tag in sorted({r["tag"] for r in c30}):
    ds = sorted(r["time"]/1000.0 - r["clk"]*Q20 for r in c30 if r["tag"] == tag)
    if ds:
        print("  %-18s n=%-3d 余量范围 %.1f ~ %.1f  中位 %.1f" %
              (tag, len(ds), ds[0], ds[-1], ds[len(ds)//2]))

print("\n== D=15.0 子集画像 (csi29) ==")
sub = [r for r in c29 if r["D"] == 15.0]
print("  各场:", Counter(r["tag"] for r in sub).most_common())
print("  各A:", Counter(r["A"] for r in sub).most_common())
print("  各C:", Counter(r["C"] for r in sub).most_common())
sub1 = [r for r in c29 if r["D"] == -1.0]
print("  D=-1 各场:", Counter(r["tag"] for r in sub1).most_common())
print("  D=-1 各A:", Counter(r["A"] for r in sub1).most_common())

print("\n== csi29 与 csi30 同场共存关系 ==")
t29 = {r["tag"] for r in c29}; t30 = {r["tag"] for r in c30}
print("  仅29:", sorted(t29-t30), " 仅30:", sorted(t30-t29))
