#!/usr/bin/env python3
"""t38_align.py — Task 38 主攻：csi29(ownVehiclePosition)/csi30(inspired) 元素字段语义终判
方法：与 0x0A volatile 位置流（v6 权威布局 [eid][ref][pos3f][v203f][v323f][tail]）同时钟对齐
测试：
  T1 time(ms?) vs clk(Q20 s) 线性关系
  T2 A(u16) vs 量化yaw(v32) / 速度(pos差分) / 量化坐标
  T3 C(u8) vs tail / 速度状态
  T4 D(f32) vs 速度 / 加速度
  T5 B 恒 0 复核
"""
import json, struct, zlib, math, glob
from collections import defaultdict, Counter
from Crypto.Cipher import Blowfish

KEY = bytes([0xDE,0x72,0xBE,0xA0,0xDE,0x04,0xBE,0xB1,
             0xDE,0xFE,0xBE,0xEF,0xDE,0xAD,0xBE,0xEF])

def load_pkts(path):
    data = open(path, "rb").read()
    magic, bc = struct.unpack_from("<II", data, 0)
    pos = 8; blocks = []
    for _ in range(bc):
        (blen,) = struct.unpack_from("<I", data, pos)
        blocks.append(data[pos+4:pos+4+blen]); pos += 4 + blen
    (declared,) = struct.unpack_from("<I", data, pos); pos += 4
    (slen,) = struct.unpack_from("<I", data, pos); pos += 4
    main = data[pos:]          # 密文区到 EOF（含 padding，8 字节对齐）
    # blowfish-CBC(IV=0) 解密 + zlib
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    out = b""; prev = b"\x00" * 8
    for i in range(0, len(main), 8):
        d = cipher.decrypt(main[i:i+8])
        d = bytes(a ^ b for a, b in zip(d, prev))
        prev = d
        out += d
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from("<III", stream, q)
        pkts.append((ty, clock, stream[q+12:q+12+size]))
        q += 12 + size
    return blocks, pkts

TAGS = {  # p24_final_v2 的 tag → 文件
    "siegfried_EU_935": "20260905_2048_sweden-S41_BV_111_14_siegfried_line",
    "karelia_EU_935":   "20260906_1529_germany-G189_Hirschkafer_01_karelia",
    "lakeville_EU_935": "20260907_1321_germany-G197_Pz_Kpfw_Neu_07_lakeville",
    "caucasus_NA_945":  "20260910_1057_china-Ch67_BZ_79_37_caucasus",
    "namerica_CN_942":  "20260911_1534_ussr-R52_Object_261_44_north_america",
    "tundra_CN_942":    "20260911_1749_uk-GB156_Black_Prince_II_63_tundra",
    "caucasus_CN_942":  "20260911_1801_ussr-R52_Object_261_37_caucasus",
    "greatwall_EU_944": "20260912_1036_france-F143_Fauteur_59_asia_great_wall",
    "karelia2_EU_944":  "20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia",
    "PTZ_EU_944":       "PTZ_10K",
    "WZ219_EU_944":     "WZ-219",
}

def parse_0a(payload):
    """[eid u32][ref u32][pos 3f][v20 3f][v32 3f][tail u8] = 45B"""
    if len(payload) != 45:
        return None
    eid, ref = struct.unpack_from("<II", payload, 0)
    pos = struct.unpack_from("<3f", payload, 8)
    v20 = struct.unpack_from("<3f", payload, 20)
    v32 = struct.unpack_from("<3f", payload, 32)
    tail = payload[44]
    return dict(eid=eid, ref=ref, pos=pos, v20=v20, v32=v32, tail=tail)

def main():
    p24 = json.load(open("/tmp/wot/p24_final_v2.json"))
    # 按需只解析出现 csi29/30 的 replay
    need = defaultdict(list)
    for rec in p24:
        if rec.get("csi") in (29, 30) and rec.get("ok"):
            need[rec["tag"]].append(rec)
    print("需对齐场:", {k: len(v) for k, v in need.items()})

    results = []
    for tag, recs in sorted(need.items()):
        if tag == "tundra_CN_942":   # 非随机战, 用户指令排除
            continue
        fname = TAGS[tag]
        path = f"/tmp/wot/github_test/{fname}.wotreplay"
        blocks, pkts = load_pkts(path)
        # 0x0A 索引: eid -> [(clk, parsed)]
        a_idx = defaultdict(list)
        n_0a = 0
        bad_len = Counter()
        for ty, clk, pl in pkts:
            if ty == 0x0A:
                n_0a += 1
                if len(pl) != 45:
                    bad_len[len(pl)] += 1
                    continue
                p = parse_0a(pl)
                a_idx[p["eid"]].append((clk, p))
        print(f"\n=== {tag}: 0x0A={n_0a} 非标长度={dict(bad_len)}")
        for rec in recs:
            eid = rec["eid"]
            lst = a_idx.get(eid, [])
            if not lst:
                results.append(dict(tag=tag, **{k: rec[k] for k in ("clk","csi","eid")},
                                    matched=0))
                continue
            # 二分找最近 clk
            clks = [c for c, _ in lst]
            import bisect
            i = bisect.bisect_left(clks, rec["clk"])
            cands = [j for j in (i-1, i) if 0 <= j < len(lst)]
            j = min(cands, key=lambda j: abs(lst[j][0] - rec["clk"]))
            clk0, p = lst[j]
            el = rec["elems"][0] if rec.get("elems") else {}
            results.append(dict(
                tag=tag, clk=rec["clk"], csi=rec["csi"], eid=eid,
                matched=1, dclk=rec["clk"] - clk0,
                A=el.get("A"), B=el.get("B"), C=el.get("C"), D=el.get("D"),
                time=el.get("time"),
                pos=list(p["pos"]), v20=list(p["v20"]), v32=list(p["v32"]),
                tail=p["tail"], ref=p["ref"]))
    json.dump(results, open("/tmp/wot/t38_align.json", "w"), ensure_ascii=False)
    n_m = sum(1 for r in results if r.get("matched"))
    print(f"\n对齐结果: {n_m}/{len(results)}  → /tmp/wot/t38_align.json")

if __name__ == "__main__":
    main()
