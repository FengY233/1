# -*- coding: utf-8 -*-
"""launch_portal.py — file_server.py 的双 fork 守护化启动器

背景: 沙箱会回收直接 nohup/setsid 启动的 HTTP 服务(见 worklog Task 21-supplement);
双 fork + setsid + stdio 重定向后的进程(PPid=1)可跨工具调用存活(实证: pid 2022 存活整夜)。
用法: python3 /home/z/my-project/scripts/launch_portal.py   (立即返回, 服务后台常驻 :3000)
"""
import os
import sys

SRV = '/home/z/my-project/scripts/file_server.py'
LOG = '/tmp/wot/file_server.log'

if os.fork() > 0:
    os._exit(0)            # 父进程立即退出
os.setsid()                # 新会话, 脱离控制终端
if os.fork() > 0:
    os._exit(0)            # 二次 fork, 孙进程由 init 收养 (PPid=1)
os.chdir('/')
os.umask(0)
log = open(LOG, 'ab', 0)   # stdio 全部重定向: stdout/stderr -> 日志, stdin -> /dev/null
os.dup2(log.fileno(), 1)
os.dup2(log.fileno(), 2)
dn = os.open('/dev/null', os.O_RDONLY)
os.dup2(dn, 0)

code = open(SRV, encoding='utf-8').read()
sys.argv = ['file_server.py']
# 在本进程内执行服务代码 (__name__ 仍为 __main__, 触发 file_server 的启动块)
exec(compile(code, SRV, 'exec'))
