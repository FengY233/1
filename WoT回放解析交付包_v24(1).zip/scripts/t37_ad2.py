#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
t37_ad2.py — Task 37 ④b：按实体类型的 csi 宽度正确解码 AreaDestructibles slice 包
AreaDestructibles numCS=4 → csi 2bit。
vanilla: [1][csi 2b][0][start nb][end nb] + 值, nb=bitsRequirement(arrlen+1) 随长度变
关键观测: 值起点是否随数组增长从 1B→2B→3B 漂移
"""
import struct, sys, collections
sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import REPLAYS, load_pkts

def bits_of(bs): return ''.join(f'{x:08b}' for x in bs)

TAG, RP = None, None
for t, p in REPLAYS:
    if 'karelia_EU' in t: TAG, RP = t, p; break

pkts = load_pkts(RP)
# eid -> typeID (0x05: [eid u32][typeID u32]...)
eid2ty = {}
for ty, clk, pl in pkts:
    if ty == 5 and len(pl) >= 8:
        e, n = struct.unpack_from('<II', pl, 0)
        eid2ty[e] = n
print('实体数:', len(eid2ty), collections.Counter(eid2ty.values()))

p24 = [(c, pl) for ty, c, pl in pkts if ty == 0x24]
# AreaDestructibles typeID = 7
rows = []
for clk, pl in p24:
    eid, isl, ln = struct.unpack_from('<IBI', pl, 0)
    if eid2ty.get(eid) != 7: continue
    body = pl[9:9+ln]
    if not body: continue
    b = body[0]
    if not (b & 0x80): continue
    csi2 = (b >> 5) & 0x3          # 2bit csi
    stop = (b >> 4) & 1
    rows.append((clk, eid, isl, ln, body, csi2, stop))

print('AD 0x24 包数:', len(rows))
cnt = collections.Counter((r[4+1], r[6], r[2]) for r in rows)  # (csi2, stop, isl)
print('(csi2, stopbit, isSlice) 分布:', dict(cnt))

# csi=1 destroyedFragiles: 按时间序
fr = [r for r in rows if r[5] == 1]
print(f'\ndestroyedFragiles(csi=1) n={len(fr)}')
arrlen = {}
for i, (clk, eid, isl, ln, body, csi2, stop) in enumerate(fr):
    curlen = arrlen.get(eid, 1)
    nb = max(1, (curlen).bit_length())
    total = 4 + 2 * nb
    voff = (total + 7) // 8
    bstr = bits_of(body)
    start = int(bstr[4:4+nb], 2)
    end = int(bstr[4+nb:4+2*nb], 2)
    val = body[voff:]
    print(f'[{i:3d}] clk={clk} eid={eid} len={ln} nb={nb} start={start} end={end} voff={voff} val={val.hex()[:40]}')
    # 长度状态机: 假设元素=2B, slice(start,end)+len(val)/2 个新元素
    if val:
        nnew = max(0, len(val) // 2)
        arrlen[eid] = max(curlen + max(0, nnew - max(0, end - start)), start + nnew, end)
    if i >= 30: break
