#!/usr/bin/env python3
"""t38_final.py — Task 38 终态固化：
1. p24_final_v2.json 通道 29/30 语义重命名（perks / perksRibbonNotify）+ perks.xml 效果名 join
2. 输出 per-battle 技能画像表
3. 交付 data_v21/perks通道语义解码_v23.json"""
import json, sys
sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file
from collections import defaultdict, Counter

# ---- perks.xml ID -> 参数名 ----
node = decode_file('/tmp/wot_scripts/scripts/item_defs/perks/perks.xml')
PERK_ARGS = {}
for p in node.children:
    if p.name != 'perk':
        continue
    pid = None
    args = []
    for c in p.children:
        if c.name == 'id':
            pid = c.asInt()
        elif c.name == 'defaultBlockSettings':
            for a in c.children:
                if a.name == 'arg':
                    kv = {x.name: x.asString() for x in a.children}
                    args.append(kv.get('argId', '?'))
    PERK_ARGS[pid] = ', '.join(args)

FAMILY = lambda pid: {1: '视野/观察系', 2: '瞄准/火控系', 3: '机动/引擎系',
                      4: '装填/武器系', 5: '乘员/通用系'}.get(pid // 100, '特殊')

# ---- 对齐数据 ----
R = json.load(open('/tmp/wot/t38_align.json'))
out = []
for r in R:
    if r['csi'] == 29:
        pid = (r['A'] or 0) | ((r['B'] or 0) << 16)
        out.append({
            'tag': r['tag'], 'clk': r['clk'], 'eid': r['eid'],
            'channel': 'perks', 'elem': 'PERK_INFO_HUD',
            'perkID': pid, 'perkArgs': PERK_ARGS.get(pid, '<未知>'),
            'perkFamily': FAMILY(pid),
            'state': r['C'], 'coolDown': r['D'], 'lifeTime': r['time'],
        })
    elif r['csi'] == 30:
        pid = (r['A'] or 0) | ((r['B'] or 0) << 16)
        out.append({
            'tag': r['tag'], 'clk': r['clk'], 'eid': r['eid'],
            'channel': 'perksRibbonNotify', 'elem': 'PERK_INFO_RIBBON',
            'perkID': pid, 'perkArgs': PERK_ARGS.get(pid, '<未知>'),
            'perkFamily': FAMILY(pid),
            'endTime': r['time'],
        })

json.dump(out, open('/tmp/wot/perks_semantic_v23.json', 'w'), ensure_ascii=False, indent=1)
print('语义化记录:', len(out), '条 → /tmp/wot/perks_semantic_v23.json')

# ---- per-battle 技能画像 ----
print('\n== 各场录像玩家技能画像（随机战 10 场）==')
prof = defaultdict(Counter)
for r in out:
    if r['channel'] == 'perks':
        prof[r['tag']][r['perkID']] += 1
for tag in sorted(prof):
    ids = prof[tag]
    print('  %-18s %s' % (tag, ' '.join('%d(%s ×%d)' % (i, PERK_ARGS.get(i, '?')[:28], c)
                                        for i, c in ids.most_common())))

# ---- 统计确认 ----
print('\n== state/coolDown 关系统 ==')
sc = Counter((r.get('state'), round(r.get('coolDown', 0))) for r in out if r['channel'] == 'perks')
for k, v in sorted(sc.items(), key=lambda x: -x[1]):
    print('  state=%s coolDown=%s : %d 次' % (k[0], k[1], v))
