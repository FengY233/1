#!/usr/bin/env python3
"""p05_entity_scan.py — Task35: 指定 typeID 的 0x05 全流 dump (判别排序模型)
用法: python3 p05_entity_scan.py <typeID> [场tag]
"""
import json, struct, zlib, sys
from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])

REPLAYS = [
    ("siegfried_EU_935", "/tmp/wot/github_test/20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay"),
    ("karelia_EU_935", "/tmp/wot/github_test/20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay"),
    ("lakeville_EU_935", "/tmp/wot/github_test/20260907_1321_germany-G197_Pz_Kpfw_Neu_07_lakeville.wotreplay"),
    ("caucasus_NA_945", "/tmp/wot/github_test/20260910_1057_china-Ch67_BZ_79_37_caucasus.wotreplay"),
    ("namerica_CN_942", "/tmp/wot/github_test/20260911_1534_ussr-R52_Object_261_44_north_america.wotreplay"),
    ("caucasus_CN_942", "/tmp/wot/github_test/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay"),
    ("greatwall_EU_944", "/tmp/wot/github_test/20260912_1036_france-F143_Fauteur_59_asia_great_wall.wotreplay"),
    ("karelia2_EU_944", "/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay"),
    ("PTZ_EU_944", "/tmp/wot/github_test/PTZ_10K.wotreplay"),
    ("WZ219_EU_944", "/tmp/wot/github_test/WZ-219.wotreplay"),
]


def load_pkts(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from('<I', data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b'\x00' * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        dd = cipher.decrypt(main[i:i + 8])
        dd = bytes(a ^ b for a, b in zip(dd, prev))
        prev = dd
        out += dd
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from('<III', stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


def main():
    tid = int(sys.argv[1])
    tag_want = sys.argv[2] if len(sys.argv) > 2 else None
    limit = int(sys.argv[3]) if len(sys.argv) > 3 else 6
    n = 0
    for tag, path in REPLAYS:
        if tag_want and tag != tag_want:
            continue
        pkts = load_pkts(path)
        ents = [pl for ty, c, pl in pkts if ty == 5 and len(pl) >= 47
                and struct.unpack_from('<I', pl, 4)[0] == tid]
        for pl in ents[:limit]:
            eid = struct.unpack_from('<I', pl, 0)[0]
            propBytes, = struct.unpack_from('<I', pl, 42)
            body = pl[46:]
            print(f'== {tag} eid={eid} propBytes={propBytes} count={body[0]} len={len(body)}')
            for off in range(0, len(body), 16):
                print(f'  +{off:3d}: ' + body[off:off+16].hex(' '))
            n += 1
            if n >= limit:
                return
        if ents and not tag_want:
            print(f'({tag}: {len(ents)} 个, 展示前几个)')


if __name__ == '__main__':
    main()
