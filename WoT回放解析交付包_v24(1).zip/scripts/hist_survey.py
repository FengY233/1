#!/usr/bin/env python3
"""hist_survey.py — 随机战语料包类型直方图 + 尾部结算块检查（百分比估算事实基座）
tundra(bt=46, 7v7 特殊模式) 单列对照，其余 10 场 = 随机战语料"""
import json, struct, zlib
from collections import Counter
from Crypto.Cipher import Blowfish

KEY = bytes([0xDE,0x72,0xBE,0xA0,0xDE,0x04,0xBE,0xB1,
             0xDE,0xFE,0xBE,0xEF,0xDE,0xAD,0xBE,0xEF])

def load(path):
    data = open(path, "rb").read()
    magic, bc = struct.unpack_from("<II", data, 0)
    assert magic == 0x11343212
    pos = 8; blocks = []
    for _ in range(bc):
        (blen,) = struct.unpack_from("<I", data, pos)
        blocks.append(data[pos+4:pos+4+blen]); pos += 4 + blen
    (declared,) = struct.unpack_from("<I", data, pos); pos += 4
    (stream_len,) = struct.unpack_from("<I", data, pos); pos += 4
    main = data[pos:]
    return blocks, declared, stream_len, main, len(data) - pos - stream_len  # 尾部余量

def parse_packets(main):
    # 主流分片: [u32 fragLen][blowfish(fragLen)] 循环
    bf = Blowfish.new(KEY, Blowfish.MODE_ECB)
    raw = b""; pos = 0
    while pos + 4 <= len(main):
        (flen,) = struct.unpack_from("<I", main, pos); pos += 4
        chunk = main[pos:pos+flen]; pos += flen
        pad = (-flen) % 8
        raw += bf.decrypt(chunk + b"\x00" * pad)[:flen]
    # 包: [u8 type][u32 clk][payload...]，0x00=keepalive 长度1? 实际族: [type][...]
    pkts = []; p = 0
    while p < len(raw):
        t = raw[p]
        if t == 0x00:
            pkts.append((t, 0, b"")); p += 1; continue
        if p + 5 > len(raw): break
        clk = struct.unpack_from("<I", raw, p+1)[0]
        # 长度由类型决定——此处只统计类型与首部，用既有事实: 大多数包 [t][clk u32][len u32][body]
        # 0x18/0x2D 等为变长字符串族, 用 survey 的成熟逻辑不可得, 简化: 只对已知定长族计数
        pkts.append((t, clk, raw[p+5:p+13])); p += 1  # 占位——真实解析在既有脚本
    return raw, pkts

# 直接复用成熟解析: 找 survey 的 parse
import importlib.util as iu
spec = iu.spec_from_file_location("sv", "/home/z/my-project/scripts/survey_new_replays.py")
sv = iu.module_from_spec(spec)
try:
    spec.loader.exec_module(sv)
except SystemExit:
    pass

import glob
files = sorted(glob.glob("/tmp/wot/github_test/*.wotreplay"))
tundra = [f for f in files if "tundra" in f][0]
rnd = [f for f in files if "tundra" not in f]

agg_rand, agg_tundra = Counter(), Counter()
print("%-52s %-6s %-7s %-5s %s" % ("文件", "块数", "主流KB", "尾余", "类型top8"))
for f in files:
    blocks, declared, slen, main, tail = load(f)
    # 解密主流
    raw = sv_decrypt = None
    # 用 survey 模块内部的解密+解析（survey() 函数本身）
    r = sv.survey(f)
    hist = Counter()
    for t, c in r["types"].items():
        hist[int(t, 16)] = c
    if f == tundra:
        agg_tundra.update(hist)
    else:
        agg_rand.update(hist)
    top = " ".join("%02X:%d" % (t, c) for t, c in hist.most_common(8))
    print("%-52s %-6d %-7d %-5d %s" % (f.split("/")[-1][:52], len(blocks), slen//1024, tail, top))

print("\n== 随机战 10 场合计 ==")
tot = sum(agg_rand.values())
for t, c in agg_rand.most_common():
    print("  0x%02X  %7d  %5.1f%%" % (t, c, 100.0*c/tot))
print("  TOTAL", tot)
print("\n== tundra(非随机战) 对照 ==")
for t, c in agg_tundra.most_common(12):
    print("  0x%02X  %7d" % (t, c))
