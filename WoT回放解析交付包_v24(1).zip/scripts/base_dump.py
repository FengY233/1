#!/usr/bin/env python3
"""base_dump.py — dump 0x05 基础段原始字节 (46 起 60B) 供人工断句"""
import struct, zlib
from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])


def load_pkts(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from('<I', data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b'\x00' * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        dd = cipher.decrypt(main[i:i + 8])
        dd = bytes(a ^ b for a, b in zip(dd, prev))
        prev = dd
        out += dd
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from('<III', stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


CASES = [
    ("T92", "/tmp/wot/github_test/20260910_1057_china-Ch67_BZ_79_37_caucasus.wotreplay"),
    ("Fauteur", "/tmp/wot/github_test/20260907_1321_germany-G197_Pz_Kpfw_Neu_07_lakeville.wotreplay"),
    ("BV111", "/tmp/wot/github_test/20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay"),
    ("HoRi", "/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay"),
]

for name, path in CASES:
    pkts = load_pkts(path)
    veh = [pl for ty, c, pl in pkts if ty == 5 and len(pl) >= 47
           and struct.unpack_from('<I', pl, 4)[0] == 6]
    print(f'== {name} ({len(veh)} veh) 前 3 辆:')
    for pl in veh[:3]:
        eid = struct.unpack_from('<I', pl, 0)[0]
        cnt = pl[46]
        h = pl[46:46 + 72].hex()
        print(f'  eid={eid} count={cnt} len={len(pl)}')
        print(f'    {h}')
    print()
