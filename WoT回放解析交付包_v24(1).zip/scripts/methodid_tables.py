#!/usr/bin/env python3
"""methodid_tables.py — 网络层 methodID 分配表生成器 + 未识别实体对号

§12.3 规则：网络 methodID = 域内 exposedMethods_（isExposed = flags&0xC）
stable_sort by streamSize（定长升序在前、变长按 vlh 升序在后、同键保持声明序）后 0 起编号。
0x08 为服务器→客户端调用 → client 域编号。
对比 11 场"每场恰一个"的未识别实体 methodID 签名 → 识别身份。
"""
import json
import sys

sys.path.insert(0, '/home/z/my-project/scripts')
import os
from bwxml import decode_file
from defparse import EntityDefParser
import digest_fork_v2 as dfv


def build_records():
    """复用 digest_fork_v2 main() 的组装逻辑，返回主实体部分 records + 挂载"""
    parser = EntityDefParser(dfv.SCRIPTS)
    parser.load()                   # 40 主实体（entities.xml 声明序）

    comps_root = decode_file(os.path.join(dfv.SCRIPTS, 'components.xml'), 'components.xml')
    static_list = [k.name for k in comps_root.child('StaticComponents').children]

    mounts = {}
    sub_cache = {}
    locator = dfv.DefLocator([])
    for name in static_list:
        sec = decode_file(os.path.join(dfv.CD, name + '.def'), name + '.def')
        ofe = sec.child('ofEntity')
        if ofe is not None:
            for e in ofe.children:
                mounts.setdefault(e.asString(), []).append(name)

    records = [dfv.parse_space_record(parser)]
    for ed in parser.entities:
        ed.fork_components = [dfv.load_static_comp(parser, locator, c, sub_cache)
                              for c in mounts.get(ed.name, [])]
        records.append(ed)
    return records, parser


def exposed_sorted(ed, domain='client'):
    """域内 exposed 方法 stable_sort by streamSize → (methodID, name) 表"""
    DOM = {'client': 'client_methods', 'base': 'base_methods', 'cell': 'cell_methods'}[domain]
    cand = list(getattr(ed, DOM))
    for sd in getattr(ed, 'fork_components', []):
        cand += getattr(sd, DOM)
    exposed = [m for m in cand if m.flags & 0xC]
    # stable_sort：定长(streamSize>=0)在前按 size 升序；变长(<0)在后按 vlh 升序
    keyed = [(0, m._stream_size, m.var_len_header, i, m) for i, m in enumerate(exposed)]
    keyed.sort(key=lambda t: (t[0], t[1] if t[0] == 0 else t[2]))
    return [(i, m.name, m._stream_size, m.var_len_header, m.flags)
            for i, (_, _, _, _, m) in enumerate(keyed)]


def main():
    records, parser = build_records()
    by_name = {ed.name: ed for ed in records}

    # 11 场未识别实体的观测签名（mid_signatures2 输出汇总）
    observed = {
        "siegfried_EU":  {10, 28, 29, 30, 37, 38, 40, 54, 58, 62, 65, 67},
        "karelia_EU":    {10, 28, 29, 30, 37, 38, 40, 54, 58, 62, 67, 68},
        "lakeville_EU":  {10, 28, 29, 30, 37, 38, 40, 54, 58, 62, 67, 68},
        "caucasus_NA":   {10, 23, 28, 29, 30, 33, 37, 38, 54, 58, 62, 65, 67, 68},
        "namerica_CN":   {10, 23, 27, 28, 37, 38, 40, 53, 54, 58, 62, 67},
        "tundra_CN_bt46": {28, 29, 30, 37, 54, 58, 62, 67},
        "caucasus_CN":   {10, 23, 27, 28, 37, 38, 53, 54, 58, 62, 65, 67},
        "greatwall_EU":  {10, 28, 29, 30, 37, 38, 40, 54, 58, 62, 67, 68},
        "karelia2_EU":   {7, 10, 28, 29, 30, 37, 38, 40, 54, 58, 62, 67, 68},
        "PTZ_10K_EU":    {7, 10, 23, 28, 29, 30, 33, 37, 38, 54, 58, 62, 67, 68},
        "WZ219_EU":      {10, 28, 37, 38, 54, 58, 62, 65, 67, 68},
    }
    all_obs = set().union(*observed.values())
    obs_count = {}
    for s in observed.values():
        for m in s:
            obs_count[m] = obs_count.get(m, 0) + 1

    # 对每个实体类型打分：观测 mid 是否都 < 该实体 client exposed 方法总数
    print("=== 候选实体 client 域 exposed 方法表（与观测对比）===")
    results = []
    for ed in records:
        if ed.name == 'GeneralSpaceData':
            continue
        tbl = exposed_sorted(ed, 'client')
        nmeth = len(tbl)
        if nmeth == 0:
            continue
        cover = sum(1 for m in all_obs if m < nmeth)
        results.append((ed.name, nmeth, cover, tbl))

    results.sort(key=lambda r: -r[2])
    for name, nmeth, cover, tbl in results[:15]:
        print(f"  {name:32s} client暴露方法 {nmeth:3d} 个, 覆盖观测 mid {cover}/{len(all_obs)}")

    # 最佳候选详细表
    print("\n=== 最佳候选（按覆盖排序前 3）详细 methodID 表 ===")
    out = {}
    for name, nmeth, cover, tbl in results[:3]:
        print(f"\n--- {name} ({nmeth} client exposed methods) ---")
        d = {}
        for i, mname, ss, vlh, fl in tbl:
            mark = ' ★' if i in all_obs else ''
            cnt = obs_count.get(i, 0)
            tag = f' [{cnt}/11 场]' if cnt else ''
            print(f"  {i:3d}  {mname:45s} ss={ss:4d} vlh={vlh} fl=0x{fl:x}{mark}{tag}")
            d[i] = mname
        out[name] = d
    # 存全部表
    full = {}
    for name, nmeth, cover, tbl in results:
        full[name] = {i: mname for i, mname, _, _, _ in tbl}
        full[name + '__meta'] = {'n_client_exposed': nmeth}
    with open('/tmp/wot/methodid_tables.json', 'w') as f:
        json.dump(full, f, ensure_ascii=False, indent=1)
    print("\n[saved] /tmp/wot/methodid_tables.json")


if __name__ == '__main__':
    main()
