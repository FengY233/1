#!/usr/bin/env python3
"""compdef_dump.py — 解析全部 component_defs/*.def 的属性表 (BWXML)
输出: 组件名 → [(属性名, 类型串, streamSize, isCS)]
"""
import os, sys, json
sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file
from defparse import DT

CDIR = '/tmp/wot_scripts/scripts/component_defs'


def type_str(dt):
    k = dt.kind
    if k in ('ARRAY', 'TUPLE'):
        return f'{k}<{type_str(dt.elem)}>'
    if k == 'FIXED_DICT':
        return 'FD{' + ','.join(n + ':' + type_str(t) for n, t in dt.fields) + '}'
    if k == 'INT':
        return ('I' if dt.signed else 'U') + str(dt.size * 8)
    if k == 'FLOAT':
        return 'F32' if dt.size == 4 else 'F64'
    if k == 'VECTOR':
        return f'V{dt.n}'
    return k


def prop_ss(dt):
    try:
        return dt.streamSize()
    except Exception:
        return -2


def parse_def(path):
    """手撸 def 解析: 用 defparse 的内部? 不, 直接 BWXML → 结构"""
    root = decode_file(path)  # 返回什么? 先探测
    return root


# 先看 bwxml.decode_file 返回结构
r = decode_file(os.path.join(CDIR, 'HealthComponent.def'))
print('root type:', type(r))
if isinstance(r, (list, tuple)):
    for c in r[:5]:
        print(' child:', type(c), str(c)[:200])
elif hasattr(r, 'children'):
    for c in r.children[:5]:
        print(' child:', type(c), str(c)[:200])
else:
    print(str(r)[:500])
