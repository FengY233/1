#!/usr/bin/env python3
"""entity_decl_order.py — entities.xml 声明序 ↔ 0x05 typeID 对齐

entities.xml <ClientServerEntities> 有 40 个子节点 = 声明序。
digest 工作（findings §12）已知 1 基序：Account(1) Avatar(2) ArenaInfo(3)
ClientSelectableObject(4) HangarVehicle(5) Vehicle(6) AreaDestructibles(7)…
0x05 实证：typeID=3 每场恰 1 个（ArenaInfo ✓）、6=车辆群 ✓、7=可破坏物群 ✓
→ 输出 1 基声明序全表，标注 0x05 跨场观测（哪些 typeID 被网络创建、频次特征）
"""
import json
import sys

sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file

root = decode_file('/tmp/wot_scripts/scripts/entities.xml')
cs = root.children[0]
names = [c.name for c in cs.children]
print(f"ClientServerEntities 共 {len(names)} 实体，声明序（1 基）：")
for i, n in enumerate(names, 1):
    print(f"  {i:3d}  {n}")

# 载入跨场 0x05 观测
anchor = json.load(open('/tmp/wot/entity_anchor.json'))
obs = {}
for r in anchor:
    for t, c in r['typeIDs'].items():
        obs.setdefault(t, []).append((r['tag'], c))

print("\n=== 0x05 跨场观测对齐（typeID → 实体名 → 出现场次）===")
for t in sorted(obs):
    t2 = int(t)
    nm = names[t2 - 1] if 1 <= t2 <= len(names) else '???'
    fields = ', '.join(f"{tag}:{c}" for tag, c in obs[t])
    n_fields = len(obs[t])
    print(f"  typeID={t2:3d} {nm:35s} {n_fields}/11 场  [{fields}]")
