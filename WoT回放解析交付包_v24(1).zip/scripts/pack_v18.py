#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""pack_v18.py — V18 交付包：0x24 终局破解轮"""
import json, os, zipfile, shutil, hashlib

BASE = '/home/z/my-project'
DL = f'{BASE}/download'
OUT = f'{DL}/WoT回放解析交付包_v18.zip'
DATA = f'{DL}/data_v18'
os.makedirs(DATA, exist_ok=True)

# 1) p24_final_v2 → data_v18
shutil.copy('/tmp/wot/p24_final_v2.json', f'{DATA}/0x24全量精确解码_5241条_v22.json')
shutil.copy('/tmp/wot/veh_decl_table.json', f'{DATA}/Vehicle声明序表_76属性.json')

# 2) findings/worklog 快照
shutil.copy(f'{DL}/findings.md', f'{DATA}/findings_v22.md')

# 3) 打包
files = []
for root, _, fs in os.walk(DATA):
    for f in fs:
        p = os.path.join(root, f)
        files.append((p, os.path.relpath(p, DATA)))
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED) as z:
    for p, arc in files:
        z.write(p, arc)
    # 关键脚本
    for s in ('p24_decode_v2.py', 't37_sm2.py', 't37_sm3.py', 't37_alias2.py',
              't37_decl.py', 't37_7bit.py', 't37_bits.py'):
        z.write(f'{BASE}/scripts/{s}', f'scripts/{s}')
    z.write(f'{BASE}/worklog.md', 'worklog.md')

h = hashlib.md5(open(OUT, 'rb').read()).hexdigest()
sz = os.path.getsize(OUT)
print(f'V18 打包完成: {OUT}')
print(f'  大小: {sz:,} B  md5: {h}')
with zipfile.ZipFile(OUT) as z:
    names = z.namelist()
    print(f'  条目: {len(names)}')
    for n in names: print('   ', n)
