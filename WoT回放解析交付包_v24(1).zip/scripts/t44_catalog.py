#!/usr/bin/env python3
"""t44_catalog.py — Task 44 收尾: 0x32/0x37/0x39 全量经验语法目录
文法(本轮 decomp+EXE 白盒成果):
  0x32 = ClientHub 通道0 消息: [u32 len(recorder加)] + [u16 BE class<<8|sub] + body + 后续消息
  0x37 = NRL 原始字节流(整块喂给 hub+0xb8 缓冲): [u16 BE nid][u8 op][u8 sub][body] 组循环
  0x39 = 多消息流: [u8 X][u8 b0][u8 class][u8 sub][body] 循环 (X<6 普通 / X==6 updateNode)
产出: 各 (class,sub)/(op,sub) 族的 数量/长度分布/样本/字符串 → 语义族目录
"""
import struct, sys, glob, json
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter, defaultdict

REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
tundra = [f for f in REPLAYS if 'tundra' in f][0]
RND = [f for f in REPLAYS if f != tundra]

def parse_hierarchy_array(p):
    for start in range(0, min(len(p), 400)):
        n = p[start]
        if not (3 <= n <= 12):
            continue
        pos = start + 1
        items = []
        ok = True
        for _ in range(n):
            if pos >= len(p):
                ok = False; break
            ln = p[pos]; pos += 1
            if not (2 <= ln <= 32) or pos + ln + 4 > len(p):
                ok = False; break
            name = p[pos:pos+ln].decode('utf-8', 'replace')
            pos += ln
            nid = struct.unpack_from('<I', p, pos)[0]
            pos += 4
            items.append((name, nid))
        if ok and pos == len(p) and items:
            return start, items
    return None, None

fam32 = defaultdict(lambda: {'n': 0, 'lens': Counter(), 'sample': None, 'strs': Counter()})
fam37 = defaultdict(lambda: {'n': 0, 'lens': Counter(), 'sample': None})
nid37 = Counter()
hier_count = 0
nid2slot = {}

for f in RND:
    blocks, declared, slen, pkts = load(f)
    for t, c, p in pkts:
        if t == 0x32:
            stream = p[4:]
            if len(stream) < 2:
                continue
            cls, sub = stream[0], stream[1]
            key = (cls, sub)
            d = fam32[key]
            d['n'] += 1
            d['lens'][len(stream)] += 1
            if d['sample'] is None:
                d['sample'] = stream[:60].hex(' ')
            # 字符串普查
            i = 0
            while i < len(stream) - 1:
                n = stream[i]
                if 4 <= n <= 32 and i + 1 + n <= len(stream):
                    s = stream[i+1:i+1+n]
                    if all(32 <= x < 127 for x in s):
                        try:
                            d['strs'][s.decode()] += 1
                        except Exception:
                            pass
                        i += 1 + n
                        continue
                i += 1
            # hierarchy 数组
            st, items = parse_hierarchy_array(stream)
            if items and any(s in ('hull', 'turret', 'gun', 'chassis') for s, _ in items):
                hier_count += 1
                for s, nid in items:
                    nid2slot.setdefault(nid, set()).add(s)
        elif t == 0x37:
            stream = p[4:]
            # 组循环: [u16 BE nid][u8 op][u8 sub][body?] —— 组边界未知, 先按 7B/10B 观察值
            if len(stream) >= 4:
                nid = struct.unpack_from('>H', stream, 0)[0]
                op, sub = stream[2], stream[3]
                fam37[(op, sub)]['n'] += 1
                fam37[(op, sub)]['lens'][len(stream)] += 1
                if fam37[(op, sub)]['sample'] is None:
                    fam37[(op, sub)]['sample'] = stream[:40].hex(' ')
                nid37[nid] += 1

print('=' * 70)
print('0x32 消息族目录 (class, sub) — 10 场随机战')
print('=' * 70)
for (cls, sub), d in sorted(fam32.items(), key=lambda kv: -kv[1]['n']):
    tops = ', '.join(f'{s}×{n}' for s, n in d['strs'].most_common(3))
    lens = ', '.join(f'{l}:{n}' for l, n in d['lens'].most_common(4))
    print(f'class={cls} sub={sub:#04x}: n={d["n"]:5d}  len[{lens}]')
    if tops:
        print(f'    strs: {tops}')
    print(f'    sample: {d["sample"][:72]}')

print()
print('=' * 70)
print('0x37 组族目录 (op, sub) — 首组统计')
print('=' * 70)
for (op, sub), d in sorted(fam37.items(), key=lambda kv: -kv[1]['n']):
    lens = ', '.join(f'{l}:{n}' for l, n in d['lens'].most_common(4))
    print(f'op={op} sub={sub:#04x}: n={d["n"]:5d}  len[{lens}]  sample: {d["sample"][:56]}')

print()
print('0x37 首nid TOP15 (BE):', [(hex(n), c) for n, c in nid37.most_common(15)])
veh_hit = sum(c for n, c in nid37.items() if n in nid2slot)
print(f'首nid 命中车辆槽位字典: {veh_hit}/{sum(nid37.values())}')
print(f'hierarchy 包总数: {hier_count}, nid字典规模: {len(nid2slot)}')

# 保存
out = {
    'fam32': {f'{c}_{s:02x}': {'n': d['n'], 'lens': dict(d['lens']), 'sample': d['sample'],
                              'strs': dict(d['strs'])} for (c, s), d in fam32.items()},
    'fam37': {f'{o}_{s:02x}': {'n': d['n'], 'lens': dict(d['lens']), 'sample': d['sample']}
              for (o, s), d in fam37.items()},
    'nid37': {str(k): v for k, v in nid37.most_common()},
    'nid2slot': {str(k): sorted(v) for k, v in nid2slot.items()},
    'hier_count': hier_count,
}
json.dump(out, open('/tmp/wot/t44_catalog.json', 'w'), ensure_ascii=False, indent=1)
print('\n已存 /tmp/wot/t44_catalog.json')
