#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
t37_bits.py — Task 37 ③b：csi=29/30 原始 body 位级注解
逐位标注: [1][csi 6b][0][leafIdx 2b (Single) 或 start 3b+end 3b (Slice)] [padding] [value...]
并给出两种值起点假设的字节切分。
"""
import struct, sys, collections
sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import REPLAYS, load_pkts

def bits_of(b):
    return ''.join(f'{x:08b}' for x in b)

TAG, REPLAY = None, None
for t, p in REPLAYS:
    if '1801' in p: TAG, REPLAY = t, p; break

pkts = load_pkts(REPLAY)
p24 = [(c, pl) for ty, c, pl in pkts if ty == 0x24]
print(f'{TAG}: 0x24 n={len(p24)}')

for clk, pl in p24:
    eid, isl, ln = struct.unpack_from('<IBI', pl, 0)
    body = pl[9:9+ln]
    # 首 8 bit: [1][csi 6b][stop?]
    b0 = bits_of(body[0])
    if b0[0] != '1': continue
    csi = int(b0[1:7], 2)
    if csi not in (29, 30, 27, 28): continue
    stop = b0[7]
    rest = bits_of(body[1:])
    print(f'\neid={eid} isl={isl} len={ln} csi={csi} stopbit={stop}')
    print(f'  body = {body.hex()}')
    print(f'  bits = {b0} | {rest}')
    if isl == 0:
        # Single: leafIdx 2b (csi=29: dict 4 fields; csi=30: 7 fields -> 3b)
        nfields = {29: 4, 30: 7, 27: None, 28: None}[csi]
        if nfields:
            nb = max(1, (nfields-1).bit_length())
            print(f'  Single leafIdx ({nb}b over {nfields} fields) = {rest[:nb]}')
            print(f'  [假设A: 值起始于 ceil((8+{nb})/8)*2={((8+nb+7)//8)*1}]字节 -> val={body[2:].hex()}')
    else:
        nfields = {29: 4, 30: 7, 27: None, 28: None}[csi]
        if nfields:
            nb = max(1, (nfields).bit_length())  # bitsRequired(n+1)
            print(f'  Slice start/end 各 {nb}b = {rest[:nb]} / {rest[nb:2*nb]}')
            print(f'  val(从字节2) = {body[2:].hex()}')
    # 统计 csi=29 的 body[1] 高 nibble（slice 位所在）
