#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
t37_fit.py — Task 37 ②：csi 映射漂移拟合
方法：对 Vehicle / AreaDestructibles 的 0x24 包，统计每 csi 的 (isSlice, nested, 值长) 直方图；
     用 def 类型树推每个 csi 候选属性在各种路径下的可能值长集合；
     测试「漂移假设」：csi 与 def 声明序错位 k 时是否全局自洽。
数据：/tmp/wot/p24_final.json (5,241 包) + def 类型树 (defparse)
"""
import json, sys, collections
sys.path.insert(0, '/home/z/my-project/scripts')

d = json.load(open('/tmp/wot/p24_final.json'))

# ---- 每实体的 csi -> (isSlice, nested) -> 值长直方图 ----
hist = collections.defaultdict(lambda: collections.Counter())
names = {}
for r in d:
    key = (r['type'], r['csi'])
    names[key] = r.get('name', '?')
    hist[key][(r['isSlice'], bool(r.get('nested')), len(bytes.fromhex(r['val'])))] += 1

print('=== 观测: (实体, csi) -> [(isSlice, nested, 值长): n] ===')
for key in sorted(hist, key=lambda k: (k[0], k[1])):
    print(f'{key[0]:20s} csi={key[1]:2d} [{names[key]:22s}] ' +
          ' '.join(f'{k}:{v}' for k, v in sorted(hist[key].items())))

# ---- AreaDestructibles 类型树 ----
print()
print('=== AreaDestructibles.def CS 属性 (声明序) ===')
from bwxml import decode_file
DEFS = '/tmp/wot_scripts/scripts/entity_defs'
def sval(sec):
    try: return sec.data_str if hasattr(sec, 'data_str') else (sec.data if isinstance(sec.data, str) else sec.data.decode('utf8', 'replace'))
    except Exception: return str(sec.data)

ad = decode_file(DEFS + '/AreaDestructibles.def', 'AreaDestructibles.def')
idx = 0
for c in ad.children:
    if c.name == 'Properties':
        for p in c.children:
            tname = ''
            flags = ''
            for k in p.children:
                if k.name == 'Type': tname = sval(k)
                if k.name == 'Flags': flags = sval(k)
            # 只列 ALL_CLIENTS / BASE_CLIENTS 等 CS 属性
            if 'CLIENT' in flags:
                print(f'  CS#{idx:2d} {p.name:24s} {tname:30s} {flags}')
                idx += 1
