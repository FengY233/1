#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
t37_alias.py — Task 37 ①：0x24 值段类型定义提取
目标：OWN_VEHICLE_POSITION / INSPIRED_EFFECT / PERK_EFFECTS(+INSPIRING) / PERKS 的
完整类型树（FIXED_DICT 字段序 + AllowNone + 元素类型），供值段字段级解码对位。
数据源：/tmp/wot_scripts/scripts/entity_defs/alias.xml (BWXML) + Vehicle.def
"""
import sys, json
sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file

DEFS = '/tmp/wot_scripts/scripts/entity_defs'

def dump_type(sec, depth=0, maxdepth=12):
    """递归打印 BWXML 类型节点 -> 结构化 dict"""
    out = {'name': sec.name}
    kids = sec.children
    # <Type> 或 <Array>/<FixedDict>/<Tuple> 容器
    if sec.name in ('Array', 'Tuple'):
        inner = [c for c in kids if c.name != 'databaseLen']
        out['kind'] = sec.name
        out['elem'] = [dump_type(c, depth+1, maxdepth) for c in inner]
        dl = [c for c in kids if c.name == 'databaseLen']
        if dl: out['databaseLen'] = True
    elif sec.name == 'FixedDict':
        out['kind'] = 'FixedDict'
        out['AllowNone'] = any(c.name == 'AllowNone' for c in kids)
        out['fields'] = []
        for c in kids:
            if c.name == 'property':
                fname = c.string if hasattr(c, 'string') else None
                # property 节点: 名字在自身 data，类型在子节点
                f = {'field': c.data_str if hasattr(c, 'data_str') else str(c.data)}
                sub = [k for k in c.children]
                f['type'] = [dump_type(k, depth+1, maxdepth) for k in sub]
                out['fields'].append(f)
    elif sec.name == 'property':
        out['kind'] = 'property'
        out['type'] = [dump_type(c, depth+1, maxdepth) for c in kids]
    else:
        # 标量类型节点：<Type>STRING</Type> 的形态
        out['kind'] = 'scalar'
        out['val'] = sec.data_str if hasattr(sec, 'data_str') else str(sec.data)
    return out

# 1) alias.xml —— 直接解析
alias_sec = decode_file(DEFS + '/alias.xml', 'alias.xml')
targets = ['OWN_VEHICLE_POSITION', 'INSPIRED_EFFECT', 'INSPIRING_EFFECT',
           'PERK_EFFECTS', 'PERKS', 'PERK_INFO_HUD', 'BUFF_EFFECT']
result = {}
for c in alias_sec.children:
    if c.name in targets:
        # alias 子节点: <OWN_VEHICLE_POSITION> <FixedDict>... 或 <Array of ...>
        result[c.name] = dump_type(c, 0)
        # 也保留原始 XML dump

# 2) Vehicle.def —— 属性声明（类型名 + Flags/DetailLevel + INTERNAL 标记）
veh = decode_file(DEFS + '/Vehicle.def', 'Vehicle.def')
props = {}
want = {'ownVehiclePosition', 'perkEffects', 'inspired', 'inspiring', 'perks'}
for c in veh.children:
    if c.name == 'Properties':
        for p in c.children:
            if p.name in want:
                rec = {'children': [k.name for k in p.children]}
                for k in p.children:
                    # <ownVehiclePosition> <Type> OWN_VEHICLE_POSITION </Type> <Flags> ... </Flags>
                    ks = k.data_str if hasattr(k, 'data_str') else str(k.data)
                    rec[k.name] = ks
                    rec[k.name + '_kids'] = [g.name for g in k.children]
                props[p.name] = rec

print(json.dumps({'alias': result, 'vehicle_props': props},
                 ensure_ascii=False, indent=1)[:6000])
