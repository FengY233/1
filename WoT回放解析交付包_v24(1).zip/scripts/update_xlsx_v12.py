#!/usr/bin/env python3
"""update_xlsx_v12.py — 在 V11 xlsx 基础上加 2 表（v16 扩展方法修正 + 网络 methodID 机制）"""
import shutil
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

SRC = '/tmp/wot/v11_unpack/WoT回放解析数据包_20260911_caucasus.xlsx'
DST = '/tmp/wot/v12_stage/WoT回放解析数据包_20260911_caucasus.xlsx'

import os
os.makedirs('/tmp/wot/v12_stage', exist_ok=True)
shutil.copy(SRC, DST)

wb = load_workbook(DST)
print('现有表:', wb.sheetnames)

HDR_FILL = PatternFill('solid', fgColor='645B42')
HDR_FONT = Font(name='Calibri', size=11, bold=True, color='FFFFFF')
THIN = Border(*[Side(style='thin', color='D9D2B8')] * 4)


def add_sheet(name, headers, rows, widths):
    if name in wb.sheetnames:
        del wb[name]
    ws = wb.create_sheet(name)
    ws.append(headers)
    for c in ws[1]:
        c.fill, c.font = HDR_FILL, HDR_FONT
        c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        c.border = THIN
    for r in rows:
        ws.append(r)
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.alignment = Alignment(vertical='top', wrap_text=True)
            c.border = THIN
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[chr(64 + i) if i <= 26 else 'A' + chr(64 + i - 26)].width = w
    ws.freeze_panes = 'A2'
    return ws


# 表 1: v16 方法层修正与真值锚
rows1 = [
    ['v13 判定（错误）', 'client 方法 flags 恒 0 → 全部出局；base/cell 用 is_exposed(0x2 位) 过滤',
     '0x08 运行时 1265 包对账证伪：Avatar client 域 flags=0x4 方法（70 个）全部可网络调用'],
    ['fork 真实规则', 'component==CLIENT 时 flags |= 4（IS_EXPOSED_TO_ALL_CLIENTS）',
     'FUN_142aa7540:377428 机器码 if(param_3==0) flags|=4；vanilla 无此规则（唯一行为差异）'],
    ['修复后过滤', '三域统一 (flags & 0xC) != 0（分布位，非 exposed 位）',
     'client 方法全部进 digest；base/cell 纯 exposed(0x2) 方法出局'],
    ['方法 flags 宽度', 'u16（2 字节 [flags, 0x00]）', 'slot10=0x1403e8260 u16 喂入器；v9-v13 集体漏读'],
    ['方法数修正', '163 → 366（主消融 105 → 247）', 'V12 重建版同口径统计 372/253（含静态子描述，digest 流逐位一致）'],
    ['varLen 分支激活', 'client 方法进 digest → isForClient 的 varLen u32 前缀生效',
     'vlh 分布 {1:342, 2:5}：showGUI/updateSpawnList/explodeProjectile/updateQuestProgress/setUpdatedGoodiesSnapshot'],
    ['ReturnValues 复核', '全部 5 处 RV 方法无分布位 → 0 字节', '新语义下复核维持出局'],
    ['0x08 真值', '1,265 包 / 31 eid / 128 (eid, methodID) 对全量命中',
     'Vehicle mid=1=showShooting、4=onHealthChanged、10=showDamageFromShot；Avatar mid=23=updateArena×28'],
    ['jsonl m 字段', '生成器错位标注，弃用', 'README 警告应验：mid=58 标 setClientReady 实为 updateArena 参数'],
    ['digest 值', '5976CA145E07E97C627D8B40ED9952CF（v16 终态，318 记录）',
     'V12 重建精确复现；仍 ≠ 目标 5DF886F75E73B33CFF9D87FB9C69389C'],
    ['剩余自由度', 'dyncomp 记录内容（267/318 = 84% 无运行时真值源）',
     '破口：录大逃杀/前线/背水之战回放取扩展真值锚'],
]
add_sheet('v16方法层修正', ['项目', '结论', '证据/备注'], rows1, [18, 52, 70])

# 表 2: 网络 methodID 机制 + 版本终局
rows2 = [
    ['编号体系', '网络 methodID ≠ digest index（两套编号）',
     'digest index = legacyExposedIndex（声明序计数，仅通过者递增）'],
    ['网络 methodID', '域内 exposedMethods_ stable_sort by streamSize 后 0 起编号',
     '定长升序在前、变长按 varLenHeaderSize 在后——与属性 csi 排序同族同构'],
    ['streamSize(true)', '定长=args 和（cell exposed 服务器方向 +4）；变长=-vlh',
     'vanilla method_description.cpp 源码确认'],
    ['0x05 n 字段', '= 实体类型索引（记录 +0x82 计数器）',
     '分布 {3:ArenaInfo, 6:Vehicle×30, 7:AreaDestructibles, 18/28/29:各1, 40:NetworkEntity×4}'],
    ['entities.xml 序', '真实声明序非字母序',
     'Account, Avatar, ArenaInfo, ClientSelectableObject, HangarVehicle, Vehicle(6th), AreaDestructibles(7th)…'],
    ['索引公式', '索引 = space(0) + 声明序(1..40)', '0x05 真值完美吻合；defparse 按声明序加载'],
    ['NetworkEntity n=40', '载荷与 csi 表逐字段吻合（索引布局铁证）',
     'scale=1,1,1 / unique_id=UUID / prefab_path="37_bridge_destruction_01" / name="Collisions"'],
    ['0x3D 方向', '客户端→服务器 LogOnParams 上行（登录流四件套 t=24/45/48/61）',
     'clk=0 头部区单调相邻；服务器回放录制的是收到的上行包'],
    ['版本终局', '全部材料对齐 #942；#938→#942 仅 6 文件（precache/version/manifest/元数据）',
     '零 def 变更；#942→#949 的 152 M 全非 digest 输入；exe sha256 与 #942 manifest 一致'],
    ['版本时间线(北京)', '09-11 05:58 镜像#942 → 09-11 18:01 回放录制 → 09-18 03:23 镜像#949',
     '用户客户端一直 #942 未更新；「小版本」=#938→#942'],
    ['mod 干扰', '无改 entityDefs 的 mod → digest 输入=纯 pkg defs', '用户确认'],
]
add_sheet('v16方法ID与版本终局', ['项目', '结论', '证据/备注'], rows2, [20, 52, 70])

wb.save(DST)
print('已加 2 表, 共', len(wb.sheetnames), '表:', wb.sheetnames)
