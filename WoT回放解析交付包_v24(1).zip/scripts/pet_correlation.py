#!/usr/bin/env python3
"""pet_correlation.py — activePetID 与 0x39 包的跨场相关性验证

假设: 0x39 = 宠物/伴随物(pet)遥测流
验证: 11 场中, 0x39 出现场是否恰为"有玩家激活宠物"的场
扩展: 每场宠物数、宠物主车型、技能ID、与射手对位
"""
import json
import struct

REPLAYS = [
    ("siegfried_EU_39", "/tmp/wot/github_test/20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay"),
    ("karelia_EU_39", "/tmp/wot/github_test/20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay"),
    ("lakeville_EU_0", "/tmp/wot/github_test/20260907_1321_germany-G197_Pz_Kpfw_Neu_07_lakeville.wotreplay"),
    ("caucasus_NA_0", "/tmp/wot/github_test/20260910_1057_china-Ch67_BZ_79_37_caucasus.wotreplay"),
    ("namerica_CN_0", "/tmp/wot/github_test/20260911_1534_ussr-R52_Object_261_44_north_america.wotreplay"),
    ("tundra_CN_0", "/tmp/wot/github_test/20260911_1749_uk-GB156_Black_Prince_II_63_tundra.wotreplay"),
    ("caucasus_CN942_0", "/tmp/wot/github_test/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay"),
    ("greatwall_EU_0", "/tmp/wot/github_test/20260912_1036_france-F143_Fauteur_59_asia_great_wall.wotreplay"),
    ("karelia2_EU_39", "/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay"),
    ("PTZ_10K_EU_0", "/tmp/wot/github_test/PTZ_10K.wotreplay"),
    ("WZ219_EU_39", "/tmp/wot/github_test/WZ-219.wotreplay"),
]

N39 = {"siegfried_EU_39": 30, "karelia_EU_39": 5832, "lakeville_EU_0": 0,
       "caucasus_NA_0": 0, "namerica_CN_0": 0, "tundra_CN_0": 0,
       "caucasus_CN942_0": 0, "greatwall_EU_0": 0, "karelia2_EU_39": 4762,
       "PTZ_10K_EU_0": 0, "WZ219_EU_39": 6304}

SHOOTER_EID = {"karelia_EU_39": 8332904, "WZ219_EU_39": 543485522,
               "karelia2_EU_39": 539312076, "siegfried_EU_39": 550629014}


def get_b0(path):
    data = open(path, "rb").read()
    (magic, bc) = struct.unpack_from("<II", data, 0)
    pos = 8
    (blen,) = struct.unpack_from("<I", data, pos)
    return json.loads(data[pos + 4:pos + 4 + blen])


def main():
    print("%-18s %-6s %-7s %-38s %s" % ("replay", "0x39", "pets", "宠物主(车型|玩家|技能)", "射手一致?"))
    for tag, path in REPLAYS:
        b0 = get_b0(path)
        veh = b0.get("vehicles") or {}
        pets = []
        for dbid, v in veh.items():
            pid = v.get("activePetID", 0)
            if pid:
                pets.append((str(dbid), pid, v.get("vehicleType"), v.get("name"),
                             v.get("vehPostProgression")))
        n39 = N39[tag]
        shoot = SHOOTER_EID.get(tag)
        hit = ""
        if shoot is not None:
            owner = [p for p in pets if p[0] == shoot]
            hit = "✓ 宠物主=射手" if owner else "✗ 射手无宠物!"
        desc = "; ".join(f"{p[2]}|{p[3]}|pet={p[1]}|{p[4]}" for p in pets[:4])
        if len(pets) > 4:
            desc += f" (+{len(pets)-4})"
        print("%-18s %-6s %-7s %-38s %s" % (tag, n39, len(pets), desc[:80], hit))


if __name__ == "__main__":
    main()
