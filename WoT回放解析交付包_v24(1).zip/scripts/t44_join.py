#!/usr/bin/env python3
"""t44_join.py — Task 44 决定性实证: hierarchyInfo 字典提取 + 0x37 节点引用 join
新知识:
  0x32 流 = [u16 BE msgType(class<<8|sub)] + body + 后续 [u8 X][u8 b0][u8 class][u8 sub][body]...
  层级消息尾部 = [count][[u8 len][slotName][u32 networkID]]×count  (ARRAY<VEHICLE_HIERARCHY_INFO>)
  0x37 载荷 = 原始 blob(节点变换注记), 引用 networkID
步骤:
  A. 10 场随机战全部 0x32 → 提取 (eid, [(slotName, networkID)...])
  B. 0x37 首 u16 + 组内 u16 → 对撞 networkID 空间
  C. 0x32 完整消息语法走查(用 [X][b0][class][sub] 文法)
"""
import struct, sys, glob, json
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter, defaultdict

REPLAYS = sorted(glob.glob('/tmp/wot/github_test/*.wotreplay'))
tundra = [f for f in REPLAYS if 'tundra' in f][0]
RND = [f for f in REPLAYS if f != tundra]

def strings_in(b):
    out, i = [], 0
    while i < len(b) - 1:
        n = b[i]
        if 3 <= n <= 40 and i + 1 + n <= len(b):
            s = b[i+1:i+1+n]
            if all(32 <= x < 127 for x in s):
                out.append((i, s.decode())); i += 1 + n; continue
        i += 1
    return out

def parse_hierarchy_array(p, end):
    """从载荷尾部反向找 [count][len][name][u32 nid]... 数组; 返回 (count, items)"""
    # 尝试: 从末尾回退, 数组总长 = 1 + sum(1+len+4)
    # 更稳: 扫描所有位置, 尝试解析一个完整数组直到结尾
    for start in range(0, min(len(p), 400)):
        n = p[start]
        if not (3 <= n <= 12):
            continue
        pos = start + 1
        items = []
        ok = True
        for _ in range(n):
            if pos >= len(p):
                ok = False; break
            ln = p[pos]; pos += 1
            if not (2 <= ln <= 32) or pos + ln + 4 > len(p):
                ok = False; break
            name = p[pos:pos+ln].decode('utf-8', 'replace')
            pos += ln
            nid = struct.unpack_from('<I', p, pos)[0]
            pos += 4
            items.append((name, nid))
        if ok and pos == len(p) and items:
            return start, items
    return None, None

all_maps = {}       # eid -> list of (slot, nid)
file_stats = []
for f in RND:
    blocks, declared, slen, pkts = load(f)
    p32 = [(i, c, p) for i, (t, c, p) in enumerate(pkts) if t == 0x32]
    p37 = [(i, c, p) for i, (t, c, p) in enumerate(pkts) if t == 0x37]
    hier = 0
    nids = {}
    for i, c, p in p32:
        stream = p[4:]  # 去 recorder [u32 len]
        # eid = 流内 bytes 5..9 (msgType 2 + 00 01 01? — 先按观察: bytes[5:9])
        start, items = parse_hierarchy_array(stream, None)
        if items and any(s in ('hull', 'turret', 'gun', 'chassis') for s, _ in items):
            hier += 1
            eid = struct.unpack_from('<I', stream, 5)[0] if len(stream) >= 9 else 0
            all_maps.setdefault(eid, []).extend(items)
            for s, nid in items:
                nids.setdefault(nid, set()).add(s)
    # 0x37 首 u16 对撞
    hit = miss = 0
    missvals = Counter()
    for i, c, p in p37:
        if len(p) >= 6:
            u = struct.unpack_from('<H', p, 4)[0]
            if u in nids:
                hit += 1
            else:
                miss += 1
                missvals[u] += 1
    file_stats.append((f.split('/')[-1][:44], len(p32), hier, len(p37), hit, miss))
    print(f'{f.split("/")[-1][:44]:46s} 0x32={len(p32):5d} 层级={hier:4d} 0x37={len(p37):5d} join命中={hit:5d} 未中={miss:5d} 命中率={hit/(hit+miss)*100 if hit+miss else 0:.1f}%')

print('\n===== eid→槽位字典规模 =====')
print(f'唯一 eid 数: {len(all_maps)}')
slotcount = Counter()
for eid, items in all_maps.items():
    for s, _ in items:
        slotcount[s] += 1
print('槽位名频率 top15:', slotcount.most_common(15))

# networkID 全局分布
allnid = Counter()
for eid, items in all_maps.items():
    for _, nid in items:
        allnid[nid] += 1
print(f'\n唯一 networkID 数: {len(allnid)}, 值域: {min(allnid)}..{max(allnid)}')
print('networkID 频率 top10:', allnid.most_common(10))

# 保存映射
out = {'per_entity': {str(k): v for k, v in all_maps.items()},
       'nid_to_slots': {str(k): sorted(v) for k, v in nids.items()} if 'nids' in dir() else {}}
json.dump(out, open('/tmp/wot/t44_hierarchy_maps.json', 'w'), ensure_ascii=False, indent=1)
print('\n已存 /tmp/wot/t44_hierarchy_maps.json')
