#!/usr/bin/env python3
"""ext_probe.py — Task34 侦察: 0x05 CSI>=50 扩展区原始字节全 dump + csi 值域直方图
目的: 钉死扩展区条目格式 ([u8 csi][value]? 还是组件分组结构?)
"""
import json, struct, zlib
from collections import Counter, defaultdict
from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])

REPLAYS = [
    ("siegfried_EU_935", "/tmp/wot/github_test/20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay"),
    ("caucasus_CN_942", "/tmp/wot/github_test/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay"),
    ("karelia2_EU_944", "/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay"),
]

CSI = {}
d = json.load(open('/home/z/my-project/download/csi_tables_v8.json'))
for p in d['entities']['Vehicle']['properties']:
    CSI[p['csi']] = (p['name'], p['streamSize'])


def load_pkts(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from('<I', data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b'\x00' * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        dd = cipher.decrypt(main[i:i + 8])
        dd = bytes(a ^ b for a, b in zip(dd, prev))
        prev = dd
        out += dd
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from('<III', stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


def walk_base(pl):
    propBytes, = struct.unpack_from('<I', pl, 42)
    if 46 + propBytes != len(pl):
        return None, 'propBytes'
    q = 46
    count = pl[q]; q += 1
    ents = []
    for i in range(count):
        if q >= len(pl):
            return None, 'overrun'
        idx = pl[q]
        if idx >= 50:
            break
        q += 1
        if idx not in CSI:
            return None, f'badidx{idx}'
        name, ss = CSI[idx]
        if ss > 0:
            if q + ss > len(pl):
                return None, 'fxover'
            ents.append((idx, pl[q:q + ss].hex()))
            q += ss
        else:
            if q >= len(pl):
                return None, 'vlover'
            n = pl[q]
            if q + 1 + n > len(pl):
                return None, 'varover'
            ents.append((idx, pl[q + 1:q + 1 + n].hex()))
            q += 1 + n
    return (ents, q, count), None


def main():
    # 1) 全量 csi 直方图: 按 [u8 csi] 盲读扩展区首字节? 不可靠.
    #    先 dump 少量车完整扩展区, 人工分析格式.
    for tag, path in REPLAYS:
        pkts = load_pkts(path)
        veh = [pl for ty, c, pl in pkts if ty == 5 and len(pl) >= 47
               and struct.unpack_from('<I', pl, 4)[0] == 6]
        print(f'== {tag}: veh 0x05 = {len(veh)}')
        shown = 0
        for pl in veh:
            r, why = walk_base(pl)
            if r is None:
                continue
            ents, extoff, count = r
            ext = pl[extoff:]
            eid = struct.unpack_from('<I', pl, 0)[0]
            # 基础段条目数 vs count
            print(f'-- eid={eid} plen={len(pl)} count={count} base_n={len(ents)} extoff={extoff} extlen={len(ext)}')
            print(f'   base csis: {[i for i,_ in ents]}')
            print(f'   ext hex  : {ext.hex()}')
            shown += 1
            if shown >= 8:
                break
        print()

    # 2) 扩展区按固定步长假设扫描: 若 [u8 csi][1B val] 连续, csi 序列 = ext[0::2]
    #    对全场车做 ext[0], ext[2] 位置分布 -> 验证奇偶结构
    print('== csi 值直方图 (ext[0] 即首条目 csi) ==')
    hist = Counter()
    for tag, path in REPLAYS:
        pkts = load_pkts(path)
        veh = [pl for ty, c, pl in pkts if ty == 5 and len(pl) >= 47
               and struct.unpack_from('<I', pl, 4)[0] == 6]
        for pl in veh:
            r, why = walk_base(pl)
            if r is None:
                continue
            ents, extoff, count = r
            hist[pl[extoff]] += 1
    for k in sorted(hist):
        print(f'  csi={k:3d} (0x{k:02x}): {hist[k]}')


if __name__ == '__main__':
    main()
