#!/usr/bin/env python3
"""p05_idx_hist.py — Task35: 0x05 count 段 idx 直方图 (本车 vs AoI 分组)
模型修正器: 确定变长组 31-49 的真实布局
"""
import json, struct, sys
sys.path.insert(0, '/home/z/my-project/scripts')
from net05_table import REPLAYS, load_pkts, get_b0, walk_entity, NET05, R, WALK
from collections import Counter, defaultdict


def main():
    hist_all = Counter()
    hist_own = Counter()
    hist_aoi = Counter()
    for tag, path in REPLAYS:
        b0 = get_b0(path)
        # 录像玩家 = playerID 对应 avatarSessionID (roster 里找 dbid == playerID)
        pid = b0.get('playerID')
        own_sid = None
        for dbid, v in (b0.get('vehicles') or {}).items():
            if int(dbid) == pid:
                own_sid = v.get('avatarSessionID')
        pkts = load_pkts(path)
        veh = [pl for ty, c, pl in pkts if ty == 5 and len(pl) >= 47
               and struct.unpack_from('<I', pl, 4)[0] == 6]
        for pl in veh:
            eid = struct.unpack_from('<I', pl, 0)[0]
            props, stop, err = walk_entity(pl)
            if err:
                continue
            body = pl[46:]
            r = R(body, 1)
            idxs = []
            ok = True
            for i in range(body[0]):
                if r.q >= len(body):
                    ok = False
                    break
                idx = r.u8()
                idxs.append(idx)
                n, k = NET05.get(idx, (None, None))
                if n is None:
                    break
                try:
                    if k.startswith('fx'):
                        r.take(int(k[2:]))
                    elif k == 'my':
                        break  # MY 段起点: 记录后停
                    else:
                        WALK[k](r)
                except Exception:
                    ok = False
                    break
            for i in idxs:
                hist_all[i] += 1
                if eid == own_sid:
                    hist_own[i] += 1
                else:
                    hist_aoi[i] += 1
    print('idx | 总次数 | 本车 | AoI | 属性(模型a)')
    for i in sorted(hist_all):
        n, k = NET05.get(i, ('??', '??'))
        print(f'{i:3d} | {hist_all[i]:5d} | {hist_own[i]:4d} | {hist_aoi[i]:5d} | {n}')


if __name__ == '__main__':
    main()
