#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
p05_decoder.py — Task35 终局交付: WoT 0x05 创建块全量语义解码器 (11 场 × 全实体类型)

突破 (Task35):
  1. 0x05 网络 idx 表 = 「v8 定长组 0-30 + 变长组 RULE X」— Vehicle 1092/1092 精确吃满
     + roster 四重验证 (name(fake)/maxHealth/stFrags/team) + vpp 754/754
  2. publicInfo@32 铁证推翻 v8 变长序; dogTag@48 (BATTLE_DOG_TAG 双数组+show 字节结构)
  3. eid == roster.avatarSessionID (0x05 首字段即名册键)
  4. v18/v19 的「CSI>=50 扩展区/动态组件通道」= publicInfo 误走伪影 — 0x05 无组件段
  5. publicInfo.name = fakeName (WoT 匿名化机制)

输出: /tmp/wot/p05_decoded.json — 每实体一条 {tag, eid, typeID, pos, ypr, props}
"""
import json, struct, zlib, sys, os
from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])

REPLAYS = [
    ("siegfried_EU_935", "/tmp/wot/github_test/20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay"),
    ("karelia_EU_935", "/tmp/wot/github_test/20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay"),
    ("lakeville_EU_935", "/tmp/wot/github_test/20260907_1321_germany-G197_Pz_Kpfw_Neu_07_lakeville.wotreplay"),
    ("caucasus_NA_945", "/tmp/wot/github_test/20260910_1057_china-Ch67_BZ_79_37_caucasus.wotreplay"),
    ("namerica_CN_942", "/tmp/wot/github_test/20260911_1534_ussr-R52_Object_261_44_north_america.wotreplay"),
    ("caucasus_CN_942", "/tmp/wot/github_test/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay"),
    ("tundra_CN_942", "/tmp/wot/github_test/20260911_1749_uk-GB156_Black_Prince_II_63_tundra.wotreplay"),
    ("greatwall_EU_944", "/tmp/wot/github_test/20260912_1036_france-F143_Fauteur_59_asia_great_wall.wotreplay"),
    ("karelia2_EU_944", "/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay"),
    ("PTZ_EU_944", "/tmp/wot/github_test/PTZ_10K.wotreplay"),
    ("WZ219_EU_944", "/tmp/wot/github_test/WZ-219.wotreplay"),
]

# ============================ 线编码 walker ============================
class R:
    __slots__ = ('b', 'q')

    def __init__(self, b, q=0):
        self.b, self.q = b, q

    def u8(self):
        v = self.b[self.q]; self.q += 1; return v

    def take(self, n):
        v = self.b[self.q:self.q + n]; self.q += n; return v

    def pi(self):
        v = self.u8()
        if v == 0xFF:
            v = struct.unpack('<I', self.take(4))[0]
        return v


def w_str(r):
    n = r.pi()
    return r.take(n).decode('utf-8', 'replace')


def w_arr_i4(r):
    n = r.pi()
    return [struct.unpack('<i', r.take(4))[0] for _ in range(n)]


def w_arr_i1(r):
    n = r.pi()
    return list(r.take(n))


def w_tuple1(r):
    n = r.pi()
    return list(r.take(n))


def w_tuple3(r):
    n = r.pi()
    return [list(r.take(3)) for _ in range(n)]


def w_tuple5(r):
    n = r.pi()
    return [list(r.take(5)) for _ in range(n)]


def w_pub(r):
    return {
        'name': w_str(r), 'compDescr': r.take(r.pi()).hex(),
        'outfit': r.take(r.pi()).hex(), 'outfitLevel': r.u8(),
        'index': r.u8(), 'team': r.u8(),
        'prebattleID': struct.unpack('<i', r.take(4))[0],
        'marksOnGun': r.u8(),
        'crewGroups': [struct.unpack('<h', r.take(2))[0] for _ in range(r.pi())],
        'commanderSkinID': struct.unpack('<H', r.take(2))[0],
        'maxHealth': struct.unpack('<H', r.take(2))[0],
        'respawnID': struct.unpack('<I', r.take(4))[0],
        'stFrags': struct.unpack('<I', r.take(4))[0],
    }


def w_heal(r):
    if r.u8() == 0:
        return None
    return {'senderKey': w_str(r),
            'startTime': struct.unpack('<d', r.take(8))[0],
            'endTime': struct.unpack('<d', r.take(8))[0],
            'inactStart': struct.unpack('<d', r.take(8))[0],
            'inactEnd': struct.unpack('<d', r.take(8))[0]}


def w_hot(r):
    if r.u8() == 0:
        return None
    d = w_heal(r)
    d['isInfluenceZone'] = r.u8()
    return d


def _w_dogtag_comps(r):
    n = r.pi()
    return [{'id': struct.unpack('<i', r.take(4))[0],
             'progress': struct.unpack('<f', r.take(4))[0],
             'grade': r.u8()} for _ in range(n)]


def w_dogtag(r):
    return {'dogTag': _w_dogtag_comps(r), 'defaultDogTag': _w_dogtag_comps(r),
            'showDogTagToKiller': r.u8()}


def w_fdsticker(r):
    n = r.pi()
    return [{'networkID': struct.unpack('<i', r.take(4))[0],
             'segment': struct.unpack('<q', r.take(8))[0],
             'params': struct.unpack('<i', r.take(4))[0]} for _ in range(n)]


WALK = {'str': w_str, 'arr:i4': w_arr_i4, 'arr:i1': w_arr_i1, 'tuple1': w_tuple1,
        'tuple3': w_tuple3, 'tuple5': w_tuple5,
        'fd:pub': w_pub, 'fd:heal': w_heal, 'fd:hot': w_hot, 'fd:dogtag': w_dogtag,
        'arr:fdsticker': w_fdsticker}

# ============================ idx 表 ============================
# Vehicle: 定长组 = v8 (streamSize 升序稳定排序); 变长组 = RULE X (Task35 实测)
NET05_VEHICLE = {}
_v8 = json.load(open('/home/z/my-project/download/csi_tables_v8.json'))
for p in _v8['entities']['Vehicle']['properties']:
    if p['csi'] <= 30:
        NET05_VEHICLE[p['csi']] = (p['name'], f"fx{p['streamSize']}")
_VK = {
    'postmortemViewPointName': 'str', 'publicInfo': 'fd:pub',
    'damageStickers': 'arr:fdsticker', 'publicStateModifiers': 'arr:i1',
    'crewCompactDescrs': 'my', 'enhancements': 'my', 'setups': 'my',
    'setupsIndexes': 'my', 'vehPerks': 'my', 'vehPostProgression': 'arr:i4',
    'steeringAngles': 'tuple1', 'wheelsScroll': 'tuple1',
    'perkEffects': 'my', 'perks': 'my', 'disabledSwitches': 'my',
    'healing': 'fd:heal', 'healOverTime': 'fd:hot', 'dogTag': 'fd:dogtag',
    'perksRibbonNotify': 'my',
}
for i, n in enumerate(['postmortemViewPointName', 'publicInfo', 'damageStickers',
                       'publicStateModifiers', 'crewCompactDescrs', 'enhancements',
                       'setups', 'setupsIndexes', 'vehPerks', 'vehPostProgression']):
    NET05_VEHICLE[31 + i] = (n, _VK[n])
for i, n in enumerate(['steeringAngles', 'wheelsScroll', 'perkEffects', 'perks']):
    NET05_VEHICLE[41 + i] = (n, _VK[n])
for i, n in enumerate(['disabledSwitches', 'healing', 'healOverTime', 'dogTag',
                       'perksRibbonNotify']):
    NET05_VEHICLE[45 + i] = (n, _VK[n])

# 其他实体 (变长=文件声明序, 定长=尺寸排序 — 通用 vanilla 规则)
NET05_OTHER = {
    7: {0: ('destroyedModules', 'tuple3'), 1: ('destroyedFragiles', 'tuple3'),
        2: ('fallenColumns', 'tuple3'), 3: ('fallenTrees', 'tuple5')},  # AreaDestructibles
    40: {0: ('scale', 'fx12'), 1: ('unique_id', 'str'), 2: ('prefab_path', 'str'),
         3: ('name', 'str')},  # NetworkEntity (定长 scale@0, 变量=声明序)
    29: {0: ('avatarID', 'fx4')},  # AvatarInfo
    28: {0: ('teamID', 'fx4'), 1: ('unk1', 'str'), 2: ('unk2', 'str'),
         3: ('unk3', 'str')},  # 运行时 TeamInfo (fork 扩展, wot_scripts 副本缺 3 属性)
    12: {0: ('isUnderWater', 'fx1'), 1: ('isCollidingWithWorld', 'fx1'),
         2: ('vehicleID', 'fx4'), 3: ('vehicleCompDescr', 'str'),
         4: ('outfitCD', 'str')},  # DetachedTurret
    13: {0: ('drawObjects', 'str')},  # DebugDrawEntity (类型未细究)
}

TYPENAME = {6: 'Vehicle', 7: 'AreaDestructibles', 40: 'NetworkEntity', 29: 'AvatarInfo',
            28: 'TeamInfo', 12: 'DetachedTurret', 13: 'DebugDrawEntity', 3: 'ArenaInfo', 18: 'EmptyEntity'}


def load_pkts(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from('<I', data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b'\x00' * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        dd = cipher.decrypt(main[i:i + 8])
        dd = bytes(a ^ b for a, b in zip(dd, prev))
        prev = dd
        out += dd
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from('<III', stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


def get_b0(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos = 8
    (blen,) = struct.unpack_from('<I', data, pos)
    return json.loads(data[pos + 4:pos + 4 + blen])


def decode_entries(body, table, skip_my=True):
    """[u8 count][count × [u8 idx][typed value]] — 返回 (props, 消费位置, 错误)"""
    count = body[0]
    r = R(body, 1)
    props = {}
    for i in range(count):
        if r.q >= len(body):
            return props, r.q, f'overrun@{i}'
        idx = r.u8()
        ent = table.get(idx)
        if ent is None:
            r.q -= 1
            return props, r.q, None  # 未知 idx → 停
        name, kind = ent
        if kind == 'my':
            if skip_my:
                r.q -= 1
                return props, r.q, None
            props[name] = None
            continue
        try:
            if kind.startswith('fx'):
                props[name] = r.take(int(kind[2:])).hex()
            else:
                props[name] = WALK[kind](r)
        except Exception as e:
            return props, r.q, f'{name}:{e}@{i}'
    return props, r.q, None


def decode_05(pl):
    """完整 0x05 载荷解码"""
    eid, typeID = struct.unpack_from('<II', pl, 0)
    pos = struct.unpack_from('<3f', pl, 12)
    ypr = struct.unpack_from('<3f', pl, 24)
    propBytes, = struct.unpack_from('<I', pl, 42)
    body = pl[46:]
    out = {'eid': eid, 'typeID': typeID, 'typeName': TYPENAME.get(typeID, f'T{typeID}'),
           'pos': pos, 'ypr': ypr}
    if typeID == 6:
        props, stop, err = decode_entries(body, NET05_VEHICLE)
        out['props'] = props
        out['_err'] = err
        out['_exact'] = (stop == len(body))
    elif typeID in NET05_OTHER and NET05_OTHER[typeID]:
        props, stop, err = decode_entries(body, NET05_OTHER[typeID])
        out['props'] = props
        out['_err'] = err
        out['_exact'] = (stop == len(body))
    else:
        out['_raw'] = body.hex()
        out['_exact'] = None
    # roster join 字段 (仅 Vehicle)
    return out


def main():
    rows = []
    stats = {}
    for tag, path in REPLAYS:
        b0 = get_b0(path)
        roster = {}
        for dbid, v in (b0.get('vehicles') or {}).items():
            sid = v.get('avatarSessionID')
            if sid:
                roster[int(sid)] = v
        pkts = load_pkts(path)
        for ty, c, pl in pkts:
            if ty != 5 or len(pl) < 47:
                continue
            rec = decode_05(pl)
            rec['tag'] = tag
            rec['clk'] = c
            if rec['typeID'] == 6:
                ent = roster.get(rec['eid'])
                if ent:
                    rec['roster'] = {k: ent.get(k) for k in
                                     ('vehicleType', 'name', 'fakeName', 'team',
                                      'maxHealth', 'stFrags', 'vehPostProgression',
                                      'customRoleSlotTypeId', 'clanAbbrev')}
            s = stats.setdefault(rec['typeName'], {'n': 0, 'exact': 0, 'err': 0})
            s['n'] += 1
            if rec.get('_exact'):
                s['exact'] += 1
            if rec.get('_err'):
                s['err'] += 1
            rows.append(rec)
    print('== 0x05 全量解码统计 ==')
    for tn, s in sorted(stats.items(), key=lambda x: -x[1]['n']):
        print(f"  {tn:20s} n={s['n']:5d} 精确吃满={s['exact']:5d} 错误={s['err']}")
    out = '/tmp/wot/p05_decoded.json'
    json.dump(rows, open(out, 'w'), ensure_ascii=False)
    print(f'\n[saved] {out}  rows={len(rows)}')


if __name__ == '__main__':
    main()
