#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
t37_ext.py — Task 37 ⑥：0x05 扩展区条目解析 → dyncomp csi 布局
基础段 [u8 csi<50] 走 v20 规则；扩展区条目 [u8 csi>=50][typed value]。
目标：提取每车 ext 条目的 csi 序列，与 0x24 的 58/60/66/68 对位。
值类型未知 → 用「下一个条目起点扫描」：ext 区自洽切分需要类型表，
先用启发式: csi 字节后跟 [u8 len][data] 的 varlen 形态试切。
"""
import struct, sys, collections, json
sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import REPLAYS, load_pkts
from veh05_ext import walk_base

def try_ext_split(ext):
    """启发式: [csi][u8 len][data]* 形态切分，返回条目或 None"""
    q = 0
    ents = []
    while q < len(ext):
        csi = ext[q]; q += 1
        if csi < 50: return None
        if q >= len(ext): return None
        n = ext[q]; q += 1
        if q + n > len(ext): return None
        ents.append((csi, n, ext[q:q+n]))
        q += n
    return ents

rows = []
for TAG, RP in REPLAYS:
    pkts = load_pkts(RP)
    veh = [(c, pl) for ty, c, pl in pkts if ty == 5 and len(pl) >= 47
           and struct.unpack_from('<I', pl, 4)[0] == 6]
    for clk, pl in veh:
        r, why = walk_base(pl)
        if r is None: continue
        ents, extoff = r
        ext = pl[extoff:]
        sp = try_ext_split(ext)
        rows.append({'tag': TAG, 'eid': struct.unpack_from('<I', pl, 0)[0],
                     'extlen': len(ext), 'split': sp is not None,
                     'ents': [(c, n, v.hex()) for c, n, v in sp] if sp else None,
                     'raw': ext.hex()})

ok = [r for r in rows if r['split']]
print(f'启发式切分成功: {len(ok)}/{len(rows)}')
# ext csi 序列分布
seq = collections.Counter()
for r in ok:
    seq[tuple(c for c, n, v in r['ents'])] += 1
print('=== ext 条目 csi 序列 top15 ===')
for s, n in seq.most_common(15):
    print(f'  n={n:4d} ', s)
# 单 csi 分布
single = collections.Counter()
lens = collections.defaultdict(collections.Counter)
for r in ok:
    for c, n, v in r['ents']:
        single[c] += 1
        lens[c][n] += 1
print('=== 单 csi 分布 ===')
for c, n in sorted(single.items()):
    print(f'  csi={c:3d}: n={n:4d} len分布={dict(lens[c].most_common(4))}')
json.dump(rows, open('/tmp/wot/t37_ext.json', 'w'))
