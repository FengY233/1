#!/usr/bin/env python3
"""pack_v14.py — V14 交付包制作（基于 V13 结构）
新增: findings v18(§14) + worklog(883行) + data_v18/(6 JSON) + scripts +24件 + 审计 v14"""
import json, os, shutil, zipfile, hashlib

DL = '/home/z/my-project/download'
STAGE = '/tmp/wot/v14_stage/pack'
V13 = f'{DL}/WoT回放解析交付包_v13.zip'
OUT = f'{DL}/WoT回放解析交付包_v14.zip'

# 1. 从 V13 解包为基底
if os.path.exists(STAGE):
    shutil.rmtree(STAGE)
os.makedirs(STAGE)
with zipfile.ZipFile(V13) as z:
    z.extractall(STAGE)

# 2. 更新 findings / worklog
shutil.copy(f'{DL}/findings.md', f'{STAGE}/findings.md')
shutil.copy('/home/z/my-project/worklog.md', f'{STAGE}/worklog.md')

# 3. data_v18
d18 = f'{STAGE}/data_v18'
os.makedirs(d18, exist_ok=True)
DATA = [
    ('/tmp/wot/block0_full.json', '11场block0全字段_构建号归属.json'),
    ('/tmp/wot/roster_matrix.json', '314车名册矩阵_vpp技能.json'),
    ('/tmp/wot/veh05_ext.json', '0x05扩展区_动态组件通道_1092车.json'),
    ('/tmp/wot/veh05_join.json', '0x05载荷名册join.json'),
    ('/tmp/wot/veh_decl_table.json', 'Vehicle声明序全表_76属性.json'),
    ('/tmp/wot/p07_csi_scan.json', '11场0x07_csi键空间.json'),
    ('/tmp/wot/new_replay_survey.json', '11场回放普查.json'),
]
for src, name in DATA:
    if os.path.exists(src):
        shutil.copy(src, f'{d18}/{name}')
    else:
        print('MISS', src)

# 4. scripts 增量（V13 已有 15 件 → 补本轮 24 件）
SC = [
    'block0_full.py', 'roster_matrix.py', 'p07_align.py', 'p07_csi_scan.py',
    'p07_bodies.py', 'veh05_join.py', 'veh05_layout.py', 'veh05_props.py',
    'veh05_decl.py', 'veh05_ext.py',
    'tier11_skill_probe.py', 'p39_decode.py', 'p39_full_decode.py',
    'p39_roster.py', 'p39_roster2.py', 'p39_traj.py', 'p39_shooter.py',
    'p39_identify.py', 'pp_skill_roster.py', 'pet_correlation.py',
]
for s in SC:
    src = f'/home/z/my-project/scripts/{s}'
    if os.path.exists(src):
        shutil.copy(src, f'{STAGE}/scripts/{s}')
    else:
        print('MISS script', s)

# 5. 审计 v14
def count_lines(p):
    return sum(1 for _ in open(p, encoding='utf-8', errors='replace')) if os.path.exists(p) else 0

audit = {
    '版本': 'v14',
    '基准': 'V13 全量 + findings v18 + worklog Task33 + data_v18 + 20 脚本',
    'findings行数': count_lines(f'{STAGE}/findings.md'),
    'worklog行数': count_lines(f'{STAGE}/worklog.md'),
    '新增章节': '§14（14.1归属终局/14.2技能三分离/14.3 0x07格式/14.4 0x05格式/14.5 CSI≥50动态组件通道/14.6 0x39游戏对象流/14.7 vanilla参考/14.8工具）+ 附录J',
    'data_v18文件': [n for _, n in DATA if os.path.exists(os.path.join(d18, n))],
    'data_v17保留': True,
    '关键结论': [
        'digest = 2.4.0.0 世代跨构建(#935-#945)跨区域(EU/NA/CN)统一 EntityDescriptionMap 指纹（推翻 v17 #942 安装指纹定性）',
        'CN#942 实为 3 场（1534/1749/1801），外服 8 场 #935/#944/#945',
        '乘员技能=csi33/34/35(perks族, 0x07活跃) vs 车辆技能=csi44/45(vehPerks/vehPostProgression, 创建一次性)',
        'CSI≥50 扩展区 = 运行时挂载动态组件属性通道；有vpp车 extlen 中位117 vs 无vpp 93 (+25%)',
        '0x39 = NetworkReplicationPointComponent 游戏对象复制流（部署态宠物/随从）',
        '§11.5 数据同期性假设①②③全部排除；剩余偏差 100% 收敛于 dyncomp 解析细节',
    ],
}
json.dump(audit, open(f'{STAGE}/覆盖度终审_v14_audit.json', 'w'), ensure_ascii=False, indent=1)

# 6. README 更新版本行
rp = f'{STAGE}/README.md'
txt = open(rp, encoding='utf-8').read()
add = ('\n## v14（2026-09-25 · 技能体系分离 + 动态组件通道轮）\n'
       '- findings §14：回放归属终局（构建号全表，digest 定性修正为世代指纹）+ 技能三分离（乘员 csi34 vs 车辆 csi44/45）'
       '+ 0x07/0x05 格式钉死 + **CSI≥50 扩展区=动态组件属性通道**（1,092 车观测，+25% 技能字节签名）+ 0x39 游戏对象复制流 + vanilla 参考实现\n'
       '- data_v18/：7 份新数据（block0 全字段/名册矩阵/扩展区/join/声明序表/csi 键空间/普查）\n'
       '- scripts/ +20 件（本轮 10 + 会话 H 恢复 10）\n')
open(rp, 'w', encoding='utf-8').write(txt + add)

# 7. 打包
if os.path.exists(OUT):
    os.remove(OUT)
zf = zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED)
n = 0
for root, dirs, files in os.walk(STAGE):
    for f in sorted(files):
        p = os.path.join(root, f)
        arc = os.path.relpath(p, STAGE)
        zf.write(p, arc)
        n += 1
zf.close()
h = hashlib.md5(open(OUT, 'rb').read()).hexdigest()
print(f'V14: {n} 文件, {os.path.getsize(OUT)/1e6:.2f}MB, md5={h}')
