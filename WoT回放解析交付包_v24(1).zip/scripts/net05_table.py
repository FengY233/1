#!/usr/bin/env python3
"""net05_table.py — Task35: 0x05 网络表 (模型a) 构建 + 全量验证器
模型a: 固定组 0-30 = v8 排序(streamSize 升序, 同尺寸声明序)
       变长组 31-44 = 自有 def 变长属性(声明序) + 45-49 = Wheels/Perks 接口变长
验证: avatarID@16 join roster, publicInfo@32 字段对 roster (name/maxHealth/stFrags/team),
      health@14 == maxHealth, vpp@40 == vehPostProgression
"""
import json, struct, zlib, sys
from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])

REPLAYS = [
    ("siegfried_EU_935", "/tmp/wot/github_test/20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay"),
    ("karelia_EU_935", "/tmp/wot/github_test/20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay"),
    ("lakeville_EU_935", "/tmp/wot/github_test/20260907_1321_germany-G197_Pz_Kpfw_Neu_07_lakeville.wotreplay"),
    ("caucasus_NA_945", "/tmp/wot/github_test/20260910_1057_china-Ch67_BZ_79_37_caucasus.wotreplay"),
    ("namerica_CN_942", "/tmp/wot/github_test/20260911_1534_ussr-R52_Object_261_44_north_america.wotreplay"),
    ("caucasus_CN_942", "/tmp/wot/github_test/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay"),
    ("greatwall_EU_944", "/tmp/wot/github_test/20260912_1036_france-F143_Fauteur_59_asia_great_wall.wotreplay"),
    ("karelia2_EU_944", "/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay"),
    ("PTZ_EU_944", "/tmp/wot/github_test/PTZ_10K.wotreplay"),
    ("WZ219_EU_944", "/tmp/wot/github_test/WZ-219.wotreplay"),
]

# ---- 模型a 表: idx -> (name, kind)  kind: fx<N> | str | arr:<elemwalk> | fd:pub | fd:heal | tuple1 ----
NET05 = {}
_v8 = json.load(open('/home/z/my-project/download/csi_tables_v8.json'))
for p in _v8['entities']['Vehicle']['properties']:
    if p['csi'] <= 30:
        NET05[p['csi']] = (p['name'], f"fx{p['streamSize']}")
# 变长组 (RULE X: Task35 实测定案 — 1092/1092 精确吃满 + roster 四重验证)
# 31-40 = 自有 def 变长属性 1-10 (声明序); 41-44 = Wheels/Perks 接口变长;
# 45-48 = 自有变长 11-14; 49 = perksRibbonNotify (尾部机制待深究, 41-47/49 无观测差异)
_var_own = ['postmortemViewPointName', 'publicInfo', 'damageStickers', 'publicStateModifiers',
            'crewCompactDescrs', 'enhancements', 'setups', 'setupsIndexes', 'vehPerks',
            'vehPostProgression']
_var_mid = ['steeringAngles', 'wheelsScroll', 'perkEffects', 'perks']
_var_tail = ['disabledSwitches', 'healing', 'healOverTime', 'dogTag', 'perksRibbonNotify']
_kinds = {
    'postmortemViewPointName': 'str', 'publicInfo': 'fd:pub',
    'damageStickers': 'arr:fdsticker', 'publicStateModifiers': 'arr:i1',
    'crewCompactDescrs': 'my', 'enhancements': 'my', 'setups': 'my', 'setupsIndexes': 'my',
    'vehPerks': 'my', 'vehPostProgression': 'arr:i4', 'disabledSwitches': 'my',
    'healing': 'fd:heal', 'healOverTime': 'fd:hot', 'dogTag': 'fd:dogtag',
    'steeringAngles': 'tuple1', 'wheelsScroll': 'tuple1',
    'perkEffects': 'my', 'perks': 'my', 'perksRibbonNotify': 'my',
}
for i, n in enumerate(_var_own):
    NET05[31 + i] = (n, _kinds[n])
for i, n in enumerate(_var_mid):
    NET05[41 + i] = (n, _kinds[n])
for i, n in enumerate(_var_tail):
    NET05[45 + i] = (n, _kinds[n])

MY_IDX = {i for i, (n, k) in NET05.items() if k == 'my'}


def load_pkts(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from('<I', data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b'\x00' * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        dd = cipher.decrypt(main[i:i + 8])
        dd = bytes(a ^ b for a, b in zip(dd, prev))
        prev = dd
        out += dd
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from('<III', stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


def get_b0(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos = 8
    (blen,) = struct.unpack_from('<I', data, pos)
    return json.loads(data[pos + 4:pos + 4 + blen])


class R:
    """字节游标"""
    def __init__(self, b, q=0):
        self.b, self.q = b, q

    def u8(self):
        v = self.b[self.q]; self.q += 1; return v

    def take(self, n):
        v = self.b[self.q:self.q + n]; self.q += n; return v

    def pi(self):
        v = self.u8()
        if v == 0xFF:
            v = struct.unpack('<I', self.take(4))[0]
        return v


def w_str(r):
    n = r.pi()
    return r.take(n)


def w_arr_i4(r):
    n = r.pi()
    return [struct.unpack('<i', r.take(4))[0] for _ in range(n)]


def w_arr_i1(r):
    n = r.pi()
    return list(r.take(n))


def w_tuple1(r):
    n = r.pi()
    return list(r.take(n))


def w_pub(r):
    d = {}
    d['name'] = w_str(r)
    d['compDescr'] = w_str(r)
    d['outfit'] = w_str(r)
    d['outfitLevel'] = r.u8()
    d['index'] = r.u8()
    d['team'] = r.u8()
    d['prebattleID'] = struct.unpack('<i', r.take(4))[0]
    d['marksOnGun'] = r.u8()
    n = r.pi()
    d['crewGroups'] = [struct.unpack('<h', r.take(2))[0] for _ in range(n)]
    d['commanderSkinID'] = struct.unpack('<H', r.take(2))[0]
    d['maxHealth'] = struct.unpack('<H', r.take(2))[0]
    d['respawnID'] = struct.unpack('<I', r.take(4))[0]
    d['stFrags'] = struct.unpack('<I', r.take(4))[0]
    return d


def w_fd_none(r, nfloat):
    """allow_none FD: [u8 0=none / 1=val]"""
    flag = r.u8()
    if flag == 0:
        return None
    d = {'senderKey': w_str(r)}
    for fn in ('startTime', 'endTime', 'inactStart', 'inactEnd')[:nfloat]:
        d[fn] = struct.unpack('<d', r.take(8))[0]
    return d


def w_hot(r):
    flag = r.u8()
    if flag == 0:
        return None
    d = {'senderKey': w_str(r)}
    for fn in ('startTime', 'endTime', 'inactStart', 'inactEnd'):
        d[fn] = struct.unpack('<d', r.take(8))[0]
    d['isInfluenceZone'] = r.u8()
    return d


def w_dogtag(r):
    # BATTLE_DOG_TAG: {dogTag{components ARRAY<FD{id i4,prog f4,grade u8}>}},
    #                 defaultDogTag{...}, showDogTagToKiller u8}  (AllowNone?)
    d = {}
    for k in ('dogTag', 'defaultDogTag'):
        n = r.pi()
        comps = []
        for _ in range(n):
            comps.append({'id': struct.unpack('<i', r.take(4))[0],
                          'progress': struct.unpack('<f', r.take(4))[0],
                          'grade': r.u8()})
        d[k] = comps
    d['showDogTagToKiller'] = r.u8()
    return d


def w_arr_fdsticker(r):
    # damageStickers ARRAY<FD{networkID INT4, segment INT8, params INT4}> = 16B 元素
    n = r.pi()
    out = []
    for _ in range(n):
        out.append({'networkID': struct.unpack('<i', r.take(4))[0],
                    'segment': struct.unpack('<q', r.take(8))[0],
                    'params': struct.unpack('<i', r.take(4))[0]})
    return out


WALK = {
    'str': w_str, 'arr:i4': w_arr_i4, 'arr:i1': w_arr_i1, 'tuple1': w_tuple1,
    'fd:pub': w_pub, 'fd:heal': lambda r: w_fd_none(r, 4), 'fd:hot': w_hot,
    'fd:dogtag': w_dogtag, 'arr:fdsticker': w_arr_fdsticker,
}


def walk_entity(pl):
    """走实体段; 返回 (props dict, 停止位置, 错误)"""
    propBytes, = struct.unpack_from('<I', pl, 42)
    body = pl[46:]
    count = body[0]
    r = R(body, 1)
    props = {}
    for i in range(count):
        if r.q >= len(body):
            return props, r.q, f'overrun@{i}'
        idx = r.u8()
        if idx >= 50 or idx in MY_IDX:
            # 回退 1 字节: 组件区/MY 区起点
            r.q -= 1
            return props, r.q, None
        if idx not in NET05:
            return props, r.q, f'badidx{idx}@{i}'
        name, kind = NET05[idx]
        try:
            if kind.startswith('fx'):
                props[name] = r.take(int(kind[2:]))
            else:
                props[name] = WALK[kind](r)
        except Exception as e:
            return props, r.q, f'{name}:{e}@{i}'
    return props, r.q, None


def main():
    stats = {'total': 0, 'walk_ok': 0, 'join': 0, 'name_ok': 0, 'mh_ok': 0,
             'stf_ok': 0, 'team_ok': 0, 'vpp_ok': 0, 'health_ok': 0, 'stop_exact': 0}
    fails = {}
    samples = []
    for tag, path in REPLAYS:
        b0 = get_b0(path)
        roster = {}
        for dbid, v in (b0.get('vehicles') or {}).items():
            sid = v.get('avatarSessionID')
            if sid:
                roster[int(sid)] = v
        pkts = load_pkts(path)
        veh = [pl for ty, c, pl in pkts if ty == 5 and len(pl) >= 47
               and struct.unpack_from('<I', pl, 4)[0] == 6]
        for pl in veh:
            stats['total'] += 1
            props, stop, err = walk_entity(pl)
            if err:
                fails[err.split('@')[0]] = fails.get(err.split('@')[0], 0) + 1
                continue
            stats['walk_ok'] += 1
            # join: roster.avatarSessionID == Vehicle 实体 eid (0x05 首字段)
            eid = struct.unpack_from('<I', pl, 0)[0]
            ent = roster.get(eid)
            if ent:
                stats['join'] += 1
                pi = props.get('publicInfo')
                if pi:
                    # publicInfo.name = fakeName (匿名化机制; roster fakeName 缺省=name)
                    fake = ent.get('fakeName') or ent.get('name')
                    if pi.get('name', b'').decode('utf-8', 'replace') == fake:
                        stats['name_ok'] += 1
                    elif pi.get('name', b'').decode('utf-8', 'replace') == ent.get('name'):
                        stats['name_ok'] += 1
                        stats['name_real_fallback'] = stats.get('name_real_fallback', 0) + 1
                    if pi.get('maxHealth') == ent.get('maxHealth'):
                        stats['mh_ok'] += 1
                    if pi.get('stFrags') == ent.get('stFrags'):
                        stats['stf_ok'] += 1
                    if pi.get('team') == ent.get('team'):
                        stats['team_ok'] += 1
                    if len(samples) < 3:
                        samples.append((tag, pi.get('name'), pi.get('maxHealth'),
                                        ent.get('maxHealth'), pi.get('stFrags'), ent.get('stFrags')))
            # health@14 == maxHealth
            if 'health' in props and 'publicInfo' in props:
                if struct.unpack('<H', props['health'])[0] == props['publicInfo']['maxHealth']:
                    stats['health_ok'] += 1
            # vpp
            if 'vehPostProgression' in props:
                if props['vehPostProgression'] == (ent or {}).get('vehPostProgression'):
                    stats['vpp_ok'] += 1
            # 停止位置 == 组件区起点 (后面还有字节)
            propBytes, = struct.unpack_from('<I', pl, 42)
            if stop < 1 + propBytes:
                stats['stop_exact'] += 1
    print('== 模型a 全量验证 ==')
    for k, v in stats.items():
        print(f'  {k}: {v}')
    print('失败分布:', dict(sorted(fails.items(), key=lambda x: -x[1])[:8]))
    for s in samples:
        print('  样例:', s)


if __name__ == '__main__':
    main()
