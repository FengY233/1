#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
p24_probe.py — Task36①: 0x24 通道全量结构侦察（11 场）
已知线索(Task35 侦察): 键=(N<<8)|flag; N=17/18 时目标多为车辆, N=4/5/6/7 时全非车辆;
body 含 -1.0 哨兵与战斗时钟 f32 —— 组件属性候选通道。
本轮: 包数/大小分布 + 首包 hex dump + 键空间分布 + eid 关联验证
"""
import struct
import sys
from collections import Counter, defaultdict

sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import REPLAYS, load_pkts, get_b0  # noqa: E402


def veh_eids(path):
    b0 = get_b0(path)
    return {v.get('avatarSessionID') for v in (b0.get('vehicles') or {}).values()
            if v.get('avatarSessionID')}


def hexdump(b, n=64):
    rows = []
    for i in range(0, min(len(b), n), 16):
        chunk = b[i:i+16]
        hexs = ' '.join(f'{x:02x}' for x in chunk)
        asc = ''.join(chr(x) if 32 <= x < 127 else '.' for x in chunk)
        rows.append(f'    {i:04x}  {hexs:<48s}  {asc}')
    return '\n'.join(rows)


def main():
    # 跨场聚合
    key_space = Counter()          # (N<<8)|flag u16 首键
    n_distribution = Counter()     # 键高字节 N
    sizes = Counter()              # 包大小分桶
    n_pkts = 0
    first_dump = []
    eid_hits = Counter()           # body 前 4 字节 == 某车辆 eid?
    veh05_eids = set()             # 0x05 出现过的所有 eid（从解码缓存或重扫）
    # 收集每场 0x05 eid 集合
    per_replay = {}
    for tag, path in REPLAYS:
        pkts = load_pkts(path)
        p24 = [(c, pl) for ty, c, pl in pkts if ty == 0x24]
        p05_eids = {struct.unpack_from('<I', pl, 0)[0] for ty, c, pl in pkts
                    if ty == 5 and len(pl) >= 47}
        vehs = veh_eids(path)
        per_replay[tag] = {'n24': len(p24), 'n05': len(p05_eids), 'veh': len(vehs),
                           'veh_in_05': len(vehs & p05_eids)}
        n_pkts += len(p24)
        for c, pl in p24:
            sizes[min(len(pl) // 64, 8)] += 1
            if len(pl) >= 2:
                k = struct.unpack_from('<H', pl, 0)[0]
                key_space[k] += 1
                n_distribution[k >> 8] += 1
            # body 内 u32 扫描命中车辆 eid 的偏移统计（前 16 字节）
            for off in range(0, min(len(pl) - 3, 16)):
                v = struct.unpack_from('<I', pl, off)[0]
                if v in vehs:
                    eid_hits[off] += 1
                    break
        first_dump.extend(p24[:2])
    print('== 每场 0x24 概览 ==')
    for tag, st in per_replay.items():
        print(f"  {tag:18s} p24={st['n24']:5d}  p05实体={st['n05']:4d}  车辆名册={st['veh']}")
    print(f'\n总 p24 = {n_pkts}')
    print('\n== 包大小分布 (64B 分桶) ==')
    for b in sorted(sizes):
        print(f'  {"<64" if b==0 else (f"{b*64}-{(b+1)*64}" if b<8 else ">=512"):>10s} B: {sizes[b]}')
    print('\n== 键高字节 N 分布 (top20) ==')
    for n, c in n_distribution.most_common(20):
        print(f'  N={n:3d} (0x{n:02x}): {c:6d}')
    print('\n== 完整键 top30 (N<<8|flag) ==')
    for k, c in key_space.most_common(30):
        print(f'  0x{k:04x} (N={k>>8}, flag=0x{k&0xff:02x}): {c:6d}')
    print('\n== body 前16B 内车辆 eid 命中偏移 ==')
    for off, c in eid_hits.most_common(8):
        print(f'  off={off}: {c}')
    print('\n== 每场前 2 个 0x24 样本 ==')
    for i, (c, pl) in enumerate(first_dump[:6]):
        print(f'  [{i}] clk={c} len={len(pl)}')
        print(hexdump(pl, 80))


if __name__ == '__main__':
    main()
