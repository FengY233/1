#!/usr/bin/env python3
"""p39_traj.py — 0x39 对象全轨迹提取与运动学分析

对 4 个出现场提取 72B 子型的 6-float 载荷(位置3+方向3), 分析:
  - 轨迹形状(圆周? 巡逻? 定点?)
  - 速度剖面(加速? 恒定?)
  - 41B(0x25) 子型出现时刻 vs 72B 节奏
  - seq 起点与 battle 时长的关系
"""
import math
import struct
import zlib
from collections import Counter

from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])

SRC = {
    "karelia_EU": "/tmp/wot/github_test/20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay",
    "karelia2_EU": "/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay",
    "WZ219_EU": "/tmp/wot/github_test/WZ-219.wotreplay",
    "siegfried_EU": "/tmp/wot/github_test/20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay",
}


def load_pkts(path):
    data = open(path, "rb").read()
    (magic, bc) = struct.unpack_from("<II", data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from("<I", data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b"\x00" * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        d = cipher.decrypt(main[i:i + 8])
        d = bytes(a ^ b for a, b in zip(d, prev))
        prev = d
        out += d
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from("<III", stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


def main():
    for tag, path in SRC.items():
        pkts = load_pkts(path)
        p39 = [(clk, pl) for ty, clk, pl in pkts if ty == 0x39]
        p72 = [(c, p) for c, p in p39 if len(p) == 72]
        p41 = [(c, p) for c, p in p39 if len(p) == 41]
        print(f"\n########## {tag}: 72B={len(p72)} 41B={len(p41)} ##########")
        if not p72:
            continue
        # 全 clk 范围(全包)
        allclk = [c for ty, c, _ in pkts]
        print(f"全流 clk: {min(allclk)}..{max(allclk)}  0x39 clk: {p39[0][0]}..{p39[-1][0]}")
        # 轨迹统计
        pts = []
        for clk, pl in p72:
            x, y, z = struct.unpack_from("<fff", pl, 42)
            dx, dy, dz = struct.unpack_from("<fff", pl, 54)
            seqA, = struct.unpack_from("<I", pl, 15)
            pts.append((clk, seqA, x, y, z, dx, dy, dz))
        xs = [p[2] for p in pts]; ys = [p[3] for p in pts]; zs = [p[4] for p in pts]
        print(f"位置范围: x[{min(xs):.0f},{max(xs):.0f}] y[{min(ys):.1f},{max(ys):.1f}] z[{min(zs):.0f},{max(zs):.0f}]")
        # 方向模长分布
        mags = [math.sqrt(p[5] ** 2 + p[6] ** 2 + p[7] ** 2) for p in pts]
        print(f"方向模长: min={min(mags):.1f} max={max(mags):.1f} mean={sum(mags)/len(mags):.1f}")
        # y(高度)变化
        print(f"高度演变(每800包采样): {[f'{pts[i][3]:.1f}' for i in range(0, len(pts), max(1,len(pts)//10))]}")
        # 轨迹: 抽样打印前40个点
        step = max(1, len(pts) // 25)
        print("轨迹抽样 (clk, seq, x, y, z, |dir|):")
        for i in range(0, len(pts), step):
            c, s, x, y, z, dx, dy, dz = pts[i]
            m = math.sqrt(dx * dx + dy * dy + dz * dz)
            print(f"  clk={c} seq={s} ({x:8.1f},{y:6.1f},{z:8.1f}) |dir|={m:7.1f}")
        # 相邻包位移速度
        dists = []
        for a, b in zip(pts, pts[1:]):
            d = math.dist(a[2:5], b[2:5])
            dists.append(d)
        dists.sort()
        print(f"相邻包位移: p10={dists[len(dists)//10]:.2f} 中位={dists[len(dists)//2]:.2f} p90={dists[len(dists)*9//10]:.2f} max={dists[-1]:.2f}")
        # 41B 出现的 clk 相位
        if p41:
            c41 = [c for c, _ in p41]
            print(f"41B clk 区间: {min(c41)}..{max(c41)} (占 0x39 时段 {(max(c41)-min(c41))/(p39[-1][0]-p39[0][0])*100:.0f}%)")
        # 0x44 节奏: 相邻 clk 差分布
        difs = [b[0] - a[0] for a, b in zip(p72, p72[1:])]
        dc = Counter()
        for dd in difs:
            if dd <= 0:
                dc['<=0'] += 1
            elif dd < 3000:
                dc['<3k'] += 1
            elif dd < 30000:
                dc['3k-30k'] += 1
            elif dd < 60000:
                dc['30k-60k'] += 1
            else:
                dc['>60k'] += 1
        print("72B 相邻 clk 差分布:", dict(dc))


if __name__ == "__main__":
    main()
