#!/usr/bin/env python3
"""pack_v16.py — Task35: V16 交付包打包
内容: V15 全量 + data_v20/(net05 表 + p05 解码产物) + scripts +7件 + findings v20 + worklog Task35 + 审计
"""
import zipfile, os, hashlib, json, time

BASE = '/home/z/my-project'
STAGE = '/tmp/wot/v16_stage'
ZIP = os.path.join(STAGE, 'WoT回放解析交付包_v16.zip')

os.makedirs(STAGE, exist_ok=True)

files = {}   # arcname -> diskpath

# 1) scripts 全量 (排除 __pycache__)
sdir = os.path.join(BASE, 'scripts')
for f in sorted(os.listdir(sdir)):
    p = os.path.join(sdir, f)
    if f.endswith('.py') and os.path.isfile(p):
        files[f'scripts/{f}'] = p

# 2) findings + worklog
files['findings.md'] = os.path.join(BASE, 'upload/findings.md')
files['worklog.md'] = os.path.join(BASE, 'worklog.md')

# 3) data_v20/ — 本轮新产物
files['data_v20/0x05网络idx表_RULE_X_v20.json'] = '/tmp/wot/net05_table_v20.json'
files['data_v20/0x05全量解码_6899条_11场.json'] = '/tmp/wot/p05_decoded_compact.json'

# 4) data_v12~v19 目录 (沿用 V15 结构)
DL = os.path.join(BASE, 'download')
for sub in sorted(os.listdir(DL)):
    dpath = os.path.join(DL, sub)
    if os.path.isdir(dpath) and sub.startswith('data_v'):
        for f in sorted(os.listdir(dpath)):
            fp = os.path.join(dpath, f)
            if os.path.isfile(fp):
                files[f'{sub}/{f}'] = fp

# 5) V15 包内的其余顶层文件 (README/审计等)
v15zip = os.path.join(STAGE, '..', 'v15_stage', 'WoT回放解析交付包_v15.zip')
if not os.path.exists(v15zip):
    v15zip = '/tmp/wot/v15_stage/WoT回放解析交付包_v15.zip'
with zipfile.ZipFile(v15zip) as z:
    for info in z.infolist():
        an = info.filename
        if an.endswith('/'):
            continue
        if an.startswith('scripts/') or an in ('findings.md', 'worklog.md') or an.startswith('data_v20/'):
            continue
        if any(an.startswith(d + '/') for d in os.listdir(DL) if d.startswith('data_v')):
            continue
        if an in files:
            continue
        # 从 V15 提取
        tmp = os.path.join(STAGE, '_x_' + an.replace('/', '__'))
        z.extract(an, os.path.join(STAGE, '_x'))
        files[an] = os.path.join(STAGE, '_x', an)

# 6) 审计 v16
audit = {
    'version': 'v16', 'date': time.strftime('%Y-%m-%d %H:%M'),
    'task': 'Task 35: 0x05 全通道语义解码终局 (RULE X 网络表 + 推翻扩展区理论)',
    'headline': [
        'RULE X 网络 idx 表: 定长组=v8 + 变长组 31-49 重排 (publicInfo@32/vpp@40/dogTag@48 三锚全验证)',
        '推翻 v18 §14.5 扩展区理论: 0x05 无组件段, publicInfo 误走伪影',
        'eid==roster.avatarSessionID join 修正 (1092/1092)',
        'publicInfo.name==fakeName 匿名化机制 (1092/1092)',
        '全实体 11 场 6899/6899 字节级 100% 精确解码 (7 实体类型)',
        '运行时 def≠wot_scripts 副本铁证 (TeamInfo +3 属性) → digest 偏差归因需重估',
        'alias AllowNone digest 影响闭环: 无漏读',
    ],
    'verification': {
        'walk': '1124/1124', 'eid_join': '1092/1092', 'name_fake': '1092/1092',
        'maxHealth': '1092/1092', 'stFrags': '1092/1092', 'team': '1092/1092',
        'vpp': '754/754', 'exact_bytes': '6899/6899 (全部实体类型)',
    },
    'files': len(files),
}
ap = os.path.join(STAGE, 'audit_v16.json')
json.dump(audit, open(ap, 'w'), ensure_ascii=False, indent=1)
files['audit_v16.json'] = ap

# 打包 (writestr 直写, 避免 tmpfile 中转 bug)
with zipfile.ZipFile(ZIP, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for arc, disk in sorted(files.items()):
        z.writestr(arc, open(disk, 'rb').read())

md5 = hashlib.md5(open(ZIP, 'rb').read()).hexdigest()
sz = os.path.getsize(ZIP)
print(f'V16 打包完成: {ZIP}')
print(f'  文件数 {len(files)}, 大小 {sz/1048576:.2f}MB, md5={md5}')
json.dump({'zip': ZIP, 'files': len(files), 'size': sz, 'md5': md5},
          open(os.path.join(STAGE, 'pack_info.json'), 'w'))
