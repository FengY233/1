#!/usr/bin/env python3
"""t44_endpoints.py — 找 BWEndPoint 派生类 vtable
特征: vtable 槽位 +0x58/+0x60/+0x68/+0x70/+0x78 (slot11-15) 指向 CGF 解析区 0x140e40000-0x140e90000
     且前面有 RTTI COL 指针
"""
import pefile, struct

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()
secs = [(s.Name.decode().rstrip('\0'), imgbase+s.VirtualAddress, s.Misc_VirtualSize, s.PointerToRawData, s.SizeOfRawData) for s in pe.sections]

def va_to_off(va):
    for n, v, vs, raw, rs in secs:
        if v <= va < v + max(vs, rs):
            return raw + (va - v) if raw else None
    return None

def rq(va):
    o = va_to_off(va)
    return struct.unpack('<Q', data[o:o+8])[0] if o is not None else None

def rtti_name(col_va):
    o = va_to_off(col_va)
    if o is None: return None
    sig, off2, td = struct.unpack('<III', data[o:o+12])
    if sig != 1: return None
    tdo = va_to_off(td)
    if tdo is None: return None
    return data[tdo+16:tdo+16+140].split(b'\x00')[0].decode('utf-8','replace')

# 扫描 .rdata 中所有疑似 vtable: qword 指向 .text, 且 -8 处是 COL(sig=1)
rdata = [s for s in secs if s[0]=='.rdata'][0]
lo, hi = rdata[1], rdata[1]+rdata[2]
CGF_LO, CGF_HI = 0x140e40000, 0x140ea0000

cands = []
va = lo
end = min(hi, lo + 0xd21000)
while va < end - 8:
    col = rq(va)
    if col and lo <= col < hi:
        # 检查 sig
        o = va_to_off(col)
        if o and struct.unpack('<I', data[o:o+4])[0] == 1:
            # vtable 从 va+8 开始; 检查 slot11(+0x58) 是否指向 CGF 区
            s11 = rq(va + 8 + 0x58)
            if s11 and CGF_LO <= s11 < CGF_HI:
                name = rtti_name(col)
                cands.append((va+8, name))
    va += 8

print(f'候选端点类 vtable: {len(cands)}')
for vt, name in cands:
    print(f'\nvtable @{hex(vt)}  类名: {name}')
    for off, label in [(0x58,'slot11/class0'), (0x60,'slot12/class1'), (0x68,'slot13/class2'),
                       (0x70,'slot14/class3'), (0x78,'slot15/class4'), (0x50,'slot10'),
                       (0x80,'slot16'), (0x88,'slot17')]:
        v = rq(vt + off)
        print(f'  +{hex(off)} ({label}): {hex(v) if v else None}')
