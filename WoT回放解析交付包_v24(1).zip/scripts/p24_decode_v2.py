#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
p24_decode_v2.py — Task 37 终态：0x24 全通道精确解码器（推翻 v21 对齐体系）
════════════════════════════════════════════════════════════════════
模型（5,241/5,241 = 100% 验证，11 场零违例）：
  线格式: [eid u32][isSlice u8][len u32][body]
  body = 位路径(MSB-first) + 值:
    [1][csi: bitsRequired(numCS)]          ← 首层 = RULE X csi（CS 属性网络索引）
    循环 [1][idx: bitsRequirement(ownerN)]  ← 下钻（本次数据集全部无下钻）
    [0] 停止
    Single: [idx: bitsRequirement(arrlen)]          ← 替换第 idx 元素
    Slice:  [s: bitsRequirement(arrlen+1)][e: 同]   ← 替换 [s,e) 区间
    值 = 从下一整字节边界起（BitReader 整字节消费）
  ★ 位宽随数组当前长度漂移（增长→变宽）——v21 固定 6+6bit 假设被推翻
  ★ 0x05 重创建（AoI 重入）→ 数组状态重置为该次 0x05 初始值
通道真身（RULE X 映射 + 状态机验证）：
  Vehicle:     29=ownVehiclePosition(历史缓冲, 元素18B) 30=inspired(13B)
               33=damageStickers(16B) 34=publicStateModifiers(1B)
  AreaDestructibles: 0/1/2/3 = destroyedModules/destroyedFragiles/fallenColumns/fallenTrees
产出: /tmp/wot/p24_final_v2.json（全量 5,241 包精确解码）
"""
import struct, sys, json
sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import REPLAYS, load_pkts

def br(n):
    if n <= 1: return 0
    r = 0
    while (1 << r) < n: r += 1
    return r

class BitReader:
    def __init__(self, b): self.b = b; self.p = 0
    def get(self, n):
        v = 0
        for _ in range(n):
            v = (v << 1) | ((self.b[self.p >> 3] >> (7 - (self.p & 7))) & 1); self.p += 1
        return v
    def used(self): return (self.p + 7) >> 3

# ---- 元素解码器 ----
def dec_ownveh(el):
    """18B: [u8 hasValues][u16 A][u16 B][u8 C][f32 D][f64 E]"""
    if el[0] == 0: return None
    return {'A': struct.unpack_from('<H', el, 1)[0],
            'B': struct.unpack_from('<H', el, 3)[0],
            'C': el[5],
            'D': round(struct.unpack_from('<f', el, 6)[0], 4),
            'time': round(struct.unpack_from('<d', el, 10)[0], 3)}

def dec_insp(el):
    """13B: [u8 hasValues][u16 A][u16 B][f64 E]"""
    if el[0] == 0: return None
    return {'A': struct.unpack_from('<H', el, 1)[0],
            'B': struct.unpack_from('<H', el, 3)[0],
            'time': round(struct.unpack_from('<d', el, 5)[0], 3)}

def dec_sticker(el):
    """16B: {networkID u32, segment i64, params u32}"""
    return {'networkID': struct.unpack_from('<i', el, 0)[0],
            'segment': struct.unpack_from('<q', el, 4)[0],
            'params': struct.unpack_from('<i', el, 12)[0]}

def dec_u8(el):
    return el[0]

CHANNELS = {  # csi -> (name, elem_size, decoder)
    29: ('ownVehiclePosition', 18, dec_ownveh),
    30: ('inspired', 13, dec_insp),
    33: ('damageStickers', 16, dec_sticker),
    34: ('publicStateModifiers', 1, dec_u8),
}
AD_CHANNELS = {0: ('destroyedModules', 3), 1: ('destroyedFragiles', 3),
               2: ('fallenColumns', 3), 3: ('fallenTrees', 5)}

# 0x05 初始数组长度 (tag, eid, 序号) -> {ds, psm}
p05init = {}      # Vehicle: (ds, psm)
adinit = {}       # AreaDestructibles: (dM, dF, fC, fT)
d = json.load(open('/tmp/wot/p05_decoded.json'))
for r in d:
    p = r.get('props') or {}
    if r.get('typeName') == 'Vehicle':
        p05init.setdefault((r['tag'], r['eid']), []).append(
            (len(p.get('damageStickers') or []), len(p.get('publicStateModifiers') or [])))
    elif r.get('typeName') == 'AreaDestructibles':
        adinit.setdefault((r['tag'], r['eid']), []).append(
            (len(p.get('destroyedModules') or []), len(p.get('destroyedFragiles') or []),
             len(p.get('fallenColumns') or []), len(p.get('fallenTrees') or [])))

out = []
stats = {'ok': 0, 'bad': 0}
for TAG, RP in REPLAYS:
    pkts = load_pkts(RP)
    eid2ty = {}
    p05seq = {}
    for ty, clk, pl in pkts:
        if ty == 5 and len(pl) >= 8:
            e, n = struct.unpack_from('<II', pl, 0)
            eid2ty[e] = n
            if n in (6, 7):
                p05seq.setdefault(e, []).append(clk)
    state = {}
    for ty, clk, pl in pkts:
        if ty != 0x24: continue
        eid, isl, ln = struct.unpack_from('<IBI', pl, 0)
        body = pl[9:9+ln]
        if len(body) < 2: continue
        tyid = eid2ty.get(eid)
        nb_cs = {6: 50, 7: 4}.get(tyid)
        if nb_cs is None: continue
        b = BitReader(body)
        if b.get(1) != 1: continue
        csi = b.get(br(nb_cs))
        # 下钻（无）
        depth = 0; idxs = []
        while b.get(1) == 1:
            idxs.append(b.get(br(nb_cs))); depth += 1
            if depth > 3: break
        if depth > 0:
            stats['bad'] += 1
            continue
        # 状态键: (eid, 0x05代, csi)
        seq = p05seq.get(eid, [])
        gen = max(0, sum(1 for c in seq if c < clk) - 1)
        key = (eid, gen, csi)
        # 初始长度
        if key not in state:
            if tyid == 7:
                ai = adinit.get((TAG, eid), [(0, 0, 0, 0)])
                a = ai[min(gen, len(ai)-1)]
                state[key] = {0: a[0], 1: a[1], 2: a[2], 3: a[3]}.get(csi, 0)
            else:
                if csi == 33:
                    inits = p05init.get((TAG, eid), [(0, 0)])
                    state[key] = inits[min(gen, len(inits)-1)][0]
                elif csi == 34:
                    inits = p05init.get((TAG, eid), [(0, 0)])
                    state[key] = inits[min(gen, len(inits)-1)][1]
                else:
                    state[key] = 0
        n = state[key]
        dec = None
        if tyid == 7:
            name, E = AD_CHANNELS.get(csi, (None, None))
            if name is None: continue
        else:
            ch = CHANNELS.get(csi)
            if ch is None: continue
            name, E, dec = ch
        if isl:
            nb = br(n + 1)
            s, e = b.get(nb), b.get(nb)
            val = body[b.used():]
            ok = s <= e <= n and len(val) % E == 0
            if ok and dec is not None:
                elems = [dec(val[i:i+E]) for i in range(0, len(val), E)]
            elif ok:
                elems = [val[i:i+E].hex() for i in range(0, len(val), E)]
            else:
                elems = None
            if ok: state[key] = s + len(val)//E + (n - e)
            rec = {'op': 'slice', 'start': s, 'end': e, 'oldLen': n}
        else:
            nb = br(n)
            idx = b.get(nb)
            val = body[b.used():]
            ok = idx < n and len(val) == E
            if ok and dec is not None:
                elems = [dec(val)]
            elif ok:
                elems = [val.hex()]
            else:
                elems = None
            rec = {'op': 'set', 'idx': idx, 'oldLen': n}
        stats['ok' if ok else 'bad'] += 1
        out.append({'tag': TAG, 'clk': clk, 'eid': eid, 'type': 'Vehicle' if tyid == 6 else 'AreaDestructibles',
                    'csi': csi, 'name': name, **rec, 'ok': ok,
                    'elems': elems, 'rawVal': val.hex()})

json.dump(out, open('/tmp/wot/p24_final_v2.json', 'w'), ensure_ascii=False)
print('解码统计:', stats, '总包:', len(out))
print('已写 /tmp/wot/p24_final_v2.json')
