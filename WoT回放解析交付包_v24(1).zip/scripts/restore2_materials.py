# -*- coding: utf-8 -*-
"""restore2_materials.py — 第4次重置恢复 · 阶段2a：研究材料重建（快操作）
  1. /tmp/wot/github_test/  ← 11 场回放（backup_v11_restore/replays_11）
  2. /tmp/wot_scripts/      ← upload/scripts.7z（服务器 scripts + 273 def, #942）
  3. /tmp/my-project/repos/decomp ← upload/decomp.zip（Ghidra 转储）
  4. /tmp/my-project/repos/  ← wot_src.7z.001+002 合并解压（wotstat/wot-src #942）
  5. /tmp/wot/dec.7z        ← 分卷合并 + 密码验证 + 与 decomp.zip 内容对账（md5）
  6. /tmp/wotexe_x/         ← wotexe.7z（WorldOfTanks.exe）
BigWorld tar.gz 单独后台解压（restore2b）。
"""
import hashlib
import os
import shutil
import subprocess
import sys
import time
import zipfile

import py7zr

UP = '/home/z/my-project/upload'
B11 = f'{UP}/backup_v11_restore'
W = '/tmp/wot'
REPOS = '/tmp/my-project/repos'


def md5(path, bs=1 << 20):
    h = hashlib.md5()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(bs), b''):
            h.update(chunk)
    return h.hexdigest()


def step(n, msg):
    print(f'[{n}] {msg}', flush=True)


# 1. 11 场回放
os.makedirs(f'{W}/github_test', exist_ok=True)
for f in os.listdir(f'{B11}/replays_11'):
    shutil.copy2(f'{B11}/replays_11/{f}', f'{W}/github_test/{f}')
step(1, f'回放 {len(os.listdir(f"{W}/github_test"))} 场 → /tmp/wot/github_test/')

# 2. scripts.7z → /tmp/wot_scripts
os.makedirs('/tmp/wot_scripts', exist_ok=True)
t0 = time.time()
with py7zr.SevenZipFile(f'{UP}/scripts.7z') as z:
    z.extractall('/tmp/wot_scripts')
n = sum(len(fs) for _, _, fs in os.walk('/tmp/wot_scripts'))
step(2, f'scripts.7z 解压 {n} 文件 → /tmp/wot_scripts/ ({time.time()-t0:.1f}s)')
veh = '/tmp/wot_scripts/scripts/entity_defs/Vehicle.def'
print('    Vehicle.def 在位' if os.path.isfile(veh) else '    !! Vehicle.def 缺失')

# 3. decomp.zip → /tmp/my-project/repos/decomp
os.makedirs(REPOS, exist_ok=True)
t0 = time.time()
with zipfile.ZipFile(f'{UP}/decomp.zip') as z:
    z.extractall(f'{REPOS}/decomp')
n = sum(len(fs) for _, _, fs in os.walk(f'{REPOS}/decomp'))
step(3, f'decomp.zip 解压 {n} 文件 → {REPOS}/decomp ({time.time()-t0:.1f}s)')

# 4. wot_src 分卷合并解压
os.makedirs(REPOS, exist_ok=True)
merged = f'{REPOS}/wot_src_merged.7z'
if not os.path.isfile(merged):
    with open(merged, 'wb') as out:
        for part in (f'{UP}/wot_src.7z.001', f'{UP}/wot_src.7z.002'):
            with open(part, 'rb') as src:
                shutil.copyfileobj(src, out, 1 << 24)
t0 = time.time()
with py7zr.SevenZipFile(merged) as z:
    z.extractall(REPOS)
n = sum(len(fs) for _, _, fs in os.walk(REPOS) if 'decomp' not in _)
step(4, f'wot_src 解压完成 ({time.time()-t0:.1f}s)，repos 顶层:')
for d in sorted(os.listdir(REPOS)):
    print('   ', d)

# 5. dec.7z 分卷合并 + 密码验证 + 对账
os.makedirs(W, exist_ok=True)
dec = f'{W}/dec.7z'
with open(dec, 'wb') as out:
    for part in (f'{B11}/dec.7z.001', f'{B11}/dec.7z.002'):
        with open(part, 'rb') as src:
            shutil.copyfileobj(src, out, 1 << 24)
step(5, f'dec.7z 合并 {os.path.getsize(dec)/1048576:.1f}MB, md5={md5(dec)}')
try:
    with py7zr.SevenZipFile(dec, mode='r', password='114514.1919810') as z:
        names = z.getnames()
        info = z.archiveinfo()
        print(f'    密码 OK，{len(names)} 条目，解压后 {info.uncompressed/1048576:.0f}MB')
        # 与 decomp.zip 对账：比对条目数与抽样 md5
        dz = zipfile.ZipFile(f'{UP}/decomp.zip')
        dnames = [x for x in dz.namelist() if not x.endswith('/')]
        print(f'    decomp.zip 条目 {len(dnames)} vs dec.7z 条目 {len(names)}')
        sample = None
        for cand in ('README.md', 'index.tsv'):
            for nm in names:
                if nm.endswith(cand):
                    sample = nm
                    break
            if sample:
                break
        if sample:
            import tempfile
            with tempfile.TemporaryDirectory() as td:
                z.extract(targets=[sample], path=td)
                got = os.path.join(td, sample)
                dzname = None
                for dn in dnames:
                    if dn.endswith(sample.split('/')[-1]):
                        dzname = dn
                        break
                m7 = md5(got)
                if dzname:
                    import io
                    mzip = hashlib.md5(dz.read(dzname)).hexdigest()
                    print(f'    抽样 {sample}: dec.7z={m7} decomp.zip={mzip} '
                          f'{"一致" if m7 == mzip else "不一致"}')
except Exception as e:
    print(f'    !! dec.7z 打开失败: {type(e).__name__}: {e}')

# 6. wotexe.7z → /tmp/wotexe_x
os.makedirs('/tmp/wotexe_x', exist_ok=True)
t0 = time.time()
with py7zr.SevenZipFile(f'{B11}/wotexe.7z') as z:
    z.extractall('/tmp/wotexe_x')
exe = '/tmp/wotexe_x/WorldOfTanks.exe'
if os.path.isfile(exe):
    print(f'[{6}] wotexe.7z → {exe} {os.path.getsize(exe)/1048576:.1f}MB '
          f'md5={md5(exe)} ({time.time()-t0:.1f}s)')
else:
    print(f'[{6}] /tmp/wotexe_x/ 内容: {os.listdir("/tmp/wotexe_x")}')

# 磁盘
df = subprocess.run(['df', '-h', '/'], capture_output=True, text=True).stdout
print('--- 磁盘 ---')
print(df.strip().splitlines()[-1])
print('阶段2a 完成')
