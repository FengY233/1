#!/usr/bin/env python3
"""veh05_ext.py — 0x05 创建块 CSI>=50 扩展区(动态组件通道)统计分析
基础段走通后, 剩余字节 = 组件属性区; 按 (车型, vpp有无) 分组:
  - 扩展区长度分布
  - 扩展区首字节(idx 序列)签名
与 roster join → 十一级车技能组件 vs 普通车的组件挂载差异"""
import json, struct, zlib
from collections import Counter, defaultdict
from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])

REPLAYS = [
    ("siegfried_EU_935", "/tmp/wot/github_test/20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay"),
    ("karelia_EU_935", "/tmp/wot/github_test/20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay"),
    ("lakeville_EU_935", "/tmp/wot/github_test/20260907_1321_germany-G197_Pz_Kpfw_Neu_07_lakeville.wotreplay"),
    ("caucasus_NA_945", "/tmp/wot/github_test/20260910_1057_china-Ch67_BZ_79_37_caucasus.wotreplay"),
    ("namerica_CN_942", "/tmp/wot/github_test/20260911_1534_ussr-R52_Object_261_44_north_america.wotreplay"),
    ("caucasus_CN_942", "/tmp/wot/github_test/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay"),
    ("greatwall_EU_944", "/tmp/wot/github_test/20260912_1036_france-F143_Fauteur_59_asia_great_wall.wotreplay"),
    ("karelia2_EU_944", "/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay"),
    ("PTZ_EU_944", "/tmp/wot/github_test/PTZ_10K.wotreplay"),
    ("WZ219_EU_944", "/tmp/wot/github_test/WZ-219.wotreplay"),
]

CSI = {}
d = json.load(open('/home/z/my-project/download/csi_tables_v8.json'))
for p in d['entities']['Vehicle']['properties']:
    CSI[p['csi']] = (p['name'], p['streamSize'])


def load_pkts(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from('<I', data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b'\x00' * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        dd = cipher.decrypt(main[i:i + 8])
        dd = bytes(a ^ b for a, b in zip(dd, prev))
        prev = dd
        out += dd
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from('<III', stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


def get_b0(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos = 8
    (blen,) = struct.unpack_from('<I', data, pos)
    return json.loads(data[pos + 4:pos + 4 + blen])


def walk_base(pl):
    """走基础段; 返回 (base_entries, ext_offset) 或 (None, fail_reason)
    遇 idx>=50 即停(扩展区起点); 基础段内变长属性按 [u8 len][data]"""
    propBytes, = struct.unpack_from('<I', pl, 42)
    if 46 + propBytes != len(pl):
        return None, 'propBytes'
    q = 46
    count = pl[q]; q += 1
    ents = []
    for i in range(count):
        if q >= len(pl):
            return None, 'overrun'
        idx = pl[q]
        if idx >= 50:
            break
        q += 1
        if idx not in CSI:
            return None, f'badidx{idx}'
        name, ss = CSI[idx]
        if ss > 0:
            if q + ss > len(pl):
                return None, 'fxover'
            ents.append((idx, pl[q:q + ss].hex()))
            q += ss
        else:
            if q >= len(pl):
                return None, 'vlover'
            n = pl[q]
            if q + 1 + n > len(pl):
                return None, 'varover'
            ents.append((idx, pl[q + 1:q + 1 + n].hex()))
            q += 1 + n
    return (ents, q), None


def main():
    rows = []
    for tag, path in REPLAYS:
        b0 = get_b0(path)
        roster = {}
        for dbid, v in (b0.get('vehicles') or {}).items():
            sid = v.get('avatarSessionID')
            if sid:
                roster[int(sid)] = v
        pkts = load_pkts(path)
        veh = [pl for ty, c, pl in pkts if ty == 5 and len(pl) >= 47
               and struct.unpack_from('<I', pl, 4)[0] == 6]
        nok = 0
        for pl in veh:
            r, why = walk_base(pl)
            if r is None:
                continue
            ents, extoff = r
            # roster join (avatarID 出现在载荷中)
            hits = [aid for aid in roster if struct.pack('<I', aid) in pl]
            ent = roster[hits[0]] if len(hits) >= 1 else {}
            extlen = len(pl) - extoff
            # 扩展区索引签名: 基础段后的 [u8 idx] 序列粗取
            rows.append({
                'tag': tag, 'eid': struct.unpack_from('<I', pl, 0)[0],
                'vtype': ent.get('vehicleType'), 'vpp': ent.get('vehPostProgression'),
                'pet': ent.get('activePetID'),
                'plen': len(pl), 'extoff': extoff, 'extlen': extlen,
                'ext_head': pl[extoff:extoff + 24].hex(),
                'base_ents': [(i, v) for i, v in ents],
            })
            nok += 1
        print(f'{tag}: walk ok {nok}/{len(veh)}')

    # 按 (车型, vpp有无) 聚合
    grp = defaultdict(list)
    for r in rows:
        vt = r['vtype'] or '?'
        hasvpp = '有vpp' if r['vpp'] else '无vpp'
        grp[(vt, hasvpp)].append(r)
    print(f'\n== 车型 × vpp × 扩展区长度 ==')
    for (vt, hv), rs in sorted(grp.items(), key=lambda kv: -len(kv[1])):
        extlens = [r['extlen'] for r in rs]
        print(f'  {vt:36s} {hv}  n={len(rs):2d}  extlen: '
              f'min={min(extlens)} 中位={sorted(extlens)[len(extlens)//2]} max={max(extlens)}')
    json.dump(rows, open('/tmp/wot/veh05_ext.json', 'w'), ensure_ascii=False)
    print(f'\n[saved] /tmp/wot/veh05_ext.json  rows={len(rows)}')


if __name__ == '__main__':
    main()
