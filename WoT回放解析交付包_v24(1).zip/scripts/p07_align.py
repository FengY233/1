#!/usr/bin/env python3
"""p07_align.py — CN942 场: jsonl 0x07 记录 ↔ 原始包对齐 → 推导 0x07 原始编码
之后即可对外服回放做 0x07 全量 csi 解码（组件通道分析的前置）。"""
import json, struct, zlib
from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])
RP = '/tmp/wot/github_test/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay'


def load_pkts(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from('<I', data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b'\x00' * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        d = cipher.decrypt(main[i:i + 8])
        d = bytes(a ^ b for a, b in zip(d, prev))
        prev = d
        out += d
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from('<III', stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


def main():
    pkts = load_pkts(RP)
    # jsonl 0x07 记录
    recs = []
    for line in open('/tmp/wot/rjsonl/replay.jsonl', encoding='utf-8'):
        try:
            r = json.loads(line)
        except Exception:
            continue
        if r.get('t') == 7:
            recs.append(r)
    print('jsonl 0x07 记录数:', len(recs))
    # clk → raw 7 索引
    raw7 = {}
    for ty, clk, pl in pkts:
        if ty == 7:
            raw7.setdefault(clk, []).append(pl)
    hit = miss = 0
    shown = 0
    for r in recs:
        cands = raw7.get(r['clk'])
        if not cands:
            miss += 1
            continue
        body = bytes.fromhex(r['body'])
        eid, key = r['eid'], r['key']
        for pl in cands:
            if len(pl) >= 8 and struct.unpack_from('<I', pl, 0)[0] == eid:
                # 尝试定位 body 在载荷中的偏移
                off = pl.find(body)
                ok = off >= 0
                hit += 1
                if shown < 12 and ok:
                    print(f"clk={r['clk']} eid={eid} key={key} blen={len(body)} "
                          f"pl[{len(pl)}]={pl.hex()} body@{off}")
                    shown += 1
                break
        else:
            miss += 1
    print(f'\nclk+eid 命中 {hit} / 未命中 {miss}')

    # 专门验证: key 与 body 的偏移规律
    print('\n== 规律验证(前 30 条命中) ==')
    n = 0
    for r in recs[:4000]:
        cands = raw7.get(r['clk'])
        if not cands:
            continue
        body = bytes.fromhex(r['body'])
        eid, key = r['eid'], r['key']
        for pl in cands:
            if len(pl) >= 8 and struct.unpack_from('<I', pl, 0)[0] == eid:
                off = pl.find(body)
                if off < 0:
                    print(f'  ✗ body 不在载荷内: key={key} body={r["body"]} pl={pl.hex()}')
                    n += 1
                else:
                    # key 编码检查: pl[4:off) 应编码 key
                    seg = pl[4:off]
                    enc = None
                    if len(seg) == 1:
                        enc = ('u8', seg[0]) if seg[0] == key else None
                    if len(seg) == 2:
                        v = struct.unpack('<H', seg)[0]
                        enc = ('u16', v) if v == key else None
                    if len(seg) == 4:
                        v = struct.unpack('<I', seg)[0]
                        enc = ('u32', v) if v == key else None
                    if n < 30:
                        print(f'  key={key:3d} blen={len(body):2d} seg={seg.hex()} enc={enc}')
                    n += 1
                break
        if n > 40:
            break


if __name__ == '__main__':
    main()
