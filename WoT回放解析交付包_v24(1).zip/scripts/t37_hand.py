#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
t39_hand.py — Task 37 ③：csi=29/30/33/34 包位级手工解码（不信任 p24_final 的值提取）
0x24 线格式: [eid u32][isSlice u8][len u32][body]
body = 位流路径 + 值。位流(MSB-first):
  [1][csi: bitsRequired(50)=6]
  循环 [1][idx: bitsRequired(ownerN)]（本次观测全为 [0] 直接停）
  Single:  [leafIdx: bitsRequired(leafOwnerN)]
  Slice:   [start: bitsRequired(leafOwnerN+1)][end: 同]
值从下一整字节边界开始。
关键问题: leafOwnerN 到底是多少 → 决定值起点。枚举 ownerN∈{2..8} 看哪种自洽。
"""
import struct, sys, zlib, json, os, collections

REPLAY = '/tmp/wot/github_test/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay'  # CN942 基准场

def load_05_packets(path):
    raw = open(path, 'rb').read()
    # block 结构: 找 0x05 块
    i = raw.find(b'\n\n')
    jsonlen = int.from_bytes(raw[:4], 'little')
    body = raw[4+jsonlen+2:]
    # 解析块
    off = 0
    blocks = []
    while off < len(body):
        bid = body[off]
        blen = int.from_bytes(body[off+1:off+5], 'little')
        blocks.append((bid, body[off+5:off+5+blen]))
        off += 5 + blen
    return blocks

def parse_05(b05):
    """0x05 块: pickle + 包流。直接扫描包流部分。
    已知格式（前期已破译）: 前部 pickle 段 + [u32 count][包...] —— 用既有锚: 扫 [eid][t][len]"""
    return b05

blocks = load_05_packets(REPLAY)
print('块清单:', [(b[0], len(b[1])) for b in blocks])
b05 = [b[1] for b in blocks if b[0] == 5][0]
print('0x05 长度:', len(b05))

# p24 系列脚本已有包提取器，借用 p24_probe 的扫描方式
# 包流在 0x05 内部: pickle 结束后 [u32 nPackets] 然后逐包 [clk u32][size u32][msgId u8][payload]
# 先定位包流起点: 已知 0x24 包特征 [eid u32][isSlice u8][len u32] 且 len 恰好吃满
# 用既有脚本逻辑: 从 p24_probe.py 拷贝
sys.path.insert(0, '/home/z/my-project/scripts')
# 找 p24_probe 的函数
src = open('/home/z/my-project/scripts/p24_probe.py').read()
print('--- p24_probe 头 60 行 ---')
print('\n'.join(src.split('\n')[:60]))
