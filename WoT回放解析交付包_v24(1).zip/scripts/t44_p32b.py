#!/usr/bin/env python3
"""t44_p32b.py — 对照 20260911_1801 (v5 原分析场) 的 0x32/0x37 结构
目标: 识别 [u16 组件标签] 家族 + 帧 grammar
"""
import struct, sys
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter

F = '/tmp/wot/github_test/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay'
blocks, declared, slen, pkts = load(F)
p32 = [(i, c, p) for i, (t, c, p) in enumerate(pkts) if t == 0x32]
p37 = [(i, c, p) for i, (t, c, p) in enumerate(pkts) if t == 0x37]
print(f'0x32: {len(p32)}  0x37: {len(p37)}')

def strings_in(b):
    out, i = [], 0
    while i < len(b) - 1:
        n = b[i]
        if 3 <= n <= 40 and i + 1 + n <= len(b):
            s = b[i+1:i+1+n]
            if all(32 <= x < 127 for x in s):
                out.append((i, s.decode())); i += 1 + n; continue
        i += 1
    return out

# 0x32 按 [u16 tag@4:6] 分族统计 (跳过 recorder [u32 len])
fam = Counter()
famex = {}
for i, c, p in p32:
    if len(p) >= 8:
        tag = struct.unpack_from('<H', p, 4)[0]
        fam[tag] += 1
        if tag not in famex:
            famex[tag] = (i, p)
print('\n0x32 tag@4:6 分布:', [(hex(t), n) for t, n in fam.most_common(20)])

print('\n===== 各族首例 =====')
for tag, n in fam.most_common(8):
    i, p = famex[tag]
    ss = strings_in(p)
    print(f'\n-- tag={hex(tag)} ×{n}  pkt#{i} len={len(p)}')
    print('  ', p[:min(72, len(p))].hex(' '))
    if ss:
        print('   strs:', [s for _, s in ss][:6])

# 13B 短消息的 tag
short = Counter()
for i, c, p in p32:
    if len(p) == 13:
        short[struct.unpack_from('<H', p, 4)[0]] += 1
print('\n13B 短消息 tag 分布:', [(hex(t), n) for t, n in short.most_common(10)])

# 0x37 结构: [u32 len] 后的首 u16
f37 = Counter()
for i, c, p in p37:
    if len(p) >= 8:
        f37[struct.unpack_from('<H', p, 4)[0]] += 1
print('\n0x37 首 u16 分布:', [(hex(t), n) for t, n in f37.most_common(12)])

# 0x37 长度分布
l37 = Counter(len(p) for _, _, p in p37)
print('0x37 长度分布:', sorted(l37.items())[:15])

# 0x37 首批样本(不同长度)
print('\n===== 0x37 样本(按长度多样) =====')
seen = set()
for i, c, p in p37:
    key = min(len(p), 80)
    if key in seen: continue
    seen.add(key)
    print(f'pkt#{i} len={len(p)}: {p[:64].hex(" ")}')
    if len(seen) >= 10: break
