#!/usr/bin/env python3
"""verify_v19.py — Task34 综合验证: 全部新结论的量化固化
1. MY_VEHICLE 属性清单 (服务器 def DetailLevel)
2. vpp idx=40 铁证复验
3. alias AllowNone 清单 (defparse 漏读)
4. 组件 CS 属性统计
5. 尾部骨架覆盖率
6. NetworkEntity 格式验证
"""
import json, struct, sys, os
sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file
from collections import Counter

print('=' * 70)
print('1) Vehicle.def DetailLevel 分组')
root = decode_file('/tmp/wot_scripts/scripts/entity_defs/Vehicle.def')
props = [c for c in root.children if c.name == 'Properties'][0]
lod = {}
for c in props.children:
    dl = ''
    for cc in c.children:
        if cc.name == 'DetailLevel':
            dl = cc.asString()
    lod.setdefault(dl or '(default)', []).append(c.name)
for k, v in lod.items():
    print(f'  DetailLevel={k}: {len(v)} 属性')
    if k != '(default)':
        print(f'    -> {v}')

print()
print('2) vpp idx=40 复验 (1092 车)')
rows = json.load(open('/tmp/wot/ext_cluster.json'))
hit = miss = 0
for r in rows:
    vpp = r.get('vpp') or []
    if not vpp:
        continue
    pat = struct.pack('<B', len(vpp)) + b''.join(struct.pack('<i', x) for x in vpp)
    i = bytes.fromhex(r['ext']).find(pat)
    if i >= 1 and bytes.fromhex(r['ext'])[i - 1] == 40:
        hit += 1
    else:
        miss += 1
print(f'  idx=40 命中 {hit} / 偏差 {miss}')

print()
print('3) alias.xml AllowNone 清单 (实体 def 常用 alias)')
ar = decode_file('/tmp/wot_scripts/scripts/entity_defs/alias.xml')
n_an = 0
an_list = []
for c in ar.children:
    has = any(x.name == 'AllowNone' for x in c.children)
    if has:
        n_an += 1
        an_list.append(c.name)
print(f'  AllowNone alias 数: {n_an} / 总 alias: {len(ar.children)}')
print(f'  样例: {an_list[:15]}')

print()
print('4) 组件 CS 属性统计')
CDIR = '/tmp/wot_scripts/scripts/component_defs'
CS = {'ALL_CLIENTS', 'OWN_CLIENTS'}
tot = 0
ncomp = 0
cr = decode_file('/tmp/wot_scripts/scripts/components.xml')
for grp in cr.children:
    for comp in grp.children:
        p = os.path.join(CDIR, comp.name + '.def')
        if not os.path.exists(p):
            continue
        sec = decode_file(p)
        ps = [c for c in sec.children if c.name == 'Properties']
        if not ps:
            continue
        n = 0
        for c in ps[0].children:
            for cc in c.children:
                if cc.name == 'Flags' and cc.asString() in CS:
                    n += 1
                    break
        if n:
            ncomp += 1
            tot += n
print(f'  有 CS 属性的组件: {ncomp}, CS 属性总数: {tot}')

print()
print('5) 尾部骨架覆盖率 (1092 车)')
c21 = sum(1 for r in rows if '2100' in r['ext'])
c22 = sum(1 for r in rows if '2200' in r['ext'])
c2f = sum(1 for r in rows if '2f00' in r['ext'])
c30 = sum(1 for r in rows if '3002' in r['ext'])
c2c = sum(1 for r in rows if '2c01' in r['ext'])
c09 = sum(1 for r in rows if '0942' in r['ext'] or '0948' in r['ext'])
print(f'  21 00 (perkEff 空): {c21}')
print(f'  22 00 (perks 空): {c22}')
print(f'  2f 00 (idx47 空): {c2f}')
print(f'  30 02 (idx48=02): {c30}')
print(f'  2c 01 (idx44): {c2c}')
print(f'  09 42/48: {c09}')

print()
print('6) 同型车模板恒定性 (扩展区全同比例)')
from collections import defaultdict
bt = defaultdict(set)
for r in rows:
    bt[(r['tag'], r['vtype'])].add(r['ext'])
same = sum(1 for k, v in bt.items() if len(v) == 1)
tot_g = len(bt)
print(f'  同场次同车型组: {tot_g}, 扩展区全同: {same} ({same * 100 // tot_g}%)')
