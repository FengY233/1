#!/usr/bin/env python3
"""p07_csi_scan.py — 11场 0x07 全量解码 → 每实体类 csi 键直方图
目的: 找超出实体自身属性空间的 key = 动态组件属性通道 (dyncomp 真值锚)
0x07 格式(本轮钉死): [u32 eid]([u32 key][u32 blen][body])×N
"""
import json, struct, zlib
from collections import Counter, defaultdict
from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])

REPLAYS = [
    ("siegfried_EU", "/tmp/wot/github_test/20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay"),
    ("karelia_EU", "/tmp/wot/github_test/20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay"),
    ("lakeville_EU", "/tmp/wot/github_test/20260907_1321_germany-G197_Pz_Kpfw_Neu_07_lakeville.wotreplay"),
    ("caucasus_NA", "/tmp/wot/github_test/20260910_1057_china-Ch67_BZ_79_37_caucasus.wotreplay"),
    ("namerica_CN", "/tmp/wot/github_test/20260911_1534_ussr-R52_Object_261_44_north_america.wotreplay"),
    ("tundra_CN_bt46", "/tmp/wot/github_test/20260911_1749_uk-GB156_Black_Prince_II_63_tundra.wotreplay"),
    ("caucasus_CN942", "/tmp/wot/github_test/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay"),
    ("greatwall_EU", "/tmp/wot/github_test/20260912_1036_france-F143_Fauteur_59_asia_great_wall.wotreplay"),
    ("karelia2_EU", "/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay"),
    ("PTZ_10K_EU", "/tmp/wot/github_test/PTZ_10K.wotreplay"),
    ("WZ219_EU", "/tmp/wot/github_test/WZ-219.wotreplay"),
]

MAX_KEY = 400      # 合理 key 上界(超出判解析失败)
MAX_BODY = 64


def load_pkts(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from('<I', data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b'\x00' * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        d = cipher.decrypt(main[i:i + 8])
        d = bytes(a ^ b for a, b in zip(d, prev))
        prev = d
        out += d
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from('<III', stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


def parse_entries(pl):
    """[u32 eid]([u32 key][u32 blen][body])×N → (eid, [(key, body)]) 或 None"""
    if len(pl) < 12:
        return None
    eid, = struct.unpack_from('<I', pl, 0)
    q = 4
    out = []
    while q + 8 <= len(pl):
        key, blen = struct.unpack_from('<II', pl, q)
        if key > MAX_KEY or blen > MAX_BODY or q + 8 + blen > len(pl):
            # 回退: 整包单条
            if q == 4 and len(pl) >= 12:
                k2, b2 = struct.unpack_from('<II', pl, 4)
                return (eid, [(k2, pl[12:])]) if b2 == len(pl) - 12 else None
            return None
        out.append((key, pl[q + 8:q + 8 + blen]))
        q += 8 + blen
    return (eid, out) if out else None


def main():
    result = {}
    for tag, path in REPLAYS:
        pkts = load_pkts(path)
        eid2type = {}
        for ty, clk, pl in pkts:
            if ty == 5 and len(pl) >= 8:
                e, n = struct.unpack_from('<II', pl, 0)
                eid2type[e] = n
        csi_by_type = defaultdict(Counter)     # typeID -> key -> count
        csi_unmapped = Counter()
        bad = n07 = nent = 0
        for ty, clk, pl in pkts:
            if ty != 7:
                continue
            n07 += 1
            r = parse_entries(pl)
            if r is None:
                bad += 1
                continue
            eid, entries = r
            nent += len(entries)
            t = eid2type.get(eid)
            tgt = csi_by_type[t] if t is not None else csi_unmapped
            for key, body in entries:
                tgt[key] += 1
        result[tag] = {
            'n07': n07, 'entries': nent, 'bad': bad,
            'csi_by_type': {str(k): dict(v) for k, v in csi_by_type.items()},
            'csi_unmapped': dict(csi_unmapped),
        }
        print(f'\n=== {tag}: 0x07×{n07} 条目{nent} 坏包{bad} ===')
        for t in sorted(csi_by_type, key=lambda x: (x is None, x)):
            keys = csi_by_type[t]
            ks = sorted(keys)
            print(f'  t{t}: keys {ks[:8]}{"..." if len(ks) > 8 else ""} '
                  f'max={max(ks) if ks else "-"} n_keys={len(ks)}')
        if csi_unmapped:
            ks = sorted(csi_unmapped)
            print(f'  unmapped: keys {ks[:10]} max={max(ks)} n={len(ks)}')
    json.dump(result, open('/tmp/wot/p07_csi_scan.json', 'w'))
    print('\n[saved] /tmp/wot/p07_csi_scan.json')


if __name__ == '__main__':
    main()
