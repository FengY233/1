#!/usr/bin/env python3
"""tier11_skill_probe.py — 十一级车特殊技能在包数据中的踪迹探针

用户纠正(2026-09-25): 外服回放全部带十一级车+车辆特殊技能(乘员技能另算, 勿混淆);
仅 1 场 CN942。本脚本对比 11 场:
  1) Vehicle(typeID=6) 的 0x08 mid 集合差异 —— 外服独有 mid = 候选技能方法
  2) 0x07 csi key 直方图按场对比 —— Vehicle 实体 csi 空间 0..49, 越界键 = 组件属性通道
  3) Vehicle 0x05 载荷长度/头部结构对比
  4) 全场 mid 覆盖矩阵(所有 eid 段)
输出 /tmp/wot/tier11_probe.json
"""
import json
import struct
import zlib
from collections import Counter, defaultdict

from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])

REPLAYS = [
    ("siegfried_EU", "/tmp/wot/github_test/20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay"),
    ("karelia_EU", "/tmp/wot/github_test/20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay"),
    ("lakeville_EU", "/tmp/wot/github_test/20260907_1321_germany-G197_Pz_Kpfw_Neu_07_lakeville.wotreplay"),
    ("caucasus_NA", "/tmp/wot/github_test/20260910_1057_china-Ch67_BZ_79_37_caucasus.wotreplay"),
    ("namerica_CN", "/tmp/wot/github_test/20260911_1534_ussr-R52_Object_261_44_north_america.wotreplay"),
    ("tundra_CN_bt46", "/tmp/wot/github_test/20260911_1749_uk-GB156_Black_Prince_II_63_tundra.wotreplay"),
    ("caucasus_CN942", "/tmp/wot/github_test/20260911_1801_ussr-R52_Object_261_37_caucasus.wotreplay"),
    ("greatwall_EU", "/tmp/wot/github_test/20260912_1036_france-F143_Fauteur_59_asia_great_wall.wotreplay"),
    ("karelia2_EU", "/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay"),
    ("PTZ_10K_EU", "/tmp/wot/github_test/PTZ_10K.wotreplay"),
    ("WZ219_EU", "/tmp/wot/github_test/WZ-219.wotreplay"),
]

# jsonl 0x07 csi 观测上限: 仅对 CN942 主分析场可用(jsonl 只有一份)
VEH_CSI_MAX = 49  # Vehicle 实体 csi 空间 0..49 (csi_tables_v8)


def load_pkts(path):
    data = open(path, "rb").read()
    (magic, bc) = struct.unpack_from("<II", data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from("<I", data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b"\x00" * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        d = cipher.decrypt(main[i:i + 8])
        d = bytes(a ^ b for a, b in zip(d, prev))
        prev = d
        out += d
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from("<III", stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


def analyze(tag, path):
    pkts = load_pkts(path)
    eid2type = {}
    veh_payloads = []
    for ty, clk, pl in pkts:
        if ty == 5 and len(pl) >= 8:
            eid, n = struct.unpack_from("<II", pl, 0)
            eid2type[eid] = n
            if n == 6 and len(veh_payloads) < 5:
                veh_payloads.append(pl)
    # Vehicle eid 集合
    veh_eids = {e for e, n in eid2type.items() if n == 6}
    # 0x08 mid 按 (实体类别) 分桶
    mid_by_cls = defaultdict(Counter)   # cls -> mid -> count
    for ty, clk, pl in pkts:
        if ty == 8 and len(pl) >= 8:
            eid, mid = struct.unpack_from("<II", pl, 0)
            n = eid2type.get(eid)
            cls = f"t{n}" if n is not None else "unmapped"
            mid_by_cls[cls][mid] += 1
    # 0x07: [eid][key][body] 格式(参考 jsonl: eid + key + len-prefixed?) → 直接按 jsonl 对齐:
    # jsonl 样例 body 长度与 key 相关, 0x07 原始格式需探测: 先假设 [u32 eid][u8 key][rest]
    # —— 改用保守法: 记录 0x07 载荷首 8 字节做直方图
    p07_shapes = Counter()
    veh07 = []
    for ty, clk, pl in pkts:
        if ty == 7:
            p07_shapes[len(pl)] += 1
            if len(veh07) < 4000:
                veh07.append(pl)
    return {
        "tag": tag,
        "n05": len(eid2type),
        "n_veh": len(veh_eids),
        "veh05_len_hist": dict(Counter(len(p) for p in
                                       [pl for ty, c, pl in pkts if ty == 5
                                        and len(pl) >= 8
                                        and struct.unpack_from('<I', pl, 4)[0] == 6])),
        "veh05_first3": [p.hex() for p in veh_payloads[:3]],
        "mid_by_cls": {k: dict(v) for k, v in mid_by_cls.items()},
        "p07_len_hist_top": dict(p07_shapes.most_common(12)),
    }


def main():
    out = []
    for tag, path in REPLAYS:
        r = analyze(tag, path)
        out.append(r)
        veh_mids = set(r["mid_by_cls"].get("t6", {}))
        print(f"\n=== {tag}: veh05={r['veh05_len_hist']} n_veh={r['n_veh']}")
        print(f"    Vehicle mids: {sorted(veh_mids)}")
        unm = r["mid_by_cls"].get("unmapped", {})
        print(f"    unmapped eid mids: {sorted(unm.keys())}")
    with open("/tmp/wot/tier11_probe.json", "w") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    print("\n[saved] /tmp/wot/tier11_probe.json")

    # ---- 差分: 以 CN942 为基线 ----
    base = next(r for r in out if r["tag"] == "caucasus_CN942")
    base_veh = set(base["mid_by_cls"].get("t6", {}))
    print("\n===== Vehicle mid 差分 (相对 CN942 基线) =====")
    for r in out:
        if r["tag"] == "caucasus_CN942":
            continue
        mids = set(r["mid_by_cls"].get("t6", {}))
        extra = sorted(mids - base_veh)
        missing = sorted(base_veh - mids)
        if extra or missing:
            print(f"{r['tag']:18s} +{extra} -{missing}")
        else:
            print(f"{r['tag']:18s} (identical)")
    print("\n===== Vehicle 0x05 载荷长度分布 =====")
    for r in out:
        print(f"{r['tag']:18s} {r['veh05_len_hist']}")


if __name__ == "__main__":
    main()
