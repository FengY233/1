#!/usr/bin/env python3
"""ext_dump.py — dump 0x05 原始字节供人工断句"""
import struct, zlib
from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])


def load_pkts(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from('<I', data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b'\x00' * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        dd = cipher.decrypt(main[i:i + 8])
        dd = bytes(a ^ b for a, b in zip(dd, prev))
        prev = dd
        out += dd
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from('<III', stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


path = "/tmp/wot/github_test/20260905_2048_sweden-S41_BV_111_14_siegfried_line.wotreplay"
pkts = load_pkts(path)
veh = [pl for ty, c, pl in pkts if ty == 5 and len(pl) >= 47
       and struct.unpack_from('<I', pl, 4)[0] == 6]

pl = veh[0]
eid = struct.unpack_from('<I', pl, 0)[0]
print(f'eid={eid} plen={len(pl)}')
print(f'  [0:4]   eid      = {pl[0:4].hex()}')
print(f'  [4:8]   typeID   = {struct.unpack_from("<I", pl, 4)[0]}')
print(f'  [8:18]  head10   = {pl[8:18].hex()}')
print(f'  [18:30] pos      = {struct.unpack_from("<3f", pl, 18)}')
print(f'  [30:42] ypr      = {struct.unpack_from("<3f", pl, 30)}')
print(f'  [42:46] propBytes= {struct.unpack_from("<I", pl, 42)[0]}')
print(f'  [46]    count    = {pl[46]}')
print(f'  [47:]   props hex:')
h = pl[47:].hex()
for i in range(0, len(h), 64):
    print(f'    {47 + i//2:4d}: {h[i:i+64]}')
