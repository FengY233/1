#!/usr/bin/env python3
"""csi_anchor.py — Task34: 用 roster 真值反推 0x05 扩展区 idx→属性 映射
vpp ARRAY<I32> 值 = [n][n×I32 LE] = roster vehPostProgression
定位后取前 1 字节 = idx → 直方图
"""
import json, struct
from collections import Counter, defaultdict

rows = json.load(open('/tmp/wot/ext_cluster.json'))
print(f'{len(rows)} 车')

# 1) vpp 锚: 构造字节模式搜 ext
idx_hist = Counter()
idx_by_len = defaultdict(Counter)
miss = 0
hit = 0
for r in rows:
    vpp = r.get('vpp') or []
    ext = bytes.fromhex(r['ext'])
    if not vpp:
        continue
    # ARRAY<I32> n 个元素 = [n][each 4B LE]
    pat = struct.pack('<B', len(vpp)) + b''.join(struct.pack('<i', x) for x in vpp)
    i = ext.find(pat)
    if i < 0:
        # 也许 n 用 packedInt 多字节 (n<255 恒 1B, 不会)
        miss += 1
        continue
    hit += 1
    idx = ext[i - 1] if i >= 1 else -1
    idx_hist[idx] += 1
    idx_by_len[len(vpp)][idx] += 1

print(f'vpp 命中 {hit} / 未中 {miss}')
print('idx 直方图:', dict(idx_hist.most_common(10)))
for ln in sorted(idx_by_len):
    print(f'  vpp元素数={ln}: idx 分布 {dict(idx_by_len[ln].most_common(5))}')

# 2) avatarID 已知 csi16 (在基础段) — 验证扩展区无 avatarID
# 3) maxHealth: roster 无, 但 publicInfo.maxHealth 在 csi37 FD 内
# 4) dogTag / healOT 等 None 默认不发

# 5) 固定后缀结构统计: 从尾部固定模式反推
# 尾部普遍: ... 2c 01 [1B pickle] 或 42 00... 统计每车尾部 12B
tailc = Counter()
for r in rows:
    ext = bytes.fromhex(r['ext'])
    tailc[ext[-6:].hex()] += 1
print('\n尾 6B top10:')
for t, c in tailc.most_common(10):
    print(f'  {t}: {c}')

# 6) 21 00 / 22 00 (perkEff/perks 空标记) 出现率
c21 = sum(1 for r in rows if '2100' in r['ext'])
c22 = sum(1 for r in rows if '2200' in r['ext'])
print(f'\n含 21 00: {c21} 车 / 含 22 00: {c22} 车')
