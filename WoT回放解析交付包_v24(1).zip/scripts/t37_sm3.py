#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
t37_sm3.py — Task 37 ⑨：通道 29/30 数组状态机终审
假设: ownVehiclePosition(csi29) = ARRAY<elem 18B>, inspired(csi30) = ARRAY<elem 13B>
元素 = AllowNone FIXED_DICT (首字节 01 = hasValues)
初始: 空(0x07 发过 00=None; 0x05 不含)
规则同 33/34: path=[1][csi6][0] + idx/slice 位宽 bitsRequirement(len(+1))
"""
import struct, sys
sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import REPLAYS, load_pkts

def br(n):
    if n <= 1: return 0
    r = 0
    while (1 << r) < n: r += 1
    return r

class B:
    def __init__(s, b): s.b = b; s.p = 0
    def get(s, n):
        v = 0
        for _ in range(n): v = (v << 1) | ((s.b[s.p >> 3] >> (7 - (s.p & 7))) & 1); s.p += 1
        return v
    def used(s): return (s.p + 7) >> 3

ELEM = {29: 18, 30: 13}
total = {29: [0, 0], 30: [0, 0]}
bads = []
for TAG, RP in REPLAYS:
    pkts = load_pkts(RP)
    eid2ty = {}
    p05seq = {}
    for ty, clk, pl in pkts:
        if ty == 5 and len(pl) >= 8:
            e, n = struct.unpack_from('<II', pl, 0)
            eid2ty[e] = n
            if n == 6:
                p05seq.setdefault(e, []).append(clk)
    state = {}
    for ty, clk, pl in pkts:
        if ty != 0x24: continue
        eid, isl, ln = struct.unpack_from('<IBI', pl, 0)
        if eid2ty.get(eid) != 6: continue
        body = pl[9:9+ln]
        if len(body) < 2 or not (body[0] & 0x80): continue
        b = B(body)
        if b.get(1) != 1: continue
        csi = b.get(6)
        if csi not in ELEM: continue
        if b.get(1) != 0: continue
        # 0x05 重创建 → 重置(0x05 不含这些属性 → 重置为空); 每通道独立数组状态
        seq = p05seq.get(eid, [-1])
        gen = max(0, sum(1 for c in seq if c < clk) - 1)
        key = (eid, gen, csi)
        if key not in state:
            state[key] = 0
        n = state[key]
        E = ELEM[csi]
        if isl:
            nb = br(n + 1)
            s, e = b.get(nb), b.get(nb)
            val = body[b.used():]
            ok = s <= e <= n and len(val) % E == 0 and len(val) > 0
            if ok: state[key] = s + len(val)//E + (n - e)
        else:
            nb = br(n)
            idx = b.get(nb)
            val = body[b.used():]
            ok = idx < n and len(val) == E
        total[csi][0 if ok else 1] += 1
        if not ok and len(bads) < 15:
            bads.append((TAG, clk, eid, isl, csi, n, body.hex()))

print('通道29 (ownVehiclePosition? elem18B): ok=%d bad=%d' % tuple(total[29]))
print('通道30 (inspired? elem13B):           ok=%d bad=%d' % tuple(total[30]))
for x in bads: print('  BAD:', x)
