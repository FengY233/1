#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""wot_src_extract.py — wot_src.7z 后台解压守护（Popen detach, 同 file_server 存活方式）
先精准解压 replay 研究关键文件，再全量。"""
import subprocess
import sys
import time

CMD = '''
import py7zr, time, sys
t0 = time.time()
# 阶段1: 精准解压 replay 研究关键文件
targets = None
with py7zr.SevenZipFile('/tmp/my-project/repos/wot_src_merged.7z') as z:
    names = z.getnames()
    keys = ['BattleReplay.py', 'ValueReplay.py', 'ReplayEvents.py',
            'VehicleGunRotator.py', 'PlayerAvatar.py', 'Vehicle.py',
            'avatar.py', 'ArenaInfo.py', 'entities.xml', 'components.xml']
    targets = [n for n in names if any(k in n for k in keys) and n.endswith(('.py', '.xml'))]
    print('targets:', len(targets), flush=True)
    if targets:
        z.extract(path='/tmp/my-project/repos/wot_src_sel', targets=targets)
    print('SEL DONE %.1fs' % (time.time()-t0), flush=True)
# 阶段2: 全量
with py7zr.SevenZipFile('/tmp/my-project/repos/wot_src_merged.7z') as z:
    z.extractall(path='/tmp/my-project/repos/wot_src_full')
print('FULL DONE %.1fs' % (time.time()-t0), flush=True)
'''

p = subprocess.Popen(
    [sys.executable, '-c', CMD],
    stdout=open('/tmp/wot_src_extract.log', 'w'),
    stderr=subprocess.STDOUT,
    start_new_session=True)
print(f'后台解压 PID={p.pid}（日志 /tmp/wot_src_extract.log）')
