#!/usr/bin/env python3
"""t44_vtable.py — Task 44: 定位 0x32/0x37 录制写入器所在的 vtable
方法: 在 EXE .rdata/.data 搜 qword 0x140584f80 / f90 / fa0 / fb0 / 0x140585000 / 0x140585010
     → 找到 vtable 基址 → dump 整表 + RTTI 邻域 → 还原 handler 接口
"""
import pefile, struct, sys

EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
print(f'ImageBase: {hex(imgbase)}')

# 全文件读入
data = open(EXE, 'rb').read()

# 段表
for s in pe.sections:
    print(f'{s.Name.decode().rstrip(chr(0)):10s} VA={hex(imgbase+s.VirtualAddress):>14} VS={hex(s.Misc_VirtualSize):>10} RAW={hex(s.PointerToRawData):>10}')

targets = [0x140584f80, 0x140584f90, 0x140584fa0, 0x140584fb0,
           0x140584fc0, 0x140585000, 0x140585010, 0x140585020,
           0x140584f50, 0x140584f60, 0x140584f70]

def va_to_off(va):
    for s in pe.sections:
        if imgbase + s.VirtualAddress <= va < imgbase + s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (va - imgbase - s.VirtualAddress)
    return None

print('\n=== 搜索 vtable 槽位 ===')
hits = {}
for t in targets:
    pat = struct.pack('<Q', t)
    off = 0
    while True:
        i = data.find(pat, off)
        if i < 0:
            break
        # 换算 VA
        va = None
        for s in pe.sections:
            if s.PointerToRawData <= i < s.PointerToRawData + s.SizeOfRawData:
                va = imgbase + s.VirtualAddress + (i - s.PointerToRawData)
                break
        print(f'  {hex(t)} @ file_off={hex(i)} VA={hex(va) if va else "?"}')
        if va:
            hits[va] = t
        off = i + 1

# 找连续区（vtable）: 相邻 8 字节
if hits:
    vas = sorted(hits)
    print('\n=== 槽位聚集分析 ===')
    base = vas[0]
    # 向前向后扫描出整张表（qword 指向 .text 的连续区）
    def is_text_ptr(va):
        off = va_to_off(va)
        if off is None:
            return False
        for s in pe.sections:
            if s.PointerToRawData <= off < s.PointerToRawData + s.SizeOfRawData:
                return b'.text' in s.Name
        return False

    # 从最小命中向上扫到非 text 指针
    lo = base
    while True:
        prev = lo - 8
        off = va_to_off(prev)
        if off is None:
            break
        v = struct.unpack('<Q', data[off:off+8])[0]
        if is_text_ptr(v):
            lo = prev
        else:
            break
    hi = vas[-1]
    while True:
        nxt = hi + 8
        off = va_to_off(nxt)
        if off is None:
            break
        v = struct.unpack('<Q', data[off:off+8])[0]
        if is_text_ptr(v):
            hi = nxt
        else:
            break
    print(f'疑似 vtable 区间: {hex(lo)} .. {hex(hi)}  ({(hi-lo)//8+1} 槽)')
    print('\n=== 全表 dump ===')
    va = lo
    idx = 0
    while va <= hi:
        off = va_to_off(va)
        v = struct.unpack('<Q', data[off:off+8])[0]
        mark = ' <<<' if va in hits else ''
        print(f'  slot[{idx:2d}] @{hex(va)} = {hex(v)}{mark}')
        va += 8
        idx += 1
    # vtable 上方通常有 RTTI COL 指针
    off = va_to_off(lo - 8)
    if off:
        v = struct.unpack('<Q', data[off:off+8])[0]
        print(f'\n  vtable-8 (RTTI COL?) = {hex(v)}')
        col_off = va_to_off(v)
        if col_off:
            sig, off2, cd = struct.unpack('<III', data[col_off:col_off+12])
            print(f'  COL: sig={hex(sig)} offset={hex(off2)} typeDescriptor={hex(cd)}')
            td_off = va_to_off(cd)
            if td_off:
                # TypeDescriptor: vftable(8) + spare(8) + name(...)
                name = data[td_off+16:td_off+16+80].split(b'\x00')[0].decode('utf-8', 'replace')
                print(f'  ★ 类名: {name}')
