#!/usr/bin/env python3
"""csi_solve.py — Task34 核心: 0x05 属性流联合求解器
模型 (FUN_142a92db0 白盒 + vanilla 线编码):
  流 = [u8 count] x ([u8 idx][typed value])
  idx<50: 实体 CS 属性 (csi 表, 观测修正版)
  idx>=50: 组件属性 (宽度未知, 全局一致约束)
线编码:
  定长: 直出 | 变长 SEQ: [packedInt n][elem...] | STRING/PYTHON: [packedInt len][..]
  FD allow_none: [u8 0]None/[u8 1]+字段 | 空 ARRAY: [u8 0]
求解: 回溯 walk, csi>=50 节点宽度记为未知变量, 同 idx 跨车同宽
"""
import json, struct
from collections import defaultdict

# ---------- 修正版 Vehicle csi 表 (观测锚: vpp=40, healing=47, healOT=48 待验, perks=34, perkEff=33, steering=31) ----------
# 类型: ('fx', N) 定长N | ('seq', elem_desc) 变长序列 | ('str',) | ('py',) | ('fdnone',) FD可None
CSI_OBS = {
    0: ('fx', 1),    # burnoutLevel U8
    1: ('fx', 1),    # isStrafing
    2: ('fx', 1),    # isHidden
    3: ('fx', 1),    # physicsMode
    4: ('fx', 1),    # siegeState
    5: ('fx', 1),    # isCrewActive
    6: ('fx', 1),    # customRoleSlotTypeId
    7: ('fx', 1),    # arenaBonusType
    8: ('fx', 1),    # isSpeedCapturing
    9: ('fx', 1),    # isBlockingCapture
    10: ('fx', 1),   # isMyVehicle
    11: ('fx', 1),   # enableExternalRespawn
    12: ('fx', 1),   # botDisplayStatus
    13: ('fx', 2),   # gunAnglesPacked
    14: ('fx', 2),   # health
    15: ('fx', 2),   # engineMode TUPLE<UINT8>x2 定长直出
    16: ('fx', 4),   # avatarID
    17: ('fx', 4),   # masterVehID
    18: ('fx', 4),   # arenaTypeID
    19: ('fx', 4),   # debuff
    20: ('fx', 4),   # quickShellChangerFactor
    21: ('fx', 4),   # onRespawnReloadTimeFactor
    22: ('fx', 8),   # wheelsState
    23: ('fx', 8),   # stunInfo
    24: ('fx', 8),   # arenaUniqueID
    25: ('fx', 14),  # dotEffect
    26: ('fx', 22),  # remoteCamera
    27: ('fx', 24),  # inspiringEffect
    28: ('fx', 24),  # healingEffect
    29: ('fx', 32),  # ownVehiclePosition
    30: ('fx', 36),  # inspired
    31: ('seq', ('fx', 1)),   # steeringAngles TUPLE<UINT8>
    32: ('seq', ('fx', 1)),   # wheelsScroll TUPLE<UINT8>
    33: ('fdempty',),         # perkEffects FD{equipment:ARRAY<STRING>} -> 空时 [u8 0] 1B
    34: ('seq', 'fdperk'),    # perks ARRAY<FD allow_none>
    35: ('seq', 'fdribbon'),  # perksRibbonNotify ARRAY<FD allow_none>
    36: ('str',),             # postmortemViewPointName
    37: ('fdpublic',),        # publicInfo (复杂)
    38: ('seq', 'fdsticker'), # damageStickers
    39: ('seq', ('fx', 1)),   # publicStateModifiers ARRAY<U8>
    40: ('seq', ('fx', 4)),   # ★vehPostProgression ARRAY<I32> (观测锚)
    41: ('py',), 42: ('py',), 43: ('py',),   # enh/setups/setupIdx (顺序待验)
    44: ('py',),              # vehPerks 区 (观测 `2c 01 [00]`)
    45: ('seq', ('fx', 4)),   # disabledSwitches / crew 等 (待验)
    46: ('py',),
    47: ('fdnone',),          # healing (观测 `2f 00`)
    48: ('unknown',),         # healOverTime? (观测 `30 02` 非None!)
    49: ('unknown',),         # dogTag?
}


def load_rows():
    return json.load(open('/tmp/wot/ext_cluster.json'))


def solve_stream(pl, q, count, uid_widths, log):
    """从 q 走 count 条; 返回结束位置 或 None
    csi>=50 宽度用 uid_widths[idx] (无则试探候选并记录)"""
    n = len(pl)
    walked = 0
    trail = []
    for i in range(count):
        if q >= n:
            return None, trail
        idx = pl[q]
        q += 1
        if idx < 50:
            t = CSI_OBS.get(idx)
            if t is None:
                return None, trail
            k = t[0]
            if k == 'fx':
                q += t[1]
            elif k == 'seq':
                if q >= n:
                    return None, trail
                cnt = pl[q]; q += 1
                ek = t[1]
                if ek == ('fx', 1):
                    q += cnt
                elif ek == ('fx', 4):
                    q += cnt * 4
                else:
                    return None, trail  # FD 元素暂不展开
            elif k in ('str', 'py'):
                if q >= n:
                    return None, trail
                ln = pl[q]; q += 1 + ln
            elif k in ('fdempty', 'fdnone'):
                q += 1
            else:
                return None, trail
            trail.append((idx, q))
            walked += 1
        else:
            # 组件 idx: 试探宽度
            w = uid_widths.get(idx)
            cands = [w] if w else [1, 2, 4]
            ok = None
            for cw in cands:
                if q + cw <= n:
                    # 接受并记录
                    uid_widths.setdefault(idx, cw)
                    trail.append((idx, q + cw))
                    q += cw
                    ok = cw
                    break
            if ok is None:
                return None, trail
            walked += 1
        if q > n:
            return None, trail
    return q, trail


def main():
    rows = load_rows()
    # 先对最短扩展区的车求解 (贪心: 短流约束强)
    rows_s = sorted(rows, key=lambda r: len(r['ext']))
    uid_widths = {}
    solved = 0
    fail_stream = []
    for r in rows_s[:80]:
        ext = bytes.fromhex(r['ext'])
        count = r['count']
        base_n = r['base_n']
        # 扩展区从 extoff 起 = 基础段后. count - base_n = 扩展区条目数(实体部分)
        # 但组件条目数未知 -> 尝试 count 补 + 剩余全走
        # 策略: 先走 count-base_n 条, 然后继续回溯直到流尾
        q = 0
        trail = []
        rem = count - base_n
        if rem > 0:
            q2, tr = solve_stream(ext, 0, rem, uid_widths, None)
            if q2 is None:
                fail_stream.append((r['tag'], r['eid'], 'head'))
                continue
            q = q2
            trail = tr
        # 继续走到底: 每次 1 条, 失败则停 (记录覆盖率)
        cov = q
        while q < len(ext):
            q2, tr = solve_stream(ext[q:], 0, 1, uid_widths, None) if False else (None, None)
            # 简化: 用 solve_stream 逐条
            res = solve_stream(ext, q, 1, uid_widths, None)
            if res[0] is None:
                break
            q = res[0]
            trail += res[1]
            cov = q
        r['cov'] = cov
        r['extlen'] = len(ext)
        if cov == len(ext):
            solved += 1
        else:
            fail_stream.append((r['tag'][:14], r['vtype'], f'{cov}/{len(ext)}'))
    print(f'完整走通: {solved}/80')
    print('样例失败 (前 12):')
    for f in fail_stream[:12]:
        print('  ', f)
    print('\n已锁组件 idx 宽度:', dict(sorted(uid_widths.items())))


if __name__ == '__main__':
    main()
