# -*- coding: utf-8 -*-
"""pack_v17.py — V17 交付包：0x24 通道全协议白盒轮（Task 36①）"""
import os
import shutil
import zipfile

BASE = '/home/z/my-project'
DL = f'{BASE}/download'
OUT = f'{DL}/WoT回放解析交付包_v17.zip'

FILES_ROOT = [  # (src, arcname)
    (f'{BASE}/findings.md', 'findings.md'),
    (f'{BASE}/worklog.md', 'worklog.md'),
    (f'{DL}/csi_tables_v8.json', 'csi_tables_v8.json'),
]
SCRIPTS = ['p24_probe.py', 'p24_decode.py', 'p24_bitpath.py', 'p24_bitpath2.py',
           'p24_deep.py', 'p24_slice.py', 'p24_var29.py', 'p24_final.py',
           'p05_decoder.py', 'net05_table.py', 'defparse.py', 'bwxml.py',
           'restore_after_reset4.py', 'restore2_materials.py', 'restore2b_bg.sh',
           'restore2c_dec.py', 'wot_src_extract.py', 'fix_download_names.py',
           'file_server.py']
DATA = [
    ('/tmp/wot/p24_final.json', 'data_v21/0x24全量解码_5241条_11场.json'),
    ('/tmp/wot/p24_top_csi.json', 'data_v21/0x24顶层csi分布.json'),
    ('/tmp/wot/p24_keys.json', 'data_v21/0x24键空间_旧口径.json'),
    ('/tmp/wot/p05_decoded.json', 'data_v20/0x05全量解码_6899条_11场.json'),
]

with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED) as z:
    for src, arc in FILES_ROOT:
        z.write(src, arc)
    for s in SCRIPTS:
        p = f'{BASE}/scripts/{s}'
        if os.path.isfile(p):
            z.write(p, f'scripts/{s}')
        else:
            print('  [缺]', s)
    for src, arc in DATA:
        if os.path.isfile(src):
            z.write(src, arc)
        else:
            print('  [缺]', src)
    # README
    readme = """# WoT 回放解析交付包 V17 —— 0x24 通道全协议白盒（Task 36①）

## 本轮核心突破（v21 / findings §17）
1. **0x24 = 嵌套/切片属性更新通道**（BigWorld nestedEntityProperty/sliceEntityProperty）
   - decomp 写入器 FUN_140587300 = WGReplayMessageHandler::getFile（源文件+行号级白盒）
   - 包头 [eid u32][isSlice u8][len u32][payload]，11 场 5,241 包 100% len 吃满
2. **payload 压缩路径位流全解**（MSB-first；首层 index = csi，位宽 bitsRequired(numCS)）
   - 与 0x07 同 csi 表；写入端/读取端 vanilla 源码逐行对照
3. **全量分类**：perkEffects×1,497 / destroyedFragiles×2,173 / ownVehiclePosition×496
   / perks×170 / inspired×168 / fallenTrees×573 / fallenColumns×90 / destroyedModules×74
4. 旧 v6「火炮瞄准装填参数」推断推翻（'ba 01'=位流 [1][csi=29]）
5. AllowNone=[u8 hasValues] 双通道实证；perks slice(0,2)+0B=数组删除语义

## 交付物
- findings.md（v21，§17 新章）/ worklog.md（Task 36 全记录）
- scripts/：0x24 全链 8 件（p24_*）+ 基础设施 + 环境恢复 6 件
- data_v21/：0x24 全量解码 5,241 条（eid/csi/slice 区间/值 hex/时钟）
- data_v20/：0x05 全量解码 6,899 条（重新生成，验证恢复完整性）

## 环境恢复说明（本轮开头）
第 4 次环境重置：工作区全清，upload/ 幸存。本包全部材料自 backup_v16 + 四大源
（decomp/scripts.7z/BigWorld/wot_src 分卷）全量恢复。dec.7z 真相：= decomp.zip 的
AES 加密容器（内层 md5 逐字节一致，无增量信息）。
"""
    z.writestr('README.md', readme)

print('打包完成:', OUT, f'{os.path.getsize(OUT)/1048576:.2f} MB')
# 备份到 upload
os.makedirs(f'{BASE}/upload/backup_v17', exist_ok=True)
shutil.copy2(OUT, f'{BASE}/upload/backup_v17/WoT回放解析交付包_v17.zip')
shutil.copy2(f'{BASE}/findings.md', f'{BASE}/upload/backup_v17/findings_v21.md')
shutil.copy2(f'{BASE}/worklog.md', f'{BASE}/upload/backup_v17/worklog.md')
print('backup_v17 三件已存')
# 校验
with zipfile.ZipFile(OUT) as z:
    print('zip 条目:', len(z.namelist()))
