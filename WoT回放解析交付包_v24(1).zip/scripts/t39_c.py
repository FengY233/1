#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
t39_c.py — Task 39-c/39-a 合并攻坚：
A. 0x05 重创建触发条件终判（AoI 离开/重入协议链: 0x04=leaveAoI? 配对验证 + 0x0A 位置流中断测量）
B. E 字段(lifeTime/endTime)纪元判定（dateTime→unix 场间结构 + 场内 span vs duration + clk 映射）
"""
import json, struct, sys, datetime
from collections import defaultdict, Counter

sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import REPLAYS, load_pkts

RB = [r for r in REPLAYS if r[0] != 'tundra_CN_942']

# ================= A. AoI 协议链 =================
print('===== A. 0x04(leaveAoI?) ↔ 0x05(createEntity) 协议链 =====')
tot = Counter()
pairs_gap = []          # (tag,eid) 重创建 0x05 与其前最近同 eid 0x04 的 clk 差
no04 = 0                # 重创建 0x05 前无同 eid 0x04
gap_to_prev05 = []      # 重创建与前次 0x05 的间隔
recreate_by_type = defaultdict(list)
veh_pos_gap = []        # Vehicle 重创建前后 0x0A 中断窗口
p05 = json.load(open('/tmp/wot/p05_decoded.json'))
et = {}
for r in p05:
    if r['tag'] != 'tundra_CN_942':
        et[(r['tag'], r['eid'])] = r.get('typeID')
TNAME = {6: 'Vehicle', 7: 'AreaDestr', 12: 'DetachedTurret', 28: 'TeamInfo', 29: 'AvatarInfo', 40: 'NetworkEntity'}

for tag, path in RB:
    pkts = load_pkts(path)
    tot['04'] += sum(1 for t, _, _ in pkts if t == 4)
    tot['05'] += sum(1 for t, _, _ in pkts if t == 5)
    tot['06'] += sum(1 for t, _, _ in pkts if t == 6)
    # per-eid 时间线
    ev = defaultdict(list)      # eid -> [(clk, 'L'/'C')]
    last0A = {}                 # eid -> 最近 0x0A clk
    idx = defaultdict(int)      # eid -> 0x05 计数
    for ty, clk, body in pkts:
        if ty == 4:
            (eid,) = struct.unpack_from('<I', body, 0)
            ev[eid].append((clk, 'L'))
        elif ty == 5:
            (eid,) = struct.unpack_from('<I', body, 0)
            n = idx[eid]; idx[eid] = n + 1
            if n > 0:   # 重创建
                # 找该 eid 在此 clk 之前最近的 L
                Ls = [c for c, k in ev[eid] if k == 'L' and c <= clk]
                prevC = [c for c, k in ev[eid] if k == 'C' and c < clk]
                tid = et.get((tag, eid), -1)
                recreate_by_type[tid].append(n)
                if Ls:
                    pairs_gap.append((tag, eid, tid, clk - Ls[-1], clk - prevC[-1] if prevC else -1))
                else:
                    no04 += 1
                ev[eid].append((clk, 'C'))
                # Vehicle: 0x0A 中断窗口
                if tid == 6 and eid in last0A:
                    veh_pos_gap.append((tag, eid, clk - last0A[eid]))
        elif ty == 0x0A:
            (eid,) = struct.unpack_from('<I', body, 0)
            last0A[eid] = clk

print('10场合计: 0x04=%d  0x05=%d  0x06=%d' % (tot['04'], tot['05'], tot['06']))
print('重创建 0x05 前有同eid 0x04: %d 例; 无: %d 例' % (len(pairs_gap), no04))
g = [x[3] for x in pairs_gap if x[3] >= 0]
g.sort()
import statistics
if g:
    print('重创建C ← 最近leaveAoI L 间隔(clk): min=%d p10=%d 中位=%d p90=%d max=%d' % (
        g[0], g[len(g)//10], statistics.median(g), g[len(g)*9//10], g[-1]))
    # 间隔直方
    h = Counter()
    for v in g:
        if v <= 100: h['≤100'] += 1
        elif v <= 2000: h['101-2k'] += 1
        elif v <= 100000: h['2k-100k'] += 1
        else: h['>100k'] += 1
    print('间隔分桶:', dict(h))
g2 = [x[4] for x in pairs_gap if x[4] >= 0]
if g2:
    g2.sort()
    print('重创建 ← 前次创建0x05 间隔(clk): min=%d 中位=%d max=%d' % (g2[0], statistics.median(g2), g2[-1]))
print('重创建 per typeID:', {TNAME.get(k, k): len(v) for k, v in sorted(recreate_by_type.items())})
if veh_pos_gap:
    v = sorted(x[2] for x in veh_pos_gap)
    print('Vehicle 重创建前 0x0A 位置流中断(clk): n=%d min=%d 中位=%d max=%d' % (
        len(v), v[0], statistics.median(v), v[-1]))

# leaveAoI 是否也发生在从不重创建的 eid 上（战斗尾清场）
print()
print('== leaveAoI 的去向: 无后续 0x05 的比例（战斗结束清场）==')
n_L_noC = 0; n_L_total = 0
for tag, path in RB[:3]:
    pkts = load_pkts(path)
    seq = defaultdict(list)
    for ty, clk, body in pkts:
        if ty == 4:
            (eid,) = struct.unpack_from('<I', body, 0); seq[eid].append(('L', clk))
        elif ty == 5:
            (eid,) = struct.unpack_from('<I', body, 0); seq[eid].append(('C', clk))
    for eid, s in seq.items():
        n_L_total += sum(1 for k, _ in s if k == 'L')
        # 每个 L 后是否有更晚的 C
        for i, (k, c) in enumerate(s):
            if k == 'L' and not any(k2 == 'C' and c2 > c for k2, c2 in s):
                n_L_noC += 1
print('前3场: leaveAoI 总 %d, 其中无后续重创建 %d (清场/销毁)' % (n_L_total, n_L_noC))

# ================= B. E 纪元 =================
print()
print('===== B. E(lifeTime/endTime) 纪元判定 =====')
def parse_dt(s):
    return datetime.datetime.strptime(s, '%d.%m.%Y %H:%M:%S').timestamp()

sem = json.load(open('/tmp/wot/perks_semantic_v23.json'))
E = defaultdict(list)
for r in sem:
    t = r.get('lifeTime') or r.get('endTime')
    if t: E[r['tag']].append((t, r['clk']))
binfo = None
# 从块0取 dateTime
import struct as st
def get_dt(path):
    data = open(path, 'rb').read()
    (magic, bc) = st.unpack_from('<II', data, 0)
    pos = 8
    (blen,) = st.unpack_from('<I', data, pos); pos += 4
    b0 = json.loads(data[pos:pos + blen])
    return b0.get('dateTime')

rows = []
for tag, path in RB:
    dt = get_dt(path)
    if tag not in E: continue
    ts = [t for t, c in E[tag]]
    rows.append((tag, parse_dt(dt), min(ts), max(ts), max(ts) - min(ts)))
# 场间差结构: unix 差 vs E 差
print('%-18s %-12s %-11s %-11s %-8s' % ('tag', 'unix', 'E_min', 'E_max', 'span'))
for tag, u, a, b, s in rows:
    print('%-18s %-12d %-11.1f %-11.1f %-8.1f' % (tag, u, a, b, s))
print()
# 同服务器配对检验（相邻场 unix 差 vs E 差）
rows.sort(key=lambda x: x[1])
print('相邻场配对: Δunix vs ΔE_min (若同源单调时钟应 ΔE≈Δunix)')
for i in range(len(rows) - 1):
    t1, u1, a1, b1, s1 = rows[i]
    t2, u2, a2, b2, s2 = rows[i + 1]
    print('  %-16s→%-16s Δunix=%6ds  ΔE_min=%+10.1f' % (t1, t2, u2 - u1, a2 - a1))
# 场内: E - clk 线性?
print()
print('场内 E vs clk 的关系(抽样每场首尾):')
for tag in sorted(E):
    v = E[tag]
    v.sort(key=lambda x: x[1])
    if len(v) >= 2:
        (e0, c0), (e1, c1) = v[0], v[-1]
        dc = (c1 - c0) / 1048576.0     # clk Q20→秒(候选)
        de = e1 - e0
        print('  %-18s Δclk(Q20→s)=%8.2f  ΔE=%8.2f  比率=%.3f' % (tag, dc, de, de / dc if dc else 0))

json.dump({'pairs_gap': pairs_gap[:2000], 'veh_pos_gap': veh_pos_gap[:500]},
          open('/tmp/wot/t39_c.json', 'w'))
print('\n→ /tmp/wot/t39_c.json')
