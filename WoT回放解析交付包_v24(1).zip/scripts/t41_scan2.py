#!/usr/bin/env python3
"""t41_scan2.py — Task 41: 方法参数命名/ReturnValue/CDATA 结构扫描

WoT 魔改 MethodDescription 布局 (decomp):
  +0x80: args vector<{BW::string name@0, DataType*@0x20}>  (0x28/元素)
  +0xa0: returnValues vector<同构>
需确认 def 文件里:
  1. <ClientMethods>/<BaseMethods>/<CellMethods> 下方法的 <Arg> 是否带名字
  2. <ReturnValue(s)> 标签的存在与结构
  3. <Arg> 的 XML 形态 (旧式类型文本 vs 新式命名子节点)
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bwxml import decode_file

SCRIPTS = '/tmp/wot/scripts942/scripts'


def dump(el, ind=0, maxdepth=3):
    if ind > maxdepth:
        return
    t = el.type if hasattr(el, 'type') else '?'
    print(' ' * ind + f'<{el.name} type={t}>')
    for c in el.children:
        dump(c, ind + 2, maxdepth)


def main():
    # Vehicle.def 方法段样例
    root = decode_file(os.path.join(SCRIPTS, 'entity_defs/Vehicle.def'), 'V')
    for sec in root.children:
        if 'Methods' in sec.name:
            print(f'=== Vehicle.def <{sec.name}> ({len(sec.children)} 个) ===')
            for m in sec.children[:4]:
                dump(m, 2, 3)
            break
    # Avatar.def
    root = decode_file(os.path.join(SCRIPTS, 'entity_defs/Avatar.def'), 'A')
    for sec in root.children:
        if 'Methods' in sec.name:
            print(f'=== Avatar.def <{sec.name}> ({len(sec.children)} 个) ===')
            for m in sec.children[:3]:
                dump(m, 2, 3)
            break
    # 全量统计: ReturnValue 标签
    n_ret = 0
    ret_files = []
    n_named_arg = 0
    n_plain_arg = 0
    for d in ('entity_defs', 'component_defs', 'user_data_object_defs'):
        dd = os.path.join(SCRIPTS, d)
        for f in sorted(os.listdir(dd)):
            if not f.endswith('.def'):
                continue
            try:
                r = decode_file(os.path.join(dd, f), f)
            except Exception:
                continue
            for sec in r.children:
                if 'Methods' not in sec.name:
                    continue
                for m in sec.children:
                    for a in m.children:
                        if a.name in ('ReturnValue', 'ReturnValues'):
                            n_ret += 1
                            ret_files.append(f'{d}/{f}:{m.name}')
                        if a.name == 'Arg':
                            if a.children:
                                n_named_arg += 1
                            else:
                                n_plain_arg += 1
    print(f'=== ReturnValue 标签: {n_ret} 个 ===')
    for x in ret_files[:10]:
        print('  ', x)
    print(f'=== <Arg> 带子节点(命名): {n_named_arg}, 纯文本(类型): {n_plain_arg} ===')


if __name__ == '__main__':
    main()
