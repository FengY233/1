#!/usr/bin/env python3
"""t44_stream.py — 定位 BW::MemoryIStream vftable 并解析槽位
decomp 中 FUN_140584fc0 引用了 BW::MemoryIStream::vftable 符号 → 在 EXE 中找该符号地址
"""
import pefile, struct
EXE = '/tmp/wot/wotexe/WorldOfTanks.exe'
pe = pefile.PE(EXE, fast_load=True)
imgbase = pe.OPTIONAL_HEADER.ImageBase
data = open(EXE, 'rb').read()
secs = [(s.Name.decode().rstrip('\0'), imgbase+s.VirtualAddress, s.Misc_VirtualSize, s.PointerToRawData, s.SizeOfRawData) for s in pe.sections]
def va_to_off(va):
    for n, v, vs, raw, rs in secs:
        if v <= va < v + max(vs, rs):
            return raw + (va - v) if raw else None
    return None
def rq(va):
    o = va_to_off(va)
    return struct.unpack('<Q', data[o:o+8])[0] if o is not None else None

# 从 decomp 找 BW::MemoryIStream::vftable 的地址: 查 c_140495d70.c 中 FUN_140584fc0 附近
# Ghidra 符号 "BW::MemoryIStream::vftable" 有地址 → 搜索 decomp 中的定义
import re, subprocess
D = '/tmp/my-project/repos/decomp/decomp'
# 符号表在 index.tsv? 只有 FUN_ 名。用另一种方法: EXE RTTI 找类名 MemoryIStream
# 扫 .rdata: TypeDescriptor 名含 "MemoryIStream"
rdata = [s for s in secs if s[0]=='.rdata'][0]
off0, size = rdata[3], rdata[4]
buf = data[off0:off0+size]
for name in [b'MemoryIStream', b'BinaryIStream', b'BinaryOStream']:
    i = 0
    while True:
        j = buf.find(b'.?AV' + name + b'@@', i)
        if j < 0:
            j = buf.find(b'.?AV' + name, i)
            if j < 0:
                break
        td_va = rdata[1] + j - 16   # TypeDescriptor 起始 = name - 16
        print(f'{name.decode()}: TypeDescriptor @ {hex(td_va)}')
        # 找引用此 TD 的 COL
        pat = struct.pack('<I', 1) + struct.pack('<I', 0) + struct.pack('<I', td_va)
        k = 0
        while True:
            m = buf.find(pat, k)
            if m < 0:
                break
            col_va = rdata[1] + m
            # COL 被引用于 vtable-8 → 找 qword == col_va
            colq = struct.pack('<Q', col_va)
            w = 0
            while True:
                z = buf.find(colq, w)
                if z < 0:
                    break
                vt_va = rdata[1] + z + 8
                print(f'   COL @{hex(col_va)} → vtable @{hex(vt_va)}')
                # dump 槽位
                for slot in range(14):
                    v = rq(vt_va + slot*8)
                    print(f'      slot{slot} (+{hex(slot*8)}): {hex(v) if v else None}')
                w = z + 1
                break
            k = m + 1
        i = j + 1
