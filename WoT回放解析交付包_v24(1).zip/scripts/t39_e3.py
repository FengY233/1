#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
t39_e3.py — Task 39-e: 0x32/0x37 十场全量结构化（衔接 v5 帧格式）
1. v5 帧格式推广验证: [u32 len][u16 组件标签][u16 子标签][u8 01][u32 eid][嵌套流]
2. 嵌套子消息族普查（B级残留组成清单）
3. deathOrder 击杀链 10 场全量验证
4. f32 服务器时刻字段族确认
"""
import json, struct, sys, re
from collections import Counter, defaultdict

sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import REPLAYS, load_pkts

RB = [r for r in REPLAYS if r[0] != 'tundra_CN_942']

def collect(TY):
    out = []
    for tag, path in RB:
        for ty, clk, body in load_pkts(path):
            if ty == TY:
                out.append((tag, clk, body))
    return out

# ============ 1. 0x32 帧格式验证 ============
pk32 = collect(0x32)
print('0x32 n=%d' % len(pk32))
# 帧族: (子标签 u16, 标志 u8) 分布
fam = Counter(); eid_set = set()
comp = Counter()
for tag, clk, b in pk32:
    if len(b) < 13: fam['<13B'] += 1; continue
    (n,) = struct.unpack_from('<I', b, 0)
    oid, sub = struct.unpack_from('<HH', b, 4)
    flag = b[8]
    (eid,) = struct.unpack_from('<I', b, 9)
    eid_set.add(eid)
    fam[(sub, flag)] += 1
    comp[oid] += 1
print('帧族(sub,flag) top12:', [((hex(a), b), c) for (a, b), c in fam.most_common(12)])
print('eid 数:', len(eid_set))
print('组件标签(LE u16) top15:', [(hex(k), v) for k, v in comp.most_common(15)])

# 0x32 短消息(9B 载荷) 与 0x05 成对性
pair_ok = 0; pair_tot = 0
for tag, path in RB:
    pk = load_pkts(path)
    pend = set()
    for ty, clk, body in pk:
        if ty == 5:
            pend.add(struct.unpack_from('<I', body, 0)[0])
        elif ty == 0x32 and len(body) == 13:
            pair_tot += 1
            if struct.unpack_from('<I', body, 9)[0] in pend: pair_ok += 1
print('13B 短消息 eid ∈ 已创建集: %d/%d' % (pair_ok, pair_tot))

# ============ 2. 嵌套子消息族普查（body ≥1 的包） ============
print()
print('===== 嵌套子消息族（body 内容物） =====')
str_hits = Counter()
tlv_pat = Counter()
for tag, clk, b in pk32:
    if len(b) <= 13: continue
    body = b[13:]
    # 内嵌字符串 [u16 len][ascii] 或 [u8 len][ascii]
    for m in re.finditer(rb'[\x20-\x7e]{6,}', body):
        s = m.group(0)
        if 6 <= len(s) <= 40:
            str_hits[s[:36].decode('ascii', 'replace')] += 1
    # 82/83-87 82 族
    for m in re.finditer(rb'([\x82-\x88])\x82', body):
        tlv_pat[m.group(1)[0]] += 1
print('内嵌字符串 top25:')
for s, c in str_hits.most_common(25):
    print('   %-38r ×%d' % (s, c))
print('TLV 双字节族 [8X 82]:', {hex(k): v for k, v in sorted(tlv_pat.items())})

# ============ 3. deathOrder 10 场全量 ============
print()
print('===== deathOrder 击杀链（0x37） =====')
pk37 = collect(0x37)
kills = []
for tag, clk, b in pk37:
    if b'deathOrder' in b:
        i = b.index(b'deathOrder')
        kills.append((tag, clk, b[max(0, i - 12):i + 40].hex()))
print('deathOrder 包数:', len(kills))
for tag, clk, h in kills[:40]:
    print('  %-16s clk=%-11d %s' % (tag, clk, h))

# ============ 4. f32 服务器时刻族（0x37 尾） ============
print()
print('===== f32 服务器时刻字段族（0x37 尾 4B ≈ E 域） =====')
import struct as st
cnt = 0; tot = 0; per_tag = defaultdict(list)
for tag, clk, b in pk37:
    if len(b) >= 10:
        v = st.unpack_from('<f', b, len(b) - 4)[0]
        tot += 1
        if 1000.0 < abs(v) < 1000000.0:
            cnt += 1
            per_tag[tag].append(v)
print('尾4B 为 E 量级 f32: %d/%d' % (cnt, tot))
for tag in sorted(per_tag):
    v = per_tag[tag]
    print('  %-18s n=%4d  E域=[%.1f, %.1f]' % (tag, len(v), min(v), max(v)))

# 0x32 短消息与 0x05 重创建成对（AoI 重入视觉重建）
print()
n32_after05 = 0; n32 = 0
for tag, path in RB:
    pk = load_pkts(path)
    last05 = {}
    for i, (ty, clk, body) in enumerate(pk):
        if ty == 5: last05[struct.unpack_from('<I', body, 0)[0]] = i
        elif ty == 0x32 and len(body) == 13:
            n32 += 1
            eid = struct.unpack_from('<I', body, 9)[0]
            if eid in last05: n32_after05 += 1
print('13B 0x32 有同 eid 0x05 前驱: %d/%d' % (n32_after05, n32))
