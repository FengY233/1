#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
t37_decl.py — Task 37 ⑦：重建 Vehicle 全 76 属性声明序表 + 定位 0x24 的 decl 58/60/66/68
依据 decomp FUN_142a7bfa0→FUN_142a8e570: 首层位宽 = bitsRequired(desc+0xfc 字段)。
若 +0xfc = 全量属性数(76) → 7bit，0x24 索引 = 声明序（Vehicle.def 自身 + Implements 接口）。
输出: decl 序号 → (name, flags, 是否CS, 类型) 对照 0x24 观测 58/60/66/68。
"""
import sys, json
sys.path.insert(0, '/home/z/my-project/scripts')
from defparse import EntityDefParser

DEFS = '/tmp/wot_scripts/scripts/entity_defs'
p = EntityDefParser("/tmp/wot_scripts/scripts")
p.load()

# Vehicle 全属性声明序
veh = next((e for e in p.entities if e.name == 'Vehicle'), None)
print('Vehicle 对象:', type(veh))
props = veh.properties if hasattr(veh, 'properties') else veh.get('properties')
print('属性总数(声明序):', len(props))
cs_flags = ('ALL_CLIENTS', 'BASE_CLIENTS', 'CELL_PUBLIC')
rows = []
for i, pr in enumerate(props):
    name, flags = pr.name, pr.flags
    iscs = pr.is_client_server
    rows.append({'decl': i, 'name': name, 'flags': str(flags), 'cs': iscs,
                 'csi': pr.csi, 'type': str(pr.dt)[:48] if pr.dt is not None else '?'})
for r in rows:
    mark = ' ◀◀◀ 0x24 观测' if r['decl'] in (58, 60, 66, 68) else ''
    print(f"decl {r['decl']:2d} {r['name']:28s} {r['flags'][:28]:28s} CS={r['cs']}{mark}")
json.dump(rows, open('/tmp/wot/veh_decl_table.json', 'w'), ensure_ascii=False, indent=1)
print('\n已存 /tmp/wot/veh_decl_table.json')
