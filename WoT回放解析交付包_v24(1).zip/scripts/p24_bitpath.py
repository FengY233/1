#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
p24_bitpath.py — Task36①: 0x24 压缩路径位流验证（BigWorld readCompressedPathAndApply 同构）
协议(vanilla property_change_reader.cpp 白盒):
  BitReader MSB-first
  loop: [1 bit 下潜][bitsRequired(numProps) bits 子索引]  至 bit=0
  Single(isSlice=0): [bitsRequired(numProps) bits leafIndex]
  Slice (isSlice=1): [bitsRequired(numProps+1) bits start][同宽 end]
  剩余整字节 = 值
本验证: 顶层 numProps=76(Vehicle)/4?(AreaDestructibles)，首 index 分布 → 属性名
"""
import json
import struct
import sys
from collections import Counter

sys.path.insert(0, '/home/z/my-project/scripts')
from p05_decoder import REPLAYS, load_pkts  # noqa: E402


class BitReader:
    def __init__(self, data):
        self.d = data
        self.q = 0
        self.bits_left = 0
        self.byte = 0

    def get(self, n):
        ret = 0
        got = 0
        while got < n:
            if self.bits_left == 0:
                self.byte = self.d[self.q]
                self.q += 1
                self.bits_left = 8
            take = min(n - got, self.bits_left)
            ret = (ret << take) | (self.byte >> (8 - take))
            self.byte = (self.byte << take) & 0xFF
            self.bits_left -= take
            got += take
        return ret


def bits_required(n):
    if n <= 1:
        return 0
    n -= 1
    b = 0
    while n > 1:
        n >>= 1
        b += 1
    return b + 1


def main():
    veh76 = json.load(open(
        '/home/z/my-project/download/data_v18/Vehicle声明序全表_76属性.json'))
    idx2name = {p['decl']: p['name'] for p in veh76}
    p05 = json.load(open('/tmp/wot/p05_decoded.json'))
    eid2type = {r['eid']: (r['typeName'], r['typeID']) for r in p05}

    # 每实体类型的全属性数（已知: Vehicle=76; AreaDestructibles def 4 属性?）
    NPROPS = {'Vehicle': 76, 'AreaDestructibles': 4, 'NetworkEntity': 5,
              'TeamInfo': 4, 'AvatarInfo': 1, 'DetachedTurret': 5,
              'DebugDrawEntity': 1}

    top_idx = Counter()        # (typeName, isSlice) → 首 index 分布
    depth_cnt = Counter()
    bad = 0
    samples = []
    for tag, path in REPLAYS:
        pkts = load_pkts(path)
        for ty, c, pl in pkts:
            if ty != 0x24 or len(pl) < 10:
                continue
            eid, = struct.unpack_from('<I', pl, 0)
            is_slice = pl[4]
            body = pl[9:]
            tn, tid = eid2type.get(eid, ('?', -1))
            n = NPROPS.get(tn)
            if not n:
                continue
            try:
                br = BitReader(body)
                # 顶层
                if br.get(1) == 0:
                    # 直接顶层叶子
                    idx = br.get(bits_required(n))
                    top_idx[(tn, is_slice, idx)] += 1
                    depth_cnt[(tn, 'depth0')] += 1
                    continue
                idx = br.get(bits_required(n))
                top_idx[(tn, is_slice, idx)] += 1
                # 尝试继续下潜（未知子 owner 大小，只统计一层）
                depth_cnt[(tn, 'depth1+')] += 1
                if len(samples) < 30 and tn == 'Vehicle':
                    samples.append((eid, is_slice, idx, body[:24].hex()))
            except IndexError:
                bad += 1
    print(f'overrun {bad}')
    print('\n== (类型, isSlice, 首index) top40 ==')
    for (tn, sl, idx), n in top_idx.most_common(40):
        nm = idx2name.get(idx, '?') if tn == 'Vehicle' else ''
        print(f'  {tn:18s} slice={sl} idx={idx:3d} {nm:28s} n={n}')
    print('\n== Vehicle 样本 (eid, slice, idx, body) ==')
    for s in samples[:12]:
        print('  ', s)


if __name__ == '__main__':
    main()
