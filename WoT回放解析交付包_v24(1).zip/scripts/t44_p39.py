#!/usr/bin/env python3
"""t44_p39.py — 用 0x39 真实载荷验证 FUN_140e5c6f0 消息循环语法
循环: [u8 X][3B: b0 b1 b2] → msgID=(b1<<8)|b2, class=b1, extra=b0
     逐条吃 body 由 class 处理器决定 —— 先看 X 的值域与边界假设
"""
import struct, sys
sys.path.insert(0, '/home/z/my-project/scripts')
from survey_new_replays import load
from collections import Counter

# 0x39 只在 EU 场出现 —— 找一个 EU 场
import glob
for f in sorted(glob.glob('/tmp/wot/github_test/*.wotreplay')):
    blocks, declared, slen, pkts = load(f)
    p39 = [(i, c, p) for i, (t, c, p) in enumerate(pkts) if t == 0x39]
    if p39:
        print(f'== {f.split("/")[-1]}: 0x39×{len(p39)}')
        for i, c, p in p39[:8]:
            print(f'  pkt#{i} clk={c} len={len(p)}: {p.hex(" ")}')
        if len(p39) > 3:
            break

# 0x38 也看下
for f in sorted(glob.glob('/tmp/wot/github_test/*.wotreplay')):
    blocks, declared, slen, pkts = load(f)
    p38 = [(i, c, p) for i, (t, c, p) in enumerate(pkts) if t == 0x38]
    if p38:
        print(f'\n== 0x38 in {f.split("/")[-1]}: ×{len(p38)}')
        for i, c, p in p38[:4]:
            print(f'  pkt#{i} clk={c} len={len(p)}: {p.hex(" ")}')
        break
