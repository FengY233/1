#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
t37_alias2.py — Task 37 ①修正版：完整下钻 alias 类型树
alias 形态: <OWN_VEHICLE_POSITION><Type>FIXED_DICT</Type><FixedDict>...</FixedDict></...>
另: Vehicle 的 perks/perkEffects 疑似来自 Perks_Vehicle 接口，一并提取。
"""
import sys, json
sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file

DEFS = '/tmp/wot_scripts/scripts/entity_defs'

def sval(sec):
    try: return sec.data_str if hasattr(sec, 'data_str') else (sec.data if isinstance(sec.data, str) else sec.data.decode('utf8', 'replace'))
    except Exception: return str(sec.data)

def dump(sec, depth=0):
    """递归结构化 BWXML 节点"""
    n = {'n': sec.name}
    kids = list(sec.children)
    if not kids:
        n['v'] = sval(sec)
        return n
    if sec.name in ('FixedDict', 'Array', 'Tuple'):
        n['v'] = sval(sec) if sval(sec) else None
    else:
        n['v'] = sval(sec) or None
    n['c'] = []
    for k in kids:
        if k.name in ('databaseLen', 'AllowNone', 'Types'):
            n[k.name] = sval(k) or True
            # Types 是 BigWorld 新式类型表
            if k.name == 'Types':
                n['Types'] = [sval(g) for g in k.children]
            continue
        if sec.name == 'FixedDict' and k.name == 'property':
            fn = sval(k)
            f = {'f': fn, 'c': []}
            for g in k.children:
                f['c'].append(dump(g, depth+1))
            n['c'].append(f)
            continue
        n['c'].append(dump(k, depth+1))
    if not n.get('c') and not any(k in n for k in ('databaseLen','AllowNone','Types')):
        del n['c']
    return n

alias_sec = decode_file(DEFS + '/alias.xml', 'alias.xml')
targets = ['OWN_VEHICLE_POSITION', 'INSPIRED_EFFECT', 'INSPIRING_EFFECT',
           'PERK_EFFECTS', 'PERKS', 'PERK_INFO_HUD', 'BUFF_EFFECT']
res = {}
for c in alias_sec.children:
    if c.name in targets:
        res[c.name] = dump(c)

# Perks_Vehicle 接口
try:
    pk = decode_file(DEFS + '/Perks_Vehicle.def', 'Perks_Vehicle.def')
    pkres = {}
    for c in pk.children:
        if c.name == 'Properties':
            for p in c.children:
                if p.name in ('perks', 'perkEffects'):
                    pkres[p.name] = dump(p)
    res['_Perks_Vehicle'] = pkres
except Exception as e:
    res['_Perks_Vehicle'] = str(e)

print(json.dumps(res, ensure_ascii=False, indent=1)[:9000])
