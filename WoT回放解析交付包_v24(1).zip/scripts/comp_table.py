#!/usr/bin/env python3
"""comp_table.py — 全局组件属性表 v2: CS 过滤 + 组件内 streamSize 排序
idx = 50 + Σ(前序组件 CS 属性数) + 组件内 csi
顺序候选: dynamic_first / static_first
"""
import os, sys, json
sys.path.insert(0, '/home/z/my-project/scripts')
from bwxml import decode_file

CDIR = '/tmp/wot_scripts/scripts/component_defs'

# FLAG: ALL_CLIENTS / OWN_CLIENTS / CELL_PUBLIC 等 -> CS
CS_FLAGS = {'ALL_CLIENTS', 'OWN_CLIENTS'}


def get_flags(sec):
    for cc in sec.children:
        if cc.name == 'Flags':
            return cc.asString()
    return None


def parse_comp_props(comp):
    """返回 (cs_count, [(name, kind, size)]) 声明序"""
    path = os.path.join(CDIR, comp + '.def')
    if not os.path.exists(path):
        return 0, []
    try:
        sec = decode_file(path)
    except Exception:
        return 0, []
    props = None
    for c in sec.children:
        if c.name == 'Properties':
            props = c
            break
    out = []
    if props is None:
        return 0, []
    for c in props.children:
        f = get_flags(c)
        if f not in CS_FLAGS:
            continue
        # 类型粗判
        tsec = None
        for cc in c.children:
            if cc.name == 'Type':
                tsec = cc
                break
        kind, size = '?', -1
        if tsec is not None:
            ch = tsec.children
            if ch:
                k = ch[0].name
                if k in ('UINT8', 'INT8', 'BOOL'):
                    kind, size = k, 1
                elif k in ('UINT16', 'INT16'):
                    kind, size = k, 2
                elif k in ('UINT32', 'INT32', 'FLOAT32'):
                    kind, size = k, 4
                elif k in ('UINT64', 'INT64', 'FLOAT64'):
                    kind, size = k, 8
                elif k == 'VECTOR3':
                    kind, size = k, 12
                elif k in ('ARRAY', 'TUPLE', 'STRING', 'PYTHON', 'BLOB', 'UNICODE_STRING'):
                    kind, size = k, -1
                else:
                    kind, size = k, -1  # alias/FD
            else:
                kind, size = tsec.asString(), -1
        out.append((c.name, kind, size))
    return len(out), out


def build(order):
    root = decode_file('/tmp/wot_scripts/scripts/components.xml')
    sc = [c.name for c in root.children[0].children]
    dc = [c.name for c in root.children[1].children]
    seq = (sc + dc) if order == 'static_first' else (dc + sc)
    table = []
    base = 50
    for comp in seq:
        n, props = parse_comp_props(comp)
        table.append({'comp': comp, 'base': base, 'n': n, 'props': props})
        base += n
    return table, base


for order in ('dynamic_first', 'static_first'):
    t, top = build(order)
    total = sum(x['n'] for x in t)
    print(f'== {order}: CS 属性总数={total}, idx 上限={top}')
    # 观测 idx 204-208, 68, 76, 127, 113, 13, 174, 47, 58, 60
    obs = [13, 47, 58, 60, 68, 76, 113, 127, 174, 203, 204, 205, 206, 207, 208]
    for want in obs:
        for x in t:
            if x['base'] <= want < x['base'] + max(x['n'], 1) and x['n'] > 0:
                li = want - x['base']
                pn = x['props'][li][0] if li < len(x['props']) else '?'
                print(f'  idx={want}: {x["comp"]}.{pn} (base={x["base"]}, local={li})')
                break
    print()
