#!/usr/bin/env python3
"""Task 33-a2: 11场 vehicles 名册汇总 → 十一级车(后置进度)分布矩阵
vehPostProgression 值分布 / 车型 / prestige / maxHP → 0x05 载荷关联的外部锚"""
import json
from collections import defaultdict, Counter

d = json.load(open('/tmp/wot/block0_full.json'))

rows = []          # (replay, build, name, vehicleType, vpp, prestige, hp, team)
vpp_counter = Counter()
vt_counter = Counter()
for fn, hdr in d.items():
    build = hdr['clientVersionFromXml'].split('#')[-1].strip()
    for sid, v in hdr.get('vehicles', {}).items():
        vpp = v.get('vehPostProgression')
        rows.append((fn[:26], build, v.get('name'), v.get('vehicleType'),
                     json.dumps(vpp), v.get('prestigeLevel'), v.get('maxHealth'),
                     v.get('team')))
        vpp_counter[json.dumps(vpp)] += 1
        vt_counter[v.get('vehicleType')] += 1

print("== 车型分布（11场 330 车） ==")
for vt, c in vt_counter.most_common():
    print("  %-32s %d" % (vt, c))
print("\n== vehPostProgression 值分布 ==")
for val, c in vpp_counter.most_common():
    print("  %-40s %d" % (val, c))

print("\n== 各场后置进度车数量/比例 ==")
per = defaultdict(lambda: [0, 0])
for r in rows:
    key = (r[0], r[1])
    per[key][1] += 1
    if r[4] not in ('null', '[]'):
        per[key][0] += 1
for (fn, build), (nvpp, tot) in sorted(per.items()):
    print("  %-28s build#%-4s 后置进度车 %2d/%2d" % (fn, build, nvpp, tot))

# vpp 值的位分解探索
print("\n== vpp 值位模式 ==")
import struct
vals = set()
for r in rows:
    if r[4] not in ('null', '[]'):
        for x in json.loads(r[4]):
            vals.add(x)
for x in sorted(vals):
    print("  %d = 0x%08X  bin=%s" % (x, x, format(x, '032b')))

json.dump(rows, open('/tmp/wot/roster_matrix.json', 'w'), ensure_ascii=False)
print("\nsaved /tmp/wot/roster_matrix.json  rows=", len(rows))
