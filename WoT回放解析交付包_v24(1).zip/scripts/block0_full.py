#!/usr/bin/env python3
"""Task 33-a: 11场回放 block0 全字段提取 → CN942归属实证 + digest归属修正素材
block0 = [u32 json_len][json bytes]，提取全部字段（含嵌套），输出对照表。"""
import json, struct, os, glob

RD = '/tmp/wot/github_test'
out = {}
for fp in sorted(glob.glob(os.path.join(RD, '*.wotreplay'))):
    with open(fp, 'rb') as f:
        raw = f.read(12)
        n = struct.unpack('<I', raw[8:12])[0]  # [4B magic][u32 块数=2][u32 json长度]
        hdr = json.loads(f.read(n))
    out[os.path.basename(fp)] = hdr

# 全字段并集
allkeys = []
for h in out.values():
    for k in h:
        if k not in allkeys:
            allkeys.append(k)

print("字段并集(%d): %s" % (len(allkeys), allkeys))
print()
for fn, h in out.items():
    # 打印区分性字段（跳过大数组/长对象）
    row = {}
    for k in allkeys:
        v = h.get(k, None)
        if isinstance(v, (str, int, float, bool)) or v is None:
            s = str(v)
            row[k] = s if len(s) <= 60 else s[:57] + '...'
    print(fn)
    for k, v in row.items():
        print("   %-28s = %s" % (k, v))
    print()

json.dump(out, open('/tmp/wot/block0_full.json', 'w'), ensure_ascii=False, indent=1)
print("saved /tmp/wot/block0_full.json")
