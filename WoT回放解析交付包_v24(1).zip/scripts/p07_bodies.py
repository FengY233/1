#!/usr/bin/env python3
"""p07_bodies.py — 0x07 各 csi 键的 body 长度/样例 → 变长属性线编码字典
然后手工走通一个完整 0x05 Vehicle 载荷"""
import json, struct, zlib
from collections import Counter, defaultdict
from Crypto.Cipher import Blowfish

KEY = bytes([0xDE, 0x72, 0xBE, 0xA0, 0xDE, 0x04, 0xBE, 0xB1,
             0xDE, 0xFE, 0xBE, 0xEF, 0xDE, 0xAD, 0xBE, 0xEF])
RP = '/tmp/wot/github_test/20260912_1151_japan-J53_Ho_Ri_Shugo_01_karelia.wotreplay'


def load_pkts(path):
    data = open(path, 'rb').read()
    (magic, bc) = struct.unpack_from('<II', data, 0)
    pos = 8
    for _ in range(bc):
        (blen,) = struct.unpack_from('<I', data, pos)
        pos += 4 + blen
    pos += 8
    main = data[pos:]
    cipher = Blowfish.new(KEY, Blowfish.MODE_ECB)
    prev = b'\x00' * 8
    out = bytearray()
    for i in range(0, len(main) - 7, 8):
        d = cipher.decrypt(main[i:i + 8])
        d = bytes(a ^ b for a, b in zip(d, prev))
        prev = d
        out += d
    stream = zlib.decompress(bytes(out))
    pkts = []
    q = 0
    while q + 12 <= len(stream):
        size, ty, clock = struct.unpack_from('<III', stream, q)
        pkts.append((ty, clock, stream[q + 12:q + 12 + size]))
        q += 12 + size
    return pkts


def main():
    pkts = load_pkts(RP)
    eid2type = {}
    for ty, clk, pl in pkts:
        if ty == 5 and len(pl) >= 8:
            e, n = struct.unpack_from('<II', pl, 0)
            eid2type[e] = n
    bodies = defaultdict(list)
    for ty, clk, pl in pkts:
        if ty == 7 and len(pl) >= 12:
            e, key, blen = struct.unpack_from('<III', pl, 0)
            if eid2type.get(e) == 6 and len(pl) == 12 + blen:
                bodies[key].append(pl[12:])
    print('== Vehicle 0x07 各键 body 形态 ==')
    for key in sorted(bodies):
        bs = bodies[key]
        lens = Counter(len(b) for b in bs)
        ex = bs[0].hex() if bs else ''
        print(f'  key={key:2d} n={len(bs):5d} lens={dict(lens.most_common(5))} 例:{ex[:64]}')

    # 完整 0x05 载荷 dump(第一个)
    for ty, clk, pl in pkts:
        if ty == 5 and len(pl) >= 47 and struct.unpack_from('<I', pl, 4)[0] == 6:
            print(f'\n== 完整 0x05 载荷 len={len(pl)} ==')
            propBytes, = struct.unpack_from('<I', pl, 42)
            print(f'propBytes={propBytes} (46+{propBytes}={46+propBytes} == len? {46+propBytes==len(pl)})')
            print(f'[42:]={pl[42:].hex()}')
            break


if __name__ == '__main__':
    main()
