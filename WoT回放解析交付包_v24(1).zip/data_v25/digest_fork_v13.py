#!/usr/bin/env python3
"""digest_fork_v13.py — 静态组件属性并入 + 分块 csi + VLH 门修正

Task 43 决定性发现 (2026-09-25):
  1. build_parts 从未把 StaticComponents 挂载组件的【属性】并入实体记录
     —— Avatar 少 4 (AvatarInBattleVehicleSwitch: vehicleSpawnList/isVehicleConfirmed/
        spawnInfoForVehicle/spawnPoints), TeamInfo 少 3 (capturedPoints/statuses/positions)
     —— 0x05 运行时铁证 (TeamInfo idx1-3 pickle) + csi_tables_v9 权威表双重确认
  2. csi 分配是【分块式】: 自有 CS 排序块 0..N-1, 各挂载组件排序块接 running baseIndex
     —— Avatar isVehicleConfirmed(U8) 在 csi 28 (非 13) 铁证分块
  3. VLH 门与排序用的 streamSize = getServerToClientStreamSize:
     变长 = -vlh (AllowNone FD 亦变长!) —— spawnInfoForVehicle(FD?, vlh=2) ss=-2
     —— 语料 p.stream_size() 对 AllowNone FD 返回正数 → VLH 漏喂 4 字节
"""
import sys, os, time, hashlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bwxml import decode_file
from defparse import Property
from digest_fork_v2 import (SCRIPTS, CD, CLI, TARGET, _has_script,
                            DefLocator, parse_comp_record, load_static_comp,
                            parse_space_record, iter_extensions,
                            parse_ext_entities, parse_ext_dyncomps)
from digest_fork_v7 import build_parts as build_parts_v7
from digest_fork_v12 import emit as emit_v12, type_bytes


# ---------------- VLH/排序用 streamSize (getServerToClientStreamSize 语义) ----------------
def gsc_stream_size(p):
    ss = p.stream_size()          # defparse: 变长 → -vlh; 定长 → 字节数
    if ss >= 0 and p.dt.kind == 'FIXED_DICT' and p.dt.allow_none:
        return -p.var_len_header  # ★ AllowNone FD = 变长 -vlh (spawnInfoForVehicle ss=-2 铁证)
    return ss


def sort_key(p, decl_idx):
    ss = gsc_stream_size(p)
    return ((0, ss) if ss >= 0 else (1, -ss), decl_idx)


def realloc_csi_blocks(ed):
    """分块式: 自有排序块 + 各组件排序块 (running baseIndex)"""
    cmap = getattr(ed, '_comp_prop_map', {})   # idx -> comp name
    own = [(i, p) for i, p in enumerate(ed.properties)
           if p.is_client_server and i not in cmap]
    own.sort(key=lambda ip: sort_key(ip[1], ip[0]))
    base = 0
    for i, _ in own:
        ed.properties[i].csi = base
        base += 1
    for sd in getattr(ed, 'fork_components', []):
        comp = [(i, p) for i, p in enumerate(ed.properties)
                if cmap.get(i) == sd.name and p.is_client_server]
        comp.sort(key=lambda ip: sort_key(ip[1], ip[0]))
        for i, _ in comp:
            ed.properties[i].csi = base
            base += 1


def merge_static_props(parser, ed):
    """把挂载静态组件的 Properties 并入 ed.properties (声明序追加, 挂载序)"""
    added = 0
    cmap = {}
    for sd in getattr(ed, 'fork_components', []):
        path = os.path.join(CD, sd.name + '.def')
        if not os.path.exists(path):
            continue
        sec = decode_file(path, sd.name + '.def')
        props = sec.child('Properties')
        if props is None:
            continue
        for c in props.children:
            p = parser._parse_property(c)
            if p is None:
                continue
            cmap[len(ed.properties)] = sd.name
            p.index = len(ed.properties)
            ed.properties.append(p)
            added += 1
    ed._comp_prop_map = cmap
    return added


def emit(records, cfg):
    """v12 精确字节模型 + VLH 门改用 gsc_stream_size"""
    mailbox_bytes, method_vlh_ifc, comp_first = cfg

    def TB(dt):
        if dt.kind == 'MAILBOX' and mailbox_bytes:
            return b'MailBox\x00'
        return type_bytes(dt)

    def _u32(v):
        return int(v).to_bytes(4, 'little', signed=True) if v < 0 else int(v).to_bytes(4, 'little')

    def feed_method(out, m, idx):
        ss = m._stream_size
        if m.var_len_header != 1 and ss < 0:
            if not method_vlh_ifc or m.is_for_client:
                out += _u32(m.var_len_header)
        out += m.name.encode()
        out.append(m.flags & 0xff)
        for a in m.args:
            out += TB(a)
        for r in getattr(m, 'retvals', ()) or ():
            out += TB(r)
        out += _u32(idx)

    out = bytearray()
    for ed in records:
        out += ed.name.encode()
        for p in ed.properties:
            if not p.is_client_server:
                continue
            out += _u32(p.csi)
            if gsc_stream_size(p) < 0 and p.var_len_header != 1:   # ★ 修正后的门
                out += _u32(p.var_len_header)
            out += p.name.encode()
            out += _u32(p.flags & 0x5F)
            out.append(getattr(p, 'is_volatile', 0) & 0xff)
            out += TB(p.dt)
        comps = list(getattr(ed, 'fork_components', []))
        for domain in (2, 1, 4):
            attr = {2: 'client_methods', 1: 'base_methods', 4: 'cell_methods'}[domain]
            own = list(getattr(ed, attr, []))
            cmps = [m for sd in comps for m in getattr(sd, attr, [])]
            seq = (cmps + own) if comp_first else (own + cmps)
            if domain == 2:
                idx = 0
                for m in seq:
                    if m.flags & 0xC:
                        feed_method(out, m, idx)
                    idx += 1
            else:
                idx = 0
                for m in seq:
                    if m.flags & 0xC:
                        feed_method(out, m, idx)
                        idx += 1
    return bytes(out)


def build_parts_v13():
    """v7 记录集 + 静态组件属性并入 + 分块 csi 重排"""
    from defparse import EntityDefParser
    parser = EntityDefParser(SCRIPTS)
    parser.load()
    space, main_ents, ext_ents, main_dyn, ext_dyn = build_parts_v7()
    # 主实体: 并入静态组件属性 + csi 分块重排
    n_merged = 0
    for ed in main_ents:
        if getattr(ed, 'fork_components', None):
            n_merged += merge_static_props(parser, ed)
        realloc_csi_blocks(ed)
    # 扩展实体/组件记录: 无静态挂载 (ofEntity 只在主树), 重排一次保序
    for ed in ext_ents + main_dyn + ext_dyn:
        realloc_csi_blocks(ed)
    return (space, main_ents, ext_ents, main_dyn, ext_dyn), n_merged, parser


def main():
    t0 = time.time()
    (space, main_ents, ext_ents, main_dyn, ext_dyn), n_merged, parser = build_parts_v13()
    print(f'并入静态组件属性 {n_merged} 个  ({time.time()-t0:.1f}s)')
    # 抽查 Avatar/TeamInfo
    for nm in ['Avatar', 'TeamInfo']:
        ed = [r for r in main_ents if r.name == nm][0]
        cmap = getattr(ed, '_comp_prop_map', {})
        cs = [(p.csi, p.name, cmap.get(i, '-')) for i, p in enumerate(ed.properties) if p.is_client_server]
        cs.sort()
        print(f'{nm} CS 属性 {len(cs)}: 尾部={cs[-6:]}')
    print(f'[目标] {TARGET}')
    variants = [
        ('A 基线318', space + main_ents + ext_ents + main_dyn + ext_dyn),
        ('B 无扩展148', space + main_ents + main_dyn),
        ('C 仅扩实体158', space + main_ents + ext_ents + main_dyn),
        ('D 仅扩dyn308', space + main_ents + main_dyn + ext_dyn),
    ]
    import itertools
    cfgs = list(itertools.product((0, 1), (0, 1), (0, 1)))
    for label, recs in variants:
        for cfg in cfgs:
            d = hashlib.md5(emit(recs, cfg)).hexdigest().upper()
            if d == TARGET:
                print(f'★★★★★ 命中!!!! {label} cfg={cfg}')
                return
    print('仍未命中 — 继续: ', hashlib.md5(emit(variants[0][1], (0,0,0))).hexdigest().upper())


if __name__ == '__main__':
    main()
