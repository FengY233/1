#!/usr/bin/env python3
"""t43_exe.py — 942 客户端 EXE 分析底座 + MD5Calculator vtable 交叉验证
用法:
  python3 t43_exe.py info          # PE 基本信息 + 版本
  python3 t43_exe.py read <VA> <n> # 读原始字节
  python3 t43_exe.py verify        # 交叉验证另一 AI 的 MD5Calculator vtable 转储
  python3 t43_exe.py rtti <关键词>  # RTTI TypeDescriptor 扫描
"""
import sys, struct, re
import pefile

EXE = "/tmp/wot/wotexe/WorldOfTanks.exe"

_pe = None
def pe():
    global _pe
    if _pe is None:
        _pe = pefile.PE(EXE, fast_load=True)
        _pe.parse_data_directories(
            directories=[pefile.DIRECTORY_ENTRY['IMAGE_DIRECTORY_ENTRY_RESOURCE']])
    return _pe

def va2off(va):
    """VA -> 文件偏移"""
    image_base = pe().OPTIONAL_HEADER.ImageBase
    rva = va - image_base
    for s in pe().sections:
        if s.VirtualAddress <= rva < s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (rva - s.VirtualAddress)
    return None

def off2va(off):
    image_base = pe().OPTIONAL_HEADER.ImageBase
    for s in pe().sections:
        if s.PointerToRawData <= off < s.PointerToRawData + s.SizeOfRawData:
            return image_base + s.VirtualAddress + (off - s.PointerToRawData)
    return None

def read(va, n):
    off = va2off(va)
    if off is None:
        return None
    with open(EXE, "rb") as f:
        f.seek(off)
        return f.read(n)

def qword(va):
    b = read(va, 8)
    return struct.unpack("<Q", b)[0] if b and len(b) == 8 else None

def cstr_at(va, maxlen=256):
    b = read(va, maxlen)
    if not b:
        return None
    z = b.find(b"\x00")
    return b[:z if z >= 0 else maxlen].decode("utf-8", "replace")

def cmd_info():
    p = pe()
    print(f"Machine: {hex(p.FILE_HEADER.Machine)} (0x8664=x64)")
    print(f"ImageBase: {hex(p.OPTIONAL_HEADER.ImageBase)}")
    print(f"SizeOfImage: {hex(p.OPTIONAL_HEADER.SizeOfImage)}")
    print(f"Sections:")
    for s in p.sections:
        print(f"  {s.Name.decode().rstrip(chr(0)):10s} VA={hex(p.OPTIONAL_HEADER.ImageBase + s.VirtualAddress):>14s} "
              f"VSz={hex(s.Misc_VirtualSize):>10s} RawSz={hex(s.SizeOfRawData):>10s} off={hex(s.PointerToRawData):>10s} chr={hex(s.Characteristics)}")
    # 版本资源
    try:
        for fi in p.FileInfo:
            for entry in fi:
                if entry.Key == b"StringFileInfo":
                    for st in entry.StringTable:
                        for k, v in st.entries.items():
                            print(f"  VER {k.decode()}: {v.decode()}")
    except Exception as e:
        print("  (no version info)", e)

def cmd_read(va, n):
    b = read(va, n)
    print(f"[{hex(va)}] ({va2off(va)}) {len(b) if b else 0} bytes")
    if b:
        for i in range(0, len(b), 16):
            row = b[i:i+16]
            hexs = " ".join(f"{c:02x}" for c in row)
            print(f"  {va+i:+#x} {hexs}")

def cmd_verify():
    """交叉验证另一 AI 的 MD5Calculator vtable 转储"""
    print("=== 验证 §一 原始字节表 @0x1439230B0 (136 bytes) ===")
    b = read(0x1439230B0, 136)
    if not b:
        print("读取失败!"); return
    expect = [
        (0x1439230B0, 0x143EA00A8, "COL(MD5Calculator)"),
        (0x1439230B8, 0x142A9B580, "slot0  dtor"),
        (0x1439230C0, 0x1402F7290, "slot1  empty"),
        (0x1439230C8, 0x1402F7290, "slot2  empty"),
        (0x1439230D0, 0x1402F7290, "slot3  empty"),
        (0x1439230D8, 0x1402F7290, "slot4  empty"),
        (0x1439230E0, 0x1403E8290, "slot5  upd u32"),
        (0x1439230E8, 0x1403E8260, "slot6  upd u16"),
        (0x1439230F0, 0x1403E8230, "slot7  upd u8"),
        (0x1439230F8, 0x1403E8290, "slot8  upd u32"),
        (0x143923100, 0x1403E8260, "slot9  upd u16"),
        (0x143923108, 0x1403E8230, "slot10 upd u8"),
        (0x143923110, 0x1403E8230, "slot11 upd u8"),
        (0x143923118, 0x1403E8210, "slot12 upd str"),
        (0x143923120, 0x1403E81E0, "slot13 upd cstr"),
        (0x143923128, 0x1402ED600, "slot14 digest"),
        (0x143923130, 0x143EA0180, "COL(AbstractMD5Visitor)"),
    ]
    ok = 0
    for va, exp, name in expect:
        got = qword(va)
        mark = "✓" if got == exp else f"✗ got {hex(got) if got else None}"
        if got == exp: ok += 1
        print(f"  {hex(va)}  {name:26s} expect={hex(exp)}  {mark}")
    print(f"\n命中 {ok}/{len(expect)}")
    # 基类表
    print("=== 基类 IMD5Calculator vtable @0x143923038 ===")
    got = qword(0x143923038)
    print(f"  COL = {hex(got) if got else None} (expect 0x143EA0030)")
    for i in range(15):
        p = qword(0x143923040 + i*8)
        print(f"  slot{i:2d} {hex(0x143923040+i*8)} -> {hex(p) if p else None}")
    # RTTI 名验证
    print("=== RTTI 名 ===")
    for col_va, nm in [(0x143EA00A8, "MD5Calculator"), (0x143EA0030, "IMD5Calculator"), (0x143EA0180, "AbstractMD5Visitor")]:
        td = qword(col_va + 12) if read(col_va, 16) else None
        if td:
            name = cstr_at(td + 16)
            print(f"  COL {hex(col_va)} -> TD {hex(td)} .?AV{name} (expect contains {nm})")

def cmd_rtti(keyword):
    """全 .rdata 扫描 .?AV...TypeDescriptor 名"""
    p = pe()
    pat = f".?AV{keyword}".encode()
    hits = []
    with open(EXE, "rb") as f:
        data = f.read()
    for m in re.finditer(re.escape(pat), data):
        va = off2va(m.start())
        if va:
            z = data[m.start():m.start()+200].find(b"\x00")
            full = data[m.start():m.start()+z].decode("utf-8", "replace")
            hits.append((va, full))
    for va, full in hits:
        print(f"  TD-name @ {hex(va)}  {full}")
    # 对每个 TD 名位置，找 COL (TD 位于 TypeDescriptor+16)，再找指向 COL 的 vtable
    for td_name_va, full in hits:
        td_va = td_name_va - 16  # TypeDescriptor: vptr(8) + spare(8) + name
        # 扫描 .rdata 中指向 td_va+0? COL 结构: sig(4)+offset(4)+cdOffset(4)+pTypeDescriptor(4)+pHierarchy(4)
        # COL+12 = pTypeDescriptor (32位 RVA 在 EXE 内是 VA? MSVC RTTI 用 32 位偏移)
        # 此 EXE 是 x64, RTTI COL 的 pTypeDescriptor 是 32 位偏移还是完整 VA? 大文件用 VA 截断为 32 位
        td_low = td_va & 0xFFFFFFFF
        with open(EXE, "rb") as f:
            data = f.read()
        import struct as st
        col_hits = []
        for m in re.finditer(st.pack("<I", td_low), data):
            off = m.start()
            # 检查前置 sig=1
            if off >= 12:
                pre = st.unpack("<I", data[off-12:off-8])[0]
                if pre == 1:
                    va = off2va(off - 12)
                    if va:
                        col_hits.append(va)
        for col_va in col_hits[:6]:
            # 找 .rdata 中 qword == col_va 的位置 => vtable 表头(槽-1)
            col_va_full = (td_va & 0xFFFFFFFF00000000) | col_va if col_va < 0x100000000 else col_va
            vt_heads = []
            for m in re.finditer(st.pack("<Q", col_va_full), data):
                va = off2va(m.start())
                if va:
                    vt_heads.append(va)
            print(f"  TD {hex(td_va)} ({full}) -> COL {[hex(c) for c in col_hits[:4]]} -> vtable-heads {[hex(v) for v in vt_heads[:6]]}")

if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "info"
    if cmd == "info":
        cmd_info()
    elif cmd == "read":
        cmd_read(int(sys.argv[2], 16), int(sys.argv[3], 0))
    elif cmd == "verify":
        cmd_verify()
    elif cmd == "rtti":
        cmd_rtti(sys.argv[2])
