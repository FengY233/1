#!/usr/bin/env python3
"""t43_visitor.py — 定位并解剖 ClientServerTypesMD5Visitor vtable（digest 攻坚核心）
步骤:
  1. 修正版 RTTI 扫描 (x64 COL: pTypeDescriptor 是 32 位 RVA)
  2. 反汇编 FUN_142a9b5b0 确认安装的 vtable 地址
  3. dump visitor 全部槽 + 反汇编槽 1-4
"""
import sys, struct, re
import capstone
from t43_exe import pe, read, qword, va2off, off2va, cstr_at

EXE = "/tmp/wot/wotexe/WorldOfTanks.exe"
IMAGE_BASE = 0x140000000

def u32(va):
    b = read(va, 4)
    return struct.unpack("<I", b)[0] if b and len(b) == 4 else None

def td_name_from_col(col_va):
    """COL -> TypeDescriptor -> 类名 (x64: pTypeDescriptor@COL+12 是 32 位 RVA)"""
    rva = u32(col_va + 12)
    if rva is None or rva == 0 or rva > pe().OPTIONAL_HEADER.SizeOfImage:
        return None
    td_va = IMAGE_BASE + rva
    return cstr_at(td_va + 16), td_va

def scan_rtti_names(pattern):
    """在 .rdata/.data 扫 .?AV<pattern>... TypeDescriptor 名, 返回 [(td_va, name)]"""
    with open(EXE, "rb") as f:
        data = f.read()
    out = []
    for m in re.finditer(pattern.encode(), data):
        va = off2va(m.start())
        if va is None:
            continue
        z = data[m.start():m.start()+200].find(b"\x00")
        name = data[m.start():m.start()+z].decode("utf-8", "replace")
        out.append((va - 16, name, va))  # td_va, name, name_va
    return out

def find_cols_for_td(td_va):
    """找所有 COL: 其 +12 处 u32 RVA == td_va - IMAGE_BASE"""
    rva = td_va - IMAGE_BASE
    with open(EXE, "rb") as f:
        data = f.read()
    cols = []
    for m in re.finditer(re.escape(struct.pack("<I", rva)), data):
        off = m.start() - 12
        if off < 0:
            continue
        if struct.unpack("<I", data[off:off+4])[0] == 1:  # sig=1
            va = off2va(off)
            if va:
                cols.append(va)
    return cols

def find_vtables_for_col(col_va):
    """找 .rdata 中 qword==col_va 的位置 => vtable 表头(COL 槽)"""
    with open(EXE, "rb") as f:
        data = f.read()
    vts = []
    for m in re.finditer(re.escape(struct.pack("<Q", col_va)), data):
        va = off2va(m.start())
        if va:
            vts.append(va)
    return vts

md = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_64)
md.detail = False

def disasm(va, n=120, max_instr=60):
    code = read(va, n)
    if not code:
        print(f"  [{hex(va)}] 读取失败")
        return
    cnt = 0
    for ins in md.disasm(code, va):
        print(f"    {hex(ins.address)}  {ins.mnemonic:<8s} {ins.op_str}")
        cnt += 1
        if cnt >= max_instr:
            break

def resolve_rip_target(ins):
    """解析 lea/mov rip 相对寻址目标"""
    import capstone
    if 'rip' in ins.op_str:
        try:
            ops = ins.op_str.split(', ')
            for op in ops:
                if op.startswith('[rip'):
                    m = re.search(r'\[rip ([+-]) (0x[0-9a-f]+)\]', op)
                    if m:
                        d = int(m.group(2), 16)
                        if m.group(1) == '-':
                            d = -d
                        return ins.address + ins.size + d
        except Exception:
            pass
    return None

def main():
    print("=" * 70)
    print("STEP 1: RTTI 扫描 *MD5Visitor* / *MD5* 类")
    print("=" * 70)
    for pat in [r"\.\?AV[A-Za-z0-9_]*MD5Visitor[A-Za-z0-9_@]*", r"\.\?AV[A-Za-z0-9_]*MD5[A-Za-z0-9_@]*"]:
        for td_va, name, _ in scan_rtti_names(pat):
            print(f"  TD {hex(td_va)}  {name}")

    print()
    print("=" * 70)
    print("STEP 2: 反汇编 FUN_142a9b5b0 (visitor 安装点)")
    print("=" * 70)
    disasm(0x142a9b5b0, 200, 70)

    print()
    print("=" * 70)
    print("STEP 3: 对每个 MD5Visitor TD -> COL -> vtable 全链")
    print("=" * 70)
    for pat in [r"\.\?AV[A-Za-z0-9_]*Visitor[A-Za-z0-9_@]*MD5[A-Za-z0-9_@]*", r"\.\?AVClientServer[A-Za-z0-9_@]*"]:
        for td_va, name, _ in scan_rtti_names(pat):
            cols = find_cols_for_td(td_va)
            for col in cols:
                vts = find_vtables_for_col(col)
                print(f"  {name}")
                print(f"    TD {hex(td_va)} -> COL {hex(col)} -> vtable-head(s) {[hex(v) for v in vts]}")
                for vt in vts:
                    # dump 槽直到看起来越界(指向非 .text)
                    print(f"    --- vtable @ {hex(vt)} (slot0 @ {hex(vt+8)}) ---")
                    for i in range(24):
                        p = qword(vt + 8 + i*8)
                        if p is None:
                            break
                        in_text = 0x140001000 <= p < 0x140001000 + 0x35b352c
                        looks_col = p and 0x1435b5000 <= p < 0x1442d60be and u32(p) == 1 if p else False
                        tag = "TEXT" if in_text else ("COL?" if looks_col else "???")
                        print(f"      slot{i:2d} {hex(vt+8+i*8)} -> {hex(p)} [{tag}]")
                        if not in_text:
                            break

if __name__ == "__main__":
    main()
