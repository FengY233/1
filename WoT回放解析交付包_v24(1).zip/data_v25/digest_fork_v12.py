#!/usr/bin/env python3
"""digest_fork_v12.py — ★EXE 白盒终局版：精确字节模型（2026-09-25 Task 43）

依据 (WorldOfTanks.exe 逐字节验证 + decomp 全链):
  [调用链] EntityType::init → FUN_142a9b640(栈上96B MD5Calculator, 回调, finalize)
           → FUN_142a9b5b0(栈对象S={CSMD5Visitor vptr, inner=calc, bool}, walker)
           → FUN_142a9b410(0x328步长遍历, slot7=+0x87 canBeOnClient 过滤)
           → FUN_142a93420(per-entity: 属性/client方法/base方法/cell方法)
  [喂入真相] MD5Calculator 槽1-4=空钩子/纯虚 ⇒ 一切 slot3 域标记零字节!
           slot5/8=update(u32) 仅 r8d 值入哈希, rdx 标签被覆盖丢弃
           slot10/11=update(u8), slot12=BW::string 无NUL, slot13=cstr 含NUL
  [属性序] u32(csi) → [u32(vlh) 若 ss<0&&vlh!=1] → name(无NUL) → u32(flags&0x5F)
           → u8(isVolatile) → 类型序列化
  [方法序] [u32(vlh)?] → name(无NUL) → u8(flags) → arg类型们 → retval类型们 → u32(idx)
           client域: 计数器数全部方法(喂入仅 flags&0xC), base/cell域: 预过滤+重置计数
  [类型层] "Int\0"/"Uint\0"+u32(size) / "Float\0" / "Float64\0" / "Vector\0"+u32(n)
           "String\0" / "Python\0" / "UnicodeString\0" / "Blob\0" / "User\0"+mod+inst
           "UserDataObjectLinkDataType\0" / "Array\0"/"Tuple\0"+u32(seq)+[u32(dbLen)]
           "FixedDict\0"+mod+inst+u8(allowNone)+每字段{name+类型}
           ★MAILBOX = 零字节 (UnsupportedDataType::addToMD5 = 错误日志路径)
  [实体头] 仅 slot12(name) 无NUL; 域标记 "properties"/"xxxMethods" 全部零字节
"""
import sys, os, itertools, hashlib, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from digest_fork_v2 import TARGET
from digest_fork_v7 import build_parts


def _u32(v):
    return int(v).to_bytes(4, 'little', signed=True) if v < 0 else int(v).to_bytes(4, 'little')


def type_bytes(dt):
    """fork 类型序列化 (逐函数反编译验证)"""
    k = dt.kind
    if k == 'INT':
        return (('Int' if dt.signed else 'Uint').encode() + b'\x00') + _u32(dt.size)
    if k == 'FLOAT':
        return b'Float\x00' if dt.size == 4 else b'Float64\x00'
    if k == 'VECTOR':
        return b'Vector\x00' + _u32(dt.n)
    if k == 'STRING':
        return b'String\x00'
    if k == 'UNICODE_STRING':
        return b'UnicodeString\x00'
    if k == 'BLOB':
        return b'Blob\x00'
    if k == 'PYTHON':
        return b'Python\x00'
    if k == 'MAILBOX':
        return b''                       # ★ UnsupportedDataType: 零字节
    if k == 'UDO_REF':
        return b'UserDataObjectLinkDataType\x00'
    if k == 'USER':
        return b'User\x00' + dt.module.encode() + dt.instance.encode()
    if k in ('ARRAY', 'TUPLE'):
        out = (b'Array\x00' if k == 'ARRAY' else b'Tuple\x00') + _u32(dt.seq_size)
        if dt.db_len > 0:
            out += _u32(dt.db_len)
        return out + type_bytes(dt.elem)
    if k == 'FIXED_DICT':
        # 启动期 isCustomClassImplInited_=false (0xb8==0) → 恒喂 mod/inst
        out = b'FixedDict\x00' + dt.module.encode() + dt.instance.encode()
        out += bytes((1 if dt.allow_none else 0,))
        for fname, ft in dt.fields:
            out += fname.encode() + type_bytes(ft)
        return out
    if k == 'CLASS':                     # 理论不进 CS 位, 防御性处理
        out = b'Class\x00' + bytes((1 if dt.allow_none else 0,))
        for fname, ft in dt.fields:
            out += fname.encode() + type_bytes(ft)
        return out
    raise ValueError(k)


def emit(records, cfg):
    """cfg = (mailbox_bytes, method_vlh_ifc, comp_first)
       mailbox_bytes: 0=零字节(fork真身) 1="MailBox\0"(旧vanilla式)
       method_vlh_ifc: 0=无条件(反编译真身) 1=仅 is_for_client
       comp_first: 0=自有方法在前组件在后 1=组件在前
    """
    mailbox_bytes, method_vlh_ifc, comp_first = cfg

    def TB(dt):
        if dt.kind == 'MAILBOX' and mailbox_bytes:
            return b'MailBox\x00'
        return type_bytes(dt)

    def feed_method(out, m, idx):
        ss = m._stream_size
        if m.var_len_header != 1 and ss < 0:
            if not method_vlh_ifc or m.is_for_client:
                out += _u32(m.var_len_header)
        out += m.name.encode()                       # slot12 无 NUL
        out.append(m.flags & 0xff)                   # slot10 u8
        for a in m.args:                             # 仅类型, 名字不喂
            out += TB(a)
        for r in getattr(m, 'retvals', ()) or ():   # 942 全空, 防御性保留
            out += TB(r)
        out += _u32(idx)                             # slot6 尾部 idx u32

    out = bytearray()
    for ed in records:
        out += ed.name.encode()                      # 实体名 slot12 无 NUL
        # ---- 属性域: 声明序, 门 = flags & 0x106 ----
        for p in ed.properties:
            if not p.is_client_server:
                continue
            out += _u32(p.csi)                       # +0x9c
            if p.stream_size() < 0 and p.var_len_header != 1:
                out += _u32(p.var_len_header)        # +0x58
            out += p.name.encode()                   # slot12 无 NUL
            out += _u32(p.flags & 0x5F)              # +0x78 & 0x5F
            out.append(getattr(p, 'is_volatile', 0) & 0xff)
            out += TB(p.dt)
        # ---- 方法三域 ----
        comps = list(getattr(ed, 'fork_components', []))
        for domain in (2, 1, 4):                     # client → base → cell
            attr = {2: 'client_methods', 1: 'base_methods', 4: 'cell_methods'}[domain]
            own = list(getattr(ed, attr, []))
            cmps = [m for sd in comps for m in getattr(sd, attr, [])]
            seq = (cmps + own) if comp_first else (own + cmps)
            if domain == 2:
                # client: 计数器数全部, 喂入仅 exposed
                idx = 0
                for m in seq:
                    if m.flags & 0xC:
                        feed_method(out, m, idx)
                    idx += 1
            else:
                # base/cell: 预过滤, 计数仅计喂入的
                idx = 0
                for m in seq:
                    if m.flags & 0xC:
                        feed_method(out, m, idx)
                        idx += 1
    return bytes(out)


def run(label, records, cfgs):
    hits = []
    for cfg in cfgs:
        stream = emit(records, cfg)
        d = hashlib.md5(stream).hexdigest().upper()
        if d == TARGET:
            print(f'★★★ 命中!!! {label} cfg={cfg}')
            hits.append((label, cfg))
    return hits


def main():
    t0 = time.time()
    space, main_ents, ext_ents, main_dyn, ext_dyn = build_parts()
    print(f'分区: space={len(space)} main_ents={len(main_ents)} ext_ents={len(ext_ents)} '
          f'main_dyn={len(main_dyn)} ext_dyn={len(ext_dyn)}  ({time.time()-t0:.1f}s)')
    print(f'[目标] {TARGET}')
    variants = [
        ('A 基线318', space + main_ents + ext_ents + main_dyn + ext_dyn),
        ('B 无扩展148', space + main_ents + main_dyn),
        ('C 仅扩实体158', space + main_ents + ext_ents + main_dyn),
        ('D 仅扩dyn308', space + main_ents + main_dyn + ext_dyn),
        ('F 扩dyn在前', space + main_ents + ext_ents + ext_dyn + main_dyn),
        ('G 无space', main_ents + ext_ents + main_dyn + ext_dyn),
        ('H 扩展前置', space + ext_ents + ext_dyn + main_ents + main_dyn),
    ]
    cfgs = list(itertools.product((0, 1), (0, 1), (0, 1)))
    all_hits = []
    n = 0
    t1 = time.time()
    for label, recs in variants:
        hits = run(label, recs, cfgs)
        n += len(cfgs)
        all_hits += hits
        if hits:
            break
    print(f'{n} 组合 ({time.time()-t1:.1f}s)')
    if not all_hits:
        print('全不中 — 记录集需扩展变体')


if __name__ == '__main__':
    main()
