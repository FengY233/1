#!/usr/bin/env python3
"""digest_fork_v11.py — 终极消融: 15维结构化假设空间

新增维度(vs v10):
  scopenul: flag=1 域标记 NUL 独立于 flag=0 值
  namefl:   "name" 字段名独立于其他数值字段名
  vlh=3:    仅喂 vlh 值(不带 "varLenHeaderSize" 名)
  compt:    方法 flags 含 comp 位(defparse式) / 纯 exposed 位(vanilla式)
"""
import sys, os, itertools, hashlib, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from digest_fork_v8 import build_parts
from digest_fork_v2 import TARGET

TYPE_NAMES = {'FLOAT': 'Float', 'FLOAT64': 'Float64', 'STRING': 'String',
              'PYTHON': 'Python', 'MAILBOX': 'MailBox', 'VECTOR': 'Vector',
              'ARRAY': 'Array', 'TUPLE': 'Tuple', 'FIXED_DICT': 'FixedDict'}


def emit(records, cfg):
    (nul18, scopenul, nul6x, namefl, field, topnull, ent, prop, scope,
     vlh, nest, cflg, compt, endb, cfltf) = cfg
    out = bytearray()

    def V18(s):
        b = s.encode('utf-8') if isinstance(s, str) else s
        return b + b'\x00' if nul18 else b
    def VSC(s):
        b = s.encode('utf-8') if isinstance(s, str) else s
        return b + b'\x00' if scopenul else b
    def V6X(s):
        b = s.encode('utf-8') if isinstance(s, str) else s
        return b + b'\x00' if nul6x else b
    def NF():
        return V6X('name') if namefl else b''
    def F(nm):
        return V6X(nm) if field else b''
    def U32(v):
        out.extend(int(v).to_bytes(4, 'little', signed=True))
    def ENDB():
        if endb:
            out.append(0)

    def type_visit(dt, outer):
        if outer is not None:
            out.extend(V18(outer))
        k = dt.kind
        if k == 'INT':
            out.extend(NF() + V6X('Int' if dt.signed else 'Uint'))
            out.extend(F('size')); U32(dt.size)
        elif k in TYPE_NAMES:
            out.extend(NF() + V6X(TYPE_NAMES[k]))
            if k == 'VECTOR':
                out.extend(F('size')); U32(dt.n)
            elif k in ('ARRAY', 'TUPLE'):
                out.extend(F('size')); U32(dt.seq_size)
                if dt.db_len > 0:
                    out.extend(F('dbLen')); U32(dt.db_len)
                type_visit(dt.elem, 'elementType' if nest == 2 else
                           ('type' if nest == 1 else None))
        elif k == 'FIXED_DICT':
            out.extend(NF() + V6X('FixedDict'))
            out.extend(F('moduleName') + V6X(dt.module))
            out.extend(F('instanceName') + V6X(dt.instance))
            out.extend(F('allowNone'))
            out.append(1 if dt.allow_none else 0)
            if scope:
                out.extend(VSC('fields'))
            for fname, ft in dt.fields:
                out.extend(V18(fname))
                if prop:
                    out.extend(NF() + V6X(fname))
                type_visit(ft, 'fieldType' if nest == 2 else
                           ('type' if nest == 1 else None))
                ENDB()
            ENDB()
        ENDB()

    if topnull:
        out.append(0)

    def MFLG(m):
        f = m.flags
        if not compt:
            f = f & ~0x3          # 去 comp 位 (client=0 无影响, base=2/cell=1)
        if cflg:
            f |= 0x4              # client |=4 (对 base/cell 已 exposed 的无影响)
        return f & 0xff

    for ed in records:
        out.extend(V18(ed.name))
        if ent:
            out.extend(NF() + V6X(ed.name))
        if scope:
            out.extend(VSC('properties'))
        for p in ed.properties:
            if not p.is_client_server:
                continue
            U32(p.csi)
            out.extend(V18(p.name))
            if prop:
                out.extend(NF() + V6X(p.name))
            if p.stream_size() < 0 and p.var_len_header != 1:
                if vlh in (1, 2):
                    out.extend(F('varLenHeaderSize'))
                if vlh >= 2:
                    U32(p.var_len_header)
            out.extend(F('dataDistributionFlags')); U32(p.flags & 0x5F)
            out.extend(F('isVolatile'))
            out.append(getattr(p, 'is_volatile', 0) & 0xff)
            type_visit(p.dt, 'type')
        for domain, own_list in ((2, ed.client_methods),
                                 (1, ed.base_methods),
                                 (4, ed.cell_methods)):
            if scope:
                out.extend(VSC({2: 'clientMethods', 1: 'baseMethods',
                                4: 'cellMethods'}[domain]))
            idx = 0
            def emit_method(m):
                nonlocal idx
                out.extend(V18(m.name))
                if prop:
                    out.extend(NF() + V6X(m.name))
                if m.is_for_client and m._stream_size < 0 and m.var_len_header != 1:
                    if vlh in (1, 2):
                        out.extend(F('varLenHeaderSize'))
                    if vlh >= 2:
                        U32(m.var_len_header)
                out.extend(F('flags'))
                out.append(MFLG(m))
                if m.args:
                    if scope:
                        out.extend(VSC('Argument'))
                    for a in m.args:
                        type_visit(a, 'argType' if nest == 2 else
                                   ('type' if nest == 1 else None))
                        ENDB()
                    ENDB()
                U32(idx)
                idx += 1
            sel = (lambda m: True) if not cfltf else (lambda m: bool(m.flags & 0xC))
            if domain == 2:
                for m in own_list:
                    if sel(m):
                        emit_method(m)
                for sd in getattr(ed, 'fork_components', []):
                    for m in sd.client_methods:
                        if sel(m):
                            emit_method(m)
            else:
                attr = 'base_methods' if domain == 1 else 'cell_methods'
                for m in own_list:
                    if m.flags & 0xC:
                        emit_method(m)
                for sd in getattr(ed, 'fork_components', []):
                    for m in getattr(sd, attr):
                        if m.flags & 0xC:
                            emit_method(m)
    return bytes(out)


def main():
    t0 = time.time()
    records = build_parts()
    print(f'records = {len(records)}  (构建 {time.time()-t0:.1f}s)')
    print(f'[目标] {TARGET}')
    grid = itertools.product(
        (1, 0), (1, 0), (1, 0), (1, 0), (1, 0),   # nul18 scopenul nul6x namefl field
        (0, 1), (0, 1), (0, 1), (1, 0),           # topnull ent prop scope
        (0, 1, 2, 3), (0, 1, 2),                  # vlh nest
        (1, 0), (1, 0), (0, 1), (0, 1),           # cflg compt endb cfltf
    )
    n = 0
    t1 = time.time()
    for cfg in grid:
        d = hashlib.md5(emit(records, cfg)).hexdigest().upper()
        n += 1
        if d == TARGET:
            print(f'★★★ 命中!!! cfg={cfg}')
            return
    print(f'{n} 组合不中 ({time.time()-t1:.1f}s)')


if __name__ == '__main__':
    main()
