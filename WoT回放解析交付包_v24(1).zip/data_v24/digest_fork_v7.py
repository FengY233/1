#!/usr/bin/env python3
"""digest_fork_v7.py — Task 41: 分区消融矩阵 —— 攻 919053EC ≠ 5DF886F7

背景:
  - 输入侧主树 def 已验证 = 942 权威(scripts942 与 wot_scripts 11,536 文件 md5 零差异)
  - 喂入格式已 100% 反编译穷尽(Task 40)
  - 剩余最大未验证输入 = 170 条扩展记录(10 扩展实体 + 160 扩展 dyncomp, 无运行时锚)
  - 消融发现 AllowNone 修正零效果(当前 def 集无 FD+AllowNone 属性)

实验矩阵(每行独立重建记录集 + 重算 digest):
  A. 当前 v5 基线: 1+40+10+107+160 = 318
  B. 无扩展:       1+40+107        = 148  ← 假设: 扩展 pkg 未挂载进 digest
  C. 仅扩展实体:   1+40+10+107     = 158
  D. 仅扩展 dyncomp: 1+40+107+160  = 308
  E. B + UDO 14:  1+40+107+14     = 162
  F. 扩展块换序(扩展 dyncomp 在主 dyncomp 前)
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bwxml import decode_file
from defparse import (EntityDefParser, MD5, DATA_DISTRIBUTION_FLAGS)
from digest_fork_v2 import (SCRIPTS, EXT_ROOT, CD, CLI, TARGET,
                            _has_script, DefLocator, parse_comp_record,
                            load_static_comp, parse_space_record,
                            iter_extensions, parse_ext_entities,
                            parse_ext_dyncomps)
from digest_fork_v5 import (vanilla_stream_size, realloc_csi_v3,
                            fork_add_to_md5_v5)

def build_parts():
    """返回分区化的记录列表: (space, main_ents, ext_ents, main_dyn, ext_dyn)"""
    parser = EntityDefParser(SCRIPTS)
    parser.load()

    comps_root = decode_file(os.path.join(SCRIPTS, 'components.xml'),
                             'components.xml')
    static_list = [k.name for k in comps_root.child('StaticComponents').children]
    dyn_list = [k.name for k in comps_root.child('DynamicComponents').children]

    mounts = {}
    for cname in static_list:
        sec = decode_file(os.path.join(CD, cname + '.def'), cname + '.def')
        ofe = sec.child('ofEntity')
        if ofe is not None:
            for k in ofe.children:
                mounts.setdefault(k.name, []).append(cname)

    sub_cache, rec_cache, comp_cache = {}, {}, {}
    locator = DefLocator([])

    space = [parse_space_record(parser)]
    main_ents = []
    for ed in parser.entities:
        ed.fork_components = [load_static_comp(parser, locator, c, sub_cache)
                              for c in mounts.get(ed.name, [])]
        realloc_csi_v3(ed)
        main_ents.append(ed)
        rec_cache[ed.name] = ed

    ext_ents = []
    for ext in iter_extensions():
        eloc = DefLocator([os.path.join(EXT_ROOT, ext, '_raw')])
        for ed in parse_ext_entities(parser, eloc, ext, rec_cache):
            realloc_csi_v3(ed)
            ext_ents.append(ed)
            rec_cache[ed.name] = ed

    seen = set()
    main_dyn = []
    for name in dyn_list:
        if name in seen:
            continue
        seen.add(name)
        if not _has_script(CLI, name):
            continue
        ed = parse_comp_record(parser, locator, name, comp_cache)
        ed.fork_components = []
        realloc_csi_v3(ed)
        main_dyn.append(ed)
        rec_cache[ed.name] = ed

    ext_dyn = []
    for ext in iter_extensions():
        eloc = DefLocator([os.path.join(EXT_ROOT, ext, '_raw')])
        eds, sk = parse_ext_dyncomps(parser, eloc, ext, rec_cache, comp_cache)
        for ed in eds:
            realloc_csi_v3(ed)
            ext_dyn.append(ed)
    return space, main_ents, ext_ents, main_dyn, ext_dyn


def run(tag, records):
    md5 = MD5()
    for ed in records:
        fork_add_to_md5_v5(ed, md5)
    d = md5.getDigestQuote()
    hit = ' ★★★ 命中!!!' if d == TARGET else ''
    print(f'[{tag:38s}] n={len(records):3d} {d}{hit}')
    return d


def main():
    space, main_ents, ext_ents, main_dyn, ext_dyn = build_parts()
    print(f'分区: space={len(space)} main_ents={len(main_ents)} '
          f'ext_ents={len(ext_ents)} main_dyn={len(main_dyn)} ext_dyn={len(ext_dyn)}')
    print(f'[目标] {TARGET}')
    run('A 基线 v5(318)', space + main_ents + ext_ents + main_dyn + ext_dyn)
    run('B 无扩展(148)', space + main_ents + main_dyn)
    run('C 仅扩展实体(158)', space + main_ents + ext_ents + main_dyn)
    run('D 仅扩展dyncomp(308)', space + main_ents + main_dyn + ext_dyn)
    run('F 扩展dyn在前', space + main_ents + ext_ents + ext_dyn + main_dyn)
    run('G 无space', main_ents + ext_ents + main_dyn + ext_dyn)
    run('H 扩展前置于全部', space + ext_ents + ext_dyn + main_ents + main_dyn)


if __name__ == '__main__':
    main()
