#!/usr/bin/env python3
"""digest_fork_v10.py — WoT 魔改 entity_description_digests.cpp 完整结构化复现

本轮 decomp 全解(类型层结构化):
  typeVisit(dt, outerName):
    (+0x18)(outerName, 0)                  ← 外层字段名当值喂
    (+0x68)("name", typeName)
    INT:    (+0x28)("size", bitwidth)
    VECTOR: (+0x28)("size", n)
    ARRAY/TUPLE: (+0x28)("size", seq_size) [dbLen>0: ("dbLen", n)]
                 typeVisit(elem, "elementType")
    FIXED_DICT: [+0x60)("moduleName",s) ("instanceName",s)] ("allowNone",b)
                (+0x18)("fields",1) 每字段{(+0x18)(fname,0) (+0x60)("name",fname)
                  typeVisit(ftype, NEST)} (+0x20)
    FLOAT/STRING/PYTHON/MAILBOX: 无附加
    (+0x20)()
  常量破译: DAT_1435d2d24="name" DAT_1435e0950="type" DAT_1435e92e4="size"
    DAT_143676a60="Int" DAT_143928948="Uint" DAT_143676a50="Bool"
"""
import sys, os, itertools, hashlib, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from digest_fork_v8 import build_parts
from digest_fork_v2 import TARGET

TYPE_NAMES = {
    'INT': None,  # 动态 Int/Uint
    'FLOAT': 'Float', 'FLOAT64': 'Float64',
    'STRING': 'String', 'PYTHON': 'Python', 'MAILBOX': 'MailBox',
    'VECTOR': 'Vector', 'ARRAY': 'Array', 'TUPLE': 'Tuple',
    'FIXED_DICT': 'FixedDict',
}


def emit(records, cfg):
    (nul18, nul6x, topnull, ent, prop, scope, field, vlh, nest,
     cflg, endb, mbname, cfltf) = cfg
    out = bytearray()

    def V18(s):                       # +0x18 值(含域标记)
        b = s.encode('utf-8') if isinstance(s, str) else s
        return b + b'\x00' if nul18 else b
    def V6X(s):                       # +0x60/+0x68 字符串
        b = s.encode('utf-8') if isinstance(s, str) else s
        return b + b'\x00' if nul6x else b
    def F(name):                      # 字段名(FIELD开关)
        return V6X(name) if field else b''
    def U32(v):
        out.extend(int(v).to_bytes(4, 'little', signed=True))
    def U8(v):
        out.append(v & 0xff)
    def ENDB():
        if endb:
            out.append(0)

    def type_visit(dt, outer):
        if outer is not None:
            out.extend(V18(outer))
        k = dt.kind
        if k == 'INT':
            out.extend(F('name') + V6X('Int' if dt.signed else 'Uint'))
            out.extend(F('size')); U32(dt.size)
        elif k in ('FLOAT', 'STRING', 'PYTHON', 'MAILBOX'):
            nm = TYPE_NAMES[k] if k != 'MAILBOX' else mbname
            out.extend(F('name') + V6X(nm))
        elif k == 'VECTOR':
            out.extend(F('name') + V6X('Vector'))
            out.extend(F('size')); U32(dt.n)
        elif k in ('ARRAY', 'TUPLE'):
            out.extend(F('name') + V6X(TYPE_NAMES[k]))
            out.extend(F('size')); U32(dt.seq_size)
            if dt.db_len > 0:
                out.extend(F('dbLen')); U32(dt.db_len)
            type_visit(dt.elem, 'elementType' if nest == 2 else
                       ('type' if nest == 1 else None))
        elif k == 'FIXED_DICT':
            out.extend(F('name') + V6X('FixedDict'))
            out.extend(F('moduleName') + V6X(dt.module))
            out.extend(F('instanceName') + V6X(dt.instance))
            out.extend(F('allowNone')); U8(1 if dt.allow_none else 0)
            if scope:
                out.extend(V18('fields'))
            for fname, ft in dt.fields:
                out.extend(V18(fname))
                if prop:
                    out.extend(F('name') + V6X(fname))
                type_visit(ft, 'type' if nest == 1 else
                           ('fieldType' if nest == 2 else None))
                ENDB()
            ENDB()   # end fields
        ENDB()

    if topnull:
        out.append(0)

    for ed in records:
        out.extend(V18(ed.name))
        if ent:
            out.extend(F('name') + V6X(ed.name))
        if scope:
            out.extend(V18('properties'))
        for p in ed.properties:
            if not p.is_client_server:
                continue
            U32(p.csi)
            out.extend(V18(p.name))
            if prop:
                out.extend(F('name') + V6X(p.name))
            if p.stream_size() < 0 and p.var_len_header != 1:
                if vlh >= 1:
                    out.extend(F('varLenHeaderSize'))
                if vlh >= 2:
                    U32(p.var_len_header)
            out.extend(F('dataDistributionFlags')); U32(p.flags & 0x5F)
            out.extend(F('isVolatile')); U8(getattr(p, 'is_volatile', 0))
            type_visit(p.dt, 'type')
        for domain, own_list in ((2, ed.client_methods),
                                 (1, ed.base_methods),
                                 (4, ed.cell_methods)):
            if scope:
                out.extend(V18({2: 'clientMethods', 1: 'baseMethods',
                                4: 'cellMethods'}[domain]))
            idx = 0
            def emit_method(m):
                nonlocal idx
                out.extend(V18(m.name))
                if prop:
                    out.extend(F('name') + V6X(m.name))
                if m.is_for_client and m._stream_size < 0 and m.var_len_header != 1:
                    if vlh >= 1:
                        out.extend(F('varLenHeaderSize'))
                    if vlh >= 2:
                        U32(m.var_len_header)
                out.extend(F('flags'))
                U8((m.flags | 0x4) if cflg else m.flags)
                if m.args:
                    if scope:
                        out.extend(V18('Argument'))
                    for a in m.args:
                        type_visit(a, 'type' if nest == 1 else
                                   ('argType' if nest == 2 else None))
                        ENDB()
                    ENDB()
                U32(idx)
                idx += 1
            if domain == 2:
                for m in own_list:
                    if not cfltf or (m.flags & 0xC):
                        emit_method(m)
                for sd in getattr(ed, 'fork_components', []):
                    for m in sd.client_methods:
                        if not cfltf or (m.flags & 0xC):
                            emit_method(m)
            else:
                attr = 'base_methods' if domain == 1 else 'cell_methods'
                for m in own_list:
                    if m.flags & 0xC:
                        emit_method(m)
                for sd in getattr(ed, 'fork_components', []):
                    for m in getattr(sd, attr):
                        if m.flags & 0xC:
                            emit_method(m)
    return bytes(out)


def main():
    t0 = time.time()
    records = build_parts()
    print(f'records = {len(records)}  (构建 {time.time()-t0:.1f}s)')
    print(f'[目标] {TARGET}')
    grid = itertools.product(
        (1, 0),          # nul18
        (1, 0),          # nul6x
        (0, 1),          # topnull
        (0, 1),          # ent
        (0, 1),          # prop
        (1, 0),          # scope
        (1, 0),          # field
        (0, 1, 2),       # vlh
        (0, 1, 2),       # nest
        (1, 0),          # cflg
        (0, 1),          # endb
        ('MailBox',),    # mbname
        (0, 1),          # cfltf: client域 &0xC 过滤
    )
    n = 0
    t1 = time.time()
    for cfg in grid:
        d = hashlib.md5(emit(records, cfg)).hexdigest().upper()
        n += 1
        if d == TARGET:
            print(f'★★★ 命中!!! cfg={cfg}')
            return
    print(f'{n} 组合不中 ({time.time()-t1:.1f}s)')


if __name__ == '__main__':
    main()
