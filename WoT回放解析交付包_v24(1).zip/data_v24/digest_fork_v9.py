#!/usr/bin/env python3
"""digest_fork_v9.py — v8 细化版: 字符串 NUL 规则分立 + end/flags 维度

新洞察:
  +0x18(cstr, flag) → 底层 FUN_1403e81e0 (strlen+1 含NUL)   [SN1 规则]
  +0x60("name", BW::string*) → FUN_1403e8210 (size 不含NUL) [SN2 规则]
  字段名常量 (DAT "name"/"type"/...) C 字面量               [SN3 规则]
三个 NUL 维度独立消融; 另加 endScope 字节与 client flags |=4 两维.
"""
import sys, os, itertools, hashlib, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from defparse import EntityDefParser
from digest_fork_v2 import (SCRIPTS, EXT_ROOT, CD, CLI, TARGET,
                            _has_script, DefLocator, parse_comp_record,
                            load_static_comp, parse_space_record,
                            iter_extensions, parse_ext_entities,
                            parse_ext_dyncomps)
from digest_fork_v5 import realloc_csi_v3
from digest_fork_v8 import CapMD5, type_bytes, build_parts

SCOPE_NAMES = {2: b'clientMethods', 1: b'baseMethods', 4: b'cellMethods'}


def emit(records, cfg):
    (sn1, sn2, sn3, ent, scope, prop, field, vlh, typ, arg, argmk,
     endb, cflg) = cfg
    out = bytearray()

    def V1(name):      # +0x18 值字符串
        b = name.encode('utf-8')
        return b + b'\x00' if sn1 else b
    def V2(name):      # +0x60 值字符串
        b = name.encode('utf-8')
        return b + b'\x00' if sn2 else b
    def FN(lit):       # 字段名常量
        return lit + b'\x00' if sn3 else lit
    def ENDB():
        return b'\x00' if endb == 1 else b''
    def CFLG(m):
        return (m.flags | 0x4) & 0xff if cflg else m.flags & 0xff

    for ed in records:
        if ent in (0, 1):
            out += V1(ed.name)
        if ent in (1, 2):
            out += FN(b'name') + V2(ed.name)
        if scope:
            out += V1('properties')
        for p in ed.properties:
            if not p.is_client_server:
                continue
            out += p.csi.to_bytes(4, 'little', signed=True)
            if prop in (0, 1):
                out += V1(p.name)
            ss = p.stream_size()
            if ss < 0 and p.var_len_header != 1:
                if vlh >= 1:
                    out += FN(b'varLenHeaderSize')
                if vlh >= 2:
                    out += p.var_len_header.to_bytes(4, 'little')
            if prop in (1, 2):
                out += FN(b'name') + V2(p.name)
            if field:
                out += FN(b'dataDistributionFlags')
            out += (p.flags & 0x5F).to_bytes(4, 'little')
            if field:
                out += FN(b'isVolatile')
            out.append(getattr(p, 'is_volatile', 0) & 0xff)
            if typ == 1:
                out += FN(b'type')
            out += type_bytes(p.dt)
            out += ENDB()
        for domain, own_list in ((2, ed.client_methods),
                                 (1, ed.base_methods),
                                 (4, ed.cell_methods)):
            if scope:
                out += V1(SCOPE_NAMES[domain].decode())
            idx = 0
            def emit_method(m):
                nonlocal out, idx
                if prop in (0, 1):
                    out += V1(m.name)
                if m.is_for_client and m._stream_size < 0 and m.var_len_header != 1:
                    if vlh >= 1:
                        out += FN(b'varLenHeaderSize')
                    if vlh >= 2:
                        out += m.var_len_header.to_bytes(4, 'little')
                if prop in (1, 2):
                    out += FN(b'name') + V2(m.name)
                if field:
                    out += FN(b'flags')
                out.append(CFLG(m))
                if m.args:
                    if argmk:
                        out += V1('Argument')
                    for a in m.args:
                        if arg == 1:
                            out += V1('')
                        out += type_bytes(a)
                        if endb == 1:
                            out += b'\x00'
                    if endb == 1:
                        out += b'\x00'
                out += idx.to_bytes(4, 'little', signed=True)
                out += ENDB()
            if domain == 2:
                for m in own_list:
                    emit_method(m)
                    idx += 1
                for sd in getattr(ed, 'fork_components', []):
                    for m in sd.client_methods:
                        emit_method(m)
                        idx += 1
            else:
                attr = 'base_methods' if domain == 1 else 'cell_methods'
                for m in own_list:
                    if m.flags & 0xC:
                        emit_method(m)
                        idx += 1
                for sd in getattr(ed, 'fork_components', []):
                    for m in getattr(sd, attr):
                        if m.flags & 0xC:
                            emit_method(m)
                            idx += 1
    return bytes(out)


def main():
    t0 = time.time()
    records = build_parts()
    print(f'records = {len(records)}  (构建 {time.time()-t0:.1f}s)')
    print(f'[目标] {TARGET}')
    # 阶段1: 固定 endb=0 cflg=1, 跑细化字符串规则
    grid1 = itertools.product((1, 0), (1, 0), (1, 0), (0, 1, 2), (1, 0),
                              (0, 1, 2), (1, 0), (0, 1, 2), (0, 1), (0, 1),
                              (0, 1), (0,), (1,))
    n = 0
    t1 = time.time()
    for cfg in grid1:
        d = hashlib.md5(emit(records, cfg)).hexdigest().upper()
        n += 1
        if d == TARGET:
            print(f'★★★ 命中!!! cfg={cfg}')
            return
    print(f'阶段1: {n} 组合不中 ({time.time()-t1:.1f}s)')
    # 阶段2: 加 endb/cflg 维度
    grid2 = itertools.product((1, 0), (1, 0), (1, 0), (0, 1, 2), (1, 0),
                              (0, 1, 2), (1, 0), (0, 1, 2), (0, 1), (0, 1),
                              (0, 1), (1,), (0, 1))
    n = 0
    for cfg in grid2:
        d = hashlib.md5(emit(records, cfg)).hexdigest().upper()
        n += 1
        if d == TARGET:
            print(f'★★★ 命中(阶段2)!!! cfg={cfg}')
            return
    print(f'阶段2: {n} 组合不中 ({time.time()-t1:.1f}s)')


if __name__ == '__main__':
    main()
