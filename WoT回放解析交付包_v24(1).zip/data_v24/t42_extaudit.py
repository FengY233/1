#!/usr/bin/env python3
"""t42_extaudit.py — Task 42-①: 扩展 def 解析保真度人工核对

取 3 个扩展 dyncomp 样本(frontline FLAvatarComponent / battle_modifiers / comp7),
BWXML 原文 dump vs defparse(parse_comp_record) 输出逐字段对比:
  属性名/Flags/Type/vlh/isVolatile + 三域方法名/args/vlh
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bwxml import decode_file
from defparse import EntityDefParser
from digest_fork_v2 import (SCRIPTS, EXT_ROOT, CD, CLI, _has_script,
                            DefLocator, parse_comp_record)

SAMPLES = [
    ('frontline', 'FLAvatarComponent'),
    ('battle_modifiers', 'BattleModifiersComponent'),
    ('comp7', 'Comp7DynamicComponent'),
]


def dump_def_xml(path):
    root = decode_file(path, os.path.basename(path))
    print(f'  -- <Properties> ({len(root.child("Properties").children) if root.child("Properties") else 0})')
    props = root.child('Properties')
    if props:
        for p in props.children:
            flags = tname = vlh = ''
            for a in p.children:
                if a.name == 'Flags':
                    flags = a.asString()
                elif a.name == 'Type':
                    # Type 可能是文本或子节点
                    tname = a.asString() if not a.children else \
                        f'<{a.children[0].name}:{a.children[0].asString()}>'
                elif a.name == 'VariableLengthHeaderSize':
                    vlh = a.asInt()
            print(f'     {p.name:36s} {flags:18s} {tname:24s} vlh={vlh}')
    for dom in ('ClientMethods', 'BaseMethods', 'CellMethods'):
        sec = root.child(dom)
        if not sec:
            continue
        print(f'  -- <{dom}> ({len(sec.children)})')
        for m in sec.children:
            args = [a.asString() or f'<{a.children[0].name}>' if a.children else a.asString()
                    for a in m.children if a.name == 'Arg']
            exp = any(a.name == 'Exposed' for a in m.children)
            print(f'     {m.name:36s} args={args} exposed={exp}')


def dump_parsed(name, ext):
    parser = EntityDefParser(SCRIPTS)
    parser.load()
    locator = DefLocator([os.path.join(EXT_ROOT, ext, '_raw')])
    comp_cache = {}
    ed = parse_comp_record(parser, locator, name, comp_cache)
    print(f'  == defparse: props={len(ed.properties)} '
          f'client/base/cell={len(ed.client_methods)}/{len(ed.base_methods)}/{len(ed.cell_methods)}')
    for p in ed.properties:
        print(f'     {p.name:36s} flags=0x{p.flags:03x} cs={p.is_client_server} '
              f'kind={p.dt.kind} vlh={p.var_len_header} vol={getattr(p,"is_volatile",0)}')
    for dom, lst in (('client', ed.client_methods), ('base', ed.base_methods),
                     ('cell', ed.cell_methods)):
        for m in lst:
            print(f'     [{dom}] {m.name:32s} flags=0x{m.flags:02x} '
                  f'nargs={len(m.args)} ifc={m.is_for_client} ss={m._stream_size}')


def main():
    for ext, name in SAMPLES:
        d = os.path.join(EXT_ROOT, ext, '_raw', 'component_defs', name + '.def')
        print(f'==== {ext}/{name} ====')
        if not os.path.exists(d):
            # 找该扩展下任意 def
            cd = os.path.join(EXT_ROOT, ext, '_raw', 'component_defs')
            if os.path.isdir(cd):
                alts = sorted(os.listdir(cd))
                print(f'  (无 {name}.def; 该扩展有: {alts[:8]})')
                if alts:
                    name = alts[0][:-4]
                    d = os.path.join(cd, alts[0])
            else:
                print('  (无 component_defs 目录)')
                continue
        print(f'  == BWXML 原文 ({name}):')
        try:
            dump_def_xml(d)
        except Exception as e:
            print(f'  XML dump 失败: {e}')
        print(f'  == defparse 输出:')
        try:
            dump_parsed(name, ext if os.path.isdir(os.path.join(EXT_ROOT, ext, '_raw')) else 'frontline')
        except Exception as e:
            print(f'  defparse 失败: {e}')
        print()


if __name__ == '__main__':
    main()
