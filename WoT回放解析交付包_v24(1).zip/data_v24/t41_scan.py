#!/usr/bin/env python3
"""t41_scan.py — Task 41: ExposedForReplay/Volatile 全量扫描

vanilla data_description.cpp:262-276 发现:
  if (isClientServerData()):
      isExposedForReplay = readBool("ExposedForReplay", isOtherClientData())
      → |= DATA_REPLAY 或 &= ~DATA_REPLAY
  DATA_REPLAY ∈ CS_MASK → 影响 isClientServerData → 影响进 digest!

  唯一改变判定的情况: 非OTHER/OWN属性(CELL_PUBLIC/BASE/CELL_PRIVATE)显式
  ExposedForReplay=true → 获得 REPLAY → 进 digest (defparse 会漏!)

同时扫描 <Volatile><Properties> 标记 (fork isVolatile 喂入的来源)
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bwxml import decode_file

SCRIPTS = '/tmp/wot/scripts942/scripts'


def scan_def(path, tag):
    """返回 (exposed_for_replay_props, volatile_props, total_props, flags统计)"""
    try:
        root = decode_file(path, os.path.basename(path))
    except Exception as e:
        return None
    epr = []
    vol = []
    total = 0
    flag_count = {}
    for sec in root.children:
        if sec.name == 'Properties':
            for p in sec.children:
                total += 1
                flags = ''
                e = None
                for a in p.children:
                    if a.name == 'Flags':
                        flags = a.asString() if hasattr(a, 'asString') else str(a.value)
                    if a.name == 'ExposedForReplay':
                        e = a.asBool() if hasattr(a, 'asBool') else (a.value == 'true')
                flag_count[flags] = flag_count.get(flags, 0) + 1
                if e:
                    epr.append((p.name, flags, e))
        if sec.name == 'Volatile':
            for sub in sec.children:
                if sub.name == 'Properties':
                    for nm in sub.children:
                        vol.append(nm.name)
    return epr, vol, total, flag_count


def main():
    roots = ['entity_defs', 'component_defs', 'user_data_object_defs']
    n_epr = 0
    epr_detail = []
    vol_detail = []
    for r in roots:
        d = os.path.join(SCRIPTS, r)
        for f in sorted(os.listdir(d)):
            if not f.endswith('.def'):
                continue
            res = scan_def(os.path.join(d, f), f)
            if res is None:
                continue
            epr, vol, total, fc = res
            for (pn, flags, e) in epr:
                # 关键: flags 不含 OTHER_CLIENT/OWN_CLIENT 却显式 ExposedForReplay
                critical = ('OTHER_CLIENT' not in flags.upper()
                            and 'OWN_CLIENT' not in flags.upper()
                            and 'ALL_CLIENTS' not in flags.upper()
                            and 'BASE_AND_CLIENT' not in flags.upper())
                epr_detail.append((r, f, pn, flags, e, critical))
                n_epr += 1
            if vol:
                vol_detail.append((r, f, len(vol), vol[:5]))
    print(f'== ExposedForReplay 显式标签总数: {n_epr}')
    for (r, f, pn, fl, e, crit) in epr_detail:
        mark = ' ★CRITICAL(会改变CS判定!)' if crit else ''
        print(f'  {r}/{f}: {pn} Flags={fl} ExposedForReplay={e}{mark}')
    print(f'== Volatile 标记的 def: {len(vol_detail)}')
    for (r, f, n, sample) in vol_detail[:25]:
        print(f'  {r}/{f}: {n} 个 {sample}')


if __name__ == '__main__':
    main()
