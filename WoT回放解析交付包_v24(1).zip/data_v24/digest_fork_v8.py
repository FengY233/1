#!/usr/bin/env python3
"""digest_fork_v8.py — Task 41: WoT 魔改版结构化 digest 复现 + 消融矩阵

依据 (entity_description_digests.cpp 反编译全链, 本轮解明):
  calc(MD5Calculator) vtable 槽:
    +0x18(str, flag): visitString —— flag=0 值 / flag=1 域标记
    +0x60("name", str): visitStringField —— DAT_1435d2d24="name" 已破译
    +0x28(field, u32): visitUint32Field ("dataDistributionFlags")
    +0x40(field): visitXxxField ("varLenHeaderSize") [Ghidra 可能丢值参]
    +0x50(field, u8): ("flags") / +0x58(field, u8): ("isVolatile")
    +0x70(): getState (裸 append 用)
  每记录喂入序 (FUN_142a9b6e0 + FUN_142a93420):
    [名] [name字段+名] [properties?] 每CS属性{csi4B 名 [vlh?] [name字段+名]
      [dataDistributionFlags] [isVolatile] [type+类型序列化] end}
    [clientMethods?] 每client方法{名 [vlh?] [name字段+名] [flags1B]
      [Argument标记? 每arg{argName 类型 end} end] idx4B} end
    [baseMethods?] (flags&0xC)!=0 过滤 ... [cellMethods?] 同
  ReturnValues 全空(4/4) → 恒跳过; isVolatile 主实体全0(仅GunMarker组件1个)

消融开关 (9维):
  NUL(2)   字符串 append 含NUL / 不含
  ENT(3)   实体头: 仅名 / 名+name字段+名 / 仅name字段+名
  SCOPE(2) "properties"/"xxxMethods" 域标记进 / 不进
  PROP(3)  属性方法名: 仅首名 / 首名+name字段+名 / 仅name字段+名
  FIELD(2) 数值字段名(dataDistributionFlags/flags/isVolatile) 进 / 不进
  VLH(3)   不喂 / 仅"varLenHeaderSize"名 / 名+vlh4B
  TYPE(2)  vanilla类型序列化 / "type"+NUL+vanilla
  ARG(2)   arg只类型 / argName+类型
  ARGMK(2) "Argument"标记 进 / 不进
"""
import sys, os, itertools, hashlib, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from defparse import (EntityDefParser, MD5, DATA_DISTRIBUTION_FLAGS)
from digest_fork_v2 import (SCRIPTS, EXT_ROOT, CD, CLI, TARGET,
                            _has_script, DefLocator, parse_comp_record,
                            load_static_comp, parse_space_record,
                            iter_extensions, parse_ext_entities,
                            parse_ext_dyncomps)
from digest_fork_v5 import realloc_csi_v3

VARLEN_NAME = b'varLenHeaderSize\x00'
NAME_FIELD = b'name\x00'
TYPE_FIELD = b'type\x00'
ARG_MARK = b'Argument\x00'
SCOPE_NAMES = {2: b'clientMethods\x00', 1: b'baseMethods\x00', 4: b'cellMethods\x00'}


class CapMD5(object):
    """捕获式 MD5 —— 把 add_to_md5 的字节流记录下来(用于类型序列化捕获)"""
    def __init__(self):
        self.buf = bytearray()
    def append(self, b, n=None):
        if isinstance(b, str):
            b = b.encode('utf-8')
        self.buf += bytes(b[:n] if n else b)
    def append_int32(self, v):
        self.buf += int(v & 0xffffffff).to_bytes(4, 'little', signed=False) if v >= 0 \
            else v.to_bytes(4, 'little', signed=True)
    def append_uint32(self, v):
        self.buf += int(v).to_bytes(4, 'little')
    def append_uint8(self, v):
        self.buf.append(v & 0xff)
    def append_uint16(self, v):
        self.buf += int(v).to_bytes(2, 'little')


def _s(name, nul):
    b = name.encode('utf-8')
    return b + b'\x00' if nul else b


def type_bytes(dt):
    c = CapMD5()
    dt.add_to_md5(c)
    return bytes(c.buf)


def emit(records, cfg):
    """按配置生成完整喂入流"""
    (nul, ent, scope, prop, field, vlh, typ, arg, argmk) = cfg
    out = bytearray()

    def S(name):        # 值字符串
        return _s(name, nul)
    def FLD(b):         # 字段名字符串(固定含NUL——字段名常量从DAT来带NUL)
        return b if field or True else b''

    for ed in records:
        # ---- 实体头 FUN_142a9b6e0 ----
        if ent in (0, 1):
            out += S(ed.name)
        if ent in (1, 2):
            out += NAME_FIELD + _s(ed.name, nul)
        # ---- beginProperties (wrapper+0x8 → FUN_142a9b7f0) ----
        if scope:
            out += b'properties\x00' if nul else b'properties'
        # ---- 属性域 ----
        for p in ed.properties:
            if not p.is_client_server:
                continue
            out += int(p.csi & 0xffffffff).to_bytes(4, 'little', signed=True) \
                if p.csi < 0 else p.csi.to_bytes(4, 'little', signed=True)
            if prop in (0, 1):
                out += S(p.name)
            ss = p.stream_size()
            if p.is_client_server and ss < 0 and p.var_len_header != 1:
                if vlh >= 1:
                    out += VARLEN_NAME
                if vlh >= 2:
                    out += p.var_len_header.to_bytes(4, 'little')
            if prop in (1, 2):
                out += NAME_FIELD + _s(p.name, nul)
            if field:
                out += b'dataDistributionFlags\x00'
            out += (p.flags & 0x5F).to_bytes(4, 'little', signed=True)
            if field:
                out += b'isVolatile\x00'
            out.append(getattr(p, 'is_volatile', 0) & 0xff)
            if typ == 1:
                out += TYPE_FIELD
            out += type_bytes(p.dt)
        # ---- 方法三域 ----
        for domain, own_list in ((2, ed.client_methods),
                                 (1, ed.base_methods),
                                 (4, ed.cell_methods)):
            if scope:
                sn = SCOPE_NAMES[domain]
                out += sn if nul else sn[:-1]
            idx = 0
            def emit_method(m):
                nonlocal out
                if prop in (0, 1):
                    out += S(m.name)
                ss = m._stream_size
                if m.is_for_client and ss < 0 and m.var_len_header != 1:
                    if vlh >= 1:
                        out += VARLEN_NAME
                    if vlh >= 2:
                        out += m.var_len_header.to_bytes(4, 'little')
                if prop in (1, 2):
                    out += NAME_FIELD + _s(m.name, nul)
                if field:
                    out += b'flags\x00'
                out.append(m.flags & 0xff)
                if m.args:
                    if argmk:
                        am = ARG_MARK
                        out += am if nul else am[:-1]
                    for a in m.args:
                        if arg == 1:
                            out += _s('', nul)      # 旧式 Arg 名 = 空串
                        out += type_bytes(a)
                    # 每arg的end + 列表end —— 假设无字节
                # returnValues 全空 → 跳过
                out += idx.to_bytes(4, 'little', signed=True)
            if domain == 2:
                # client 域: 全部, 自有在前组件在后
                for m in own_list:
                    emit_method(m)
                    idx += 1
                for sd in getattr(ed, 'fork_components', []):
                    for m in sd.client_methods:
                        emit_method(m)
                        idx += 1
            else:
                for m in own_list:
                    if m.flags & 0xC:
                        emit_method(m)
                        idx += 1
                attr = 'base_methods' if domain == 1 else 'cell_methods'
                for sd in getattr(ed, 'fork_components', []):
                    for m in getattr(sd, attr):
                        if m.flags & 0xC:
                            emit_method(m)
                            idx += 1
    return bytes(out)


def build_parts():
    parser = EntityDefParser(SCRIPTS)
    parser.load()
    from bwxml import decode_file
    comps_root = decode_file(os.path.join(SCRIPTS, 'components.xml'),
                             'components.xml')
    static_list = [k.name for k in comps_root.child('StaticComponents').children]
    dyn_list = [k.name for k in comps_root.child('DynamicComponents').children]
    mounts = {}
    for cname in static_list:
        sec = decode_file(os.path.join(CD, cname + '.def'), cname + '.def')
        ofe = sec.child('ofEntity')
        if ofe is not None:
            for k in ofe.children:
                mounts.setdefault(k.name, []).append(cname)
    sub_cache, rec_cache, comp_cache = {}, {}, {}
    locator = DefLocator([])
    records = [parse_space_record(parser)]
    for ed in parser.entities:
        ed.fork_components = [load_static_comp(parser, locator, c, sub_cache)
                              for c in mounts.get(ed.name, [])]
        realloc_csi_v3(ed)
        records.append(ed)
        rec_cache[ed.name] = ed
    for ext in iter_extensions():
        eloc = DefLocator([os.path.join(EXT_ROOT, ext, '_raw')])
        for ed in parse_ext_entities(parser, eloc, ext, rec_cache):
            realloc_csi_v3(ed)
            records.append(ed)
            rec_cache[ed.name] = ed
    seen = set()
    for name in dyn_list:
        if name in seen:
            continue
        seen.add(name)
        if not _has_script(CLI, name):
            continue
        ed = parse_comp_record(parser, locator, name, comp_cache)
        ed.fork_components = []
        realloc_csi_v3(ed)
        records.append(ed)
        rec_cache[ed.name] = ed
    for ext in iter_extensions():
        eloc = DefLocator([os.path.join(EXT_ROOT, ext, '_raw')])
        eds, sk = parse_ext_dyncomps(parser, eloc, ext, rec_cache, comp_cache)
        for ed in eds:
            realloc_csi_v3(ed)
            records.append(ed)
    return records


def main():
    t0 = time.time()
    records = build_parts()
    print(f'records = {len(records)}  (构建 {time.time()-t0:.1f}s)')
    print(f'[目标] {TARGET}')
    # 预缓存类型序列化
    grid = itertools.product((1, 0), (0, 1, 2), (1, 0), (0, 1, 2), (1, 0),
                             (0, 1, 2), (0, 1), (0, 1), (0, 1))
    n = 0
    t1 = time.time()
    for cfg in grid:
        stream = emit(records, cfg)
        d = hashlib.md5(stream).hexdigest().upper()
        n += 1
        if d == TARGET:
            print(f'★★★ 命中!!! cfg={cfg}')
            return
    print(f'消融 {n} 组合全不中 ({time.time()-t1:.1f}s) — 扩大假设空间')


if __name__ == '__main__':
    main()
