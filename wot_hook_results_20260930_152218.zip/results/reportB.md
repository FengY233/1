# reportB.md — digest 捕获回传报告 (自动生成 2026-09-30 15:22:18)

- 测试包版本: v1 (项目B V2设计 · V3脚本 · 2026-09-30)
- 环境: python=None frida=17.19.0 exe匹配参考=True
- 运行记录: 3 条, 命中: 1

## 命中摘要

- digest = `5df886f75e73b33cff9d87fb9c69389c`
- total_in = 61161 B (期望 ~60KB 量级)
- n_updates = 9648
- 本地自检 (md5(digest_input.bin)==目标) = False

## 文件清单

- `README.txt` (89 B)
- `env_info.txt` (343 B)
- `runs_index.json` (1022 B)
- `capture_spawn_20260930_152138\console_log.txt` (1355 B)
- `capture_spawn_20260930_152138\digest_input.bin` (61161 B)
- `capture_spawn_20260930_152138\projectB_log.jsonl` (123080 B)
- `capture_spawn_20260930_152138\stream_01_5df886f7.bin` (61161 B)
- `capture_spawn_20260930_152138\summary.json` (491 B)
- `step0_global_20260930_152044\console_log.txt` (591 B)
- `step0_global_20260930_152044\projectB_log.jsonl` (585 B)
- `step0_global_20260930_152044\summary.json` (261 B)
