/* ==================== FUNC 0x140e379d0 FUN_140e379d0 ==================== */


/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140e379d0(longlong param_1)

{
  int *piVar1;
  void **ppvVar2;
  longlong lVar3;
  byte bVar4;
  longlong lVar5;
  char cVar6;
  int iVar7;
  undefined4 uVar8;
  undefined8 uVar9;
  longlong *plVar10;
  longlong *plVar11;
  ulonglong uVar12;
  void *pvVar13;
  undefined8 *puVar14;
  undefined8 *puVar15;
  ulonglong uVar16;
  ulonglong uVar17;
  undefined1 auStack_118 [32];
  undefined4 local_f8;
  byte local_e8;
  undefined1 local_e7;
  undefined1 local_e6;
  void **local_d8;
  longlong *plStack_d0;
  void *local_b8 [2];
  longlong local_a8;
  void *local_a0;
  undefined8 uStack_98;
  longlong local_90;
  undefined4 local_88;
  undefined4 uStack_84;
  ulonglong local_58;
  
  local_58 = DAT_144379740 ^ (ulonglong)auStack_118;
  cVar6 = FUN_140e6ffd0(param_1 + 0x58);
  if (cVar6 == '\0') {
    local_f8 = 0;
    uVar9 = FUN_1403da4e0(&local_d8,0,5,&DAT_14368b070);
    FUN_1403dad90(uVar9,"BWRootNode::onUpdate: Couldn\'t apply received volatile delta");
    return 0;
  }
  if (*(longlong *)(param_1 + 0x88) != *(longlong *)(param_1 + 0x90)) {
    *(longlong *)(param_1 + 0x90) = *(longlong *)(param_1 + 0x88);
  }
  FUN_1403e8140(local_b8);
  local_d8 = local_b8;
  plStack_d0 = (longlong *)param_1;
  iVar7 = FUN_140e37830(&local_d8,param_1);
  plVar10 = plStack_d0;
  ppvVar2 = local_d8;
  if (iVar7 == 0) {
    puVar14 = *(undefined8 **)(param_1 + 0x28);
    puVar15 = *(undefined8 **)(param_1 + 0x30);
    while ((puVar14 != puVar15 &&
           (local_d8 = ppvVar2, plStack_d0 = plVar10, cVar6 = FUN_140e376b0(*puVar14,&local_d8,0),
           cVar6 != '\0'))) {
      puVar14 = puVar14 + 2;
    }
  }
  uVar9 = FUN_140e6f610(local_b8);
  *(undefined8 *)(param_1 + 0xa0) = uVar9;
  uVar8 = (**(code **)(**(longlong **)(param_1 + 0xa8) + 0x68))();
  plVar10 = (longlong *)FUN_140e70690(param_1 + 0x58,*(undefined8 *)(param_1 + 0xa0),uVar8);
  if (plVar10 == (longlong *)0x0) {
    return 1;
  }
  FUN_140e6f0f0(local_b8,plVar10,1);
  puVar14 = *(undefined8 **)(param_1 + 0x90);
  puVar15 = *(undefined8 **)(param_1 + 0x88);
  uVar16 = 0;
  uVar17 = uVar16;
  if (CONCAT44(uStack_84,local_88) == (longlong)puVar14 - (longlong)puVar15 >> 3) {
    for (; puVar15 != puVar14; puVar15 = puVar15 + 1) {
      uVar12 = uVar16 >> 5;
      bVar4 = (byte)uVar16;
      uVar16 = uVar16 + 1;
      if ((1 << (bVar4 & 0x1f) & *(uint *)((longlong)local_a0 + uVar12 * 4)) != 0) {
        (**(code **)(*(longlong *)*puVar15 + 0x60))((longlong *)*puVar15,plVar10);
        uVar17 = uVar17 + 1;
      }
    }
    iVar7 = (**(code **)(*plVar10 + 0x10))(plVar10);
    if ((iVar7 == 0) && (uVar17 != 0)) {
      if (local_a0 != (void *)0x0) {
        pvVar13 = local_a0;
        if ((0xfff < (ulonglong)((local_90 - (longlong)local_a0 >> 2) * 4)) &&
           (pvVar13 = *(void **)((longlong)local_a0 + -8),
           0x1f < (ulonglong)((longlong)local_a0 + (-8 - (longlong)pvVar13)))) goto LAB_140e37e5b;
        free(pvVar13);
        local_a0 = (void *)0x0;
        uStack_98 = 0;
        local_90 = 0;
      }
      if (local_b8[0] == (void *)0x0) {
LAB_140e37c83:
        puVar14 = *(undefined8 **)(*(longlong *)(param_1 + 0x18) + 0x48);
        if (puVar14[1] != 0) {
          LOCK();
          piVar1 = (int *)(puVar14[1] + 8);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        ppvVar2 = (void **)*puVar14;
        plVar10 = (longlong *)puVar14[1];
        local_d8 = ppvVar2;
        plStack_d0 = plVar10;
        plVar11 = (longlong *)(**(code **)((longlong)*ppvVar2 + 0x20))(ppvVar2,1);
        if (plVar11 != (longlong *)0x0) {
          uVar8 = *(undefined4 *)(param_1 + 0x40);
          local_e7 = (undefined1)((uint)uVar8 >> 8);
          local_e6 = (undefined1)uVar8;
          local_e8 = (byte)((uint)uVar8 >> 0x10) | 6;
          (**(code **)(*plVar11 + 0x18))(plVar11,&local_e8,3);
          FUN_140e70900(param_1 + 0x58,plVar11);
          cVar6 = (**(code **)((longlong)*ppvVar2 + 0x18))(ppvVar2);
          if (plVar10 != (longlong *)0x0) {
            LOCK();
            plVar11 = plVar10 + 1;
            lVar5 = *plVar11;
            *(int *)plVar11 = (int)*plVar11 + -1;
            UNLOCK();
            if ((int)lVar5 == 1) {
              (**(code **)*plVar10)(plVar10);
              LOCK();
              piVar1 = (int *)((longlong)plVar10 + 0xc);
              iVar7 = *piVar1;
              *piVar1 = *piVar1 + -1;
              UNLOCK();
              if (iVar7 == 1) {
                (**(code **)(*plVar10 + 8))(plVar10);
              }
            }
          }
          if (cVar6 == '\0') {
            return 0;
          }
          return 1;
        }
        if (plVar10 == (longlong *)0x0) {
          return 0;
        }
        LOCK();
        plVar11 = plVar10 + 1;
        lVar5 = *plVar11;
        *(int *)plVar11 = (int)*plVar11 + -1;
        UNLOCK();
        if ((int)lVar5 != 1) {
          return 0;
        }
        (**(code **)*plVar10)(plVar10);
        LOCK();
        piVar1 = (int *)((longlong)plVar10 + 0xc);
        iVar7 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar7 != 1) {
          return 0;
        }
        (**(code **)(*plVar10 + 8))(plVar10);
        return 0;
      }
      pvVar13 = local_b8[0];
      if (((ulonglong)((local_a8 - (longlong)local_b8[0] >> 2) * 4) < 0x1000) ||
         (pvVar13 = *(void **)((longlong)local_b8[0] + -8),
         (ulonglong)((longlong)local_b8[0] + (-8 - (longlong)pvVar13)) < 0x20)) {
        free(pvVar13);
        goto LAB_140e37c83;
      }
      goto LAB_140e37e5b;
    }
    local_f8 = 0;
    uVar9 = FUN_1403da4e0(&local_d8,0,5,&DAT_14368b070);
    lVar5 = *(longlong *)(param_1 + 0x90);
    lVar3 = *(longlong *)(param_1 + 0x88);
    uVar8 = (**(code **)(*plVar10 + 0x10))(plVar10);
    local_f8 = (undefined4)uVar17;
    FUN_1403dad90(uVar9,
                  "BWRootNode::onUpdate: hashes match, but data->remainingLength() = %d. Volatile node count = %d, updated %d nodes."
                  ,uVar8,lVar5 - lVar3 >> 3 & 0xffffffff);
  }
  else {
    local_f8 = 0;
    uVar9 = FUN_1403da4e0(&local_d8,0,5,&DAT_14368b070);
    FUN_1403dad90(uVar9,
                  "BWRootNode::onUpdate: hashes match, but flags.size() != m_volatileNodeBuffer.size() (%d != %d)"
                  ,local_88,*(longlong *)(param_1 + 0x90) - *(longlong *)(param_1 + 0x88) >> 3);
  }
  if (local_a0 != (void *)0x0) {
    pvVar13 = local_a0;
    if ((0xfff < (local_90 - (longlong)local_a0 & 0xfffffffffffffffcU)) &&
       (pvVar13 = *(void **)((longlong)local_a0 + -8),
       0x1f < (ulonglong)((longlong)local_a0 + (-8 - (longlong)pvVar13)))) goto LAB_140e37e5b;
    free(pvVar13);
    local_a0 = (void *)0x0;
    uStack_98 = 0;
    local_90 = 0;
  }
  if (local_b8[0] == (void *)0x0) {
    return 0;
  }
  pvVar13 = local_b8[0];
  if (((local_a8 - (longlong)local_b8[0] & 0xfffffffffffffffcU) < 0x1000) ||
     (pvVar13 = *(void **)((longlong)local_b8[0] + -8),
     (ulonglong)((longlong)local_b8[0] + (-8 - (longlong)pvVar13)) < 0x20)) {
    free(pvVar13);
    return 0;
  }
LAB_140e37e5b:
                    /* WARNING: Subroutine does not return */
  _invalid_parameter_noinfo_noreturn();
}



