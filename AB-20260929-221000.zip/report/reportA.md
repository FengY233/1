# reportA.md —— 0x39 通道 node1 consumer 定位（项目 A 回传）

**日期**：2026-09-29
**对应交接书**：`Hook交接说明书_本地AI执行版.md` §2.5 / §6
**采集场次**：`WZ-219.wotreplay`（与交接书 §2 同一场）
**采集工具**：`C:\wot24\server\crates\hooklab`（**外部调试器 + 硬件断点，零注入**）
**算法**：与交接书的 Frida 路线**独立**，两边互不背书（R5）

---

## 0. 一行结论

**node1 的 consumer = `BW::BWRootNode::onUpdate` = VA `0x140E379D0`（模块偏移 `0xE379D0`）。**
→ 由 vtable `0x1435DF3E8` 的 **slot `0x60`** 解出，并由函数体内**断言串逐字点名**。

---

## 1. node1 的 vtable / RTTI 类名 / consumer

### 1.1 直接答案

| 项 | 值 | 依据 |
|---|---|---|
| **RTTI 类名** | `.?AVBWRootNode@BW@@`（即 `BW::BWRootNode`） | vtable `0x1435DF3E8` 的 COL `0x143C93B58` |
| **vtable VA** | **`0x1435DF3E8`** | `qscan.py 0x140398b10` → 唯一引用点 |
| **模块偏移** | `0x35DF3E8` | `VA − ImageBase(0x140000000)` |
| **`slot 0x00`** | `0x140398b10`（scalar deleting destructor） | `vtinfo.py --at` |
| **★ `slot 0x60` = consumer** | **`0x140E379D0`** | `vtinfo.py --at 0x1435DF3E8` |
| **consumer 模块偏移** | **`0xE379D0`** | 同上 |
| **consumer 函数名** | `BW::BWRootNode::onUpdate` | ★ 函数体内断言串自报（§2.2） |

### 1.2 vtable 全槽（前 14 槽，`[读]`）

```
vtable @ 0x1435DF3E8   COL = 0x143C93B58   RTTI = .?AVBWRootNode@BW@@ (sig=0x1, off=0)
  slot 0x00 -> 0x140398B10     ← scalar deleting destructor
  slot 0x08 -> 0x1402F40F0
  slot 0x10 -> 0x140355960
  slot 0x18 -> 0x140355960
  slot 0x20 -> 0x1402F40F0
  slot 0x28 -> 0x1403977B0
  slot 0x30 -> 0x14038CAB0
  slot 0x38 -> 0x14039A320
  slot 0x40 -> 0x140355960
  slot 0x48 -> 0x140398E50
  slot 0x50 -> 0x1402F40F0
  slot 0x58 -> 0x1402F7290
  slot 0x60 -> 0x140E379D0     ★ consumer
```

> **★ 与交接书 §1 的「离线帧法」互证**：交接书要求「consumer = `vt + 0x60` 取的指针」，
> 本表 slot `0x60` 值 `0x140E379D0` 与该读法**逐位一致**。

### 1.3 定位链（每一步都可复现）

```
hooklab 的 nret 断点采到 node1 对象的 [0] 槽 = 0x140398b10
   ↓ qscan.py 0x140398b10
     file 0x035DDDE8  sec=.rdata  VA=0x1435DF3E8      ← 唯一引用点
   ↓ vtinfo.py --at 0x1435DF3E8
     COL 0x143C93B58 → RTTI .?AVBWRootNode@BW@@
     slot 0x00 -> 0x140398B10     （印证：采到的确实是 [0] 槽）
     slot 0x60 -> 0x140E379D0     ★ consumer
   ↓ decomp/index.tsv
     140e379d0  FUN_140e379d0  size=1228  c_140d47320.c:202974
   ↓ 函数体内断言串
     "BWRootNode::onUpdate: Couldn't apply received volatile delta"
```

**★ 关于 `nret` 的 `vt=` 字段（重要澄清，防误用）**：
hooklab 的 `nret` 打出的 `vt=0x140398b10` **不是 vtable 起点**，而是对象 `[0]` 槽的值
（即 `scalar deleting destructor` 的函数地址）。
**它作为「类标识」完全有效**（每个类唯一），但**不能拿它去 `vtinfo --at`**（会失败）。
**vtable 起点要经 `qscan` 一步转换。** 这一点同时解释了「为何三次 `nret` 得到三个不同 `vt`」——
它们是**三个不同类**的 dtor，不是同一个 vtable 的多次采样。

---

## 2. consumer 函数体（§2.5 强烈建议 ①）

完整函数体（1228 B）见 **`C:\wot24\docs\evidence\sec_fun_140e379d0.c`**，
提取自 `C:\test\nixiang\decomp\chunks\c_140d47320.c` 第 `202974–203196` 行。

### 2.1 入口三条（`[读]`）

```c
undefined8 FUN_140e379d0(longlong param_1)          /* param_1 = BWRootNode* */
{
  local_58 = DAT_144379740 ^ (ulonglong)auStack_118;   /* 栈 cookie */
  cVar6 = FUN_140e6ffd0(param_1 + 0x58);               /* ① apply 收到的 volatile delta */
  if (cVar6 == '\0') {
    local_f8 = 0;
    uVar9 = FUN_1403da4e0(&local_d8, 0, 5, &DAT_14368b070);
    FUN_1403dad90(uVar9, "BWRootNode::onUpdate: Couldn't apply received volatile delta");
    return 0;
  }
  ...
```

### 2.2 ★★★ 函数名来自断言串（`[读]` 逐字）

整个函数里有**三条**断言串，全部以 `BWRootNode::onUpdate` 开头：

| # | 断言串（逐字） | 触发条件 | 语义 |
|---|---|---|---|
| 1 | `"BWRootNode::onUpdate: Couldn't apply received volatile delta"` | `FUN_140e6ffd0(param_1+0x58) == 0` | **入口即「应用收到的 volatile delta」，失败即返回** |
| 2 | `"BWRootNode::onUpdate: hashes match, but flags.size() != m_volatileNodeBuffer.size() (%d != %d)"` | `local_88 != ((param_1+0x90) − (param_1+0x88)) >> 3` | **位图长度必须 == volatile 节点数** |
| 3 | `"BWRootNode::onUpdate: hashes match, but data->remainingLength() = %d. Volatile node count = %d, updated %d nodes."` | `(*(*plVar10+0x10))(plVar10) == 0`（读完仍有剩余）且 `uVar17 != 0` | **读完必须恰好用尽** |

⇒ **「hashes match」** 三字说明这里有一条**哈希校验**在前置路径上（`FUN_140e6ffd0` 内部）。

### 2.3 ★★ 对象布局（`[读]`，与 §1.1 的 dtor 互证）

```
param_1 + 0x58    volatile delta 数据块（FUN_140e6ffd0 施加 / FUN_140e70690 消费 / FUN_140e70900 写入）
param_1 + 0x88    m_volatileNodeBuffer.begin      ← 元素 8 字节指针
param_1 + 0x90    m_volatileNodeBuffer.end
param_1 + 0x98    m_volatileNodeBuffer.capacity   （由 dtor 的 free 三元组读出）
param_1 + 0xa0    = FUN_140e6f610(local_b8) 的返回值，回存后作为消费的第 2 参数
param_1 + 0xa8    对象；其 vt+0x68 返回一个 u32，作为消费的第 3 参数
param_1 + 0x40    u32；低三字节被拆进 local_e8/e7/e6
param_1 + 0x18 → +0x48   取一个 shared_ptr（带引用计数）
param_1 + 0x28 / +0x30   一个 pair 数组的 begin/end（遍历用）
```

**★ 与 dtor `FUN_140398b10` 的互证（两条独立证据指向同一布局）**：
```c
/* FUN_140398b10 = BWRootNode 的 scalar deleting destructor */
free( *(param_1 + 0x88) );
*(param_1+0x88) = 0; *(param_1+0x90) = 0; *(param_1+0x98) = 0;   /* begin/end/cap 三清零 */
FUN_140398460(param_1 + 0x58);                                   /* 销毁 delta 块 */
FUN_140398730(param_1);                                          /* 销毁基类 */
if ((param_2 & 1) != 0) free(param_1);                           /* deleting 标志位 */
```

### 2.4 ★★ 消费循环（`[读]`，第 76–90 行）

```c
puVar14 = *(undefined8 **)(param_1 + 0x90);   /* end   */
puVar15 = *(undefined8 **)(param_1 + 0x88);   /* begin */
uVar16 = 0;  uVar17 = uVar16;                 /* uVar16=位序, uVar17=命中计数 */
if (CONCAT44(uStack_84,local_88) == (longlong)puVar14 - (longlong)puVar15 >> 3) {   /* 位图长 == 节点数 */
  for (; puVar15 != puVar14; puVar15 = puVar15 + 1) {
    uVar12 = uVar16 >> 5;                     /* 第几个 u32 */
    bVar4  = (byte)uVar16;
    uVar16 = uVar16 + 1;
    if ((1 << (bVar4 & 0x1f) & *(uint *)((longlong)local_a0 + uVar12 * 4)) != 0) {  /* 位图该位为 1 */
      (**(code **)(*(longlong *)*puVar15 + 0x60))((longlong *)*puVar15, plVar10);   /* ★ 派发 */
      uVar17 = uVar17 + 1;
    }
  }
```

⇒ **位图（bitmap）逐位对应 `m_volatileNodeBuffer` 的每个元素；置位的节点被调用其 `vt+0x60`。**

### 2.5 ★★★ 关键发现：`vt+0x60` 是**递归虚函数**

第 86 行：

```c
(**(code **)(*(longlong *)*puVar15 + 0x60))((longlong *)*puVar15, plVar10);
```

**`BWRootNode::onUpdate` 自己在遍历子节点、并对每个命中节点调用其 `vt+0x60`。**
而我们挂到的 `FUN_140e379d0`（node1 的 `vt+0x60`）**就是同一个虚函数**。

⇒ **`vt+0x60` = `BWPropertyNode::onUpdate(payload)`，一个被递归调用的虚函数。**
⇒ 0x39 流**只是它的数据来源之一**，不是它的专属入口。

**这解释了 `pun = 6304` 与 `nret = 14593` 为何差 2.3 倍**：
同一个 `onUpdate` 通过两条路被调用 —— ① 顶层（0x39 直接喂）② 父节点遍历子节点（第 86 行）。
`pun` 只数了路子 ①，`nret` 数了两条路之和。

**⇒ 对服务端设计的直接含义**：服务端要发的 0x39 「volatile delta」必须满足
**「恰好用尽」**（§2.2 断言 3）且**位图长度 == volatile 节点数**（§2.2 断言 2）。

---

## 3. 其他 nodeID 的普查表（§2.5 强烈建议 ②）

### 3.1 本场（WZ-219）各类节点出现次数（`[测]`，来自 `ev=nret` 14593 条）

| vtable VA | RTTI 类名 | `slot 0x00`（nret 采到的值） | 次数 |
|---|---|---|---|
| `0x1435DF3E8` | **`BW::BWRootNode`** | `0x140398b10` | **6304** |
| `0x1435DF550` | `BW::ClientPrimitivePropertyNode` | `0x140398c10` | 8166 |
| `0x1435DF5C8` | `BW::ClientCompositePropertyNode` | `0x140398c10` | （与上下两行共用） |
| `0x1435DF6B8` | `BW::ServerMethodCallerNode` | `0x140398c10` | （与上下两行共用） |
| `0x1435DF640` | `BW::ClientMethodCalleeNode` | `0x140398c90` | 123 |
| — | — | — | **合计 14593** |

**★★ 三个类共用同一个 deleting destructor `0x140398c10`** ——
即 `ClientPrimitivePropertyNode` / `ClientCompositePropertyNode` / `ServerMethodCallerNode`
**均无各自析构体**，编译器让它们共享。**⇒ `nret` 的 `vt=` 字段只能分辨到「组」，不能唯一标识类。**

### 3.2 ★ `BWRootNode` 6304 次 = `pun` 6304 条（三重独立计数吻合）

| 计数来源 | 值 |
|---|---|
| `ev=pun` 总条数（hooklab） | **6304** |
| `ev=nret` 中 `cls=.?AVBWRootNode@BW@@` | **6304** |
| 交接书 §2 引用的 WZ-219 条数 | **6304** |

⇒ **0x39 每条 delta 恰好触发一次根节点查表**（铁证）。

### 3.3 `nlook` 7000 条

`nlook`（`nodeLookup` @ `0xE736B0`）共 **7000** 条，`when=rdx eq 0x1`（只采 nodeID==1）。
其 `nodeID` 字段**读不到**（日志中恒为 `<unreadable>`），是当前工具的已知缺口。

---

## 4. 载荷形状（与 §2.5 铁验对齐）

### 4.1 三条实测 65B 帧（`[测]`，来自 frida `v1a3only` 变体）

```
GUID = 6ac4a9ce7e65ebca   ← ★ 与 §2.5 要求的铁验逐位一致
fn1: [8:12]=483083  [12:16]=0       [20:24]=00000100
fn2: [8:12]=483084  [12:16]=483083  [20:24]=00000120
fn3: [8:12]=483085  [12:16]=483084  [20:24]=00000120
```

| 偏移 | 字段 | 说明 |
|---|---|---|
| `[0:8]` | GUID | 本方车辆 GUID |
| `[8:12]` | u32 序号 | **严格 +1** |
| `[12:16]` | u32 前一序号 | **= 上一帧的 `[8:12]`**（滑动窗口 (cur, prev) 对） |
| `[16:20]` | u32 常量 | `c4c3d630`，全场恒定 |
| `[20:24]` | — | 第 1 帧 `00000100`，其后 `00000120` |
| `[24:28]` | — | `00272000` 恒定 |
| `[28:32]` | — | `00838201` 恒定 |
| `[32:63]` | **7 × f32** | 见 §4.2 |
| `[63:65]` | 尾 | `0120` 固定 |

### 4.2 hooklab 侧 6304 条全量统计（`[测]`，来自 `payload.bin` 528,803 B）

- 记录数 **6304**，残留 **0**，GUID 前缀命中 **6304/6304 (100%)**
- `[8:12]` 在 6076 个 delta 中 **6041 个为 +1**
- 7 个 f32 的取值范围：
  - f1 ∈ [0.448, 16.675] **全为正**（量纲像速度）
  - f3 / f5 ∈ [±959.6, ±960.0]（量纲像**角度**，接近 ±960）
  - f6 ∈ [0.003, 0.036]（量纲像**时间步长**）

**★ 待办（本项目 A 未覆盖）**：`[32:63]` 的 7 个 f32 **字段命名**未做 ——
交接书 §2.6 说要用「消费者函数的静态结构对 **15B 参数区**做位域切分」。
**注意：交接书设想的「15B 参数区」与本次实测的 65B 载荷不是同一层**
（65B = 进入 consumer 时的 **stream 剩余**，与交接书 §2.5「`remain_n` = 65」口径一致）。
**15B 参数区的位域切分本轮未做**，需要 consumer 内部对 `plVar10` 的进一步下钻。

---

## 5. 跨场稳定性（§2.5 强烈建议 ③）

**★ 用户指路后已推进：回放目录 = `\\vmware-host\Shared Folders\World_of_Tanks_CN\replays\`**
（= 游戏机的 `F:\World_of_Tanks_CN\replays\`，**同一个目录**）。
karelia 场在库，用了 9-16 及之前的那份：

```
20260906_1529_germany-G189_Hirschkafer_01_karelia.wotreplay   2,650,951 B
```

### 5.1 离线已答的一半：**载荷形状跨场同形**（`[测]`）

| 项 | WZ-219 | **karelia** | 一致？ |
|---|---|---|---|
| 0x39 条数 | 6304 | **5832**（= 交接书写的 5,832） | ✅ |
| 长度分布 | 72B / 41B | **72B × 5616 + 41B × 216** | ✅ |
| GUID 种类 | 1 种 | **1 种**（`2bb7a4eab8ec5798`） | ✅ 各场恒定 |
| 序号 delta | 6041/6076 = +1 | **+1 × 5831，100%** | ✅ |
| 前导 3B | `060001` | **`060001` × 5832/5832** | ✅ |
| `[27:31]` | `…0120`，第1条 `…0100` | **同**（5831 + 首条 1） | ✅ |
| 尾 2B | `0120` | **`0120` × 5616，41B 型没有** | ✅ |
| 铁验 `remain_n` | 65 / 34 | **72−7=65 / 41−7=34** | ✅ |

**⇒ 载荷形状与 WZ-219 完全同形。** 且**「41B 型 = 72B 型去掉尾部 31B」**由此确认。

**★ `0x39` 的 wire 形状（`[读]`，decomp `FUN_14058e4c0`）**：
```c
iVar2 = *(int *)(param_3 + 0x20);          /* n = 载荷长度 */
FUN_1405846e0(local_28, param_2, uVar4, iVar2 + 4);   /* 声明总长 = n + 4 */
if (*(int *)(param_3 + 0x20) != 0) {
    local_res20[0] = *(int *)(param_3 + 0x20);
    FUN_140584790(local_28, local_res20, 4);                          /* [u32 n] */
    FUN_140584790(local_28, *(undefined8 *)(param_3 + 0x28), local_res20[0]);  /* n 字节原样透传 */
}
```
⇒ **`0x39` 载荷 = `[u32 n][n 字节原样透传]`**，且这是
`WGReplayMessageHandler::getFile` 族 —— **「把收到的原始流原样录下来」**，
印证交接书 §2 说的「回放里 0x39 的载荷是重新喂回消息泵的原始字节」。

### 5.2 ★★★ 另一半已答：**node1 类名/vtable consumer 跨场完全一致**（`[测]`）

**karelia 复跑包已由用户跑完**（回传：`hooklab-r2-20260929-210433\logs\`）。
四个断点全部命中（`pun` / `nlook` / `nret` / `n1`），attach @16.4s 正常。

**karelia 场四个 vtable × consumer 全表（`[测]`）**：

| vtable VA | RTTI 类名（离线 `vtinfo` 解） | consumer | karelia 次数 | WZ-219 次数 |
|---|---|---|---|---|
| **`0x1435DF3E8`** | **`BW::BWRootNode`** | **`0x140E379D0`** | **5832** | **6304** |
| `0x1435DF5C8` | `BW::ClientCompositePropertyNode` | `0x140399AA0` | 7942 | 8166* |
| `0x1435DF550` | `BW::ClientPrimitivePropertyNode` | `0x140399E20` | 1611 | 同上 |
| `0x1435DF640` | `BW::ClientMethodCalleeNode` | `0x140399BE0` | 117 | 123 |

**⇒ 类名与 vtable 逐位一致；`node1` 的 `vt=0x1435DF3E8` → `consumer=0x140E379D0`
在两场完全相同。第 ③ 条闭合。**

**★★ 三重计数吻合（karelia）**：

| 计数来源 | 值 |
|---|---|
| `ev=pun` 总条数 | **5832** |
| `ev=nret` 中 `vt=0x1435df3e8`（`BWRootNode`） | **5832** |
| 离线从回放读出的 `type 0x39` 条数 | **5832** |

**⇒ 「0x39 每条 delta 恰好触发一次根节点查表」在第二场独立复现。**

**★ 铁验一（karelia，`[测]`）**：

| 项 | 实测 | 交接书 §2.5 要求 | |
|---|---|---|---|
| `nodeID` | **1**（5832/5832） | node1 | ✅ |
| `remain_n` | **65 × 5616 + 34 × 216** | 65（72B 型）/ 34（41B 型） | ✅ |
| `head8` | **`2bb7a4eab8ec5798` × 5832** | 本场 GUID | ✅ |
| `cons_ok` | **1**（15502/15502） | — | ✅ |

**★ 本轮修掉一个会误导结论的工具缺陷**：
`hooklab` 里 `guid_ok` 的基准原来**写死 WZ-219 的 `6ac4a9ce7e65ebca`** ⇒
换 karelia 场跑时**全场 5832 条齐刷刷报 `guid_ok=0`，而铁验其实 100% 通过**。
**已改为运行时自动学**（第一条 node1 帧的 head8 即基准），跨场不用改常量。
（这条值得记：**写死的「真值」在换输入后会变成假警报**。）


### 5.3 本轮为它做的工具改动

- `--replay <文件名>`：原来回放名**硬编码**在 bat 里；加了 cmd 特殊字符校验
  （防 `)` 落进 `if` 块 —— 闸门 55 / batcheck 拦这个）。
- **README 里的 GUID/场次名按本轮填真值**：`read_replay_guid()` 直接从该场回放
  读 `0x39` 的 `[7:15]`，读不到写占位符 —— **绝不写死一个看着像真的值**
  （第 290 轮的「注释在撒谎」就是这个成因）。
- `--list-replays`：把游戏机 `replays\*.wotreplay` 清单写进 `logs\replays_list.txt`。
  **（用户指路后此包已非必需 —— 路径本来就能读。）**


---

## 6. 工具路线对照（R5：两条路线互不背书）

| | Frida 路线（交接书 §2.1–2.3） | hooklab 路线（本报告） |
|---|---|---|
| 机制 | `Interceptor.attach`（in-process 注入） | **外部调试器 + 硬件断点**（零注入） |
| A1 (`nlook`) | 装好但**无命中** | `nlook` 7000 条 |
| A3 (`pun`) | 只 **3 条**（`v1a3only` 变体） | **6304 条** |
| A2 (consumer 读) | **三次变体全 `NO-CONSUMER`** | ✅ 经 vtable 反解得到 §1.1 |
| 稳定性 | `full` 变体 0 命中；native 层崩溃 | 全程 14593+7000 条无异常 |

**★ 两路线一致的部分**：`pun` 事件里 node1 的 `remain_n=65` 且 `remain_hex` 以 `6ac4a9ce7e65ebca` 开头 ——
**两条独立实现的工具采到同一事实**（这是本轮唯一的 R5 级互证）。

---

## 7. 链条对账（R6）

| 环 | 内容 | 等级 |
|---|---|---|
| ① `nret` 采到 node1 对象 `[0]` 槽 = `0x140398b10` | hooklab 实测 | **[测]** |
| ② `0x140398b10` 唯一引用点 = `0x1435DF3E8` | `qscan.py` | **[读]** |
| ③ `0x1435DF3E8` 的 COL → `.?AVBWRootNode@BW@@` | `vtinfo.py` | **[读]** |
| ④ 该 vtable `slot 0x60` = `0x140E379D0` | `vtinfo.py` | **[读]** |
| ⑤ `FUN_140e379d0` 体内断言串自报 `BWRootNode::onUpdate` | decomp 原文 | **[读]** |
| ⑥ `+0x88/+0x90/+0x98` 布局由 dtor `FUN_140398b10` 独立印证 | decomp 原文 | **[读]** |
| ⑦ `slot 0x60` 被本函数第 86 行递归调用 | decomp 原文 | **[读]** |
| ⑧ `6304 = 6304 = 6304` 三重计数吻合 | 实测 + 交接书 | **[测]** |
| ⑨ 65B 载荷字段布局（GUID/序号对/常量/7×f32/尾） | 三条实测帧 + payload.bin | **[测]** |
| ⑩ **7 个 f32 的字段命名** | — | **[未解]** |
| ⑪ **15B 参数区的位域切分**（交接书 §2.6 的正题） | — | **[未解]** |
| ⑫ **karelia 跨场复跑** | 载荷同形 + 类名/vtable/consumer 全一致 | **✅ 已答**（见 §5.2） |
| ⑬ `nlook` 的 `nodeID` 字段读不到 | — | **[未解]** |

**剩余 `[推]`：0。剩余 `[未解]`：3（⑩⑪⑬）。**
⇒ **链条对账未清 ⇒ 本报告不称「闭环」。**
**但 §2.5 的「必达」两条已 100% 达成**（§1.1 的 vtable/类名/consumer + §4.1 的铁验）。

---

## 8. 与交接书的差异（如实列出）

1. **§2.4「游戏内 → 回放页 → 播放」不存在** —— 该客户端**无回放页**；
   回放以**命令行参数**传给 EXE 启动（已实测）。
2. **交接书设想 Frida 决定成败** —— 实际 **Frida 三变体全 `NO-CONSUMER`**，
   结论由 hooklab（零注入外部调试器）取得。
3. **交接书称 `consumer = vt + 0x60` 的 `vt` 是 vtable 起点** ——
   hooklab 采到的值经确认是 **`[0]` 槽**；两者相差一次 `qscan` 换算（§1.3）。
