# reportB —— 交接书 §3 项目 B 回传

**日期**：2026-09-29
**装置**：hooklab（外部调试器 + 硬件执行断点，零注入）
**目标 exe**：`F:\World_of_Tanks_CN\win64\WorldOfTanks.exe`（2.4.0.10161 #2616763）

---

## 0. 一句话

**必达项未取得。** 三次运行均无 `md5_digest` 记录产出。

---

## 1. §3.5 验收标准逐项

### 必达

- [ ] **至少一条 `md5_digest` 记录 `hit_target: true`**

  **未取得。** 三次运行 `ev=md5_hit_dump 无命中`。

- [ ] **该记录的 `in_hex` 完整、`total_in` / `n_updates` 有值**

  **未取得。** 无命中记录。

### 强烈建议

- [ ] **命中记录的 `in_hex` 另存 `digest_input.bin`**

  **未产出。** 文件不存在。

- [ ] **全部非命中的 digest 值列表**

  **为空。** `ev=md5_digests_seen` 未出现。

---

## 2. 三次运行

| | 运行 1 | 运行 2 | 运行 3 |
|---|---|---|---|
| 模式 | `--startup` | `--startup` | `--native` |
| attach 时刻 | @15.3s | **@0.0s** | **@0.0s** |
| armed 线程 | 122 | 213 | 279 |
| 观测时长 | 79s | 34s | 137s |
| `md5w` 命中 | 0 | **0** | **0** |
| `md5c` 命中 | 0 | **0** | **0** |
| `md5z` 命中 | 0 | **0** | **0** |
| `md5_compress_blocks` | 0 | **0** | **0** |
| 客户端到达 | 登录界面 | 登录界面 | **inWorld=True / isStarted=True** |

### 收尾三行（三次一致；运行 1 的 `attach_at` 为 `15s`）

```
ev=hit_first_seen attach_at=0s md5w=never md5c=never md5z=never
ev=md5_hit_dump 无命中（本局没采到目标 digest）
ev=md5_compress_blocks n=0 （0 ⇒ 本场没有任何 MD5 计算执行）
```

### 断点

三次均为：

```
hardware breakpoints: Dr0=0x1403e82f0 Dr1=0x142a9b640 Dr2=0x1403e8620
```

挂点地址与指纹按附录 X1 逐条核对，`hooklab_sigcheck` 全部通过：

```
[OK] md5w     RVA 0x3e82f0   -> VA 0x1403e82f0   mov qword ptr [rsp + 0x18], rbx
[OK] md5c     RVA 0x2a9b640  -> VA 0x142a9b640   push rbx
[OK] md5z     RVA 0x3e8620   -> VA 0x1403e8620   mov qword ptr [rsp + 8], rbx
```

### 运行 3 客户端状态（`logsB_3/wot24.log`，21:59:54）

```
player=PlayerAvatar playerVehicleID=546611525 | initProgress=63(15=ALL_STEPS_PASSED)
inWorld=True | spaceID=805306369 | isStarted=True | entity=True
typeDescriptor='china:Ch71_WZ_219' | health=1900
team=2 | rosterOwn(team/isAlive/name)=(2, 1, 'wot24_player')
arena.vehicles=1 hasOwn=True
```

战斗周期在推进：

```
21:59:52.499 arena period=1 endTime=15 serverTime=14.965
22:00:02.496 arena period=2 endTime=25 serverTime=24.948
```

---

## 3. §3.6 排障条目对照

### 「worker 有流量但 digest() 从不触发」

**答：worker 无流量。**

原 B2 挂点 `FUN_1402ed600`（`digest()`）在运行 1 中命中 **378 次**。
该地址全映像有 **30+ 个调用点**（`ripxref 0x2ED600` 输出 30 条），
命中全部来自其它调用者。`MD5Calculator` 路径未产出 `md5_digest` 记录。

### 「digest() 触发但 16B 对不上目标」

**答：不适用。** `digest()` 未产出记录。

### 「完全无流量」

排障处置原文：**「attach 太晚（计算已结束）。必须 spawn 模式重来。」**

**答：已按此重做。**

运行 2、3 的 attach 时刻为 `@0.0s` —— 在目标进程第一条用户指令之前，
断点在 `CREATE_PROCESS_DEBUG_EVENT` 时即已安装（`abs = base + offset`），
后续每个 `CREATE_THREAD_DEBUG_EVENT` 都调用 `arm_thread`。
armed 线程数 213（运行 2）/ 279（运行 3）。

结果仍为 `md5w=never md5c=never md5z=never`。

### 运行 2/3 的客户端进度

运行 2（`logsB_2/game.log`）：

```
21:52:46.495  [SCRIPT] [PY_DEBUG] Checking F:/World_of_Tanks_CN/res_mods/2.4.0.0/: mods found
21:52:56.596  [SCRIPT] [game_loading] Game loaded in 16.462 seconds and 59 steps
21:52:57.556  [SCRIPT] [gui.app_loader.loader] Space is changed: WaitingSpace() -> LoginSpace()
```

attach 时刻早于以上全部行。

---

## 4. 挂点表核对（`C:\test\nixiang\decomp`）

### §3.1 的 15 槽表，逐槽核实

vtable 起址 `0x1439230B8`（§3.1 记载），表头 COL `0x1439230B0`。

| 槽 | 实际地址 | §3.1 描述 | 核对 |
|---|---|---|---|
| 0 | `0x142a9b580` | 析构 | 符 |
| 1 | `0x1402f7290` | 空钩 | 符 |
| 2 | `0x1402f7290` | 空钩 | 符 |
| 3 | `0x1402f7290` | 空钩 | 符 |
| 4 | `0x1402f7290` | 空钩 | 符 |
| 5 | `0x1403e8290` | `update(u32)` | 符 |
| 6 | `0x1403e8260` | `update(u16)` | 符 |
| 7 | `0x1403e8230` | `update(u8)` | 符 |
| 8 | `0x1403e8290` | `update(u32)` | 符 |
| 9 | `0x1403e8260` | `update(u16)` | 符 |
| 10 | `0x1403e8230` | `update(u8)` | 符 |
| 11 | `0x1403e8230` | `update(u8)` | 符 |
| 12 | `0x1403e8210` | `update(std::string)` | 符 |
| 13 | `0x1403e81e0` | `update(const char*)` | 符 |
| 14 | `0x1402ed600` | `digest()` | 符 |

各族重复次数与 §3.1 描述一致（1-4 空钩 ×4、5/8 ×2、6/9 ×2、7/10/11 ×3）。

**`md5w`（`0x3E82F0`）不在这 15 槽内。**

### `md5w` 是「唯一咽喉」的核对

`ripxref 0x3E82F0` 输出 7 条，全部落在 `0x1403E8201 .. 0x1403E856D`：

```
0x1403E8201  0x1403E8226  0x1403E824C  0x1403E827D
0x1403E82AC  0x1403E82CA  0x1403E856D
```

### `md5z`（`0x3E8620`，compress）的调用点

`ripxref 0x3E8620` 输出 4 条：

| 调用点 | 所属函数 |
|---|---|
| `0x1403E839E` | `FUN_1403e82f0`（= `md5w`） |
| `0x1403E83CA` | `FUN_1403e82f0`（= `md5w`） |
| `0x1403E850E` | `FUN_1403e8410` |
| `0x1403E853A` | `FUN_1403e8410` |

`FUN_1403e8410` 的唯一调用者为 `FUN_1403e82e0`；
`FUN_1403e82e0` 的唯一调用者为 `FUN_142a9b640`（= `md5c`）。

### 基类 `IMD5Calculator`

`0x143EA0030` → RTTI `.?AVIMD5Calculator@BW@@`
（TypeDescriptor 直读：`0x14479d358`，名称在 `+0x10`）。

其 vtable 起址 `0x143923038`，槽 1–7 全为 `0x142c96cb2`（`_purecall`）。

**全映像引用 `0x143EA0030` 的位置只有一处**：`0x143923030`。

### 调用链

`FUN_142a9b640`（`md5c`）全映像唯一调用点 = `0x140394571`，
位于 `FUN_140394440` = `BW::EntityType::init`（`entity_type.cpp`）。

`FUN_140394440` 全映像唯一调用点 = `0x14038210B`，
位于 `FUN_140381660` = `BW::BigWorldClientScript::init`（`script_bigworld.cpp`）。

`FUN_142a9b640` 反编译体：

```c
undefined8 * FUN_142a9b640(undefined8 *param_1, undefined8 param_2, code *param_3)
{
  local_28 = DAT_144379740 ^ (ulonglong)auStack_a8;
  *param_1 = 0;
  param_1[1] = 0;
  local_88 = BW::MD5Calculator::vftable;
  FUN_1403e8140(local_80);            /* MD5 init */
  (*param_3)(param_2,&local_88);      /* 喂数据 */
  FUN_1403e82e0(local_80,param_1);    /* finalize */
  return param_1;
}
```

调用点实参（`0x14039455B` / `0x140394562` / `0x140394569`）：

```
lea r8,  [rip + 0x270704e]  ; = 0x142A9B5B0   param_3
lea rdx, [rip + 0x44a9ae7]  ; = 0x14483E050   param_2
lea rcx, [rbp + 0xd0]                          param_1
call 0x142a9b640
```

结果写出到 `0x14483E028` / `0x14483E038` / `0x14483E040`（`0x140394586` 起）。

`param_3` = `FUN_142a9b5b0`，体内：

```c
local_28 = BW::AbstractMD5Visitor::vftable;
local_20 = param_2;
(**(code **)(*param_2 + 0x18))(param_2,0,0);
local_28 = BW::ClientServerTypesMD5Visitor::vftable;
FUN_142a9b410(param_1,&local_28);
```

`FUN_142a9b410` 遍历步长 `0x328`，对每个描述调 `FUN_142a93420`；
后者对成员按 `0xf0` 步长、对方法按 `0x170` 步长继续遍历。

---

## 5. 关于 B2 挂点的说明

§3.2 的 B2 定为 `FUN_1402ed600`（`digest()`）。
该地址全映像 30+ 个调用点（`ripxref 0x2ED600`）。

`FUN_142a9b640`（`md5c`）体内**不调用** `digest()` —— 它直接调 `FUN_1403e82e0`
做 finalize，结果写进 `param_1`。

本次运行 2、3 把结果读取点改到 `md5c` 入口的 `RCX`
（`FUN_142a9b640` 末行 `return param_1;`，返回值恒等于 `RCX`），
读 `+8`（`digest_at_this8`）与 `+0x10`（`digest_at_state`）两处。

三种设置下 `md5_digest` 记录均为 0 条。

---

## 6. 链条对账

| 环 | 内容 | 等级 |
|---|---|---|
| ① 挂点地址/指纹与附录 X1 一致 | `hooklab_sigcheck` 全部通过 | **[读]** |
| ② 15 槽 vtable 与 §3.1 逐槽吻合 | `exe_ref read 0x1439230B8` | **[读]** |
| ③ `md5w` 是 7 个 update 槽的唯一咽喉 | `ripxref 0x3E82F0`（7 条） | **[读]** |
| ④ `md5z` 调用点全落在 `md5w`/`FUN_1403e8410` 内 | `ripxref 0x3E8620`（4 条） | **[读]** |
| ⑤ 基类 `IMD5Calculator` 全纯虚；引用处唯一 | `vtinfo` + `qscan` | **[读]** |
| ⑥ `md5c` → `EntityType::init` → `BigWorldClientScript::init` 逐级唯一 | `ripxref` | **[读]** |
| ⑦ 三次运行 `md5w`/`md5c`/`md5z` 命中均为 0 | `hooklab.log` ×3 | **[测]** |
| ⑧ 三次 `ev=md5_compress_blocks n=0` | 同上 | **[测]** |
| ⑨ 运行 3 客户端 `inWorld=True` / `isStarted=True` | `wot24.log` | **[读]** |
| ⑩ 必达项 `hit_target=1` | — | **[未做]** |

**剩余 `[推]`：0。剩余 `[未做]`：1（必达项 1）。**

---

## 7. 回传文件

| 文件 | 内容 |
|---|---|
| `report/reportA.md` | 项目 A 报告 |
| `report/reportB.md` | 本文件 |
| `report/sec_fun_140e379d0.c` | 项目 A：consumer 函数体全文（222 行） |
| `report/sec-0x39-15B-paramarea.md` | 项目 A：§2.6 参数区核对 |
| `logsA/hooklab-WZ219.log` | 项目 A：WZ-219 场 |
| `logsA/hooklab-karelia.log` | 项目 A：karelia 场 |
| `logsB_1/hooklab.log` | 项目 B 运行 1（`--startup`，@15.3s） |
| `logsB_2/hooklab.log` | 项目 B 运行 2（`--startup`，@0.0s） |
| `logsB_2/game.log` | 项目 B 运行 2 的客户端日志 |
| `logsB_3/hooklab.log` | 项目 B 运行 3（`--native`，@0.0s） |
| `logsB_3/game.log` | 项目 B 运行 3 的客户端日志 |
| `logsB_3/wot24.log` | 项目 B 运行 3 的 mod 日志（含 inWorld 状态） |

**未产出**：`digest_input.bin`、`projectB_log.jsonl`、非命中 digest 清单。
