项目 A / 项目 B 回传 —— 2026-09-29
==================================

装置：hooklab（外部调试器 + 硬件执行断点 Dr0-Dr3，零注入，无 onLeave）
目标：F:\World_of_Tanks_CN\win64\WorldOfTanks.exe（2.4.0.10161 #2616763）
交接书：Hook交接说明书_本地AI执行版.md


目录
====
  report\                    报告
    reportA.md               项目 A 报告（§2.5）
    reportB.md               项目 B 报告（§3.5）
    sec_fun_140e379d0.c      项目 A：consumer 函数体全文
    sec-0x39-15B-paramarea.md 项目 A：§2.6 参数区核对

  logsA\                     项目 A 的两场原始日志
    hooklab-WZ219.log        WZ-219 场（targets: pun,nlook,nret）
    hooklab-karelia.log      karelia 场（targets: pun,nlook,nret）

  logsB_1\ logsB_2\ logsB_3\ 项目 B 的三次运行原始日志
    hooklab.log              hooklab 输出
    game.log                 引擎日志（部分）
    wot24.log                mod 日志（部分）


项目 A 结论（§2.5）
==================
必达两项：取得。
  ① node1 consumer = BW::BWRootNode::onUpdate = 0x140E379D0
     vtable 0x1435DF3E8 / RTTI .?AVBWRootNode@BW@@ / slot 0x60
  ② WZ-219 6304/6304 条 remain_hex 以 6ac4a9ce7e65ebca 开头，remain_n=65

强烈建议三项：全部完成。karelia 场四类 vtable×consumer 与 WZ-219 逐位一致。

详见 report\reportA.md。


项目 B 结论（§3.5）
==================
必达两项：未取得。
强烈建议两项：未取得（digest_input.bin 未产出；非命中 digest 清单为空）。

三次运行，md5w / md5c / md5z 命中均为 0，ev=md5_compress_blocks n=0。
运行 3 客户端已 inWorld=True / isStarted=True（连我方服务端、进战斗）。

详见 report\reportB.md。


未产出的文件
============
  digest_input.bin
  projectB_log.jsonl      （装置为 hooklab，原始输出为 hooklab.log）
  非命中 digest 清单
